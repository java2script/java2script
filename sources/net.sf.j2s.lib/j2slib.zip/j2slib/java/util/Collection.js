$_L(["java.lang.Iterable"],"java.util.Collection",null,function(){
$_I(java.util,"Collection",Iterable);
});
