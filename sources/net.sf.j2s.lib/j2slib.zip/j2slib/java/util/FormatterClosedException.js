$_L(["java.lang.IllegalStateException"],"java.util.FormatterClosedException",null,function(){
c$=$_T(java.util,"FormatterClosedException",IllegalStateException,java.io.Serializable);
$_K(c$,
function(){
$_R(this,java.util.FormatterClosedException,[]);
});
});
