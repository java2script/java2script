﻿$_L(null,"java.util.Observable",["java.lang.NullPointerException","java.util.Vector"],function(){
c$=$_C(function(){
this.changed=false;
this.obs=null;
$_Z(this,arguments);
},java.util,"Observable");
$_K(c$,
function(){
this.obs=new java.util.Vector();
});
$_M(c$,"addObserver",
function(o){
if(o==null)throw new NullPointerException();
if(!this.obs.contains(o)){
this.obs.addElement(o);
}},"java.util.Observer");
$_M(c$,"deleteObserver",
function(o){
this.obs.removeElement(o);
},"java.util.Observer");
$_M(c$,"notifyObservers",
function(){
this.notifyObservers(null);
});
$_M(c$,"notifyObservers",
function(arg){
var arrLocal;
{
if(!this.changed)return;
arrLocal=this.obs.toArray();
this.clearChanged();
}for(var i=arrLocal.length-1;i>=0;i--)(arrLocal[i]).update(this,arg);

},"~O");
$_M(c$,"deleteObservers",
function(){
this.obs.removeAllElements();
});
$_M(c$,"setChanged",
function(){
this.changed=true;
});
$_M(c$,"clearChanged",
function(){
this.changed=false;
});
$_M(c$,"hasChanged",
function(){
return this.changed;
});
$_M(c$,"countObservers",
function(){
return this.obs.size();
});
});
