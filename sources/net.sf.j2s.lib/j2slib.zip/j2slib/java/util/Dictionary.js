c$=$_T(java.util,"Dictionary");
