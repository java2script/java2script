﻿$_L(["java.util.AbstractMap","$.AbstractSet","$.Iterator","$.Map","$.SortedMap","java.util.TreeMap.SubMap"],"java.util.TreeMap",["java.io.IOException","java.lang.IllegalArgumentException","$.IllegalStateException","$.InternalError","java.util.AbstractCollection","$.ConcurrentModificationException","$.NoSuchElementException"],function(){
c$=$_C(function(){
this.$comparator=null;
this.root=null;
this.$size=0;
this.modCount=0;
this.$entrySet=null;
if(!$_D("java.util.TreeMap.SubMap")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.fromStart=false;
this.toEnd=false;
this.fromKey=null;
this.toKey=null;
this.$entrySet=null;
if(!$_D("java.util.TreeMap.SubMap.EntrySetView")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.$size=-1;
this.sizeModCount=0;
$_Z(this,arguments);
},java.util.TreeMap.SubMap,"EntrySetView",java.util.AbstractSet);
$_V(c$,"size",
function(){
if(this.$size==-1||this.sizeModCount!=this.b$["java.util.TreeMap"].modCount){
this.$size=0;
this.sizeModCount=this.b$["java.util.TreeMap"].modCount;
var a=this.iterator();
while(a.hasNext()){
this.$size++;
a.next();
}
}return this.$size;
});
$_V(c$,"isEmpty",
function(){
return!this.iterator().hasNext();
});
$_V(c$,"contains",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
var c=b.getKey();
if(!this.b$["java.util.TreeMap.SubMap"].inRange(c))return false;
var d=this.b$["java.util.TreeMap"].getEntry(c);
return d!=null&&java.util.TreeMap.valEquals(d.getValue(),b.getValue());
},"~O");
$_V(c$,"remove",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
var c=b.getKey();
if(!this.b$["java.util.TreeMap.SubMap"].inRange(c))return false;
var d=this.b$["java.util.TreeMap"].getEntry(c);
if(d!=null&&java.util.TreeMap.valEquals(d.getValue(),b.getValue())){
this.b$["java.util.TreeMap"].deleteEntry(d);
return true;
}return false;
},"~O");
$_V(c$,"iterator",
function(){
return $_N(java.util.TreeMap.SubMapEntryIterator,this,null,(this.b$["java.util.TreeMap.SubMap"].fromStart?this.b$["java.util.TreeMap"].firstEntry():this.b$["java.util.TreeMap"].getCeilEntry(this.b$["java.util.TreeMap.SubMap"].fromKey)),(this.b$["java.util.TreeMap.SubMap"].toEnd?null:this.b$["java.util.TreeMap"].getCeilEntry(this.b$["java.util.TreeMap.SubMap"].toKey)));
});
c$=$_P();
}
$_Z(this,arguments);
},java.util.TreeMap,"SubMap",java.util.AbstractMap,[java.util.SortedMap,java.io.Serializable]);
$_Y(c$,function(){
this.$entrySet=$_N(java.util.TreeMap.SubMap.EntrySetView,this,null);
});
$_K(c$,
function(a,b){
$_R(this,java.util.TreeMap.SubMap,[]);
if(this.b$["java.util.TreeMap"].compare(a,b)>0)throw new IllegalArgumentException("fromKey > toKey");
this.fromKey=a;
this.toKey=b;
},"~O,~O");
$_K(c$,
function(a,b){
$_R(this,java.util.TreeMap.SubMap,[]);
this.b$["java.util.TreeMap"].compare(a,a);
if(b){
this.fromStart=true;
this.toKey=a;
}else{
this.toEnd=true;
this.fromKey=a;
}},"~O,~B");
$_K(c$,
function(a,b,c,d){
$_R(this,java.util.TreeMap.SubMap,[]);
this.fromStart=a;
this.fromKey=b;
this.toEnd=c;
this.toKey=d;
},"~B,~O,~B,~O");
$_V(c$,"isEmpty",
function(){
return this.$entrySet.isEmpty();
});
$_V(c$,"containsKey",
function(a){
return this.inRange(a)&&this.b$["java.util.TreeMap"].containsKey(a);
},"~O");
$_V(c$,"get",
function(a){
if(!this.inRange(a))return null;
return this.b$["java.util.TreeMap"].get(a);
},"~O");
$_V(c$,"put",
function(a,b){
if(!this.inRange(a))throw new IllegalArgumentException("key out of range");
return this.b$["java.util.TreeMap"].put(a,b);
},"~O,~O");
$_V(c$,"comparator",
function(){
return this.b$["java.util.TreeMap"].$comparator;
});
$_V(c$,"firstKey",
function(){
var a=java.util.TreeMap.key(this.fromStart?this.b$["java.util.TreeMap"].firstEntry():this.b$["java.util.TreeMap"].getCeilEntry(this.fromKey));
if(!this.toEnd&&this.b$["java.util.TreeMap"].compare(a,this.toKey)>=0)throw(new java.util.NoSuchElementException());
return a;
});
$_V(c$,"lastKey",
function(){
var a=java.util.TreeMap.key(this.toEnd?this.b$["java.util.TreeMap"].lastEntry():this.b$["java.util.TreeMap"].getPrecedingEntry(this.toKey));
if(!this.fromStart&&this.b$["java.util.TreeMap"].compare(a,this.fromKey)<0)throw(new java.util.NoSuchElementException());
return a;
});
$_V(c$,"entrySet",
function(){
return this.$entrySet;
});
$_V(c$,"subMap",
function(a,b){
if(!this.inRange2(a))throw new IllegalArgumentException("fromKey out of range");
if(!this.inRange2(b))throw new IllegalArgumentException("toKey out of range");
return $_N(java.util.TreeMap.SubMap,this,null,a,b);
},"~O,~O");
$_V(c$,"headMap",
function(a){
if(!this.inRange2(a))throw new IllegalArgumentException("toKey out of range");
return $_N(java.util.TreeMap.SubMap,this,null,this.fromStart,this.fromKey,false,a);
},"~O");
$_V(c$,"tailMap",
function(a){
if(!this.inRange2(a))throw new IllegalArgumentException("fromKey out of range");
return $_N(java.util.TreeMap.SubMap,this,null,false,a,this.toEnd,this.toKey);
},"~O");
$_M(c$,"inRange",
($fz=function(a){
return(this.fromStart||this.b$["java.util.TreeMap"].compare(a,this.fromKey)>=0)&&(this.toEnd||this.b$["java.util.TreeMap"].compare(a,this.toKey)<0);
},$fz.isPrivate=true,$fz),"~O");
$_M(c$,"inRange2",
($fz=function(a){
return(this.fromStart||this.b$["java.util.TreeMap"].compare(a,this.fromKey)>=0)&&(this.toEnd||this.b$["java.util.TreeMap"].compare(a,this.toKey)<=0);
},$fz.isPrivate=true,$fz),"~O");
c$=$_P();
}
if(!$_D("java.util.TreeMap.EntryIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.expectedModCount=0;
this.lastReturned=null;
this.$next=null;
$_Z(this,arguments);
},java.util.TreeMap,"EntryIterator",null,java.util.Iterator);
$_Y(c$,function(){
this.expectedModCount=this.b$["java.util.TreeMap"].modCount;
});
$_K(c$,
function(){
this.$next=this.b$["java.util.TreeMap"].firstEntry();
});
$_K(c$,
function(a){
this.$next=a;
},"java.util.TreeMap.Entry");
$_V(c$,"hasNext",
function(){
return this.$next!=null;
});
$_M(c$,"nextEntry",
function(){
if(this.$next==null)throw new java.util.NoSuchElementException();
if(this.b$["java.util.TreeMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
this.lastReturned=this.$next;
this.$next=this.b$["java.util.TreeMap"].successor(this.$next);
return this.lastReturned;
});
$_V(c$,"next",
function(){
return this.nextEntry();
});
$_V(c$,"remove",
function(){
if(this.lastReturned==null)throw new IllegalStateException();
if(this.b$["java.util.TreeMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
if(this.lastReturned.left!=null&&this.lastReturned.right!=null)this.$next=this.lastReturned;
this.b$["java.util.TreeMap"].deleteEntry(this.lastReturned);
this.expectedModCount++;
this.lastReturned=null;
});
c$=$_P();
}
if(!$_D("java.util.TreeMap.KeyIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.TreeMap,"KeyIterator",java.util.TreeMap.EntryIterator,null,$_N(java.util.TreeMap.EntryIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().key;
});
c$=$_P();
}
if(!$_D("java.util.TreeMap.ValueIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.TreeMap,"ValueIterator",java.util.TreeMap.EntryIterator,null,$_N(java.util.TreeMap.EntryIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.nextEntry().value;
});
c$=$_P();
}
if(!$_D("java.util.TreeMap.SubMapEntryIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.firstExcludedKey=null;
$_Z(this,arguments);
},java.util.TreeMap,"SubMapEntryIterator",java.util.TreeMap.EntryIterator,null,$_N(java.util.TreeMap.EntryIterator,this,null,$_G));
$_K(c$,
function(a,b){
$_R(this,java.util.TreeMap.SubMapEntryIterator,[a]);
this.firstExcludedKey=(b==null?b:b.key);
},"java.util.TreeMap.Entry,java.util.TreeMap.Entry");
$_V(c$,"hasNext",
function(){
return this.$next!=null&&this.$next.key!=this.firstExcludedKey;
});
$_V(c$,"next",
function(){
if(this.$next==null||this.$next.key==this.firstExcludedKey)throw new java.util.NoSuchElementException();
return this.nextEntry();
});
c$=$_P();
}
$_Z(this,arguments);
},java.util,"TreeMap",java.util.AbstractMap,[java.util.SortedMap,Cloneable,java.io.Serializable]);
$_H();
c$=$_C(function(){
this.key=null;
this.value=null;
this.left=null;
this.right=null;
this.parent=null;
this.color=true;
$_Z(this,arguments);
},java.util.TreeMap,"Entry",null,java.util.Map.Entry);
$_K(c$,
function(a,b,c){
this.key=a;
this.value=b;
this.parent=c;
},"~O,~O,java.util.TreeMap.Entry");
$_M(c$,"getKey",
function(){
return this.key;
});
$_M(c$,"getValue",
function(){
return this.value;
});
$_V(c$,"setValue",
function(a){
var b=this.value;
this.value=a;
return b;
},"~O");
$_V(c$,"equals",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return java.util.TreeMap.valEquals(this.key,b.getKey())&&java.util.TreeMap.valEquals(this.value,b.getValue());
},"~O");
$_V(c$,"hashCode",
function(){
var a=(this.key==null?0:this.key.hashCode());
var b=(this.value==null?0:this.value.hashCode());
return a^b;
});
$_V(c$,"toString",
function(){
return this.key+"="+this.value;
});
c$=$_P();
$_M(c$,"incrementSize",
($fz=function(){
this.modCount++;
this.$size++;
},$fz.isPrivate=true,$fz));
$_M(c$,"decrementSize",
($fz=function(){
this.modCount++;
this.$size--;
},$fz.isPrivate=true,$fz));
$_K(c$,
function(){
$_R(this,java.util.TreeMap,[]);
});
$_K(c$,
function(c){
$_R(this,java.util.TreeMap,[]);
this.$comparator=c;
},"java.util.Comparator");
$_K(c$,
function(m){
$_R(this,java.util.TreeMap,[]);
this.putAll(m);
},"java.util.Map");
$_K(c$,
function(m){
$_R(this,java.util.TreeMap,[]);
this.$comparator=m.comparator();
try{
this.buildFromSorted(m.size(),m.entrySet().iterator(),null,null);
}catch(e){
if($_O(e,java.io.IOException)){
}else if($_O(e,ClassNotFoundException)){
}else{
throw e;
}
}
},"java.util.SortedMap");
$_M(c$,"size",
function(){
return this.$size;
});
$_V(c$,"containsKey",
function(key){
return this.getEntry(key)!=null;
},"~O");
$_V(c$,"containsValue",
function(value){
return(this.root==null?false:(value==null?this.valueSearchNull(this.root):this.valueSearchNonNull(this.root,value)));
},"~O");
$_M(c$,"valueSearchNull",
($fz=function(n){
if(n.value==null)return true;
return(n.left!=null&&this.valueSearchNull(n.left))||(n.right!=null&&this.valueSearchNull(n.right));
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"valueSearchNonNull",
($fz=function(n,value){
if(value.equals(n.value))return true;
return(n.left!=null&&this.valueSearchNonNull(n.left,value))||(n.right!=null&&this.valueSearchNonNull(n.right,value));
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry,~O");
$_V(c$,"get",
function(key){
var p=this.getEntry(key);
return(p==null?null:p.value);
},"~O");
$_M(c$,"comparator",
function(){
return this.$comparator;
});
$_V(c$,"firstKey",
function(){
return java.util.TreeMap.key(this.firstEntry());
});
$_V(c$,"lastKey",
function(){
return java.util.TreeMap.key(this.lastEntry());
});
$_V(c$,"putAll",
function(map){
var mapSize=map.size();
if(this.$size==0&&mapSize!=0&&$_O(map,java.util.SortedMap)){
var c=(map).comparator();
if(c==this.$comparator||(c!=null&&c.equals(this.$comparator))){
++this.modCount;
try{
this.buildFromSorted(mapSize,map.entrySet().iterator(),null,null);
}catch(e){
if($_O(e,java.io.IOException)){
}else if($_O(e,ClassNotFoundException)){
}else{
throw e;
}
}
return;
}}$_U(this,java.util.TreeMap,"putAll",[map]);
},"java.util.Map");
$_M(c$,"getEntry",
($fz=function(key){
var p=this.root;
while(p!=null){
var cmp=this.compare(key,p.key);
if(cmp==0)return p;
else if(cmp<0)p=p.left;
else p=p.right;
}
return null;
},$fz.isPrivate=true,$fz),"~O");
$_M(c$,"getCeilEntry",
($fz=function(key){
var p=this.root;
if(p==null)return null;
while(true){
var cmp=this.compare(key,p.key);
if(cmp==0){
return p;
}else if(cmp<0){
if(p.left!=null)p=p.left;
else return p;
}else{
if(p.right!=null){
p=p.right;
}else{
var parent=p.parent;
var ch=p;
while(parent!=null&&ch==parent.right){
ch=parent;
parent=parent.parent;
}
return parent;
}}}
},$fz.isPrivate=true,$fz),"~O");
$_M(c$,"getPrecedingEntry",
($fz=function(key){
var p=this.root;
if(p==null)return null;
while(true){
var cmp=this.compare(key,p.key);
if(cmp>0){
if(p.right!=null)p=p.right;
else return p;
}else{
if(p.left!=null){
p=p.left;
}else{
var parent=p.parent;
var ch=p;
while(parent!=null&&ch==parent.left){
ch=parent;
parent=parent.parent;
}
return parent;
}}}
},$fz.isPrivate=true,$fz),"~O");
c$.key=$_M(c$,"key",
($fz=function(e){
if(e==null)throw new java.util.NoSuchElementException();
return e.key;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_V(c$,"put",
function(key,value){
var t=this.root;
if(t==null){
this.incrementSize();
this.root=new java.util.TreeMap.Entry(key,value,null);
return null;
}while(true){
var cmp=this.compare(key,t.key);
if(cmp==0){
return t.setValue(value);
}else if(cmp<0){
if(t.left!=null){
t=t.left;
}else{
this.incrementSize();
t.left=new java.util.TreeMap.Entry(key,value,t);
this.fixAfterInsertion(t.left);
return null;
}}else{
if(t.right!=null){
t=t.right;
}else{
this.incrementSize();
t.right=new java.util.TreeMap.Entry(key,value,t);
this.fixAfterInsertion(t.right);
return null;
}}}
},"~O,~O");
$_V(c$,"remove",
function(key){
var p=this.getEntry(key);
if(p==null)return null;
var oldValue=p.value;
this.deleteEntry(p);
return oldValue;
},"~O");
$_V(c$,"clear",
function(){
this.modCount++;
this.$size=0;
this.root=null;
});
$_M(c$,"clone",
function(){
var clone=null;
try{
clone=$_U(this,java.util.TreeMap,"clone",[]);
}catch(e){
if($_O(e,CloneNotSupportedException)){
throw new InternalError();
}else{
throw e;
}
}
clone.root=null;
clone.$size=0;
clone.modCount=0;
clone.$entrySet=null;
try{
clone.buildFromSorted(this.$size,this.entrySet().iterator(),null,null);
}catch(e){
if($_O(e,java.io.IOException)){
}else if($_O(e,ClassNotFoundException)){
}else{
throw e;
}
}
return clone;
});
$_V(c$,"keySet",
function(){
if(this.$keySet==null){
this.$keySet=(function(i$,v$){
if(!$_D("java.util.TreeMap$1")){
$_H();
c$=$_W(java.util,"TreeMap$1",java.util.AbstractSet);
$_M(c$,"iterator",
function(){
return $_N(java.util.TreeMap.KeyIterator,this,null);
});
$_M(c$,"size",
function(){
return this.b$["java.util.TreeMap"].size();
});
$_V(c$,"contains",
function(o){
return this.b$["java.util.TreeMap"].containsKey(o);
},"~O");
$_V(c$,"remove",
function(o){
var oldSize=this.b$["java.util.TreeMap"].$size;
this.b$["java.util.TreeMap"].remove(o);
return this.b$["java.util.TreeMap"].$size!=oldSize;
},"~O");
$_V(c$,"clear",
function(){
this.b$["java.util.TreeMap"].clear();
});
c$=$_P();
}
return $_N(java.util.TreeMap$1,i$,v$);
})(this,null);
}return this.$keySet;
});
$_V(c$,"values",
function(){
if(this.$values==null){
this.$values=(function(i$,v$){
if(!$_D("java.util.TreeMap$2")){
$_H();
c$=$_W(java.util,"TreeMap$2",java.util.AbstractCollection);
$_V(c$,"iterator",
function(){
return $_N(java.util.TreeMap.ValueIterator,this,null);
});
$_V(c$,"size",
function(){
return this.b$["java.util.TreeMap"].size();
});
$_V(c$,"contains",
function(o){
for(var e=this.b$["java.util.TreeMap"].firstEntry();e!=null;e=this.b$["java.util.TreeMap"].successor(e))if(java.util.TreeMap.valEquals(e.getValue(),o))return true;

return false;
},"~O");
$_V(c$,"remove",
function(o){
for(var e=this.b$["java.util.TreeMap"].firstEntry();e!=null;e=this.b$["java.util.TreeMap"].successor(e)){
if(java.util.TreeMap.valEquals(e.getValue(),o)){
this.b$["java.util.TreeMap"].deleteEntry(e);
return true;
}}
return false;
},"~O");
$_V(c$,"clear",
function(){
this.b$["java.util.TreeMap"].clear();
});
c$=$_P();
}
return $_N(java.util.TreeMap$2,i$,v$);
})(this,null);
}return this.$values;
});
$_M(c$,"entrySet",
function(){
if(this.$entrySet==null){
this.$entrySet=(function(i$,v$){
if(!$_D("java.util.TreeMap$3")){
$_H();
c$=$_W(java.util,"TreeMap$3",java.util.AbstractSet);
$_M(c$,"iterator",
function(){
return $_N(java.util.TreeMap.EntryIterator,this,null);
});
$_V(c$,"contains",
function(o){
if(!($_O(o,java.util.Map.Entry)))return false;
var entry=o;
var value=entry.getValue();
var p=this.b$["java.util.TreeMap"].getEntry(entry.getKey());
return p!=null&&java.util.TreeMap.valEquals(p.getValue(),value);
},"~O");
$_V(c$,"remove",
function(o){
if(!($_O(o,java.util.Map.Entry)))return false;
var entry=o;
var value=entry.getValue();
var p=this.b$["java.util.TreeMap"].getEntry(entry.getKey());
if(p!=null&&java.util.TreeMap.valEquals(p.getValue(),value)){
this.b$["java.util.TreeMap"].deleteEntry(p);
return true;
}return false;
},"~O");
$_M(c$,"size",
function(){
return this.b$["java.util.TreeMap"].size();
});
$_V(c$,"clear",
function(){
this.b$["java.util.TreeMap"].clear();
});
c$=$_P();
}
return $_N(java.util.TreeMap$3,i$,v$);
})(this,null);
}return this.$entrySet;
});
$_V(c$,"subMap",
function(fromKey,toKey){
return $_N(java.util.TreeMap.SubMap,this,null,fromKey,toKey);
},"~O,~O");
$_V(c$,"headMap",
function(toKey){
return $_N(java.util.TreeMap.SubMap,this,null,toKey,true);
},"~O");
$_V(c$,"tailMap",
function(fromKey){
return $_N(java.util.TreeMap.SubMap,this,null,fromKey,false);
},"~O");
$_M(c$,"compare",
($fz=function(k1,k2){
return(this.$comparator==null?(k1).compareTo(k2):this.$comparator.compare(k1,k2));
},$fz.isPrivate=true,$fz),"~O,~O");
c$.valEquals=$_M(c$,"valEquals",
($fz=function(o1,o2){
return(o1==null?o2==null:o1.equals(o2));
},$fz.isPrivate=true,$fz),"~O,~O");
$_M(c$,"firstEntry",
($fz=function(){
var p=this.root;
if(p!=null)while(p.left!=null)p=p.left;

return p;
},$fz.isPrivate=true,$fz));
$_M(c$,"lastEntry",
($fz=function(){
var p=this.root;
if(p!=null)while(p.right!=null)p=p.right;

return p;
},$fz.isPrivate=true,$fz));
$_M(c$,"successor",
($fz=function(t){
if(t==null)return null;
else if(t.right!=null){
var p=t.right;
while(p.left!=null)p=p.left;

return p;
}else{
var p=t.parent;
var ch=t;
while(p!=null&&ch==p.right){
ch=p;
p=p.parent;
}
return p;
}},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
c$.colorOf=$_M(c$,"colorOf",
($fz=function(p){
return(p==null?true:p.color);
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
c$.parentOf=$_M(c$,"parentOf",
($fz=function(p){
return(p==null?null:p.parent);
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
c$.setColor=$_M(c$,"setColor",
($fz=function(p,c){
if(p!=null)p.color=c;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry,~B");
c$.leftOf=$_M(c$,"leftOf",
($fz=function(p){
return(p==null)?null:p.left;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
c$.rightOf=$_M(c$,"rightOf",
($fz=function(p){
return(p==null)?null:p.right;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"rotateLeft",
($fz=function(p){
var r=p.right;
p.right=r.left;
if(r.left!=null)r.left.parent=p;
r.parent=p.parent;
if(p.parent==null)this.root=r;
else if(p.parent.left==p)p.parent.left=r;
else p.parent.right=r;
r.left=p;
p.parent=r;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"rotateRight",
($fz=function(p){
var l=p.left;
p.left=l.right;
if(l.right!=null)l.right.parent=p;
l.parent=p.parent;
if(p.parent==null)this.root=l;
else if(p.parent.right==p)p.parent.right=l;
else p.parent.left=l;
l.right=p;
p.parent=l;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"fixAfterInsertion",
($fz=function(x){
x.color=false;
while(x!=null&&x!=this.root&&x.parent.color==false){
if(java.util.TreeMap.parentOf(x)==java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)))){
var y=java.util.TreeMap.rightOf(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)));
if(java.util.TreeMap.colorOf(y)==false){
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(y,true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)),false);
x=java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x));
}else{
if(x==java.util.TreeMap.rightOf(java.util.TreeMap.parentOf(x))){
x=java.util.TreeMap.parentOf(x);
this.rotateLeft(x);
}java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)),false);
if(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x))!=null)this.rotateRight(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)));
}}else{
var y=java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)));
if(java.util.TreeMap.colorOf(y)==false){
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(y,true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)),false);
x=java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x));
}else{
if(x==java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(x))){
x=java.util.TreeMap.parentOf(x);
this.rotateRight(x);
}java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)),false);
if(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x))!=null)this.rotateLeft(java.util.TreeMap.parentOf(java.util.TreeMap.parentOf(x)));
}}}
this.root.color=true;
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"deleteEntry",
($fz=function(p){
this.decrementSize();
if(p.left!=null&&p.right!=null){
var s=this.successor(p);
p.key=s.key;
p.value=s.value;
p=s;
}var replacement=(p.left!=null?p.left:p.right);
if(replacement!=null){
replacement.parent=p.parent;
if(p.parent==null)this.root=replacement;
else if(p==p.parent.left)p.parent.left=replacement;
else p.parent.right=replacement;
p.left=p.right=p.parent=null;
if(p.color==true)this.fixAfterDeletion(replacement);
}else if(p.parent==null){
this.root=null;
}else{
if(p.color==true)this.fixAfterDeletion(p);
if(p.parent!=null){
if(p==p.parent.left)p.parent.left=null;
else if(p==p.parent.right)p.parent.right=null;
p.parent=null;
}}},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"fixAfterDeletion",
($fz=function(x){
while(x!=this.root&&java.util.TreeMap.colorOf(x)==true){
if(x==java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(x))){
var sib=java.util.TreeMap.rightOf(java.util.TreeMap.parentOf(x));
if(java.util.TreeMap.colorOf(sib)==false){
java.util.TreeMap.setColor(sib,true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),false);
this.rotateLeft(java.util.TreeMap.parentOf(x));
sib=java.util.TreeMap.rightOf(java.util.TreeMap.parentOf(x));
}if(java.util.TreeMap.colorOf(java.util.TreeMap.leftOf(sib))==true&&java.util.TreeMap.colorOf(java.util.TreeMap.rightOf(sib))==true){
java.util.TreeMap.setColor(sib,false);
x=java.util.TreeMap.parentOf(x);
}else{
if(java.util.TreeMap.colorOf(java.util.TreeMap.rightOf(sib))==true){
java.util.TreeMap.setColor(java.util.TreeMap.leftOf(sib),true);
java.util.TreeMap.setColor(sib,false);
this.rotateRight(sib);
sib=java.util.TreeMap.rightOf(java.util.TreeMap.parentOf(x));
}java.util.TreeMap.setColor(sib,java.util.TreeMap.colorOf(java.util.TreeMap.parentOf(x)));
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(java.util.TreeMap.rightOf(sib),true);
this.rotateLeft(java.util.TreeMap.parentOf(x));
x=this.root;
}}else{
var sib=java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(x));
if(java.util.TreeMap.colorOf(sib)==false){
java.util.TreeMap.setColor(sib,true);
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),false);
this.rotateRight(java.util.TreeMap.parentOf(x));
sib=java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(x));
}if(java.util.TreeMap.colorOf(java.util.TreeMap.rightOf(sib))==true&&java.util.TreeMap.colorOf(java.util.TreeMap.leftOf(sib))==true){
java.util.TreeMap.setColor(sib,false);
x=java.util.TreeMap.parentOf(x);
}else{
if(java.util.TreeMap.colorOf(java.util.TreeMap.leftOf(sib))==true){
java.util.TreeMap.setColor(java.util.TreeMap.rightOf(sib),true);
java.util.TreeMap.setColor(sib,false);
this.rotateLeft(sib);
sib=java.util.TreeMap.leftOf(java.util.TreeMap.parentOf(x));
}java.util.TreeMap.setColor(sib,java.util.TreeMap.colorOf(java.util.TreeMap.parentOf(x)));
java.util.TreeMap.setColor(java.util.TreeMap.parentOf(x),true);
java.util.TreeMap.setColor(java.util.TreeMap.leftOf(sib),true);
this.rotateRight(java.util.TreeMap.parentOf(x));
x=this.root;
}}}
java.util.TreeMap.setColor(x,true);
},$fz.isPrivate=true,$fz),"java.util.TreeMap.Entry");
$_M(c$,"readTreeSet",
function(size,s,defaultVal){
this.buildFromSorted(size,null,s,defaultVal);
},"~N,java.io.ObjectInputStream,~O");
$_M(c$,"addAllForTreeSet",
function(set,defaultVal){
try{
this.buildFromSorted(set.size(),set.iterator(),null,defaultVal);
}catch(e){
if($_O(e,java.io.IOException)){
}else if($_O(e,ClassNotFoundException)){
}else{
throw e;
}
}
},"java.util.SortedSet,~O");
$_M(c$,"buildFromSorted",
($fz=function(size,it,str,defaultVal){
this.$size=size;
this.root=java.util.TreeMap.buildFromSorted(0,0,size-1,java.util.TreeMap.computeRedLevel(size),it,str,defaultVal);
},$fz.isPrivate=true,$fz),"~N,java.util.Iterator,java.io.ObjectInputStream,~O");
c$.buildFromSorted=$_M(c$,"buildFromSorted",
($fz=function(level,lo,hi,redLevel,it,str,defaultVal){
if(hi<lo)return null;
var mid=Math.floor((lo+hi)/2);
var left=null;
if(lo<mid)left=java.util.TreeMap.buildFromSorted(level+1,lo,mid-1,redLevel,it,str,defaultVal);
var key;
var value;
if(it!=null){
if(defaultVal==null){
var entry=it.next();
key=entry.getKey();
value=entry.getValue();
}else{
key=it.next();
value=defaultVal;
}}else{
key=str.readObject();
value=(defaultVal!=null?defaultVal:str.readObject());
}var middle=new java.util.TreeMap.Entry(key,value,null);
if(level==redLevel)middle.color=false;
if(left!=null){
middle.left=left;
left.parent=middle;
}if(mid<hi){
var right=java.util.TreeMap.buildFromSorted(level+1,mid+1,hi,redLevel,it,str,defaultVal);
middle.right=right;
right.parent=middle;
}return middle;
},$fz.isPrivate=true,$fz),"~N,~N,~N,~N,java.util.Iterator,java.io.ObjectInputStream,~O");
c$.computeRedLevel=$_M(c$,"computeRedLevel",
($fz=function(sz){
var level=0;
for(var m=sz-1;m>=0;m=Math.floor(m/2)-1)level++;

return level;
},$fz.isPrivate=true,$fz),"~N");
$_S(c$,
"RED",false,
"BLACK",true);
});
