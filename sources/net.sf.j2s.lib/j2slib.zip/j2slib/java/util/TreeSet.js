﻿$_L(["java.util.AbstractSet","$.SortedSet"],"java.util.TreeSet",["java.io.IOException","java.lang.InternalError","java.util.TreeMap"],function(){
c$=$_C(function(){
this.m=null;
this.keySet=null;
$_Z(this,arguments);
},java.util,"TreeSet",java.util.AbstractSet,[java.util.SortedSet,Cloneable,java.io.Serializable]);
$_K(c$,
($fz=function(m){
$_R(this,java.util.TreeSet,[]);
this.m=m;
this.keySet=m.keySet();
},$fz.isPrivate=true,$fz),"java.util.SortedMap");
$_K(c$,
function(){
this.construct(new java.util.TreeMap());
});
$_K(c$,
function(c){
this.construct(new java.util.TreeMap(c));
},"java.util.Comparator");
$_K(c$,
function(c){
this.construct();
this.addAll(c);
},"java.util.Collection");
$_K(c$,
function(s){
this.construct(s.comparator());
this.addAll(s);
},"java.util.SortedSet");
$_M(c$,"iterator",
function(){
return this.keySet.iterator();
});
$_V(c$,"size",
function(){
return this.m.size();
});
$_V(c$,"isEmpty",
function(){
return this.m.isEmpty();
});
$_V(c$,"contains",
function(o){
return this.m.containsKey(o);
},"~O");
$_V(c$,"add",
function(o){
return this.m.put(o,java.util.TreeSet.PRESENT)==null;
},"~O");
$_V(c$,"remove",
function(o){
return this.m.remove(o)==java.util.TreeSet.PRESENT;
},"~O");
$_V(c$,"clear",
function(){
this.m.clear();
});
$_V(c$,"addAll",
function(c){
if(this.m.size()==0&&c.size()>0&&$_O(c,java.util.SortedSet)&&$_O(this.m,java.util.TreeMap)){
var set=c;
var map=this.m;
var cc=set.comparator();
var mc=map.comparator();
if(cc==mc||(cc!=null&&cc.equals(mc))){
map.addAllForTreeSet(set,java.util.TreeSet.PRESENT);
return true;
}}return $_U(this,java.util.TreeSet,"addAll",[c]);
},"java.util.Collection");
$_V(c$,"subSet",
function(fromElement,toElement){
return new java.util.TreeSet(this.m.subMap(fromElement,toElement));
},"~O,~O");
$_V(c$,"headSet",
function(toElement){
return new java.util.TreeSet(this.m.headMap(toElement));
},"~O");
$_V(c$,"tailSet",
function(fromElement){
return new java.util.TreeSet(this.m.tailMap(fromElement));
},"~O");
$_M(c$,"comparator",
function(){
return this.m.comparator();
});
$_V(c$,"first",
function(){
return this.m.firstKey();
});
$_V(c$,"last",
function(){
return this.m.lastKey();
});
$_M(c$,"clone",
function(){
var clone=null;
try{
clone=$_U(this,java.util.TreeSet,"clone",[]);
}catch(e){
if($_O(e,CloneNotSupportedException)){
throw new InternalError();
}else{
throw e;
}
}
clone.m=new java.util.TreeMap(this.m);
clone.keySet=clone.m.keySet();
return clone;
});
c$.PRESENT=c$.prototype.PRESENT=new Object();
});
