﻿$_J("java.util.regex");
$_L(null,"java.util.regex.Pattern",["java.lang.StringBuilder","java.util.regex.Matcher"],function(){
c$=$_C(function(){
this.$pattern=null;
this.$flags=0;
$_Z(this,arguments);
},java.util.regex,"Pattern",null,java.io.Serializable);
$_K(c$,
($fz=function(p,f){
this.$pattern=p;
this.$flags=f;
},$fz.isPrivate=true,$fz),"~S,~N");
c$.compile=$_M(c$,"compile",
function(regex){
return new java.util.regex.Pattern(regex,0);
},"~S");
c$.compile=$_M(c$,"compile",
function(regex,flags){
return new java.util.regex.Pattern(regex,flags);
},"~S,~N");
$_M(c$,"pattern",
function(){
return this.$pattern;
});
$_V(c$,"toString",
function(){
return this.$pattern;
});
$_M(c$,"matcher",
function(input){
var m=new java.util.regex.Matcher(this,input);
return m;
},"CharSequence");
$_M(c$,"flags",
function(){
return this.$flags;
});
c$.matches=$_M(c$,"matches",
function(regex,input){
var p=java.util.regex.Pattern.compile(regex);
var m=p.matcher(input);
return m.matches();
},"~S,CharSequence");
$_M(c$,"split",
function(input,limit){
var index=0;
var matchLimited=limit>0;
var matches=new Array(0);
var m=this.matcher(input);
while(m.find()){
if(!matchLimited||matches.length<limit-1){
var match=input.subSequence(index,m.start()).toString();
matches[matches.length]=match;
index=m.end();
}else if(matches.length==limit-1){
var match=input.subSequence(index,input.length()).toString();
matches[matches.length]=match;
index=m.end();
}}
if(index==0)return[input.toString()];
if(!matchLimited||matches.length<limit)matches[matches.length]=input.subSequence(index,input.length()).toString();
var resultSize=matches.length;
if(limit==0)while(resultSize>0&&matches[resultSize-1].equals(""))resultSize--;

var result=new Array(resultSize);
for(var i=0;i<resultSize;i++){
result[i]=matches[i];
}
return result;
},"CharSequence,~N");
$_M(c$,"split",
function(input){
return this.split(input,0);
},"CharSequence");
c$.quote=$_M(c$,"quote",
function(s){
var slashEIndex=s.indexOf("\\E");
if(slashEIndex==-1)return"\\Q"+s+"\\E";
var sb=new StringBuilder(s.length*2);
sb.append("\\Q");
slashEIndex=0;
var current=0;
while((slashEIndex=s.indexOf("\\E",current))!=-1){
sb.append(s.substring(current,slashEIndex));
current=slashEIndex+2;
sb.append("\\E\\\\E\\Q");
}
sb.append(s.substring(current,s.length));
sb.append("\\E");
return sb.toString();
},"~S");
$_S(c$,
"UNIX_LINES",0x01,
"CASE_INSENSITIVE",0x02,
"COMMENTS",0x04,
"MULTILINE",0x08,
"LITERAL",0x10,
"DOTALL",0x20,
"UNICODE_CASE",0x40,
"CANON_EQ",0x80);
});
