﻿$_J("java.util.regex");
$_L(["java.lang.IllegalArgumentException"],"java.util.regex.PatternSyntaxException",["java.lang.StringBuffer"],function(){
c$=$_C(function(){
this.desc=null;
this.pattern=null;
this.index=0;
$_Z(this,arguments);
},java.util.regex,"PatternSyntaxException",IllegalArgumentException);
$_K(c$,
function(desc,regex,index){
$_R(this,java.util.regex.PatternSyntaxException,[]);
this.desc=desc;
this.pattern=regex;
this.index=index;
},"~S,~S,~N");
$_M(c$,"getIndex",
function(){
return this.index;
});
$_M(c$,"getDescription",
function(){
return this.desc;
});
$_M(c$,"getPattern",
function(){
return this.pattern;
});
$_V(c$,"getMessage",
function(){
var nl=System.getProperty("line.separator");
var sb=new StringBuffer();
sb.append(this.desc);
if(this.index>=0){
sb.append(" near index ");
sb.append(this.index);
}sb.append(nl);
sb.append(this.pattern);
if(this.index>=0){
sb.append(nl);
for(var i=0;i<this.index;i++)sb.append(' ');

sb.append('^');
}return sb.toString();
});
});
