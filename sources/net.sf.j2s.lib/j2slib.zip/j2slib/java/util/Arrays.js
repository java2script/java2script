﻿c$=$_T(java.util,"Arrays");
c$.equals=$_M(c$,"equals",
function(a,a2){
if(a==a2)return true;
if(a==null||a2==null)return false;
var length=a.length;
if(a2.length!=length)return false;
for(var i=0;i<length;i++){
var o1=a[i];
var o2=a2[i];
if(!(o1==null?o2==null:o1.equals(o2)))return false;
}
return true;
},"~A,~A");
