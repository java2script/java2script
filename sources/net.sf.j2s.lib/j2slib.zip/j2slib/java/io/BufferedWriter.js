﻿$_L(["java.io.Writer"],"java.io.BufferedWriter",["java.io.IOException","java.lang.IllegalArgumentException","$.IndexOutOfBoundsException"],function(){
c$=$_C(function(){
this.out=null;
this.cb=null;
this.nChars=0;
this.nextChar=0;
this.lineSeparator=null;
$_Z(this,arguments);
},java.io,"BufferedWriter",java.io.Writer);
$_K(c$,
function(out){
this.construct(out,java.io.BufferedWriter.defaultCharBufferSize);
},"java.io.Writer");
$_K(c$,
function(out,sz){
$_R(this,java.io.BufferedWriter,[out]);
if(sz<=0)throw new IllegalArgumentException("Buffer size <= 0");
this.out=out;
this.cb=$_A(sz,'\0');
this.nChars=sz;
this.nextChar=0;
{
this.lineSeparator="\r\n";
}},"java.io.Writer,~N");
$_M(c$,"ensureOpen",
($fz=function(){
if(this.out==null)throw new java.io.IOException("Stream closed");
},$fz.isPrivate=true,$fz));
$_M(c$,"flushBuffer",
function(){
{
this.ensureOpen();
if(this.nextChar==0)return;
this.out.write(this.cb,0,this.nextChar);
this.nextChar=0;
}});
$_M(c$,"write",
function(c){
{
this.ensureOpen();
if(this.nextChar>=this.nChars)this.flushBuffer();
this.cb[this.nextChar++]=String.fromCharCode(c);
}},"~N");
$_M(c$,"min",
($fz=function(a,b){
if(a<b)return a;
return b;
},$fz.isPrivate=true,$fz),"~N,~N");
$_M(c$,"write",
function(cbuf,off,len){
{
this.ensureOpen();
if((off<0)||(off>cbuf.length)||(len<0)||((off+len)>cbuf.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}else if(len==0){
return;
}if(len>=this.nChars){
this.flushBuffer();
this.out.write(cbuf,off,len);
return;
}var b=off;
var t=off+len;
while(b<t){
var d=this.min(this.nChars-this.nextChar,t-b);
System.arraycopy(cbuf,b,this.cb,this.nextChar,d);
b+=d;
this.nextChar+=d;
if(this.nextChar>=this.nChars)this.flushBuffer();
}
}},"~A,~N,~N");
$_M(c$,"write",
function(s,off,len){
{
this.ensureOpen();
var b=off;
var t=off+len;
while(b<t){
var d=this.min(this.nChars-this.nextChar,t-b);
s.getChars(b,b+d,this.cb,this.nextChar);
b+=d;
this.nextChar+=d;
if(this.nextChar>=this.nChars)this.flushBuffer();
}
}},"~S,~N,~N");
$_M(c$,"newLine",
function(){
this.write(this.lineSeparator);
});
$_M(c$,"flush",
function(){
{
this.flushBuffer();
this.out.flush();
}});
$_M(c$,"close",
function(){
{
if(this.out==null)return;
this.flushBuffer();
this.out.close();
this.out=null;
this.cb=null;
}});
$_S(c$,
"defaultCharBufferSize",8192);
});
