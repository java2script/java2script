﻿$_L(["java.io.Writer"],"java.io.StringWriter",["java.lang.IllegalArgumentException","$.IndexOutOfBoundsException","$.StringBuffer"],function(){
c$=$_C(function(){
this.buf=null;
$_Z(this,arguments);
},java.io,"StringWriter",java.io.Writer);
$_K(c$,
function(){
$_R(this,java.io.StringWriter,[]);
this.buf=new StringBuffer();
this.lock=this.buf;
});
$_K(c$,
function(initialSize){
$_R(this,java.io.StringWriter,[]);
if(initialSize<0){
throw new IllegalArgumentException("Negative buffer size");
}this.buf=new StringBuffer(initialSize);
this.lock=this.buf;
},"~N");
$_M(c$,"write",
function(c){
this.buf.append(String.fromCharCode(c));
},"~N");
$_M(c$,"write",
function(cbuf,off,len){
if((off<0)||(off>cbuf.length)||(len<0)||((off+len)>cbuf.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}else if(len==0){
return;
}this.buf.append(cbuf,off,len);
},"~A,~N,~N");
$_M(c$,"write",
function(str){
this.buf.append(str);
},"~S");
$_M(c$,"write",
function(str,off,len){
this.buf.append(str.substring(off,off+len));
},"~S,~N,~N");
$_V(c$,"toString",
function(){
return this.buf.toString();
});
$_M(c$,"getBuffer",
function(){
return this.buf;
});
$_V(c$,"flush",
function(){
});
$_V(c$,"close",
function(){
});
});
