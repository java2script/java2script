﻿$_L(null,"java.io.Bits",["java.lang.Double","$.Float"],function(){
c$=$_T(java.io,"Bits");
c$.getBoolean=$_M(c$,"getBoolean",
function(b,off){
return b[off]!=0;
},"~A,~N");
c$.getChar=$_M(c$,"getChar",
function(b,off){
return String.fromCharCode((((b[off+1]&0xFF)<<0)+((b[off+0]&0xFF)<<8)));
},"~A,~N");
c$.getShort=$_M(c$,"getShort",
function(b,off){
return(((b[off+1]&0xFF)<<0)+((b[off+0]&0xFF)<<8));
},"~A,~N");
c$.getInt=$_M(c$,"getInt",
function(b,off){
return((b[off+3]&0xFF)<<0)+((b[off+2]&0xFF)<<8)+((b[off+1]&0xFF)<<16)+((b[off+0]&0xFF)<<24);
},"~A,~N");
c$.getFloat=$_M(c$,"getFloat",
function(b,off){
var i=((b[off+3]&0xFF)<<0)+((b[off+2]&0xFF)<<8)+((b[off+1]&0xFF)<<16)+((b[off+0]&0xFF)<<24);
return Float.intBitsToFloat(i);
},"~A,~N");
c$.getLong=$_M(c$,"getLong",
function(b,off){
return((b[off+7]&0xFF)<<0)+((b[off+6]&0xFF)<<8)+((b[off+5]&0xFF)<<16)+((b[off+4]&0xFF)<<24)+((b[off+3]&0xFF)<<32)+((b[off+2]&0xFF)<<40)+((b[off+1]&0xFF)<<48)+((b[off+0]&0xFF)<<56);
},"~A,~N");
c$.getDouble=$_M(c$,"getDouble",
function(b,off){
var j=((b[off+7]&0xFF)<<0)+((b[off+6]&0xFF)<<8)+((b[off+5]&0xFF)<<16)+((b[off+4]&0xFF)<<24)+((b[off+3]&0xFF)<<32)+((b[off+2]&0xFF)<<40)+((b[off+1]&0xFF)<<48)+((b[off+0]&0xFF)<<56);
return Double.longBitsToDouble(j);
},"~A,~N");
c$.putBoolean=$_M(c$,"putBoolean",
function(b,off,val){
b[off]=(val?1:0);
},"~A,~N,~B");
c$.putChar=$_M(c$,"putChar",
function(b,off,val){
b[off+1]=((val).charCodeAt(0)>>>0);
b[off+0]=((val).charCodeAt(0)>>>8);
},"~A,~N,~N");
c$.putShort=$_M(c$,"putShort",
function(b,off,val){
b[off+1]=(val>>>0);
b[off+0]=(val>>>8);
},"~A,~N,~N");
c$.putInt=$_M(c$,"putInt",
function(b,off,val){
b[off+3]=(val>>>0);
b[off+2]=(val>>>8);
b[off+1]=(val>>>16);
b[off+0]=(val>>>24);
},"~A,~N,~N");
c$.putFloat=$_M(c$,"putFloat",
function(b,off,val){
var i=Float.floatToIntBits(val);
b[off+3]=(i>>>0);
b[off+2]=(i>>>8);
b[off+1]=(i>>>16);
b[off+0]=(i>>>24);
},"~A,~N,~N");
c$.putLong=$_M(c$,"putLong",
function(b,off,val){
b[off+7]=(val>>>0);
b[off+6]=(val>>>8);
b[off+5]=(val>>>16);
b[off+4]=(val>>>24);
b[off+3]=(val>>>32);
b[off+2]=(val>>>40);
b[off+1]=(val>>>48);
b[off+0]=(val>>>56);
},"~A,~N,~N");
c$.putDouble=$_M(c$,"putDouble",
function(b,off,val){
var j=Double.doubleToLongBits(val);
b[off+7]=(j>>>0);
b[off+6]=(j>>>8);
b[off+5]=(j>>>16);
b[off+4]=(j>>>24);
b[off+3]=(j>>>32);
b[off+2]=(j>>>40);
b[off+1]=(j>>>48);
b[off+0]=(j>>>56);
},"~A,~N,~N");
});
