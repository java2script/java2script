$_L(["java.lang.IndexOutOfBoundsException"],"java.lang.StringIndexOutOfBoundsException",null,function(){
c$=$_T(java.lang,"StringIndexOutOfBoundsException",IndexOutOfBoundsException);
});
