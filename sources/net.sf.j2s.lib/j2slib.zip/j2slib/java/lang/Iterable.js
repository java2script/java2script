$_L(null,"java.lang.Iterable",["java.util.Iterator"],function(){
$_I(java.lang,"Iterable");
});
