﻿c$=$_I(reflect,"Member");
$_S(c$,
"PUBLIC",0,
"DECLARED",1);
