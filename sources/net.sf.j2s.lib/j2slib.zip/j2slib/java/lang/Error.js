/* http://j2s.sf.net/ */$_L(["java.lang.Throwable"],"java.lang.Error",null,function(){
c$=$_T(java.lang,"Error",Throwable);
});
