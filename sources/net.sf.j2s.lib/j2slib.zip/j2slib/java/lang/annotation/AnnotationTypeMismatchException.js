﻿$_L(["java.lang.RuntimeException"],"java.lang.annotation.AnnotationTypeMismatchException",["org.apache.harmony.luni.util.Msg"],function(){
c$=$_C(function(){
this.$element=null;
this.$foundType=null;
$_Z(this,arguments);
},java.lang.annotation,"AnnotationTypeMismatchException",RuntimeException);
$_K(c$,
function(element,foundType){
$_R(this,java.lang.annotation.AnnotationTypeMismatchException,[org.apache.harmony.luni.util.Msg.getString("annotation.1",element,foundType)]);
this.$element=element;
this.$foundType=foundType;
},"java.lang.reflect.Method,~S");
$_M(c$,"element",
function(){
return this.$element;
});
$_M(c$,"foundType",
function(){
return this.$foundType;
});
});
