$_L(["java.lang.Error"],"java.lang.ThreadDeath",null,function(){
c$=$_T(java.lang,"ThreadDeath",Error);
$_K(c$,
function(){
$_R(this,ThreadDeath,[]);
});
});
