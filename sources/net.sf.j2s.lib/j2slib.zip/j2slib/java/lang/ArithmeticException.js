$_L(["java.lang.RuntimeException"],"java.lang.ArithmeticException",null,function(){
c$=$_T(java.lang,"ArithmeticException",RuntimeException);
});
