$_L(["java.lang.LinkageError"],"java.lang.NoClassDefFoundError",null,function(){
c$=$_T(java.lang,"NoClassDefFoundError",LinkageError);
});
