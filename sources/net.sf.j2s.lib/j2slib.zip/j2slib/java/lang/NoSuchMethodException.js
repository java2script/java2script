﻿$_L(["java.lang.Exception"],"java.lang.NoSuchMethodException",null,function(){
c$=$_T(java.lang,"NoSuchMethodException",Exception);
});
