Clazz.declarePackage ("net.sf.j2s.widget");
c$ = Clazz.declareType (net.sf.j2s.widget, "Widget");
Clazz.defineMethod (c$, "setElementClass", 
function (el) {
var name = this.getClass ().getSimpleName ();
var prevUppercase = false;
var size = name.length;
var s = "";
for (var i = 0; i < size - 1; i++) {
var c = name.charAt (i);
var n = name.charAt (i + 1);
if (i > 0 && c >= 'A' && c <= 'Z') {
if (!prevUppercase) {
s += "-";
} else {
if (n < 'A' || n > 'Z') {
s += "-";
}}}s += c;
}
s += name.charAt (size - 1);
(el).className = s.toLowerCase ();
}, "~O");
c$.toHTML = Clazz.defineMethod (c$, "toHTML", 
($fz = function (raw) {
return raw.replaceAll ("&", "&amp;").replaceAll (">", "&gt;").replaceAll ("<", "&lt;");
}, $fz.isPrivate = true, $fz), "~S");
c$.getValue = Clazz.defineMethod (c$, "getValue", 
($fz = function (varName, oThis, oLocal, updateAssignment) {
var c = varName.charAt (1);
var value = null;
var needHTMLizing = true;
if (c == '.') {
value = oThis[varName.substring(2)];
} else if (c == '~') {
value = oLocal[varName.substring(2)];
} else if (c == '/') {
var cThis = null;
if (typeof oThis == "function") {
cThis = oThis;
} else {
cThis = oThis.getClass();
}
var s = cThis.getResourceAsStream(".");
var path = s.url;
if (path.endsWith("/.")) {
path = path.substring(0, path.length - 2);
}
value = path;
} else if (updateAssignment && (c == ':' || c == '#')) {
value = "<!--" + varName + "-->";
needHTMLizing = false;
}{
var t = typeof value;
if (t == "number" || t == "boolean") {
value = "" + value;
t = "string";
}
}if (Clazz.instanceOf (value, String)) {
return !needHTMLizing || value == null ? value : net.sf.j2s.widget.Widget.toHTML (value);
} else if (Clazz.instanceOf (value, net.sf.j2s.widget.Widget)) {
return "<!--" + varName + "-->";
} else {
return null;
}}, $fz.isPrivate = true, $fz), "~S,~O,~O,~B");
c$.parseXTag = Clazz.defineMethod (c$, "parseXTag", 
function (oThis, oLocal, sources) {
var buffer =  new Array (0);
var key = "{$";
var lastIndex = 0;
var index = sources.indexOf (key, 0);
while (index != -1) {
var idx = sources.indexOf ("}", index + key.length);
if (idx == -1) {
break;
}var $var = sources.substring (index + key.length - 1, idx);
if ($var.indexOf (' ') == -1) {
var value = net.sf.j2s.widget.Widget.getValue ($var, oThis, oLocal, true);
if (value != null) {
buffer[buffer.length] = sources.substring (lastIndex, index);
buffer[buffer.length] = value;
lastIndex = idx + 1;
}}index = sources.indexOf (key, idx + 1);
}
if (lastIndex == 0) {
} else {
buffer[buffer.length] = sources.substring (lastIndex);
{
sources = buffer.join("");
}buffer =  new Array (0);
lastIndex = 0;
}key = "<!--";
index = sources.indexOf (key, 0);
while (index != -1) {
var idx = sources.indexOf ("-->", index + key.length);
if (idx == -1) {
break;
}var comment = sources.substring (index + key.length, idx).trim ();
if (comment.startsWith ("$") && comment.indexOf (' ') == -1) {
var value = net.sf.j2s.widget.Widget.getValue (comment, oThis, oLocal, false);
if (value != null) {
buffer[buffer.length] = sources.substring (lastIndex, index);
buffer[buffer.length] = value;
lastIndex = idx + 3;
}}index = sources.indexOf (key, idx + 3);
}
if (lastIndex == 0) {
} else {
buffer[buffer.length] = sources.substring (lastIndex);
{
sources = buffer.join("");
}buffer =  new Array (0);
lastIndex = 0;
}key = "id";
index = sources.indexOf (key, 0);
while (index > 0) {
var last = sources.charAt (index - 1);
if (!(last == ' ' || last == '\t' || last == '\n' || last == '\r')) {
index = sources.indexOf (key, index + key.length);
continue;
}var idxEqual = index + key.length;
do {
var c = sources.charAt (idxEqual);
if (c == '=') {
break;
} else if (c == ' ' || c == '\t') {
idxEqual++;
if (idxEqual == sources.length - 1) {
idxEqual = -1;
break;
}} else {
idxEqual = -1;
break;
}} while (true);
if (idxEqual == -1 || idxEqual == sources.length - 1) {
break;
}var quote = String.fromCharCode (0);
var idxQuoteStart = idxEqual + 1;
do {
var c = sources.charAt (idxQuoteStart);
if (c == '\'' || c == '\"') {
quote = c;
break;
} else if (c == ' ' || c == '\t') {
idxQuoteStart++;
if (idxQuoteStart == sources.length - 1) {
idxQuoteStart = -1;
break;
}} else {
idxQuoteStart = -1;
break;
}} while (true);
if (idxQuoteStart == -1 || idxQuoteStart == sources.length - 1) {
break;
}var idxQuoteEnd = sources.indexOf (quote, idxQuoteStart + 1);
if (idxQuoteEnd == -1 || idxQuoteEnd == sources.length - 1) {
break;
}var idxTagStart = sources.lastIndexOf ('<', index);
if (idxTagStart == -1 || idxTagStart < lastIndex) {
break;
}var idStr = sources.substring (idxQuoteStart + 1, idxQuoteEnd).trim ();
if (idStr.startsWith ("$") && idStr.indexOf (' ') == -1 && idStr.length >= 2 && (idStr.charAt (1) == ':' || idStr.charAt (1) == '#')) {
buffer[buffer.length] = sources.substring (lastIndex, idxTagStart);
buffer[buffer.length] = "<!--" + idStr + "-->";
var html = sources.substring (idxTagStart, index).replaceAll ("\\s+$", "");
buffer[buffer.length] = html;
if (sources.length > idxQuoteEnd) {
var nextChar = sources.charAt (idxQuoteEnd + 1);
if (!(nextChar == ' ' || nextChar == '>' || nextChar == '\t' || nextChar == '\n' || nextChar == '\r')) {
buffer[buffer.length] = " ";
}}lastIndex = idxQuoteEnd + 1;
}index = sources.indexOf (key, idxQuoteEnd + 1);
}
if (lastIndex == 0) {
} else {
buffer[buffer.length] = sources.substring (lastIndex);
{
sources = buffer.join("");
}buffer =  new Array (0);
lastIndex = 0;
}return sources;
}, "~O,~O,~S");
c$.parseHTML = Clazz.defineMethod (c$, "parseHTML", 
function (el, oThis, oLocal, html) {
{
if (arguments.length == 0) {
return null;
}
var xhtml = arguments[arguments.length - 1];
var xLocal = null;
var xThis = null;
var xEl = null;
for (var i = arguments.length - 2; i >= 0; i--) {
var arg = arguments[i];
var pt = arg.constructor != null ? arg.constructor.prototype : null;
if (pt == null) continue;
var clazzKey = "__CLASS_NAME__";
var elementKey = "nodeName";
if (xThis == null && typeof arg == "function" && arg[clazzKey] != null) {
xThis = arg;
} else if (xLocal == null && xThis == null && pt[clazzKey] == null && arg[elementKey] == null) {
xLocal = arg;
} else if (xThis == null && pt[clazzKey] != null && arg[elementKey] == null) {
xThis = arg;
} else if (xThis == null && pt[clazzKey] != null && arg[elementKey] == null) {
xThis = arg;
} else if (xEl == null && pt[clazzKey] == null && arg[elementKey] != null) {
xEl = arg;
// } else {
}
}
html = xhtml;
oLocal = xLocal;
oThis = xThis;
el = xEl;
}var newHTML = net.sf.j2s.widget.Widget.parseXTag (oThis, oLocal, html);
var container = d$.createElement ("DIV");
d$.body.appendChild (container);
container.innerHTML = newHTML;
var result = net.sf.j2s.widget.Widget.parseHTMLElments (container, oThis, oLocal);
if (el != null) {
while (container.childNodes.length > 0) {
(el).appendChild (container.childNodes[0]);
}
container.parentNode.removeChild (container);
container = null;
}return result;
}, "~O,~O,~O,~S");
c$.parseHTMLElments = Clazz.defineMethod (c$, "parseHTMLElments", 
($fz = function (el, oThis, oLocal) {
var container = el;
if (container.childNodes != null && container.childNodes.length > 0) {
var markedEls =  new Array (0);
net.sf.j2s.widget.Widget.traverseDOM (container, oThis, oLocal, markedEls);
if (markedEls.length != 0) {
if (markedEls.length == 1) {
return markedEls[0];
} else {
markedEls.reverse();
return markedEls;
}} else {
if (container.childNodes.length == 1) {
return container.childNodes[0];
} else {
for (var i = container.childNodes.length - 1; i >= 0; i--) {
var node = container.childNodes[i];
var nodeName = node.nodeName;
if (nodeName != null && nodeName.length > 0 && !nodeName.startsWith ("#")) {
markedEls[markedEls.length] = node;
}}
if (markedEls.length == 1) {
return markedEls[0];
}return markedEls;
}}} else {
return null;
}}, $fz.isPrivate = true, $fz), "~O,~O,~O");
c$.traverseDOM = Clazz.defineMethod (c$, "traverseDOM", 
($fz = function (containerEl, oThis, oLocal, markedEls) {
var container = containerEl;
var next = null;
var debugging = false;
{
debugging = window["j2s.script.debugging"];
}var commentEls =  new Array (0);
for (var i = container.childNodes.length - 1; i >= 0; i--) {
var node = container.childNodes[i];
var nodeName = node.nodeName;
if (nodeName != null && nodeName.length > 0 && !nodeName.startsWith ("#")) {
if (node.childNodes != null && node.childNodes.length > 0) {
net.sf.j2s.widget.Widget.traverseDOM (node, oThis, oLocal, markedEls);
}} else {
var key = node.nodeValue;
if (key != null && key.length > 0 && "#comment".equals (nodeName)) {
key = key.trim ();
if (key.length >= 2 && key.charAt (0) == '$') {
var c = key.charAt (1);
if (c == '.' || c == '~') {
var f = null;
if (c == '.') {
f = oThis[key.substring(2)];
} else {
f = oLocal[key.substring(2)];
}if (Clazz.instanceOf (f, net.sf.j2s.widget.Widget)) {
if (next == null) {
(f).createContent (node.parentNode);
} else {
var length = container.childNodes.length;
var siblings =  new Array (length - (i + 1));
var idx = 0;
for (var j = length - 1; j > i; j--) {
var item = container.childNodes[j];
siblings[idx] = item;
idx++;
node.parentNode.removeChild (item);
}
(f).createContent (node.parentNode);
for (var j = siblings.length - 1; j >= 0; j--) {
node.parentNode.appendChild (siblings[j]);
}
}}} else if (c == ':') {
if (next != null) {
oThis[key.substring(2)]  = next;
}} else if (c == '#') {
if (next != null) {
markedEls[markedEls.length] = next;
}}if (!debugging) {
commentEls[commentEls.length] = node;
}}}}next = node;
}
if (!debugging && commentEls.length > 0) {
for (var j = 0; j < commentEls.length; j++) {
var item = commentEls[j];
item.parentNode.removeChild (item);
}
}}, $fz.isPrivate = true, $fz), "~O,~O,~O,~A");
c$.parseCSS = Clazz.defineMethod (c$, "parseCSS", 
function (oThis, oLocal, css) {
{
if (arguments.length == 0) {
return null;
}
var xcss = arguments[arguments.length - 1];
var xLocal = null;
var xThis = null;
for (var i = arguments.length - 2; i >= 0; i--) {
var arg = arguments[i];
var pt = arg.constructor != null ? arg.constructor.prototype : null;
if (pt == null) continue;
var clazzKey = "__CLASS_NAME__";
var elementKey = "nodeName";
if (xThis == null && typeof arg == "function" && arg[clazzKey] != null) {
xThis = arg;
} else if (xLocal == null && xThis == null && pt[clazzKey] == null && arg[elementKey] == null) {
xLocal = arg;
} else if (xThis == null && pt[clazzKey] != null && arg[elementKey] == null) {
xThis = arg;
} else if (xThis == null && pt[clazzKey] != null && arg[elementKey] == null) {
xThis = arg;
// } else {
}
}
css = xcss;
oLocal = xLocal;
oThis = xThis;
}if (css != null) {
net.sf.j2s.widget.Widget.addCSS (net.sf.j2s.widget.Widget.parseXTag (oThis, oLocal, css));
}}, "~O,~O,~S");
c$.addCSS = Clazz.defineMethod (c$, "addCSS", 
function (cssText) {
if (document.createStyleSheet != null) {
// Internet Explorer does not support loading dynamic css styles
// by creating <STYLE> element!
var sheet = null;
try {
sheet = document.createStyleSheet ();
sheet.cssText = cssText;
} catch (e) {
//sheet = document.styleSheets[document.styleSheets.length - 1];
var min = 0;
var idx = 0;
for (var i = 0; i < document.styleSheets.length; i++) {
var style = document.styleSheets[i];
if (min == 0) {
min = style.cssText.length;
idx = i;
} else if (min > style.cssText.length) {
min = style.cssText.length;
idx = i;
}
}
sheet = document.styleSheets[idx];
sheet.cssText += "\r\n" + cssText;
}
} else {
var cssStyle = document.createElement ("STYLE");
cssStyle.appendChild (document.createTextNode (cssText));
document.getElementsByTagName ("HEAD")[0].appendChild (cssStyle);
}
}, "~S");
Clazz.defineMethod (c$, "dispose", 
function () {
});

Clazz.parseHTML = net.sf.j2s.widget.Widget.parseHTML;
Clazz.parseCSS = net.sf.j2s.widget.Widget.parseCSS;
