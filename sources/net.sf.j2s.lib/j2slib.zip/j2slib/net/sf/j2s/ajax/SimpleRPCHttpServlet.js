﻿$_J("net.sf.j2s.ajax");
$_L(["javax.servlet.http.HttpServlet","java.util.HashSet"],"net.sf.j2s.ajax.SimpleRPCHttpServlet",["java.io.ByteArrayOutputStream","java.lang.Long","$.StringBuffer","java.net.URLDecoder","java.util.Date"],function(){
c$=$_C(function(){
this.runnables=null;
this.postLimit=0x1000000;
this.supportXSS=true;
this.xssPartLimit=128;
this.xssLatency=60000;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimpleRPCHttpServlet",javax.servlet.http.HttpServlet);
$_Y(c$,function(){
this.runnables=new java.util.HashSet();
});
$_M(c$,"maxPostLimit",
function(){
return this.postLimit;
});
$_M(c$,"supportXSSRequest",
function(){
return this.supportXSS;
});
$_M(c$,"maxXSSRequestParts",
function(){
return this.xssPartLimit;
});
$_M(c$,"maxXSSRequestLatency",
function(){
return this.xssLatency;
});
$_M(c$,"getRunnableByRequest",
function(request){
if(request==null)return null;
var length=request.length;
if(length<=7||!request.startsWith("WLL"))return null;
var index=request.indexOf('#');
if(index==-1)return null;
var clazzName=request.substring(6,index);
if(!this.validateRunnable(clazzName))return null;
return this.createRunnableInstance(clazzName);
},"~S");
$_M(c$,"createRunnableInstance",
function(clazzName){
try{
var runnableClass=Class.forName(clazzName);
if(runnableClass!=null){
var constructor=runnableClass.getConstructor([new Array(0)]);
var obj=constructor.newInstance([new Array(0)]);
if(obj!=null&&$_O(obj,net.sf.j2s.ajax.SimpleRPCRunnable)){
return obj;
}}}catch(e){
if($_O(e,SecurityException)){
e.printStackTrace();
}else if($_O(e,IllegalArgumentException)){
e.printStackTrace();
}else if($_O(e,ClassNotFoundException)){
e.printStackTrace();
}else if($_O(e,NoSuchMethodException)){
e.printStackTrace();
}else if($_O(e,InstantiationException)){
e.printStackTrace();
}else if($_O(e,IllegalAccessException)){
e.printStackTrace();
}else if($_O(e,java.lang.reflect.InvocationTargetException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},"~S");
$_M(c$,"init",
function(){
var runnableStr=this.getInitParameter("simple.rpc.runnables");
if(runnableStr!=null){
var splits=runnableStr.trim().$plit("\\s*[,;:]\\s*");
for(var i=0;i<splits.length;i++){
var trim=splits[i].trim();
if(trim.length!=0){
this.runnables.add(trim);
}}
}var postLimitStr=this.getInitParameter("simple.rpc.post.limit");
if(postLimitStr!=null){
try{
this.postLimit=Long.parseLong(postLimitStr);
if(this.postLimit<=0){
this.postLimit=9223372036854775807;
}}catch(e){
if($_O(e,NumberFormatException)){
e.printStackTrace();
}else{
throw e;
}
}
}var xssSupportStr=this.getInitParameter("simple.rpc.xss.support");
if(xssSupportStr!=null){
this.supportXSS="true".equals(xssSupportStr);
}var xssLatencytStr=this.getInitParameter("simple.rpc.xss.max.latency");
if(xssLatencytStr!=null){
try{
this.xssLatency=Long.parseLong(xssLatencytStr);
}catch(e){
if($_O(e,NumberFormatException)){
e.printStackTrace();
}else{
throw e;
}
}
}var xssPartsStr=this.getInitParameter("simple.rpc.xss.max.parts");
if(xssPartsStr!=null){
try{
this.xssPartLimit=Integer.parseInt(xssPartsStr);
}catch(e){
if($_O(e,NumberFormatException)){
e.printStackTrace();
}else{
throw e;
}
}
}$_U(this,net.sf.j2s.ajax.SimpleRPCHttpServlet,"init",[]);
});
$_M(c$,"validateRunnable",
function(clazzName){
return this.runnables.contains(clazzName);
},"~S");
$_V(c$,"doPost",
function(req,resp){
var request=null;
var res=req.getInputStream();
try{
var baos=new java.io.ByteArrayOutputStream();
var buf=$_A(1024,0);
var read=0;
while((read=res.read(buf))!=-1){
baos.write(buf,0,read);
if(baos.size()>this.maxPostLimit()){
res.close();
resp.sendError(403,"Data size reaches the limit of Java2Script Simple RPC!");
return;
}}
res.close();
request=baos.toString();
}catch(e){
if($_O(e,java.io.IOException)){
e.printStackTrace();
resp.sendError(400);
return;
}else{
throw e;
}
}
var runnable=this.getRunnableByRequest(request);
if(runnable==null){
resp.sendError(404);
return;
}resp.setContentType("text/plain");
var writer=resp.getWriter();
runnable.deserialize(request);
runnable.ajaxRun();
writer.write(runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_V(c$,"doGet",
function(req,resp){
var request=req.getQueryString();
if(request==null||request.length<4){
resp.sendError(400);
return;
}var isScriptReuest=false;
var requestID=null;
if((request.charAt(3)).charCodeAt(0)==('=').charCodeAt(0)){
request=req.getParameter("jzz");
if(request==null||request.trim().length==0){
resp.sendError(400);
return;
}requestID=req.getParameter("jzn");
if(requestID!=null&&requestID.length!=0){
isScriptReuest=true;
request=this.prepareScriptRequest(req,resp,requestID,request);
if(request==null){
return;
}}}else{
request=java.net.URLDecoder.decode(request,"UTF-8");
}var runnable=this.getRunnableByRequest(request);
if(runnable==null){
resp.sendError(404);
return;
}runnable.deserialize(request);
runnable.ajaxRun();
var serialize=runnable.serialize();
if(isScriptReuest){
resp.setContentType("text/javascript");
var writer=resp.getWriter();
writer.write("net.sf.j2s.ajax.SimpleRPCRequest.xssNotify(");
writer.write("\"" + requestID + "\", \"");
writer.write(serialize.replaceAll("\r","\\\\r").replaceAll("\n","\\\\n").replaceAll("\"", "\\\\\""));
writer.write("\");");
return;
}resp.setContentType("text/plain");
var writer=resp.getWriter();
writer.write(serialize);
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_M(c$,"prepareScriptRequest",
($fz=function(req,resp,scriptRequestID,request){
if(!scriptRequestID.matches("\\d{6,}")){
resp.sendError(400);
return null;
}if(!this.supportXSSRequest()){
resp.setContentType("text/javascript");
resp.getWriter().write("net.sf.j2s.ajax.SimpleRPCRequest"+".xssNotify(\"" + scriptRequestID + "\", \"unsupported\");");
return null;
}var count=req.getParameter("jzp");
if(count==null||!count.matches("[1-9]\\d{0,2}")){
resp.sendError(400);
return null;
}var partsCount=Integer.parseInt(count);
if(partsCount==1){
return request;
}var current=req.getParameter("jzc");
if(current==null||!current.matches("[1-9]\\d{0,2}")){
resp.sendError(400);
return null;
}var curPart=Integer.parseInt(current);
if(partsCount<1||curPart>partsCount){
resp.sendError(400);
return null;
}if(partsCount>this.maxXSSRequestParts()){
resp.setContentType("text/javascript");
resp.getWriter().write("net.sf.j2s.ajax.SimpleRPCRequest"+".xssNotify(\"" + scriptRequestID + "\", \"exceedrequestlimit\");");
return null;
}var attrName="jzn"+scriptRequestID;
var attrTime="jzt"+scriptRequestID;
var parts=null;
var badRequest=false;
var toContinue=false;
var session=req.getSession();
{
this.cleanSession(session);
var attr=session.getAttribute(attrName);
if(attr==null){
parts=new Array(partsCount);
session.setAttribute(attrName,parts);
session.setAttribute(attrTime,new java.util.Date());
}else{
parts=attr;
if(partsCount!=parts.length){
badRequest=true;
}}if(!badRequest){
parts[curPart-1]=request;
for(var i=0;i<parts.length;i++){
if(parts[i]==null){
toContinue=true;
break;
}}
if(!toContinue){
session.removeAttribute(attrName);
session.removeAttribute(attrTime);
}}}if(badRequest){
resp.sendError(400);
return null;
}if(toContinue){
resp.setContentType("text/javascript");
resp.getWriter().write("net.sf.j2s.ajax.SimpleRPCRequest"+".xssNotify(\"" + scriptRequestID + "\", \"continue\""+((curPart==1)?", \"" + session.getId () + "\");":");"));
return null;
}var buf=new StringBuffer();
for(var i=0;i<parts.length;i++){
buf.append(parts[i]);
parts[i]=null;
}
return buf.toString();
},$fz.isPrivate=true,$fz),"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse,~S,~S");
$_M(c$,"cleanSession",
($fz=function(ses){
var attrNames=ses.getAttributeNames();
while(attrNames.hasMoreElements()){
var name=attrNames.nextElement();
if(name.startsWith("jzt")){
var dt=ses.getAttribute(name);
if(new java.util.Date().getTime()-dt.getTime()>this.maxXSSRequestLatency()){
ses.removeAttribute(name);
ses.removeAttribute("jzn"+name.substring(3));
}}}
},$fz.isPrivate=true,$fz),"javax.servlet.http.HttpSession");
});
