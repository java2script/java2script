﻿$_J("net.sf.j2s.ajax");
$_L(null,"net.sf.j2s.ajax.SimplePipeHelper",["java.lang.Thread"],function(){
c$=$_T(net.sf.j2s.ajax,"SimplePipeHelper");
$_I(net.sf.j2s.ajax.SimplePipeHelper,"IPipeThrough");
$_I(net.sf.j2s.ajax.SimplePipeHelper,"IPipeClosing");
c$.registerPipe=$_M(c$,"registerPipe",
function(key,pipe){
if(key==null||pipe==null)return;
if(net.sf.j2s.ajax.SimplePipeHelper.pipes==null){
net.sf.j2s.ajax.SimplePipeHelper.pipes=new Object();
}
net.sf.j2s.ajax.SimplePipeHelper.pipes[key]=pipe;
},"~S,net.sf.j2s.ajax.SimplePipeRunnable");
c$.removePipe=$_M(c$,"removePipe",
function(key){
delete net.sf.j2s.ajax.SimplePipeHelper.pipes[key];
},"~S");
c$.getPipe=$_M(c$,"getPipe",
function(key){
var ps=net.sf.j2s.ajax.SimplePipeHelper.pipes;
if(ps==null||key==null)return null;
return ps[key];
},"~S");
c$.waitAMomentForClosing=$_M(c$,"waitAMomentForClosing",
function(runnable){
var extra=runnable.pipeWaitClosingInterval();
var interval=runnable.pipeMonitoringInterval();
if(interval<=0){
interval=1000;
}while(!runnable.isPipeLive()&&extra>0){
try{
Thread.sleep(interval);
extra-=interval;
}catch(e){
if($_O(e,InterruptedException)){
}else{
throw e;
}
}
}
return!runnable.isPipeLive();
},"net.sf.j2s.ajax.SimplePipeRunnable");
$_S(c$,
"pipeMap",null,
"pipes",null);
});
