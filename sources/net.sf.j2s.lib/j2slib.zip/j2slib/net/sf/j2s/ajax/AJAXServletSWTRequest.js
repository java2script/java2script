﻿$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.AJAXServletRequest"],"net.sf.j2s.ajax.AJAXServletSWTRequest",["net.sf.j2s.ajax.HttpRequest","$.XHRCallbackSWTAdapter"],function(){
c$=$_T(net.sf.j2s.ajax,"AJAXServletSWTRequest",net.sf.j2s.ajax.AJAXServletRequest);
c$.swtRequest=$_M(c$,"swtRequest",
function(runnable){
this.ajaxRequest(runnable);
},"net.sf.j2s.ajax.SimpleRPCRunnable");
c$.swtAJAXRequest=$_M(c$,"swtAJAXRequest",
($fz=function(runnable){
var request=new net.sf.j2s.ajax.HttpRequest();
request.open("POST",runnable.url(),true);
request.registerOnReadyStateChange((function(i$,v$){
if(!$_D("net.sf.j2s.ajax.AJAXServletSWTRequest$1")){
$_H();
c$=$_W(net.sf.j2s.ajax,"AJAXServletSWTRequest$1",net.sf.j2s.ajax.XHRCallbackSWTAdapter);
$_V(c$,"swtOnComplete",
function(){
this.f$.runnable.deserialize(this.f$.request.getResponseText());
this.f$.runnable.ajaxOut();
});
c$=$_P();
}
return $_N(net.sf.j2s.ajax.AJAXServletSWTRequest$1,i$,v$);
})(this,$_F("runnable",runnable,"request",request)));
request.send(runnable.serialize());
},$fz.isPrivate=true,$fz),"net.sf.j2s.ajax.SimpleRPCRunnable");
});
