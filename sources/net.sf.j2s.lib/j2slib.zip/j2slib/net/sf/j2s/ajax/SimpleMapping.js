﻿$_J("net.sf.j2s.ajax");
c$=$_C(function(){
this.map=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimpleMapping");
$_Y(c$,function(){
this.map=$_A(8,2,null);
});
$_M(c$,"getRunnableClassName",
function(relativeURL){
for(var i=0;i<this.map.length;i++){
if(this.map[i]!=null){
if(relativeURL.equals(this.map[i][0])){
return this.map[i][1];
}}}
return null;
},"~S");
$_M(c$,"getRunnableURL",
function(clazzName){
for(var i=0;i<this.map.length;i++){
if(this.map[i]!=null){
if(clazzName.equals(this.map[i][1])){
return this.map[i][2];
}}}
return null;
},"~S");
$_M(c$,"add",
function(url,clazzName){
var length=this.map.length;
if(url==null&&clazzName==null){
return false;
}if(url==null){
for(var i=0;i<length;i++){
if(this.map[i]!=null){
if(clazzName.equals(this.map[i][1])){
this.map[i]=null;
return true;
}}}
return false;
}for(var i=0;i<length;i++){
if(this.map[i]!=null){
if(clazzName.equals(this.map[i][1])){
return false;
}}}
for(var i=0;i<length;i++){
if(this.map[i]==null){
this.map[i]=new Array(2);
this.map[i][0]=url;
this.map[i][1]=clazzName;
return true;
}}
var newMap=$_A(length+8,2,null);
for(var i=0;i<length;i++){
newMap[i]=this.map[i];
}
newMap[length]=new Array(2);
newMap[length][0]=url;
newMap[length][1]=clazzName;
this.map=newMap;
return true;
},"~S,~S");
