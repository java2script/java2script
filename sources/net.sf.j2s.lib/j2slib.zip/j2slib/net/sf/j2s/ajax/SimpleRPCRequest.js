﻿$_J("net.sf.j2s.ajax");
$_L(null,"net.sf.j2s.ajax.SimpleRPCRequest",["net.sf.j2s.ajax.HttpRequest","$.XHRCallbackAdapter"],function(){
c$=$_T(net.sf.j2s.ajax,"SimpleRPCRequest");
c$.switchToAJAXMode=$_M(c$,"switchToAJAXMode",
function(){
($t$=net.sf.j2s.ajax.SimpleRPCRequest.runningMode=net.sf.j2s.ajax.SimpleRPCRequest.MODE_AJAX,net.sf.j2s.ajax.SimpleRPCRequest.prototype.runningMode=net.sf.j2s.ajax.SimpleRPCRequest.runningMode,$t$);
});
c$.switchToLocalJavaThreadMode=$_M(c$,"switchToLocalJavaThreadMode",
function(){
($t$=net.sf.j2s.ajax.SimpleRPCRequest.runningMode=net.sf.j2s.ajax.SimpleRPCRequest.MODE_LOCAL_JAVA_THREAD,net.sf.j2s.ajax.SimpleRPCRequest.prototype.runningMode=net.sf.j2s.ajax.SimpleRPCRequest.runningMode,$t$);
});
c$.request=$_M(c$,"request",
function(runnable){
runnable.ajaxIn();
net.sf.j2s.ajax.SimpleRPCRequest.ajaxRequest(runnable);
},"net.sf.j2s.ajax.SimpleRPCRunnable");
c$.getClassNameURL=$_M(c$,"getClassNameURL",
function(runnable){
var oClass=runnable.getClass();
var name=oClass.getName();
while(name.indexOf('$')!=-1){
oClass=oClass.getSuperclass();
if(oClass==null){
return null;
}name=oClass.getName();
}
return name;
},"net.sf.j2s.ajax.SimpleRPCRunnable");
c$.ajaxRequest=$_M(c$,"ajaxRequest",
($fz=function(runnable){
var request=new net.sf.j2s.ajax.HttpRequest();
var url=runnable.getHttpURL();
var method=runnable.getHttpMethod();
if(method==null){
method="POST";
}request.open(method,url,true);
request.registerOnReadyStateChange((function(i$,v$){
if(!$_D("net.sf.j2s.ajax.SimpleRPCRequest$1")){
$_H();
c$=$_W(net.sf.j2s.ajax,"SimpleRPCRequest$1",net.sf.j2s.ajax.XHRCallbackAdapter);
$_V(c$,"onLoaded",
function(){
this.f$.runnable.deserialize(this.f$.request.getResponseText());
this.f$.runnable.ajaxOut();
});
c$=$_P();
}
return $_N(net.sf.j2s.ajax.SimpleRPCRequest$1,i$,v$);
})(this,$_F("runnable",runnable,"request",request)));
request.send(runnable.serialize());
},$fz.isPrivate=true,$fz),"net.sf.j2s.ajax.SimpleRPCRunnable");
$_S(c$,
"MODE_AJAX",1,
"MODE_LOCAL_JAVA_THREAD",2);
c$.runningMode=c$.prototype.runningMode=net.sf.j2s.ajax.SimpleRPCRequest.MODE_LOCAL_JAVA_THREAD;
});
