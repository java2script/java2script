/* http://j2s.sf.net/ */
function CookieMonster(aXMLHttpRequest)
{
this.channel_=aXMLHttpRequest.channel;



this.topic_="http-on-modify-request";

this.observerService_=Components.classes["@mozilla.org/observer-service;1"].getService(Components.interfaces.nsIObserverService);
this.observerService_.addObserver(this,this.topic_,false);



this.lunchTime_=new Scheduler(this.stopEating,15000);
}


CookieMonster.prototype.QueryInterface=function(iid)
{
if(iid.equals(Components.interfaces.nsISupports)
||iid.equals(Components.interfaces.nsIObserver))
return this;
throw Components.results.NS_ERROR_NO_INTERFACE;
}


CookieMonster.prototype.observe=function(subject,topic,data)
{
if(topic!=this.topic_||subject!=this.channel_)
return;


this.channel_.QueryInterface(Components.interfaces.nsIHttpChannel);
this.channel_.setRequestHeader("Cookie","",false);




this.lunchTime_.stop();
this.stopEating();
}


CookieMonster.prototype.stopEating=function()
{

this.observerService_.removeObserver(this,this.topic_);
delete(this.channel_);
delete(this.lunchTime_);
delete(this.observerService_);
}


function Scheduler(callback,callAfter_MS)
{
this.callback_=callback;


this.timer_=Components.classes["@mozilla.org/timer;1"].createInstance(Components.interfaces.nsITimer);


var observerService=Components.classes["@mozilla.org/observer-service;1"].getService(Components.interfaces.nsIObserverService);
observerService.addObserver(this,"xpcom-shutdown",false);


this.timer_.initWithCallback(this,callAfter_MS,this.timer_.TYPE_ONE_SHOT);
}

Scheduler.prototype.QueryInterface=function(iid)
{
if(iid.equals(Components.interfaces.nsISupports)
||iid.equals(Components.interfaces.nsITimerCallback)
||iid.equals(Components.interfaces.nsIObserver))
return this;
throw Components.results.NS_ERROR_NO_INTERFACE;
}

Scheduler.prototype.observe=function(aSubject,aTopic,aData)
{

if(aTopic=="xpcom-shutdown")
this.stop();
}

Scheduler.prototype.stop=function()
{
if(this.timer_){

this.timer_.cancel();
this.timer_=null;
this.callback_=null;
var observerService=Components.classes["@mozilla.org/observer-service;1"].getService(Components.interfaces.nsIObserverService);
observerService.removeObserver(this,"xpcom-shutdown");
}
}

Scheduler.prototype.notify=function(aTimer)
{
this.callback_();
this.stop();
}

