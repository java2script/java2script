﻿Clazz.declarePackage ("org.eclipse.core.runtime");
Clazz.load (["java.util.EventListener"], "org.eclipse.core.runtime.IRegistryChangeListener", null, function () {
Clazz.declareInterface (org.eclipse.core.runtime, "IRegistryChangeListener", java.util.EventListener);
});
