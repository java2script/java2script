﻿Clazz.declarePackage ("org.eclipse.core.runtime");
c$ = Clazz.declareInterface (org.eclipse.core.runtime, "IPath", Cloneable);
Clazz.defineStatics (c$,
"SEPARATOR", '/',
"DEVICE_SEPARATOR", ':');
