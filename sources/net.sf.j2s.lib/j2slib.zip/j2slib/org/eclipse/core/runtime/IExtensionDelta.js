﻿Clazz.declarePackage ("org.eclipse.core.runtime");
c$ = Clazz.declareInterface (org.eclipse.core.runtime, "IExtensionDelta");
Clazz.defineStatics (c$,
"ADDED", 1,
"REMOVED", 2);
