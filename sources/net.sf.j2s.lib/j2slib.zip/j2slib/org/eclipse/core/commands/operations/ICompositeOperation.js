﻿Clazz.declarePackage ("org.eclipse.core.commands.operations");
Clazz.load (["org.eclipse.core.commands.operations.IUndoableOperation"], "org.eclipse.core.commands.operations.ICompositeOperation", null, function () {
Clazz.declareInterface (org.eclipse.core.commands.operations, "ICompositeOperation", org.eclipse.core.commands.operations.IUndoableOperation);
});
