﻿Clazz.declarePackage ("org.eclipse.core.commands.common");
Clazz.load (["org.eclipse.core.commands.common.CommandException"], "org.eclipse.core.commands.common.NotDefinedException", null, function () {
c$ = Clazz.declareType (org.eclipse.core.commands.common, "NotDefinedException", org.eclipse.core.commands.common.CommandException);
});
