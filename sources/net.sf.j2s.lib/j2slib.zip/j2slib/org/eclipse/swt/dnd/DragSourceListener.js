$_L(["$wt.internal.SWTEventListener"],"$wt.dnd.DragSourceListener",null,function(){
$_I($wt.dnd,"DragSourceListener",$wt.internal.SWTEventListener);
});
