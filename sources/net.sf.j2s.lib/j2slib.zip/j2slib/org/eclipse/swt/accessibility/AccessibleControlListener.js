$_L(["$wt.internal.SWTEventListener"],"$wt.accessibility.AccessibleControlListener",null,function(){
$_I($wt.accessibility,"AccessibleControlListener",$wt.internal.SWTEventListener);
});
