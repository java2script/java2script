$_L(["java.lang.Cloneable"],"$wt.internal.CloneableCompatibility",null,function(){
$_I($wt.internal,"CloneableCompatibility",Cloneable);
});
