﻿$_L(null,"$wt.internal.browser.OS",["$wt.graphics.Point"],function(){
O$=c$=$_T($wt.internal.browser,"OS");
c$.destroyHandle=$_M(c$,"destroyHandle",
function(handle){
if(handle==null){
return;
}var el=handle;
el.onblur=null;
el.onchange=null;
el.onclick=null;
el.oncontextmenu=null;
el.ondblclick=null;
el.onfocus=null;
el.onkeydown=null;
el.onkeypress=null;
el.onkeyup=null;
el.onmousedown=null;
el.onmousemove=null;
el.onmouseout=null;
el.onmouseover=null;
el.onmouseup=null;
el.onselectchange=null;
el.onselectstart=null;
if(el.parentNode!=null){
try{
el.parentNode.removeChild(el);
}catch(e){
if($_O(e,Error)){
}else{
throw e;
}
}
}},"~O");
c$.clearChildren=$_M(c$,"clearChildren",
function(handle){
if(handle==null||(handle).nodeType!=1){
return;
}var el=handle;
for(var i=el.childNodes.length-1;i>=0;i--){
el.removeChild(el.childNodes[i]);
}
},"~O");
c$.deepClearChildren=$_M(c$,"deepClearChildren",
function(handle){
if(handle==null){
return;
}var el=handle;
for(var i=el.childNodes.length-1;i>=0;i--){
var child=el.childNodes[i];
if(child.nodeType==1){
O$.deepClearChildren(child);
O$.destroyHandle(child);
}else{
el.removeChild(child);
}}
},"~O");
c$.SetWindowPos=$_M(c$,"SetWindowPos",
function(handle,x,y,w,h,flags){
if(handle==null){
return;
}},"~O,~N,~N,~N,~N,~N");
c$.init=$_M(c$,"init",
($fz=function(){
if(O$.invisibleContainer==null){
var el=d$.createElement("DIV");
d$.body.appendChild(el);
var s=el.style;
s.position="absolute";
s.left="-4000px";
s.top="-300px";
s.width="3000px";
s.height="100px";
s.overflow="scroll";
($t$=O$.invisibleContainer=el,O$.prototype.invisibleContainer=O$.invisibleContainer,$t$);
($t$=O$.containers=new Object(),O$.prototype.containers=O$.containers,$t$);
el=d$.createElement("DIV");
O$.invisibleContainer.appendChild(el);
el.className="system-default";
el.style.whiteSpace="nowrap";
el.style.overflow="visible";
($t$=O$.lineContainer=el,O$.prototype.lineContainer=O$.lineContainer,$t$);
el=d$.createElement("DIV");
O$.invisibleContainer.appendChild(el);
el.style.overflow="visible";
el.style.whiteSpace="normal";
($t$=O$.blockContainer=el,O$.prototype.blockContainer=O$.blockContainer,$t$);
}},$fz.isPrivate=true,$fz));
c$.getContainerWidth=$_M(c$,"getContainerWidth",
function(container){
var el=container;
return Math.max(el.offsetWidth,Math.max(el.clientWidth,el.scrollWidth));
},"~O");
c$.getContainerHeight=$_M(c$,"getContainerHeight",
function(container){
var el=container;
var max=Math.max(el.offsetHeight,Math.max(el.clientHeight,el.scrollHeight));
if(O$.isIE){
max--;
}return max;
},"~O");
c$.insertText=$_M(c$,"insertText",
function(el,text){
var lines=null;
var handle=el;
{
if(!((/[\r\n\t&]/).test(text))){
handle.style.display="inline";
handle.appendChild(document.createTextNode(text));
return text;
}
var c160=String.fromCharCode(160);
var c160x8=c160+c160+c160+c160+c160+c160+c160+c160;
var s=text.replace(/\t/g,c160x8);
if(window["Console"]!=null&&Console.splitNeedFixed){
try{
lines=Console.splitIntoLines(s);
}catch(e){
lines=s.split(/\r\n|\r|\n/g);
}
}else{
lines=s.split(/\r\n|\r|\n/g);
}
}for(var i=0;i<lines.length;i++){
if(i>0){
handle.appendChild(d$.createElement("BR"));
}var line=lines[i];
if(line.length==0){
line=c160;
}var lastIndex=0;
var idx=line.indexOf('&');
var lineEl=d$.createElement("SPAN");
handle.appendChild(lineEl);
while(idx!=-1){
if(idx<line.length-1){
var c=line.charAt(idx+1);
if((c).charCodeAt(0)==('&').charCodeAt(0)){
idx=line.indexOf('&',idx+2);
continue;}else{
var chs=line.substring(lastIndex,idx);
if(chs.length!=0){
lineEl.appendChild(d$.createTextNode(chs));
}var span=d$.createElement("SPAN");
lineEl.appendChild(span);
span.appendChild(d$.createTextNode(""+c));
text=""+c;
lastIndex=idx+2;
idx=line.indexOf('&',lastIndex);
}}else{
break;
}}
var s=null;
{
if(lastIndex==0){
s=lines[i].replace(/&&/g,'&');
}else{
s=lines[i].substring(lastIndex,lines[i].length).replace(/&&/g,'&');
}
}lineEl.appendChild(d$.createTextNode(s));
}
return text;
},"~O,~S");
c$.wrapCSS=$_M(c$,"wrapCSS",
($fz=function(a){
if(a==null){
return null;
}else{
a=a.replace(/(^|[^-])(left|top|right|bottom|height|width)\s*:\s*[\+\-]?\d+(cm|mm|em|px|pt)?(\s*;|$)/ig,'$1');
a=a.replace(/background(-[^:]+)?\s*:\s*[^;]+(\s*;|$)/ig,'');
a=a.replace(/visibility(-[^:]+)?\s*:\s*[^;]+(\s*;|$)/ig,'');
a=a.trim();
return a;
}},$fz.isPrivate=true,$fz),"~S");
c$.setupAsPlain=$_M(c$,"setupAsPlain",
($fz=function(str,wrappedWidth){
O$.init();
var c=null;
if(wrappedWidth>0){
c=O$.blockContainer;
c.style.width=wrappedWidth+"px";
}else{
c=O$.lineContainer;
}O$.clearChildren(c);
O$.insertText(c,str);
return c;
},$fz.isPrivate=true,$fz),"~S,~N");
c$.setupAsStyled=$_M(c$,"setupAsStyled",
($fz=function(str,className,cssText,wrappedWidth){
O$.init();
cssText=O$.wrapCSS(cssText);
var e=O$.containers;
var f=null;
var g=null;
if(wrappedWidth>0){
g="+"+className+"|"+cssText;
}else{
g="~"+className+"|"+cssText;
}{
f=e[g];
}if(f!=null){
O$.clearChildren(f);
}else{
f=d$.createElement("DIV");
O$.invisibleContainer.appendChild(f);
var x=f.style;
f.className=className;
x.cssText=cssText;
if(wrappedWidth>0){
x.whiteSpace="normal";
}else{
x.whiteSpace="nowrap";
}x.overflow="visible";
{
e[g]=f;
}}if(wrappedWidth>0){
f.style.width=wrappedWidth+"px";
}O$.insertText(f,str);
return f;
},$fz.isPrivate=true,$fz),"~S,~S,~S,~N");
c$.getStringPlainWidth=$_M(c$,"getStringPlainWidth",
function(str){
var c=O$.setupAsPlain(str,-1);
return O$.getContainerWidth(c);
},"~S");
c$.getStringStyledWidth=$_M(c$,"getStringStyledWidth",
function(str,className,cssText){
{
var r=/display\s*:\s*none/ig;
if(r.test(cssText)){
return 0;
}
}var c=O$.setupAsStyled(str,className,cssText,-1);
return O$.getContainerWidth(c);
},"~S,~S,~S");
c$.getStringPlainHeight=$_M(c$,"getStringPlainHeight",
function(str){
var c=O$.setupAsPlain(str,-1);
return O$.getContainerHeight(c);
},"~S");
c$.getStringPlainWrappedHeight=$_M(c$,"getStringPlainWrappedHeight",
function(str,wrappedWidth){
var c=O$.setupAsPlain(str,wrappedWidth);
return O$.getContainerHeight(c);
},"~S,~N");
c$.getStringStyledHeight=$_M(c$,"getStringStyledHeight",
function(str,className,cssText){
{
var r=/display\s*:\s*none/ig;
if(r.test(cssText)){
return 0;
}
}var c=O$.setupAsStyled(str,className,cssText,-1);
return O$.getContainerHeight(c);
},"~S,~S,~S");
c$.getStringStyledWrappedHeight=$_M(c$,"getStringStyledWrappedHeight",
function(str,className,cssText,wrappedWidth){
{
var r=/display\s*:\s*none/ig;
if(r.test(cssText)){
return 0;
}
}var c=O$.setupAsStyled(str,className,cssText,wrappedWidth);
return O$.getContainerHeight(c);
},"~S,~S,~S,~N");
c$.getStringPlainSize=$_M(c$,"getStringPlainSize",
function(str){
var c=O$.setupAsPlain(str,-1);
return new $wt.graphics.Point(O$.getContainerWidth(c),O$.getContainerHeight(c));
},"~S");
c$.getStringStyledSize=$_M(c$,"getStringStyledSize",
function(str,className,cssText){
{
var r=/display\s*:\s*none/ig;
if(r.test(cssText)){
return new org.eclipse.swt.graphics.Point(0,0);
}
}var c=O$.setupAsStyled(str,className,cssText,-1);
return new $wt.graphics.Point(O$.getContainerWidth(c),O$.getContainerHeight(c));
},"~S,~S,~S");
c$.calcuateRelativePosition=$_M(c$,"calcuateRelativePosition",
function(el,relativeEl){
var srcEl=el;
var left=0;
var top=0;
while(el!=null&&el!=relativeEl){
left+=el.offsetLeft-el.scrollLeft;
top+=el.offsetTop-el.scrollTop;
if(el!=srcEl){
var style=null;
if(document.defaultView!=null){
style=document.defaultView.getComputedStyle(el,null);
}else if(el.currentStyle!=null){
style=el.currentStyle;
}
if(!O$.isOpera&&style!=null){
var w=0;
var bw=style.borderLeftWidth;
if(bw.length!=0){
w=parseInt(bw);
if(!isNaN(w)){
left+=w;
}
}
bw=style.borderTopWidth;
if(bw.length!=0){
w=parseInt(bw);
if(!isNaN(w)){
top+=w;
}
}
}
}el=el.offsetParent;
}
return new $wt.graphics.Point(left,top);
},"$wt.internal.xhtml.Element,$wt.internal.xhtml.Element");
c$.updateArrowSize=$_M(c$,"updateArrowSize",
function(el,style,cx,cy){
var xx=Math.floor(Math.min(cx,cy)/3);
var s=(el).style;
s.borderWidth=(xx>0?xx:0)+"px";
if((style&16384)!=0){
s.borderLeftWidth="0";
}else if((style&131072)!=0){
s.borderRightWidth="0";
}else if((style&128)!=0){
s.borderTopWidth="0";
}else if((style&1024)!=0){
if(xx>1){
s.borderWidth=(xx-1)+"px";
}s.borderBottomWidth="0";
}else{
s.borderTopWidth="0";
}var x=Math.floor(cy/6);
xx=Math.floor(cy/3);
s.position="relative";
if((style&(147456))!=0){
s.top=(x-3)+"px";
if((style&131072)!=0){
s.left="1px";
}}else{
if((style&128)!=0){
s.top=(xx-3)+"px";
}else if((style&1024)!=0){
s.top=(xx-2)+"px";
}}if(O$.isMozilla&&!O$.isFirefox){
if((style&128)!=0){
s.left="-2px";
}else if((style&1024)!=0){
s.left="-1px";
}}if(O$.isFirefox){
if((style&(147456))!=0){
s.top="-2px";
if((style&131072)!=0){
s.left="1px";
}}else{
if((style&128)!=0){
if(Math.min(cx,cy)<=12){
s.left="-1px";
}else{
s.left="-2px";
}s.top="-1px";
}else if((style&1024)!=0){
s.left="-1px";
s.top="-1px";
}}}},"~O,~N,~N,~N");
c$.existedCSSClass=$_M(c$,"existedCSSClass",
function(el,cssClazz){
var e=el;
var className=e.className;
if(className==null||className.length==0){
return false;
}var clazz=className.$plit("\\s");
for(var i=0;i<clazz.length;i++){
if(clazz[i]==cssClazz){
return true;
}}
return false;
},"~O,~S");
c$.replaceCSSClassInDepth=$_M(c$,"replaceCSSClassInDepth",
function(el,toBeRemovedCSSClazz,toBeInsertedCSSClazz){
var e=el;
if(toBeRemovedCSSClazz==null||toBeRemovedCSSClazz.length==0||toBeInsertedCSSClazz==null){
return false;
}O$.replaceCSSClass(el,toBeRemovedCSSClazz,toBeInsertedCSSClazz);
var length=e.childNodes.length;
var replaced=false;
for(var i=0;i<length;i++){
replaced=replaced||O$.replaceCSSClassInDepth(e.childNodes[i],toBeRemovedCSSClazz,toBeInsertedCSSClazz);
}
return replaced;
},"~O,~S,~S");
c$.replaceCSSClass=$_M(c$,"replaceCSSClass",
function(el,toBeRemovedCSSClazz,toBeInsertedCSSClazz){
var e=el;
var className=e.className;
if(className==null||className.length==0){
return false;
}var clazz=className.$plit("\\s");
var existed=false;
for(var i=0;i<clazz.length;i++){
if(clazz[i]==toBeRemovedCSSClazz){
existed=true;
clazz[i]=toBeInsertedCSSClazz;
break;
}}
if(existed){
e.className=clazz.join(" ");
}return existed;
},"~O,~S,~S");
c$.removeCSSClassInDepth=$_M(c$,"removeCSSClassInDepth",
function(el,cssClazz){
var e=el;
if(cssClazz==null||cssClazz.length==0){
return false;
}O$.removeCSSClass(el,cssClazz);
var length=e.childNodes.length;
var removed=false;
for(var i=0;i<length;i++){
removed=removed||O$.removeCSSClassInDepth(e.childNodes[i],cssClazz);
}
return removed;
},"~O,~S");
c$.removeCSSClass=$_M(c$,"removeCSSClass",
function(el,cssClazz){
var e=el;
var className=e.className;
if(className==null||className.length==0){
return false;
}var clazz=className.$plit("\\s");
var existed=false;
for(var i=0;i<clazz.length;i++){
if(clazz[i]==cssClazz){
existed=true;
for(var j=i;j<clazz.length-1;j++){
clazz[j]=clazz[j+1];
}
{
clazz.length--;
}break;
}}
if(existed){
e.className=clazz.join(" ");
}return existed;
},"~O,~S");
c$.addCSSClass=$_M(c$,"addCSSClass",
function(el,cssClazz){
var e=el;
var className=e.className;
if(className==null||className.length==0){
e.className=cssClazz;
return true;
}var clazz=className.$plit("\\s");
for(var i=0;i<clazz.length;i++){
if(clazz[i]==cssClazz){
return false;
}}
clazz[clazz.length]=cssClazz;
{
e.className=clazz.join(" ");
}return true;
},"~O,~S");
c$.toggleCSSClass=$_M(c$,"toggleCSSClass",
function(el,cssClazz){
var e=el;
var className=e.className;
if(className==null||className.length==0){
e.className=cssClazz;
return;
}var clazz=className.$plit("\\s");
for(var i=0;i<clazz.length;i++){
if(clazz[i]==cssClazz){
for(var j=i;j<clazz.length-1;j++){
clazz[j]=clazz[j+1];
}
{
clazz.length--;
e.className=clazz.join(" ");
}return;
}}
clazz[clazz.length]=cssClazz;
{
e.className=clazz.join(" ");
}},"~O,~S");
c$.updateCSSClass=$_M(c$,"updateCSSClass",
function(el,cssClazz,kept){
var e=el;
var className=e.className;
if(className==null||className.length==0){
if(kept){
e.className=cssClazz;
}return;
}var clazz=className.$plit("\\s");
for(var i=0;i<clazz.length;i++){
if(clazz[i]==cssClazz){
if(kept){
return;
}for(var j=i;j<clazz.length-1;j++){
clazz[j]=clazz[j+1];
}
{
clazz.length--;
e.className=clazz.join(" ");
}return;
}}
if(kept){
clazz[clazz.length]=cssClazz;
{
e.className=clazz.join(" ");
}}},"~O,~S,~B");
c$.getFixedBodyClientHeight=$_M(c$,"getFixedBodyClientHeight",
function(){
var b=d$.body;
var p=b.parentNode;
var bcHeight=b.clientHeight;
var pcHeight=p.clientHeight;
if(O$.isIE){
return(pcHeight==0)?bcHeight:pcHeight;
}else if(O$.isFirefox){
return(pcHeight==p.offsetHeight&&pcHeight==p.scrollHeight)?bcHeight:pcHeight;
}return bcHeight;
});
c$.getFixedBodyOffsetTop=$_M(c$,"getFixedBodyOffsetTop",
function(){
var b=d$.body;
var p=b.parentNode;
var pcHeight=p.clientHeight;
var bcScrollTop=b.scrollTop+b.offsetTop;
var pcScrollTop=p.scrollTop+p.offsetTop;
if(O$.isIE){
return(pcHeight==0)?bcScrollTop:pcScrollTop;
}else if(O$.isFirefox){
return(pcHeight==p.offsetHeight&&pcHeight==p.scrollHeight)?bcScrollTop:pcScrollTop;
}return bcScrollTop;
});
c$.getFixedBodyOffsetLeft=$_M(c$,"getFixedBodyOffsetLeft",
function(){
var b=d$.body;
var p=b.parentNode;
var pcHeight=p.clientHeight;
var bcScrollLeft=b.scrollLeft+b.offsetLeft;
var pcScrollLeft=p.scrollLeft+p.offsetLeft;
if(O$.isIE){
return(pcHeight==0)?bcScrollLeft:pcScrollLeft;
}else if(O$.isFirefox){
return(pcHeight==p.offsetHeight&&pcHeight==p.scrollHeight)?bcScrollLeft:pcScrollLeft;
}return bcScrollLeft;
});
c$.getImageSize=$_M(c$,"getImageSize",
function(image){
var w=16;
var h=16;
if(image.width==0&&image.height==0){
if(image.url!=null&&image.url.length!=0){
var img=new Image();
img.src=image.url;
image.width=img.width;
image.height=img.height;
w=img.width;
h=img.height;
}}else{
w=image.width;
h=image.height;
}return new $wt.graphics.Point(w,h);
},"$wt.graphics.Image");
c$.SetFocus=$_M(c$,"SetFocus",
function(handle){
handle.focus();
},"$wt.internal.xhtml.Element");
$_S(c$,
"isIE",false,
"isIE60",false,
"isIE55",false,
"isIE50",false,
"isMozilla",false,
"isFirefox",false,
"isSafari",false,
"isOpera",false);
{
var os=$wt.internal.browser.OS;
var dua=navigator.userAgent;
var dav=navigator.appVersion;
os.isOpera=dua.indexOf("Opera")>=0;
var isKHTML=(dav.indexOf("Konqueror")>=0)||(dav.indexOf("Safari")>=0);
os.isSafari=dav.indexOf("Safari")>=0;
var geckoPos=dua.indexOf("Gecko");
os.isMozilla=(geckoPos>=0)&&(!isKHTML);
os.isFirefox=os.isMozilla&&dua.indexOf("Firefox")!=-1;
os.isIE=(document.all)&&(!os.isOpera);
os.isIE50=os.isIE&&dav.indexOf("MSIE 5.0")>=0;
os.isIE55=os.isIE&&dav.indexOf("MSIE 5.5")>=0;
os.isIE60=os.isIE&&dav.indexOf("MSIE 6.0")>=0;
}$_S(c$,
"invisibleContainer",null,
"containers",null,
"lineContainer",null,
"blockContainer",null);
});
