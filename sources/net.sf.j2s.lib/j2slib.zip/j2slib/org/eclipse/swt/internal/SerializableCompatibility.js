$_L(["java.io.Serializable"],"$wt.internal.SerializableCompatibility",null,function(){
$_I($wt.internal,"SerializableCompatibility",java.io.Serializable);
});
