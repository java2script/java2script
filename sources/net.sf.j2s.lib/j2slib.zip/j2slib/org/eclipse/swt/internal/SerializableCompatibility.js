﻿$_I($wt.internal,"SerializableCompatibility",java.io.Serializable);
