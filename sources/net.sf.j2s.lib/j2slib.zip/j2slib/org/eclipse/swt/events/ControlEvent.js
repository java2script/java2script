$_L(["$wt.events.TypedEvent"],"$wt.events.ControlEvent",["$wt.widgets.Event"],function(){
c$=$_T($wt.events,"ControlEvent",$wt.events.TypedEvent);
});
