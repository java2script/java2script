$_L(["$wt.internal.SWTEventListener"],"$wt.events.MouseMoveListener",null,function(){
$_I($wt.events,"MouseMoveListener",$wt.internal.SWTEventListener);
});
