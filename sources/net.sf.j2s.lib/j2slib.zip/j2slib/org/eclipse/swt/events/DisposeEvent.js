$_L(["$wt.events.TypedEvent"],"$wt.events.DisposeEvent",["$wt.widgets.Event"],function(){
c$=$_T($wt.events,"DisposeEvent",$wt.events.TypedEvent);
});
