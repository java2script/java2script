$_L(["$wt.internal.SWTEventListener"],"$wt.events.TreeListener",null,function(){
$_I($wt.events,"TreeListener",$wt.internal.SWTEventListener);
});
