$_L(["$wt.internal.SWTEventListener"],"$wt.custom.LineBackgroundListener",null,function(){
$_I($wt.custom,"LineBackgroundListener",$wt.internal.SWTEventListener);
});
