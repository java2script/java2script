$_L(["$wt.internal.SWTEventListener"],"$wt.custom.CTabFolderListener",null,function(){
$_I($wt.custom,"CTabFolderListener",$wt.internal.SWTEventListener);
});
