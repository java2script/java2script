$_L(["$wt.widgets.Item"],"$wt.widgets.CoolItem",["$wt.graphics.Point","$.Rectangle","$wt.widgets.TypedListener"],function(){
c$=$_C(function(){
this.parent=null;
this.control=null;
this.id=0;
this.ideal=false;
this.minimum=false;
$_Z(this,arguments);
},$wt.widgets,"CoolItem",$wt.widgets.Item);
$_K(c$,
function(parent,style){
$_R(this,$wt.widgets.CoolItem,[parent,style]);
this.parent=parent;
parent.createItem(this,parent.getItemCount());
},"$wt.widgets.CoolBar,~N");
$_K(c$,
function(parent,style,index){
$_R(this,$wt.widgets.CoolItem,[parent,style]);
this.parent=parent;
parent.createItem(this,index);
},"$wt.widgets.CoolBar,~N,~N");
$_M(c$,"addSelectionListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(13,typedListener);
this.addListener(14,typedListener);
},"$wt.events.SelectionListener");
$_M(c$,"computeSize",
function(wHint,hHint){
var index=this.parent.indexOf(this);
if(index==-1)return new $wt.graphics.Point(0,0);
var width=wHint;
var height=hHint;
if(wHint==-1)width=32;
if(hHint==-1)height=32;
width+=this.parent.getMargin(index);
return new $wt.graphics.Point(width,height);
},"~N,~N");
$_M(c$,"getBounds",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return new $wt.graphics.Rectangle(0,0,0,0);
return new $wt.graphics.Rectangle(0,0,0,0);
});
$_M(c$,"getClientArea",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return new $wt.graphics.Rectangle(0,0,0,0);
return new $wt.graphics.Rectangle(0,0,0,0);
});
$_M(c$,"getControl",
function(){
return this.control;
});
$_M(c$,"getParent",
function(){
return this.parent;
});
$_M(c$,"releaseChild",
function(){
$_U(this,$wt.widgets.CoolItem,"releaseChild",[]);
this.parent.destroyItem(this);
});
$_M(c$,"releaseWidget",
function(){
$_U(this,$wt.widgets.CoolItem,"releaseWidget",[]);
this.control=null;
this.parent=null;
});
$_M(c$,"setControl",
function(control){
if(control!=null){
}var index=this.parent.indexOf(this);
if(index==-1)return;
if(this.control!=null&&this.control.isDisposed()){
this.control=null;
}var oldControl=this.control;
var newControl=control;
this.control=newControl;
},"$wt.widgets.Control");
$_M(c$,"getPreferredSize",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return new $wt.graphics.Point(0,0);
return new $wt.graphics.Point(0,0);
});
$_M(c$,"setPreferredSize",
function(width,height){
var index=this.parent.indexOf(this);
if(index==-1)return;
width=Math.max(0,width);
height=Math.max(0,height);
this.ideal=true;
var handle=this.parent.itemHandles[this.parent.indexOf(this)];
handle.style.width=width+"px";
handle.style.height=height+"px";
},"~N,~N");
$_M(c$,"setPreferredSize",
function(size){
this.setPreferredSize(size.x,size.y);
},"$wt.graphics.Point");
$_M(c$,"setText",
function(string){
if((this.style&2)!=0)return;
$_U(this,$wt.widgets.CoolItem,"setText",[string]);
var handle=this.parent.itemHandles[this.parent.indexOf(this)];
if(handle!=null){
handle.appendChild(d$.createTextNode(string));
}},"~S");
$_M(c$,"getSize",
function(){
var index=this.parent.indexOf(this);
if(index==-1)new $wt.graphics.Point(0,0);
return new $wt.graphics.Point(0,0);
});
$_M(c$,"setSize",
function(width,height){
var index=this.parent.indexOf(this);
if(index==-1)return;
width=Math.max(0,width);
height=Math.max(0,height);
},"~N,~N");
$_M(c$,"setSize",
function(size){
this.setSize(size.x,size.y);
},"$wt.graphics.Point");
$_M(c$,"getMinimumSize",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return new $wt.graphics.Point(0,0);
return new $wt.graphics.Point(32,16);
});
$_M(c$,"setMinimumSize",
function(width,height){
var index=this.parent.indexOf(this);
if(index==-1)return;
width=Math.max(0,width);
height=Math.max(0,height);
this.minimum=true;
},"~N,~N");
$_M(c$,"setMinimumSize",
function(size){
this.setMinimumSize(size.x,size.y);
},"$wt.graphics.Point");
$_M(c$,"getWrap",
function(){
var index=this.parent.indexOf(this);
return false;
});
$_M(c$,"setWrap",
function(wrap){
var index=this.parent.indexOf(this);
},"~B");
$_M(c$,"removeSelectionListener",
function(listener){
if(this.eventTable==null)return;
this.eventTable.unhook(13,listener);
this.eventTable.unhook(14,listener);
},"$wt.events.SelectionListener");
});
$_L(["$wt.widgets.Composite"],"$wt.widgets.CoolBar",["$wt.graphics.Point","$wt.widgets.CoolItem"],function(){
Clazz.registerCSS("$wt.widgets.CoolBar", ".cool-bar-default {\nposition:absolute;\n}\n.cool-bar-border {\nborder:1px inset white;\n}\n.cool-item-default {\nborder:1px outset white;\nfloat:left;\ncursor:default;\nmargin:1px;\nwhite-space:nowrap;\n}");
c$=$_C(function(){
this.items=null;
this.itemHandles=null;
this.originalItems=null;
this.locked=false;
this.ignoreResize=false;
$_Z(this,arguments);
},$wt.widgets,"CoolBar",$wt.widgets.Composite);
$_K(c$,
function(parent,style){
$_R(this,$wt.widgets.CoolBar,[parent,$wt.widgets.CoolBar.checkStyle(style)]);
},"$wt.widgets.Composite,~N");
c$.checkStyle=$_M(c$,"checkStyle",
function(style){
style|=524288;
return style&-769;
},"~N");
$_M(c$,"computeSize",
function(wHint,hHint,changed){
var width=0;
var height=0;
var border=this.getBorderWidth();
var newWidth=wHint==-1?0x3FFF:wHint+(border*2);
var newHeight=hHint==-1?0x3FFF:hHint+(border*2);
if(width==0)width=64;
if(height==0)height=64;
if(wHint!=-1)width=wHint;
if(hHint!=-1)height=hHint;
height+=border*2;
width+=border*2;
return new $wt.graphics.Point(width,height);
},"~N,~N,~B");
$_M(c$,"createHandle",
function(){
$_U(this,$wt.widgets.CoolBar,"createHandle",[]);
this.state&=-3;
this.handle=d$.createElement("DIV");
if(this.parent.handle!=null){
this.parent.handle.appendChild(this.handle);
}this.handle.className="cool-bar-default";
if((this.style&2048)!=0){
this.handle.className+=" cool-bar-border";
}});
$_M(c$,"createItem",
function(item,index){
var count=this.items.length;
var id=this.items.length;
this.items[item.id=id]=item;
this.itemHandles[id]=d$.createElement("DIV");
var handle=this.itemHandles[id];
handle.className="cool-item-default";
if(index==count){
handle.appendChild(handle);
}else{
handle.insertBefore(handle,this.itemHandles[index]);
}},"$wt.widgets.CoolItem,~N");
$_M(c$,"createWidget",
function(){
$_U(this,$wt.widgets.CoolBar,"createWidget",[]);
this.items=new Array(4);
this.originalItems=new Array(0);
this.items=new Array(0);
});
$_M(c$,"destroyItem",
function(item){
},"$wt.widgets.CoolItem");
$_M(c$,"getMargin",
function(index){
var margin=0;
if((this.style&8388608)!=0){
margin+=12;
}else{
margin+=16;
}return margin;
},"~N");
$_V(c$,"findThemeControl",
function(){
return null;
});
$_M(c$,"getItem",
function(index){
var count=this.items.length;
return this.items[index];
},"~N");
$_M(c$,"getItemCount",
function(){
return this.items.length;
});
$_M(c$,"getItemOrder",
function(){
return $_A(0,0);
});
$_M(c$,"getItems",
function(){
return this.items;
});
$_M(c$,"getItemSizes",
function(){
return null;
});
$_M(c$,"getLastIndexOfRow",
function(index){
return 0;
},"~N");
$_M(c$,"isLastItemOfRow",
function(index){
return false;
},"~N");
$_M(c$,"getLocked",
function(){
return this.locked;
});
$_M(c$,"getWrapIndices",
function(){
var items=this.getItems();
var indices=$_A(items.length,0);
var count=0;
for(var i=0;i<items.length;i++){
if(items[i].getWrap())indices[count++]=i;
}
var result=$_A(count,0);
System.arraycopy(indices,0,result,0,count);
return result;
});
$_M(c$,"indexOf",
function(item){
for(var i=0;i<this.items.length;i++){
if(item==this.items[i]){
return i;
}}
return-1;
},"$wt.widgets.CoolItem");
$_M(c$,"resizeToPreferredWidth",
function(index){
},"~N");
$_M(c$,"resizeToMaximumWidth",
function(index){
},"~N");
$_M(c$,"releaseWidget",
function(){
for(var i=0;i<this.items.length;i++){
var item=this.items[i];
if(item!=null&&!item.isDisposed()){
item.releaseResources();
}}
this.items=null;
$_U(this,$wt.widgets.CoolBar,"releaseWidget",[]);
});
$_M(c$,"removeControl",
function(control){
$_U(this,$wt.widgets.CoolBar,"removeControl",[control]);
for(var i=0;i<this.items.length;i++){
var item=this.items[i];
if(item!=null&&item.control==control){
item.setControl(null);
}}
},"$wt.widgets.Control");
$_M(c$,"setBackgroundPixel",
function(pixel){
if(this.background==pixel)return;
this.background=pixel;
},"~N");
$_M(c$,"setForegroundPixel",
function(pixel){
if(this.foreground==pixel)return;
this.foreground=pixel;
},"~N");
$_M(c$,"setItemColors",
function(foreColor,backColor){
},"~N,~N");
$_M(c$,"setItemLayout",
function(itemOrder,wrapIndices,sizes){
this.setRedraw(false);
this.setItemOrder(itemOrder);
this.setWrapIndices(wrapIndices);
this.setItemSizes(sizes);
this.setRedraw(true);
},"~A,~A,~A");
$_M(c$,"setItemOrder",
function(itemOrder){
},"~A");
$_M(c$,"setItemSizes",
function(sizes){
},"~A");
$_M(c$,"setLocked",
function(locked){
this.locked=locked;
},"~B");
$_M(c$,"setWrapIndices",
function(indices){
if(indices==null)indices=$_A(0,0);
var count=this.getItemCount();
for(var i=0;i<indices.length;i++){
}
this.setRedraw(false);
var items=this.getItems();
for(var i=0;i<items.length;i++){
var item=items[i];
if(item.getWrap()){
this.resizeToPreferredWidth(i-1);
item.setWrap(false);
}}
this.resizeToMaximumWidth(count-1);
for(var i=0;i<indices.length;i++){
var index=indices[i];
if(0<=index&&index<items.length){
var item=items[index];
item.setWrap(true);
this.resizeToMaximumWidth(index-1);
}}
this.setRedraw(true);
},"~A");
$_S(c$,
"SEPARATOR_WIDTH",2,
"MAX_WIDTH",0x7FFF);
});
