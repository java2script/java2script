﻿$_L(["$wt.widgets.Item"],"$wt.widgets.TreeItem",["$wt.SWT","$.SWTException","$wt.graphics.Color","$.Font","$.Image","$.Rectangle","$wt.internal.RunnableCompatibility","$wt.internal.browser.OS","$wt.widgets.Event"],function(){
c$=$_C(function(){
this.strings=null;
this.images=null;
this.parent=null;
this.parentItem=null;
this.items=null;
this.index=0;
this.expandStatus=false;
this.checkElement=null;
$_Z(this,arguments);
},$wt.widgets,"TreeItem",$wt.widgets.Item);
$_K(c$,
function(parent,style){
$_R(this,$wt.widgets.TreeItem,[parent,style]);
this.parent=parent;
this.items=new Array(0);
parent.createItem(this,null,-1);
},"$wt.widgets.Tree,~N");
$_K(c$,
function(parent,style,index){
$_R(this,$wt.widgets.TreeItem,[parent,style]);
this.parent=parent;
this.items=new Array(0);
parent.createItem(this,null,index);
},"$wt.widgets.Tree,~N,~N");
$_K(c$,
function(parentItem,style){
$_R(this,$wt.widgets.TreeItem,[parentItem.parent,style]);
this.parent=parentItem.parent;
this.parentItem=parentItem;
this.items=new Array(0);
this.parent.createItem(this,parentItem.handle,-1);
},"$wt.widgets.TreeItem,~N");
$_K(c$,
function(parentItem,style,index){
$_R(this,$wt.widgets.TreeItem,[parentItem.parent,style]);
this.parent=parentItem.parent;
this.items=new Array(0);
this.parentItem=parentItem;
this.parent.createItem(this,parentItem.handle,index);
},"$wt.widgets.TreeItem,~N,~N");
c$.checkNull=$_M(c$,"checkNull",
function(item){
return item;
},"$wt.widgets.TreeItem");
$_M(c$,"getBackground",
function(){
return new $wt.graphics.Color(this.display,this.handle.style.backgroundColor);
});
$_M(c$,"getBackground",
function(index){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return this.getBackground();
return new $wt.graphics.Color(this.display,this.handle.style.backgroundColor);
},"~N");
$_M(c$,"getBounds",
function(){
return new $wt.graphics.Rectangle(0,0,0,0);
});
$_M(c$,"getBounds",
function(index){
return new $wt.graphics.Rectangle(0,0,0,0);
},"~N");
$_M(c$,"getChecked",
function(){
if((this.parent.style&32)==0)return false;
if(this.checkElement!=null){
return this.checkElement.checked;
}return false;
});
$_M(c$,"getExpanded",
function(){
return false;
});
$_M(c$,"getFont",
function(){
return this.display.getSystemFont();
});
$_M(c$,"getFont",
function(index){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return this.getFont();
return this.display.getSystemFont();
},"~N");
$_M(c$,"getForeground",
function(){
return new $wt.graphics.Color(this.display,this.parent.handle.style.color);
});
$_M(c$,"getForeground",
function(index){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return this.getForeground();
return new $wt.graphics.Color(this.display,this.handle.style.color);
},"~N");
$_M(c$,"getGrayed",
function(){
if((this.parent.style&32)==0)return false;
if(this.checkElement!=null){
return this.checkElement.checked;
}return true;
});
$_M(c$,"getItem",
function(index){
return this.items[index];
},"~N");
$_M(c$,"getItemCount",
function(){
return this.items.length;
});
$_M(c$,"getItems",
function(){
return this.items;
});
$_M(c$,"getImage",
function(index){
if(index==0)return this.getImage();
if(this.images!=null){
if(0<=index&&index<this.images.length)return this.images[index];
}return null;
},"~N");
$_M(c$,"getImageBounds",
function(index){
return new $wt.graphics.Rectangle(0,0,0,0);
},"~N");
$_M(c$,"getParent",
function(){
return this.parent;
});
$_M(c$,"getParentItem",
function(){
return this.parentItem;
});
$_M(c$,"getText",
function(index){
if(index==0)return this.getText();
if(this.strings!=null){
if(0<=index&&index<this.strings.length){
var string=this.strings[index];
return string!=null?string:"";
}}return"";
},"~N");
$_M(c$,"indexOf",
function(item){
return this.parent.indexOf(this.index,item);
},"$wt.widgets.TreeItem");
$_M(c$,"redraw",
function(){
if(this.parent.drawCount>0)return;
});
$_M(c$,"redraw",
function(column,drawText,drawImage){
if(this.parent.drawCount>0)return;
},"~N,~B,~B");
$_M(c$,"releaseChild",
function(){
$_U(this,$wt.widgets.TreeItem,"releaseChild",[]);
var children=this.getItems();
for(var i=0;i<children.length;i++){
children[i].dispose();
}
this.parent.destroyItem(this);
if(this.parentItem!=null){
this.parentItem.destroyItem(this);
}});
$_M(c$,"destroyItem",
($fz=function(item){
var length=this.items.length;
var index=-1;
for(var i=0;i<length;i++){
if(this.items[i].equals(item)){
index=i;
}}
if(index>-1){
var newItems=new Array(0);
System.arraycopy(this.items,0,newItems,0,index);
System.arraycopy(this.items,index+1,newItems,index,this.items.length-index-1);
this.items=newItems;
}},$fz.isPrivate=true,$fz),"$wt.widgets.TreeItem");
$_M(c$,"releaseHandle",
function(){
$_U(this,$wt.widgets.TreeItem,"releaseHandle",[]);
if(this.handle!=null){
O$.destroyHandle(this.handle);
this.handle=null;
}});
$_M(c$,"releaseWidget",
function(){
$_U(this,$wt.widgets.TreeItem,"releaseWidget",[]);
if(this.handle!=null){
O$.destroyHandle(this.handle);
this.handle=null;
}});
$_M(c$,"removeAll",
function(){
var items=this.getItems();
var length=items.length;
for(var i=0;i<length;i++){
items[i].dispose();
}
this.items=new Array(0);
});
$_M(c$,"setBackground",
function(color){
this.redraw();
},"$wt.graphics.Color");
$_M(c$,"setBackground",
function(index,color){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return;
this.redraw(index,true,true);
},"~N,$wt.graphics.Color");
$_M(c$,"setChecked",
function(checked){
if((this.parent.style&32)==0)return;
if(this.checkElement!=null){
this.checkElement.checked=checked;
}},"~B");
$_M(c$,"setExpanded",
function(expanded){
this.expandStatus=expanded;
if(this.getItemCount()==0){
return;
}var items=this.parent.getDescendantItems(this.index);
for(var i=0;i<items.length;i++){
if(items[i]==null)continue;if(items[i].parentItem==this){
items[i].expandStatus=this.expandStatus;
}if(items[i].expandStatus){
items[i].handle.style.display=expanded?"":"none";
}else{
items[i].handle.style.display="none";
}}
if(items.length==0){
this.updateModifier(0);
}else{
this.updateModifier(expanded?1:-1);
}},"~B");
$_M(c$,"setFont",
function(font){
},"$wt.graphics.Font");
$_M(c$,"setFont",
function(index,font){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return;
},"~N,$wt.graphics.Font");
$_M(c$,"setForeground",
function(color){
this.redraw();
},"$wt.graphics.Color");
$_M(c$,"setForeground",
function(index,color){
var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return;
this.redraw(index,true,false);
},"~N,$wt.graphics.Color");
$_M(c$,"setGrayed",
function(grayed){
if((this.parent.style&32)==0)return;
if(this.checkElement!=null){
this.checkElement.checked=grayed;
}},"~B");
$_M(c$,"setImage",
function(images){
for(var i=0;i<images.length;i++){
this.setImage(i,images[i]);
}
},"~A");
$_M(c$,"setImage",
function(index,image){
if(index==0){
if(image!=null&&image.type==1){
if(image.equals(this.image))return;
}$_U(this,$wt.widgets.TreeItem,"setImage",[image]);
}var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return;
if(this.images==null&&index!=0)this.images=new Array(count);
if(this.images!=null){
if(image!=null&&image.type==1){
if(image.equals(this.images[index]))return;
}this.images[index]=image;
}},"~N,$wt.graphics.Image");
$_M(c$,"setImage",
function(image){
this.setImage(0,image);
},"$wt.graphics.Image");
$_M(c$,"setText",
function(strings){
for(var i=0;i<strings.length;i++){
var string=strings[i];
if(string!=null)this.setText(i,string);
}
},"~A");
$_M(c$,"setText",
function(index,string){
if(index==0){
if(string.equals(this.text))return;
$_U(this,$wt.widgets.TreeItem,"setText",[string]);
}var count=Math.max(1,this.parent.getColumnCount());
if(0>index||index>count-1)return;
if(this.strings==null&&index!=0)this.strings=new Array(count);
if(this.strings!=null){
if(string.equals(this.strings[index]))return;
this.strings[index]=string;
}if(index==0){
}var tbodyTD=null;
if(index<this.handle.childNodes.length){
if(this.handle.childNodes[index]!=null&&"TD".equals(this.handle.childNodes[index].nodeName)){
tbodyTD=this.handle.childNodes[index];
}}if(tbodyTD==null){
tbodyTD=d$.createElement("TD");
this.handle.appendChild(tbodyTD);
}if(tbodyTD.childNodes!=null){
O$.clearChildren(tbodyTD);
}var hItem=d$.createElement("DIV");
hItem.className="tree-item-default";
var hAnchor=d$.createElement("DIV");
hAnchor.className="tree-item-anchor-default";
hAnchor.onclick=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.TreeItem$1")){
$_H();
c$=$_W($wt.widgets,"TreeItem$1",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
this.b$["$wt.widgets.TreeItem"].toggleExpandStatus();
});
c$=$_P();
}
return $_N($wt.widgets.TreeItem$1,i$,v$);
})(this,null));
hAnchor.appendChild(d$.createTextNode(""+String.fromCharCode(160)+String.fromCharCode(160)+String.fromCharCode(160)));
hItem.appendChild(hAnchor);
if((this.parent.style&32)!=0){
this.checkElement=d$.createElement("INPUT");
this.checkElement.type="checkbox";
hItem.appendChild(this.checkElement);
this.checkElement.onclick=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.TreeItem$2")){
$_H();
c$=$_W($wt.widgets,"TreeItem$2",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
var e=new $wt.widgets.Event();
e.display=this.b$["$wt.widgets.TreeItem"].display;
e.type=13;
e.detail=32;
e.item=this.b$["$wt.widgets.TreeItem"];
e.widget=this.b$["$wt.widgets.TreeItem"];
this.b$["$wt.widgets.TreeItem"].parent.sendEvent(e);
});
c$=$_P();
}
return $_N($wt.widgets.TreeItem$2,i$,v$);
})(this,null));
}var s=(index==0)?this.getText():this.strings[index];
var text=d$.createElement("DIV");
text.className="tree-item-text-default";
text.appendChild(d$.createTextNode(s));
text.onclick=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.TreeItem$3")){
$_H();
c$=$_W($wt.widgets,"TreeItem$3",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
var evt=this.getEvent();
this.b$["$wt.widgets.TreeItem"].parent.toggleSelection(this.b$["$wt.widgets.TreeItem"],evt.ctrlKey,evt.shiftKey);
var e=new $wt.widgets.Event();
e.display=this.b$["$wt.widgets.TreeItem"].display;
e.type=13;
e.detail=0;
e.item=this.b$["$wt.widgets.TreeItem"];
e.widget=this.b$["$wt.widgets.TreeItem"];
this.b$["$wt.widgets.TreeItem"].parent.sendEvent(e);
this.toReturn(false);
});
c$=$_P();
}
return $_N($wt.widgets.TreeItem$3,i$,v$);
})(this,null));
text.ondblclick=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.TreeItem$4")){
$_H();
c$=$_W($wt.widgets,"TreeItem$4",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
this.b$["$wt.widgets.TreeItem"].toggleExpandStatus();
var e=new $wt.widgets.Event();
e.display=this.b$["$wt.widgets.TreeItem"].display;
e.type=14;
e.detail=0;
e.item=this.b$["$wt.widgets.TreeItem"];
e.widget=this.b$["$wt.widgets.TreeItem"];
this.b$["$wt.widgets.TreeItem"].parent.sendEvent(e);
this.toReturn(false);
});
c$=$_P();
}
return $_N($wt.widgets.TreeItem$4,i$,v$);
})(this,null));
text.onselectstart=$_Q((function(i$,v$){
if(!$_D("org.eclipse.swt.widgets.TreeItem$5")){
$_H();
c$=$_W($wt.widgets,"TreeItem$5",$wt.internal.RunnableCompatibility);
$_V(c$,"run",
function(){
this.toReturn(false);
});
c$=$_P();
}
return $_N($wt.widgets.TreeItem$5,i$,v$);
})(this,null));
hItem.appendChild(text);
var pItem=this.parentItem;
var padding=0;
while(pItem!=null){
pItem=pItem.parentItem;
padding+=20;
}
if((this.parent.style&67108864)!=0){
hItem.style.marginRight=padding+"px";
hAnchor.style.width="20px";
}else{
hItem.style.marginLeft=padding+"px";
}tbodyTD.appendChild(hItem);
},"~N,~S");
$_M(c$,"setText",
function(string){
this.setText(0,string);
},"~S");
$_M(c$,"showSelection",
function(selected){
var index=1;
if((this.parent.style&32)!=0){
index++;
}var element=this.handle.childNodes[0].childNodes[0].childNodes[index];
element.className=selected?"tree-item-text-selected":"tree-item-text-default";
},"~B");
$_M(c$,"toggleExpandStatus",
function(){
var clazzName=this.handle.childNodes[0].childNodes[0].childNodes[0].className;
var type=0;
if(clazzName==null){
type=0;
}else if(clazzName.indexOf("expanded")!=-1){
type=-1;
}else if(clazzName.indexOf("collapsed")!=-1){
type=1;
}if(type==0){
return;
}var toExpand=type>=0;
this.setExpanded(toExpand);
var e=new $wt.widgets.Event();
e.type=toExpand?17:18;
e.display=this.display;
e.item=this;
e.widget=this;
this.parent.sendEvent(e);
});
$_M(c$,"updateModifier",
function(type){
var isRTL=(this.parent.style&67108864)!=0;
var element=this.handle.childNodes[0].childNodes[0].childNodes[0];
if(type==-1){
element.className="tree-item-anchor-collapsed"+(isRTL?"-rtl":"");
return false;
}else if(type==1){
element.className="tree-item-anchor-expanded"+(isRTL?"-rtl":"");
return true;
}else{
element.className="tree-item-anchor-default";
return true;
}},"~N");
$_M(c$,"addItem",
function(item,index){
if(index==-1||index==this.items.length){
this.items[this.items.length]=item;
}else{
var newItem=new Array(0);
System.arraycopy(this.items,0,newItem,0,index);
System.arraycopy(this.items,index,newItem,index+1,this.items.length-index);
newItem[index]=item;
this.items=newItem;
}},"$wt.widgets.TreeItem,~N");
});
$_L(["$wt.widgets.Item"],"$wt.widgets.TreeColumn",["$wt.widgets.TypedListener"],function(){
c$=$_C(function(){
this.parent=null;
this.resizable=false;
$_Z(this,arguments);
},$wt.widgets,"TreeColumn",$wt.widgets.Item);
$_K(c$,
function(parent,style){
$_R(this,$wt.widgets.TreeColumn,[parent,$wt.widgets.TreeColumn.checkStyle(style)]);
this.resizable=true;
this.parent=parent;
parent.createItem(this,parent.getColumnCount());
},"$wt.widgets.Tree,~N");
$_K(c$,
function(parent,style,index){
$_R(this,$wt.widgets.TreeColumn,[parent,$wt.widgets.TreeColumn.checkStyle(style)]);
this.resizable=true;
this.parent=parent;
parent.createItem(this,index);
},"$wt.widgets.Tree,~N,~N");
$_M(c$,"addControlListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(11,typedListener);
this.addListener(10,typedListener);
},"$wt.events.ControlListener");
$_M(c$,"addSelectionListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(13,typedListener);
this.addListener(14,typedListener);
},"$wt.events.SelectionListener");
c$.checkStyle=$_M(c$,"checkStyle",
function(style){
return $wt.widgets.Widget.checkBits(style,16384,16777216,131072,0,0,0);
},"~N");
$_M(c$,"getAlignment",
function(){
if((this.style&16384)!=0)return 16384;
if((this.style&16777216)!=0)return 16777216;
if((this.style&131072)!=0)return 131072;
return 16384;
});
$_V(c$,"getNameText",
function(){
return this.getText();
});
$_M(c$,"getParent",
function(){
return this.parent;
});
$_M(c$,"getResizable",
function(){
return this.resizable;
});
$_M(c$,"getWidth",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return 0;
return 0;
});
$_M(c$,"pack",
function(){
var index=this.parent.indexOf(this);
if(index==-1)return;
var columnWidth=0;
});
$_M(c$,"releaseChild",
function(){
$_U(this,$wt.widgets.TreeColumn,"releaseChild",[]);
this.parent.destroyItem(this);
});
$_M(c$,"releaseWidget",
function(){
$_U(this,$wt.widgets.TreeColumn,"releaseWidget",[]);
this.parent=null;
});
$_M(c$,"removeControlListener",
function(listener){
if(this.eventTable==null)return;
this.eventTable.unhook(10,listener);
this.eventTable.unhook(11,listener);
},"$wt.events.ControlListener");
$_M(c$,"removeSelectionListener",
function(listener){
if(this.eventTable==null)return;
this.eventTable.unhook(13,listener);
this.eventTable.unhook(14,listener);
},"$wt.events.SelectionListener");
$_M(c$,"setAlignment",
function(alignment){
if((alignment&(16924672))==0)return;
var index=this.parent.indexOf(this);
if(index==-1||index==0)return;
this.style&=-16924673;
this.style|=alignment&(16924672);
},"~N");
$_M(c$,"setImage",
function(image){
var index=this.parent.indexOf(this);
if(index==-1)return;
$_U(this,$wt.widgets.TreeColumn,"setImage",[image]);
},"$wt.graphics.Image");
$_M(c$,"setResizable",
function(resizable){
this.resizable=resizable;
},"~B");
$_M(c$,"setText",
function(string){
var index=this.parent.indexOf(this);
if(index==-1)return;
$_U(this,$wt.widgets.TreeColumn,"setText",[string]);
},"~S");
$_M(c$,"setWidth",
function(width){
var index=this.parent.indexOf(this);
if(index==-1)return;
},"~N");
});
$_L(["$wt.widgets.Composite"],"$wt.widgets.Tree",["$wt.SWT","$.SWTException","$wt.events.SelectionEvent","$.SelectionListener","$.TreeListener","$wt.graphics.Point","$wt.widgets.TreeColumn","$.TreeItem","$.TypedListener"],function(){
Clazz.registerCSS("$wt.widgets.Tree",".tree-item-default {\n/*background-color:#cccccc;*/\n/*height:20px;*/\nwhite-space:nowrap;\nfont-size:9pt;\nfont-family:Arial,sans-serif;\n}\n.tree-default {\nbackground-color:white;\noverflow:auto;\nposition:absolute;\n}\n.tree-default table {\nwidth:100%;\nmargin:0;\npadding:0;\n}\n.tree-border {\nborder-style:inset;\n}\n/*\n.tree-border table {\nborder-style:inset;\n}\n*/\n.tree-item-anchor-default {\ndisplay:inline;\nwidth:20px;\nheight:1em;\npadding-left:20px;\nheight:20px;\nbackground-image:url(\'images/T.png\');\nbackground-repeat:no-repeat;\nbackground-position:center center;\ncursor:default;\n}\n.tree-item-anchor-expanded {\ndisplay:inline;\nwidth:20px;\noverflow:hidden;\npadding-left:20px;\nheight:20px;\nbackground-image:url(\'images/Lminus.png\');\nbackground-repeat:no-repeat;\nbackground-position:center center;\ncursor:default;\n/*border:1px solid red;*/\n}\n.tree-item-anchor-collapsed {\ndisplay:inline;\nwidth:20px;\noverflow:hidden;\npadding-left:20px;\nheight:20px;\nbackground-image:url(\'images/Lplus.png\');\nbackground-repeat:no-repeat;\nbackground-position:center center;\ncursor:default;\n/*border:1px solid red;*/\n}\n.tree-item-text-default {\ndisplay:inline;\ncursor:default;\n}\n.tree-item-text-selected {\ndisplay:inline;\nbackground-color:#00008e;\ncolor:white;\ncursor:default;\n}\n/* Just for right to left images I used the arrow pngs this should be changed.*/\n.tree-item-anchor-expanded-rtl {\ndisplay:inline;\nwidth:20px;\noverflow:hidden;\npadding-left:20px;\nheight:20px;\nbackground-image:url(\'images/Lminus_rtl.png\');\nbackground-repeat:no-repeat;\nbackground-position:center center;\ncursor:default;\n/*border:1px solid red;*/\n}\n.tree-item-anchor-collapsed-rtl {\ndisplay:inline;\nwidth:20px;\noverflow:hidden;\npadding-left:20px;\nheight:20px;\nbackground-image:url(\'images/Lplus_rtl.png\');\nbackground-repeat:no-repeat;\nbackground-position:center center;\ncursor:default;\n/*border:1px solid red;*/\n}");
c$=$_C(function(){
this.items=null;
this.columns=null;
this.itemHandles=null;
this.columnHandles=null;
this.imageList=null;
this.dragStarted=false;
this.gestureCompleted=false;
this.insertAfter=false;
this.ignoreSelect=false;
this.ignoreExpand=false;
this.ignoreDeselect=false;
this.ignoreResize=false;
this.lockSelection=false;
this.oldSelected=false;
this.newSelected=false;
this.linesVisible=false;
this.customDraw=false;
this.printClient=false;
this.selections=null;
this.lastSelection=null;
this.hwndParent=null;
this.hwndHeader=null;
this.hAnchor=null;
this.hInsert=null;
$_Z(this,arguments);
},$wt.widgets,"Tree",$wt.widgets.Composite);
c$.checkStyle=$_M(c$,"checkStyle",
function(style){
style|=768;
return $wt.widgets.Widget.checkBits(style,4,2,0,0,0,0);
},"~N");
$_M(c$,"addSelectionListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(13,typedListener);
this.addListener(14,typedListener);
},"$wt.events.SelectionListener");
$_M(c$,"addTreeListener",
function(listener){
var typedListener=new $wt.widgets.TypedListener(listener);
this.addListener(17,typedListener);
this.addListener(18,typedListener);
},"$wt.events.TreeListener");
$_M(c$,"computeSize",
function(wHint,hHint,changed){
var width=0;
var height=0;
if(width==0)width=64;
if(height==0)height=64;
if(wHint!=-1)width=wHint;
if(hHint!=-1)height=hHint;
var border=this.getBorderWidth();
width+=border*2;
height+=border*2;
if((this.style&512)!=0){
}if((this.style&256)!=0){
}return new $wt.graphics.Point(width,height);
},"~N,~N,~B");
$_M(c$,"createHandle",
function(){
this.selections=new Array(0);
this.items=new Array(0);
$_U(this,$wt.widgets.Tree,"createHandle",[]);
this.state&=-3;
this.handle.className+=" tree-default";
if((this.style&2048)!=0){
this.handle.className+=" tree-border";
}var table=d$.createElement("TABLE");
table.style.backgroundColor="white";
this.handle.appendChild(table);
});
$_M(c$,"createItem",
function(column,index){
},"$wt.widgets.TreeColumn,~N");
$_M(c$,"createItem",
function(item,hParent,index){
if(this.items==null){
this.items=new Array(0);
}var count=0;
for(var i=0;i<this.items.length;i++){
if(this.items[i]!=null&&this.items[i].handle==null){
this.items[i]=null;
count++;
}}
if(count==this.items.length){
this.items=new Array(0);
}var table=this.handle.childNodes[0];
var tbody=null;
for(var i=0;i<table.childNodes.length;i++){
if("TBODY".equals(table.childNodes[i].nodeName)){
tbody=table.childNodes[i];
break;
}}
if(tbody==null){
tbody=d$.createElement("TBODY");
table.appendChild(tbody);
}var idx=-1;
if(hParent!=null){
for(var i=0;i<tbody.childNodes.length;i++){
if(tbody.childNodes[i]==hParent){
idx=i;
break;
}}
}var newTR=d$.createElement("TR");
item.handle=newTR;
var existedIndex=-1;
if(index>=0){
existedIndex=this.findItem(idx,index);
if(existedIndex!=-1){
tbody.insertBefore(newTR,tbody.childNodes[existedIndex]);
for(var i=this.items.length;i>existedIndex;i--){
this.items[i]=this.items[i-1];
this.items[i].index=i;
}
item.index=existedIndex;
this.items[existedIndex]=item;
}}if(existedIndex==-1){
if(idx<0){
tbody.appendChild(newTR);
item.index=this.items.length;
this.items[this.items.length]=item;
}else{
var siblingIndex=this.findNextSiblingItem(idx);
if(siblingIndex==-1){
tbody.appendChild(newTR);
item.index=this.items.length;
this.items[this.items.length]=item;
}else{
tbody.insertBefore(newTR,tbody.childNodes[siblingIndex]);
for(var i=this.items.length;i>siblingIndex;i--){
this.items[i]=this.items[i-1];
this.items[i].index=i;
}
item.index=siblingIndex;
this.items[siblingIndex]=item;
}}}if(item.parentItem!=null){
item.parentItem.addItem(item,index);
item.parentItem.setExpanded(false);
}item.checkOrientation(this);
item._updateOrientation();
},"$wt.widgets.TreeItem,~O,~N");
$_M(c$,"toggleSelection",
function(item,isCtrlKeyHold,isShiftKeyHold){
if(item==null){
return false;
}if((this.style&2)!=0&&(isCtrlKeyHold||isShiftKeyHold)){
if(isCtrlKeyHold){
for(var i=0;i<this.selections.length;i++){
if(item==this.selections[i]){
var newSelections=new Array(this.selections.length);
for(var j=0;j<i;j++){
newSelections[j]=this.selections[j];
}
for(var j=i;j<this.selections.length-1;j++){
newSelections[j]=this.selections[j+1];
}
this.selections=newSelections;
item.showSelection(false);
this.lastSelection=item;
return false;
}}
this.selections[this.selections.length]=item;
this.lastSelection=item;
item.showSelection(true);
}else{
for(var i=0;i<this.selections.length;i++){
if(this.selections[i]!=null){
this.selections[i].showSelection(false);
}}
if(this.lastSelection!=null){
var idx1=Math.min(this.lastSelection.index,item.index);
var idx2=Math.max(this.lastSelection.index,item.index);
this.selections=new Array(0);
for(var i=idx1;i<=idx2;i++){
var ti=this.items[i];
if(ti.handle.style.display!="none"){
this.selections[this.selections.length]=ti;
ti.showSelection(true);
}}
return true;
}else{
if(this.selections.length!=1){
this.selections=new Array(1);
}this.selections[0]=item;
}}}else{
item.showSelection(true);
for(var i=0;i<this.selections.length;i++){
if(this.selections[i]!=null&&this.selections[i]!=item){
this.selections[i].showSelection(false);
}}
if(this.selections.length!=1){
this.selections=new Array(1);
}this.selections[0]=item;
}this.lastSelection=item;
return true;
},"$wt.widgets.TreeItem,~B,~B");
$_M(c$,"skipItems",
function(index){
var parentItem=this.items[index];
index++;
while(this.items[index]!=null){
var item=this.items[index];
if(item.parentItem!=parentItem){
if(item.parentItem==this.items[index-1]){
index=this.skipItems(index-1);
if(index==-1){
return-1;
}var ti=this.items[index];
var outOfHierarchies=true;
while(ti!=null){
ti=ti.parentItem;
if(ti==parentItem){
outOfHierarchies=false;
break;
}}
if(outOfHierarchies){
return index;
}}else{
return index;
}}index++;
}
return-1;
},"~N");
$_M(c$,"createParent",
function(){
this.forceResize();
this.register();
});
$_M(c$,"createWidget",
function(){
$_U(this,$wt.widgets.Tree,"createWidget",[]);
this.items=new Array(0);
this.columns=new Array(0);
});
$_M(c$,"deselectAll",
function(){
for(var i=0;i<this.selections.length;i++){
this.selections[i].showSelection(false);
}
});
$_M(c$,"destroyItem",
function(column){
},"$wt.widgets.TreeColumn");
$_M(c$,"destroyItem",
function(item){
var length=this.selections.length;
var index=-1;
for(var i=0;i<length;i++){
if(this.selections[i].equals(item)){
index=i;
break;
}}
if(index!=-1){
var oldSelection=this.selections;
this.selections=new Array(length-1);
System.arraycopy(oldSelection,0,this.selections,0,index);
System.arraycopy(oldSelection,index+1,this.selections,index,length-index-1);
}var found=false;
length=this.items.length;
for(var i=0;i<length;i++){
if(found){
this.items[i-1]=this.items[i];
}if(this.items[i].equals(item)){
found=true;
}}
{
this.items.length=length-1;
}this.updateScrollBar();
},"$wt.widgets.TreeItem");
$_M(c$,"findItem",
function(id){
return null;
},"~N");
$_M(c$,"getGridLineWidth",
function(){
return 1;
});
$_M(c$,"getHeaderHeight",
function(){
return 16;
});
$_M(c$,"getHeaderVisible",
function(){
return false;
});
$_M(c$,"getImageSize",
function(){
if(this.imageList!=null)return this.imageList.getImageSize();
return new $wt.graphics.Point(0,this.getItemHeight());
});
$_M(c$,"getColumn",
function(index){
return this.columns[index];
},"~N");
$_M(c$,"getColumnCount",
function(){
return this.columns.length;
});
$_M(c$,"getColumns",
function(){
return this.columns;
});
$_M(c$,"getDescendantItems",
function(index){
var nextSiblingIdx=this.findNextSiblingItem(index);
if(nextSiblingIdx==-1){
nextSiblingIdx=this.items.length;
}var children=new Array(nextSiblingIdx-index-1);
for(var i=index+1;i<nextSiblingIdx;i++){
children[i-index-1]=this.items[i];
}
return children;
},"~N");
$_M(c$,"findItem",
function(parentIndex,index){
if(parentIndex<0){
for(var i=0;i<this.items.length;i++){
if(this.items[i].parentItem==null){
if(index==0){
return i;
}index--;
}}
return-1;
}var parentItem=this.items[parentIndex];
parentIndex++;
while(this.items[parentIndex]!=null){
var item=this.items[parentIndex];
if(item.parentItem!=parentItem){
if(item.parentItem==this.items[parentIndex-1]){
parentIndex=this.skipItems(parentIndex-1);
if(parentIndex==-1){
return-1;
}}else{
return-1;
}}else{
if(index==0){
return parentIndex;
}index--;
}parentIndex++;
}
return-1;
},"~N,~N");
$_M(c$,"findNextSiblingItem",
function(parentIndex){
if(parentIndex<0){
parentIndex=0;
}var parentItem=this.items[parentIndex];
parentIndex++;
if(this.items[parentIndex]!=null){
var item=this.items[parentIndex];
if(item.parentItem!=parentItem.parentItem){
if(item.parentItem==this.items[parentIndex-1]){
parentIndex=this.skipItems(parentIndex-1);
if(parentIndex==-1){
return-1;
}var ti=this.items[parentIndex];
var outOfHierarchies=true;
while(ti!=null){
ti=ti.parentItem;
if(ti==parentItem){
outOfHierarchies=false;
break;
}}
if(outOfHierarchies){
return parentIndex;
}}else{
return parentIndex;
}}else{
return parentIndex;
}}return-1;
},"~N");
$_M(c$,"indexOf",
function(parentIndex,ti){
var index=0;
if(parentIndex<0){
if(ti.parentItem!=null){
return-1;
}for(var i=0;i<this.items.length;i++){
if(this.items[i]==ti){
return index;
}else if(this.items[i].parentItem==null){
index++;
}}
return-1;
}var parentItem=this.items[parentIndex];
parentIndex++;
while(this.items[parentIndex]!=null){
var item=this.items[parentIndex];
if(item.parentItem!=parentItem){
if(item.parentItem==this.items[parentIndex-1]){
parentIndex=this.skipItems(parentIndex-1);
if(parentIndex==-1){
return-1;
}if(this.items[parentIndex].parentItem==parentItem.parentItem){
return-1;
}else{
if(this.items[parentIndex]==ti){
return index;
}index++;
}}else{
return-1;
}}else{
if(item==ti){
return index;
}index++;
}parentIndex++;
}
return-1;
},"~N,$wt.widgets.TreeItem");
$_M(c$,"getItem",
function(index){
return this.getItems()[index];
},"~N");
$_M(c$,"getItem",
function(point){
return null;
},"$wt.graphics.Point");
$_M(c$,"getItemCount",
function(){
return this.getItems().length;
});
$_M(c$,"getItemCount",
function(hItem){
var count=0;
return this.items.length;
},"~N");
$_M(c$,"getItemHeight",
function(){
return 16;
});
$_M(c$,"getItems",
function(){
var copiedItems=new Array(0);
for(var i=0;i<this.items.length;i++){
if(this.items[i]!=null&&this.items[i].parentItem==null){
copiedItems[copiedItems.length]=this.items[i];
}}
return copiedItems;
});
$_M(c$,"getItems",
function(hTreeItem){
var children=new Array(0);
if(hTreeItem<0){
hTreeItem=0;
}var parentItem=this.items[hTreeItem];
hTreeItem++;
while(this.items[hTreeItem]!=null){
var item=this.items[hTreeItem];
if(item.parentItem!=parentItem){
if(item.parentItem==this.items[hTreeItem-1]){
hTreeItem=this.skipItems(hTreeItem-1);
if(hTreeItem==-1){
return children;
}if(this.items[hTreeItem].parentItem==parentItem.parentItem){
return children;
}else{
children[children.length]=this.items[hTreeItem];
}}else{
return children;
}}else{
children[children.length]=item;
}hTreeItem++;
}
return children;
},"~N");
$_M(c$,"getLinesVisible",
function(){
return this.linesVisible;
});
$_M(c$,"getParentItem",
function(){
return null;
});
$_M(c$,"getSelection",
function(){
return this.selections;
});
$_M(c$,"getSelectionCount",
function(){
return this.selections.length;
});
$_M(c$,"getTopItem",
function(){
return this.items[0];
});
$_M(c$,"indexOf",
function(column){
var count=this.columns.length;
for(var i=0;i<count;i++){
if(this.columns[i]==column)return i;
}
return-1;
},"$wt.widgets.TreeColumn");
$_M(c$,"indexOf",
function(item){
for(var i=0;i<this.items.length;i++){
if(this.items[i]==item){
return i;
}}
return-1;
},"$wt.widgets.TreeItem");
$_M(c$,"releaseWidget",
function(){
var columnCount=this.columns.length;
for(var i=0;i<this.items.length;i++){
var item=this.items[i];
if(item!=null&&!item.isDisposed()){
item.releaseResources();
}}
this.items=null;
for(var i=0;i<columnCount;i++){
var column=this.columns[i];
if(!column.isDisposed())column.releaseResources();
}
this.columns=null;
$_U(this,$wt.widgets.Tree,"releaseWidget",[]);
});
$_M(c$,"removeAll",
function(){
this.ignoreDeselect=this.ignoreSelect=true;
var items=this.getItems();
var length=items.length;
for(var i=0;i<length;i++){
items[i].dispose();
}
this.items=new Array(0);
this.updateScrollBar();
});
$_M(c$,"removeSelectionListener",
function(listener){
this.eventTable.unhook(13,listener);
this.eventTable.unhook(14,listener);
},"$wt.events.SelectionListener");
$_M(c$,"removeTreeListener",
function(listener){
if(this.eventTable==null)return;
this.eventTable.unhook(17,listener);
this.eventTable.unhook(18,listener);
},"$wt.events.TreeListener");
$_M(c$,"setInsertMark",
function(item,before){
},"$wt.widgets.TreeItem,~B");
$_M(c$,"setLinesVisible",
function(show){
if(this.linesVisible==show)return;
this.linesVisible=show;
},"~B");
$_M(c$,"selectAll",
function(){
if((this.style&4)!=0)return;
});
$_M(c$,"setCheckboxImageList",
function(){
if((this.style&32)==0)return;
var count=5;
});
$_M(c$,"setHeaderVisible",
function(show){
this.setScrollWidth();
this.updateScrollBar();
},"~B");
$_V(c$,"setRedraw",
function(redraw){
},"~B");
$_M(c$,"setScrollWidth",
function(){
});
$_M(c$,"setSelection",
function(items){
var length=items.length;
if(length==0||((this.style&4)!=0&&length>1)){
this.deselectAll();
return;
}this.selections=items;
for(var i=0;i<items.length;i++){
items[i].showSelection(true);
}
},"~A");
$_M(c$,"setTopItem",
function(item){
this.updateScrollBar();
},"$wt.widgets.TreeItem");
$_M(c$,"showItem",
function(hItem){
this.updateScrollBar();
},"$wt.internal.xhtml.Element");
$_M(c$,"showColumn",
function(column){
if(column.parent!=this)return;
var index=this.indexOf(column);
if(index==-1)return;
},"$wt.widgets.TreeColumn");
$_M(c$,"showItem",
function(item){
this.showItem(item.handle);
},"$wt.widgets.TreeItem");
$_M(c$,"showSelection",
function(){
});
$_V(c$,"topHandle",
function(){
return this.hwndParent!=null?this.hwndParent:this.handle;
});
$_M(c$,"updateScrollBar",
function(){
});
$_S(c$,
"INSET",3,
"GRID_WIDTH",1,
"HEADER_MARGIN",10);
});
