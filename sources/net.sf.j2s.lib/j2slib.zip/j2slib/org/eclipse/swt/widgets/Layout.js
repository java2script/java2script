c$=$_T($wt.widgets,"Layout");
$_M(c$,"flushCache",
function(control){
return false;
},"$wt.widgets.Control");
