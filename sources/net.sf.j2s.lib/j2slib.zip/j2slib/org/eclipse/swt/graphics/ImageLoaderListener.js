﻿$_L(["$wt.internal.SWTEventListener"],"$wt.graphics.ImageLoaderListener",null,function(){
$_I($wt.graphics,"ImageLoaderListener",$wt.internal.SWTEventListener);
});
