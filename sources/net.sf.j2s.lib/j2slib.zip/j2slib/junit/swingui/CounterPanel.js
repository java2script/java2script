Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.JPanel", "junit.swingui.TestRunner"], "junit.swingui.CounterPanel", ["java.awt.GridBagConstraints", "$.GridBagLayout", "$.Insets", "javax.swing.BorderFactory", "$.JLabel", "$.JTextField"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fNumberOfErrors = null;
this.fNumberOfFailures = null;
this.fNumberOfRuns = null;
this.fFailureIcon = null;
this.fErrorIcon = null;
this.fTotal = 0;
Clazz.instantialize (this, arguments);
}, junit.swingui, "CounterPanel", javax.swing.JPanel);
Clazz.prepareFields (c$, function () {
this.fFailureIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/failure.gif");
this.fErrorIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/error.gif");
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.CounterPanel, [ new java.awt.GridBagLayout ()]);
this.fNumberOfErrors = this.createOutputField (5);
this.fNumberOfFailures = this.createOutputField (5);
this.fNumberOfRuns = this.createOutputField (9);
this.addToGrid ( new javax.swing.JLabel ("Runs:", 0), 0, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 0, 0, 0));
this.addToGrid (this.fNumberOfRuns, 1, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 0));
this.addToGrid ( new javax.swing.JLabel ("Errors:", this.fErrorIcon, 2), 2, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 8, 0, 0));
this.addToGrid (this.fNumberOfErrors, 3, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 0));
this.addToGrid ( new javax.swing.JLabel ("Failures:", this.fFailureIcon, 2), 4, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 8, 0, 0));
this.addToGrid (this.fNumberOfFailures, 5, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 0));
});
Clazz.defineMethod (c$, "createOutputField", 
($fz = function (width) {
var field =  new javax.swing.JTextField ("0", width);
field.setMinimumSize (field.getPreferredSize ());
field.setMaximumSize (field.getPreferredSize ());
field.setHorizontalAlignment (2);
field.setFont (junit.swingui.StatusLine.BOLD_FONT);
field.setEditable (false);
field.setBorder (javax.swing.BorderFactory.createEmptyBorder ());
return field;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "addToGrid", 
function (comp, gridx, gridy, gridwidth, gridheight, weightx, weighty, anchor, fill, insets) {
var constraints =  new java.awt.GridBagConstraints ();
constraints.gridx = gridx;
constraints.gridy = gridy;
constraints.gridwidth = gridwidth;
constraints.gridheight = gridheight;
constraints.weightx = weightx;
constraints.weighty = weighty;
constraints.anchor = anchor;
constraints.fill = fill;
constraints.insets = insets;
this.add (comp, constraints);
}, "java.awt.Component,~N,~N,~N,~N,~N,~N,~N,~N,java.awt.Insets");
Clazz.defineMethod (c$, "reset", 
function () {
this.setLabelValue (this.fNumberOfErrors, 0);
this.setLabelValue (this.fNumberOfFailures, 0);
this.setLabelValue (this.fNumberOfRuns, 0);
this.fTotal = 0;
});
Clazz.defineMethod (c$, "setTotal", 
function (value) {
this.fTotal = value;
}, "~N");
Clazz.defineMethod (c$, "setRunValue", 
function (value) {
this.fNumberOfRuns.setText (Integer.toString (value) + "/" + this.fTotal);
}, "~N");
Clazz.defineMethod (c$, "setErrorValue", 
function (value) {
this.setLabelValue (this.fNumberOfErrors, value);
}, "~N");
Clazz.defineMethod (c$, "setFailureValue", 
function (value) {
this.setLabelValue (this.fNumberOfFailures, value);
}, "~N");
Clazz.defineMethod (c$, "setLabelValue", 
($fz = function (label, value) {
label.setText (Integer.toString (value));
}, $fz.isPrivate = true, $fz), "javax.swing.JTextField,~N");
});
