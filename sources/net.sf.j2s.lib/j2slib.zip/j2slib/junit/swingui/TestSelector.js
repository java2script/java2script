﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (["java.awt.event.KeyAdapter", "$.MouseAdapter", "javax.swing.DefaultListCellRenderer", "$.JDialog", "junit.runner.Sorter"], "junit.swingui.TestSelector", ["java.awt.Cursor", "$.GridBagConstraints", "$.GridBagLayout", "$.Insets", "$.Toolkit", "java.awt.event.ActionListener", "$.WindowAdapter", "java.lang.Character", "java.util.Vector", "javax.swing.JButton", "$.JLabel", "$.JList", "$.JScrollPane", "$.UIManager", "javax.swing.event.ListSelectionListener"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fCancel = null;
this.fOk = null;
this.fList = null;
this.fScrolledList = null;
this.fDescription = null;
this.fSelectedItem = null;
if (!Clazz.isClassDefined ("junit.swingui.TestSelector.DoubleClickListener")) {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, junit.swingui.TestSelector, "DoubleClickListener", java.awt.event.MouseAdapter);
Clazz.overrideMethod (c$, "mouseClicked", 
function (a) {
if (a.getClickCount () == 2) {
this.b$["junit.swingui.TestSelector"].okSelected ();
}}, "java.awt.event.MouseEvent");
c$ = Clazz.p0p ();
}
if (!Clazz.isClassDefined ("junit.swingui.TestSelector.KeySelectListener")) {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, junit.swingui.TestSelector, "KeySelectListener", java.awt.event.KeyAdapter);
Clazz.overrideMethod (c$, "keyTyped", 
function (a) {
this.b$["junit.swingui.TestSelector"].keySelectTestClass (a.getKeyChar ());
}, "java.awt.event.KeyEvent");
c$ = Clazz.p0p ();
}
if (!Clazz.isClassDefined ("junit.swingui.TestSelector.ParallelSwapper")) {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.fOther = null;
Clazz.instantialize (this, arguments);
}, junit.swingui.TestSelector, "ParallelSwapper", null, junit.runner.Sorter.Swapper);
Clazz.makeConstructor (c$, 
function (a) {
this.fOther = a;
}, "java.util.Vector");
Clazz.overrideMethod (c$, "swap", 
function (a, b, c) {
var d = a.elementAt (b);
a.setElementAt (a.elementAt (c), b);
a.setElementAt (d, c);
var e = this.fOther.elementAt (b);
this.fOther.setElementAt (this.fOther.elementAt (c), b);
this.fOther.setElementAt (e, c);
}, "java.util.Vector,~N,~N");
c$ = Clazz.p0p ();
}
Clazz.instantialize (this, arguments);
}, junit.swingui, "TestSelector", javax.swing.JDialog);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fLeafIcon = null;
this.fSuiteIcon = null;
Clazz.instantialize (this, arguments);
}, junit.swingui.TestSelector, "TestCellRenderer", javax.swing.DefaultListCellRenderer);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.TestSelector.TestCellRenderer, []);
this.fLeafIcon = javax.swing.UIManager.getIcon ("Tree.leafIcon");
this.fSuiteIcon = javax.swing.UIManager.getIcon ("Tree.closedIcon");
});
Clazz.defineMethod (c$, "getListCellRendererComponent", 
function (a, b, c, d, e) {
var f = Clazz.superCall (this, junit.swingui.TestSelector.TestCellRenderer, "getListCellRendererComponent", [a, b, c, d, e]);
var g = junit.swingui.TestSelector.TestCellRenderer.displayString (b);
if (g.startsWith ("AllTests")) this.setIcon (this.fSuiteIcon);
 else this.setIcon (this.fLeafIcon);
this.setText (g);
return f;
}, "javax.swing.JList,~O,~N,~B,~B");
c$.displayString = Clazz.defineMethod (c$, "displayString", 
function (a) {
var b = a.lastIndexOf ('.');
if (b < 0) return a;
return a.substring (b + 1) + " - " + a.substring (0, b);
}, "~S");
c$.matchesKey = Clazz.defineMethod (c$, "matchesKey", 
function (a, b) {
return (b).charCodeAt (0) == (Character.toUpperCase (a.charAt (junit.swingui.TestSelector.TestCellRenderer.typeIndex (a)))).charCodeAt (0);
}, "~S,~N");
c$.typeIndex = Clazz.defineMethod (c$, "typeIndex", 
($fz = function (a) {
var b = a.lastIndexOf ('.');
var c = 0;
if (b > 0) c = b + 1;
return c;
}, $fz.isPrivate = true, $fz), "~S");
c$ = Clazz.p0p ();
Clazz.makeConstructor (c$, 
function (parent, testCollector) {
Clazz.superConstructor (this, junit.swingui.TestSelector, [parent, true]);
this.setSize (350, 300);
this.setResizable (false);
try {
this.setLocationRelativeTo (parent);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodError)) {
junit.swingui.TestSelector.centerWindow (this);
} else {
throw e;
}
}
this.setTitle ("Test Selector");
var list = null;
try {
parent.setCursor (java.awt.Cursor.getPredefinedCursor (3));
list = this.createTestList (testCollector);
} finally {
parent.setCursor (java.awt.Cursor.getDefaultCursor ());
}
this.fList =  new javax.swing.JList (list);
this.fList.setSelectionMode (0);
this.fList.setCellRenderer ( new junit.swingui.TestSelector.TestCellRenderer ());
this.fScrolledList =  new javax.swing.JScrollPane (this.fList);
this.fCancel =  new javax.swing.JButton ("Cancel");
this.fDescription =  new javax.swing.JLabel ("Select the Test class:");
this.fOk =  new javax.swing.JButton ("OK");
this.fOk.setEnabled (false);
this.getRootPane ().setDefaultButton (this.fOk);
this.defineLayout ();
this.addListeners ();
}, "java.awt.Frame,junit.runner.TestCollector");
c$.centerWindow = Clazz.defineMethod (c$, "centerWindow", 
function (c) {
var paneSize = c.getSize ();
var screenSize = c.getToolkit ().getScreenSize ();
c.setLocation (Math.floor ((screenSize.width - paneSize.width) / 2), Math.floor ((screenSize.height - paneSize.height) / 2));
}, "java.awt.Component");
Clazz.defineMethod (c$, "addListeners", 
($fz = function () {
this.fCancel.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestSelector$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestSelector$1", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestSelector"].dispose ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestSelector$1, i$, v$);
}) (this, null));
this.fOk.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestSelector$2")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestSelector$2", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestSelector"].okSelected ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestSelector$2, i$, v$);
}) (this, null));
this.fList.addMouseListener (Clazz.innerTypeInstance (junit.swingui.TestSelector.DoubleClickListener, this, null));
this.fList.addKeyListener (Clazz.innerTypeInstance (junit.swingui.TestSelector.KeySelectListener, this, null));
this.fList.addListSelectionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestSelector$3")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestSelector$3", null, javax.swing.event.ListSelectionListener);
Clazz.overrideMethod (c$, "valueChanged", 
function (e) {
this.b$["junit.swingui.TestSelector"].checkEnableOK (e);
}, "javax.swing.event.ListSelectionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestSelector$3, i$, v$);
}) (this, null));
this.addWindowListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestSelector$4")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestSelector$4", java.awt.event.WindowAdapter);
Clazz.overrideMethod (c$, "windowClosing", 
function (e) {
this.b$["junit.swingui.TestSelector"].dispose ();
}, "java.awt.event.WindowEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestSelector$4, i$, v$);
}) (this, null));
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "defineLayout", 
($fz = function () {
this.getContentPane ().setLayout ( new java.awt.GridBagLayout ());
var labelConstraints =  new java.awt.GridBagConstraints ();
labelConstraints.gridx = 0;
labelConstraints.gridy = 0;
labelConstraints.gridwidth = 1;
labelConstraints.gridheight = 1;
labelConstraints.fill = 1;
labelConstraints.anchor = 17;
labelConstraints.weightx = 1.0;
labelConstraints.weighty = 0.0;
labelConstraints.insets =  new java.awt.Insets (8, 8, 0, 8);
this.getContentPane ().add (this.fDescription, labelConstraints);
var listConstraints =  new java.awt.GridBagConstraints ();
listConstraints.gridx = 0;
listConstraints.gridy = 1;
listConstraints.gridwidth = 4;
listConstraints.gridheight = 1;
listConstraints.fill = 1;
listConstraints.anchor = 10;
listConstraints.weightx = 1.0;
listConstraints.weighty = 1.0;
listConstraints.insets =  new java.awt.Insets (8, 8, 8, 8);
this.getContentPane ().add (this.fScrolledList, listConstraints);
var okConstraints =  new java.awt.GridBagConstraints ();
okConstraints.gridx = 2;
okConstraints.gridy = 2;
okConstraints.gridwidth = 1;
okConstraints.gridheight = 1;
okConstraints.anchor = 13;
okConstraints.insets =  new java.awt.Insets (0, 8, 8, 8);
this.getContentPane ().add (this.fOk, okConstraints);
var cancelConstraints =  new java.awt.GridBagConstraints ();
cancelConstraints.gridx = 3;
cancelConstraints.gridy = 2;
cancelConstraints.gridwidth = 1;
cancelConstraints.gridheight = 1;
cancelConstraints.anchor = 13;
cancelConstraints.insets =  new java.awt.Insets (0, 8, 8, 8);
this.getContentPane ().add (this.fCancel, cancelConstraints);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "checkEnableOK", 
function (e) {
this.fOk.setEnabled (this.fList.getSelectedIndex () != -1);
}, "javax.swing.event.ListSelectionEvent");
Clazz.defineMethod (c$, "okSelected", 
function () {
this.fSelectedItem = this.fList.getSelectedValue ();
this.dispose ();
});
Clazz.defineMethod (c$, "isEmpty", 
function () {
return this.fList.getModel ().getSize () == 0;
});
Clazz.defineMethod (c$, "keySelectTestClass", 
function (ch) {
var model = this.fList.getModel ();
if (!Character.isJavaIdentifierStart (ch)) return ;
for (var i = 0; i < model.getSize (); i++) {
var s = model.getElementAt (i);
if (junit.swingui.TestSelector.TestCellRenderer.matchesKey (s, Character.toUpperCase (ch))) {
this.fList.setSelectedIndex (i);
this.fList.ensureIndexIsVisible (i);
return ;
}}
java.awt.Toolkit.getDefaultToolkit ().beep ();
}, "~N");
Clazz.defineMethod (c$, "getSelectedItem", 
function () {
return this.fSelectedItem;
});
Clazz.defineMethod (c$, "createTestList", 
($fz = function (collector) {
var each = collector.collectTests ();
var v =  new java.util.Vector (200);
var displayVector =  new java.util.Vector (v.size ());
while (each.hasMoreElements ()) {
var s = each.nextElement ();
v.addElement (s);
displayVector.addElement (junit.swingui.TestSelector.TestCellRenderer.displayString (s));
}
if (v.size () > 0) junit.runner.Sorter.sortStrings (displayVector, 0, displayVector.size () - 1, Clazz.innerTypeInstance (junit.swingui.TestSelector.ParallelSwapper, this, null, v));
return v;
}, $fz.isPrivate = true, $fz), "junit.runner.TestCollector");
});
