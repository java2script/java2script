Clazz.declarePackage ("junit.swingui");
Clazz.load (["junit.runner.BaseTestRunner", "junit.swingui.TestRunContext", "java.util.Vector"], "junit.swingui.TestRunner", ["java.awt.BorderLayout", "$.GridBagConstraints", "$.GridBagLayout", "$.GridLayout", "$.Insets", "java.awt.event.ActionListener", "$.ItemListener", "$.KeyAdapter", "$.WindowAdapter", "java.io.BufferedReader", "$.BufferedWriter", "$.File", "$.FileReader", "$.FileWriter", "java.lang.Runnable", "$.Thread", "javax.swing.DefaultListModel", "$.ImageIcon", "$.JButton", "$.JCheckBox", "$.JComboBox", "$.JFrame", "$.JLabel", "$.JMenu", "$.JMenuBar", "$.JMenuItem", "$.JOptionPane", "$.JPanel", "$.JScrollPane", "$.JSeparator", "$.JSplitPane", "$.JTabbedPane", "$.SwingUtilities", "javax.swing.event.ChangeListener", "junit.framework.TestFailure", "$.TestResult", "$.TestSuite", "junit.runner.SimpleTestCollector", "$.Version", "junit.swingui.AboutDialog", "$.CounterPanel", "$.DefaultFailureDetailView", "$.FailureRunView", "$.ProgressBar", "$.StatusLine", "$.TestHierarchyRunView", "$.TestSelector"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fFrame = null;
this.fRunner = null;
this.fTestResult = null;
this.fSuiteCombo = null;
this.fProgressIndicator = null;
this.fFailures = null;
this.fLogo = null;
this.fCounterPanel = null;
this.fRun = null;
this.fQuitButton = null;
this.fRerunButton = null;
this.fStatusLine = null;
this.fFailureView = null;
this.fTestViewTab = null;
this.fUseLoadingRunner = null;
this.fTestRunViews = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "TestRunner", junit.runner.BaseTestRunner, junit.swingui.TestRunContext);
Clazz.prepareFields (c$, function () {
this.fTestRunViews =  new java.util.Vector ();
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.TestRunner, []);
});
c$.main = Clazz.defineMethod (c$, "main", 
function (args) {
 new junit.swingui.TestRunner ().start (args);
}, "~A");
c$.run = Clazz.defineMethod (c$, "run", 
function (test) {
var args = [test.getName ()];
junit.swingui.TestRunner.main (args);
}, "Class");
Clazz.overrideMethod (c$, "testFailed", 
function (status, test, t) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
switch (this.f$.status) {
case 1:
this.b$["junit.swingui.TestRunner"].fCounterPanel.setErrorValue (this.b$["junit.swingui.TestRunner"].fTestResult.errorCount ());
this.b$["junit.swingui.TestRunner"].appendFailure (this.f$.test, this.f$.t);
break;
case 2:
this.b$["junit.swingui.TestRunner"].fCounterPanel.setFailureValue (this.b$["junit.swingui.TestRunner"].fTestResult.failureCount ());
this.b$["junit.swingui.TestRunner"].appendFailure (this.f$.test, this.f$.t);
break;
}
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$1, i$, v$);
}) (this, Clazz.cloneFinals ("status", status, "test", test, "t", t)));
}, "~N,junit.framework.Test,Throwable");
Clazz.overrideMethod (c$, "testStarted", 
function (testName) {
this.postInfo ("Running: " + testName);
}, "~S");
Clazz.overrideMethod (c$, "testEnded", 
function (stringName) {
this.synchUI ();
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$2")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$2", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
if (this.b$["junit.swingui.TestRunner"].fTestResult != null) {
this.b$["junit.swingui.TestRunner"].fCounterPanel.setRunValue (this.b$["junit.swingui.TestRunner"].fTestResult.runCount ());
this.b$["junit.swingui.TestRunner"].fProgressIndicator.step (this.b$["junit.swingui.TestRunner"].fTestResult.runCount (), this.b$["junit.swingui.TestRunner"].fTestResult.wasSuccessful ());
}});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$2, i$, v$);
}) (this, null));
}, "~S");
Clazz.defineMethod (c$, "setSuite", 
function (suiteName) {
this.fSuiteCombo.getEditor ().setItem (suiteName);
}, "~S");
Clazz.defineMethod (c$, "addToHistory", 
($fz = function (suite) {
for (var i = 0; i < this.fSuiteCombo.getItemCount (); i++) {
if (suite.equals (this.fSuiteCombo.getItemAt (i))) {
this.fSuiteCombo.removeItemAt (i);
this.fSuiteCombo.insertItemAt (suite, 0);
this.fSuiteCombo.setSelectedIndex (0);
return ;
}}
this.fSuiteCombo.insertItemAt (suite, 0);
this.fSuiteCombo.setSelectedIndex (0);
this.pruneHistory ();
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "pruneHistory", 
($fz = function () {
var historyLength = junit.runner.BaseTestRunner.getPreference ("maxhistory", 5);
if (historyLength < 1) historyLength = 1;
for (var i = this.fSuiteCombo.getItemCount () - 1; i > historyLength - 1; i--) this.fSuiteCombo.removeItemAt (i);

}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "appendFailure", 
($fz = function (test, t) {
this.fFailures.addElement ( new junit.framework.TestFailure (test, t));
if (this.fFailures.size () == 1) this.revealFailure (test);
}, $fz.isPrivate = true, $fz), "junit.framework.Test,Throwable");
Clazz.defineMethod (c$, "revealFailure", 
($fz = function (test) {
for (var e = this.fTestRunViews.elements (); e.hasMoreElements (); ) {
var v = e.nextElement ();
v.revealFailure (test);
}
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "aboutToStart", 
function (testSuite) {
for (var e = this.fTestRunViews.elements (); e.hasMoreElements (); ) {
var v = e.nextElement ();
v.aboutToStart (testSuite, this.fTestResult);
}
}, "junit.framework.Test");
Clazz.defineMethod (c$, "runFinished", 
function (testSuite) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$3")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$3", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
for (var e = this.b$["junit.swingui.TestRunner"].fTestRunViews.elements (); e.hasMoreElements (); ) {
var v = e.nextElement ();
v.runFinished (this.f$.testSuite, this.b$["junit.swingui.TestRunner"].fTestResult);
}
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$3, i$, v$);
}) (this, Clazz.cloneFinals ("testSuite", testSuite)));
}, "junit.framework.Test");
Clazz.defineMethod (c$, "createCounterPanel", 
function () {
return  new junit.swingui.CounterPanel ();
});
Clazz.defineMethod (c$, "createFailedPanel", 
function () {
var failedPanel =  new javax.swing.JPanel ( new java.awt.GridLayout (0, 1, 0, 2));
this.fRerunButton =  new javax.swing.JButton ("Run");
this.fRerunButton.setEnabled (false);
this.fRerunButton.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$4")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$4", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestRunner"].rerun ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$4, i$, v$);
}) (this, null));
failedPanel.add (this.fRerunButton);
return failedPanel;
});
Clazz.defineMethod (c$, "createFailureDetailView", 
function () {
var className = junit.runner.BaseTestRunner.getPreference (junit.swingui.TestRunner.FAILUREDETAILVIEW_KEY);
if (className != null) {
var viewClass = null;
try {
viewClass = Class.forName (className);
return viewClass.newInstance ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
javax.swing.JOptionPane.showMessageDialog (this.fFrame, "Could not create Failure DetailView - using default view");
} else {
throw e;
}
}
}return  new junit.swingui.DefaultFailureDetailView ();
});
Clazz.defineMethod (c$, "createJUnitMenu", 
function () {
var menu =  new javax.swing.JMenu ("JUnit");
menu.setMnemonic ('J');
var mi1 =  new javax.swing.JMenuItem ("About...");
mi1.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$5")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$5", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (event) {
this.b$["junit.swingui.TestRunner"].about ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$5, i$, v$);
}) (this, null));
mi1.setMnemonic ('A');
menu.add (mi1);
menu.addSeparator ();
var mi2 =  new javax.swing.JMenuItem (" Exit ");
mi2.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$6")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$6", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (event) {
this.b$["junit.swingui.TestRunner"].terminate ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$6, i$, v$);
}) (this, null));
mi2.setMnemonic ('x');
menu.add (mi2);
return menu;
});
Clazz.defineMethod (c$, "createFrame", 
function () {
var frame =  new javax.swing.JFrame ("JUnit");
var icon = this.loadFrameIcon ();
if (icon != null) frame.setIconImage (icon);
frame.getContentPane ().setLayout ( new java.awt.BorderLayout (0, 0));
frame.addWindowListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$7")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$7", java.awt.event.WindowAdapter);
Clazz.overrideMethod (c$, "windowClosing", 
function (e) {
this.b$["junit.swingui.TestRunner"].terminate ();
}, "java.awt.event.WindowEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$7, i$, v$);
}) (this, null));
return frame;
});
Clazz.defineMethod (c$, "createLogo", 
function () {
var label;
var icon = junit.swingui.TestRunner.getIconResource (junit.runner.BaseTestRunner, "logo.gif");
if (icon != null) label =  new javax.swing.JLabel (icon);
 else label =  new javax.swing.JLabel ("JV");
label.setToolTipText ("JUnit Version " + junit.runner.Version.id ());
return label;
});
Clazz.defineMethod (c$, "createMenus", 
function (mb) {
mb.add (this.createJUnitMenu ());
}, "javax.swing.JMenuBar");
Clazz.defineMethod (c$, "createUseLoaderCheckBox", 
function () {
var useLoader = this.useReloadingTestSuiteLoader ();
var box =  new javax.swing.JCheckBox ("Reload classes every run", useLoader);
box.setToolTipText ("Use a custom class loader to reload the classes for every run");
if (junit.runner.BaseTestRunner.inVAJava ()) box.setVisible (false);
return box;
});
Clazz.defineMethod (c$, "createQuitButton", 
function () {
var quit =  new javax.swing.JButton (" Exit ");
quit.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$8")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$8", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestRunner"].terminate ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$8, i$, v$);
}) (this, null));
return quit;
});
Clazz.defineMethod (c$, "createRunButton", 
function () {
var run =  new javax.swing.JButton ("Run");
run.setEnabled (true);
run.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$9")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$9", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestRunner"].runSuite ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$9, i$, v$);
}) (this, null));
return run;
});
Clazz.defineMethod (c$, "createBrowseButton", 
function () {
var browse =  new javax.swing.JButton ("...");
browse.setToolTipText ("Select a Test class");
browse.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$10")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$10", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.swingui.TestRunner"].browseTestClasses ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$10, i$, v$);
}) (this, null));
return browse;
});
Clazz.defineMethod (c$, "createStatusLine", 
function () {
return  new junit.swingui.StatusLine (380);
});
Clazz.defineMethod (c$, "createSuiteCombo", 
function () {
var combo =  new javax.swing.JComboBox ();
combo.setEditable (true);
combo.setLightWeightPopupEnabled (false);
combo.getEditor ().getEditorComponent ().addKeyListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$11")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$11", java.awt.event.KeyAdapter);
Clazz.overrideMethod (c$, "keyTyped", 
function (e) {
this.b$["junit.swingui.TestRunner"].textChanged ();
if ((e.getKeyChar ()).charCodeAt (0) == 10) this.b$["junit.swingui.TestRunner"].runSuite ();
}, "java.awt.event.KeyEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$11, i$, v$);
}) (this, null));
try {
this.loadHistory (combo);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
combo.addItemListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$12")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$12", null, java.awt.event.ItemListener);
Clazz.overrideMethod (c$, "itemStateChanged", 
function (event) {
if (event.getStateChange () == 1) {
this.b$["junit.swingui.TestRunner"].textChanged ();
}}, "java.awt.event.ItemEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$12, i$, v$);
}) (this, null));
return combo;
});
Clazz.defineMethod (c$, "createTestRunViews", 
function () {
var pane =  new javax.swing.JTabbedPane (3);
var lv =  new junit.swingui.FailureRunView (this);
this.fTestRunViews.addElement (lv);
lv.addTab (pane);
var tv =  new junit.swingui.TestHierarchyRunView (this);
this.fTestRunViews.addElement (tv);
tv.addTab (pane);
pane.addChangeListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$13")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$13", null, javax.swing.event.ChangeListener);
Clazz.overrideMethod (c$, "stateChanged", 
function (e) {
this.b$["junit.swingui.TestRunner"].testViewChanged ();
}, "javax.swing.event.ChangeEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$13, i$, v$);
}) (this, null));
return pane;
});
Clazz.defineMethod (c$, "testViewChanged", 
function () {
var view = this.fTestRunViews.elementAt (this.fTestViewTab.getSelectedIndex ());
view.activate ();
});
Clazz.defineMethod (c$, "createTestResult", 
function () {
return  new junit.framework.TestResult ();
});
Clazz.defineMethod (c$, "createUI", 
function (suiteName) {
var frame = this.createFrame ();
var mb =  new javax.swing.JMenuBar ();
this.createMenus (mb);
frame.setJMenuBar (mb);
var suiteLabel =  new javax.swing.JLabel ("Test class name:");
this.fSuiteCombo = this.createSuiteCombo ();
this.fRun = this.createRunButton ();
frame.getRootPane ().setDefaultButton (this.fRun);
var browseButton = this.createBrowseButton ();
this.fUseLoadingRunner = this.createUseLoaderCheckBox ();
this.fProgressIndicator =  new junit.swingui.ProgressBar ();
this.fCounterPanel = this.createCounterPanel ();
this.fFailures =  new javax.swing.DefaultListModel ();
this.fTestViewTab = this.createTestRunViews ();
var failedPanel = this.createFailedPanel ();
this.fFailureView = this.createFailureDetailView ();
var tracePane =  new javax.swing.JScrollPane (this.fFailureView.getComponent (), 22, 32);
this.fStatusLine = this.createStatusLine ();
this.fQuitButton = this.createQuitButton ();
this.fLogo = this.createLogo ();
var panel =  new javax.swing.JPanel ( new java.awt.GridBagLayout ());
this.addGrid (panel, suiteLabel, 0, 0, 2, 2, 1.0, 17);
this.addGrid (panel, this.fSuiteCombo, 0, 1, 1, 2, 1.0, 17);
this.addGrid (panel, browseButton, 1, 1, 1, 0, 0.0, 17);
this.addGrid (panel, this.fRun, 2, 1, 1, 2, 0.0, 10);
this.addGrid (panel, this.fUseLoadingRunner, 0, 2, 3, 0, 1.0, 17);
this.addGrid (panel, this.fProgressIndicator, 0, 3, 2, 2, 1.0, 17);
this.addGrid (panel, this.fLogo, 2, 3, 1, 0, 0.0, 11);
this.addGrid (panel, this.fCounterPanel, 0, 4, 2, 0, 0.0, 17);
this.addGrid (panel,  new javax.swing.JSeparator (), 0, 5, 2, 2, 1.0, 17);
this.addGrid (panel,  new javax.swing.JLabel ("Results:"), 0, 6, 2, 2, 1.0, 17);
var splitter =  new javax.swing.JSplitPane (0, this.fTestViewTab, tracePane);
this.addGrid (panel, splitter, 0, 7, 2, 1, 1.0, 17);
this.addGrid (panel, failedPanel, 2, 7, 1, 2, 0.0, 11);
this.addGrid (panel, this.fStatusLine, 0, 9, 2, 2, 1.0, 10);
this.addGrid (panel, this.fQuitButton, 2, 9, 1, 2, 0.0, 10);
frame.setContentPane (panel);
frame.pack ();
frame.setLocation (200, 200);
return frame;
}, "~S");
Clazz.defineMethod (c$, "addGrid", 
($fz = function (p, co, x, y, w, fill, wx, anchor) {
var c =  new java.awt.GridBagConstraints ();
c.gridx = x;
c.gridy = y;
c.gridwidth = w;
c.anchor = anchor;
c.weightx = wx;
c.fill = fill;
if (fill == 1 || fill == 3) c.weighty = 1.0;
c.insets =  new java.awt.Insets (y == 0 ? 10 : 0, x == 0 ? 10 : 4, 4, 4);
p.add (co, c);
}, $fz.isPrivate = true, $fz), "javax.swing.JPanel,java.awt.Component,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "getSuiteText", 
function () {
if (this.fSuiteCombo == null) return "";
return this.fSuiteCombo.getEditor ().getItem ();
});
Clazz.overrideMethod (c$, "getFailures", 
function () {
return this.fFailures;
});
Clazz.defineMethod (c$, "insertUpdate", 
function (event) {
this.textChanged ();
}, "javax.swing.event.DocumentEvent");
Clazz.defineMethod (c$, "browseTestClasses", 
function () {
var collector = this.createTestCollector ();
var selector =  new junit.swingui.TestSelector (this.fFrame, collector);
if (selector.isEmpty ()) {
javax.swing.JOptionPane.showMessageDialog (this.fFrame, "No Test Cases found.\nCheck that the configured \'TestCollector\' is supported on this platform.");
return ;
}selector.show ();
var className = selector.getSelectedItem ();
if (className != null) this.setSuite (className);
});
Clazz.defineMethod (c$, "createTestCollector", 
function () {
var className = junit.runner.BaseTestRunner.getPreference (junit.swingui.TestRunner.TESTCOLLECTOR_KEY);
if (className != null) {
var collectorClass = null;
try {
collectorClass = Class.forName (className);
return collectorClass.newInstance ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
javax.swing.JOptionPane.showMessageDialog (this.fFrame, "Could not create TestCollector - using default collector");
} else {
throw e;
}
}
}return  new junit.runner.SimpleTestCollector ();
});
Clazz.defineMethod (c$, "loadFrameIcon", 
($fz = function () {
var icon = junit.swingui.TestRunner.getIconResource (junit.runner.BaseTestRunner, "smalllogo.gif");
if (icon != null) return icon.getImage ();
return null;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "loadHistory", 
($fz = function (combo) {
var br =  new java.io.BufferedReader ( new java.io.FileReader (this.getSettingsFile ()));
var itemCount = 0;
try {
var line;
while ((line = br.readLine ()) != null) {
combo.addItem (line);
itemCount++;
}
if (itemCount > 0) combo.setSelectedIndex (0);
} finally {
br.close ();
}
}, $fz.isPrivate = true, $fz), "javax.swing.JComboBox");
Clazz.defineMethod (c$, "getSettingsFile", 
($fz = function () {
var home = System.getProperty ("user.home");
return  new java.io.File (home, ".junitsession");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "postInfo", 
($fz = function (message) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$14")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$14", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["junit.swingui.TestRunner"].showInfo (this.f$.message);
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$14, i$, v$);
}) (this, Clazz.cloneFinals ("message", message)));
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "postStatus", 
($fz = function (status) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$15")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$15", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["junit.swingui.TestRunner"].showStatus (this.f$.status);
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$15, i$, v$);
}) (this, Clazz.cloneFinals ("status", status)));
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "removeUpdate", 
function (event) {
this.textChanged ();
}, "javax.swing.event.DocumentEvent");
Clazz.defineMethod (c$, "rerun", 
($fz = function () {
var view = this.fTestRunViews.elementAt (this.fTestViewTab.getSelectedIndex ());
var rerunTest = view.getSelectedTest ();
if (rerunTest != null) this.rerunTest (rerunTest);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "rerunTest", 
($fz = function (test) {
if (!(Clazz.instanceOf (test, junit.framework.TestCase))) {
this.showInfo ("Could not reload " + test.toString ());
return ;
}var reloadedTest = null;
var rerunTest = test;
try {
var reloadedTestClass = this.getLoader ().reload (test.getClass ());
reloadedTest = junit.framework.TestSuite.createTest (reloadedTestClass, rerunTest.getName ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
this.showInfo ("Could not reload " + test.toString ());
return ;
} else {
throw e;
}
}
var result =  new junit.framework.TestResult ();
reloadedTest.run (result);
var message = reloadedTest.toString ();
if (result.wasSuccessful ()) this.showInfo (message + " was successful");
 else if (result.errorCount () == 1) this.showStatus (message + " had an error");
 else this.showStatus (message + " had a failure");
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "reset", 
function () {
this.fCounterPanel.reset ();
this.fProgressIndicator.reset ();
this.fRerunButton.setEnabled (false);
this.fFailureView.clear ();
this.fFailures.clear ();
});
Clazz.overrideMethod (c$, "runFailed", 
function (message) {
this.showStatus (message);
this.fRun.setText ("Run");
this.fRunner = null;
}, "~S");
Clazz.defineMethod (c$, "runSuite", 
function () {
if (this.fRunner != null) {
this.fTestResult.stop ();
} else {
this.setLoading (this.shouldReload ());
this.reset ();
this.showInfo ("Load Test Case...");
var suiteName = this.getSuiteText ();
var testSuite = this.getTest (suiteName);
if (testSuite != null) {
this.addToHistory (suiteName);
this.doRunTest (testSuite);
}}});
Clazz.defineMethod (c$, "shouldReload", 
($fz = function () {
return !junit.runner.BaseTestRunner.inVAJava () && this.fUseLoadingRunner.isSelected ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "runTest", 
function (testSuite) {
if (this.fRunner != null) {
this.fTestResult.stop ();
} else {
this.reset ();
if (testSuite != null) {
this.doRunTest (testSuite);
}}}, "junit.framework.Test");
Clazz.defineMethod (c$, "doRunTest", 
($fz = function (testSuite) {
this.setButtonLabel (this.fRun, "Stop");
this.fRunner = (function (i$, arg0, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$16")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$16", Thread);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["junit.swingui.TestRunner"].start (this.f$.testSuite);
this.b$["junit.swingui.TestRunner"].postInfo ("Running...");
var startTime = System.currentTimeMillis ();
this.f$.testSuite.run (this.b$["junit.swingui.TestRunner"].fTestResult);
if (this.b$["junit.swingui.TestRunner"].fTestResult.shouldStop ()) {
this.b$["junit.swingui.TestRunner"].postStatus ("Stopped");
} else {
var endTime = System.currentTimeMillis ();
var runTime = endTime - startTime;
this.b$["junit.swingui.TestRunner"].postInfo ("Finished: " + this.b$["junit.swingui.TestRunner"].elapsedTimeAsString (runTime) + " seconds");
}this.b$["junit.swingui.TestRunner"].runFinished (this.f$.testSuite);
this.b$["junit.swingui.TestRunner"].setButtonLabel (this.b$["junit.swingui.TestRunner"].fRun, "Run");
this.b$["junit.swingui.TestRunner"].fRunner = null;
System.gc ();
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$16, i$, v$, arg0);
}) (this, "TestRunner-Thread", Clazz.cloneFinals ("testSuite", testSuite));
this.fTestResult = this.createTestResult ();
this.fTestResult.addListener (this.b$["junit.swingui.TestRunner"]);
this.aboutToStart (testSuite);
this.fRunner.start ();
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "saveHistory", 
($fz = function () {
var bw =  new java.io.BufferedWriter ( new java.io.FileWriter (this.getSettingsFile ()));
try {
for (var i = 0; i < this.fSuiteCombo.getItemCount (); i++) {
var testsuite = this.fSuiteCombo.getItemAt (i).toString ();
bw.write (testsuite, 0, testsuite.length);
bw.newLine ();
}
} finally {
bw.close ();
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setButtonLabel", 
($fz = function (button, label) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$17")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$17", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.f$.button.setText (this.f$.label);
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$17, i$, v$);
}) (this, Clazz.cloneFinals ("button", button, "label", label)));
}, $fz.isPrivate = true, $fz), "javax.swing.JButton,~S");
Clazz.overrideMethod (c$, "handleTestSelected", 
function (test) {
this.fRerunButton.setEnabled (test != null && (Clazz.instanceOf (test, junit.framework.TestCase)));
this.showFailureDetail (test);
}, "junit.framework.Test");
Clazz.defineMethod (c$, "showFailureDetail", 
($fz = function (test) {
if (test != null) {
var failures = this.getFailures ();
for (var i = 0; i < failures.getSize (); i++) {
var failure = failures.getElementAt (i);
if (failure.failedTest () == test) {
this.fFailureView.showFailure (failure);
return ;
}}
}this.fFailureView.clear ();
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "showInfo", 
($fz = function (message) {
this.fStatusLine.showInfo (message);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "showStatus", 
($fz = function (status) {
this.fStatusLine.showError (status);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "start", 
function (args) {
var suiteName = this.processArguments (args);
this.fFrame = this.createUI (suiteName);
this.fFrame.pack ();
this.fFrame.setVisible (true);
if (suiteName != null) {
this.setSuite (suiteName);
this.runSuite ();
}}, "~A");
Clazz.defineMethod (c$, "start", 
($fz = function (test) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$18")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$18", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
var total = this.f$.test.countTestCases ();
this.b$["junit.swingui.TestRunner"].fProgressIndicator.start (total);
this.b$["junit.swingui.TestRunner"].fCounterPanel.setTotal (total);
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$18, i$, v$);
}) (this, Clazz.cloneFinals ("test", test)));
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "synchUI", 
($fz = function () {
try {
javax.swing.SwingUtilities.invokeAndWait ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestRunner$19")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestRunner$19", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestRunner$19, i$, v$);
}) (this, null));
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "terminate", 
function () {
this.fFrame.dispose ();
try {
this.saveHistory ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
System.out.println ("Couldn't save test run history");
} else {
throw e;
}
}
System.exit (0);
});
Clazz.defineMethod (c$, "textChanged", 
function () {
this.fRun.setEnabled (this.getSuiteText ().length > 0);
this.clearStatus ();
});
Clazz.overrideMethod (c$, "clearStatus", 
function () {
this.fStatusLine.clear ();
});
c$.getIconResource = Clazz.defineMethod (c$, "getIconResource", 
function (clazz, name) {
var url = clazz.getResource (name);
if (url == null) {
System.err.println ("Warning: could not load \"" + name + "\" icon");
return null;
}return  new javax.swing.ImageIcon (url);
}, "Class,~S");
Clazz.defineMethod (c$, "about", 
($fz = function () {
var about =  new junit.swingui.AboutDialog (this.fFrame);
about.show ();
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"GAP", 4,
"HISTORY_LENGTH", 5,
"TESTCOLLECTOR_KEY", "TestCollectorClass",
"FAILUREDETAILVIEW_KEY", "FailureViewClass");
});
