Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.JPanel", "javax.swing.tree.DefaultTreeCellRenderer", "junit.framework.TestListener"], "junit.swingui.TestSuitePanel", ["java.awt.BorderLayout", "$.Dimension", "java.util.Vector", "javax.swing.JScrollPane", "$.JTree", "$.SwingUtilities", "$.ToolTipManager", "javax.swing.tree.TreePath", "junit.swingui.TestRunner", "$.TestTreeModel"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fTree = null;
this.fScrollTree = null;
this.fModel = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "TestSuitePanel", javax.swing.JPanel, junit.framework.TestListener);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fErrorIcon = null;
this.fOkIcon = null;
this.fFailureIcon = null;
Clazz.instantialize (this, arguments);
}, junit.swingui.TestSuitePanel, "TestTreeCellRenderer", javax.swing.tree.DefaultTreeCellRenderer);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.TestSuitePanel.TestTreeCellRenderer);
this.loadIcons ();
});
Clazz.defineMethod (c$, "loadIcons", 
function () {
this.fErrorIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/error.gif");
this.fOkIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/ok.gif");
this.fFailureIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/failure.gif");
});
Clazz.defineMethod (c$, "stripParenthesis", 
function (a) {
var b = a.toString ();
var c = b.indexOf ('(');
if (c < 1) return b;
return b.substring (0, c);
}, "~O");
Clazz.defineMethod (c$, "getTreeCellRendererComponent", 
function (a, b, c, d, e, f, g) {
var h = Clazz.superCall (this, junit.swingui.TestSuitePanel.TestTreeCellRenderer, "getTreeCellRendererComponent", [a, b, c, d, e, f, g]);
var i = a.getModel ();
if (Clazz.instanceOf (i, junit.swingui.TestTreeModel)) {
var j = i;
var k = b;
var l = "";
if (j.isFailure (k)) {
if (this.fFailureIcon != null) this.setIcon (this.fFailureIcon);
l = " - Failed";
} else if (j.isError (k)) {
if (this.fErrorIcon != null) this.setIcon (this.fErrorIcon);
l = " - Error";
} else if (j.wasRun (k)) {
if (this.fOkIcon != null) this.setIcon (this.fOkIcon);
l = " - Passed";
}if (Clazz.instanceOf (h, javax.swing.JComponent)) (h).setToolTipText (this.getText () + l);
}this.setText (this.stripParenthesis (b));
return h;
}, "javax.swing.JTree,~O,~B,~B,~B,~N,~B");
c$ = Clazz.p0p ();
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.TestSuitePanel, [ new java.awt.BorderLayout ()]);
this.setPreferredSize ( new java.awt.Dimension (300, 100));
this.fTree =  new javax.swing.JTree ();
this.fTree.setModel (null);
this.fTree.setRowHeight (20);
javax.swing.ToolTipManager.sharedInstance ().registerComponent (this.fTree);
this.fTree.putClientProperty ("JTree.lineStyle", "Angled");
this.fScrollTree =  new javax.swing.JScrollPane (this.fTree);
this.add (this.fScrollTree, java.awt.BorderLayout.CENTER);
});
Clazz.overrideMethod (c$, "addError", 
function (test, t) {
this.fModel.addError (test);
this.fireTestChanged (test, true);
}, "junit.framework.Test,Throwable");
Clazz.overrideMethod (c$, "addFailure", 
function (test, t) {
this.fModel.addFailure (test);
this.fireTestChanged (test, true);
}, "junit.framework.Test,junit.framework.AssertionFailedError");
Clazz.overrideMethod (c$, "endTest", 
function (test) {
this.fModel.addRunTest (test);
this.fireTestChanged (test, false);
}, "junit.framework.Test");
Clazz.overrideMethod (c$, "startTest", 
function (test) {
}, "junit.framework.Test");
Clazz.defineMethod (c$, "getSelectedTest", 
function () {
var paths = this.fTree.getSelectionPaths ();
if (paths != null && paths.length == 1) return paths[0].getLastPathComponent ();
return null;
});
Clazz.defineMethod (c$, "getTree", 
function () {
return this.fTree;
});
Clazz.defineMethod (c$, "showTestTree", 
function (root) {
this.fModel =  new junit.swingui.TestTreeModel (root);
this.fTree.setModel (this.fModel);
this.fTree.setCellRenderer ( new junit.swingui.TestSuitePanel.TestTreeCellRenderer ());
}, "junit.framework.Test");
Clazz.defineMethod (c$, "fireTestChanged", 
($fz = function (test, expand) {
javax.swing.SwingUtilities.invokeLater ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestSuitePanel$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestSuitePanel$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
var vpath =  new java.util.Vector ();
var index = this.b$["junit.swingui.TestSuitePanel"].fModel.findTest (this.f$.test, this.b$["junit.swingui.TestSuitePanel"].fModel.getRoot (), vpath);
if (index >= 0) {
var path =  new Array (vpath.size ());
vpath.copyInto (path);
var treePath =  new javax.swing.tree.TreePath (path);
this.b$["junit.swingui.TestSuitePanel"].fModel.fireNodeChanged (treePath, index);
if (this.f$.expand) {
var fullPath =  new Array (vpath.size () + 1);
vpath.copyInto (fullPath);
fullPath[vpath.size ()] = this.b$["junit.swingui.TestSuitePanel"].fModel.getChild (treePath.getLastPathComponent (), index);
;var fullTreePath =  new javax.swing.tree.TreePath (fullPath);
this.b$["junit.swingui.TestSuitePanel"].fTree.scrollPathToVisible (fullTreePath);
}}});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestSuitePanel$1, i$, v$);
}) (this, Clazz.cloneFinals ("test", test, "expand", expand)));
}, $fz.isPrivate = true, $fz), "junit.framework.Test,~B");
});
