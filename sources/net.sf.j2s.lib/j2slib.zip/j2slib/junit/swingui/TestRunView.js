Clazz.declarePackage ("junit.swingui");
Clazz.declareInterface (junit.swingui, "TestRunView");
