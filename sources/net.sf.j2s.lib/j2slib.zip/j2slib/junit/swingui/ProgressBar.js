Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.JProgressBar"], "junit.swingui.ProgressBar", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.fError = false;
Clazz.instantialize (this, arguments);
}, junit.swingui, "ProgressBar", javax.swing.JProgressBar);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.ProgressBar);
this.setForeground (this.getStatusColor ());
});
Clazz.defineMethod (c$, "getStatusColor", 
($fz = function () {
if (this.fError) return java.awt.Color.red;
return java.awt.Color.green;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "reset", 
function () {
this.fError = false;
this.setForeground (this.getStatusColor ());
this.setValue (0);
});
Clazz.defineMethod (c$, "start", 
function (total) {
this.setMaximum (total);
this.reset ();
}, "~N");
Clazz.defineMethod (c$, "step", 
function (value, successful) {
this.setValue (value);
if (!this.fError && !successful) {
this.fError = true;
this.setForeground (this.getStatusColor ());
}}, "~N,~B");
});
