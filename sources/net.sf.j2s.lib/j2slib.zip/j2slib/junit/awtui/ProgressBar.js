Clazz.declarePackage ("junit.awtui");
Clazz.load (["java.awt.Canvas"], "junit.awtui.ProgressBar", ["java.awt.Rectangle"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fError = false;
this.fTotal = 0;
this.fProgress = 0;
this.fProgressX = 0;
Clazz.instantialize (this, arguments);
}, junit.awtui, "ProgressBar", java.awt.Canvas);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.awtui.ProgressBar);
this.setSize (20, 30);
});
Clazz.defineMethod (c$, "getStatusColor", 
($fz = function () {
if (this.fError) return java.awt.Color.red;
return java.awt.Color.green;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "paint", 
function (g) {
this.paintBackground (g);
this.paintStatus (g);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "paintBackground", 
function (g) {
g.setColor (java.awt.SystemColor.control);
var r = this.getBounds ();
g.fillRect (0, 0, r.width, r.height);
g.setColor (java.awt.Color.darkGray);
g.drawLine (0, 0, r.width - 1, 0);
g.drawLine (0, 0, 0, r.height - 1);
g.setColor (java.awt.Color.white);
g.drawLine (r.width - 1, 0, r.width - 1, r.height - 1);
g.drawLine (0, r.height - 1, r.width - 1, r.height - 1);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "paintStatus", 
function (g) {
g.setColor (this.getStatusColor ());
var r =  new java.awt.Rectangle (0, 0, this.fProgressX, this.getBounds ().height);
g.fillRect (1, 1, r.width - 1, r.height - 2);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "paintStep", 
($fz = function (startX, endX) {
this.repaint (startX, 1, endX - startX, this.getBounds ().height - 2);
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "reset", 
function () {
this.fProgressX = 1;
this.fProgress = 0;
this.fError = false;
this.paint (this.getGraphics ());
});
Clazz.defineMethod (c$, "scale", 
function (value) {
if (this.fTotal > 0) return Math.max (1, Math.floor (value * (this.getBounds ().width - 1) / this.fTotal));
return value;
}, "~N");
Clazz.defineMethod (c$, "setBounds", 
function (x, y, w, h) {
Clazz.superCall (this, junit.awtui.ProgressBar, "setBounds", [x, y, w, h]);
this.fProgressX = this.scale (this.fProgress);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "start", 
function (total) {
this.fTotal = total;
this.reset ();
}, "~N");
Clazz.defineMethod (c$, "step", 
function (successful) {
this.fProgress++;
var x = this.fProgressX;
this.fProgressX = this.scale (this.fProgress);
if (!this.fError && !successful) {
this.fError = true;
x = 1;
}this.paintStep (x, this.fProgressX);
}, "~B");
});
