(function(){var P$=Clazz.newPackage("javajs.api.js"),I$=[];
var C$=Clazz.newInterface(P$, "J2SObjectInterface");
})();
//Created 2017-12-24 13:32:52
