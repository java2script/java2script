(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newInterface(P$, "GenericBinaryDocument", null, null, 'javajs.api.GenericBinaryDocumentReader');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-24 13:32:52
