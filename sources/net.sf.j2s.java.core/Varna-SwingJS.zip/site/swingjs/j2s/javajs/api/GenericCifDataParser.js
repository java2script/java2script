(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newInterface(P$, "GenericCifDataParser");
})();
//Created 2017-12-24 13:32:52
