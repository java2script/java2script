(function(){var P$=Clazz.newPackage("javajs.util"),I$=[];
var C$=Clazz.newClass(P$, "DebugJS");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, '_$S', function (msg) {
{
if (Clazz._debugging) { debugger;
} }
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-24 13:32:54
