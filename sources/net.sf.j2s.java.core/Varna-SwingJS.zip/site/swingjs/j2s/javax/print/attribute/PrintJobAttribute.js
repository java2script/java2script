(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
var C$=Clazz.newInterface(P$, "PrintJobAttribute", null, null, 'javax.print.attribute.Attribute');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:06
