(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
var C$=Clazz.newInterface(P$, "AttributeSet");
})();
//Created 2018-01-01 20:52:24
