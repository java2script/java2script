(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
var C$=Clazz.newInterface(P$, "PrintRequestAttributeSet", null, null, 'javax.print.attribute.AttributeSet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:06
