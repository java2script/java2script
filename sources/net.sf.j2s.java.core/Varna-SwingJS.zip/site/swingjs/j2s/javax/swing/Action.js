(function(){var P$=Clazz.newPackage("javax.swing"),I$=[];
var C$=Clazz.newInterface(P$, "Action", null, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:09
