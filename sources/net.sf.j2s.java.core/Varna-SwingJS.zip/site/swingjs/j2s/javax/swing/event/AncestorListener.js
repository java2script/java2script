(function(){var P$=Clazz.newPackage("javax.swing.event"),I$=[];
var C$=Clazz.newInterface(P$, "AncestorListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:30
