(function(){var P$=Clazz.newPackage("javax.swing.colorchooser"),I$=[];
var C$=Clazz.newInterface(P$, "ColorSelectionModel");
})();
//Created 2018-01-01 08:59:29
