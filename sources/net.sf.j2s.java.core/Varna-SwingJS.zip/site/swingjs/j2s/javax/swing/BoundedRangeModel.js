(function(){var P$=Clazz.newPackage("javax.swing"),I$=[];
var C$=Clazz.newInterface(P$, "BoundedRangeModel");
})();
//Created 2018-01-01 08:59:09
