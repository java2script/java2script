(function(){var P$=Clazz.newPackage("javax.swing.border"),I$=[];
var C$=Clazz.newInterface(P$, "Border");
})();
//Created 2018-01-01 08:59:28
