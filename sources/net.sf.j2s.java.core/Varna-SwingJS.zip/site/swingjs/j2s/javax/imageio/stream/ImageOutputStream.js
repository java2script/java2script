(function(){var P$=Clazz.newPackage("javax.imageio.stream"),I$=[];
var C$=Clazz.newInterface(P$, "ImageOutputStream", null, null, ['javax.imageio.stream.ImageInputStream', 'java.io.DataOutput']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:06
