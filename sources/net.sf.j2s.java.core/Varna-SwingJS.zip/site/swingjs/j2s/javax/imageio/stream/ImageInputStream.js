(function(){var P$=Clazz.newPackage("javax.imageio.stream"),I$=[];
var C$=Clazz.newInterface(P$, "ImageInputStream");
})();
//Created 2018-01-01 08:59:06
