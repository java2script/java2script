(function(){var P$=Clazz.newPackage("javax.sound.sampled"),I$=[];
var C$=Clazz.newInterface(P$, "SourceDataLine", null, null, 'javax.sound.sampled.DataLine');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-01-01 08:59:08
