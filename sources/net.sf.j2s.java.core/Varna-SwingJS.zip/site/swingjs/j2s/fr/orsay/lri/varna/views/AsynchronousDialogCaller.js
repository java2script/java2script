(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[];
var C$=Clazz.newInterface(P$, "AsynchronousDialogCaller");
})();
//Created 2017-12-30 12:18:25
