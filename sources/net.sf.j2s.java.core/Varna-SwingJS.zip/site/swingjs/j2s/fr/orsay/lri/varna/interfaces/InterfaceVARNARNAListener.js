(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.interfaces"),I$=[];
var C$=Clazz.newInterface(P$, "InterfaceVARNARNAListener");
})();
//Created 2017-12-31 14:30:22
