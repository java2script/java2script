(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[];
var C$=Clazz.newInterface(P$, "AsynchronousDialogMessage");
})();
//Created 2017-12-28 08:57:08
