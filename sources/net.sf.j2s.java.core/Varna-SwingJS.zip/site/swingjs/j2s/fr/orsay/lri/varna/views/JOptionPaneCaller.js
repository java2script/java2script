(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[];
var C$=Clazz.newInterface(P$, "JOptionPaneCaller");
})();
//Created 2017-12-28 07:20:42
