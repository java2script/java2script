(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.naView"),I$=[];
var C$=Clazz.newClass(P$, "Region");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._start1 = 0;
this._end1 = 0;
this._start2 = 0;
this._end2 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getStart1', function () {
return this._start1;
});

Clazz.newMeth(C$, 'setStart1$I', function (start1) {
this._start1 = start1;
});

Clazz.newMeth(C$, 'getEnd1', function () {
return this._end1;
});

Clazz.newMeth(C$, 'setEnd1$I', function (end1) {
this._end1 = end1;
});

Clazz.newMeth(C$, 'getStart2', function () {
return this._start2;
});

Clazz.newMeth(C$, 'setStart2$I', function (start2) {
this._start2 = start2;
});

Clazz.newMeth(C$, 'getEnd2', function () {
return this._end2;
});

Clazz.newMeth(C$, 'setEnd2$I', function (end2) {
this._end2 = end2;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-31 14:30:23
