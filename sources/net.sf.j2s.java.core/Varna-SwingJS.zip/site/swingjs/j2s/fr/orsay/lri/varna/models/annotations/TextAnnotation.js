(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.annotations"),I$=[['java.awt.Color','java.awt.Font','org.xml.sax.helpers.AttributesImpl','fr.orsay.lri.varna.utils.XMLUtils',['fr.orsay.lri.varna.models.annotations.TextAnnotation','.AnchorType'],'fr.orsay.lri.varna.models.rna.VARNAPoint','java.text.DecimalFormat',['java.awt.geom.Point2D','.Double'],'java.util.Collections']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TextAnnotation", null, null, 'java.io.Serializable');
C$.DEFAULTCOLOR = null;
C$.DEFAULTFONT = null;
C$.XML_ELEMENT_NAME = null;
C$.XML_VAR_TYPE_NAME = null;
C$.XML_VAR_COLOR_NAME = null;
C$.XML_VAR_ANGLE_NAME = null;
C$.XML_VAR_TEXT_NAME = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.DEFAULTCOLOR = (I$[1]||$incl$(1)).black;
C$.DEFAULTFONT = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Arial", 0, 12]);
C$.XML_ELEMENT_NAME = "textAnnotation";
C$.XML_VAR_TYPE_NAME = "type";
C$.XML_VAR_COLOR_NAME = "color";
C$.XML_VAR_ANGLE_NAME = "angle";
C$.XML_VAR_TEXT_NAME = "text";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._text = null;
this._typeAnchor = null;
this._color = null;
this._angle = 0;
this._anchor = null;
this._font = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'toXML$javax_xml_transform_sax_TransformerHandler', function (hd) {
var atts = Clazz.new_((I$[3]||$incl$(3)));
atts.addAttribute$S$S$S$S$S("", "", C$.XML_VAR_TYPE_NAME, "CDATA", "" + this._typeAnchor);
atts.addAttribute$S$S$S$S$S("", "", C$.XML_VAR_COLOR_NAME, "CDATA", "" + (I$[4]||$incl$(4)).toHTMLNotation$java_awt_Color(this._color));
atts.addAttribute$S$S$S$S$S("", "", C$.XML_VAR_ANGLE_NAME, "CDATA", "" + new Double(this._angle).toString());
hd.startElement$S$S$S$org_xml_sax_Attributes("", "", C$.XML_ELEMENT_NAME, atts);
atts.clear();
hd.startElement$S$S$S$org_xml_sax_Attributes("", "", C$.XML_VAR_TEXT_NAME, atts);
(I$[4]||$incl$(4)).exportCDATAString$javax_xml_transform_sax_TransformerHandler$S(hd, this._text);
hd.endElement$S$S$S("", "", C$.XML_VAR_TEXT_NAME);
switch (this._typeAnchor) {
case (I$[5]||$incl$(5)).POSITION:
(this._anchor).toXML$javax_xml_transform_sax_TransformerHandler$S(hd, "pos");
break;
case (I$[5]||$incl$(5)).BASE:
(I$[4]||$incl$(4)).toXML$javax_xml_transform_sax_TransformerHandler$fr_orsay_lri_varna_models_rna_ModeleBase(hd, this._anchor);
break;
case (I$[5]||$incl$(5)).HELIX:
(I$[4]||$incl$(4)).toXML$javax_xml_transform_sax_TransformerHandler$java_util_ArrayList(hd, this._anchor);
break;
case (I$[5]||$incl$(5)).LOOP:
(I$[4]||$incl$(4)).toXML$javax_xml_transform_sax_TransformerHandler$java_util_ArrayList(hd, this._anchor);
break;
}
(I$[4]||$incl$(4)).toXML$javax_xml_transform_sax_TransformerHandler$java_awt_Font(hd, this._font);
hd.endElement$S$S$S("", "", C$.XML_ELEMENT_NAME);
});

Clazz.newMeth(C$, 'c$$S', function (texte) {
C$.$init$.apply(this);
this._text = texte;
this._color = C$.DEFAULTCOLOR;
this._font = C$.DEFAULTFONT;
this._angle = 0;
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D', function (texte, x, y) {
C$.c$$S.apply(this, [texte]);
this._anchor = Clazz.new_((I$[6]||$incl$(6)).c$$D$D,[x, y]);
this._typeAnchor = (I$[5]||$incl$(5)).POSITION;
}, 1);

Clazz.newMeth(C$, 'c$$S$fr_orsay_lri_varna_models_rna_ModeleBase', function (texte, mb) {
C$.c$$S.apply(this, [texte]);
this._anchor = mb;
this._typeAnchor = (I$[5]||$incl$(5)).BASE;
}, 1);

Clazz.newMeth(C$, 'c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType', function (texte, listeBase, type) {
C$.c$$S.apply(this, [texte]);
this._anchor = listeBase;
if (type === (I$[5]||$incl$(5)).HELIX ) this._typeAnchor = (I$[5]||$incl$(5)).HELIX;
 else if (type === (I$[5]||$incl$(5)).LOOP ) this._typeAnchor = (I$[5]||$incl$(5)).LOOP;
 else throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Bad argument"]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_models_annotations_TextAnnotation', function (textAnnotation) {
C$.$init$.apply(this);
this._anchor = textAnnotation.getAncrage();
this._font = textAnnotation.getFont();
this._text = textAnnotation.getTexte();
this._typeAnchor = textAnnotation.getType();
}, 1);

Clazz.newMeth(C$, 'getTexte', function () {
return this._text;
});

Clazz.newMeth(C$, 'setText$S', function (_texte) {
this._text = _texte;
});

Clazz.newMeth(C$, 'getFont', function () {
return this._font;
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (_font) {
this._font = _font;
});

Clazz.newMeth(C$, 'getAncrage', function () {
return this._anchor;
});

Clazz.newMeth(C$, 'setAncrage$fr_orsay_lri_varna_models_rna_ModeleBase', function (mb) {
this._anchor = mb;
this._typeAnchor = (I$[5]||$incl$(5)).BASE;
});

Clazz.newMeth(C$, 'setAncrage$D$D', function (x, y) {
this._anchor = Clazz.new_((I$[6]||$incl$(6)).c$$D$D,[x, y]);
this._typeAnchor = (I$[5]||$incl$(5)).POSITION;
});

Clazz.newMeth(C$, 'setAncrage$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType', function (list, type) {
this._anchor = list;
if (type === (I$[5]||$incl$(5)).HELIX ) this._typeAnchor = (I$[5]||$incl$(5)).HELIX;
 else if (type === (I$[5]||$incl$(5)).LOOP ) this._typeAnchor = (I$[5]||$incl$(5)).LOOP;
 else throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Bad argument"]);
});

Clazz.newMeth(C$, 'getType', function () {
return this._typeAnchor;
});

Clazz.newMeth(C$, 'setType$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType', function (t) {
this._typeAnchor = t;
});

Clazz.newMeth(C$, 'getColor', function () {
return this._color;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (color) {
this._color = color;
});

Clazz.newMeth(C$, 'getHelixDescription', function () {
var listeBase = (this._anchor);
var minA = 2147483647;
var maxA = -2147483648;
var minB = 2147483647;
var maxB = -2147483648;
for (var mb, $mb = listeBase.iterator (); $mb.hasNext () && ((mb = $mb.next ()) || true);) {
var i = mb.getBaseNumber();
if (mb.getElementStructure() > i) {
minA = Math.min(minA, i);
maxA = Math.max(maxA, i);
} else {
minB = Math.min(minB, i);
maxB = Math.max(maxB, i);
}}
return "[" + minA + "," + maxA + "] [" + minB + "," + maxB + "]" ;
});

Clazz.newMeth(C$, 'getLoopDescription', function () {
var listeBase = (this._anchor);
var min = 2147483647;
var max = -2147483648;
for (var mb, $mb = listeBase.iterator (); $mb.hasNext () && ((mb = $mb.next ()) || true);) {
var i = mb.getBaseNumber();
min = Math.min(min, i);
max = Math.max(max, i);
}
return "[" + min + "," + max + "]" ;
});

Clazz.newMeth(C$, 'toString', function () {
var tmp = "[" + this._text + "] " ;
switch (this._typeAnchor) {
case (I$[5]||$incl$(5)).POSITION:
var formatter = Clazz.new_((I$[7]||$incl$(7)).c$$S,[".00"]);
return tmp + " at (" + formatter.format$D(this.getCenterPosition().x) + "," + formatter.format$D(this.getCenterPosition().y) + ")" ;
case (I$[5]||$incl$(5)).BASE:
return tmp + " on base " + (this._anchor).getBaseNumber() ;
case (I$[5]||$incl$(5)).HELIX:
return tmp + " on helix " + this.getHelixDescription() ;
case (I$[5]||$incl$(5)).LOOP:
return tmp + " on loop " + this.getLoopDescription() ;
default:
return tmp;
}
});

Clazz.newMeth(C$, 'getCenterPosition', function () {
switch (this._typeAnchor) {
case (I$[5]||$incl$(5)).POSITION:
return (this._anchor).toPoint2D();
case (I$[5]||$incl$(5)).BASE:
return (this._anchor).getCoords();
case (I$[5]||$incl$(5)).HELIX:
return p$.calculLoopHelix.apply(this, []);
case (I$[5]||$incl$(5)).LOOP:
return p$.calculLoop.apply(this, []);
default:
return Clazz.new_((I$[8]||$incl$(8)).c$$D$D,[0.0, 0.0]);
}
});

Clazz.newMeth(C$, 'calculLoop', function () {
var liste = p$.extractedArrayListModeleBaseFromAncrage.apply(this, []);
var totalX = 0.0;
var totalY = 0.0;
for (var base, $base = liste.iterator (); $base.hasNext () && ((base = $base.next ()) || true);) {
totalX += base.getCoords().x;
totalY += base.getCoords().y;
}
return Clazz.new_((I$[8]||$incl$(8)).c$$D$D,[totalX / liste.size(), totalY / liste.size()]);
});

Clazz.newMeth(C$, 'calculLoopHelix', function () {
var liste = p$.extractedArrayListModeleBaseFromAncrage.apply(this, []);
(I$[9]||$incl$(9)).sort$java_util_List(liste);
var totalX = 0.0;
var totalY = 0.0;
var num = 0.0;
for (var i = 0; i < liste.size(); i++) {
var base = liste.get$I(i);
if ((i > 0 && (i < liste.size() - 1) ) || (((liste.size()/2|0)) % 2 == 0) ) {
totalX += base.getCoords().x;
totalY += base.getCoords().y;
num += 1;
}}
return Clazz.new_((I$[8]||$incl$(8)).c$$D$D,[totalX / num, totalY / num]);
});

Clazz.newMeth(C$, 'extractedArrayListModeleBaseFromAncrage', function () {
return this._anchor;
});

Clazz.newMeth(C$, 'clone', function () {
var textAnnot = null;
try {
switch (this._typeAnchor) {
case (I$[5]||$incl$(5)).BASE:
textAnnot = Clazz.new_(C$.c$$S$fr_orsay_lri_varna_models_rna_ModeleBase,[this._text, this._anchor]);
break;
case (I$[5]||$incl$(5)).POSITION:
textAnnot = Clazz.new_(C$.c$$S$D$D,[this._text, (this._anchor).x, (this._anchor).y]);
break;
case (I$[5]||$incl$(5)).LOOP:
textAnnot = Clazz.new_(C$.c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,[this._text, p$.extractedArrayListModeleBaseFromAncrage.apply(this, []), (I$[5]||$incl$(5)).LOOP]);
break;
case (I$[5]||$incl$(5)).HELIX:
textAnnot = Clazz.new_(C$.c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,[this._text, p$.extractedArrayListModeleBaseFromAncrage.apply(this, []), (I$[5]||$incl$(5)).HELIX]);
break;
default:
break;
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
textAnnot.setFont$java_awt_Font(this._font);
textAnnot.setColor$java_awt_Color(this._color);
return textAnnot;
});

Clazz.newMeth(C$, 'copy$fr_orsay_lri_varna_models_annotations_TextAnnotation', function (textAnnotation) {
this._anchor = textAnnotation.getAncrage();
this._font = textAnnotation.getFont();
this._text = textAnnotation.getTexte();
this._typeAnchor = textAnnotation.getType();
this._color = textAnnotation.getColor();
this._angle = textAnnotation.getAngleInDegres();
});

Clazz.newMeth(C$, 'getAngleInDegres', function () {
return this._angle;
});

Clazz.newMeth(C$, 'getAngleInRadians', function () {
return (this.getAngleInDegres() * 3.141592653589793) / 180.0;
});

Clazz.newMeth(C$, 'setAngleInDegres$D', function (_angle) {
this._angle = _angle;
});

Clazz.newMeth(C$, 'setAngleInRadians$D', function (_angle) {
this._angle = _angle * 180 / 3.141592653589793;
});
;
(function(){var C$=Clazz.newClass(P$.TextAnnotation, "AnchorType", null, 'Enum');

C$.$clinit$ = function() {Clazz.load(C$, 1);
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "POSITION", 0, []);
Clazz.newEnumConst($vals, C$.c$, "BASE", 1, []);
Clazz.newEnumConst($vals, C$.c$, "HELIX", 2, []);
Clazz.newEnumConst($vals, C$.c$, "LOOP", 3, []);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values', function() { return $vals }, 1);
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-31 14:30:22
