Issues
======

VueMenu not showing default visible items
 

Modifications for SwingJS
=========================

Search for @j2sNative 


VARNA.java 
----------

moved to fr.orsay.lri.varna

adds default RNA JavaScript:

	  if (!thisApplet.__Info.sequenceDBN) {
	   thisApplet.__Info.sequenceDBN = "GGGGCCAAUAUGGCCAUCC";
	   thisApplet.__Info.structureDBN = "((((((.....))))..))";
	   thisApplet.__Info.title = prompt("Title?","Hello RNA world!");
	  } 



fr.orsay.lri.varna.views.PrinterTest.java
-----------------------------------------

simpler test that does not use java.awt.font.TextLayout



fr.orsay.lri.varna.views.VueMenu.java
-------------------------------------

changes JLabel to JMenuItem 
changes JSeparator to JPopupMenu.Separator



fr.orsay.lri.varna.views.VueMenu.java
-------------------------------------

added asynchronous OKCancelCaller callback option for JavaScript
