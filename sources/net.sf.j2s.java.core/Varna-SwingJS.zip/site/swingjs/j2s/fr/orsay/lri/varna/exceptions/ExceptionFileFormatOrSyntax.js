(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.exceptions"),I$=[];
var C$=Clazz.newClass(P$, "ExceptionFileFormatOrSyntax", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._path = null;
this._errorMessage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (errorMessage, path) {
Clazz.super_(C$, this,1);
this._path = path;
this._errorMessage = errorMessage;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (path) {
Clazz.super_(C$, this,1);
this._path = path;
}, 1);

Clazz.newMeth(C$, 'getError', function () {
return this._errorMessage;
});

Clazz.newMeth(C$, 'getMessage', function () {
return "Unknown format or syntax error in file ' " + this._path + " '. \nLoading cancelled !" ;
});

Clazz.newMeth(C$, 'setPath$S', function (path) {
this._path = path;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-31 14:30:21
