(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[];
var C$=Clazz.newInterface(P$, "OKCancelCaller");
})();
//Created 2017-12-26 07:40:59
