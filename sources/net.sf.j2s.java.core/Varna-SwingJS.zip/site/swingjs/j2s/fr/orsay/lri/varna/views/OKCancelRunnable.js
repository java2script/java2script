(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[];
var C$=Clazz.newInterface(P$, "OKCancelRunnable", null, null, 'Runnable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-26 03:43:14
