(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.components"),I$=[['javax.swing.JButton']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ActionEditor", null, 'javax.swing.AbstractCellEditor', 'javax.swing.table.TableCellEditor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._btn = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this._btn = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_event_ActionListener', function (a) {
Clazz.super_(C$, this,1);
this._btn.addActionListener$java_awt_event_ActionListener(a);
}, 1);

Clazz.newMeth(C$, 'getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I', function (table, value, isSelected, rowIndex, vColIndex) {
this._btn.setText$S(value.toString());
this._btn.setActionCommand$S(value.toString() + "-" + rowIndex );
return this._btn;
});

Clazz.newMeth(C$, 'getCellEditorValue', function () {
return "";
});

Clazz.newMeth(C$, 'shouldSelectCell$java_util_EventObject', function (anEvent) {
return C$.superclazz.prototype.shouldSelectCell$java_util_EventObject.apply(this, [anEvent]);
});

Clazz.newMeth(C$, 'isCellEditable$java_util_EventObject', function (anEvent) {
return C$.superclazz.prototype.isCellEditable$java_util_EventObject.apply(this, [anEvent]);
});

Clazz.newMeth(C$, 'stopCellEditing', function () {
return C$.superclazz.prototype.stopCellEditing.apply(this, []);
});

Clazz.newMeth(C$);
})();
//Created 2017-12-31 14:30:20
