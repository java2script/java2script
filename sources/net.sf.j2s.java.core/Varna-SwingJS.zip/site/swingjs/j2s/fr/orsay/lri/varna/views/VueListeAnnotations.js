(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[['java.awt.GridLayout','java.util.ArrayList','fr.orsay.lri.varna.components.AnnotationTableModel','javax.swing.JTable','fr.orsay.lri.varna.controlers.ControleurTableAnnotations','javax.swing.JScrollPane','javax.swing.JOptionPane']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VueListeAnnotations", null, 'javax.swing.JPanel');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vp = null;
this.data = null;
this.table = null;
this.type = 0;
this.specialTableModel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$I', function (vp, type) {
C$.superclazz.c$$java_awt_LayoutManager.apply(this, [Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[1, 0])]);
C$.$init$.apply(this);
this.type = type;
this._vp = vp;
this.data = Clazz.new_((I$[2]||$incl$(2)));
this.data.addAll$java_util_Collection(this._vp.getListeAnnotations());
this.data.addAll$java_util_Collection(this._vp.getRNA().getHighlightRegion());
this.data.addAll$java_util_Collection(this._vp.getRNA().getChemProbAnnotations());
p$.createView.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'createView', function () {
this.specialTableModel = Clazz.new_((I$[3]||$incl$(3)).c$$java_util_ArrayList,[this.data]);
this.table = Clazz.new_((I$[4]||$incl$(4)).c$$javax_swing_table_TableModel,[this.specialTableModel]);
var ctrl = Clazz.new_((I$[5]||$incl$(5)).c$$javax_swing_JTable$fr_orsay_lri_varna_VARNAPanel$I,[this.table, this._vp, this.type]);
this.table.addMouseListener$java_awt_event_MouseListener(ctrl);
this.table.addMouseMotionListener$java_awt_event_MouseMotionListener(ctrl);
var scrollPane = Clazz.new_((I$[6]||$incl$(6)).c$$java_awt_Component,[this.table]);
this.add$java_awt_Component(scrollPane);
this.UIvueListeAnnotations();
});

Clazz.newMeth(C$, 'UIvueListeAnnotations', function () {
var newContentPane = this;
newContentPane.setOpaque$Z(true);
(I$[7]||$incl$(7)).showMessageDialog$java_awt_Component$O$S$I(this._vp, newContentPane, "Annotation edition", -1);
});

Clazz.newMeth(C$, 'getData', function () {
return this.data;
});

Clazz.newMeth(C$, 'setData$java_util_ArrayList', function (data) {
this.data = data;
});

Clazz.newMeth(C$, 'get_vp', function () {
return this._vp;
});

Clazz.newMeth(C$, 'getTable', function () {
return this.table;
});

Clazz.newMeth(C$, 'setTable$javax_swing_JTable', function (table) {
this.table = table;
});

Clazz.newMeth(C$, 'getSpecialTableModel', function () {
return this.specialTableModel;
});

Clazz.newMeth(C$, 'setSpecialTableModel$fr_orsay_lri_varna_components_AnnotationTableModel', function (specialTableModel) {
this.specialTableModel = specialTableModel;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-31 14:47:55
