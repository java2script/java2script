(function(){var P$=Clazz.newPackage("a2s"),I$=[['javax.swing.JRadioButton']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Checkbox", null, 'javax.swing.JCheckBox');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'newRadioButton$S$javax_swing_ButtonGroup$Z', function (string, bg, b) {
var rb = Clazz.new_((I$[1]||$incl$(1)).c$$S$Z,[string, b]);
bg.add$javax_swing_AbstractButton(rb);
return rb;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (string) {
C$.superclazz.c$$S$Z.apply(this, [string, false]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (string, b) {
C$.superclazz.c$$S$Z.apply(this, [string, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getState', function () {
return this.isSelected();
});

Clazz.newMeth(C$, 'setState$Z', function (b) {
this.setSelected$Z(b);
});
})();
//Created 2017-12-24 13:32:16
