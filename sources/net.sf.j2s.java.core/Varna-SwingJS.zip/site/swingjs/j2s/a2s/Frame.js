(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Frame", null, 'javax.swing.JFrame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (title) {
C$.superclazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this, [gc]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_GraphicsConfiguration', function (title, gc) {
C$.superclazz.c$$S$java_awt_GraphicsConfiguration.apply(this, [title, gc]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'remove$I', function (i) {
{
this.removeInt(i);
}
});

Clazz.newMeth(C$, 'setMenuBar$a2s_MenuBar', function (m) {
this.setJMenuBar$javax_swing_JMenuBar(m);
});

Clazz.newMeth(C$, 'unsetMenuBar', function () {
this.setJMenuBar$javax_swing_JMenuBar(null);
});

Clazz.newMeth(C$, 'getMenubar', function () {
return this.getJMenuBar();
});
})();
//Created 2017-12-24 13:32:17
