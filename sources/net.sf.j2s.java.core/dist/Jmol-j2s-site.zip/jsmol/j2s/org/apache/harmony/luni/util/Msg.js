Clazz.declarePackage ("org.apache.harmony.luni.util");
Clazz.load (["java.util.Locale", "org.apache.harmony.luni.util.MsgHelp"], "org.apache.harmony.luni.util.Msg", null, function () {
c$ = Clazz.declareType (org.apache.harmony.luni.util, "Msg");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a) {
if (org.apache.harmony.luni.util.Msg.bundle == null) return a;
try {
return org.apache.harmony.luni.util.Msg.bundle.getString (a);
} catch (e) {
if (Clazz.exceptionOf (e, java.util.MissingResourceException)) {
return a;
} else {
throw e;
}
}
}, "~S");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
return org.apache.harmony.luni.util.Msg.getString (a,  Clazz.newArray (-1, [b]));
}, "~S,~O");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
return org.apache.harmony.luni.util.Msg.getString (a,  Clazz.newArray (-1, [Integer.toString (b)]));
}, "~S,~N");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
return org.apache.harmony.luni.util.Msg.getString (a,  Clazz.newArray (-1, [String.valueOf (b)]));
}, "~S,~S");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b, c) {
return org.apache.harmony.luni.util.Msg.getString (a,  Clazz.newArray (-1, [b, c]));
}, "~S,~O,~O");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
var c = a;
if (org.apache.harmony.luni.util.Msg.bundle != null) {
try {
c = org.apache.harmony.luni.util.Msg.bundle.getString (a);
} catch (e) {
if (Clazz.exceptionOf (e, java.util.MissingResourceException)) {
} else {
throw e;
}
}
}return org.apache.harmony.luni.util.MsgHelp.format (c, b);
}, "~S,~A");
Clazz.defineStatics (c$,
"bundle", null);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023