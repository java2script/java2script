Clazz.declarePackage ("org.apache.harmony.luni.util");
Clazz.load (["java.util.ResourceBundle"], "org.apache.harmony.luni.util.MsgHelp", ["java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (org.apache.harmony.luni.util, "MsgHelp");
c$.format = Clazz.defineMethod (c$, "format", 
function (a, b) {
var c =  new StringBuilder (a.length + (b.length * 20));
var d =  new Array (b.length);
for (var e = 0; e < b.length; ++e) {
if (b[e] == null) d[e] = "<null>";
 else d[e] = b[e].toString ();
}
var f = 0;
for (var g = a.indexOf ('{', 0); g >= 0; g = a.indexOf ('{', f)) {
if (g != 0 && a.charAt (g - 1) == '\\') {
if (g != 1) c.append (a.substring (f, g - 1));
c.append ('{');
f = g + 1;
} else {
if (g > a.length - 3) {
c.append (a.substring (f, a.length));
f = a.length;
} else {
var h = (a.charCodeAt (g + 1) - 48);
if (h < 0 || a.charAt (g + 2) != '}') {
c.append (a.substring (f, g + 1));
f = g + 1;
} else {
c.append (a.substring (f, g));
if (h >= d.length) c.append ("<missing argument>");
 else c.append (d[h]);
f = g + 3;
}}}}
if (f < a.length) c.append (a.substring (f, a.length));
return c.toString ();
}, "~S,~A");
c$.setLocale = Clazz.defineMethod (c$, "setLocale", 
function (a, b) {
return java.util.ResourceBundle.getBundle (b);
}, "java.util.Locale,~S");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023