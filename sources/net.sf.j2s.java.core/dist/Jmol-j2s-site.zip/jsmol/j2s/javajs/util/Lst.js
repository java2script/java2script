Clazz.declarePackage ("javajs.util");
Clazz.load (["java.util.ArrayList"], "javajs.util.Lst", null, function () {
c$ = Clazz.declareType (javajs.util, "Lst", java.util.ArrayList);
Clazz.defineMethod (c$, "addLast", 
function (v) {
{
return this.add1(v);
}}, "~O");
Clazz.defineMethod (c$, "removeItemAt", 
function (location) {
{
return this._removeItemAt(location);
}}, "~N");
Clazz.defineMethod (c$, "removeObj", 
function (v) {
{
return this._removeObject(v);
}}, "~O");
});
;//5.0.1-v1 Sun Nov 12 07:42:54 CST 2023