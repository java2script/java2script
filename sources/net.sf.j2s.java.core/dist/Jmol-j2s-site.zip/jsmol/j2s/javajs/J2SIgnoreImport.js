Clazz.declarePackage ("javajs");
;//5.0.1-v1 Sun Nov 12 07:42:54 CST 2023