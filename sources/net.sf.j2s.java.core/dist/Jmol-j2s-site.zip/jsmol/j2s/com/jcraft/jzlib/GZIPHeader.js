Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (null, "com.jcraft.jzlib.GZIPHeader", ["com.jcraft.jzlib.ZStream", "java.lang.IllegalArgumentException", "$.InternalError"], function () {
c$ = Clazz.decorateAsClass (function () {
this.text = false;
this.fhcrc = false;
this.time = 0;
this.xflags = 0;
this.os = 255;
this.extra = null;
this.name = null;
this.comment = null;
this.hcrc = 0;
this.crc = 0;
this.done = false;
this.mtime = 0;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "GZIPHeader", null, Cloneable);
Clazz.defineMethod (c$, "setModifiedTime", 
function (a) {
this.mtime = a;
}, "~N");
Clazz.defineMethod (c$, "getModifiedTime", 
function () {
return this.mtime;
});
Clazz.defineMethod (c$, "setOS", 
function (a) {
if ((0 <= a && a <= 13) || a == 255) this.os = a;
 else throw  new IllegalArgumentException ("os: " + a);
}, "~N");
Clazz.defineMethod (c$, "getOS", 
function () {
return this.os;
});
Clazz.defineMethod (c$, "setName", 
function (a) {
this.name = com.jcraft.jzlib.ZStream.getBytes (a);
}, "~S");
Clazz.defineMethod (c$, "getName", 
function () {
if (this.name == null) return "";
try {
return  String.instantialize (this.name, "ISO-8859-1");
} catch (e) {
if (Clazz.exceptionOf (e, java.io.UnsupportedEncodingException)) {
throw  new InternalError (e.toString ());
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "setComment", 
function (a) {
this.comment = com.jcraft.jzlib.ZStream.getBytes (a);
}, "~S");
Clazz.defineMethod (c$, "getComment", 
function () {
if (this.comment == null) return "";
try {
return  String.instantialize (this.comment, "ISO-8859-1");
} catch (e) {
if (Clazz.exceptionOf (e, java.io.UnsupportedEncodingException)) {
throw  new InternalError (e.toString ());
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "setCRC", 
function (a) {
this.crc = a;
}, "~N");
Clazz.defineMethod (c$, "getCRC", 
function () {
return this.crc;
});
Clazz.defineMethod (c$, "put", 
function (a) {
var b = 0;
if (this.text) {
b |= 1;
}if (this.fhcrc) {
b |= 2;
}if (this.extra != null) {
b |= 4;
}if (this.name != null) {
b |= 8;
}if (this.comment != null) {
b |= 16;
}var c = 0;
if (a.level == 1) {
c |= 4;
} else if (a.level == 9) {
c |= 2;
}a.put_short (0x8b1f);
a.put_byteB (8);
a.put_byteB (b);
a.put_byteB (this.mtime);
a.put_byteB ((this.mtime >> 8));
a.put_byteB ((this.mtime >> 16));
a.put_byteB ((this.mtime >> 24));
a.put_byteB (c);
a.put_byteB (this.os);
if (this.extra != null) {
a.put_byteB (this.extra.length);
a.put_byteB ((this.extra.length >> 8));
a.put_byte (this.extra, 0, this.extra.length);
}if (this.name != null) {
a.put_byte (this.name, 0, this.name.length);
a.put_byteB (0);
}if (this.comment != null) {
a.put_byte (this.comment, 0, this.comment.length);
a.put_byteB (0);
}}, "com.jcraft.jzlib.Deflate");
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, com.jcraft.jzlib.GZIPHeader, "clone", []);
var b;
if (a.extra != null) {
b =  Clazz.newByteArray (a.extra.length, 0);
System.arraycopy (a.extra, 0, b, 0, b.length);
a.extra = b;
}if (a.name != null) {
b =  Clazz.newByteArray (a.name.length, 0);
System.arraycopy (a.name, 0, b, 0, b.length);
a.name = b;
}if (a.comment != null) {
b =  Clazz.newByteArray (a.comment.length, 0);
System.arraycopy (a.comment, 0, b, 0, b.length);
a.comment = b;
}return a;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023