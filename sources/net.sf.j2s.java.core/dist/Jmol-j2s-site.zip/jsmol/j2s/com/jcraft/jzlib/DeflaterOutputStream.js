Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.FilterOutputStream"], "com.jcraft.jzlib.DeflaterOutputStream", ["java.io.IOException", "java.lang.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.deflater = null;
this.buffer = null;
this.closed = false;
this.syncFlush = false;
this.buf1 = null;
this.mydeflater = false;
this.close_out = true;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "DeflaterOutputStream", java.io.FilterOutputStream);
Clazz.prepareFields (c$, function () {
this.buf1 =  Clazz.newByteArray (1, 0);
});
Clazz.defineMethod (c$, "jzSetDOS", 
function (a, b, c, d) {
this.jzSetFOS (a);
if (c == 0) c = 512;
this.deflater = b;
this.buffer =  Clazz.newByteArray (c, 0);
this.close_out = d;
}, "java.io.OutputStream,com.jcraft.jzlib.Deflater,~N,~B");
Clazz.overrideMethod (c$, "writeByteAsInt", 
function (a) {
this.buf1[0] = (a & 0xff);
this.write (this.buf1, 0, 1);
}, "~N");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (this.deflater.finished ()) throw  new java.io.IOException ("finished");
if ( new Boolean ( new Boolean (b < 0 | c < 0).valueOf () | b + c > a.length).valueOf ()) throw  new IndexOutOfBoundsException ();
if (c == 0) return;
var d = this.syncFlush ? 2 : 0;
this.deflater.setInput (a, b, c, true);
while (this.deflater.avail_in > 0) {
var e = this.deflate (d);
if (e == 1) break;
}
}, "~A,~N,~N");
Clazz.defineMethod (c$, "finish", 
function () {
while (!this.deflater.finished ()) {
this.deflate (4);
}
});
Clazz.overrideMethod (c$, "close", 
function () {
if (!this.closed) {
this.finish ();
if (this.mydeflater) {
this.deflater.end ();
}if (this.close_out) this.out.close ();
this.closed = true;
}});
Clazz.defineMethod (c$, "deflate", 
function (a) {
this.deflater.setOutput (this.buffer, 0, this.buffer.length);
var b = this.deflater.deflate (a);
switch (b) {
case 0:
case 1:
break;
case -5:
if (this.deflater.avail_in <= 0 && a != 4) {
break;
}default:
throw  new java.io.IOException ("failed to deflate");
}
var c = this.deflater.next_out_index;
if (c > 0) {
this.out.write (this.buffer, 0, c);
}return b;
}, "~N");
Clazz.overrideMethod (c$, "flush", 
function () {
if (this.syncFlush && !this.deflater.finished ()) {
while (true) {
var a = this.deflate (2);
if (this.deflater.next_out_index < this.buffer.length) break;
if (a == 1) break;
}
}this.out.flush ();
});
Clazz.defineMethod (c$, "getTotalIn", 
function () {
return this.deflater.getTotalIn ();
});
Clazz.defineMethod (c$, "getTotalOut", 
function () {
return this.deflater.getTotalOut ();
});
Clazz.defineMethod (c$, "setSyncFlush", 
function (a) {
this.syncFlush = a;
}, "~B");
Clazz.defineMethod (c$, "getSyncFlush", 
function () {
return this.syncFlush;
});
Clazz.defineMethod (c$, "getDeflater", 
function () {
return this.deflater;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023