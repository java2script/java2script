Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["com.jcraft.jzlib.Tree"], "com.jcraft.jzlib.Deflate", ["com.jcraft.jzlib.CRC32", "$.GZIPHeader", "$.StaticTree"], function () {
c$ = Clazz.decorateAsClass (function () {
this.strm = null;
this.status = 0;
this.pending_buf = null;
this.pending_buf_size = 0;
this.pending_out = 0;
this.pending = 0;
this.wrap = 1;
this.data_type = 0;
this.method = 0;
this.last_flush = 0;
this.w_size = 0;
this.w_bits = 0;
this.w_mask = 0;
this.window = null;
this.window_size = 0;
this.prev = null;
this.head = null;
this.ins_h = 0;
this.hash_size = 0;
this.hash_bits = 0;
this.hash_mask = 0;
this.hash_shift = 0;
this.block_start = 0;
this.match_length = 0;
this.prev_match = 0;
this.match_available = 0;
this.strstart = 0;
this.match_start = 0;
this.lookahead = 0;
this.prev_length = 0;
this.max_chain_length = 0;
this.max_lazy_match = 0;
this.level = 0;
this.strategy = 0;
this.good_match = 0;
this.nice_match = 0;
this.dyn_ltree = null;
this.dyn_dtree = null;
this.bl_tree = null;
this.l_desc = null;
this.d_desc = null;
this.bl_desc = null;
this.bl_count = null;
this.heap = null;
this.heap_len = 0;
this.heap_max = 0;
this.depth = null;
this.l_buf = 0;
this.lit_bufsize = 0;
this.last_lit = 0;
this.d_buf = 0;
this.opt_len = 0;
this.static_len = 0;
this.matches = 0;
this.last_eob_len = 0;
this.bi_buf = 0;
this.bi_valid = 0;
this.gheader = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "Deflate");
Clazz.prepareFields (c$, function () {
this.l_desc =  new com.jcraft.jzlib.Tree ();
this.d_desc =  new com.jcraft.jzlib.Tree ();
this.bl_desc =  new com.jcraft.jzlib.Tree ();
this.bl_count =  Clazz.newShortArray (16, 0);
this.heap =  Clazz.newIntArray (573, 0);
this.depth =  Clazz.newByteArray (573, 0);
});
Clazz.makeConstructor (c$, 
function (a) {
this.strm = a;
this.dyn_ltree =  Clazz.newShortArray (1146, 0);
this.dyn_dtree =  Clazz.newShortArray (122, 0);
this.bl_tree =  Clazz.newShortArray (78, 0);
}, "com.jcraft.jzlib.ZStream");
Clazz.defineMethod (c$, "deflateInit", 
function (a) {
return this.deflateInit2 (a, 15);
}, "~N");
Clazz.defineMethod (c$, "deflateInit2", 
function (a, b) {
return this.deflateInit5 (a, 8, b, 8, 0);
}, "~N,~N");
Clazz.defineMethod (c$, "deflateInit3", 
function (a, b, c) {
return this.deflateInit5 (a, 8, b, c, 0);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "lm_init", 
function () {
this.window_size = 2 * this.w_size;
this.head[this.hash_size - 1] = 0;
for (var a = 0; a < this.hash_size - 1; a++) {
this.head[a] = 0;
}
this.max_lazy_match = com.jcraft.jzlib.Deflate.config_table[this.level].max_lazy;
this.good_match = com.jcraft.jzlib.Deflate.config_table[this.level].good_length;
this.nice_match = com.jcraft.jzlib.Deflate.config_table[this.level].nice_length;
this.max_chain_length = com.jcraft.jzlib.Deflate.config_table[this.level].max_chain;
this.strstart = 0;
this.block_start = 0;
this.lookahead = 0;
this.match_length = this.prev_length = 2;
this.match_available = 0;
this.ins_h = 0;
});
Clazz.defineMethod (c$, "tr_init", 
function () {
this.l_desc.dyn_tree = this.dyn_ltree;
this.l_desc.stat_desc = com.jcraft.jzlib.StaticTree.static_l_desc;
this.d_desc.dyn_tree = this.dyn_dtree;
this.d_desc.stat_desc = com.jcraft.jzlib.StaticTree.static_d_desc;
this.bl_desc.dyn_tree = this.bl_tree;
this.bl_desc.stat_desc = com.jcraft.jzlib.StaticTree.static_bl_desc;
this.bi_buf = 0;
this.bi_valid = 0;
this.last_eob_len = 8;
this.init_block ();
});
Clazz.defineMethod (c$, "init_block", 
function () {
for (var a = 0; a < 286; a++) this.dyn_ltree[a * 2] = 0;

for (var b = 0; b < 30; b++) this.dyn_dtree[b * 2] = 0;

for (var c = 0; c < 19; c++) this.bl_tree[c * 2] = 0;

this.dyn_ltree[512] = 1;
this.opt_len = this.static_len = 0;
this.last_lit = this.matches = 0;
});
Clazz.defineMethod (c$, "pqdownheap", 
function (a, b) {
var c = this.heap[b];
var d = b << 1;
while (d <= this.heap_len) {
if (d < this.heap_len && com.jcraft.jzlib.Deflate.smaller (a, this.heap[d + 1], this.heap[d], this.depth)) {
d++;
}if (com.jcraft.jzlib.Deflate.smaller (a, c, this.heap[d], this.depth)) break;
this.heap[b] = this.heap[d];
b = d;
d <<= 1;
}
this.heap[b] = c;
}, "~A,~N");
c$.smaller = Clazz.defineMethod (c$, "smaller", 
function (a, b, c, d) {
var e = a[b * 2];
var f = a[c * 2];
return (e < f || (e == f && d[b] <= d[c]));
}, "~A,~N,~N,~A");
Clazz.defineMethod (c$, "scan_tree", 
function (a, b) {
var c;
var d = -1;
var e;
var f = a[1];
var g = 0;
var h = 7;
var i = 4;
if (f == 0) {
h = 138;
i = 3;
}a[(b + 1) * 2 + 1] = 0xffff;
for (c = 0; c <= b; c++) {
e = f;
f = a[(c + 1) * 2 + 1];
if (++g < h && e == f) {
continue;
} else if (g < i) {
this.bl_tree[e * 2] += g;
} else if (e != 0) {
if (e != d) this.bl_tree[e * 2]++;
this.bl_tree[32]++;
} else if (g <= 10) {
this.bl_tree[34]++;
} else {
this.bl_tree[36]++;
}g = 0;
d = e;
if (f == 0) {
h = 138;
i = 3;
} else if (e == f) {
h = 6;
i = 3;
} else {
h = 7;
i = 4;
}}
}, "~A,~N");
Clazz.defineMethod (c$, "build_bl_tree", 
function () {
var a;
this.scan_tree (this.dyn_ltree, this.l_desc.max_code);
this.scan_tree (this.dyn_dtree, this.d_desc.max_code);
this.bl_desc.build_tree (this);
for (a = 18; a >= 3; a--) {
if (this.bl_tree[com.jcraft.jzlib.Tree.bl_order[a] * 2 + 1] != 0) break;
}
this.opt_len += 3 * (a + 1) + 5 + 5 + 4;
return a;
});
Clazz.defineMethod (c$, "send_all_trees", 
function (a, b, c) {
var d;
this.send_bits (a - 257, 5);
this.send_bits (b - 1, 5);
this.send_bits (c - 4, 4);
for (d = 0; d < c; d++) {
this.send_bits (this.bl_tree[com.jcraft.jzlib.Tree.bl_order[d] * 2 + 1], 3);
}
this.send_tree (this.dyn_ltree, a - 1);
this.send_tree (this.dyn_dtree, b - 1);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "send_tree", 
function (a, b) {
var c;
var d = -1;
var e;
var f = a[1];
var g = 0;
var h = 7;
var i = 4;
if (f == 0) {
h = 138;
i = 3;
}for (c = 0; c <= b; c++) {
e = f;
f = a[(c + 1) * 2 + 1];
if (++g < h && e == f) {
continue;
} else if (g < i) {
do {
this.send_code (e, this.bl_tree);
} while (--g != 0);
} else if (e != 0) {
if (e != d) {
this.send_code (e, this.bl_tree);
g--;
}this.send_code (16, this.bl_tree);
this.send_bits (g - 3, 2);
} else if (g <= 10) {
this.send_code (17, this.bl_tree);
this.send_bits (g - 3, 3);
} else {
this.send_code (18, this.bl_tree);
this.send_bits (g - 11, 7);
}g = 0;
d = e;
if (f == 0) {
h = 138;
i = 3;
} else if (e == f) {
h = 6;
i = 3;
} else {
h = 7;
i = 4;
}}
}, "~A,~N");
Clazz.defineMethod (c$, "put_byte", 
function (a, b, c) {
System.arraycopy (a, b, this.pending_buf, this.pending, c);
this.pending += c;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "put_byteB", 
function (a) {
{
this.pending_buf[this.pending++] = c&0xff;
}}, "~N");
Clazz.defineMethod (c$, "put_short", 
function (a) {
this.put_byteB ((a));
this.put_byteB ((a >>> 8));
}, "~N");
Clazz.defineMethod (c$, "putShortMSB", 
function (a) {
this.put_byteB ((a >> 8));
this.put_byteB ((a));
}, "~N");
Clazz.defineMethod (c$, "send_code", 
function (a, b) {
var c = a * 2;
this.send_bits ((b[c] & 0xffff), (b[c + 1] & 0xffff));
}, "~N,~A");
Clazz.defineMethod (c$, "send_bits", 
function (a, b) {
var c = b;
if (this.bi_valid > 16 - c) {
var d = a;
this.bi_buf |= ((d << this.bi_valid) & 0xffff);
this.put_short (this.bi_buf);
this.bi_buf = ((d >>> (16 - this.bi_valid)) & 0xffff);
this.bi_valid += c - 16;
} else {
this.bi_buf |= (((a) << this.bi_valid) & 0xffff);
this.bi_valid += c;
}}, "~N,~N");
Clazz.defineMethod (c$, "_tr_align", 
function () {
this.send_bits (2, 3);
this.send_code (256, com.jcraft.jzlib.StaticTree.static_ltree);
this.bi_flush ();
if (1 + this.last_eob_len + 10 - this.bi_valid < 9) {
this.send_bits (2, 3);
this.send_code (256, com.jcraft.jzlib.StaticTree.static_ltree);
this.bi_flush ();
}this.last_eob_len = 7;
});
Clazz.defineMethod (c$, "_tr_tally", 
function (a, b) {
this.pending_buf[this.d_buf + this.last_lit * 2] = (a >>> 8);
this.pending_buf[this.d_buf + this.last_lit * 2 + 1] = a;
this.pending_buf[this.l_buf + this.last_lit] = b;
this.last_lit++;
if (a == 0) {
this.dyn_ltree[b * 2]++;
} else {
this.matches++;
a--;
this.dyn_ltree[(com.jcraft.jzlib.Tree._length_code[b] + 256 + 1) * 2]++;
this.dyn_dtree[com.jcraft.jzlib.Tree.d_code (a) * 2]++;
}if ((this.last_lit & 0x1fff) == 0 && this.level > 2) {
var c = this.last_lit * 8;
var d = this.strstart - this.block_start;
var e;
for (e = 0; e < 30; e++) {
c += this.dyn_dtree[e * 2] * (5 + com.jcraft.jzlib.Tree.extra_dbits[e]);
}
c >>>= 3;
if ((this.matches < (Clazz.doubleToInt (this.last_lit / 2))) && c < Clazz.doubleToInt (d / 2)) return true;
}return (this.last_lit == this.lit_bufsize - 1);
}, "~N,~N");
Clazz.defineMethod (c$, "compress_block", 
function (a, b) {
var c;
var d;
var e = 0;
var f;
var g;
if (this.last_lit != 0) {
do {
c = ((this.pending_buf[this.d_buf + e * 2] << 8) & 0xff00) | (this.pending_buf[this.d_buf + e * 2 + 1] & 0xff);
d = (this.pending_buf[this.l_buf + e]) & 0xff;
e++;
if (c == 0) {
this.send_code (d, a);
} else {
f = com.jcraft.jzlib.Tree._length_code[d];
this.send_code (f + 256 + 1, a);
g = com.jcraft.jzlib.Tree.extra_lbits[f];
if (g != 0) {
d -= com.jcraft.jzlib.Tree.base_length[f];
this.send_bits (d, g);
}c--;
f = com.jcraft.jzlib.Tree.d_code (c);
this.send_code (f, b);
g = com.jcraft.jzlib.Tree.extra_dbits[f];
if (g != 0) {
c -= com.jcraft.jzlib.Tree.base_dist[f];
this.send_bits (c, g);
}}} while (e < this.last_lit);
}this.send_code (256, a);
this.last_eob_len = a[513];
}, "~A,~A");
Clazz.defineMethod (c$, "set_data_type", 
function () {
var a = 0;
var b = 0;
var c = 0;
while (a < 7) {
c += this.dyn_ltree[a * 2];
a++;
}
while (a < 128) {
b += this.dyn_ltree[a * 2];
a++;
}
while (a < 256) {
c += this.dyn_ltree[a * 2];
a++;
}
this.data_type = (c > (b >>> 2) ? 0 : 1);
});
Clazz.defineMethod (c$, "bi_flush", 
function () {
if (this.bi_valid == 16) {
this.put_short (this.bi_buf);
this.bi_buf = 0;
this.bi_valid = 0;
} else if (this.bi_valid >= 8) {
this.put_byteB (this.bi_buf);
this.bi_buf >>>= 8;
this.bi_valid -= 8;
}});
Clazz.defineMethod (c$, "bi_windup", 
function () {
if (this.bi_valid > 8) {
this.put_short (this.bi_buf);
} else if (this.bi_valid > 0) {
this.put_byteB (this.bi_buf);
}this.bi_buf = 0;
this.bi_valid = 0;
});
Clazz.defineMethod (c$, "copy_block", 
function (a, b, c) {
this.bi_windup ();
this.last_eob_len = 8;
if (c) {
this.put_short (b);
this.put_short (~b);
}this.put_byte (this.window, a, b);
}, "~N,~N,~B");
Clazz.defineMethod (c$, "flush_block_only", 
function (a) {
this._tr_flush_block (this.block_start >= 0 ? this.block_start : -1, this.strstart - this.block_start, a);
this.block_start = this.strstart;
this.strm.flush_pending ();
}, "~B");
Clazz.defineMethod (c$, "deflate_stored", 
function (a) {
var b = 0xffff;
var c;
if (b > this.pending_buf_size - 5) {
b = this.pending_buf_size - 5;
}while (true) {
if (this.lookahead <= 1) {
this.fill_window ();
if (this.lookahead == 0 && a == 0) return 0;
if (this.lookahead == 0) break;
}this.strstart += this.lookahead;
this.lookahead = 0;
c = this.block_start + b;
if (this.strstart == 0 || this.strstart >= c) {
this.lookahead = (this.strstart - c);
this.strstart = c;
this.flush_block_only (false);
if (this.strm.avail_out == 0) return 0;
}if (this.strstart - this.block_start >= this.w_size - 262) {
this.flush_block_only (false);
if (this.strm.avail_out == 0) return 0;
}}
this.flush_block_only (a == 4);
if (this.strm.avail_out == 0) return (a == 4) ? 2 : 0;
return a == 4 ? 3 : 1;
}, "~N");
Clazz.defineMethod (c$, "_tr_stored_block", 
function (a, b, c) {
this.send_bits ((0) + (c ? 1 : 0), 3);
this.copy_block (a, b, true);
}, "~N,~N,~B");
Clazz.defineMethod (c$, "_tr_flush_block", 
function (a, b, c) {
var d;
var e;
var f = 0;
if (this.level > 0) {
if (this.data_type == 2) this.set_data_type ();
this.l_desc.build_tree (this);
this.d_desc.build_tree (this);
f = this.build_bl_tree ();
d = (this.opt_len + 3 + 7) >>> 3;
e = (this.static_len + 3 + 7) >>> 3;
if (e <= d) d = e;
} else {
d = e = b + 5;
}if (b + 4 <= d && a != -1) {
this._tr_stored_block (a, b, c);
} else if (e == d) {
this.send_bits ((2) + (c ? 1 : 0), 3);
this.compress_block (com.jcraft.jzlib.StaticTree.static_ltree, com.jcraft.jzlib.StaticTree.static_dtree);
} else {
this.send_bits ((4) + (c ? 1 : 0), 3);
this.send_all_trees (this.l_desc.max_code + 1, this.d_desc.max_code + 1, f + 1);
this.compress_block (this.dyn_ltree, this.dyn_dtree);
}this.init_block ();
if (c) {
this.bi_windup ();
}}, "~N,~N,~B");
Clazz.defineMethod (c$, "fill_window", 
function () {
var a;
var b;
var c;
var d;
do {
d = (this.window_size - this.lookahead - this.strstart);
if (d == 0 && this.strstart == 0 && this.lookahead == 0) {
d = this.w_size;
} else if (d == -1) {
d--;
} else if (this.strstart >= this.w_size + this.w_size - 262) {
System.arraycopy (this.window, this.w_size, this.window, 0, this.w_size);
this.match_start -= this.w_size;
this.strstart -= this.w_size;
this.block_start -= this.w_size;
a = this.hash_size;
c = a;
do {
b = (this.head[--c] & 0xffff);
this.head[c] = (b >= this.w_size ? (b - this.w_size) : 0);
} while (--a != 0);
a = this.w_size;
c = a;
do {
b = (this.prev[--c] & 0xffff);
this.prev[c] = (b >= this.w_size ? (b - this.w_size) : 0);
} while (--a != 0);
d += this.w_size;
}if (this.strm.avail_in == 0) return;
a = this.strm.read_buf (this.window, this.strstart + this.lookahead, d);
this.lookahead += a;
if (this.lookahead >= 3) {
this.ins_h = this.window[this.strstart] & 0xff;
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[this.strstart + 1] & 0xff)) & this.hash_mask;
}} while (this.lookahead < 262 && this.strm.avail_in != 0);
});
Clazz.defineMethod (c$, "deflate_fast", 
function (a) {
var b = 0;
var c;
while (true) {
if (this.lookahead < 262) {
this.fill_window ();
if (this.lookahead < 262 && a == 0) {
return 0;
}if (this.lookahead == 0) break;
}if (this.lookahead >= 3) {
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[(this.strstart) + (2)] & 0xff)) & this.hash_mask;
b = (this.head[this.ins_h] & 0xffff);
this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
this.head[this.ins_h] = this.strstart;
}if (b != 0 && ((this.strstart - b) & 0xffff) <= this.w_size - 262) {
if (this.strategy != 2) {
this.match_length = this.longest_match (b);
}}if (this.match_length >= 3) {
c = this._tr_tally (this.strstart - this.match_start, this.match_length - 3);
this.lookahead -= this.match_length;
if (this.match_length <= this.max_lazy_match && this.lookahead >= 3) {
this.match_length--;
do {
this.strstart++;
this.ins_h = ((this.ins_h << this.hash_shift) ^ (this.window[(this.strstart) + (2)] & 0xff)) & this.hash_mask;
b = (this.head[this.ins_h] & 0xffff);
this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
this.head[this.ins_h] = this.strstart;
} while (--this.match_length != 0);
this.strstart++;
} else {
this.strstart += this.match_length;
this.match_length = 0;
this.ins_h = this.window[this.strstart] & 0xff;
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[this.strstart + 1] & 0xff)) & this.hash_mask;
}} else {
c = this._tr_tally (0, this.window[this.strstart] & 0xff);
this.lookahead--;
this.strstart++;
}if (c) {
this.flush_block_only (false);
if (this.strm.avail_out == 0) return 0;
}}
this.flush_block_only (a == 4);
if (this.strm.avail_out == 0) {
if (a == 4) return 2;
return 0;
}return a == 4 ? 3 : 1;
}, "~N");
Clazz.defineMethod (c$, "deflate_slow", 
function (a) {
var b = 0;
var c;
while (true) {
if (this.lookahead < 262) {
this.fill_window ();
if (this.lookahead < 262 && a == 0) {
return 0;
}if (this.lookahead == 0) break;
}if (this.lookahead >= 3) {
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[(this.strstart) + (2)] & 0xff)) & this.hash_mask;
b = (this.head[this.ins_h] & 0xffff);
this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
this.head[this.ins_h] = this.strstart;
}this.prev_length = this.match_length;
this.prev_match = this.match_start;
this.match_length = 2;
if (b != 0 && this.prev_length < this.max_lazy_match && ((this.strstart - b) & 0xffff) <= this.w_size - 262) {
if (this.strategy != 2) {
this.match_length = this.longest_match (b);
}if (this.match_length <= 5 && (this.strategy == 1 || (this.match_length == 3 && this.strstart - this.match_start > 4096))) {
this.match_length = 2;
}}if (this.prev_length >= 3 && this.match_length <= this.prev_length) {
var d = this.strstart + this.lookahead - 3;
c = this._tr_tally (this.strstart - 1 - this.prev_match, this.prev_length - 3);
this.lookahead -= this.prev_length - 1;
this.prev_length -= 2;
do {
if (++this.strstart <= d) {
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[(this.strstart) + (2)] & 0xff)) & this.hash_mask;
b = (this.head[this.ins_h] & 0xffff);
this.prev[this.strstart & this.w_mask] = this.head[this.ins_h];
this.head[this.ins_h] = this.strstart;
}} while (--this.prev_length != 0);
this.match_available = 0;
this.match_length = 2;
this.strstart++;
if (c) {
this.flush_block_only (false);
if (this.strm.avail_out == 0) return 0;
}} else if (this.match_available != 0) {
c = this._tr_tally (0, this.window[this.strstart - 1] & 0xff);
if (c) {
this.flush_block_only (false);
}this.strstart++;
this.lookahead--;
if (this.strm.avail_out == 0) return 0;
} else {
this.match_available = 1;
this.strstart++;
this.lookahead--;
}}
if (this.match_available != 0) {
c = this._tr_tally (0, this.window[this.strstart - 1] & 0xff);
this.match_available = 0;
}this.flush_block_only (a == 4);
if (this.strm.avail_out == 0) {
if (a == 4) return 2;
return 0;
}return a == 4 ? 3 : 1;
}, "~N");
Clazz.defineMethod (c$, "longest_match", 
function (a) {
var b = this.max_chain_length;
var c = this.strstart;
var d;
var e;
var f = this.prev_length;
var g = this.strstart > (this.w_size - 262) ? this.strstart - (this.w_size - 262) : 0;
var h = this.nice_match;
var i = this.w_mask;
var j = this.strstart + 258;
var k = this.window[c + f - 1];
var l = this.window[c + f];
if (this.prev_length >= this.good_match) {
b >>= 2;
}if (h > this.lookahead) h = this.lookahead;
do {
d = a;
if (this.window[d + f] != l || this.window[d + f - 1] != k || this.window[d] != this.window[c] || this.window[++d] != this.window[c + 1]) continue;
c += 2;
d++;
do {
} while (this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && this.window[++c] == this.window[++d] && c < j);
e = 258 - (j - c);
c = j - 258;
if (e > f) {
this.match_start = a;
f = e;
if (e >= h) break;
k = this.window[c + f - 1];
l = this.window[c + f];
}} while ((a = (this.prev[a & i] & 0xffff)) > g && --b != 0);
if (f <= this.lookahead) return f;
return this.lookahead;
}, "~N");
Clazz.defineMethod (c$, "deflateInit5", 
function (a, b, c, d, e) {
var f = 1;
this.strm.msg = null;
if (a == -1) a = 6;
if (c < 0) {
f = 0;
c = -c;
} else if (c > 15) {
f = 2;
c -= 16;
this.strm.checksum =  new com.jcraft.jzlib.CRC32 ();
}if (d < 1 || d > 9 || b != 8 || c < 9 || c > 15 || a < 0 || a > 9 || e < 0 || e > 2) {
return -2;
}this.strm.dstate = this;
this.wrap = f;
this.w_bits = c;
this.w_size = 1 << this.w_bits;
this.w_mask = this.w_size - 1;
this.hash_bits = d + 7;
this.hash_size = 1 << this.hash_bits;
this.hash_mask = this.hash_size - 1;
this.hash_shift = (Clazz.doubleToInt ((this.hash_bits + 3 - 1) / 3));
this.window =  Clazz.newByteArray (this.w_size * 2, 0);
this.prev =  Clazz.newShortArray (this.w_size, 0);
this.head =  Clazz.newShortArray (this.hash_size, 0);
this.lit_bufsize = 1 << (d + 6);
this.pending_buf =  Clazz.newByteArray (this.lit_bufsize * 4, 0);
this.pending_buf_size = this.lit_bufsize * 4;
this.d_buf = Clazz.doubleToInt (this.lit_bufsize / 2);
this.l_buf = (3) * this.lit_bufsize;
this.level = a;
this.strategy = e;
this.method = b;
return this.deflateReset ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "deflateReset", 
function () {
this.strm.total_in = this.strm.total_out = 0;
this.strm.msg = null;
this.strm.data_type = 2;
this.pending = 0;
this.pending_out = 0;
if (this.wrap < 0) {
this.wrap = -this.wrap;
}this.status = (this.wrap == 0) ? 113 : 42;
this.strm.checksum.reset ();
this.last_flush = 0;
this.tr_init ();
this.lm_init ();
return 0;
});
Clazz.defineMethod (c$, "deflateEnd", 
function () {
if (this.status != 42 && this.status != 113 && this.status != 666) {
return -2;
}this.pending_buf = null;
this.head = null;
this.prev = null;
this.window = null;
return this.status == 113 ? -3 : 0;
});
Clazz.defineMethod (c$, "deflateParams", 
function (a, b) {
var c = 0;
if (a == -1) {
a = 6;
}if (a < 0 || a > 9 || b < 0 || b > 2) {
return -2;
}if (com.jcraft.jzlib.Deflate.config_table[this.level].func != com.jcraft.jzlib.Deflate.config_table[a].func && this.strm.total_in != 0) {
c = this.strm.deflate (1);
}if (this.level != a) {
this.level = a;
this.max_lazy_match = com.jcraft.jzlib.Deflate.config_table[this.level].max_lazy;
this.good_match = com.jcraft.jzlib.Deflate.config_table[this.level].good_length;
this.nice_match = com.jcraft.jzlib.Deflate.config_table[this.level].nice_length;
this.max_chain_length = com.jcraft.jzlib.Deflate.config_table[this.level].max_chain;
}this.strategy = b;
return c;
}, "~N,~N");
Clazz.defineMethod (c$, "deflateSetDictionary", 
function (a, b) {
var c = b;
var d = 0;
if (a == null || this.status != 42) return -2;
this.strm.checksum.update (a, 0, b);
if (c < 3) return 0;
if (c > this.w_size - 262) {
c = this.w_size - 262;
d = b - c;
}System.arraycopy (a, d, this.window, 0, c);
this.strstart = c;
this.block_start = c;
this.ins_h = this.window[0] & 0xff;
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[1] & 0xff)) & this.hash_mask;
for (var e = 0; e <= c - 3; e++) {
this.ins_h = (((this.ins_h) << this.hash_shift) ^ (this.window[(e) + (2)] & 0xff)) & this.hash_mask;
this.prev[e & this.w_mask] = this.head[this.ins_h];
this.head[this.ins_h] = e;
}
return 0;
}, "~A,~N");
Clazz.defineMethod (c$, "deflate", 
function (a) {
var b;
if (a > 4 || a < 0) {
return -2;
}if (this.strm.next_out == null || (this.strm.next_in == null && this.strm.avail_in != 0) || (this.status == 666 && a != 4)) {
this.strm.msg = com.jcraft.jzlib.Deflate.z_errmsg[4];
return -2;
}if (this.strm.avail_out == 0) {
this.strm.msg = com.jcraft.jzlib.Deflate.z_errmsg[7];
return -5;
}b = this.last_flush;
this.last_flush = a;
if (this.status == 42) {
if (this.wrap == 2) {
this.getGZIPHeader ().put (this);
this.status = 113;
this.strm.checksum.reset ();
} else {
var c = (8 + ((this.w_bits - 8) << 4)) << 8;
var d = ((this.level - 1) & 0xff) >> 1;
if (d > 3) d = 3;
c |= (d << 6);
if (this.strstart != 0) c |= 32;
c += 31 - (c % 31);
this.status = 113;
this.putShortMSB (c);
if (this.strstart != 0) {
var e = this.strm.checksum.getValue ();
this.putShortMSB ((e >>> 16));
this.putShortMSB ((e & 0xffff));
}this.strm.checksum.reset ();
}}if (this.pending != 0) {
this.strm.flush_pending ();
if (this.strm.avail_out == 0) {
this.last_flush = -1;
return 0;
}} else if (this.strm.avail_in == 0 && a <= b && a != 4) {
this.strm.msg = com.jcraft.jzlib.Deflate.z_errmsg[7];
return -5;
}if (this.status == 666 && this.strm.avail_in != 0) {
this.strm.msg = com.jcraft.jzlib.Deflate.z_errmsg[7];
return -5;
}if (this.strm.avail_in != 0 || this.lookahead != 0 || (a != 0 && this.status != 666)) {
var c = -1;
switch (com.jcraft.jzlib.Deflate.config_table[this.level].func) {
case 0:
c = this.deflate_stored (a);
break;
case 1:
c = this.deflate_fast (a);
break;
case 2:
c = this.deflate_slow (a);
break;
default:
}
if (c == 2 || c == 3) {
this.status = 666;
}if (c == 0 || c == 2) {
if (this.strm.avail_out == 0) {
this.last_flush = -1;
}return 0;
}if (c == 1) {
if (a == 1) {
this._tr_align ();
} else {
this._tr_stored_block (0, 0, false);
if (a == 3) {
for (var d = 0; d < this.hash_size; d++) this.head[d] = 0;

}}this.strm.flush_pending ();
if (this.strm.avail_out == 0) {
this.last_flush = -1;
return 0;
}}}if (a != 4) return 0;
if (this.wrap <= 0) return 1;
if (this.wrap == 2) {
var c = this.strm.checksum.getValue ();
this.put_byteB ((c & 0xff));
this.put_byteB (((c >> 8) & 0xff));
this.put_byteB (((c >> 16) & 0xff));
this.put_byteB (((c >> 24) & 0xff));
this.put_byteB ((this.strm.total_in & 0xff));
this.put_byteB (((this.strm.total_in >> 8) & 0xff));
this.put_byteB (((this.strm.total_in >> 16) & 0xff));
this.put_byteB (((this.strm.total_in >> 24) & 0xff));
this.getGZIPHeader ().setCRC (c);
} else {
var c = this.strm.checksum.getValue ();
this.putShortMSB ((c >>> 16));
this.putShortMSB ((c & 0xffff));
}this.strm.flush_pending ();
if (this.wrap > 0) this.wrap = -this.wrap;
return this.pending != 0 ? 0 : 1;
}, "~N");
Clazz.defineMethod (c$, "getGZIPHeader", 
function () {
if (this.gheader == null) {
this.gheader =  new com.jcraft.jzlib.GZIPHeader ();
}return this.gheader;
});
Clazz.defineMethod (c$, "getBytesRead", 
function () {
return this.strm.total_in;
});
Clazz.defineMethod (c$, "getBytesWritten", 
function () {
return this.strm.total_out;
});
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.good_length = 0;
this.max_lazy = 0;
this.nice_length = 0;
this.max_chain = 0;
this.func = 0;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib.Deflate, "Config");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
this.good_length = a;
this.max_lazy = b;
this.nice_length = c;
this.max_chain = d;
this.func = e;
}, "~N,~N,~N,~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"config_table", null);
{
com.jcraft.jzlib.Deflate.config_table =  new Array (10);
com.jcraft.jzlib.Deflate.config_table[0] =  new com.jcraft.jzlib.Deflate.Config (0, 0, 0, 0, 0);
com.jcraft.jzlib.Deflate.config_table[1] =  new com.jcraft.jzlib.Deflate.Config (4, 4, 8, 4, 1);
com.jcraft.jzlib.Deflate.config_table[2] =  new com.jcraft.jzlib.Deflate.Config (4, 5, 16, 8, 1);
com.jcraft.jzlib.Deflate.config_table[3] =  new com.jcraft.jzlib.Deflate.Config (4, 6, 32, 32, 1);
com.jcraft.jzlib.Deflate.config_table[4] =  new com.jcraft.jzlib.Deflate.Config (4, 4, 16, 16, 2);
com.jcraft.jzlib.Deflate.config_table[5] =  new com.jcraft.jzlib.Deflate.Config (8, 16, 32, 32, 2);
com.jcraft.jzlib.Deflate.config_table[6] =  new com.jcraft.jzlib.Deflate.Config (8, 16, 128, 128, 2);
com.jcraft.jzlib.Deflate.config_table[7] =  new com.jcraft.jzlib.Deflate.Config (8, 32, 128, 256, 2);
com.jcraft.jzlib.Deflate.config_table[8] =  new com.jcraft.jzlib.Deflate.Config (32, 128, 258, 1024, 2);
com.jcraft.jzlib.Deflate.config_table[9] =  new com.jcraft.jzlib.Deflate.Config (32, 258, 258, 4096, 2);
}Clazz.defineStatics (c$,
"z_errmsg",  Clazz.newArray (-1, ["need dictionary", "stream end", "", "file error", "stream error", "data error", "insufficient memory", "buffer error", "incompatible version", ""]));
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023