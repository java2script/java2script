Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["com.jcraft.jzlib.InfTree"], "com.jcraft.jzlib.InfBlocks", ["com.jcraft.jzlib.InfCodes"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mode = 0;
this.left = 0;
this.table = 0;
this.index = 0;
this.blens = null;
this.bb = null;
this.tb = null;
this.bl = null;
this.bd = null;
this.tl = null;
this.td = null;
this.tli = null;
this.tdi = null;
this.codes = null;
this.last = 0;
this.bitk = 0;
this.bitb = 0;
this.hufts = null;
this.window = null;
this.end = 0;
this.read = 0;
this.write = 0;
this.check = false;
this.inftree = null;
this.z = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "InfBlocks");
Clazz.prepareFields (c$, function () {
this.bb =  Clazz.newIntArray (1, 0);
this.tb =  Clazz.newIntArray (1, 0);
this.bl =  Clazz.newIntArray (1, 0);
this.bd =  Clazz.newIntArray (1, 0);
this.tli =  Clazz.newIntArray (1, 0);
this.tdi =  Clazz.newIntArray (1, 0);
this.inftree =  new com.jcraft.jzlib.InfTree ();
});
Clazz.makeConstructor (c$, 
function (a, b) {
this.z = a;
this.codes =  new com.jcraft.jzlib.InfCodes (this.z, this);
this.hufts =  Clazz.newIntArray (4320, 0);
this.window =  Clazz.newByteArray (b, 0);
this.end = b;
this.check = (a.istate.wrap == 0) ? false : true;
this.mode = 0;
{
this.tl = Clazz.newArray(1, null);
this.td = Clazz.newArray(1, null);
}this.reset ();
}, "com.jcraft.jzlib.ZStream,~N");
Clazz.defineMethod (c$, "reset", 
function () {
if (this.mode == 6) {
this.codes.free (this.z);
}this.mode = 0;
this.bitk = 0;
this.bitb = 0;
this.read = this.write = 0;
if (this.check) {
this.z.checksum.reset ();
}});
Clazz.defineMethod (c$, "proc", 
function (a) {
var b;
var c;
var d;
var e;
var f;
var g;
var h;
{
e = this.z.next_in_index;
f = this.z.avail_in;
c = this.bitb;
d = this.bitk;
}{
g = this.write;
h = (g < this.read ? this.read - g - 1 : this.end - g);
}while (true) {
switch (this.mode) {
case 0:
while (d < (3)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
b = (c & 7);
this.last = b & 1;
switch (b >>> 1) {
case 0:
{
c >>>= (3);
d -= (3);
}b = d & 7;
{
c >>>= (b);
d -= (b);
}this.mode = 1;
break;
case 1:
com.jcraft.jzlib.InfTree.inflate_trees_fixed (this.bl, this.bd, this.tl, this.td, this.z);
this.codes.init (this.bl[0], this.bd[0], this.tl[0], 0, this.td[0], 0);
{
c >>>= (3);
d -= (3);
}this.mode = 6;
break;
case 2:
{
c >>>= (3);
d -= (3);
}this.mode = 3;
break;
case 3:
{
c >>>= (3);
d -= (3);
}this.mode = 9;
this.z.msg = "invalid block type";
a = -3;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}
break;
case 1:
while (d < (32)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
if ((((~c) >>> 16) & 0xffff) != (c & 0xffff)) {
this.mode = 9;
this.z.msg = "invalid stored block lengths";
a = -3;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}this.left = (c & 0xffff);
c = d = 0;
this.mode = this.left != 0 ? 2 : (this.last != 0 ? 7 : 0);
break;
case 2:
if (f == 0) {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}if (h == 0) {
if (g == this.end && this.read != 0) {
g = 0;
h = (g < this.read ? this.read - g - 1 : this.end - g);
}if (h == 0) {
this.write = g;
a = this.inflate_flush (a);
g = this.write;
h = (g < this.read ? this.read - g - 1 : this.end - g);
if (g == this.end && this.read != 0) {
g = 0;
h = (g < this.read ? this.read - g - 1 : this.end - g);
}if (h == 0) {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}}}a = 0;
b = this.left;
if (b > f) b = f;
if (b > h) b = h;
System.arraycopy (this.z.next_in, e, this.window, g, b);
e += b;
f -= b;
g += b;
h -= b;
if ((this.left -= b) != 0) break;
this.mode = this.last != 0 ? 7 : 0;
break;
case 3:
while (d < (14)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
this.table = b = (c & 0x3fff);
if ((b & 0x1f) > 29 || ((b >> 5) & 0x1f) > 29) {
this.mode = 9;
this.z.msg = "too many length or distance symbols";
a = -3;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}b = 258 + (b & 0x1f) + ((b >> 5) & 0x1f);
if (this.blens == null || this.blens.length < b) {
this.blens =  Clazz.newIntArray (b, 0);
} else {
for (var i = 0; i < b; i++) {
this.blens[i] = 0;
}
}{
c >>>= (14);
d -= (14);
}this.index = 0;
this.mode = 4;
case 4:
while (this.index < 4 + (this.table >>> 10)) {
while (d < (3)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
this.blens[com.jcraft.jzlib.InfBlocks.border[this.index++]] = c & 7;
{
c >>>= (3);
d -= (3);
}}
while (this.index < 19) {
this.blens[com.jcraft.jzlib.InfBlocks.border[this.index++]] = 0;
}
this.bb[0] = 7;
b = this.inftree.inflate_trees_bits (this.blens, this.bb, this.tb, this.hufts, this.z);
if (b != 0) {
a = b;
if (a == -3) {
this.blens = null;
this.mode = 9;
}this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}this.index = 0;
this.mode = 5;
case 5:
while (true) {
b = this.table;
if (!(this.index < 258 + (b & 0x1f) + ((b >> 5) & 0x1f))) {
break;
}var i;
var j;
var k;
b = this.bb[0];
while (d < (b)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
b = this.hufts[(this.tb[0] + (c & com.jcraft.jzlib.InfBlocks.inflate_mask[b])) * 3 + 1];
k = this.hufts[(this.tb[0] + (c & com.jcraft.jzlib.InfBlocks.inflate_mask[b])) * 3 + 2];
if (k < 16) {
c >>>= (b);
d -= (b);
this.blens[this.index++] = k;
} else {
i = k == 18 ? 7 : k - 14;
j = k == 18 ? 11 : 3;
while (d < (b + i)) {
if (f != 0) {
a = 0;
} else {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}f--;
c |= (this.z.next_in[e++] & 0xff) << d;
d += 8;
}
c >>>= (b);
d -= (b);
j += (c & com.jcraft.jzlib.InfBlocks.inflate_mask[i]);
c >>>= (i);
d -= (i);
i = this.index;
b = this.table;
if (i + j > 258 + (b & 0x1f) + ((b >> 5) & 0x1f) || (k == 16 && i < 1)) {
this.blens = null;
this.mode = 9;
this.z.msg = "invalid bit length repeat";
a = -3;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}k = k == 16 ? this.blens[i - 1] : 0;
do {
this.blens[i++] = k;
} while (--j != 0);
this.index = i;
}}
this.tb[0] = -1;
{
this.bl[0] = 9;
this.bd[0] = 6;
b = this.table;
b = this.inftree.inflate_trees_dynamic (257 + (b & 0x1f), 1 + ((b >> 5) & 0x1f), this.blens, this.bl, this.bd, this.tli, this.tdi, this.hufts, this.z);
if (b != 0) {
if (b == -3) {
this.blens = null;
this.mode = 9;
}a = b;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}this.codes.init (this.bl[0], this.bd[0], this.hufts, this.tli[0], this.hufts, this.tdi[0]);
}this.mode = 6;
case 6:
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
if ((a = this.codes.proc (a)) != 1) {
return this.inflate_flush (a);
}a = 0;
this.codes.free (this.z);
e = this.z.next_in_index;
f = this.z.avail_in;
c = this.bitb;
d = this.bitk;
g = this.write;
h = (g < this.read ? this.read - g - 1 : this.end - g);
if (this.last == 0) {
this.mode = 0;
break;
}this.mode = 7;
case 7:
this.write = g;
a = this.inflate_flush (a);
g = this.write;
h = (g < this.read ? this.read - g - 1 : this.end - g);
if (this.read != this.write) {
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}this.mode = 8;
case 8:
a = 1;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
case 9:
a = -3;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
default:
a = -2;
this.bitb = c;
this.bitk = d;
this.z.avail_in = f;
this.z.total_in += e - this.z.next_in_index;
this.z.next_in_index = e;
this.write = g;
return this.inflate_flush (a);
}
}
}, "~N");
Clazz.defineMethod (c$, "free", 
function () {
this.reset ();
this.window = null;
this.hufts = null;
});
Clazz.defineMethod (c$, "set_dictionary", 
function (a, b, c) {
System.arraycopy (a, b, this.window, 0, c);
this.read = this.write = c;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "sync_point", 
function () {
return this.mode == 1 ? 1 : 0;
});
Clazz.defineMethod (c$, "inflate_flush", 
function (a) {
var b;
var c;
var d;
c = this.z.next_out_index;
d = this.read;
b = ((d <= this.write ? this.write : this.end) - d);
if (b > this.z.avail_out) b = this.z.avail_out;
if (b != 0 && a == -5) a = 0;
this.z.avail_out -= b;
this.z.total_out += b;
if (this.check && b > 0) {
this.z.checksum.update (this.window, d, b);
}System.arraycopy (this.window, d, this.z.next_out, c, b);
c += b;
d += b;
if (d == this.end) {
d = 0;
if (this.write == this.end) this.write = 0;
b = this.write - d;
if (b > this.z.avail_out) b = this.z.avail_out;
if (b != 0 && a == -5) a = 0;
this.z.avail_out -= b;
this.z.total_out += b;
if (this.check && b > 0) {
this.z.checksum.update (this.window, d, b);
}System.arraycopy (this.window, d, this.z.next_out, c, b);
c += b;
d += b;
}this.z.next_out_index = c;
this.read = d;
return a;
}, "~N");
Clazz.defineStatics (c$,
"inflate_mask",  Clazz.newIntArray (-1, [0x00000000, 0x00000001, 0x00000003, 0x00000007, 0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f, 0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff, 0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff, 0x0000ffff]),
"border",  Clazz.newIntArray (-1, [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]));
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023