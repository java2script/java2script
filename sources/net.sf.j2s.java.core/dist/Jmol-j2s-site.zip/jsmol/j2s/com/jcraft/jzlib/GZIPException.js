Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.GZIPException", null, function () {
c$ = Clazz.declareType (com.jcraft.jzlib, "GZIPException", java.io.IOException);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023