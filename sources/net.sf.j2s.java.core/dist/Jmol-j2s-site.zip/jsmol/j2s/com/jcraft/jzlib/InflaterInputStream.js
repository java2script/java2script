Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.FilterInputStream"], "com.jcraft.jzlib.InflaterInputStream", ["java.io.EOFException", "$.IOException", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.inflater = null;
this.buf = null;
this.len = 0;
this.closed = false;
this.eof = false;
this.close_in = true;
this.myinflater = false;
this.byte1 = null;
this.b = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "InflaterInputStream", java.io.FilterInputStream);
Clazz.prepareFields (c$, function () {
this.byte1 =  Clazz.newByteArray (1, 0);
this.b =  Clazz.newByteArray (512, 0);
});
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
Clazz.superConstructor (this, com.jcraft.jzlib.InflaterInputStream, [a]);
this.inflater = b;
this.buf =  Clazz.newByteArray (c, 0);
this.close_in = d;
}, "java.io.InputStream,com.jcraft.jzlib.Inflater,~N,~B");
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
if (this.closed) {
throw  new java.io.IOException ("Stream closed");
}return this.read (this.byte1, 0, 1) == -1 ? -1 : this.byte1[0] & 0xff;
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
return this.readInf (a, b, c);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "readInf", 
function (a, b, c) {
if (this.closed) {
throw  new java.io.IOException ("Stream closed");
}if (a == null) {
throw  new NullPointerException ();
} else if (b < 0 || c < 0 || c > a.length - b) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
} else if (this.eof) {
return -1;
}var d = 0;
this.inflater.setOutput (a, b, c);
while (!this.eof) {
if (this.inflater.avail_in == 0) this.fill ();
var e = this.inflater.inflate (0);
d += this.inflater.next_out_index - b;
b = this.inflater.next_out_index;
switch (e) {
case -3:
throw  new java.io.IOException (this.inflater.msg);
case 1:
case 2:
this.eof = true;
if (e == 2) return -1;
break;
default:
}
if (this.inflater.avail_out == 0) break;
}
return d;
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "available", 
function () {
if (this.closed) {
throw  new java.io.IOException ("Stream closed");
}return (this.eof ? 0 : 1);
});
Clazz.overrideMethod (c$, "skip", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("negative skip length");
}if (this.closed) {
throw  new java.io.IOException ("Stream closed");
}var b = Math.min (a, 2147483647);
var c = 0;
while (c < b) {
var d = b - c;
if (d > this.b.length) {
d = this.b.length;
}d = this.read (this.b, 0, d);
if (d == -1) {
this.eof = true;
break;
}c += d;
}
return c;
}, "~N");
Clazz.overrideMethod (c$, "close", 
function () {
if (!this.closed) {
if (this.myinflater) this.inflater.end ();
if (this.close_in) this.$in.close ();
this.closed = true;
}});
Clazz.defineMethod (c$, "fill", 
function () {
if (this.closed) {
throw  new java.io.IOException ("Stream closed");
}this.len = this.$in.read (this.buf, 0, this.buf.length);
if (this.len == -1) {
if (this.inflater.istate.wrap == 0 && !this.inflater.finished ()) {
this.buf[0] = 0;
this.len = 1;
} else if (this.inflater.istate.was != -1) {
throw  new java.io.IOException ("footer is not found");
} else {
throw  new java.io.EOFException ("Unexpected end of ZLIB input stream");
}}this.inflater.setInput (this.buf, 0, this.len, true);
});
Clazz.overrideMethod (c$, "markSupported", 
function () {
return false;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
throw  new java.io.IOException ("mark/reset not supported");
});
Clazz.defineMethod (c$, "getTotalIn", 
function () {
return this.inflater.getTotalIn ();
});
Clazz.defineMethod (c$, "getTotalOut", 
function () {
return this.inflater.getTotalOut ();
});
Clazz.defineMethod (c$, "getAvailIn", 
function () {
if (this.inflater.avail_in <= 0) return null;
var a =  Clazz.newByteArray (this.inflater.avail_in, 0);
System.arraycopy (this.inflater.next_in, this.inflater.next_in_index, a, 0, this.inflater.avail_in);
return a;
});
Clazz.defineMethod (c$, "readHeader", 
function () {
var a = "".getBytes ();
this.inflater.setInput (a, 0, 0, false);
this.inflater.setOutput (a, 0, 0);
var b = this.inflater.inflate (0);
if (!this.inflater.istate.inParsingHeader ()) {
return;
}var c =  Clazz.newByteArray (1, 0);
do {
var d = this.$in.read (c, 0, 1);
if (d <= 0) throw  new java.io.IOException ("no input");
this.inflater.setInput (c, 0, c.length, false);
b = this.inflater.inflate (0);
if (b != 0) throw  new java.io.IOException (this.inflater.msg);
} while (this.inflater.istate.inParsingHeader ());
});
Clazz.defineMethod (c$, "getInflater", 
function () {
return this.inflater;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023