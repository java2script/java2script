Clazz.declarePackage ("com.jcraft.jzlib");
c$ = Clazz.decorateAsClass (function () {
this.mode = 0;
this.len = 0;
this.tree = null;
this.tree_index = 0;
this.need = 0;
this.lit = 0;
this.get = 0;
this.dist = 0;
this.lbits = 0;
this.dbits = 0;
this.ltree = null;
this.ltree_index = 0;
this.dtree = null;
this.dtree_index = 0;
this.z = null;
this.s = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "InfCodes");
Clazz.makeConstructor (c$, 
function (a, b) {
this.z = a;
this.s = b;
}, "com.jcraft.jzlib.ZStream,com.jcraft.jzlib.InfBlocks");
Clazz.defineMethod (c$, "init", 
function (a, b, c, d, e, f) {
this.mode = 0;
this.lbits = a;
this.dbits = b;
this.ltree = c;
this.ltree_index = d;
this.dtree = e;
this.dtree_index = f;
this.tree = null;
}, "~N,~N,~A,~N,~A,~N");
Clazz.defineMethod (c$, "proc", 
function (a) {
var b;
var c;
var d;
var e = 0;
var f = 0;
var g = 0;
var h;
var i;
var j;
var k;
g = this.z.next_in_index;
h = this.z.avail_in;
e = this.s.bitb;
f = this.s.bitk;
i = this.s.write;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
while (true) {
switch (this.mode) {
case 0:
if (j >= 258 && h >= 10) {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
a = this.inflate_fast (this.lbits, this.dbits, this.ltree, this.ltree_index, this.dtree, this.dtree_index, this.s, this.z);
g = this.z.next_in_index;
h = this.z.avail_in;
e = this.s.bitb;
f = this.s.bitk;
i = this.s.write;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
if (a != 0) {
this.mode = a == 1 ? 7 : 9;
break;
}}this.need = this.lbits;
this.tree = this.ltree;
this.tree_index = this.ltree_index;
this.mode = 1;
case 1:
b = this.need;
while (f < (b)) {
if (h != 0) a = 0;
 else {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}h--;
e |= (this.z.next_in[g++] & 0xff) << f;
f += 8;
}
c = (this.tree_index + (e & com.jcraft.jzlib.InfCodes.inflate_mask[b])) * 3;
e >>>= (this.tree[c + 1]);
f -= (this.tree[c + 1]);
d = this.tree[c];
if (d == 0) {
this.lit = this.tree[c + 2];
this.mode = 6;
break;
}if ((d & 16) != 0) {
this.get = d & 15;
this.len = this.tree[c + 2];
this.mode = 2;
break;
}if ((d & 64) == 0) {
this.need = d;
this.tree_index = Clazz.doubleToInt (c / 3) + this.tree[c + 2];
break;
}if ((d & 32) != 0) {
this.mode = 7;
break;
}this.mode = 9;
this.z.msg = "invalid literal/length code";
a = -3;
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
case 2:
b = this.get;
while (f < (b)) {
if (h != 0) a = 0;
 else {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}h--;
e |= (this.z.next_in[g++] & 0xff) << f;
f += 8;
}
this.len += (e & com.jcraft.jzlib.InfCodes.inflate_mask[b]);
e >>= b;
f -= b;
this.need = this.dbits;
this.tree = this.dtree;
this.tree_index = this.dtree_index;
this.mode = 3;
case 3:
b = this.need;
while (f < (b)) {
if (h != 0) a = 0;
 else {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}h--;
e |= (this.z.next_in[g++] & 0xff) << f;
f += 8;
}
c = (this.tree_index + (e & com.jcraft.jzlib.InfCodes.inflate_mask[b])) * 3;
e >>= this.tree[c + 1];
f -= this.tree[c + 1];
d = (this.tree[c]);
if ((d & 16) != 0) {
this.get = d & 15;
this.dist = this.tree[c + 2];
this.mode = 4;
break;
}if ((d & 64) == 0) {
this.need = d;
this.tree_index = Clazz.doubleToInt (c / 3) + this.tree[c + 2];
break;
}this.mode = 9;
this.z.msg = "invalid distance code";
a = -3;
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
case 4:
b = this.get;
while (f < (b)) {
if (h != 0) a = 0;
 else {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}h--;
e |= (this.z.next_in[g++] & 0xff) << f;
f += 8;
}
this.dist += (e & com.jcraft.jzlib.InfCodes.inflate_mask[b]);
e >>= b;
f -= b;
this.mode = 5;
case 5:
k = i - this.dist;
while (k < 0) {
k += this.s.end;
}
while (this.len != 0) {
if (j == 0) {
if (i == this.s.end && this.s.read != 0) {
i = 0;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
}if (j == 0) {
this.s.write = i;
a = this.s.inflate_flush (a);
i = this.s.write;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
if (i == this.s.end && this.s.read != 0) {
i = 0;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
}if (j == 0) {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}}}this.s.window[i++] = this.s.window[k++];
j--;
if (k == this.s.end) k = 0;
this.len--;
}
this.mode = 0;
break;
case 6:
if (j == 0) {
if (i == this.s.end && this.s.read != 0) {
i = 0;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
}if (j == 0) {
this.s.write = i;
a = this.s.inflate_flush (a);
i = this.s.write;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
if (i == this.s.end && this.s.read != 0) {
i = 0;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
}if (j == 0) {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}}}a = 0;
this.s.window[i++] = this.lit;
j--;
this.mode = 0;
break;
case 7:
if (f > 7) {
f -= 8;
h++;
g--;
}this.s.write = i;
a = this.s.inflate_flush (a);
i = this.s.write;
j = i < this.s.read ? this.s.read - i - 1 : this.s.end - i;
if (this.s.read != this.s.write) {
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}this.mode = 8;
case 8:
a = 1;
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
case 9:
a = -3;
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
default:
a = -2;
this.s.bitb = e;
this.s.bitk = f;
this.z.avail_in = h;
this.z.total_in += g - this.z.next_in_index;
this.z.next_in_index = g;
this.s.write = i;
return this.s.inflate_flush (a);
}
}
}, "~N");
Clazz.defineMethod (c$, "free", 
function (a) {
}, "com.jcraft.jzlib.ZStream");
Clazz.defineMethod (c$, "inflate_fast", 
function (a, b, c, d, e, f, g, h) {
var i;
var j;
var k;
var l;
var m;
var n;
var o;
var p;
var q;
var r;
var s;
var t;
var u;
var v;
var w;
var x;
o = h.next_in_index;
p = h.avail_in;
m = g.bitb;
n = g.bitk;
q = g.write;
r = q < g.read ? g.read - q - 1 : g.end - q;
s = com.jcraft.jzlib.InfCodes.inflate_mask[a];
t = com.jcraft.jzlib.InfCodes.inflate_mask[b];
do {
while (n < (20)) {
p--;
m |= (h.next_in[o++] & 0xff) << n;
n += 8;
}
i = m & s;
j = c;
k = d;
x = (k + i) * 3;
if ((l = j[x]) == 0) {
m >>= (j[x + 1]);
n -= (j[x + 1]);
g.window[q++] = j[x + 2];
r--;
continue;
}do {
m >>= (j[x + 1]);
n -= (j[x + 1]);
if ((l & 16) != 0) {
l &= 15;
u = j[x + 2] + (m & com.jcraft.jzlib.InfCodes.inflate_mask[l]);
m >>= l;
n -= l;
while (n < (15)) {
p--;
m |= (h.next_in[o++] & 0xff) << n;
n += 8;
}
i = m & t;
j = e;
k = f;
x = (k + i) * 3;
l = j[x];
do {
m >>= (j[x + 1]);
n -= (j[x + 1]);
if ((l & 16) != 0) {
l &= 15;
while (n < (l)) {
p--;
m |= (h.next_in[o++] & 0xff) << n;
n += 8;
}
v = j[x + 2] + (m & com.jcraft.jzlib.InfCodes.inflate_mask[l]);
m >>= (l);
n -= (l);
r -= u;
if (q >= v) {
w = q - v;
if (q - w > 0 && 2 > (q - w)) {
g.window[q++] = g.window[w++];
g.window[q++] = g.window[w++];
u -= 2;
} else {
System.arraycopy (g.window, w, g.window, q, 2);
q += 2;
w += 2;
u -= 2;
}} else {
w = q - v;
do {
w += g.end;
} while (w < 0);
l = g.end - w;
if (u > l) {
u -= l;
if (q - w > 0 && l > (q - w)) {
do {
g.window[q++] = g.window[w++];
} while (--l != 0);
} else {
System.arraycopy (g.window, w, g.window, q, l);
q += l;
w += l;
l = 0;
}w = 0;
}}if (q - w > 0 && u > (q - w)) {
do {
g.window[q++] = g.window[w++];
} while (--u != 0);
} else {
System.arraycopy (g.window, w, g.window, q, u);
q += u;
w += u;
u = 0;
}break;
} else if ((l & 64) == 0) {
i += j[x + 2];
i += (m & com.jcraft.jzlib.InfCodes.inflate_mask[l]);
x = (k + i) * 3;
l = j[x];
} else {
h.msg = "invalid distance code";
u = h.avail_in - p;
u = (n >> 3) < u ? n >> 3 : u;
p += u;
o -= u;
n -= u << 3;
g.bitb = m;
g.bitk = n;
h.avail_in = p;
h.total_in += o - h.next_in_index;
h.next_in_index = o;
g.write = q;
return -3;
}} while (true);
break;
}if ((l & 64) == 0) {
i += j[x + 2];
i += (m & com.jcraft.jzlib.InfCodes.inflate_mask[l]);
x = (k + i) * 3;
if ((l = j[x]) == 0) {
m >>= (j[x + 1]);
n -= (j[x + 1]);
g.window[q++] = j[x + 2];
r--;
break;
}} else if ((l & 32) != 0) {
u = h.avail_in - p;
u = (n >> 3) < u ? n >> 3 : u;
p += u;
o -= u;
n -= u << 3;
g.bitb = m;
g.bitk = n;
h.avail_in = p;
h.total_in += o - h.next_in_index;
h.next_in_index = o;
g.write = q;
return 1;
} else {
h.msg = "invalid literal/length code";
u = h.avail_in - p;
u = (n >> 3) < u ? n >> 3 : u;
p += u;
o -= u;
n -= u << 3;
g.bitb = m;
g.bitk = n;
h.avail_in = p;
h.total_in += o - h.next_in_index;
h.next_in_index = o;
g.write = q;
return -3;
}} while (true);
} while (r >= 258 && p >= 10);
u = h.avail_in - p;
u = (n >> 3) < u ? n >> 3 : u;
p += u;
o -= u;
n -= u << 3;
g.bitb = m;
g.bitk = n;
h.avail_in = p;
h.total_in += o - h.next_in_index;
h.next_in_index = o;
g.write = q;
return 0;
}, "~N,~N,~A,~N,~A,~N,com.jcraft.jzlib.InfBlocks,com.jcraft.jzlib.ZStream");
Clazz.defineStatics (c$,
"inflate_mask",  Clazz.newIntArray (-1, [0x00000000, 0x00000001, 0x00000003, 0x00000007, 0x0000000f, 0x0000001f, 0x0000003f, 0x0000007f, 0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff, 0x00000fff, 0x00001fff, 0x00003fff, 0x00007fff, 0x0000ffff]));
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023