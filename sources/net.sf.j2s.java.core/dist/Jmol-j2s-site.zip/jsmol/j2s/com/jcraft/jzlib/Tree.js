Clazz.declarePackage ("com.jcraft.jzlib");
c$ = Clazz.decorateAsClass (function () {
this.dyn_tree = null;
this.max_code = 0;
this.stat_desc = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "Tree");
c$.d_code = Clazz.defineMethod (c$, "d_code", 
function (a) {
return ((a) < 256 ? com.jcraft.jzlib.Tree._dist_code[a] : com.jcraft.jzlib.Tree._dist_code[256 + ((a) >>> 7)]);
}, "~N");
Clazz.defineMethod (c$, "gen_bitlen", 
function (a) {
var b = this.dyn_tree;
var c = this.stat_desc.static_tree;
var d = this.stat_desc.extra_bits;
var e = this.stat_desc.extra_base;
var f = this.stat_desc.max_length;
var g;
var h;
var i;
var j;
var k;
var l;
var m = 0;
for (j = 0; j <= 15; j++) a.bl_count[j] = 0;

b[a.heap[a.heap_max] * 2 + 1] = 0;
for (g = a.heap_max + 1; g < 573; g++) {
h = a.heap[g];
j = b[b[h * 2 + 1] * 2 + 1] + 1;
if (j > f) {
j = f;
m++;
}b[h * 2 + 1] = j;
if (h > this.max_code) continue;
a.bl_count[j]++;
k = 0;
if (h >= e) k = d[h - e];
l = b[h * 2];
a.opt_len += l * (j + k);
if (c != null) a.static_len += l * (c[h * 2 + 1] + k);
}
if (m == 0) return;
do {
j = f - 1;
while (a.bl_count[j] == 0) j--;

a.bl_count[j]--;
a.bl_count[j + 1] += 2;
a.bl_count[f]--;
m -= 2;
} while (m > 0);
for (j = f; j != 0; j--) {
h = a.bl_count[j];
while (h != 0) {
i = a.heap[--g];
if (i > this.max_code) continue;
if (b[i * 2 + 1] != j) {
a.opt_len += (j - b[i * 2 + 1]) * b[i * 2];
b[i * 2 + 1] = j;
}h--;
}
}
}, "com.jcraft.jzlib.Deflate");
Clazz.defineMethod (c$, "build_tree", 
function (a) {
var b = this.dyn_tree;
var c = this.stat_desc.static_tree;
var d = this.stat_desc.elems;
var e;
var f;
var g = -1;
var h;
a.heap_len = 0;
a.heap_max = 573;
for (e = 0; e < d; e++) {
if (b[e * 2] != 0) {
a.heap[++a.heap_len] = g = e;
a.depth[e] = 0;
} else {
b[e * 2 + 1] = 0;
}}
while (a.heap_len < 2) {
h = a.heap[++a.heap_len] = (g < 2 ? ++g : 0);
b[h * 2] = 1;
a.depth[h] = 0;
a.opt_len--;
if (c != null) a.static_len -= c[h * 2 + 1];
}
this.max_code = g;
for (e = Clazz.doubleToInt (a.heap_len / 2); e >= 1; e--) a.pqdownheap (b, e);

h = d;
do {
e = a.heap[1];
a.heap[1] = a.heap[a.heap_len--];
a.pqdownheap (b, 1);
f = a.heap[1];
a.heap[--a.heap_max] = e;
a.heap[--a.heap_max] = f;
b[h * 2] = (b[e * 2] + b[f * 2]);
a.depth[h] = (Math.max (a.depth[e], a.depth[f]) + 1);
b[e * 2 + 1] = b[f * 2 + 1] = h;
a.heap[1] = h++;
a.pqdownheap (b, 1);
} while (a.heap_len >= 2);
a.heap[--a.heap_max] = a.heap[1];
this.gen_bitlen (a);
com.jcraft.jzlib.Tree.gen_codes (b, g, a.bl_count);
}, "com.jcraft.jzlib.Deflate");
c$.gen_codes = Clazz.defineMethod (c$, "gen_codes", 
function (a, b, c) {
var d = 0;
var e;
var f;
com.jcraft.jzlib.Tree.next_code[0] = 0;
for (e = 1; e <= 15; e++) {
com.jcraft.jzlib.Tree.next_code[e] = d = ((d + c[e - 1]) << 1);
}
for (f = 0; f <= b; f++) {
var g = a[f * 2 + 1];
if (g == 0) continue;
a[f * 2] = (com.jcraft.jzlib.Tree.bi_reverse (com.jcraft.jzlib.Tree.next_code[g]++, g));
}
}, "~A,~N,~A");
c$.bi_reverse = Clazz.defineMethod (c$, "bi_reverse", 
function (a, b) {
var c = 0;
do {
c |= a & 1;
a >>>= 1;
c <<= 1;
} while (--b > 0);
return c >>> 1;
}, "~N,~N");
Clazz.defineStatics (c$,
"extra_lbits",  Clazz.newIntArray (-1, [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
"extra_dbits",  Clazz.newIntArray (-1, [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
"extra_blbits",  Clazz.newIntArray (-1, [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
"bl_order",  Clazz.newByteArray (-1, [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
"_dist_code",  Clazz.newByteArray (-1, [0, 1, 2, 3, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 0, 0, 16, 17, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29]),
"_length_code",  Clazz.newByteArray (-1, [0, 1, 2, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 27, 28]),
"base_length",  Clazz.newIntArray (-1, [0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 0]),
"base_dist",  Clazz.newIntArray (-1, [0, 1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096, 6144, 8192, 12288, 16384, 24576]),
"next_code",  Clazz.newShortArray (16, 0));
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023