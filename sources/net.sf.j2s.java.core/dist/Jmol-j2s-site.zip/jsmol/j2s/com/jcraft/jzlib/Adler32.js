Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["com.jcraft.jzlib.Checksum"], "com.jcraft.jzlib.Adler32", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.s1 = 1;
this.s2 = 0;
this.b1 = null;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "Adler32", null, com.jcraft.jzlib.Checksum);
Clazz.prepareFields (c$, function () {
this.b1 =  Clazz.newByteArray (1, 0);
});
Clazz.overrideMethod (c$, "resetLong", 
function (a) {
this.s1 = a & 0xffff;
this.s2 = (a >> 16) & 0xffff;
}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
this.s1 = 1;
this.s2 = 0;
});
Clazz.overrideMethod (c$, "getValue", 
function () {
return ((this.s2 << 16) | this.s1);
});
Clazz.overrideMethod (c$, "update", 
function (a, b, c) {
if (c == 1) {
this.s1 += a[b++] & 0xff;
this.s2 += this.s1;
this.s1 %= 65521;
this.s2 %= 65521;
return;
}var d = Clazz.doubleToInt (c / 5552);
var e = c % 5552;
while (d-- > 0) {
var f = 5552;
c -= f;
while (f-- > 0) {
this.s1 += a[b++] & 0xff;
this.s2 += this.s1;
}
this.s1 %= 65521;
this.s2 %= 65521;
}
var f = e;
c -= f;
while (f-- > 0) {
this.s1 += a[b++] & 0xff;
this.s2 += this.s1;
}
this.s1 %= 65521;
this.s2 %= 65521;
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "updateByteAsInt", 
function (a) {
this.b1[0] = a;
this.update (this.b1, 0, 1);
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023