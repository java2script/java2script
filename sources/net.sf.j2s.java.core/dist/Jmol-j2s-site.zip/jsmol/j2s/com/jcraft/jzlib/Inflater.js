Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["com.jcraft.jzlib.ZStream"], "com.jcraft.jzlib.Inflater", ["com.jcraft.jzlib.Inflate"], function () {
c$ = Clazz.declareType (com.jcraft.jzlib, "Inflater", com.jcraft.jzlib.ZStream);
Clazz.defineMethod (c$, "init", 
function (a, b) {
this.setAdler32 ();
if (a == 0) a = 15;
this.istate =  new com.jcraft.jzlib.Inflate (this);
this.istate.inflateInit (b ? -a : a);
return this;
}, "~N,~B");
Clazz.overrideMethod (c$, "inflate", 
function (a) {
if (this.istate == null) return -2;
var b = this.istate.inflate (a);
return b;
}, "~N");
Clazz.overrideMethod (c$, "end", 
function () {
if (this.istate == null) return -2;
var a = this.istate.inflateEnd ();
return a;
});
Clazz.defineMethod (c$, "sync", 
function () {
if (this.istate == null) return -2;
return this.istate.inflateSync ();
});
Clazz.defineMethod (c$, "syncPoint", 
function () {
if (this.istate == null) return -2;
return this.istate.inflateSyncPoint ();
});
Clazz.defineMethod (c$, "setDictionary", 
function (a, b) {
if (this.istate == null) return -2;
return this.istate.inflateSetDictionary (a, b);
}, "~A,~N");
Clazz.overrideMethod (c$, "finished", 
function () {
return this.istate.mode == 12;
});
Clazz.defineMethod (c$, "reset", 
function () {
this.avail_in = 0;
if (this.istate != null) this.istate.reset ();
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023