Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["com.jcraft.jzlib.ZStream"], "com.jcraft.jzlib.Deflater", ["com.jcraft.jzlib.Deflate"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$finished = false;
Clazz.instantialize (this, arguments);
}, com.jcraft.jzlib, "Deflater", com.jcraft.jzlib.ZStream);
Clazz.defineMethod (c$, "init", 
function (a, b, c) {
if (b == 0) b = 15;
this.$finished = false;
this.setAdler32 ();
this.dstate =  new com.jcraft.jzlib.Deflate (this);
this.dstate.deflateInit2 (a, c ? -b : b);
return this;
}, "~N,~N,~B");
Clazz.overrideMethod (c$, "deflate", 
function (a) {
if (this.dstate == null) {
return -2;
}var b = this.dstate.deflate (a);
if (b == 1) this.$finished = true;
return b;
}, "~N");
Clazz.overrideMethod (c$, "end", 
function () {
this.$finished = true;
if (this.dstate == null) return -2;
var a = this.dstate.deflateEnd ();
this.dstate = null;
this.free ();
return a;
});
Clazz.defineMethod (c$, "params", 
function (a, b) {
if (this.dstate == null) return -2;
return this.dstate.deflateParams (a, b);
}, "~N,~N");
Clazz.defineMethod (c$, "setDictionary", 
function (a, b) {
if (this.dstate == null) return -2;
return this.dstate.deflateSetDictionary (a, b);
}, "~A,~N");
Clazz.overrideMethod (c$, "finished", 
function () {
return this.$finished;
});
Clazz.defineMethod (c$, "finish", 
function () {
});
Clazz.defineMethod (c$, "getBytesRead", 
function () {
return this.dstate.getBytesRead ();
});
Clazz.defineMethod (c$, "getBytesWritten", 
function () {
return this.dstate.getBytesWritten ();
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023