Clazz.declarePackage ("java.net");
Clazz.load (null, "java.net.URLConnection", ["java.lang.IllegalStateException", "$.NullPointerException", "java.net.UnknownServiceException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.url = null;
this.doInput = true;
this.doOutput = false;
this.connected = false;
this.requests = null;
Clazz.instantialize (this, arguments);
}, java.net, "URLConnection");
Clazz.defineMethod (c$, "setDoInput", 
function (a) {
if (this.connected) throw  new IllegalStateException ("Already connected");
this.doInput = a;
}, "~B");
Clazz.defineMethod (c$, "getDoInput", 
function () {
return this.doInput;
});
Clazz.defineMethod (c$, "setDoOutput", 
function (a) {
if (this.connected) throw  new IllegalStateException ("Already connected");
this.doOutput = a;
}, "~B");
Clazz.defineMethod (c$, "getDoOutput", 
function () {
return this.doOutput;
});
Clazz.makeConstructor (c$, 
function (a) {
this.url = a;
}, "java.net.URL");
Clazz.defineMethod (c$, "getURL", 
function () {
return this.url;
});
Clazz.defineMethod (c$, "getInputStream", 
function () {
throw  new java.net.UnknownServiceException ("protocol doesn't support input");
});
Clazz.defineMethod (c$, "getOutputStream", 
function () {
throw  new java.net.UnknownServiceException ("protocol doesn't support output");
});
Clazz.defineMethod (c$, "setRequestProperty", 
function (a, b) {
if (this.connected) throw  new IllegalStateException ("Already connected");
if (a == null) throw  new NullPointerException ("key is null");
if (this.requests == null) this.requests =  new java.util.ArrayList ();
for (var c = this.requests.size (); --c >= 0; ) if (this.requests.get (c)[0].equals (a)) {
this.requests.get (c)[1] = b;
return;
}
this.requests.add ( Clazz.newArray (-1, [a, b]));
}, "~S,~S");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023