Clazz.declarePackage ("java.net");
Clazz.load (null, "java.net.URLStreamHandler", ["java.lang.IllegalArgumentException", "$.SecurityException", "$.UnsupportedOperationException"], function () {
c$ = Clazz.declareType (java.net, "URLStreamHandler");
Clazz.defineMethod (c$, "openConnectionProxy", 
function (a, b) {
throw  new UnsupportedOperationException ("Method not implemented.");
}, "java.net.URL,java.net.Proxy");
Clazz.defineMethod (c$, "parseURL", 
function (a, b, c, d) {
var e = a.getProtocol ();
var f = a.getAuthority ();
var g = a.getUserInfo ();
var h = a.getHost ();
var i = a.getPort ();
var j = a.getPath ();
var k = a.getQuery ();
var l = a.getRef ();
var m = false;
var n = false;
if (c < d) {
var o = b.indexOf ('?');
n = o == c;
if ((o != -1) && (o < d)) {
k = b.substring (o + 1, d);
if (d > o) d = o;
b = b.substring (0, o);
}}var o = 0;
var p = (c <= d - 4) && (b.charAt (c) == '/') && (b.charAt (c + 1) == '/') && (b.charAt (c + 2) == '/') && (b.charAt (c + 3) == '/');
if (!p && (c <= d - 2) && (b.charAt (c) == '/') && (b.charAt (c + 1) == '/')) {
c += 2;
o = b.indexOf ('/', c);
if (o < 0) {
o = b.indexOf ('?', c);
if (o < 0) o = d;
}h = f = b.substring (c, o);
var q = f.indexOf ('@');
if (q != -1) {
g = f.substring (0, q);
h = f.substring (q + 1);
} else {
g = null;
}if (h != null) {
if (h.length > 0 && (h.charAt (0) == '[')) {
throw  new IllegalArgumentException ("Invalid host: " + h);
}q = h.indexOf (':');
i = -1;
if (q >= 0) {
if (h.length > (q + 1)) {
i = Integer.parseInt (h.substring (q + 1));
}h = h.substring (0, q);
}} else {
h = "";
}if (i < -1) throw  new IllegalArgumentException ("Invalid port number :" + i);
c = o;
if (f.length > 0) j = "";
}if (h == null) {
h = "";
}if (c < d) {
if (b.charAt (c) == '/') {
j = b.substring (c, d);
} else if (j != null && j.length > 0) {
m = true;
var q = j.lastIndexOf ('/');
var r = "";
if (q == -1 && f != null) r = "/";
j = j.substring (0, q + 1) + r + b.substring (c, d);
} else {
var q = (f != null) ? "/" : "";
j = q + b.substring (c, d);
}} else if (n && j != null) {
var q = j.lastIndexOf ('/');
if (q < 0) q = 0;
j = j.substring (0, q) + "/";
}if (j == null) j = "";
if (m) {
while ((o = j.indexOf ("/./")) >= 0) {
j = j.substring (0, o) + j.substring (o + 2);
}
o = 0;
while ((o = j.indexOf ("/../", o)) >= 0) {
if (o > 0 && (d = j.lastIndexOf ('/', o - 1)) >= 0 && (j.indexOf ("/../", d) != 0)) {
j = j.substring (0, d) + j.substring (o + 3);
o = 0;
} else {
o = o + 3;
}}
while (j.endsWith ("/..")) {
o = j.indexOf ("/..");
if ((d = j.lastIndexOf ('/', o - 1)) >= 0) {
j = j.substring (0, d + 1);
} else {
break;
}}
if (j.startsWith ("./") && j.length > 2) j = j.substring (2);
if (j.endsWith ("/.")) j = j.substring (0, j.length - 1);
}this.setURL (a, e, h, i, f, g, j, k, l);
}, "java.net.URL,~S,~N,~N");
Clazz.defineMethod (c$, "getDefaultPort", 
function () {
return -1;
});
Clazz.defineMethod (c$, "equals2", 
function (a, b) {
var c = a.getRef ();
var d = b.getRef ();
return (c === d || (c != null && c.equals (d))) && this.sameFile (a, b);
}, "java.net.URL,java.net.URL");
Clazz.defineMethod (c$, "hashCode", 
function (a) {
var b = 0;
var c = a.getProtocol ();
if (c != null) b += c.hashCode ();
b += a.toString ().hashCode ();
var d = a.getFile ();
if (d != null) b += d.hashCode ();
if (a.getPort () == -1) b += this.getDefaultPort ();
 else b += a.getPort ();
var e = a.getRef ();
if (e != null) b += e.hashCode ();
return b;
}, "java.net.URL");
Clazz.defineMethod (c$, "sameFile", 
function (a, b) {
if (!((a.getProtocol () === b.getProtocol ()) || (a.getProtocol () != null && a.getProtocol ().equalsIgnoreCase (b.getProtocol ())))) return false;
if (!(a.getFile () === b.getFile () || (a.getFile () != null && a.getFile ().equals (b.getFile ())))) return false;
var c;
var d;
c = (a.getPort () != -1) ? a.getPort () : a.handler.getDefaultPort ();
d = (b.getPort () != -1) ? b.getPort () : b.handler.getDefaultPort ();
if (c != d) return false;
if (!this.hostsEqual (a, b)) return false;
return true;
}, "java.net.URL,java.net.URL");
Clazz.defineMethod (c$, "hostsEqual", 
function (a, b) {
if (a.getHost () != null && b.getHost () != null) return a.getHost ().equalsIgnoreCase (b.getHost ());
return a.getHost () == null && b.getHost () == null;
}, "java.net.URL,java.net.URL");
Clazz.defineMethod (c$, "toExternalForm", 
function (a) {
return "";
}, "java.net.URL");
Clazz.defineMethod (c$, "setURL", 
function (a, b, c, d, e, f, g, h, i) {
if (this !== a.handler) {
throw  new SecurityException ("handler for url different from this handler");
}a.set (a.getProtocol (), c, d, e, f, g, h, i);
}, "java.net.URL,~S,~S,~N,~S,~S,~S,~S,~S");
Clazz.defineMethod (c$, "setURLDeprecated", 
function (a, b, c, d, e, f) {
var g = null;
var h = null;
if (c != null && c.length != 0) {
g = (d == -1) ? c : c + ":" + d;
var i = c.lastIndexOf ('@');
if (i != -1) {
h = c.substring (0, i);
c = c.substring (i + 1);
}}var i = null;
var j = null;
if (e != null) {
var k = e.lastIndexOf ('?');
if (k != -1) {
j = e.substring (k + 1);
i = e.substring (0, k);
} else i = e;
}this.setURL (a, b, c, d, g, h, i, j, f);
}, "java.net.URL,~S,~S,~N,~S,~S");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023