Clazz.declarePackage ("java.net");
Clazz.load (["java.util.Hashtable"], "java.net.URL", ["java.lang.Character", "$.Error", "java.net.MalformedURLException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.protocol = null;
this.host = null;
this.port = -1;
this.file = null;
this.query = null;
this.authority = null;
this.path = null;
this.userInfo = null;
this.ref = null;
this.handler = null;
this.$hashCode = -1;
Clazz.instantialize (this, arguments);
}, java.net, "URL");
Clazz.makeConstructor (c$, 
function (a, b, c) {
{
switch (arguments.length) {
case 1:
spec = context;context = handler = null;
break;
case 2:
handler = null;
break;
case 3:
if (context == null || Clazz.instanceOf(context, java.net.URL))
break;
default:
alert("java.net.URL constructor format not supported");
break;
}
context && context.valueOf && context.valueOf() == null && (context = null);
}var d = b;
var e;
var f;
var g;
var h = 0;
var i = null;
var j = false;
var k = false;
try {
f = b.length;
while ((f > 0) && (b.charAt (f - 1) <= ' ')) {
f--;
}
while ((h < f) && (b.charAt (h) <= ' ')) {
h++;
}
if (b.regionMatches (true, h, "url:", 0, 4)) {
h += 4;
}if (h < b.length && b.charAt (h) == '#') {
j = true;
}for (e = h; !j && (e < f) && ((g = b.charCodeAt (e)) != 47); e++) {
if (g == 58) {
var l = b.substring (h, e).toLowerCase ();
if (this.isValidProtocol (l)) {
i = l;
h = e + 1;
}break;
}}
this.protocol = i;
if ((a != null) && ((i == null) || i.equalsIgnoreCase (a.protocol))) {
if (c == null) {
c = a.handler;
}if (a.path != null && a.path.startsWith ("/")) i = null;
if (i == null) {
this.protocol = a.protocol;
this.authority = a.authority;
this.userInfo = a.userInfo;
this.host = a.host;
this.port = a.port;
this.file = a.file;
this.path = a.path;
k = true;
}}if (this.protocol == null) {
throw  new java.net.MalformedURLException ("no protocol: " + d);
}if (c == null && (c = java.net.URL.getURLStreamHandler (this.protocol)) == null) {
throw  new java.net.MalformedURLException ("unknown protocol: " + this.protocol);
}this.handler = c;
e = b.indexOf ('#', h);
if (e >= 0) {
this.ref = b.substring (e + 1, f);
f = e;
}if (k && h == f) {
this.query = a.query;
if (this.ref == null) {
this.ref = a.ref;
}}c.parseURL (this, b, h, f);
} catch (e$$) {
if (Clazz.exceptionOf (e$$, java.net.MalformedURLException)) {
var e = e$$;
{
throw e;
}
} else if (Clazz.exceptionOf (e$$, Exception)) {
var e = e$$;
{
var l =  new java.net.MalformedURLException (e.getMessage ());
l.initCause (e);
throw l;
}
} else {
throw e$$;
}
}
}, "java.net.URL,~S,java.net.URLStreamHandler");
Clazz.defineMethod (c$, "isValidProtocol", 
function (a) {
var b = a.length;
if (b < 1) return false;
var c = a.charAt (0);
if (!Character.isLetter (c)) return false;
for (var d = 1; d < b; d++) {
c = a.charAt (d);
if (!Character.isLetterOrDigit (c) && c != '.' && c != '+' && c != '-') {
return false;
}}
return true;
}, "~S");
Clazz.defineMethod (c$, "set5", 
function (a, b, c, d, e) {
{
this.protocol = a;
this.host = b;
this.authority = c == -1 ? b : b + ":" + c;
this.port = c;
this.file = d;
this.ref = e;
this.$hashCode = -1;
var f = d.lastIndexOf ('?');
if (f != -1) {
this.query = d.substring (f + 1);
this.path = d.substring (0, f);
} else this.path = d;
}}, "~S,~S,~N,~S,~S");
Clazz.defineMethod (c$, "set", 
function (a, b, c, d, e, f, g, h) {
{
this.protocol = a;
this.host = b;
this.port = c;
this.file = g == null ? f : f + "?" + g;
this.userInfo = e;
this.path = f;
this.ref = h;
this.$hashCode = -1;
this.query = g;
this.authority = d;
}}, "~S,~S,~N,~S,~S,~S,~S,~S");
Clazz.defineMethod (c$, "getQuery", 
function () {
return this.query;
});
Clazz.defineMethod (c$, "getPath", 
function () {
return this.path;
});
Clazz.defineMethod (c$, "getUserInfo", 
function () {
return this.userInfo;
});
Clazz.defineMethod (c$, "getAuthority", 
function () {
return this.authority;
});
Clazz.defineMethod (c$, "getPort", 
function () {
return this.port;
});
Clazz.defineMethod (c$, "getDefaultPort", 
function () {
return this.handler.getDefaultPort ();
});
Clazz.defineMethod (c$, "getProtocol", 
function () {
return this.protocol;
});
Clazz.defineMethod (c$, "getHost", 
function () {
return this.host;
});
Clazz.defineMethod (c$, "getFile", 
function () {
return this.file;
});
Clazz.defineMethod (c$, "getRef", 
function () {
return this.ref;
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (!(Clazz.instanceOf (a, java.net.URL))) return false;
var b = a;
return this.handler.equals2 (this, b);
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
if (this.$hashCode != -1) return this.$hashCode;
this.$hashCode = this.handler.hashCode (this);
return this.$hashCode;
});
Clazz.defineMethod (c$, "sameFile", 
function (a) {
return this.handler.sameFile (this, a);
}, "java.net.URL");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.toExternalForm ();
});
Clazz.defineMethod (c$, "toExternalForm", 
function () {
return this.handler.toExternalForm (this);
});
Clazz.defineMethod (c$, "openConnection", 
function () {
return this.handler.openConnection (this);
});
Clazz.defineMethod (c$, "openStream", 
function () {
return this.openConnection ().getInputStream ();
});
Clazz.defineMethod (c$, "getContent", 
function () {
return this.openConnection ().getInputStream ();
});
c$.setURLStreamHandlerFactory = Clazz.defineMethod (c$, "setURLStreamHandlerFactory", 
function (a) {
{
if (java.net.URL.factory != null) {
throw  new Error ("factory already defined");
}var b = System.getSecurityManager ();
if (b != null) {
b.checkSetFactory ();
}java.net.URL.handlers.clear ();
java.net.URL.factory = a;
}}, "java.net.URLStreamHandlerFactory");
c$.getURLStreamHandler = Clazz.defineMethod (c$, "getURLStreamHandler", 
function (a) {
var b = java.net.URL.handlers.get (a);
if (b == null) {
if (java.net.URL.factory != null) {
b = java.net.URL.factory.createURLStreamHandler (a);
}}return b;
}, "~S");
Clazz.defineStatics (c$,
"factory", null);
c$.handlers = c$.prototype.handlers =  new java.util.Hashtable ();
c$.streamHandlerLock = c$.prototype.streamHandlerLock =  new Clazz._O ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023