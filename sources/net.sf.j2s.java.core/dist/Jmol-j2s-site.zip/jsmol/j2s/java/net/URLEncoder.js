Clazz.declarePackage ("java.net");
c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (a) {
return encodeURIComponent(arguments[0]);
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (b, c) {
return encodeURIComponent(arguments[0]);
}, "~S,~S");
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023