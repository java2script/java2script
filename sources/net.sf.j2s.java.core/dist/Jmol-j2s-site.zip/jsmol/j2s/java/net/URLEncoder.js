Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(arguments[0]);
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s, enc) {
return encodeURIComponent(arguments[0]);
}, "~S,~S");
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
