Clazz.declarePackage ("java.net");
c$ = Clazz.decorateAsClass (function () {
this.path = null;
this.query = null;
this.ref = null;
Clazz.instantialize (this, arguments);
}, java.net, "Parts");
Clazz.makeConstructor (c$, 
function (a) {
var b = a.indexOf ('#');
this.ref = b < 0 ? null : a.substring (b + 1);
a = b < 0 ? a : a.substring (0, b);
var c = a.lastIndexOf ('?');
if (c != -1) {
this.query = a.substring (c + 1);
this.path = a.substring (0, c);
} else {
this.path = a;
}}, "~S");
Clazz.defineMethod (c$, "getPath", 
function () {
return this.path;
});
Clazz.defineMethod (c$, "getQuery", 
function () {
return this.query;
});
Clazz.defineMethod (c$, "getRef", 
function () {
return this.ref;
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023