Clazz.declareInterface (java.io, "Closeable");
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023