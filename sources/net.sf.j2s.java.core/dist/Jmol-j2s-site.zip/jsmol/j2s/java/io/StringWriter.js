Clazz.load (["java.io.Writer"], "java.io.StringWriter", ["java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.StringBuffer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
Clazz.instantialize (this, arguments);
}, java.io, "StringWriter", java.io.Writer);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.io.StringWriter);
this.buf =  new StringBuffer (16);
this.lock = this.buf;
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.StringWriter, []);
if (a >= 0) {
this.buf =  new StringBuffer (a);
this.lock = this.buf;
} else {
throw  new IllegalArgumentException ();
}}, "~N");
Clazz.overrideMethod (c$, "close", 
function () {
});
Clazz.overrideMethod (c$, "flush", 
function () {
});
Clazz.defineMethod (c$, "getBuffer", 
function () {
{
return this.buf;
}});
Clazz.overrideMethod (c$, "toString", 
function () {
{
return this.buf.toString ();
}});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (0 <= b && b <= a.length && 0 <= c && c <= a.length - b) {
{
this.buf.append (a, b, c);
}} else {
throw  new IndexOutOfBoundsException ();
}}, "~A,~N,~N");
Clazz.defineMethod (c$, "write", 
function (a) {
{
this.buf.append (String.fromCharCode (a));
}}, "~N");
Clazz.defineMethod (c$, "write", 
function (a) {
{
this.buf.append (a);
}}, "~S");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
var d = a.substring (b, b + c);
{
this.buf.append (d);
}}, "~S,~N,~N");
Clazz.defineMethod (c$, "append", 
function (a) {
this.write (a.charCodeAt (0));
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
if (null == a) {
this.append ("null", 0, "null".length);
} else {
this.append (a, 0, a.length);
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
if (null == a) {
a = "null";
}var d = a.subSequence (b, c).toString ();
this.write (d, 0, d.length);
return this;
}, "CharSequence,~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023