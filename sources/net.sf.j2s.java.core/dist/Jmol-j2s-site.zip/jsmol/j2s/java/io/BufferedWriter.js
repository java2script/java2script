Clazz.load (["java.io.Writer"], "java.io.BufferedWriter", ["java.io.IOException", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.StringIndexOutOfBoundsException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.out = null;
this.buf = null;
this.pos = 0;
this.lineSeparator = "\r\n";
Clazz.instantialize (this, arguments);
}, java.io, "BufferedWriter", java.io.Writer);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.BufferedWriter, [a]);
this.out = a;
this.buf =  Clazz.newCharArray (8192, '\0');
}, "java.io.Writer");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.BufferedWriter, [a]);
if (b > 0) {
this.out = a;
this.buf =  Clazz.newCharArray (b, '\0');
} else {
throw  new IllegalArgumentException (org.apache.harmony.luni.util.Msg.getString ("K0058"));
}}, "java.io.Writer,~N");
Clazz.defineMethod (c$, "close", 
function () {
{
if (this.isOpen ()) {
this.flush ();
this.out.close ();
this.buf = null;
this.out = null;
}}});
Clazz.defineMethod (c$, "flush", 
function () {
{
if (this.isOpen ()) {
if (this.pos > 0) {
this.out.write (this.buf, 0, this.pos);
}this.pos = 0;
this.out.flush ();
} else {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K005d"));
}}});
Clazz.defineMethod (c$, "isOpen", 
function () {
return this.out != null;
});
Clazz.defineMethod (c$, "newLine", 
function () {
this.write ("\r\n", 0, "\r\n".length);
});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
{
if (!this.isOpen ()) {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K005d"));
}if (b < 0 || b > a.length - c || c < 0) {
throw  new IndexOutOfBoundsException ();
}if (this.pos == 0 && c >= this.buf.length) {
this.out.write (a, b, c);
return;
}var d = this.buf.length - this.pos;
if (c < d) {
d = c;
}if (d > 0) {
System.arraycopy (a, b, this.buf, this.pos, d);
this.pos += d;
}if (this.pos == this.buf.length) {
this.out.write (this.buf, 0, this.buf.length);
this.pos = 0;
if (c > d) {
b += d;
d = c - d;
if (d >= this.buf.length) {
this.out.write (a, b, d);
return;
}System.arraycopy (a, b, this.buf, this.pos, d);
this.pos += d;
}}}}, "~A,~N,~N");
Clazz.defineMethod (c$, "write", 
function (a) {
{
if (this.isOpen ()) {
if (this.pos >= this.buf.length) {
this.out.write (this.buf, 0, this.buf.length);
this.pos = 0;
}this.buf[this.pos++] = String.fromCharCode (a);
} else {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K005d"));
}}}, "~N");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
{
if (!this.isOpen ()) {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K005d"));
}if (c <= 0) {
return;
}if (b > a.length - c || b < 0) {
throw  new StringIndexOutOfBoundsException ();
}if (this.pos == 0 && c >= this.buf.length) {
var d =  Clazz.newCharArray (c, '\0');
a.getChars (b, b + c, d, 0);
this.out.write (d, 0, c);
return;
}var d = this.buf.length - this.pos;
if (c < d) {
d = c;
}if (d > 0) {
a.getChars (b, b + d, this.buf, this.pos);
this.pos += d;
}if (this.pos == this.buf.length) {
this.out.write (this.buf, 0, this.buf.length);
this.pos = 0;
if (c > d) {
b += d;
d = c - d;
if (d >= this.buf.length) {
var e =  Clazz.newCharArray (c, '\0');
a.getChars (b, b + d, e, 0);
this.out.write (e, 0, d);
return;
}a.getChars (b, b + d, this.buf, this.pos);
this.pos += d;
}}}}, "~S,~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023