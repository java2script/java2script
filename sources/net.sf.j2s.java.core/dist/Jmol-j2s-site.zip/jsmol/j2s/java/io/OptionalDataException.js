Clazz.load (["java.io.ObjectStreamException"], "java.io.OptionalDataException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.eof = false;
this.length = 0;
Clazz.instantialize (this, arguments);
}, java.io, "OptionalDataException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023