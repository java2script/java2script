Clazz.load (["java.io.Closeable"], "java.io.Reader", ["java.io.IOException", "java.lang.IllegalArgumentException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.lock = null;
this.skipBuffer = null;
Clazz.instantialize (this, arguments);
}, java.io, "Reader", null, java.io.Closeable);
Clazz.makeConstructor (c$, 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}this.lock = a;
}, "~O");
Clazz.defineMethod (c$, "skip", 
function (a) {
if (a < 0) throw  new IllegalArgumentException ("skip value is negative");
var b = Math.min (a, 8192);
{
if ((this.skipBuffer == null) || (this.skipBuffer.length < b)) this.skipBuffer =  Clazz.newCharArray (b, '\0');
var c = a;
while (c > 0) {
var d = this.read (this.skipBuffer, 0, Math.min (c, b));
if (d == -1) break;
c -= d;
}
return a - c;
}}, "~N");
Clazz.defineMethod (c$, "ready", 
function () {
return false;
});
Clazz.defineMethod (c$, "markSupported", 
function () {
return false;
});
Clazz.defineMethod (c$, "mark", 
function (a) {
throw  new java.io.IOException ("mark() not supported");
}, "~N");
Clazz.defineMethod (c$, "reset", 
function () {
throw  new java.io.IOException ("reset() not supported");
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023