Clazz.load (["java.io.Closeable", "$.Flushable", "java.lang.Appendable"], "java.io.Writer", ["java.lang.NullPointerException", "$.StringIndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.lock = null;
Clazz.instantialize (this, arguments);
}, java.io, "Writer", null, [Appendable, java.io.Closeable, java.io.Flushable]);
Clazz.makeConstructor (c$, 
function () {
this.lock = this;
});
Clazz.makeConstructor (c$, 
function (a) {
if (a != null) {
this.lock = a;
} else {
throw  new NullPointerException ();
}}, "~O");
Clazz.defineMethod (c$, "write", 
function (a) {
this.write (a, 0, a.length);
}, "~A");
Clazz.defineMethod (c$, "write", 
function (a) {
{
var b =  Clazz.newCharArray (1, '\0');
b[0] = String.fromCharCode (a);
this.write (b);
}}, "~N");
Clazz.defineMethod (c$, "write", 
function (a) {
var b =  Clazz.newCharArray (a.length, '\0');
a.getChars (0, b.length, b, 0);
{
this.write (b);
}}, "~S");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (c >= 0) {
var d =  Clazz.newCharArray (c, '\0');
a.getChars (b, b + c, d, 0);
{
this.write (d);
}} else {
throw  new StringIndexOutOfBoundsException ();
}}, "~S,~N,~N");
Clazz.defineMethod (c$, "append", 
function (a) {
this.write (a.charCodeAt (0));
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
if (null == a) {
this.write ("null");
} else {
this.write (a.toString ());
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
if (null == a) {
this.write ("null".substring (b, c));
} else {
this.write (a.subSequence (b, c).toString ());
}return this;
}, "CharSequence,~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023