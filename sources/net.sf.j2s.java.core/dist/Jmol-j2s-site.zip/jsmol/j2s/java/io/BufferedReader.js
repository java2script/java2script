Clazz.load (["java.io.Reader"], "java.io.BufferedReader", ["java.io.IOException", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$in = null;
this.cb = null;
this.nChars = 0;
this.nextChar = 0;
this.markedChar = -1;
this.readAheadLimit = 0;
this.skipLF = false;
this.markedSkipLF = false;
Clazz.instantialize (this, arguments);
}, java.io, "BufferedReader", java.io.Reader);
Clazz.defineMethod (c$, "setSize", 
function (a) {
if (a <= 0) throw  new IllegalArgumentException ("Buffer size <= 0");
this.cb =  Clazz.newCharArray (a, '\0');
this.nextChar = this.nChars = 0;
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.BufferedReader, [a]);
this.$in = a;
this.setSize (8192);
}, "java.io.Reader");
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.$in == null) throw  new java.io.IOException ("Stream closed");
});
Clazz.defineMethod (c$, "fill", 
function () {
var a;
if (this.markedChar <= -1) {
a = 0;
} else {
var b = this.nextChar - this.markedChar;
if (b >= this.readAheadLimit) {
this.markedChar = -2;
this.readAheadLimit = 0;
a = 0;
} else {
if (this.readAheadLimit <= this.cb.length) {
System.arraycopy (this.cb, this.markedChar, this.cb, 0, b);
this.markedChar = 0;
a = b;
} else {
var c =  Clazz.newCharArray (this.readAheadLimit, '\0');
System.arraycopy (this.cb, this.markedChar, c, 0, b);
this.cb = c;
this.markedChar = 0;
a = b;
}this.nextChar = this.nChars = b;
}}var b;
do {
b = this.$in.read (this.cb, a, this.cb.length - a);
} while (b == 0);
if (b > 0) {
this.nChars = a + b;
this.nextChar = a;
}});
Clazz.defineMethod (c$, "read1", 
function (a, b, c) {
if (this.nextChar >= this.nChars) {
if (c >= this.cb.length && this.markedChar <= -1 && !this.skipLF) {
return this.$in.read (a, b, c);
}this.fill ();
}if (this.nextChar >= this.nChars) return -1;
if (this.skipLF) {
this.skipLF = false;
if (this.cb[this.nextChar] == '\n') {
this.nextChar++;
if (this.nextChar >= this.nChars) this.fill ();
if (this.nextChar >= this.nChars) return -1;
}}var d = Math.min (c, this.nChars - this.nextChar);
System.arraycopy (this.cb, this.nextChar, a, b, d);
this.nextChar += d;
return d;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
{
this.ensureOpen ();
if ((b < 0) || (b > a.length) || (c < 0) || ((b + c) > a.length) || ((b + c) < 0)) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}var d = this.read1 (a, b, c);
if (d <= 0) return d;
while ((d < c) && this.$in.ready ()) {
var e = this.read1 (a, b + d, c - d);
if (e <= 0) break;
d += e;
}
return d;
}}, "~A,~N,~N");
Clazz.defineMethod (c$, "readLine1", 
function (a) {
var b = null;
var c;
{
this.ensureOpen ();
var d = a || this.skipLF;
for (; ; ) {
if (this.nextChar >= this.nChars) this.fill ();
if (this.nextChar >= this.nChars) {
if (b != null && b.length > 0) return b.toString ();
return null;
}var e = false;
var f = String.fromCharCode (0);
var g;
if (d && (this.cb[this.nextChar] == '\n')) this.nextChar++;
this.skipLF = false;
d = false;
charLoop : for (g = this.nextChar; g < this.nChars; g++) {
f = this.cb[g];
if ((f == '\n') || (f == '\r')) {
e = true;
break charLoop;
}}
c = this.nextChar;
this.nextChar = g;
var h =  String.instantialize (this.cb, c, g - c);
if (e) {
if (b != null) {
b += h;
h = b;
}this.nextChar++;
if (f == '\r') {
this.skipLF = true;
}return h;
}if (b == null) b = "";
b += h;
}
}}, "~B");
Clazz.defineMethod (c$, "readLine", 
function () {
return this.readLine1 (false);
});
Clazz.overrideMethod (c$, "skip", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("skip value is negative");
}{
this.ensureOpen ();
var b = a;
while (b > 0) {
if (this.nextChar >= this.nChars) this.fill ();
if (this.nextChar >= this.nChars) break;
if (this.skipLF) {
this.skipLF = false;
if (this.cb[this.nextChar] == '\n') {
this.nextChar++;
}}var c = this.nChars - this.nextChar;
if (b <= c) {
this.nextChar += b;
b = 0;
break;
}b -= c;
this.nextChar = this.nChars;
}
return a - b;
}}, "~N");
Clazz.defineMethod (c$, "ready", 
function () {
{
this.ensureOpen ();
if (this.skipLF) {
if (this.nextChar >= this.nChars && this.$in.ready ()) {
this.fill ();
}if (this.nextChar < this.nChars) {
if (this.cb[this.nextChar] == '\n') this.nextChar++;
this.skipLF = false;
}}return (this.nextChar < this.nChars) || this.$in.ready ();
}});
Clazz.overrideMethod (c$, "markSupported", 
function () {
return true;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("Read-ahead limit < 0");
}{
this.ensureOpen ();
this.readAheadLimit = a;
this.markedChar = this.nextChar;
this.markedSkipLF = this.skipLF;
}}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
{
this.ensureOpen ();
if (this.markedChar < 0) throw  new java.io.IOException ((this.markedChar == -2) ? "Mark invalid" : "Stream not marked");
this.nextChar = this.markedChar;
this.skipLF = this.markedSkipLF;
}});
Clazz.defineMethod (c$, "close", 
function () {
{
if (this.$in == null) return;
this.$in.close ();
this.$in = null;
this.cb = null;
}});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023