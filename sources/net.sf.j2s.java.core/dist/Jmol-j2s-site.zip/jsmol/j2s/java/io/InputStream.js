Clazz.load (null, "java.io.InputStream", ["java.io.IOException", "java.lang.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.declareType (java.io, "InputStream");
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException ();
} else if (b < 0 || c < 0 || c > a.length - b) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}var d = this.readByteAsInt ();
if (d == -1) {
return -1;
}a[b] = d;
var e = 1;
try {
for (; e < c; e++) {
d = this.readByteAsInt ();
if (d == -1) {
break;
}a[b + e] = d;
}
} catch (ee) {
if (Clazz.exceptionOf (ee, java.io.IOException)) {
} else {
throw ee;
}
}
return e;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "skip", 
function (a) {
var b = a;
var c;
if (java.io.InputStream.skipBuffer == null) java.io.InputStream.skipBuffer =  Clazz.newByteArray (2048, 0);
var d = java.io.InputStream.skipBuffer;
if (a <= 0) {
return 0;
}while (b > 0) {
c = this.read (d, 0, Math.min (2048, b));
if (c < 0) {
break;
}b -= c;
}
return a - b;
}, "~N");
Clazz.defineMethod (c$, "available", 
function () {
return 0;
});
Clazz.defineMethod (c$, "close", 
function () {
});
Clazz.defineMethod (c$, "mark", 
function (a) {
}, "~N");
Clazz.defineMethod (c$, "reset", 
function () {
throw  new java.io.IOException ("mark/reset not supported");
});
Clazz.defineMethod (c$, "markSupported", 
function () {
return false;
});
Clazz.defineMethod (c$, "resetStream", 
function () {
});
Clazz.defineStatics (c$,
"skipBuffer", null);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023