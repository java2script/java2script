Clazz.load (["java.io.FilterOutputStream"], "java.io.BufferedOutputStream", ["java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.NullPointerException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.count = 0;
Clazz.instantialize (this, arguments);
}, java.io, "BufferedOutputStream", java.io.FilterOutputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.BufferedOutputStream, []);
this.jzSetFOS (a);
this.buf =  Clazz.newByteArray (8192, 0);
}, "java.io.OutputStream");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.BufferedOutputStream, []);
this.jzSetFOS (a);
if (b <= 0) {
throw  new IllegalArgumentException (org.apache.harmony.luni.util.Msg.getString ("K0058"));
}this.buf =  Clazz.newByteArray (b, 0);
}, "java.io.OutputStream,~N");
Clazz.overrideMethod (c$, "flush", 
function () {
if (this.count > 0) {
this.out.write (this.buf, 0, this.count);
}this.count = 0;
this.out.flush ();
});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException (org.apache.harmony.luni.util.Msg.getString ("K0047"));
}if (b < 0 || b > a.length - c || c < 0) {
throw  new ArrayIndexOutOfBoundsException (org.apache.harmony.luni.util.Msg.getString ("K002f"));
}if (this.count == 0 && c >= this.buf.length) {
this.out.write (a, b, c);
return;
}var d = this.buf.length - this.count;
if (c < d) {
d = c;
}if (d > 0) {
System.arraycopy (a, b, this.buf, this.count, d);
this.count += d;
}if (this.count == this.buf.length) {
this.out.write (this.buf, 0, this.buf.length);
this.count = 0;
if (c > d) {
b += d;
d = c - d;
if (d >= this.buf.length) {
this.out.write (a, b, d);
} else {
System.arraycopy (a, b, this.buf, this.count, d);
this.count += d;
}}}}, "~A,~N,~N");
Clazz.defineMethod (c$, "write", 
function (a) {
if (this.count == this.buf.length) {
this.out.write (this.buf, 0, this.count);
this.count = 0;
}this.buf[this.count++] = a;
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023