Clazz.load (["java.io.InputStream"], "java.io.StringBufferInputStream", ["java.lang.ArrayIndexOutOfBoundsException", "$.NullPointerException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buffer = null;
this.count = 0;
this.pos = 0;
Clazz.instantialize (this, arguments);
}, java.io, "StringBufferInputStream", java.io.InputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.StringBufferInputStream, []);
if (a != null) {
this.buffer = a;
this.count = a.length;
} else {
throw  new NullPointerException ();
}}, "~S");
Clazz.overrideMethod (c$, "available", 
function () {
return this.count - this.pos;
});
Clazz.defineMethod (c$, "read", 
function () {
return this.pos < this.count ? this.buffer.charCodeAt (this.pos++) & 0xFF : -1;
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
if (this.pos >= this.count) {
return -1;
}if (a != null) {
if (0 <= b && b <= a.length && 0 <= c && c <= a.length - b) {
if (c == 0) {
return 0;
}var d = this.count - this.pos < c ? this.count - this.pos : c;
for (var e = 0; e < d; e++) {
a[b + e] = (this.buffer.charAt (this.pos + e)).charCodeAt (0);
}
this.pos += d;
return d;
}throw  new ArrayIndexOutOfBoundsException ();
}throw  new NullPointerException (org.apache.harmony.luni.util.Msg.getString ("K0047"));
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "reset", 
function () {
this.pos = 0;
});
Clazz.overrideMethod (c$, "skip", 
function (a) {
if (a <= 0) {
return 0;
}var b;
if (this.count - this.pos < a) {
b = this.count - this.pos;
this.pos = this.count;
} else {
b = a;
this.pos += a;
}return b;
}, "~N");
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
return 0;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023