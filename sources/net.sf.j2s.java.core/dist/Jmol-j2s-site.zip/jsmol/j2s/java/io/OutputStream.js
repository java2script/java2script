Clazz.load (["java.io.Closeable", "$.Flushable"], "java.io.OutputStream", ["java.lang.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.declareType (java.io, "OutputStream", null, [java.io.Closeable, java.io.Flushable]);
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException ();
} else if ((b < 0) || (b > a.length) || (c < 0) || ((b + c) > a.length) || ((b + c) < 0)) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return;
}for (var d = 0; d < c; d++) {
this.writeByteAsInt (a[b + d]);
}
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "flush", 
function () {
});
Clazz.overrideMethod (c$, "close", 
function () {
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023