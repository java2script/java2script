Clazz.load (["java.io.Reader"], "java.io.CharArrayReader", ["java.io.IOException", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.pos = 0;
this.markedPos = -1;
this.count = 0;
Clazz.instantialize (this, arguments);
}, java.io, "CharArrayReader", java.io.Reader);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.CharArrayReader, [a]);
this.buf = a;
this.count = a.length;
}, "~A");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.io.CharArrayReader, [a]);
if (0 <= b && b <= a.length && c >= 0) {
this.buf = a;
this.pos = b;
this.count = this.pos + c < a.length ? c : a.length;
} else {
throw  new IllegalArgumentException ();
}}, "~A,~N,~N");
Clazz.overrideMethod (c$, "close", 
function () {
{
if (this.isOpen ()) {
this.buf = null;
}}});
Clazz.defineMethod (c$, "isOpen", 
function () {
return this.buf != null;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
{
if (this.isOpen ()) {
this.markedPos = this.pos;
} else {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}}}, "~N");
Clazz.overrideMethod (c$, "markSupported", 
function () {
return true;
});
Clazz.defineMethod (c$, "read", 
function () {
{
if (this.isOpen ()) {
if (this.pos != this.count) {
return this.buf[this.pos++];
}return -1;
}throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
if (0 <= b && b <= a.length && 0 <= c && c <= a.length - b) {
{
if (this.isOpen ()) {
if (this.pos < this.count) {
var d = this.pos + c > this.count ? this.count - this.pos : c;
System.arraycopy (this.buf, this.pos, a, b, d);
this.pos += d;
return d;
}return -1;
}throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}}throw  new ArrayIndexOutOfBoundsException ();
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "ready", 
function () {
{
if (this.isOpen ()) {
return this.pos != this.count;
}throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}});
Clazz.overrideMethod (c$, "reset", 
function () {
{
if (this.isOpen ()) {
this.pos = this.markedPos != -1 ? this.markedPos : 0;
} else {
throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}}});
Clazz.overrideMethod (c$, "skip", 
function (a) {
{
if (this.isOpen ()) {
if (a <= 0) {
return 0;
}var b = 0;
if (a < this.count - this.pos) {
this.pos = this.pos + a;
b = a;
} else {
b = this.count - this.pos;
this.pos = this.count;
}return b;
}throw  new java.io.IOException (org.apache.harmony.luni.util.Msg.getString ("K0060"));
}}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023