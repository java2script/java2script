Clazz.load (["java.io.Reader"], "java.io.StringReader", ["java.io.IOException", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.str = null;
this.length = 0;
this.next = 0;
this.$mark = 0;
Clazz.instantialize (this, arguments);
}, java.io, "StringReader", java.io.Reader);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.StringReader, [a]);
this.str = a;
this.length = a.length;
}, "~S");
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.str == null) throw  new java.io.IOException ("Stream closed");
});
Clazz.overrideMethod (c$, "read", 
function (a, b, c) {
{
this.ensureOpen ();
if ((b < 0) || (b > a.length) || (c < 0) || ((b + c) > a.length) || ((b + c) < 0)) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}if (this.next >= this.length) return -1;
var d = Math.min (this.length - this.next, c);
this.str.getChars (this.next, this.next + d, a, b);
this.next += d;
return d;
}}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skip", 
function (a) {
{
this.ensureOpen ();
if (this.next >= this.length) return 0;
var b = Math.min (this.length - this.next, a);
b = Math.max (-this.next, b);
this.next += b;
return b;
}}, "~N");
Clazz.overrideMethod (c$, "ready", 
function () {
{
this.ensureOpen ();
return true;
}});
Clazz.overrideMethod (c$, "markSupported", 
function () {
return true;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("Read-ahead limit < 0");
}{
this.ensureOpen ();
this.$mark = this.next;
}}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
{
this.ensureOpen ();
this.next = this.$mark;
}});
Clazz.overrideMethod (c$, "close", 
function () {
this.str = null;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023