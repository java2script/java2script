Clazz.load (["java.io.IOException"], "java.io.ObjectStreamException", null, function () {
c$ = Clazz.declareType (java.io, "ObjectStreamException", java.io.IOException);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023