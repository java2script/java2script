Clazz.load (["java.io.Reader"], "java.io.InputStreamReader", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$in = null;
this.isOpen = true;
this.charsetName = null;
this.isUTF8 = false;
this.bytearr = null;
this.pos = 0;
Clazz.instantialize (this, arguments);
}, java.io, "InputStreamReader", java.io.Reader);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.InputStreamReader, [a]);
this.$in = a;
this.charsetName = b;
if (!(this.isUTF8 = "UTF-8".equals (b)) && !"ISO-8859-1".equals (b)) throw  new NullPointerException ("charsetName");
}, "java.io.InputStream,~S");
Clazz.defineMethod (c$, "getEncoding", 
function () {
return this.charsetName;
});
Clazz.overrideMethod (c$, "read", 
function (a, b, c) {
if (this.bytearr == null || this.bytearr.length < c) this.bytearr =  Clazz.newByteArray (c, 0);
var d;
var e;
var f;
var g = 0;
var h = b;
var i = this.$in.read (this.bytearr, this.pos, c - this.pos);
var j = this.$in.available ();
if (i < 0) return -1;
var k = i;
while (g < k) {
d = this.bytearr[g] & 0xff;
if (this.isUTF8) switch (d >> 4) {
case 0xC:
case 0xD:
if (g + 1 >= i) {
if (j >= 1) {
k = g;
continue;
}} else if (((e = this.bytearr[g + 1]) & 0xC0) == 0x80) {
a[h++] = String.fromCharCode (((d & 0x1F) << 6) | (e & 0x3F));
g += 2;
continue;
}this.isUTF8 = false;
break;
case 0xE:
if (g + 2 >= i) {
if (j >= 2) {
k = g;
continue;
}} else if (((e = this.bytearr[g + 1]) & 0xC0) == 0x80 && ((f = this.bytearr[g + 2]) & 0xC0) == 0x80) {
a[h++] = String.fromCharCode (((d & 0x0F) << 12) | ((e & 0x3F) << 6) | (f & 0x3F));
g += 3;
continue;
}this.isUTF8 = false;
break;
}
g++;
a[h++] = String.fromCharCode (d);
}
this.pos = i - g;
for (var l = 0; l < this.pos; l++) {
this.bytearr[l] = this.bytearr[g++];
}
return h - b;
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "ready", 
function () {
return this.isOpen;
});
Clazz.overrideMethod (c$, "close", 
function () {
this.$in.close ();
this.isOpen = false;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023