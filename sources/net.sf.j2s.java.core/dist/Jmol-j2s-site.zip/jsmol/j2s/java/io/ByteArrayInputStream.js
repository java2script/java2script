Clazz.load (["java.io.InputStream"], "java.io.ByteArrayInputStream", ["java.lang.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.pos = 0;
this.$mark = 0;
this.count = 0;
Clazz.instantialize (this, arguments);
}, java.io, "ByteArrayInputStream", java.io.InputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.ByteArrayInputStream, []);
this.buf = a;
this.pos = 0;
this.count = a.length;
}, "~A");
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
return (this.pos < this.count) ? (this.buf[this.pos++] & 0xff) : -1;
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException ();
} else if (b < 0 || c < 0 || c > a.length - b) {
throw  new IndexOutOfBoundsException ();
}if (this.pos >= this.count) {
return -1;
}var d = this.count - this.pos;
if (c > d) {
c = d;
}if (c <= 0) {
return 0;
}System.arraycopy (this.buf, this.pos, a, b, c);
this.pos += c;
return c;
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skip", 
function (a) {
var b = this.count - this.pos;
if (a < b) {
b = a < 0 ? 0 : a;
}this.pos += b;
return b;
}, "~N");
Clazz.overrideMethod (c$, "available", 
function () {
return this.count - this.pos;
});
Clazz.overrideMethod (c$, "markSupported", 
function () {
return true;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
this.$mark = this.pos;
}, "~N");
Clazz.overrideMethod (c$, "resetStream", 
function () {
});
Clazz.overrideMethod (c$, "reset", 
function () {
this.pos = this.$mark;
});
Clazz.overrideMethod (c$, "close", 
function () {
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023