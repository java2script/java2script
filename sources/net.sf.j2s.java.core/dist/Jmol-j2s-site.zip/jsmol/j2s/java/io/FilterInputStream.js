Clazz.load (["java.io.InputStream"], "java.io.FilterInputStream", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.$in = null;
Clazz.instantialize (this, arguments);
}, java.io, "FilterInputStream", java.io.InputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.FilterInputStream, []);
this.$in = a;
}, "java.io.InputStream");
Clazz.defineMethod (c$, "readByteAsInt", 
function () {
return this.$in.readByteAsInt ();
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
return this.$in.read (a, b, c);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "skip", 
function (a) {
return this.$in.skip (a);
}, "~N");
Clazz.defineMethod (c$, "available", 
function () {
return this.$in.available ();
});
Clazz.defineMethod (c$, "close", 
function () {
this.$in.close ();
});
Clazz.defineMethod (c$, "mark", 
function (a) {
this.$in.mark (a);
}, "~N");
Clazz.defineMethod (c$, "reset", 
function () {
this.$in.reset ();
});
Clazz.defineMethod (c$, "markSupported", 
function () {
return this.$in.markSupported ();
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023