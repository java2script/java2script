Clazz.load (null, "java.io.ObjectStreamField", ["java.lang.Boolean", "$.Byte", "$.Character", "$.Double", "$.Float", "$.Long", "$.NullPointerException", "$.Short", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.type = null;
this.offset = 0;
this.typeString = null;
this.unshared = false;
this.isDeserialized = false;
Clazz.instantialize (this, arguments);
}, java.io, "ObjectStreamField", null, Comparable);
Clazz.makeConstructor (c$, 
function (a, b) {
if (a == null || b == null) {
throw  new NullPointerException ();
}this.name = a;
this.type = b;
}, "~S,Class");
Clazz.makeConstructor (c$, 
function (a, b, c) {
if (a == null || b == null) {
throw  new NullPointerException ();
}this.name = a;
this.type = b;
this.unshared = c;
}, "~S,Class,~B");
Clazz.makeConstructor (c$, 
function (a, b) {
if (b == null) {
throw  new NullPointerException ();
}this.name = b;
this.typeString = a.$replace ('.', '/');
this.isDeserialized = true;
}, "~S,~S");
Clazz.overrideMethod (c$, "compareTo", 
function (a) {
var b = a;
var c = this.isPrimitive ();
var d = b.isPrimitive ();
if (c != d) {
return c ? -1 : 1;
}return this.getName ().compareTo (b.getName ());
}, "~O");
Clazz.overrideMethod (c$, "equals", 
function (a) {
return this.compareTo (a) == 0;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.getName ().hashCode ();
});
Clazz.defineMethod (c$, "getName", 
function () {
return this.name;
});
Clazz.defineMethod (c$, "getOffset", 
function () {
return this.offset;
});
Clazz.defineMethod (c$, "getTypeInternal", 
function () {
return this.type;
});
Clazz.defineMethod (c$, "getType", 
function () {
var a = this.getTypeInternal ();
if (this.isDeserialized && !a.isPrimitive ()) {
return Clazz._O;
}return a;
});
Clazz.defineMethod (c$, "getTypeCode", 
function () {
var a = this.getTypeInternal ();
if (a === Integer.TYPE) {
return 'I';
}if (a === Byte.TYPE) {
return 'B';
}if (a === Character.TYPE) {
return 'C';
}if (a === Short.TYPE) {
return 'S';
}if (a === Boolean.TYPE) {
return 'Z';
}if (a === Long.TYPE) {
return 'J';
}if (a === Float.TYPE) {
return 'F';
}if (a === Double.TYPE) {
return 'D';
}if (a.isArray ()) {
return '[';
}return 'L';
});
Clazz.defineMethod (c$, "getTypeString", 
function () {
if (this.isPrimitive ()) {
return null;
}if (this.typeString == null) {
var a = this.getTypeInternal ();
var b = a.getName ().$replace ('.', '/');
var c = (a.isArray ()) ? b : ("L" + b + ';');
this.typeString = c.intern ();
}return this.typeString;
});
Clazz.defineMethod (c$, "isPrimitive", 
function () {
var a = this.getTypeInternal ();
return a != null && a.isPrimitive ();
});
Clazz.defineMethod (c$, "setOffset", 
function (a) {
this.offset = a;
}, "~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.getClass ().getName () + '(' + this.getName () + ':' + this.getTypeInternal () + ')';
});
c$.sortFields = Clazz.defineMethod (c$, "sortFields", 
function (a) {
if (a.length > 1) {
var b = ((Clazz.isClassDefined ("java.io.ObjectStreamField$1") ? 0 : java.io.ObjectStreamField.$ObjectStreamField$1$ ()), Clazz.innerTypeInstance (java.io.ObjectStreamField$1, this, null));
java.util.Arrays.sort (a, b);
}}, "~A");
Clazz.defineMethod (c$, "resolve", 
function (a) {
if (this.typeString.length == 1) {
switch (this.typeString.charAt (0)) {
case 'I':
this.type = Integer.TYPE;
return;
case 'B':
this.type = Byte.TYPE;
return;
case 'C':
this.type = Character.TYPE;
return;
case 'S':
this.type = Short.TYPE;
return;
case 'Z':
this.type = Boolean.TYPE;
return;
case 'J':
this.type = Long.TYPE;
return;
case 'F':
this.type = Float.TYPE;
return;
case 'D':
this.type = Double.TYPE;
return;
}
}var b = this.typeString.$replace ('/', '.');
if (b.charAt (0) == 'L') {
b = b.substring (1, b.length - 1);
}try {
var c = Clazz._4Name (b, false, a);
this.type = c;
} catch (e) {
if (Clazz.exceptionOf (e, ClassNotFoundException)) {
} else {
throw e;
}
}
}, "ClassLoader");
Clazz.defineMethod (c$, "isUnshared", 
function () {
return this.unshared;
});
c$.$ObjectStreamField$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.io, "ObjectStreamField$1", null, java.util.Comparator);
Clazz.overrideMethod (c$, "compare", 
function (a, b) {
return a.compareTo (b);
}, "java.io.ObjectStreamField,java.io.ObjectStreamField");
c$ = Clazz.p0p ();
};
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023