Clazz.load (["java.io.ObjectStreamException"], "java.io.InvalidClassException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.classname = null;
Clazz.instantialize (this, arguments);
}, java.io, "InvalidClassException", java.io.ObjectStreamException);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.InvalidClassException, [b]);
this.classname = a;
}, "~S,~S");
Clazz.defineMethod (c$, "getMessage", 
function () {
var a = Clazz.superCall (this, java.io.InvalidClassException, "getMessage", []);
if (this.classname != null) {
a = this.classname + ';' + ' ' + a;
}return a;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023