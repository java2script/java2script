Clazz.load (["java.io.OutputStream"], "java.io.ByteArrayOutputStream", ["java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.OutOfMemoryError"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.count = 0;
Clazz.instantialize (this, arguments);
}, java.io, "ByteArrayOutputStream", java.io.OutputStream);
Clazz.makeConstructor (c$, 
function () {
this.construct (32);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.ByteArrayOutputStream, []);
if (a < 0) {
throw  new IllegalArgumentException ("Negative initial size: " + a);
}this.buf =  Clazz.newByteArray (a, 0);
}, "~N");
Clazz.defineMethod (c$, "ensureCapacity", 
function (a) {
if (a - this.buf.length > 0) this.grow (a);
}, "~N");
Clazz.defineMethod (c$, "grow", 
function (a) {
var b = this.buf.length;
var c = b << 1;
if (c - a < 0) c = a;
if (c < 0) {
if (a < 0) throw  new OutOfMemoryError ();
c = a;
}this.buf = java.io.ByteArrayOutputStream.arrayCopyByte (this.buf, c);
}, "~N");
c$.arrayCopyByte = Clazz.defineMethod (c$, "arrayCopyByte", 
function (a, b) {
var c =  Clazz.newByteArray (b, 0);
System.arraycopy (a, 0, c, 0, a.length < b ? a.length : b);
return c;
}, "~A,~N");
Clazz.overrideMethod (c$, "writeByteAsInt", 
function (a) {
this.ensureCapacity (this.count + 1);
this.buf[this.count] = a;
this.count += 1;
}, "~N");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if ((b < 0) || (b > a.length) || (c < 0) || ((b + c) - a.length > 0)) {
throw  new IndexOutOfBoundsException ();
}this.ensureCapacity (this.count + c);
System.arraycopy (a, b, this.buf, this.count, c);
this.count += c;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "writeTo", 
function (a) {
a.write (this.buf, 0, this.count);
}, "java.io.OutputStream");
Clazz.defineMethod (c$, "reset", 
function () {
this.count = 0;
});
Clazz.defineMethod (c$, "toByteArray", 
function () {
return (this.count == this.buf.length ? this.buf : java.io.ByteArrayOutputStream.arrayCopyByte (this.buf, this.count));
});
Clazz.defineMethod (c$, "size", 
function () {
return this.count;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return  String.instantialize (this.buf, 0, this.count);
});
Clazz.overrideMethod (c$, "close", 
function () {
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023