Clazz.load (["java.io.Writer"], "java.io.CharArrayWriter", ["java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.NullPointerException", "$.StringIndexOutOfBoundsException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.count = 0;
Clazz.instantialize (this, arguments);
}, java.io, "CharArrayWriter", java.io.Writer);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.io.CharArrayWriter);
this.buf =  Clazz.newCharArray (32, '\0');
this.lock = this.buf;
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.CharArrayWriter);
if (a >= 0) {
this.buf =  Clazz.newCharArray (a, '\0');
this.lock = this.buf;
} else {
throw  new IllegalArgumentException (org.apache.harmony.luni.util.Msg.getString ("K005e"));
}}, "~N");
Clazz.overrideMethod (c$, "close", 
function () {
});
Clazz.defineMethod (c$, "expand", 
function (a) {
if (this.count + a <= this.buf.length) {
return;
}var b =  Clazz.newCharArray (this.buf.length + (2 * a), '\0');
System.arraycopy (this.buf, 0, b, 0, this.count);
this.buf = b;
}, "~N");
Clazz.overrideMethod (c$, "flush", 
function () {
});
Clazz.defineMethod (c$, "reset", 
function () {
{
this.count = 0;
}});
Clazz.defineMethod (c$, "size", 
function () {
{
return this.count;
}});
Clazz.defineMethod (c$, "toCharArray", 
function () {
{
var a =  Clazz.newCharArray (this.count, '\0');
System.arraycopy (this.buf, 0, a, 0, this.count);
return a;
}});
Clazz.overrideMethod (c$, "toString", 
function () {
{
return  String.instantialize (this.buf, 0, this.count);
}});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (0 <= b && b <= a.length && 0 <= c && c <= a.length - b) {
{
this.expand (c);
System.arraycopy (a, b, this.buf, this.count, c);
this.count += c;
}} else {
throw  new IndexOutOfBoundsException ();
}}, "~A,~N,~N");
Clazz.defineMethod (c$, "write", 
function (a) {
{
this.expand (1);
this.buf[this.count++] = String.fromCharCode (a);
}}, "~N");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException (org.apache.harmony.luni.util.Msg.getString ("K0047"));
}if (0 <= b && b <= a.length && 0 <= c && c <= a.length - b) {
{
this.expand (c);
a.getChars (b, b + c, this.buf, this.count);
this.count += c;
}} else {
throw  new StringIndexOutOfBoundsException ();
}}, "~S,~N,~N");
Clazz.defineMethod (c$, "writeTo", 
function (a) {
{
a.write (this.buf, 0, this.count);
}}, "java.io.Writer");
Clazz.defineMethod (c$, "append", 
function (a) {
this.write (a.charCodeAt (0));
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
if (null == a) {
this.append ("null", 0, "null".length);
} else {
this.append (a, 0, a.length);
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
if (null == a) {
a = "null";
}var d = a.subSequence (b, c).toString ();
this.write (d, 0, d.length);
return this;
}, "CharSequence,~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023