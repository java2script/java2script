Clazz.load (["java.io.FilterInputStream"], "java.io.PushbackInputStream", ["java.io.IOException", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.pos = 0;
Clazz.instantialize (this, arguments);
}, java.io, "PushbackInputStream", java.io.FilterInputStream);
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.$in == null) throw  new java.io.IOException ("Stream closed");
});
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.PushbackInputStream, [a]);
if (b <= 0) {
throw  new IllegalArgumentException ("size <= 0");
}this.buf =  Clazz.newByteArray (b, 0);
this.pos = b;
}, "java.io.InputStream,~N");
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
this.ensureOpen ();
if (this.pos < this.buf.length) {
return this.buf[this.pos++] & 0xff;
}return this.$in.readByteAsInt ();
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
this.ensureOpen ();
if (a == null) {
throw  new NullPointerException ();
} else if (b < 0 || c < 0 || c > a.length - b) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}var d = this.buf.length - this.pos;
if (d > 0) {
if (c < d) {
d = c;
}System.arraycopy (this.buf, this.pos, a, b, d);
this.pos += d;
b += d;
c -= d;
}if (c > 0) {
c = this.$in.read (a, b, c);
if (c == -1) {
return d == 0 ? -1 : d;
}return d + c;
}return d;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "unreadByte", 
function (a) {
this.ensureOpen ();
if (this.pos == 0) {
throw  new java.io.IOException ("Push back buffer is full");
}this.buf[--this.pos] = a;
}, "~N");
Clazz.defineMethod (c$, "unread", 
function (a, b, c) {
this.ensureOpen ();
if (c > this.pos) {
throw  new java.io.IOException ("Push back buffer is full");
}this.pos -= c;
System.arraycopy (a, b, this.buf, this.pos, c);
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "available", 
function () {
this.ensureOpen ();
var a = this.buf.length - this.pos;
var b = this.$in.available ();
return a > (2147483647 - b) ? 2147483647 : a + b;
});
Clazz.overrideMethod (c$, "skip", 
function (a) {
this.ensureOpen ();
if (a <= 0) {
return 0;
}var b = this.buf.length - this.pos;
if (b > 0) {
if (a < b) {
b = a;
}this.pos += b;
a -= b;
}if (a > 0) {
b += this.$in.skip (a);
}return b;
}, "~N");
Clazz.overrideMethod (c$, "markSupported", 
function () {
return false;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
throw  new java.io.IOException ("mark/reset not supported");
});
Clazz.overrideMethod (c$, "close", 
function () {
if (this.$in == null) return;
this.$in.close ();
this.$in = null;
this.buf = null;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023