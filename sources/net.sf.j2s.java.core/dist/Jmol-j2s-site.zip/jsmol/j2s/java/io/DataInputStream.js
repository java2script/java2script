Clazz.load (["java.io.DataInput", "$.FilterInputStream"], "java.io.DataInputStream", ["java.io.EOFException", "$.PushbackInputStream", "$.UTFDataFormatException", "java.lang.Double", "$.Float", "$.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.bytearr = null;
this.chararr = null;
this.readBuffer = null;
this.lineBuffer = null;
Clazz.instantialize (this, arguments);
}, java.io, "DataInputStream", java.io.FilterInputStream, java.io.DataInput);
Clazz.prepareFields (c$, function () {
this.bytearr =  Clazz.newByteArray (80, 0);
this.chararr =  Clazz.newCharArray (80, '\0');
this.readBuffer =  Clazz.newByteArray (8, 0);
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
return this.$in.read (a, b, c);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "readFully", 
function (a, b, c) {
if (c < 0) throw  new IndexOutOfBoundsException ();
var d = 0;
while (d < c) {
var e = this.$in.read (a, b + d, c - d);
if (e < 0) throw  new java.io.EOFException ();
d += e;
}
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skipBytes", 
function (a) {
var b = 0;
var c = 0;
while ((b < a) && ((c = this.$in.skip (a - b)) > 0)) {
b += c;
}
return b;
}, "~N");
Clazz.overrideMethod (c$, "readBoolean", 
function () {
var a = this.$in.readByteAsInt ();
if (a < 0) throw  new java.io.EOFException ();
return (a != 0);
});
Clazz.overrideMethod (c$, "readByte", 
function () {
var a = this.$in.readByteAsInt ();
if (a < 0) throw  new java.io.EOFException ();
return (a);
});
Clazz.overrideMethod (c$, "readUnsignedByte", 
function () {
var a = this.$in.readByteAsInt ();
if (a < 0) throw  new java.io.EOFException ();
return a;
});
Clazz.overrideMethod (c$, "readShort", 
function () {
var a = this.$in.readByteAsInt ();
var b = this.$in.readByteAsInt ();
if ((a | b) < 0) throw  new java.io.EOFException ();
var c = ((a << 8) + (b << 0));
{
return (n > 0x7FFF ? n - 0x10000 : n);
}});
Clazz.defineMethod (c$, "readUnsignedShort", 
function () {
var a = this.$in.readByteAsInt ();
var b = this.$in.readByteAsInt ();
if ((a | b) < 0) throw  new java.io.EOFException ();
return (a << 8) + (b << 0);
});
Clazz.overrideMethod (c$, "readChar", 
function () {
var a = this.$in.readByteAsInt ();
var b = this.$in.readByteAsInt ();
if ((a | b) < 0) throw  new java.io.EOFException ();
return String.fromCharCode ((a << 8) + (b << 0));
});
Clazz.overrideMethod (c$, "readInt", 
function () {
var a = this.$in.readByteAsInt ();
var b = this.$in.readByteAsInt ();
var c = this.$in.readByteAsInt ();
var d = this.$in.readByteAsInt ();
if ((a | b | c | d) < 0) throw  new java.io.EOFException ();
var e = ((a << 24) + (b << 16) + (c << 8) + (d << 0));
{
return (n > 0x7FFFFFFF ? n - 0x100000000 : n);
}});
Clazz.overrideMethod (c$, "readLong", 
function () {
this.readFully (this.readBuffer, 0, 8);
return ((this.readBuffer[0] << 56) + ((this.readBuffer[1] & 255) << 48) + ((this.readBuffer[2] & 255) << 40) + ((this.readBuffer[3] & 255) << 32) + ((this.readBuffer[4] & 255) << 24) + ((this.readBuffer[5] & 255) << 16) + ((this.readBuffer[6] & 255) << 8) + ((this.readBuffer[7] & 255) << 0));
});
Clazz.overrideMethod (c$, "readFloat", 
function () {
return Float.intBitsToFloat (this.readInt ());
});
Clazz.overrideMethod (c$, "readDouble", 
function () {
return Double.longBitsToDouble (this.readLong ());
});
Clazz.overrideMethod (c$, "readLine", 
function () {
var a = this.lineBuffer;
if (a == null) {
a = this.lineBuffer =  Clazz.newCharArray (128, '\0');
}var b = a.length;
var c = 0;
var d;
loop : while (true) {
switch (d = this.$in.readByteAsInt ()) {
case -1:
case '\n':
break loop;
case '\r':
var e = this.$in.readByteAsInt ();
if ((e != 10) && (e != -1)) {
if (!(Clazz.instanceOf (this.$in, java.io.PushbackInputStream))) {
this.$in =  new java.io.PushbackInputStream (this.$in, 1);
}(this.$in).unreadByte (e);
}break loop;
default:
if (--b < 0) {
a =  Clazz.newCharArray (c + 128, '\0');
b = a.length - c - 1;
System.arraycopy (this.lineBuffer, 0, a, 0, c);
this.lineBuffer = a;
}a[c++] = String.fromCharCode (d);
break;
}
}
if ((d == -1) && (c == 0)) {
return null;
}return String.copyValueOf (a, 0, c);
});
Clazz.overrideMethod (c$, "readUTF", 
function () {
return java.io.DataInputStream.readUTFBytes (this, -1);
});
c$.readUTFBytes = Clazz.defineMethod (c$, "readUTFBytes", 
function (a, b) {
var c = (b >= 0);
if (!c) b = a.readUnsignedShort ();
var d = null;
var e = null;
if (Clazz.instanceOf (a, java.io.DataInputStream)) {
var f = a;
if (f.bytearr.length < b) {
f.bytearr =  Clazz.newByteArray (c ? b : b * 2, 0);
f.chararr =  Clazz.newCharArray (f.bytearr.length, '\0');
}e = f.chararr;
d = f.bytearr;
} else {
d =  Clazz.newByteArray (b, 0);
e =  Clazz.newCharArray (b, '\0');
}var f;
var g;
var h;
var i = 0;
var j = 0;
a.readFully (d, 0, b);
while (i < b) {
f = d[i] & 0xff;
if (f > 127) break;
i++;
e[j++] = String.fromCharCode (f);
}
while (i < b) {
f = d[i] & 0xff;
switch (f >> 4) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
i++;
e[j++] = String.fromCharCode (f);
break;
case 12:
case 13:
i += 2;
if (i > b) throw  new java.io.UTFDataFormatException ("malformed input: partial character at end");
g = d[i - 1];
if ((g & 0xC0) != 0x80) throw  new java.io.UTFDataFormatException ("malformed input around byte " + i);
e[j++] = String.fromCharCode (((f & 0x1F) << 6) | (g & 0x3F));
break;
case 14:
i += 3;
if (i > b) throw  new java.io.UTFDataFormatException ("malformed input: partial character at end");
g = d[i - 2];
h = d[i - 1];
if (((g & 0xC0) != 0x80) || ((h & 0xC0) != 0x80)) throw  new java.io.UTFDataFormatException ("malformed input around byte " + (i - 1));
e[j++] = String.fromCharCode (((f & 0x0F) << 12) | ((g & 0x3F) << 6) | ((h & 0x3F) << 0));
break;
default:
throw  new java.io.UTFDataFormatException ("malformed input around byte " + i);
}
}
return  String.instantialize (e, 0, j);
}, "java.io.DataInput,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023