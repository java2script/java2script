Clazz.load (["java.io.FilterInputStream"], "java.io.BufferedInputStream", ["java.io.IOException", "java.lang.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.buf = null;
this.count = 0;
this.pos = 0;
this.markpos = -1;
this.marklimit = 0;
Clazz.instantialize (this, arguments);
}, java.io, "BufferedInputStream", java.io.FilterInputStream);
Clazz.defineMethod (c$, "getInIfOpen", 
function () {
var a = this.$in;
if (a == null) throw  new java.io.IOException ("Stream closed");
return a;
});
Clazz.defineMethod (c$, "getBufIfOpen", 
function () {
var a = this.buf;
if (a == null) throw  new java.io.IOException ("Stream closed");
return a;
});
Clazz.overrideMethod (c$, "resetStream", 
function () {
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.io.BufferedInputStream, [a]);
this.buf =  Clazz.newByteArray (8192, 0);
}, "java.io.InputStream");
Clazz.defineMethod (c$, "fill", 
function () {
var a = this.getBufIfOpen ();
if (this.markpos < 0) this.pos = 0;
 else if (this.pos >= a.length) if (this.markpos > 0) {
var b = this.pos - this.markpos;
System.arraycopy (a, this.markpos, a, 0, b);
this.pos = b;
this.markpos = 0;
} else if (a.length >= this.marklimit) {
this.markpos = -1;
this.pos = 0;
} else {
var b = this.pos * 2;
if (b > this.marklimit) b = this.marklimit;
var c =  Clazz.newByteArray (b, 0);
System.arraycopy (a, 0, c, 0, this.pos);
a = this.buf = c;
}this.count = this.pos;
var b = this.getInIfOpen ().read (a, this.pos, a.length - this.pos);
if (b > 0) this.count = b + this.pos;
});
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
if (this.pos >= this.count) {
this.fill ();
if (this.pos >= this.count) return -1;
}return this.getBufIfOpen ()[this.pos++] & 0xff;
});
Clazz.defineMethod (c$, "read1", 
function (a, b, c) {
var d = this.count - this.pos;
if (d <= 0) {
if (c >= this.getBufIfOpen ().length && this.markpos < 0) {
return this.getInIfOpen ().read (a, b, c);
}this.fill ();
d = this.count - this.pos;
if (d <= 0) return -1;
}var e = (d < c) ? d : c;
System.arraycopy (this.getBufIfOpen (), this.pos, a, b, e);
this.pos += e;
return e;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
this.getBufIfOpen ();
if ((b | c | (b + c) | (a.length - (b + c))) < 0) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}var d = 0;
for (; ; ) {
var e = this.read1 (a, b + d, c - d);
if (e <= 0) return (d == 0) ? e : d;
d += e;
if (d >= c) return d;
var f = this.$in;
if (f != null && f.available () <= 0) return d;
}
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skip", 
function (a) {
this.getBufIfOpen ();
if (a <= 0) {
return 0;
}var b = this.count - this.pos;
if (b <= 0) {
if (this.markpos < 0) return this.getInIfOpen ().skip (a);
this.fill ();
b = this.count - this.pos;
if (b <= 0) return 0;
}var c = (b < a) ? b : a;
this.pos += c;
return c;
}, "~N");
Clazz.overrideMethod (c$, "available", 
function () {
var a = this.count - this.pos;
var b = this.getInIfOpen ().available ();
return a > (2147483647 - b) ? 2147483647 : a + b;
});
Clazz.overrideMethod (c$, "mark", 
function (a) {
this.marklimit = a;
this.markpos = this.pos;
}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
this.getBufIfOpen ();
if (this.markpos < 0) throw  new java.io.IOException ("Resetting to invalid mark");
this.pos = this.markpos;
});
Clazz.overrideMethod (c$, "markSupported", 
function () {
return true;
});
Clazz.overrideMethod (c$, "close", 
function () {
var a = this.$in;
this.$in = null;
if (a != null) a.close ();
return;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023