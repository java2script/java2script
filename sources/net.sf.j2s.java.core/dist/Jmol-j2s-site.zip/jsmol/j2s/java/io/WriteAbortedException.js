Clazz.load (["java.io.ObjectStreamException"], "java.io.WriteAbortedException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.detail = null;
Clazz.instantialize (this, arguments);
}, java.io, "WriteAbortedException", java.io.ObjectStreamException);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.io.WriteAbortedException, [a]);
this.detail = b;
this.initCause (b);
}, "~S,Exception");
Clazz.defineMethod (c$, "getMessage", 
function () {
var a = Clazz.superCall (this, java.io.WriteAbortedException, "getMessage", []);
if (this.detail != null) {
a = a + "; " + this.detail.toString ();
}return a;
});
Clazz.overrideMethod (c$, "getCause", 
function () {
return this.detail;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023