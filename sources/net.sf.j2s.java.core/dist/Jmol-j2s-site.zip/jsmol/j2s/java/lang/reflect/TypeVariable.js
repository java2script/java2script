Clazz.load (["java.lang.reflect.Type"], "java.lang.reflect.TypeVariable", null, function () {
Clazz.declareInterface (java.lang.reflect, "TypeVariable", java.lang.reflect.Type);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023