Clazz.load (null, "java.lang.reflect.Proxy", ["java.lang.IllegalArgumentException", "$.NullPointerException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.h = null;
Clazz.instantialize (this, arguments);
}, java.lang.reflect, "Proxy", null, java.io.Serializable);
Clazz.makeConstructor (c$, 
function (a) {
this.h = a;
}, "java.lang.reflect.InvocationHandler");
c$.getProxyClass = Clazz.defineMethod (c$, "getProxyClass", 
function (a, b) {
if (b == null) {
throw  new NullPointerException ();
}return null;
}, "ClassLoader,~A");
c$.newProxyInstance = Clazz.defineMethod (c$, "newProxyInstance", 
function (a, b, c) {
if (c != null) {
}throw  new NullPointerException ();
}, "ClassLoader,~A,java.lang.reflect.InvocationHandler");
c$.isProxyClass = Clazz.defineMethod (c$, "isProxyClass", 
function (a) {
if (a != null) {
}throw  new NullPointerException ();
}, "Class");
c$.getInvocationHandler = Clazz.defineMethod (c$, "getInvocationHandler", 
function (a) {
if (java.lang.reflect.Proxy.isProxyClass (a.getClass ())) {
return (a).h;
}throw  new IllegalArgumentException (org.apache.harmony.luni.util.Msg.getString ("K00f1"));
}, "~O");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023