Clazz.load (["java.lang.reflect.AccessibleObject", "$.GenericDeclaration", "$.Member", "java.lang.Void"], "java.lang.reflect.Constructor", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.clazz = null;
this.parameterTypes = null;
this.exceptionTypes = null;
this.modifiers = 0;
Clazz.instantialize (this, arguments);
}, java.lang.reflect, "Constructor", java.lang.reflect.AccessibleObject, [java.lang.reflect.GenericDeclaration, java.lang.reflect.Member]);
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
Clazz.superConstructor (this, java.lang.reflect.Constructor, []);
this.clazz = a;
this.parameterTypes = b;
this.exceptionTypes = c;
this.modifiers = d;
}, "Class,~A,~A,~N");
Clazz.overrideMethod (c$, "getTypeParameters", 
function () {
return null;
});
Clazz.defineMethod (c$, "toGenericString", 
function () {
return null;
});
Clazz.defineMethod (c$, "getGenericParameterTypes", 
function () {
return null;
});
Clazz.defineMethod (c$, "getGenericExceptionTypes", 
function () {
return null;
});
Clazz.defineMethod (c$, "getParameterAnnotations", 
function () {
return null;
});
Clazz.defineMethod (c$, "isVarArgs", 
function () {
return false;
});
Clazz.overrideMethod (c$, "isSynthetic", 
function () {
return false;
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (a != null && Clazz.instanceOf (a, java.lang.reflect.Constructor)) {
var b = a;
if (this.getDeclaringClass () === b.getDeclaringClass ()) {
var c = this.parameterTypes;
var d = b.parameterTypes;
if (c.length == d.length) {
for (var e = 0; e < c.length; e++) {
if (c[e] !== d[e]) return false;
}
return true;
}}}return false;
}, "~O");
Clazz.overrideMethod (c$, "getDeclaringClass", 
function () {
return this.clazz;
});
Clazz.defineMethod (c$, "getExceptionTypes", 
function () {
return this.exceptionTypes;
});
Clazz.overrideMethod (c$, "getModifiers", 
function () {
return this.modifiers;
});
Clazz.overrideMethod (c$, "getName", 
function () {
return this.getDeclaringClass ().getName ();
});
Clazz.defineMethod (c$, "getParameterTypes", 
function () {
return this.parameterTypes;
});
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.getDeclaringClass ().getName ().hashCode ();
});
Clazz.defineMethod (c$, "newInstance", 
function (a) {
var instance = new this.clazz (Clazz.inheritArgs);
Clazz.instantialize (instance, args);
return instance;
}, "~A");
Clazz.overrideMethod (c$, "toString", 
function () {
return null;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023