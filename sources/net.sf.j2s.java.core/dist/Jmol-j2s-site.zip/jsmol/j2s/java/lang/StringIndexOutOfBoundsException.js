Clazz.load (["java.lang.IndexOutOfBoundsException"], "java.lang.StringIndexOutOfBoundsException", null, function () {
c$ = Clazz.declareType (java.lang, "StringIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, StringIndexOutOfBoundsException, ["String index out of range: " + a]);
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023