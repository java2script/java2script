Clazz.load (["java.lang.Error"], "java.lang.AssertionError", ["java.lang.Double", "$.Float", "$.Long", "$.Throwable"], function () {
c$ = Clazz.declareType (java.lang, "AssertionError", Error);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, AssertionError, [String.valueOf (a), (Clazz.instanceOf (a, Throwable) ? a : null)]);
}, "~O");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (String.valueOf (a));
}, "~B");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (String.valueOf (a));
}, "~S");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (Integer.toString (a));
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (Long.toString (a));
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (Float.toString (a));
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (Double.toString (a));
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023