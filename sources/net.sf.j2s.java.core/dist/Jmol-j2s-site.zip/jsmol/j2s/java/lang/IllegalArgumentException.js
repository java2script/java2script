Clazz.load (["java.lang.RuntimeException"], "java.lang.IllegalArgumentException", null, function () {
c$ = Clazz.declareType (java.lang, "IllegalArgumentException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, IllegalArgumentException, [(a == null ? null : a.toString ()), a]);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023