c$ = Clazz.decorateAsClass (function () {
this.value = '\0';
Clazz.instantialize (this, arguments);
}, java.lang, "Character", null, [java.io.Serializable, Comparable]);
Clazz.makeConstructor (c$, 
function (a) {
this.value = a;
}, "~S");
Clazz.defineMethod (c$, "charValue", 
function () {
return this.value;
});
Clazz.overrideMethod (c$, "hashCode", 
function () {
return (this.value).charCodeAt (0);
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (Clazz.instanceOf (a, Character)) {
return this.value == (a).charValue ();
}return false;
}, "~O");
Clazz.overrideMethod (c$, "compareTo", 
function (a) {
return this.value.charCodeAt (0) - a.value.charCodeAt (0);
}, "Character");
c$.toLowerCase = Clazz.defineMethod (c$, "toLowerCase", 
function (a) {
return ("" + a).toLowerCase ().charAt (0);
}, "~S");
c$.toUpperCase = Clazz.defineMethod (c$, "toUpperCase", 
function (a) {
return ("" + a).toUpperCase ().charAt (0);
}, "~S");
c$.isDigit = Clazz.defineMethod (c$, "isDigit", 
function (a) {
if ('0' <= a && a <= '9') return true;
if (a.charCodeAt (0) < 1632) return false;
return false;
}, "~S");
c$.forDigit = Clazz.defineMethod (c$, "forDigit", 
function (a, b) {
if ((a >= b) || (a < 0)) {
return '\0';
}if ((b < 2) || (b > 36)) {
return '\0';
}if (a < 10) {
return String.fromCharCode (48 + a);
}return String.fromCharCode (87 + a);
}, "~N,~N");
c$.isUpperCase = Clazz.defineMethod (c$, "isUpperCase", 
function (a) {
if ('A' <= a && a <= 'Z') {
return true;
}return false;
}, "~S");
c$.isLowerCase = Clazz.defineMethod (c$, "isLowerCase", 
function (a) {
if ('a' <= a && a <= 'z') {
return true;
}return false;
}, "~S");
c$.isWhitespace = Clazz.defineMethod (c$, "isWhitespace", 
function (a) {
if ((a.charCodeAt (0) >= 0x1c && a.charCodeAt (0) <= 0x20) || (a.charCodeAt (0) >= 0x9 && a.charCodeAt (0) <= 0xd)) return true;
if (a.charCodeAt (0) == 0x1680) return true;
if (a.charCodeAt (0) < 0x2000 || a.charCodeAt (0) == 0x2007) return false;
return a.charCodeAt (0) <= 0x200b || a.charCodeAt (0) == 0x2028 || a.charCodeAt (0) == 0x2029 || a.charCodeAt (0) == 0x3000;
}, "~S");
c$.isLetter = Clazz.defineMethod (c$, "isLetter", 
function (a) {
if (('A' <= a && a <= 'Z') || ('a' <= a && a <= 'z')) return true;
if (a.charCodeAt (0) < 128) return false;
return false;
}, "~S");
c$.isLetterOrDigit = Clazz.defineMethod (c$, "isLetterOrDigit", 
function (a) {
return Character.isLetter (a) || Character.isDigit (a);
}, "~S");
c$.isSpaceChar = Clazz.defineMethod (c$, "isSpaceChar", 
function (a) {
if (a.charCodeAt (0) == 0x20 || a.charCodeAt (0) == 0xa0 || a.charCodeAt (0) == 0x1680) return true;
if (a.charCodeAt (0) < 0x2000) return false;
return a.charCodeAt (0) <= 0x200b || a.charCodeAt (0) == 0x2028 || a.charCodeAt (0) == 0x2029 || a.charCodeAt (0) == 0x202f || a.charCodeAt (0) == 0x3000;
}, "~S");
c$.digit = Clazz.defineMethod (c$, "digit", 
function (a, b) {
if (b >= 2 && b <= 36) {
if (a.charCodeAt (0) < 128) {
var c = -1;
if ('0' <= a && a <= '9') {
c = a.charCodeAt (0) - 48;
} else if ('a' <= a && a <= 'z') {
c = a.charCodeAt (0) - (87);
} else if ('A' <= a && a <= 'Z') {
c = a.charCodeAt (0) - (55);
}return c < b ? c : -1;
}}return -1;
}, "~S,~N");
Clazz.defineMethod (c$, "toString", 
function () {
var a =  Clazz.newCharArray (-1, [this.value]);
return String.valueOf (a);
});
c$.toString = Clazz.defineMethod (c$, "toString", 
function (a) {
{
if (this === Charater) {
return "class java.lang.Charater"; // Charater.class.toString
}
}return String.valueOf (a);
}, "~S");
Clazz.defineStatics (c$,
"TYPE", null);

java.lang.Character.TYPE=java.lang.Character.prototype.TYPE=java.lang.Character;
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023