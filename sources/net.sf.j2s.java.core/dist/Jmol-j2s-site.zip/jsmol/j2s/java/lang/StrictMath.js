Clazz.load (null, "java.lang.StrictMath", ["java.lang.Double", "$.Float"], function () {
c$ = Clazz.declareType (java.lang, "StrictMath");
c$.abs = Clazz.defineMethod (c$, "abs", 
function (a) {
return Math.abs (d);
}, "~N");
c$.acos = Clazz.defineMethod (c$, "acos", 
function (b) {
return Math.acos (d);
}, "~N");
c$.asin = Clazz.defineMethod (c$, "asin", 
function (a) {
return Math.asin (d);
}, "~N");
c$.atan = Clazz.defineMethod (c$, "atan", 
function (a) {
return Math.atan (d);
}, "~N");
c$.atan2 = Clazz.defineMethod (c$, "atan2", 
function (a, b) {
return Math.atan2 (d1, d2);
}, "~N,~N");
c$.ceil = Clazz.defineMethod (c$, "ceil", 
function (a) {
return Math.ceil (d);
}, "~N");
c$.cosh = Clazz.defineMethod (c$, "cosh", 
function (a) {
return Math.cosh (d);
}, "~N");
c$.cos = Clazz.defineMethod (c$, "cos", 
function (a) {
return Math.cos (d);
}, "~N");
c$.exp = Clazz.defineMethod (c$, "exp", 
function (a) {
return Math.exp (d);
}, "~N");
c$.floor = Clazz.defineMethod (c$, "floor", 
function (a) {
return Math.floor (d);
}, "~N");
c$.log = Clazz.defineMethod (c$, "log", 
function (a) {
return Math.log (d);
}, "~N");
c$.log10 = Clazz.defineMethod (c$, "log10", 
function (a) {
return Math.log10 (d);
}, "~N");
c$.max = Clazz.defineMethod (c$, "max", 
function (a, b) {
return Math.max (d1, d2);
}, "~N,~N");
c$.min = Clazz.defineMethod (c$, "min", 
function (c, d) {
return Math.min (d1, d2);
}, "~N,~N");
c$.pow = Clazz.defineMethod (c$, "pow", 
function (e, f) {
return Math.pow (d1, d2);
}, "~N,~N");
c$.random = Clazz.defineMethod (c$, "random", 
function () {
return Math.random ();
});
c$.rint = Clazz.defineMethod (c$, "rint", 
function (a) {
return Math.round (d);
}, "~N");
c$.round = Clazz.defineMethod (c$, "round", 
function (a) {
return Math.round (d);
}, "~N");
c$.signum = Clazz.defineMethod (c$, "signum", 
function (b) {
if (Double.isNaN (b)) {
return NaN;
}var c = b;
if (b > 0) {
c = 1.0;
} else if (b < 0) {
c = -1.0;
}return c;
}, "~N");
c$.signum = Clazz.defineMethod (c$, "signum", 
function (a) {
if (Float.isNaN (a)) {
return NaN;
}var b = a;
if (a > 0) {
b = 1.0;
} else if (a < 0) {
b = -1.0;
}return b;
}, "~N");
c$.sinh = Clazz.defineMethod (c$, "sinh", 
function (a) {
return Math.sinh (d);
}, "~N");
c$.sin = Clazz.defineMethod (c$, "sin", 
function (a) {
return Math.sin (d);
}, "~N");
c$.sqrt = Clazz.defineMethod (c$, "sqrt", 
function (a) {
return Math.sqrt (d);
}, "~N");
c$.tan = Clazz.defineMethod (c$, "tan", 
function (a) {
return Math.tan (d);
}, "~N");
c$.tanh = Clazz.defineMethod (c$, "tanh", 
function (a) {
return Math.tanh (d);
}, "~N");
c$.toDegrees = Clazz.defineMethod (c$, "toDegrees", 
function (a) {
return a * 180 / 3.141592653589793;
}, "~N");
c$.toRadians = Clazz.defineMethod (c$, "toRadians", 
function (a) {
return a / 180 * 3.141592653589793;
}, "~N");
Clazz.defineStatics (c$,
"$random", null);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023