Clazz.load (["java.lang.RuntimeException"], "java.lang.annotation.AnnotationTypeMismatchException", ["org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$element = null;
this.$foundType = null;
Clazz.instantialize (this, arguments);
}, java.lang.annotation, "AnnotationTypeMismatchException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.lang.annotation.AnnotationTypeMismatchException, [org.apache.harmony.luni.util.Msg.getString ("annotation.1", a, b)]);
this.$element = a;
this.$foundType = b;
}, "java.lang.reflect.Method,~S");
Clazz.defineMethod (c$, "element", 
function () {
return this.$element;
});
Clazz.defineMethod (c$, "foundType", 
function () {
return this.$foundType;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023