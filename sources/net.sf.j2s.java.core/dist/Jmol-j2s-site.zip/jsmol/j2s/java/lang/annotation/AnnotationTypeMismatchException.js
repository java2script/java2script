Clazz.load (["java.lang.RuntimeException"], "java.lang.annotation.AnnotationTypeMismatchException", ["org.apache.harmony.luni.util.Msg"], function () {
var c$ = Clazz.decorateAsClass (function () {
this.$element = null;
this.$foundType = null;
Clazz.instantialize (this, arguments);
}, java.lang.annotation, "AnnotationTypeMismatchException", RuntimeException);
Clazz.makeConstructor (c$, 
function (element, foundType) {
Clazz.superConstructor (this, java.lang.annotation.AnnotationTypeMismatchException, [org.apache.harmony.luni.util.Msg.getString ("annotation.1", element, foundType)]);
this.$element = element;
this.$foundType = foundType;
}, "java.lang.reflect.Method,~S");
Clazz.defineMethod (c$, "element", 
function () {
return this.$element;
});
Clazz.defineMethod (c$, "foundType", 
function () {
return this.$foundType;
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
