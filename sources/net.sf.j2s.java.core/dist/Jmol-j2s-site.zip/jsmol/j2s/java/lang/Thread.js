Clazz.load (null, "java.lang.Thread", ["java.lang.IllegalArgumentException", "$.ThreadGroup", "java.util.Date"], function () {
c$ = Clazz.decorateAsClass (function () {
this.target = null;
this.group = null;
this.name = null;
this.priority = 0;
Clazz.instantialize (this, arguments);
}, java.lang, "Thread", null, Runnable);
c$.currentThread = Clazz.defineMethod (c$, "currentThread", 
function () {
if (Thread.J2S_THREAD == null) {
Thread.J2S_THREAD =  new Thread ();
}return Thread.J2S_THREAD;
});
c$.sleep = Clazz.defineMethod (c$, "sleep", 
function (a) {
alert ("Thread.sleep is not implemented in Java2Script!");
}, "~N");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (a) {
this.init (null, a, "Thread-" +  new java.util.Date ().getTime () + Math.random (), 0);
}, "Runnable");
Clazz.makeConstructor (c$, 
function (a, b) {
this.init (a, b, "Thread-" +  new java.util.Date ().getTime () + Math.random (), 0);
}, "ThreadGroup,Runnable");
Clazz.makeConstructor (c$, 
function (a) {
this.init (null, null, a, 0);
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
this.init (a, null, b, 0);
}, "ThreadGroup,~S");
Clazz.makeConstructor (c$, 
function (a, b) {
this.init (null, a, b, 0);
}, "Runnable,~S");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.init (a, b, c, 0);
}, "ThreadGroup,Runnable,~S");
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
this.init (a, b, c, d);
}, "ThreadGroup,Runnable,~S,~N");
Clazz.defineMethod (c$, "init", 
function (a, b, c, d) {
if (a == null) {
a =  new ThreadGroup ();
}this.group = a;
this.target = b;
this.name = c;
this.priority = 5;
}, "ThreadGroup,Runnable,~S,~N");
Clazz.defineMethod (c$, "start", 
function () {
window.setTimeout ((function (runnable) {
return function () {
runnable.run ();
};
}) (this), 0);
});
Clazz.defineMethod (c$, "run", 
function () {
if (this.target != null) {
this.target.run ();
}});
Clazz.defineMethod (c$, "setPriority", 
function (a) {
if (a > 10 || a < 1) {
throw  new IllegalArgumentException ();
}this.priority = a;
}, "~N");
Clazz.defineMethod (c$, "getPriority", 
function () {
return this.priority;
});
Clazz.defineMethod (c$, "setName", 
function (a) {
this.name = a;
}, "~S");
Clazz.defineMethod (c$, "getName", 
function () {
return String.valueOf (this.name);
});
Clazz.defineMethod (c$, "getThreadGroup", 
function () {
return this.group;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var a = this.getThreadGroup ();
if (a != null) {
return "Thread[" + this.getName () + "," + this.getPriority () + "," + a.getName () + "]";
} else {
return "Thread[" + this.getName () + "," + this.getPriority () + "," + "" + "]";
}});
Clazz.defineStatics (c$,
"J2S_THREAD", null);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023