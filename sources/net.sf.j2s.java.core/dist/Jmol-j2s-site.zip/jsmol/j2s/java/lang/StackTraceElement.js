Clazz.load (null, "java.lang.StackTraceElement", ["java.lang.NullPointerException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.declaringClass = null;
this.methodName = null;
this.fileName = null;
this.lineNumber = 0;
Clazz.instantialize (this, arguments);
}, java.lang, "StackTraceElement", null, java.io.Serializable);
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
if (a == null || b == null) {
throw  new NullPointerException ();
}this.declaringClass = a;
this.methodName = b;
this.fileName = c;
this.lineNumber = d;
}, "~S,~S,~S,~N");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (!(Clazz.instanceOf (a, StackTraceElement))) {
return false;
}var b = a;
if ((this.methodName == null) || (b.methodName == null)) {
return false;
}if (!this.getMethodName ().equals (b.getMethodName ())) {
return false;
}if (!this.getClassName ().equals (b.getClassName ())) {
return false;
}var c = this.getFileName ();
if (c == null) {
if (b.getFileName () != null) {
return false;
}} else {
if (!c.equals (b.getFileName ())) {
return false;
}}if (this.getLineNumber () != b.getLineNumber ()) {
return false;
}return true;
}, "~O");
Clazz.defineMethod (c$, "getClassName", 
function () {
return (this.declaringClass == null) ? "<unknown class>" : this.declaringClass;
});
Clazz.defineMethod (c$, "getFileName", 
function () {
return this.fileName;
});
Clazz.defineMethod (c$, "getLineNumber", 
function () {
return this.lineNumber;
});
Clazz.defineMethod (c$, "getMethodName", 
function () {
return (this.methodName == null) ? "<unknown method>" : this.methodName;
});
Clazz.overrideMethod (c$, "hashCode", 
function () {
if (this.methodName == null) {
return 0;
}return this.methodName.hashCode () ^ this.declaringClass.hashCode ();
});
Clazz.defineMethod (c$, "isNativeMethod", 
function () {
return this.lineNumber == -2;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var a =  new StringBuilder (80);
a.append (this.getClassName ());
a.append ('.');
a.append (this.getMethodName ());
if (this.isNativeMethod ()) {
a.append ("(Native Method)");
} else {
var b = this.getFileName ();
if (b == null) {
a.append ("(Unknown Source)");
} else {
var c = this.getLineNumber ();
a.append ('(');
a.append (b);
if (c >= 0) {
a.append (':');
a.append (c);
}a.append (')');
}}return a.toString ();
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023