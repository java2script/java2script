Clazz.load (["java.lang.AbstractStringBuilder", "$.Appendable"], "java.lang.StringBuffer", ["java.lang.Character", "$.Double", "$.Float", "$.Long"], function () {
c$ = Clazz.declareType (java.lang, "StringBuffer", AbstractStringBuilder, [Appendable, java.io.Serializable, CharSequence]);
Clazz.makeConstructor (c$, 
function (a) {
if (cs == null) {
throw new NullPointerException();
}
Clazz.superConstructor(this, StringBuffer, [cs.toString()]);
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (b) {
return this.append (b ? "true" : "false");
}, "~B");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
return this.append (Double.toString (a));
}, "~N");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
this.append0 (a.toString ());
}return this;
}, "~O");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
{
this.append0 (a.getValue (), 0, a.length ());
}}return this;
}, "StringBuffer");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~A");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
this.append0 (a, b, c);
return this;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
this.append0 (a.toString ());
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
this.append0 (a, b, c);
return this;
}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "appendCodePoint", 
function (a) {
return this.append (Character.toChars (a));
}, "~N");
Clazz.defineMethod (c$, "$delete", 
function (a, b) {
this.delete0 (a, b);
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "deleteCharAt", 
function (a) {
this.deleteCharAt0 (a);
return this;
}, "~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, b ? "true" : "false");
}, "~N,~B");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, Integer.toString (b));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, Long.toString (b));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, Double.toString (b));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, Float.toString (b));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.insert (a, b == null ? "null" : b.toString ());
}, "~N,~O");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~A");
Clazz.defineMethod (c$, "insert", 
function (a, b, c, d) {
this.insert0 (a, b, c, d);
return this;
}, "~N,~A,~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b == null ? "null" : b.toString ());
return this;
}, "~N,CharSequence");
Clazz.defineMethod (c$, "insert", 
function (a, b, c, d) {
this.insert0 (a, b, c, d);
return this;
}, "~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "replace", 
function (a, b, c) {
this.replace0 (a, b, c);
return this;
}, "~N,~N,~S");
Clazz.defineMethod (c$, "reverse", 
function () {
this.reverse0 ();
return this;
});
Clazz.overrideMethod (c$, "subSequence", 
function (a, b) {
return Clazz.superCall (this, StringBuffer, "substring", [a, b]);
}, "~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023