Clazz.load (["java.lang.Exception"], "java.lang.ClassNotFoundException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.ex = null;
Clazz.instantialize (this, arguments);
}, java.lang, "ClassNotFoundException", Exception);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, ClassNotFoundException, [Clazz.castNullAs ("Throwable")]);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, ClassNotFoundException, [a, null]);
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, ClassNotFoundException, [a]);
this.ex = b;
}, "~S,Throwable");
Clazz.defineMethod (c$, "getException", 
function () {
return this.ex;
});
Clazz.overrideMethod (c$, "getCause", 
function () {
return this.ex;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023