Clazz.load (["java.lang.RuntimeException"], "java.lang.IllegalStateException", null, function () {
var c$ = Clazz.declareType (java.lang, "IllegalStateException", RuntimeException);
Clazz.makeConstructor (c$, 
function (cause) {
Clazz.superConstructor (this, IllegalStateException, [(cause == null ? null : cause.toString ()), cause]);
}, "Throwable");
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
