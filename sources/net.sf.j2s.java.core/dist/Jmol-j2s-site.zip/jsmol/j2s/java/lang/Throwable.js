c$ = Clazz.decorateAsClass (function () {
this.detailMessage = null;
this.cause = null;
this.stackTrace = null;
Clazz.instantialize (this, arguments);
}, java.lang, "Throwable", null, java.io.Serializable);
Clazz.prepareFields (c$, function () {
this.cause = this;
});
Clazz.makeConstructor (c$, 
function () {
this.fillInStackTrace ();
});
Clazz.makeConstructor (c$, 
function (a) {
this.fillInStackTrace ();
this.detailMessage = a;
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
this.fillInStackTrace ();
this.detailMessage = a;
this.cause = b;
}, "~S,Throwable");
Clazz.makeConstructor (c$, 
function (a) {
this.fillInStackTrace ();
this.detailMessage = (a == null ? null : a.toString ());
this.cause = a;
}, "Throwable");
Clazz.defineMethod (c$, "getMessage", 
function () {
{
if (typeof this.message != "undefined") {
return this.message;
}
}return this.detailMessage;
});
Clazz.defineMethod (c$, "getLocalizedMessage", 
function () {
return this.getMessage ();
});
Clazz.defineMethod (c$, "getCause", 
function () {
return (this.cause === this ? null : this.cause);
});
Clazz.defineMethod (c$, "initCause", 
function (a) {
if (this.cause !== this) throw  new IllegalStateException ("Can't overwrite cause");
if (a === this) throw  new IllegalArgumentException ("Self-causation not permitted");
this.cause = a;
return this;
}, "Throwable");
Clazz.overrideMethod (c$, "toString", 
function () {
var a = this.getClass ().getName ();
var b = this.getLocalizedMessage ();
return (b != null) ? (a + ": " + b) : a;
});
Clazz.defineMethod (c$, "printStackTrace", 
function () {
System.err.println (this);
for (var a = 0; a < this.stackTrace.length; a++) {
var t = this.c[i];
var x = t.e.indexOf ("(");
var n = t.e.substring (0, x).replace (/\s+/g, "");
if (n != "construct" || t.z == null
|| Clazz.getInheritedLevel (t.z, Throwable) < 0) {
System.err.println (t);
}
}
});
Clazz.defineMethod (c$, "printStackTrace", 
function (a) {
this.printStackTrace ();
}, "java.io.PrintStream");
Clazz.defineMethod (c$, "printStackTrace", 
function (b) {
this.printStackTrace ();
}, "java.io.PrintWriter");
Clazz.defineMethod (c$, "fillInStackTrace", 
function () {
this.c = new Array ();
var r = arguments.callee.caller;
var s = null;
var l = new Array ();
var q = Clazz.callingStackTraces;
var x = q.length - 1;
var p = true;
while (x > -1 || r != null) {
var clazzName = null;
var z = null;
if (!p || r == Clazz.tryToSearchAndExecute || r == Clazz.superCall || r == null) {
if (x < 0) {
break;
}
p = true;
s = q[x].caller;
z = q[x].owner;
x--;
} else {
s = r;
if (s.claxxOwner != null) {
z = s.claxxOwner;
} else if (s.exClazz != null) {
z = s.exClazz;
}
}
var st = new StackTraceElement (
((z != null && z.__CLASS_NAME__.length != 0) ?
z.__CLASS_NAME__ : "anonymous"),
((s.exName == null) ? "anonymous" : s.exName)
+ " (" + Clazz.getParamsType (s.arguments) + ")",
null, -1);
st.z = z;
this.c[this.c.length] = st;
for (var i = 0; i < l.length; i++) {
if (l[i] == s) {
// ... stack information lost as recursive invocation existed ...
var st = new StackTraceElement ("lost", "missing", null, -3);
st.z = null;
this.c[this.c.length] = st;
p = false;
//break;
}
}
if (s != null) {
l[l.length] = s;
}
r = s.arguments.callee.caller;
}
Clazz.initializingException = false;
return this;
});
Clazz.defineMethod (c$, "setStackTrace", 
function (a) {
var b = a.clone ();
for (var c = 0; c < b.length; c++) if (b[c] == null) throw  new NullPointerException ("stackTrace[" + c + "]");

this.stackTrace = b;
}, "~A");
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023