Clazz.load (["java.lang.RuntimeException"], "java.lang.reflect.UndeclaredThrowableException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.undeclaredThrowable = null;
Clazz.instantialize (this, arguments);
}, java.lang.reflect, "UndeclaredThrowableException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.lang.reflect.UndeclaredThrowableException);
this.undeclaredThrowable = a;
this.initCause (a);
}, "Throwable");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.lang.reflect.UndeclaredThrowableException, [b]);
this.undeclaredThrowable = a;
this.initCause (a);
}, "Throwable,~S");
Clazz.defineMethod (c$, "getUndeclaredThrowable", 
function () {
return this.undeclaredThrowable;
});
Clazz.overrideMethod (c$, "getCause", 
function () {
return this.undeclaredThrowable;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023