Clazz.load (null, "java.lang.reflect.Modifier", ["java.lang.reflect.Method"], function () {
c$ = Clazz.declareType (java.lang.reflect, "Modifier");
Clazz.makeConstructor (c$, 
function () {
});
c$.isAbstract = Clazz.defineMethod (c$, "isAbstract", 
function (a) {
return ((a & 1024) != 0);
}, "~N");
c$.isFinal = Clazz.defineMethod (c$, "isFinal", 
function (a) {
return ((a & 16) != 0);
}, "~N");
c$.isInterface = Clazz.defineMethod (c$, "isInterface", 
function (a) {
return ((a & 512) != 0);
}, "~N");
c$.isNative = Clazz.defineMethod (c$, "isNative", 
function (a) {
return ((a & 256) != 0);
}, "~N");
c$.isPrivate = Clazz.defineMethod (c$, "isPrivate", 
function (a) {
return ((a & 2) != 0);
}, "~N");
c$.isProtected = Clazz.defineMethod (c$, "isProtected", 
function (a) {
return ((a & 4) != 0);
}, "~N");
c$.isPublic = Clazz.defineMethod (c$, "isPublic", 
function (a) {
return ((a & 1) != 0);
}, "~N");
c$.isStatic = Clazz.defineMethod (c$, "isStatic", 
function (a) {
return ((a & 8) != 0);
}, "~N");
c$.isStrict = Clazz.defineMethod (c$, "isStrict", 
function (a) {
return ((a & 2048) != 0);
}, "~N");
c$.isSynchronized = Clazz.defineMethod (c$, "isSynchronized", 
function (a) {
return ((a & 32) != 0);
}, "~N");
c$.isTransient = Clazz.defineMethod (c$, "isTransient", 
function (a) {
return ((a & 128) != 0);
}, "~N");
c$.isVolatile = Clazz.defineMethod (c$, "isVolatile", 
function (a) {
return ((a & 64) != 0);
}, "~N");
c$.toString = Clazz.defineMethod (c$, "toString", 
function (a) {
var b =  new Array (0);
if (java.lang.reflect.Modifier.isPublic (a)) b[b.length] = "public";
if (java.lang.reflect.Modifier.isProtected (a)) b[b.length] = "protected";
if (java.lang.reflect.Modifier.isPrivate (a)) b[b.length] = "private";
if (java.lang.reflect.Modifier.isAbstract (a)) b[b.length] = "abstract";
if (java.lang.reflect.Modifier.isStatic (a)) b[b.length] = "static";
if (java.lang.reflect.Modifier.isFinal (a)) b[b.length] = "final";
if (java.lang.reflect.Modifier.isTransient (a)) b[b.length] = "transient";
if (java.lang.reflect.Modifier.isVolatile (a)) b[b.length] = "volatile";
if (java.lang.reflect.Modifier.isSynchronized (a)) b[b.length] = "synchronized";
if (java.lang.reflect.Modifier.isNative (a)) b[b.length] = "native";
if (java.lang.reflect.Modifier.isStrict (a)) b[b.length] = "strictfp";
if (java.lang.reflect.Modifier.isInterface (a)) b[b.length] = "interface";
if (b.length > 0) {
return a.join (" ");
}return "";
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023