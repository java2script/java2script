Clazz.load (["java.lang.AbstractStringBuilder", "$.Appendable"], "java.lang.StringBuilder", ["java.lang.Double", "$.Float", "$.Long"], function () {
c$ = Clazz.declareType (java.lang, "StringBuilder", AbstractStringBuilder, [Appendable, CharSequence, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, StringBuilder, [a.toString ()]);
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a ? "true" : "false");
return this;
}, "~B");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (Integer.toString (a));
return this;
}, "~N");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (Long.toString (a));
return this;
}, "~N");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (Float.toString (a));
return this;
}, "~N");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (Double.toString (a));
return this;
}, "~N");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
this.append0 (a.toString ());
}return this;
}, "~O");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
this.append0 (a.getValue (), 0, a.length ());
}return this;
}, "StringBuffer");
Clazz.defineMethod (c$, "append", 
function (a) {
this.append0 (a);
return this;
}, "~A");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
this.append0 (a, b, c);
return this;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "append", 
function (a) {
if (a == null) {
this.appendNull ();
} else {
this.append0 (a.toString ());
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (a, b, c) {
this.append0 (a, b, c);
return this;
}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "$delete", 
function (a, b) {
this.delete0 (a, b);
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "deleteCharAt", 
function (a) {
this.deleteCharAt0 (a);
return this;
}, "~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b ? "true" : "false");
return this;
}, "~N,~B");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, Integer.toString (b));
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, Long.toString (b));
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, Float.toString (b));
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, Double.toString (b));
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b == null ? "null" : b.toString ());
return this;
}, "~N,~O");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b);
return this;
}, "~N,~A");
Clazz.defineMethod (c$, "insert", 
function (a, b, c, d) {
this.insert0 (a, b, c, d);
return this;
}, "~N,~A,~N,~N");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
this.insert0 (a, b == null ? "null" : b.toString ());
return this;
}, "~N,CharSequence");
Clazz.defineMethod (c$, "insert", 
function (a, b, c, d) {
this.insert0 (a, b, c, d);
return this;
}, "~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "replace", 
function (a, b, c) {
this.replace0 (a, b, c);
return this;
}, "~N,~N,~S");
Clazz.defineMethod (c$, "reverse", 
function () {
this.reverse0 ();
return this;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023