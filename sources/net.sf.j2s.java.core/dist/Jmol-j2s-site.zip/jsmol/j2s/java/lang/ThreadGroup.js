Clazz.load (null, "java.lang.ThreadGroup", ["java.lang.NullPointerException", "$.Thread"], function () {
c$ = Clazz.decorateAsClass (function () {
this.parent = null;
this.name = null;
this.maxPriority = 0;
Clazz.instantialize (this, arguments);
}, java.lang, "ThreadGroup");
Clazz.makeConstructor (c$, 
function () {
this.name = "system";
this.maxPriority = 10;
});
Clazz.makeConstructor (c$, 
function (a) {
this.construct (Thread.currentThread ().getThreadGroup (), a);
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
if (a == null) {
throw  new NullPointerException ();
}this.name = b;
this.parent = a;
this.maxPriority = 10;
}, "ThreadGroup,~S");
Clazz.defineMethod (c$, "getName", 
function () {
return this.name;
});
Clazz.defineMethod (c$, "getParent", 
function () {
return this.parent;
});
Clazz.defineMethod (c$, "getMaxPriority", 
function () {
return this.maxPriority;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023