Clazz.load (["java.lang.RuntimeException"], "java.lang.UnsupportedOperationException", null, function () {
c$ = Clazz.declareType (java.lang, "UnsupportedOperationException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, UnsupportedOperationException, []);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, UnsupportedOperationException, [(a == null ? null : a.toString ()), a]);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023