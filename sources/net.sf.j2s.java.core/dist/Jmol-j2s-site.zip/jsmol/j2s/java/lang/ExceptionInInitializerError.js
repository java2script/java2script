Clazz.load (["java.lang.LinkageError"], "java.lang.ExceptionInInitializerError", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.exception = null;
Clazz.instantialize (this, arguments);
}, java.lang, "ExceptionInInitializerError", LinkageError);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, ExceptionInInitializerError);
this.initCause (null);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, ExceptionInInitializerError, [a]);
this.initCause (null);
}, "~S");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, ExceptionInInitializerError);
this.exception = a;
this.initCause (a);
}, "Throwable");
Clazz.defineMethod (c$, "getException", 
function () {
return this.exception;
});
Clazz.overrideMethod (c$, "getCause", 
function () {
return this.exception;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023