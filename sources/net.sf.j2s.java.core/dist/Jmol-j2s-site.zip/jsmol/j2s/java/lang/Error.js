Clazz.load (["java.lang.Throwable"], "java.lang.Error", null, function () {
var c$ = Clazz.declareType (java.lang, "Error", Throwable);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
