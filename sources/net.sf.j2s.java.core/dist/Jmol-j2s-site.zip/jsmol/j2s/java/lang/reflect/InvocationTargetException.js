Clazz.load (["java.lang.Exception"], "java.lang.reflect.InvocationTargetException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.target = null;
Clazz.instantialize (this, arguments);
}, java.lang.reflect, "InvocationTargetException", Exception);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.lang.reflect.InvocationTargetException, [Clazz.castNullAs ("Throwable")]);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.lang.reflect.InvocationTargetException, [null, a]);
this.target = a;
}, "Throwable");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.lang.reflect.InvocationTargetException, [b, a]);
this.target = a;
}, "Throwable,~S");
Clazz.defineMethod (c$, "getTargetException", 
function () {
return this.target;
});
Clazz.overrideMethod (c$, "getCause", 
function () {
return this.target;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023