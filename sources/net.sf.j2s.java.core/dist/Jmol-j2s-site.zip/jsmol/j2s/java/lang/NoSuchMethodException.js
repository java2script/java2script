Clazz.load (["java.lang.Exception"], "java.lang.NoSuchMethodException", null, function () {
c$ = Clazz.declareType (java.lang, "NoSuchMethodException", Exception);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023