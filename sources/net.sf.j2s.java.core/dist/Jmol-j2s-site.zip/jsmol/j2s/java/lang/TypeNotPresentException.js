Clazz.load (["java.lang.RuntimeException"], "java.lang.TypeNotPresentException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.$typeName = null;
Clazz.instantialize (this, arguments);
}, java.lang, "TypeNotPresentException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, TypeNotPresentException, ["Type " + a + " not present", b]);
this.$typeName = a;
}, "~S,Throwable");
Clazz.defineMethod (c$, "typeName", 
function () {
return this.$typeName;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023