Array.getComponentType = function () {
return Object;
}; c$ = Clazz.declareType (java.lang.reflect, "Array");
c$.newInstance = Clazz.defineMethod (c$, "newInstance", 
function (a, b) {
return Clazz.newArray (b);
}, "Class,~N");
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023