Clazz.load (["java.lang.Error"], "java.lang.annotation.AnnotationFormatError", null, function () {
c$ = Clazz.declareType (java.lang.annotation, "AnnotationFormatError", Error);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.lang.annotation.AnnotationFormatError, [a == null ? null : a.toString (), a]);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023