Clazz.load (null, "java.lang.Void", ["java.lang.RuntimeException"], function () {
c$ = Clazz.declareType (java.lang, "Void");
Clazz.defineStatics (c$,
"TYPE", null);
{
java.lang.Void.TYPE = java.lang.Void;
}});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023