Clazz.load (["java.lang.IncompatibleClassChangeError"], "java.lang.InstantiationError", null, function () {
c$ = Clazz.declareType (java.lang, "InstantiationError", IncompatibleClassChangeError);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023