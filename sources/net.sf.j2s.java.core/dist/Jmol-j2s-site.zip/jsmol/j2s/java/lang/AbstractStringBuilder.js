Clazz.load (null, "java.lang.AbstractStringBuilder", ["java.io.InvalidObjectException", "java.lang.ArrayIndexOutOfBoundsException", "$.IndexOutOfBoundsException", "$.NegativeArraySizeException", "$.NullPointerException", "$.StringIndexOutOfBoundsException", "org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.value = null;
this.count = 0;
this.shared = false;
Clazz.instantialize (this, arguments);
}, java.lang, "AbstractStringBuilder");
Clazz.defineMethod (c$, "getValue", 
function () {
return this.value;
});
Clazz.defineMethod (c$, "shareValue", 
function () {
this.shared = true;
return this.value;
});
Clazz.defineMethod (c$, "set", 
function (a, b) {
if (a == null) a =  Clazz.newCharArray (0, '\0');
if (a.length < b) throw  new java.io.InvalidObjectException (org.apache.harmony.luni.util.Msg.getString ("K0199"));
this.shared = false;
this.value = a;
this.count = b;
}, "~A,~N");
Clazz.makeConstructor (c$, 
function () {
this.value =  Clazz.newCharArray (16, '\0');
});
Clazz.makeConstructor (c$, 
function (a) {
if (a < 0) throw  new NegativeArraySizeException ();
this.value =  Clazz.newCharArray (a, '\0');
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.count = a.length;
this.shared = false;
this.value =  Clazz.newCharArray (this.count + 16, '\0');
a.getChars (0, this.count, this.value, 0);
}, "~S");
Clazz.defineMethod (c$, "enlargeBuffer", 
function (a) {
var b = (this.value.length << 1) + 2;
var c =  Clazz.newCharArray (a > b ? a : b, '\0');
System.arraycopy (this.value, 0, c, 0, this.count);
this.value = c;
this.shared = false;
}, "~N");
Clazz.defineMethod (c$, "appendNull", 
function () {
var a = this.count + 4;
if (a > this.value.length) {
this.enlargeBuffer (a);
} else if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}this.value[this.count++] = 'n';
this.value[this.count++] = 'u';
this.value[this.count++] = 'l';
this.value[this.count++] = 'l';
});
Clazz.defineMethod (c$, "append0", 
function (a) {
var b = this.count + a.length;
if (b > this.value.length) {
this.enlargeBuffer (b);
} else if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}System.arraycopy (a, 0, this.value, this.count, a.length);
this.count = b;
}, "~A");
Clazz.defineMethod (c$, "append0", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException ();
}if (b >= 0 && 0 <= c && c <= a.length - b) {
var d = this.count + c;
if (d > this.value.length) {
this.enlargeBuffer (d);
} else if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}System.arraycopy (a, b, this.value, this.count, c);
this.count = d;
} else {
throw  new ArrayIndexOutOfBoundsException ();
}}, "~A,~N,~N");
Clazz.defineMethod (c$, "append0", 
function (a) {
if (this.count == this.value.length) {
this.enlargeBuffer (this.count + 1);
}if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}this.value[this.count++] = a;
}, "~S");
Clazz.defineMethod (c$, "append0", 
function (a) {
if (a == null) {
this.appendNull ();
return;
}var b = a.length;
var c = this.count + b;
if (c > this.value.length) {
this.enlargeBuffer (c);
} else if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}a.getChars (0, b, this.value, this.count);
this.count = c;
}, "~S");
Clazz.defineMethod (c$, "append0", 
function (a, b, c) {
if (a == null) a = "null";
if (b < 0 || c < 0 || b > c || c > a.length) throw  new IndexOutOfBoundsException ();
this.append0 (a.subSequence (b, c).toString ());
}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "capacity", 
function () {
return this.value.length;
});
Clazz.defineMethod (c$, "charAt", 
function (a) {
if (a < 0 || a >= this.count) throw  new StringIndexOutOfBoundsException (a);
return this.value[a];
}, "~N");
Clazz.defineMethod (c$, "delete0", 
function (a, b) {
if (a >= 0) {
if (b > this.count) {
b = this.count;
}if (b == a) {
return;
}if (b > a) {
var c = this.count - b;
if (c > 0) {
if (!this.shared) {
System.arraycopy (this.value, b, this.value, a, c);
} else {
var d =  Clazz.newCharArray (this.value.length, '\0');
System.arraycopy (this.value, 0, d, 0, a);
System.arraycopy (this.value, b, d, a, c);
this.value = d;
this.shared = false;
}}this.count -= b - a;
return;
}}throw  new StringIndexOutOfBoundsException ();
}, "~N,~N");
Clazz.defineMethod (c$, "deleteCharAt0", 
function (a) {
if (0 > a || a >= this.count) throw  new StringIndexOutOfBoundsException (a);
var b = this.count - a - 1;
if (b > 0) {
if (!this.shared) {
System.arraycopy (this.value, a + 1, this.value, a, b);
} else {
var c =  Clazz.newCharArray (this.value.length, '\0');
System.arraycopy (this.value, 0, c, 0, a);
System.arraycopy (this.value, a + 1, c, a, b);
this.value = c;
this.shared = false;
}}this.count--;
}, "~N");
Clazz.defineMethod (c$, "ensureCapacity", 
function (a) {
if (a > this.value.length) {
this.enlargeBuffer (a);
}}, "~N");
Clazz.defineMethod (c$, "getChars", 
function (a, b, c, d) {
if (a > this.count || b > this.count || a > b) {
throw  new StringIndexOutOfBoundsException ();
}System.arraycopy (this.value, a, c, d, b - a);
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "insert0", 
function (a, b) {
if (0 > a || a > this.count) {
throw  new StringIndexOutOfBoundsException (a);
}if (b.length != 0) {
this.move (b.length, a);
System.arraycopy (b, 0, this.value, a, b.length);
this.count += b.length;
}}, "~N,~A");
Clazz.defineMethod (c$, "insert0", 
function (a, b, c, d) {
if (0 <= a && a <= this.count) {
if (c >= 0 && 0 <= d && d <= b.length - c) {
if (d != 0) {
this.move (d, a);
System.arraycopy (b, c, this.value, a, d);
this.count += d;
}return;
}throw  new StringIndexOutOfBoundsException ("offset " + c + ", len " + d + ", array.length " + b.length);
}throw  new StringIndexOutOfBoundsException (a);
}, "~N,~A,~N,~N");
Clazz.defineMethod (c$, "insert0", 
function (a, b) {
if (0 > a || a > this.count) {
throw  new ArrayIndexOutOfBoundsException (a);
}this.move (1, a);
this.value[a] = b;
this.count++;
}, "~N,~S");
Clazz.defineMethod (c$, "insert0", 
function (a, b) {
if (0 <= a && a <= this.count) {
if (b == null) b = "null";
var c = b.length;
if (c != 0) {
this.move (c, a);
b.getChars (0, c, this.value, a);
this.count += c;
}} else {
throw  new StringIndexOutOfBoundsException (a);
}}, "~N,~S");
Clazz.defineMethod (c$, "insert0", 
function (a, b, c, d) {
if (b == null) b = "null";
if (a < 0 || a > this.count || c < 0 || d < 0 || c > d || d > b.length) throw  new IndexOutOfBoundsException ();
this.insert0 (a, b.subSequence (c, d).toString ());
}, "~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "length", 
function () {
return this.count;
});
Clazz.defineMethod (c$, "move", 
function (a, b) {
var c;
if (this.value.length - this.count >= a) {
if (!this.shared) {
System.arraycopy (this.value, b, this.value, b + a, this.count - b);
return;
}c = this.value.length;
} else {
var d = this.count + a;
var e = (this.value.length << 1) + 2;
c = d > e ? d : e;
}var d =  Clazz.newCharArray (c, '\0');
System.arraycopy (this.value, 0, d, 0, b);
System.arraycopy (this.value, b, d, b + a, this.count - b);
this.value = d;
this.shared = false;
}, "~N,~N");
Clazz.defineMethod (c$, "replace0", 
function (a, b, c) {
if (a >= 0) {
if (b > this.count) b = this.count;
if (b > a) {
var d = c.length;
var e = b - a - d;
if (e > 0) {
if (!this.shared) {
System.arraycopy (this.value, b, this.value, a + d, this.count - b);
} else {
var f =  Clazz.newCharArray (this.value.length, '\0');
System.arraycopy (this.value, 0, f, 0, a);
System.arraycopy (this.value, b, f, a + d, this.count - b);
this.value = f;
this.shared = false;
}} else if (e < 0) {
this.move (-e, b);
} else if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}c.getChars (0, d, this.value, a);
this.count -= e;
return;
}if (a == b) {
if (c == null) throw  new NullPointerException ();
this.insert0 (a, c);
return;
}}throw  new StringIndexOutOfBoundsException ();
}, "~N,~N,~S");
Clazz.defineMethod (c$, "reverse0", 
function () {
if (this.count < 2) {
return;
}if (!this.shared) {
for (var a = 0, b = this.count, c = Clazz.doubleToInt (this.count / 2); a < c; a++) {
var d = this.value[--b];
this.value[b] = this.value[a];
this.value[a] = d;
}
} else {
var a =  Clazz.newCharArray (this.value.length, '\0');
for (var b = 0, c = this.count; b < this.count; b++) {
a[--c] = this.value[b];
}
this.value = a;
this.shared = false;
}});
Clazz.defineMethod (c$, "setCharAt", 
function (a, b) {
if (0 > a || a >= this.count) {
throw  new StringIndexOutOfBoundsException (a);
}if (this.shared) {
this.value = this.value.clone ();
this.shared = false;
}this.value[a] = b;
}, "~N,~S");
Clazz.defineMethod (c$, "setLength", 
function (a) {
if (a < 0) throw  new StringIndexOutOfBoundsException (a);
if (this.count < a) {
if (a > this.value.length) {
this.enlargeBuffer (a);
} else {
if (this.shared) {
var b =  Clazz.newCharArray (this.value.length, '\0');
System.arraycopy (this.value, 0, b, 0, this.count);
this.value = b;
this.shared = false;
} else {
for (var b = this.count; b < a; b++) {
this.value[b] = String.fromCharCode ( 0);
}
}}}this.count = a;
}, "~N");
Clazz.defineMethod (c$, "substring", 
function (a) {
if (0 <= a && a <= this.count) {
if (a == this.count) return "";
this.shared = true;
return  String.instantialize (this.value, a, this.count - a);
}throw  new StringIndexOutOfBoundsException (a);
}, "~N");
Clazz.defineMethod (c$, "substring", 
function (a, b) {
if (0 <= a && a <= b && b <= this.count) {
if (a == b) return "";
this.shared = true;
return  String.instantialize (this.value, a, b - a);
}throw  new StringIndexOutOfBoundsException ();
}, "~N,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.count == 0) return "";
if (this.count >= 256 && this.count <= (this.value.length >> 1)) return  String.instantialize (this.value, 0, this.count);
this.shared = true;
return  String.instantialize (this.value, 0, this.count);
});
Clazz.defineMethod (c$, "subSequence", 
function (a, b) {
return this.substring (a, b);
}, "~N,~N");
Clazz.defineMethod (c$, "indexOf", 
function (a) {
return this.indexOf (a, 0);
}, "~S");
Clazz.defineMethod (c$, "indexOf", 
function (a, b) {
if (b < 0) b = 0;
var c = a.length;
if (c > 0) {
if (c + b > this.count) return -1;
var d = a.charAt (0);
while (true) {
var e = b;
var f = false;
for (; e < this.count; e++) if (this.value[e] == d) {
f = true;
break;
}
if (!f || c + e > this.count) return -1;
var g = e;
var h = 0;
while (++h < c && this.value[++g] == a.charAt (h)) {
}
if (h == c) return e;
b = e + 1;
}
}return (b < this.count || b == 0) ? b : this.count;
}, "~S,~N");
Clazz.defineMethod (c$, "lastIndexOf", 
function (a) {
return this.lastIndexOf (a, this.count);
}, "~S");
Clazz.defineMethod (c$, "lastIndexOf", 
function (a, b) {
var c = a.length;
if (c <= this.count && b >= 0) {
if (c > 0) {
if (b > this.count - c) b = this.count - c;
var d = a.charAt (0);
while (true) {
var e = b;
var f = false;
for (; e >= 0; --e) if (this.value[e] == d) {
f = true;
break;
}
if (!f) return -1;
var g = e;
var h = 0;
while (++h < c && this.value[++g] == a.charAt (h)) {
}
if (h == c) return e;
b = e - 1;
}
}return b < this.count ? b : this.count;
}return -1;
}, "~S,~N");
Clazz.defineMethod (c$, "trimToSize", 
function () {
if (this.count < this.value.length) {
var a =  Clazz.newCharArray (this.count, '\0');
System.arraycopy (this.value, 0, a, 0, this.count);
this.value = a;
this.shared = false;
}});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023