Clazz.load (["java.lang.IndexOutOfBoundsException"], "java.lang.ArrayIndexOutOfBoundsException", null, function () {
c$ = Clazz.declareType (java.lang, "ArrayIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, ArrayIndexOutOfBoundsException, ["Array index out of range: " + a]);
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023