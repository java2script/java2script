Clazz.load (["java.lang.Enum"], "java.lang.annotation.RetentionPolicy", null, function () {
c$ = Clazz.declareType (java.lang.annotation, "RetentionPolicy", Enum);
Clazz.defineEnumConstant (c$, "SOURCE", 0, []);
Clazz.defineEnumConstant (c$, "CLASS", 1, []);
Clazz.defineEnumConstant (c$, "RUNTIME", 2, []);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023