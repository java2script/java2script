Clazz.load (["java.lang.RuntimeException"], "java.lang.annotation.IncompleteAnnotationException", ["org.apache.harmony.luni.util.Msg"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$annotationType = null;
this.$elementName = null;
Clazz.instantialize (this, arguments);
}, java.lang.annotation, "IncompleteAnnotationException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.lang.annotation.IncompleteAnnotationException, [org.apache.harmony.luni.util.Msg.getString ("annotation.0", b, a)]);
this.$annotationType = a;
this.$elementName = b;
}, "Class,~S");
Clazz.defineMethod (c$, "annotationType", 
function () {
return this.$annotationType;
});
Clazz.defineMethod (c$, "elementName", 
function () {
return this.$elementName;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023