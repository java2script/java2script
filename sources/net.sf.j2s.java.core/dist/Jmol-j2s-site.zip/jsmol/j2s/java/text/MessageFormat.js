Clazz.declarePackage ("java.text");
c$ = Clazz.decorateAsClass (function () {
this.pattern = null;
Clazz.instantialize (this, arguments);
}, java.text, "MessageFormat");
Clazz.makeConstructor (c$, 
function (a) {
this.pattern = a;
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
this.pattern = a;
}, "~S,java.util.Locale");
c$.format = Clazz.defineMethod (c$, "format", 
function (a, b) {
return a.replace (/\{(\d+)\}/g, function ($0, $1) {
var i = parseInt ($1);
if (b == null) return null;
return b[i];
});
}, "~S,~A");
Clazz.defineMethod (c$, "format", 
function (c) {
return java.text.MessageFormat.format (this.pattern,  Clazz.newArray (-1, [c]));
}, "~O");
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023