Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.util.zip.InflaterInputStream", "$.ZipConstants", "$.CRC32"], "java.util.zip.ZipInputStream", ["java.io.EOFException", "$.IOException", "$.PushbackInputStream", "java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.Long", "$.NullPointerException", "java.util.zip.Inflater", "$.ZipEntry", "$.ZipException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.entry = null;
this.flag = 0;
this.crc = null;
this.remaining = 0;
this.tmpbuf = null;
this.$closed = false;
this.entryEOF = false;
this.zc = null;
this.byteTest = null;
this.$b = null;
Clazz.instantialize (this, arguments);
}, java.util.zip, "ZipInputStream", java.util.zip.InflaterInputStream, java.util.zip.ZipConstants);
Clazz.prepareFields (c$, function () {
this.crc =  new java.util.zip.CRC32 ();
this.tmpbuf =  Clazz.newByteArray (512, 0);
this.byteTest =  Clazz.newByteArray (-1, [0x20]);
this.$b =  Clazz.newByteArray (256, 0);
});
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.$closed) {
throw  new java.io.IOException ("Stream closed");
}});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.zip.ZipInputStream, [ new java.io.PushbackInputStream (a, 1024), java.util.zip.ZipInputStream.newInflater (), 512]);
var b = "UTF-8";
try {
 String.instantialize (this.byteTest, b);
} catch (e) {
if (Clazz.exceptionOf (e, java.io.UnsupportedEncodingException)) {
throw  new NullPointerException ("charset is invalid");
} else {
throw e;
}
}
this.zc = b;
}, "java.io.InputStream");
c$.newInflater = Clazz.defineMethod (c$, "newInflater", 
function () {
return  new java.util.zip.Inflater ().init (0, true);
});
Clazz.defineMethod (c$, "getNextEntry", 
function () {
this.ensureOpen ();
if (this.entry != null) {
this.closeEntry ();
}this.crc.reset ();
this.inflater = this.inf = java.util.zip.ZipInputStream.newInflater ();
if ((this.entry = this.readLOC ()) == null) {
return null;
}if (this.entry.method == 0) {
this.remaining = this.entry.size;
}this.entryEOF = false;
return this.entry;
});
Clazz.defineMethod (c$, "closeEntry", 
function () {
this.ensureOpen ();
while (this.read (this.tmpbuf, 0, this.tmpbuf.length) != -1) {
}
this.entryEOF = true;
});
Clazz.overrideMethod (c$, "available", 
function () {
this.ensureOpen ();
return (this.entryEOF ? 0 : 1);
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
this.ensureOpen ();
if (b < 0 || c < 0 || b > a.length - c) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return 0;
}if (this.entry == null) {
return -1;
}switch (this.entry.method) {
case 8:
c = this.readInf (a, b, c);
if (c == -1) {
this.readEnd (this.entry);
this.entryEOF = true;
this.entry = null;
} else {
this.crc.update (a, b, c);
}return c;
case 0:
if (this.remaining <= 0) {
this.entryEOF = true;
this.entry = null;
return -1;
}if (c > this.remaining) {
c = this.remaining;
}c = this.$in.read (a, b, c);
if (c == -1) {
throw  new java.util.zip.ZipException ("unexpected EOF");
}this.crc.update (a, b, c);
this.remaining -= c;
if (this.remaining == 0 && this.entry.crc != this.crc.getValue ()) {
throw  new java.util.zip.ZipException ("invalid entry CRC (expected 0x" + Long.toHexString (this.entry.crc) + " but got 0x" + Long.toHexString (this.crc.getValue ()) + ")");
}return c;
default:
throw  new java.util.zip.ZipException ("invalid compression method");
}
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skip", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("negative skip length");
}this.ensureOpen ();
var b = Math.min (a, 2147483647);
var c = 0;
while (c < b) {
var d = b - c;
if (d > this.tmpbuf.length) {
d = this.tmpbuf.length;
}d = this.read (this.tmpbuf, 0, d);
if (d == -1) {
this.entryEOF = true;
break;
}c += d;
}
return c;
}, "~N");
Clazz.defineMethod (c$, "close", 
function () {
if (!this.$closed) {
Clazz.superCall (this, java.util.zip.ZipInputStream, "close", []);
this.$closed = true;
}});
Clazz.defineMethod (c$, "readLOC", 
function () {
try {
this.readFully (this.tmpbuf, 0, 30);
} catch (e) {
if (Clazz.exceptionOf (e, java.io.EOFException)) {
return null;
} else {
throw e;
}
}
if (java.util.zip.ZipInputStream.get32 (this.tmpbuf, 0) != 67324752) {
return null;
}this.flag = java.util.zip.ZipInputStream.get16 (this.tmpbuf, 6);
var a = java.util.zip.ZipInputStream.get16 (this.tmpbuf, 26);
var b = this.$b.length;
if (a > b) {
do b = b * 2;
 while (a > b);
this.$b =  Clazz.newByteArray (b, 0);
}this.readFully (this.$b, 0, a);
var c = this.createZipEntry (((this.flag & 2048) != 0) ? this.toStringUTF8 (this.$b, a) : this.toStringb2 (this.$b, a));
if ((this.flag & 1) == 1) {
throw  new java.util.zip.ZipException ("encrypted ZIP entry not supported");
}c.method = java.util.zip.ZipInputStream.get16 (this.tmpbuf, 8);
c.time = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 10);
if ((this.flag & 8) == 8) {
if (c.method != 8) {
throw  new java.util.zip.ZipException ("only DEFLATED entries can have EXT descriptor");
}} else {
c.crc = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 14);
c.csize = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 18);
c.size = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 22);
}a = java.util.zip.ZipInputStream.get16 (this.tmpbuf, 28);
if (a > 0) {
var d =  Clazz.newByteArray (a, 0);
this.readFully (d, 0, a);
c.setExtra (d);
if (c.csize == 4294967295 || c.size == 4294967295) {
var e = 0;
while (e + 4 < a) {
var f = java.util.zip.ZipInputStream.get16 (d, e + 2);
if (java.util.zip.ZipInputStream.get16 (d, e) == 1) {
e += 4;
if (f < 16 || (e + f) > a) {
return c;
}c.size = java.util.zip.ZipInputStream.get64 (d, e);
c.csize = java.util.zip.ZipInputStream.get64 (d, e + 8);
break;
}e += (f + 4);
}
}}return c;
});
Clazz.defineMethod (c$, "toStringUTF8", 
function (a, b) {
try {
return  String.instantialize (a, 0, b, this.zc);
} catch (e) {
if (Clazz.exceptionOf (e, java.io.UnsupportedEncodingException)) {
return this.toStringb2 (a, b);
} else {
throw e;
}
}
}, "~A,~N");
Clazz.defineMethod (c$, "toStringb2", 
function (a, b) {
return  String.instantialize (a, 0, b);
}, "~A,~N");
Clazz.defineMethod (c$, "createZipEntry", 
function (a) {
return  new java.util.zip.ZipEntry (a);
}, "~S");
Clazz.defineMethod (c$, "readEnd", 
function (a) {
var b = this.inf.getAvailIn ();
if (b > 0) {
(this.$in).unread (this.buf, this.len - b, b);
this.eof = false;
}if ((this.flag & 8) == 8) {
if (this.inf.getTotalOut () > 4294967295 || this.inf.getTotalIn () > 4294967295) {
this.readFully (this.tmpbuf, 0, 24);
var c = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 0);
if (c != 134695760) {
a.crc = c;
a.csize = java.util.zip.ZipInputStream.get64 (this.tmpbuf, 4);
a.size = java.util.zip.ZipInputStream.get64 (this.tmpbuf, 12);
(this.$in).unread (this.tmpbuf, 19, 4);
} else {
a.crc = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 4);
a.csize = java.util.zip.ZipInputStream.get64 (this.tmpbuf, 8);
a.size = java.util.zip.ZipInputStream.get64 (this.tmpbuf, 16);
}} else {
this.readFully (this.tmpbuf, 0, 16);
var c = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 0);
if (c != 134695760) {
a.crc = c;
a.csize = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 4);
a.size = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 8);
(this.$in).unread (this.tmpbuf, 11, 4);
} else {
a.crc = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 4);
a.csize = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 8);
a.size = java.util.zip.ZipInputStream.get32 (this.tmpbuf, 12);
}}}if (a.size != this.inf.getTotalOut ()) {
throw  new java.util.zip.ZipException ("invalid entry size (expected " + a.size + " but got " + this.inf.getTotalOut () + " bytes)");
}if (a.csize != this.inf.getTotalIn ()) {
throw  new java.util.zip.ZipException ("invalid entry compressed size (expected " + a.csize + " but got " + this.inf.getTotalIn () + " bytes)");
}if (a.crc != this.crc.getValue ()) {
throw  new java.util.zip.ZipException ("invalid entry CRC (expected 0x" + Long.toHexString (a.crc) + " but got 0x" + Long.toHexString (this.crc.getValue ()) + ")");
}}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "readFully", 
function (a, b, c) {
while (c > 0) {
var d = this.$in.read (a, b, c);
if (d == -1) {
throw  new java.io.EOFException ();
}b += d;
c -= d;
}
}, "~A,~N,~N");
c$.get16 = Clazz.defineMethod (c$, "get16", 
function (a, b) {
return (a[b] & 0xff) | ((a[b + 1] & 0xff) << 8);
}, "~A,~N");
c$.get32 = Clazz.defineMethod (c$, "get32", 
function (a, b) {
return (java.util.zip.ZipInputStream.get16 (a, b) | (java.util.zip.ZipInputStream.get16 (a, b + 2) << 16)) & 0xffffffff;
}, "~A,~N");
c$.get64 = Clazz.defineMethod (c$, "get64", 
function (a, b) {
return java.util.zip.ZipInputStream.get32 (a, b) | (java.util.zip.ZipInputStream.get32 (a, b + 4) << 32);
}, "~A,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023