Clazz.load (["java.util.AbstractList", "$.List", "$.RandomAccess"], "java.util.ArrayList", ["java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "java.lang.reflect.Array", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.firstIndex = 0;
this.lastIndex = 0;
this.array = null;
Clazz.instantialize (this, arguments);
}, java.util, "ArrayList", java.util.AbstractList, [java.util.List, Cloneable, java.io.Serializable, java.util.RandomAccess]);
Clazz.makeConstructor (c$, 
function () {
this.construct (0);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.ArrayList, []);
this.firstIndex = this.lastIndex = 0;
try {
this.array = this.newElementArray (a);
} catch (e) {
if (Clazz.exceptionOf (e, NegativeArraySizeException)) {
throw  new IllegalArgumentException ();
} else {
throw e;
}
}
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.ArrayList, []);
var b = a.size ();
this.firstIndex = this.lastIndex = 0;
this.array = this.newElementArray (b + (Clazz.doubleToInt (b / 10)));
this.addAll (a);
}, "java.util.Collection");
Clazz.defineMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.defineMethod (c$, "add", 
function (a, b) {
var c = this.size ();
if (0 < a && a < c) {
if (this.firstIndex == 0 && this.lastIndex == this.array.length) {
this.growForInsert (a, 1);
} else if ((a < Clazz.doubleToInt (c / 2) && this.firstIndex > 0) || this.lastIndex == this.array.length) {
System.arraycopy (this.array, this.firstIndex, this.array, --this.firstIndex, a);
} else {
var d = a + this.firstIndex;
System.arraycopy (this.array, d, this.array, d + 1, c - a);
this.lastIndex++;
}this.array[a + this.firstIndex] = b;
} else if (a == 0) {
if (this.firstIndex == 0) {
this.growAtFront (1);
}this.array[--this.firstIndex] = b;
} else if (a == c) {
if (this.lastIndex == this.array.length) {
this.growAtEnd (1);
}this.array[this.lastIndex++] = b;
} else {
throw  new IndexOutOfBoundsException ();
}this.modCount++;
}, "~N,~O");
Clazz.defineMethod (c$, "add", 
function (a) {
if (this.lastIndex == this.array.length) {
this.growAtEnd (1);
}this.array[this.lastIndex++] = a;
this.modCount++;
return true;
}, "~O");
Clazz.defineMethod (c$, "addAll", 
function (a, b) {
var c = this.size ();
if (a < 0 || a > c) {
throw  new IndexOutOfBoundsException ();
}var d = b.size ();
if (0 < a && a < c) {
if (this.array.length - c < d) {
this.growForInsert (a, d);
} else if ((a < Clazz.doubleToInt (c / 2) && this.firstIndex > 0) || this.lastIndex > this.array.length - d) {
var e = this.firstIndex - d;
if (e < 0) {
var f = a + this.firstIndex;
System.arraycopy (this.array, f, this.array, f - e, c - a);
this.lastIndex -= e;
e = 0;
}System.arraycopy (this.array, this.firstIndex, this.array, e, a);
this.firstIndex = e;
} else {
var e = a + this.firstIndex;
System.arraycopy (this.array, e, this.array, e + d, c - a);
this.lastIndex += d;
}} else if (a == 0) {
this.growAtFront (d);
this.firstIndex -= d;
} else if (a == c) {
if (this.lastIndex > this.array.length - d) {
this.growAtEnd (d);
}this.lastIndex += d;
}if (d > 0) {
var e = b.iterator ();
var f = a + this.firstIndex;
var g = f + d;
while (f < g) {
this.array[f++] = e.next ();
}
this.modCount++;
return true;
}return false;
}, "~N,java.util.Collection");
Clazz.defineMethod (c$, "addAll", 
function (a) {
var b = a.size ();
if (b > 0) {
if (this.lastIndex > this.array.length - b) {
this.growAtEnd (b);
}var c = a.iterator ();
var d = this.lastIndex + b;
while (this.lastIndex < d) {
this.array[this.lastIndex++] = c.next ();
}
this.modCount++;
return true;
}return false;
}, "java.util.Collection");
Clazz.overrideMethod (c$, "clear", 
function () {
if (this.firstIndex != this.lastIndex) {
java.util.Arrays.fill (this.array, this.firstIndex, this.lastIndex, null);
this.firstIndex = this.lastIndex = 0;
this.modCount++;
}});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.ArrayList, "clone", []);
a.array = this.array.clone ();
return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (a != null) {
for (var b = this.firstIndex; b < this.lastIndex; b++) {
if (a.equals (this.array[b])) {
return true;
}}
} else {
for (var b = this.firstIndex; b < this.lastIndex; b++) {
if (this.array[b] == null) {
return true;
}}
}return false;
}, "~O");
Clazz.defineMethod (c$, "ensureCapacity", 
function (a) {
if (this.array.length < a) {
if (this.firstIndex > 0) {
this.growAtFront (a - this.array.length);
} else {
this.growAtEnd (a - this.array.length);
}}}, "~N");
Clazz.overrideMethod (c$, "get", 
function (a) {
if (0 <= a && a < this.size ()) {
return this.array[this.firstIndex + a];
}throw  new IndexOutOfBoundsException ();
}, "~N");
Clazz.defineMethod (c$, "growAtEnd", 
function (a) {
var b = this.size ();
if (this.firstIndex >= a - (this.array.length - this.lastIndex)) {
var c = this.lastIndex - this.firstIndex;
if (b > 0) {
System.arraycopy (this.array, this.firstIndex, this.array, 0, b);
var d = c < this.firstIndex ? this.firstIndex : c;
java.util.Arrays.fill (this.array, d, this.array.length, null);
}this.firstIndex = 0;
this.lastIndex = c;
} else {
var c = Clazz.doubleToInt (b / 2);
if (a > c) {
c = a;
}if (c < 12) {
c = 12;
}var d = this.newElementArray (b + c);
if (b > 0) {
System.arraycopy (this.array, this.firstIndex, d, this.firstIndex, b);
}this.array = d;
}}, "~N");
Clazz.defineMethod (c$, "growAtFront", 
function (a) {
var b = this.size ();
if (this.array.length - this.lastIndex >= a) {
var c = this.array.length - b;
if (b > 0) {
System.arraycopy (this.array, this.firstIndex, this.array, c, b);
var d = this.firstIndex + b > c ? c : this.firstIndex + b;
java.util.Arrays.fill (this.array, this.firstIndex, d, null);
}this.firstIndex = c;
this.lastIndex = this.array.length;
} else {
var c = Clazz.doubleToInt (b / 2);
if (a > c) {
c = a;
}if (c < 12) {
c = 12;
}var d = this.newElementArray (b + c);
if (b > 0) {
System.arraycopy (this.array, this.firstIndex, d, d.length - b, b);
}this.firstIndex = d.length - b;
this.lastIndex = d.length;
this.array = d;
}}, "~N");
Clazz.defineMethod (c$, "growForInsert", 
function (a, b) {
var c = this.size ();
var d = Clazz.doubleToInt (c / 2);
if (b > d) {
d = b;
}if (d < 12) {
d = 12;
}var e = this.newElementArray (c + d);
if (a < Clazz.doubleToInt (c / 2)) {
var f = e.length - (c + b);
System.arraycopy (this.array, a, e, a + d, c - a);
System.arraycopy (this.array, this.firstIndex, e, f, a);
this.firstIndex = f;
this.lastIndex = e.length;
} else {
System.arraycopy (this.array, this.firstIndex, e, 0, a);
System.arraycopy (this.array, a, e, a + b, c - a);
this.firstIndex = 0;
this.lastIndex += b;
}this.array = e;
}, "~N,~N");
Clazz.overrideMethod (c$, "indexOf", 
function (a) {
if (a != null) {
for (var b = this.firstIndex; b < this.lastIndex; b++) {
if (a.equals (this.array[b])) {
return b - this.firstIndex;
}}
} else {
for (var b = this.firstIndex; b < this.lastIndex; b++) {
if (this.array[b] == null) {
return b - this.firstIndex;
}}
}return -1;
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.lastIndex == this.firstIndex;
});
Clazz.overrideMethod (c$, "lastIndexOf", 
function (a) {
if (a != null) {
for (var b = this.lastIndex - 1; b >= this.firstIndex; b--) {
if (a.equals (this.array[b])) {
return b - this.firstIndex;
}}
} else {
for (var b = this.lastIndex - 1; b >= this.firstIndex; b--) {
if (this.array[b] == null) {
return b - this.firstIndex;
}}
}return -1;
}, "~O");
Clazz.defineMethod (c$, "remove", 
function (a) {
var b;
var c = this.size ();
if (0 <= a && a < c) {
if (a == c - 1) {
b = this.array[--this.lastIndex];
this.array[this.lastIndex] = null;
} else if (a == 0) {
b = this.array[this.firstIndex];
this.array[this.firstIndex++] = null;
} else {
var d = this.firstIndex + a;
b = this.array[d];
if (a < Clazz.doubleToInt (c / 2)) {
System.arraycopy (this.array, this.firstIndex, this.array, this.firstIndex + 1, a);
this.array[this.firstIndex++] = null;
} else {
System.arraycopy (this.array, d + 1, this.array, d, c - a - 1);
this.array[--this.lastIndex] = null;
}}} else {
throw  new IndexOutOfBoundsException ();
}this.modCount++;
return b;
}, "~N");
Clazz.overrideMethod (c$, "removeRange", 
function (a, b) {
if (a >= 0 && a <= b && b <= this.size ()) {
if (a == b) {
return;
}var c = this.size ();
if (b == c) {
java.util.Arrays.fill (this.array, this.firstIndex + a, this.lastIndex, null);
this.lastIndex = this.firstIndex + a;
} else if (a == 0) {
java.util.Arrays.fill (this.array, this.firstIndex, this.firstIndex + b, null);
this.firstIndex += b;
} else {
System.arraycopy (this.array, this.firstIndex + b, this.array, this.firstIndex + a, c - b);
var d = this.lastIndex + a - b;
java.util.Arrays.fill (this.array, d, this.lastIndex, null);
this.lastIndex = d;
}this.modCount++;
} else {
throw  new IndexOutOfBoundsException ();
}}, "~N,~N");
Clazz.overrideMethod (c$, "set", 
function (a, b) {
if (0 <= a && a < this.size ()) {
var c = this.array[this.firstIndex + a];
this.array[this.firstIndex + a] = b;
return c;
}throw  new IndexOutOfBoundsException ();
}, "~N,~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.lastIndex - this.firstIndex;
});
Clazz.defineMethod (c$, "toArray", 
function () {
var a = this.size ();
var b =  new Array (a);
System.arraycopy (this.array, this.firstIndex, b, 0, a);
return b;
});
Clazz.defineMethod (c$, "toArray", 
function (a) {
var b = this.size ();
if (b > a.length) {
var c = a.getClass ().getComponentType ();
a = java.lang.reflect.Array.newInstance (c, b);
}System.arraycopy (this.array, this.firstIndex, a, 0, b);
if (b < a.length) {
a[b] = null;
}return a;
}, "~A");
Clazz.defineMethod (c$, "trimToSize", 
function () {
var a = this.size ();
var b = this.newElementArray (a);
System.arraycopy (this.array, this.firstIndex, b, 0, a);
this.array = b;
this.firstIndex = 0;
this.lastIndex = this.array.length;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023