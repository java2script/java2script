Clazz.load (["java.util.Iterator"], "java.util.ListIterator", null, function () {
Clazz.declareInterface (java.util, "ListIterator", java.util.Iterator);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023