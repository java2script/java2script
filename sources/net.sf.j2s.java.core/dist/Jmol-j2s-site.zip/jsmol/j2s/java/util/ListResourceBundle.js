Clazz.load (["java.util.ResourceBundle"], "java.util.ListResourceBundle", ["java.util.Enumeration", "$.Hashtable"], function () {
c$ = Clazz.decorateAsClass (function () {
this.table = null;
Clazz.instantialize (this, arguments);
}, java.util, "ListResourceBundle", java.util.ResourceBundle);
Clazz.defineMethod (c$, "getKeys", 
function () {
if (this.table == null) {
this.initializeTable ();
}if (this.parent == null) {
return this.table.keys ();
}return ((Clazz.isClassDefined ("java.util.ListResourceBundle$1") ? 0 : java.util.ListResourceBundle.$ListResourceBundle$1$ ()), Clazz.innerTypeInstance (java.util.ListResourceBundle$1, this, null));
});
Clazz.overrideMethod (c$, "handleGetObject", 
function (a) {
if (this.table == null) {
this.initializeTable ();
}return this.table.get (a);
}, "~S");
Clazz.defineMethod (c$, "initializeTable", 
function () {
if (this.table == null) {
var a = this.getContents ();
this.table =  new java.util.Hashtable (Clazz.doubleToInt (a.length / 3) * 4 + 3);
for (var b = 0; b < a.length; b++) {
this.table.put (a[b][0], a[b][1]);
}
}});
c$.$ListResourceBundle$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.local = null;
this.pEnum = null;
this.$nextElement = null;
Clazz.instantialize (this, arguments);
}, java.util, "ListResourceBundle$1", null, java.util.Enumeration);
Clazz.prepareFields (c$, function () {
this.local = this.b$["java.util.ListResourceBundle"].table.keys ();
this.pEnum = this.b$["java.util.ListResourceBundle"].parent.getKeys ();
});
Clazz.defineMethod (c$, "findNext", 
function () {
if (this.$nextElement != null) {
return true;
}while (this.pEnum.hasMoreElements ()) {
var a = this.pEnum.nextElement ();
if (!this.b$["java.util.ListResourceBundle"].table.containsKey (a)) {
this.$nextElement = a;
return true;
}}
return false;
});
Clazz.defineMethod (c$, "hasMoreElements", 
function () {
if (this.local.hasMoreElements ()) {
return true;
}return this.findNext ();
});
Clazz.defineMethod (c$, "nextElement", 
function () {
if (this.local.hasMoreElements ()) {
return this.local.nextElement ();
}if (this.findNext ()) {
var a = this.$nextElement;
this.$nextElement = null;
return a;
}return this.pEnum.nextElement ();
});
c$ = Clazz.p0p ();
};
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023