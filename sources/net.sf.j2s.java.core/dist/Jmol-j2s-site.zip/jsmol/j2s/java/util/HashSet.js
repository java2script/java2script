Clazz.load (["java.util.AbstractSet", "$.Set"], "java.util.HashSet", ["java.util.HashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.backingMap = null;
Clazz.instantialize (this, arguments);
}, java.util, "HashSet", java.util.AbstractSet, [java.util.Set, Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function () {
this.construct ( new java.util.HashMap ());
});
Clazz.makeConstructor (c$, 
function (a) {
this.construct ( new java.util.HashMap (a));
}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct ( new java.util.HashMap (a, b));
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct ( new java.util.HashMap (a.size () < 6 ? 11 : a.size () * 2));
for (var e, $e = a.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
this.add (e);
}
}, "java.util.Collection");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.HashSet, []);
this.backingMap = a;
}, "java.util.HashMap");
Clazz.overrideMethod (c$, "add", 
function (a) {
return this.backingMap.put (a, this) == null;
}, "~O");
Clazz.overrideMethod (c$, "clear", 
function () {
this.backingMap.clear ();
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.HashSet, "clone", []);
a.backingMap = this.backingMap.clone ();
return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.backingMap.containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.backingMap.isEmpty ();
});
Clazz.defineMethod (c$, "iterator", 
function () {
return this.backingMap.keySet ().iterator ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
return this.backingMap.remove (a) != null;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.backingMap.size ();
});
Clazz.defineMethod (c$, "createBackingMap", 
function (a, b) {
return  new java.util.HashMap (a, b);
}, "~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023