Clazz.load (["java.lang.IllegalArgumentException"], "java.util.IllegalFormatException", null, function () {
c$ = Clazz.declareType (java.util, "IllegalFormatException", IllegalArgumentException, java.io.Serializable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.IllegalFormatException, []);
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023