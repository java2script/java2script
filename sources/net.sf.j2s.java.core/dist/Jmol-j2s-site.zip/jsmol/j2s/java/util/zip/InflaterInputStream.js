Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.InflaterInputStream"], "java.util.zip.InflaterInputStream", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.inf = null;
Clazz.instantialize (this, arguments);
}, java.util.zip, "InflaterInputStream", com.jcraft.jzlib.InflaterInputStream);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.zip.InflaterInputStream, [a, b, c, true]);
this.inf = b;
}, "java.io.InputStream,java.util.zip.Inflater,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023