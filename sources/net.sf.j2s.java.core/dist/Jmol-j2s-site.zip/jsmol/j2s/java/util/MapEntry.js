Clazz.load (["java.util.Map"], "java.util.MapEntry", ["java.util.Map.Entry"], function () {
c$ = Clazz.decorateAsClass (function () {
this.key = null;
this.value = null;
Clazz.instantialize (this, arguments);
}, java.util, "MapEntry", null, [java.util.Map.Entry, Cloneable]);
Clazz.makeConstructor (c$, 
function (a) {
this.key = a;
}, "~O");
Clazz.makeConstructor (c$, 
function (a, b) {
this.key = a;
this.value = b;
}, "~O,~O");
Clazz.defineMethod (c$, "clone", 
function () {
try {
return Clazz.superCall (this, java.util.MapEntry, "clone", []);
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = a;
return (this.key == null ? b.getKey () == null : this.key.equals (b.getKey ())) && (this.value == null ? b.getValue () == null : this.value.equals (b.getValue ()));
}return false;
}, "~O");
Clazz.overrideMethod (c$, "getKey", 
function () {
return this.key;
});
Clazz.overrideMethod (c$, "getValue", 
function () {
return this.value;
});
Clazz.overrideMethod (c$, "hashCode", 
function () {
return (this.key == null ? 0 : this.key.hashCode ()) ^ (this.value == null ? 0 : this.value.hashCode ());
});
Clazz.overrideMethod (c$, "setValue", 
function (a) {
var b = this.value;
this.value = a;
return b;
}, "~O");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.key + "=" + this.value;
});
Clazz.declareInterface (java.util.MapEntry, "Type");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023