Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.Inflater"], "java.util.zip.Inflater", null, function () {
c$ = Clazz.declareType (java.util.zip, "Inflater", com.jcraft.jzlib.Inflater);
Clazz.defineMethod (c$, "initialize", 
function (a) {
return this.init (0, a);
}, "~B");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023