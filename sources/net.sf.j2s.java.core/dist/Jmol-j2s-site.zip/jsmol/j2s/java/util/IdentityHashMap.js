Clazz.load (["java.util.AbstractMap", "$.AbstractSet", "$.Iterator", "$.Map", "$.MapEntry"], "java.util.IdentityHashMap", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "java.util.AbstractCollection", "$.ConcurrentModificationException", "java.util.Map.Entry", "java.util.MapEntry.Type", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.elementData = null;
this.$size = 0;
this.threshold = 0;
this.modCount = 0;
Clazz.instantialize (this, arguments);
}, java.util, "IdentityHashMap", java.util.AbstractMap, [java.util.Map, java.io.Serializable, Cloneable]);
Clazz.makeConstructor (c$, 
function () {
this.construct (21);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.IdentityHashMap, []);
if (a >= 0) {
this.$size = 0;
this.threshold = this.getThreshold (a);
this.elementData = this.newElementArray (this.computeElementArraySize ());
} else {
throw  new IllegalArgumentException ();
}}, "~N");
Clazz.defineMethod (c$, "getThreshold", 
function (a) {
return a > 3 ? a : 3;
}, "~N");
Clazz.defineMethod (c$, "computeElementArraySize", 
function () {
return (Clazz.doubleToInt ((this.threshold * 10000) / 7500)) * 2;
});
Clazz.defineMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.size () < 6 ? 11 : a.size () * 2);
this.putAllImpl (a);
}, "java.util.Map");
Clazz.defineMethod (c$, "massageValue", 
function (a) {
return ((a === java.util.IdentityHashMap.NULL_OBJECT) ? null : a);
}, "~O");
Clazz.overrideMethod (c$, "clear", 
function () {
this.$size = 0;
for (var a = 0; a < this.elementData.length; a++) {
this.elementData[a] = null;
}
this.modCount++;
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
if (a == null) {
a = java.util.IdentityHashMap.NULL_OBJECT;
}var b = this.findIndex (a, this.elementData);
return this.elementData[b] === a;
}, "~O");
Clazz.overrideMethod (c$, "containsValue", 
function (a) {
if (a == null) {
a = java.util.IdentityHashMap.NULL_OBJECT;
}for (var b = 1; b < this.elementData.length; b = b + 2) {
if (this.elementData[b] === a) {
return true;
}}
return false;
}, "~O");
Clazz.overrideMethod (c$, "get", 
function (a) {
if (a == null) {
a = java.util.IdentityHashMap.NULL_OBJECT;
}var b = this.findIndex (a, this.elementData);
if (this.elementData[b] === a) {
var c = this.elementData[b + 1];
return this.massageValue (c);
}return null;
}, "~O");
Clazz.defineMethod (c$, "getEntry", 
function (a) {
if (a == null) {
a = java.util.IdentityHashMap.NULL_OBJECT;
}var b = this.findIndex (a, this.elementData);
if (this.elementData[b] === a) {
return this.getEntry (b);
}return null;
}, "~O");
Clazz.defineMethod (c$, "getEntry", 
function (a) {
var b = this.elementData[a];
var c = this.elementData[a + 1];
if (b === java.util.IdentityHashMap.NULL_OBJECT) {
b = null;
}if (c === java.util.IdentityHashMap.NULL_OBJECT) {
c = null;
}return  new java.util.IdentityHashMap.IdentityHashMapEntry (b, c);
}, "~N");
Clazz.defineMethod (c$, "findIndex", 
function (a, b) {
var c = b.length;
var d = this.getModuloHash (a, c);
var e = (d + c - 2) % c;
while (d != e) {
if (b[d] === a || (b[d] == null)) {
break;
}d = (d + 2) % c;
}
return d;
}, "~O,~A");
Clazz.defineMethod (c$, "getModuloHash", 
function (a, b) {
return ((System.identityHashCode (a) & 0x7FFFFFFF) % (Clazz.doubleToInt (b / 2))) * 2;
}, "~O,~N");
Clazz.overrideMethod (c$, "put", 
function (a, b) {
var c = a;
var d = b;
if (c == null) {
c = java.util.IdentityHashMap.NULL_OBJECT;
}if (d == null) {
d = java.util.IdentityHashMap.NULL_OBJECT;
}var e = this.findIndex (c, this.elementData);
if (this.elementData[e] !== c) {
this.modCount++;
if (++this.$size > this.threshold) {
this.rehash ();
e = this.findIndex (c, this.elementData);
}this.elementData[e] = c;
this.elementData[e + 1] = null;
}var f = this.elementData[e + 1];
this.elementData[e + 1] = d;
return this.massageValue (f);
}, "~O,~O");
Clazz.overrideMethod (c$, "putAll", 
function (a) {
this.putAllImpl (a);
}, "java.util.Map");
Clazz.defineMethod (c$, "rehash", 
function () {
var a = this.elementData.length << 1;
if (a == 0) {
a = 1;
}var b = this.newElementArray (a);
for (var c = 0; c < this.elementData.length; c = c + 2) {
var d = this.elementData[c];
if (d != null) {
var e = this.findIndex (d, b);
b[e] = d;
b[e + 1] = this.elementData[c + 1];
}}
this.elementData = b;
this.computeMaxSize ();
});
Clazz.defineMethod (c$, "computeMaxSize", 
function () {
this.threshold = (Clazz.doubleToInt ((Clazz.doubleToInt (this.elementData.length / 2)) * 7500 / 10000));
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (a == null) {
a = java.util.IdentityHashMap.NULL_OBJECT;
}var b;
var c;
var d;
var e;
var f;
var g;
c = d = this.findIndex (a, this.elementData);
if (this.elementData[c] !== a) {
return null;
}f = this.elementData[c + 1];
var h = this.elementData.length;
while (true) {
d = (d + 2) % h;
g = this.elementData[d];
if (g == null) {
break;
}e = this.getModuloHash (g, h);
b = e > c;
if (d < c) {
b = b || (e <= d);
} else {
b = b && (e <= d);
}if (!b) {
this.elementData[c] = g;
this.elementData[c + 1] = this.elementData[d + 1];
c = d;
}}
this.$size--;
this.modCount++;
this.elementData[c] = null;
this.elementData[c + 1] = null;
return this.massageValue (f);
}, "~O");
Clazz.overrideMethod (c$, "entrySet", 
function () {
return  new java.util.IdentityHashMap.IdentityHashMapEntrySet (this);
});
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.IdentityHashMap$1") ? 0 : java.util.IdentityHashMap.$IdentityHashMap$1$ ()), Clazz.innerTypeInstance (java.util.IdentityHashMap$1, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.IdentityHashMap$2") ? 0 : java.util.IdentityHashMap.$IdentityHashMap$2$ ()), Clazz.innerTypeInstance (java.util.IdentityHashMap$2, this, null));
}return this.valuesCollection;
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Map)) {
var b = a;
if (this.size () != b.size ()) {
return false;
}var c = this.entrySet ();
return c.equals (b.entrySet ());
}return false;
}, "~O");
Clazz.defineMethod (c$, "clone", 
function () {
try {
return Clazz.superCall (this, java.util.IdentityHashMap, "clone", []);
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.$size == 0;
});
Clazz.overrideMethod (c$, "size", 
function () {
return this.$size;
});
Clazz.defineMethod (c$, "putAllImpl", 
function (a) {
if (a.entrySet () != null) {
Clazz.superCall (this, java.util.IdentityHashMap, "putAll", [a]);
}}, "java.util.Map");
c$.$IdentityHashMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "IdentityHashMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.IdentityHashMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.IdentityHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.IdentityHashMap"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.b$["java.util.IdentityHashMap"].containsKey (a)) {
this.b$["java.util.IdentityHashMap"].remove (a);
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.IdentityHashMap.IdentityHashMapIterator (((Clazz.isClassDefined ("java.util.IdentityHashMap$1$1") ? 0 : java.util.IdentityHashMap.$IdentityHashMap$1$1$ ()), Clazz.innerTypeInstance (java.util.IdentityHashMap$1$1, this, null)), this.b$["java.util.IdentityHashMap"]);
});
c$ = Clazz.p0p ();
};
c$.$IdentityHashMap$1$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "IdentityHashMap$1$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.key;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$IdentityHashMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "IdentityHashMap$2", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.IdentityHashMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.IdentityHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.IdentityHashMap"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.IdentityHashMap.IdentityHashMapIterator (((Clazz.isClassDefined ("java.util.IdentityHashMap$2$1") ? 0 : java.util.IdentityHashMap.$IdentityHashMap$2$1$ ()), Clazz.innerTypeInstance (java.util.IdentityHashMap$2$1, this, null)), this.b$["java.util.IdentityHashMap"]);
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.iterator ();
while (b.hasNext ()) {
if (a === b.next ()) {
b.remove ();
return true;
}}
return false;
}, "~O");
c$ = Clazz.p0p ();
};
c$.$IdentityHashMap$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "IdentityHashMap$2$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.value;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.IdentityHashMap, "IdentityHashMapEntry", java.util.MapEntry);
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = a;
return (this.key === b.getKey ()) && (this.value === b.getValue ());
}return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return System.identityHashCode (this.key) ^ System.identityHashCode (this.value);
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.key + "=" + this.value;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.position = 0;
this.lastPosition = 0;
this.associatedMap = null;
this.expectedModCount = 0;
this.type = null;
this.canRemove = false;
Clazz.instantialize (this, arguments);
}, java.util.IdentityHashMap, "IdentityHashMapIterator", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a, b) {
this.associatedMap = b;
this.type = a;
this.expectedModCount = b.modCount;
}, "java.util.MapEntry.Type,java.util.IdentityHashMap");
Clazz.overrideMethod (c$, "hasNext", 
function () {
while (this.position < this.associatedMap.elementData.length) {
if (this.associatedMap.elementData[this.position] == null) {
this.position += 2;
} else {
return true;
}}
return false;
});
Clazz.defineMethod (c$, "checkConcurrentMod", 
function () {
if (this.expectedModCount != this.associatedMap.modCount) {
throw  new java.util.ConcurrentModificationException ();
}});
Clazz.overrideMethod (c$, "next", 
function () {
this.checkConcurrentMod ();
if (!this.hasNext ()) {
throw  new java.util.NoSuchElementException ();
}var a = this.associatedMap.getEntry (this.position);
this.lastPosition = this.position;
this.position += 2;
this.canRemove = true;
return this.type.get (a);
});
Clazz.overrideMethod (c$, "remove", 
function () {
this.checkConcurrentMod ();
if (!this.canRemove) {
throw  new IllegalStateException ();
}this.canRemove = false;
this.associatedMap.remove (this.associatedMap.elementData[this.lastPosition]);
this.position = this.lastPosition;
this.expectedModCount++;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.associatedMap = null;
Clazz.instantialize (this, arguments);
}, java.util.IdentityHashMap, "IdentityHashMapEntrySet", java.util.AbstractSet);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.IdentityHashMap.IdentityHashMapEntrySet, []);
this.associatedMap = a;
}, "java.util.IdentityHashMap");
Clazz.defineMethod (c$, "hashMap", 
function () {
return this.associatedMap;
});
Clazz.overrideMethod (c$, "size", 
function () {
return this.associatedMap.$size;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.associatedMap.clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.contains (a)) {
this.associatedMap.remove ((a).getKey ());
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = this.associatedMap.getEntry ((a).getKey ());
return b != null && b.equals (a);
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.IdentityHashMap.IdentityHashMapIterator (((Clazz.isClassDefined ("java.util.IdentityHashMap$IdentityHashMapEntrySet$1") ? 0 : java.util.IdentityHashMap.IdentityHashMapEntrySet.$IdentityHashMap$IdentityHashMapEntrySet$1$ ()), Clazz.innerTypeInstance (java.util.IdentityHashMap$IdentityHashMapEntrySet$1, this, null)), this.associatedMap);
});
c$.$IdentityHashMap$IdentityHashMapEntrySet$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "IdentityHashMap$IdentityHashMapEntrySet$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
c$.NULL_OBJECT = c$.prototype.NULL_OBJECT =  new Clazz._O ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023