Clazz.load (["java.util.AbstractCollection", "$.Queue"], "java.util.AbstractQueue", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "$.NullPointerException", "java.util.NoSuchElementException"], function () {
c$ = Clazz.declareType (java.util, "AbstractQueue", java.util.AbstractCollection, java.util.Queue);
Clazz.overrideMethod (c$, "add", 
function (a) {
if (null == a) {
throw  new NullPointerException ();
}if (this.offer (a)) {
return true;
}throw  new IllegalStateException ();
}, "~O");
Clazz.overrideMethod (c$, "addAll", 
function (a) {
if (null == a) {
throw  new NullPointerException ();
}if (this === a) {
throw  new IllegalArgumentException ();
}return Clazz.superCall (this, java.util.AbstractQueue, "addAll", [a]);
}, "java.util.Collection");
Clazz.defineMethod (c$, "remove", 
function () {
var a = this.poll ();
if (null == a) {
throw  new java.util.NoSuchElementException ();
}return a;
});
Clazz.overrideMethod (c$, "element", 
function () {
var a = this.peek ();
if (null == a) {
throw  new java.util.NoSuchElementException ();
}return a;
});
Clazz.overrideMethod (c$, "clear", 
function () {
var a;
do {
a = this.poll ();
} while (null != a);
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023