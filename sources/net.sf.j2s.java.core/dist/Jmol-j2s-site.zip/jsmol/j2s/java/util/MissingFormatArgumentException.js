Clazz.load (["java.util.IllegalFormatException"], "java.util.MissingFormatArgumentException", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.s = null;
Clazz.instantialize (this, arguments);
}, java.util, "MissingFormatArgumentException", java.util.IllegalFormatException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.MissingFormatArgumentException, []);
if (null == a) {
throw  new NullPointerException ();
}this.s = a;
}, "~S");
Clazz.defineMethod (c$, "getFormatSpecifier", 
function () {
return this.s;
});
Clazz.overrideMethod (c$, "getMessage", 
function () {
return "Format specifier '" + this.s + "'";
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023