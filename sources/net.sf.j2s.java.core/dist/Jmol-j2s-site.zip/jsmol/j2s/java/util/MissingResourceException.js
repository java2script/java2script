Clazz.load (["java.lang.RuntimeException"], "java.util.MissingResourceException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.className = null;
this.key = null;
Clazz.instantialize (this, arguments);
}, java.util, "MissingResourceException", RuntimeException);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.MissingResourceException, [a]);
this.className = b;
this.key = c;
}, "~S,~S,~S");
Clazz.defineMethod (c$, "getClassName", 
function () {
return this.className;
});
Clazz.defineMethod (c$, "getKey", 
function () {
return this.key;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023