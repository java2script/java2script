Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.io.FilterInputStream"], "java.util.zip.CheckedInputStream", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.cksum = null;
Clazz.instantialize (this, arguments);
}, java.util.zip, "CheckedInputStream", java.io.FilterInputStream);
Clazz.defineMethod (c$, "set", 
function (a) {
this.$in = this.$in;
this.cksum = a;
return this;
}, "com.jcraft.jzlib.Checksum");
Clazz.overrideMethod (c$, "readByteAsInt", 
function () {
var a = this.$in.readByteAsInt ();
if (a != -1) {
this.cksum.updateByteAsInt (a);
}return a;
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
c = this.$in.read (a, b, c);
if (c != -1) {
this.cksum.update (a, b, c);
}return c;
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "skip", 
function (a) {
var b =  Clazz.newByteArray (512, 0);
var c = 0;
while (c < a) {
var d = a - c;
d = this.read (b, 0, d < b.length ? d : b.length);
if (d == -1) {
return c;
}c += d;
}
return c;
}, "~N");
Clazz.defineMethod (c$, "getChecksum", 
function () {
return this.cksum;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023