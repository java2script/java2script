Clazz.load (["java.util.Collection"], "java.util.AbstractCollection", ["java.lang.StringBuilder", "$.UnsupportedOperationException", "java.lang.reflect.Array"], function () {
c$ = Clazz.declareType (java.util, "AbstractCollection", null, java.util.Collection);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "add", 
function (a) {
throw  new UnsupportedOperationException ();
}, "~O");
Clazz.overrideMethod (c$, "addAll", 
function (a) {
var b = false;
var c = a.iterator ();
while (c.hasNext ()) {
if (this.add (c.next ())) {
b = true;
}}
return b;
}, "java.util.Collection");
Clazz.overrideMethod (c$, "clear", 
function () {
var a = this.iterator ();
while (a.hasNext ()) {
a.next ();
a.remove ();
}
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
var b = this.iterator ();
if (a != null) {
while (b.hasNext ()) {
if (a.equals (b.next ())) {
return true;
}}
} else {
while (b.hasNext ()) {
if (b.next () == null) {
return true;
}}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "containsAll", 
function (a) {
var b = a.iterator ();
while (b.hasNext ()) {
if (!this.contains (b.next ())) {
return false;
}}
return true;
}, "java.util.Collection");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.size () == 0;
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.iterator ();
if (a != null) {
while (b.hasNext ()) {
if (a.equals (b.next ())) {
b.remove ();
return true;
}}
} else {
while (b.hasNext ()) {
if (b.next () == null) {
b.remove ();
return true;
}}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "removeAll", 
function (a) {
var b = false;
var c = this.iterator ();
while (c.hasNext ()) {
if (a.contains (c.next ())) {
c.remove ();
b = true;
}}
return b;
}, "java.util.Collection");
Clazz.overrideMethod (c$, "retainAll", 
function (a) {
var b = false;
var c = this.iterator ();
while (c.hasNext ()) {
if (!a.contains (c.next ())) {
c.remove ();
b = true;
}}
return b;
}, "java.util.Collection");
Clazz.defineMethod (c$, "toArray", 
function () {
var a = this.size ();
var b = 0;
var c = this.iterator ();
var d =  new Array (a);
while (b < a) {
d[b++] = c.next ();
}
return d;
});
Clazz.defineMethod (c$, "toArray", 
function (a) {
var b = this.size ();
var c = 0;
if (b > a.length) {
var d = a.getClass ().getComponentType ();
a = java.lang.reflect.Array.newInstance (d, b);
}for (var entry, $entry = this.iterator (); $entry.hasNext () && ((entry = $entry.next ()) || true);) {
a[c++] = entry;
}
if (c < a.length) {
a[c] = null;
}return a;
}, "~A");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.isEmpty ()) {
return "[]";
}var a =  new StringBuilder (this.size () * 16);
a.append ('[');
var b = this.iterator ();
while (b.hasNext ()) {
var c = b.next ();
if (c !== this) {
a.append (c);
} else {
a.append ("(this Collection)");
}if (b.hasNext ()) {
a.append (", ");
}}
a.append (']');
return a.toString ();
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023