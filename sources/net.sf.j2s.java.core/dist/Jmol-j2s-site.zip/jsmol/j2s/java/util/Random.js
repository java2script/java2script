Clazz.load (null, "java.util.Random", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.haveNextNextGaussian = false;
this.seed = 0;
this.nextNextGaussian = 0;
Clazz.instantialize (this, arguments);
}, java.util, "Random", null, java.io.Serializable);
Clazz.makeConstructor (c$, 
function () {
this.setSeed (System.currentTimeMillis ());
});
Clazz.makeConstructor (c$, 
function (a) {
this.setSeed (a);
}, "~N");
Clazz.defineMethod (c$, "next", 
function (a) {
this.seed = (this.seed * 25214903917 + 0xb) & (281474976710655);
return (this.seed >>> (48 - a));
}, "~N");
Clazz.defineMethod (c$, "nextBoolean", 
function () {
return Math.random () > 0.5;
});
Clazz.defineMethod (c$, "nextBytes", 
function (a) {
for (var i = 0; i < bytes.length; i++) {
bytes[i] = Math.round (0x100 * Math.random ());
}
}, "~A");
Clazz.defineMethod (c$, "nextDouble", 
function () {
return Math.random ();
});
Clazz.defineMethod (c$, "nextFloat", 
function () {
return Math.random ();
});
Clazz.defineMethod (c$, "nextGaussian", 
function () {
if (this.haveNextNextGaussian) {
this.haveNextNextGaussian = false;
return this.nextNextGaussian;
}var b;
var c;
var d;
do {
b = 2 * this.nextDouble () - 1;
c = 2 * this.nextDouble () - 1;
d = b * b + c * c;
} while (d >= 1);
var e = Math.sqrt (-2 * Math.log (d) / d);
this.nextNextGaussian = c * e;
this.haveNextNextGaussian = true;
return b * e;
});
Clazz.defineMethod (c$, "nextInt", 
function () {
return Math.ceil (0xffff * Math.random ()) - 0x8000;
});
Clazz.defineMethod (c$, "nextInt", 
function (a) {
if (a > 0) {
if ((a & -a) == a) {
return ((a * this.next (31)) >> 31);
}var b;
var c;
do {
b = this.next (31);
c = b % a;
} while (b - c + (a - 1) < 0);
return c;
}throw  new IllegalArgumentException ();
}, "~N");
Clazz.defineMethod (c$, "nextLong", 
function () {
return Math.ceil (0xffffffff * Math.random ()) - 0x80000000;
});
Clazz.defineMethod (c$, "setSeed", 
function (a) {
this.seed = (a ^ 25214903917) & (281474976710655);
this.haveNextNextGaussian = false;
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023