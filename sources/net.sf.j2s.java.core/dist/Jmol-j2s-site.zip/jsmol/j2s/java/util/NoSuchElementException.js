Clazz.load (["java.lang.RuntimeException"], "java.util.NoSuchElementException", null, function () {
c$ = Clazz.declareType (java.util, "NoSuchElementException", RuntimeException);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023