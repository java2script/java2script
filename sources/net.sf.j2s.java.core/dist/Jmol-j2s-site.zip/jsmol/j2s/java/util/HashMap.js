Clazz.load (["java.util.AbstractMap", "$.AbstractSet", "$.Iterator", "$.Map", "$.MapEntry"], "java.util.HashMap", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "java.util.AbstractCollection", "$.Arrays", "$.ConcurrentModificationException", "java.util.Map.Entry", "java.util.MapEntry.Type", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.elementCount = 0;
this.elementData = null;
this.loadFactor = 0;
this.threshold = 0;
this.modCount = 0;
Clazz.instantialize (this, arguments);
}, java.util, "HashMap", java.util.AbstractMap, [java.util.Map, Cloneable, java.io.Serializable]);
Clazz.defineMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.makeConstructor (c$, 
function () {
this.construct (16);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.HashMap, []);
if (a >= 0) {
this.elementCount = 0;
this.elementData = this.newElementArray (a == 0 ? 1 : a);
this.loadFactor = 0.75;
this.computeMaxSize ();
} else {
throw  new IllegalArgumentException ();
}}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.HashMap, []);
if (a >= 0 && b > 0) {
this.elementCount = 0;
this.elementData = this.newElementArray (a == 0 ? 1 : a);
this.loadFactor = b;
this.computeMaxSize ();
} else {
throw  new IllegalArgumentException ();
}}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct ();
this.putAll (a);
}, "java.util.Map");
Clazz.overrideMethod (c$, "clear", 
function () {
if (this.elementCount > 0) {
this.elementCount = 0;
java.util.Arrays.fill (this.elementData, null);
this.modCount++;
}});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.HashMap, "clone", []);
a.elementData = this.newElementArray (this.elementData.length);
var b;
for (var c = 0; c < this.elementData.length; c++) {
if ((b = this.elementData[c]) != null) {
a.elementData[c] = b.clone ();
}}
return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "computeMaxSize", 
function () {
this.threshold = Clazz.floatToInt (this.elementData.length * this.loadFactor);
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
return this.getEntry (a) != null;
}, "~O");
Clazz.defineMethod (c$, "keysEqual", 
function (a, b) {
var c = a == null ? 0 : a.hashCode ();
if (c != b.origKeyHash) {
return false;
}if (a == null && b.key == null) {
return true;
}return a.equals (b.key);
}, "~O,java.util.HashMap.Entry");
Clazz.overrideMethod (c$, "containsValue", 
function (a) {
if (a != null) {
for (var b = this.elementData.length; --b >= 0; ) {
var c = this.elementData[b];
while (c != null) {
if (a.equals (c.value)) {
return true;
}c = c.next;
}
}
} else {
for (var b = this.elementData.length; --b >= 0; ) {
var c = this.elementData[b];
while (c != null) {
if (c.value == null) {
return true;
}c = c.next;
}
}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "entrySet", 
function () {
return  new java.util.HashMap.HashMapEntrySet (this);
});
Clazz.overrideMethod (c$, "get", 
function (a) {
var b = this.getEntry (a);
if (b != null) {
return b.value;
}return null;
}, "~O");
Clazz.defineMethod (c$, "getEntry", 
function (a) {
var b = this.getModuloHash (a);
return this.findEntry (a, b);
}, "~O");
Clazz.defineMethod (c$, "getModuloHash", 
function (a) {
if (a == null) {
return 0;
}return (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
}, "~O");
Clazz.defineMethod (c$, "findEntry", 
function (a, b) {
var c;
c = this.elementData[b];
if (a != null) {
while (c != null && !this.keysEqual (a, c)) {
c = c.next;
}
} else {
while (c != null && c.key != null) {
c = c.next;
}
}return c;
}, "~O,~N");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.elementCount == 0;
});
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.HashMap$1") ? 0 : java.util.HashMap.$HashMap$1$ ()), Clazz.innerTypeInstance (java.util.HashMap$1, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "put", 
function (a, b) {
var c = this.getModuloHash (a);
var d = this.findEntry (a, c);
if (d == null) {
this.modCount++;
if (++this.elementCount > this.threshold) {
this.rehash ();
c = a == null ? 0 : (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
}d = this.createEntry (a, c, b);
return null;
}var e = d.value;
d.value = b;
return e;
}, "~O,~O");
Clazz.defineMethod (c$, "createEntry", 
function (a, b, c) {
var d =  new java.util.HashMap.Entry (a, c);
d.next = this.elementData[b];
this.elementData[b] = d;
return d;
}, "~O,~N,~O");
Clazz.overrideMethod (c$, "putAll", 
function (a) {
if (!a.isEmpty ()) {
var b = this.elementCount + a.size ();
if (b > this.threshold) {
this.rehash (b);
}Clazz.superCall (this, java.util.HashMap, "putAll", [a]);
}}, "java.util.Map");
Clazz.defineMethod (c$, "rehash", 
function (a) {
var b = (a == 0 ? 1 : a << 1);
var c = this.newElementArray (b);
for (var d = 0; d < this.elementData.length; d++) {
var e = this.elementData[d];
while (e != null) {
var f = e.key;
var g = f == null ? 0 : (f.hashCode () & 0x7FFFFFFF) % b;
var h = e.next;
e.next = c[g];
c[g] = e;
e = h;
}
}
this.elementData = c;
this.computeMaxSize ();
}, "~N");
Clazz.defineMethod (c$, "rehash", 
function () {
this.rehash (this.elementData.length);
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.removeEntry (a);
if (b != null) {
return b.value;
}return null;
}, "~O");
Clazz.defineMethod (c$, "removeEntry", 
function (a) {
var b = 0;
var c;
var d = null;
if (a != null) {
b = (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
c = this.elementData[b];
while (c != null && !this.keysEqual (a, c)) {
d = c;
c = c.next;
}
} else {
c = this.elementData[0];
while (c != null && c.key != null) {
d = c;
c = c.next;
}
}if (c == null) {
return null;
}if (d == null) {
this.elementData[b] = c.next;
} else {
d.next = c.next;
}this.modCount++;
this.elementCount--;
return c;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.elementCount;
});
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.HashMap$2") ? 0 : java.util.HashMap.$HashMap$2$ ()), Clazz.innerTypeInstance (java.util.HashMap$2, this, null));
}return this.valuesCollection;
});
c$.$HashMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "HashMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.HashMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.HashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.HashMap"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.b$["java.util.HashMap"].containsKey (a)) {
this.b$["java.util.HashMap"].remove (a);
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.HashMap.HashMapIterator (((Clazz.isClassDefined ("java.util.HashMap$1$1") ? 0 : java.util.HashMap.$HashMap$1$1$ ()), Clazz.innerTypeInstance (java.util.HashMap$1$1, this, null)), this.b$["java.util.HashMap"]);
});
c$ = Clazz.p0p ();
};
c$.$HashMap$1$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "HashMap$1$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.key;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$HashMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "HashMap$2", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.HashMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.HashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.HashMap"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.HashMap.HashMapIterator (((Clazz.isClassDefined ("java.util.HashMap$2$1") ? 0 : java.util.HashMap.$HashMap$2$1$ ()), Clazz.innerTypeInstance (java.util.HashMap$2$1, this, null)), this.b$["java.util.HashMap"]);
});
c$ = Clazz.p0p ();
};
c$.$HashMap$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "HashMap$2$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.value;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.origKeyHash = 0;
this.next = null;
Clazz.instantialize (this, arguments);
}, java.util.HashMap, "Entry", java.util.MapEntry);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.HashMap.Entry, [a, b]);
this.origKeyHash = (a == null ? 0 : a.hashCode ());
}, "~O,~O");
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, java.util.HashMap.Entry, "clone", []);
if (this.next != null) {
a.next = this.next.clone ();
}return a;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.position = 0;
this.expectedModCount = 0;
this.type = null;
this.canRemove = false;
this.entry = null;
this.lastEntry = null;
this.associatedMap = null;
Clazz.instantialize (this, arguments);
}, java.util.HashMap, "HashMapIterator", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a, b) {
this.associatedMap = b;
this.type = a;
this.expectedModCount = b.modCount;
}, "java.util.MapEntry.Type,java.util.HashMap");
Clazz.overrideMethod (c$, "hasNext", 
function () {
if (this.entry != null) {
return true;
}while (this.position < this.associatedMap.elementData.length) {
if (this.associatedMap.elementData[this.position] == null) {
this.position++;
} else {
return true;
}}
return false;
});
Clazz.defineMethod (c$, "checkConcurrentMod", 
function () {
if (this.expectedModCount != this.associatedMap.modCount) {
throw  new java.util.ConcurrentModificationException ();
}});
Clazz.overrideMethod (c$, "next", 
function () {
this.checkConcurrentMod ();
if (!this.hasNext ()) {
throw  new java.util.NoSuchElementException ();
}var a;
if (this.entry == null) {
a = this.lastEntry = this.associatedMap.elementData[this.position++];
this.entry = this.lastEntry.next;
} else {
if (this.lastEntry.next !== this.entry) {
this.lastEntry = this.lastEntry.next;
}a = this.entry;
this.entry = this.entry.next;
}this.canRemove = true;
return this.type.get (a);
});
Clazz.overrideMethod (c$, "remove", 
function () {
this.checkConcurrentMod ();
if (!this.canRemove) {
throw  new IllegalStateException ();
}this.canRemove = false;
this.associatedMap.modCount++;
if (this.lastEntry.next === this.entry) {
while (this.associatedMap.elementData[--this.position] == null) {
;}
this.associatedMap.elementData[this.position] = this.associatedMap.elementData[this.position].next;
this.entry = null;
} else {
this.lastEntry.next = this.entry;
}this.associatedMap.elementCount--;
this.expectedModCount++;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.associatedMap = null;
Clazz.instantialize (this, arguments);
}, java.util.HashMap, "HashMapEntrySet", java.util.AbstractSet);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.HashMap.HashMapEntrySet, []);
this.associatedMap = a;
}, "java.util.HashMap");
Clazz.defineMethod (c$, "hashMap", 
function () {
return this.associatedMap;
});
Clazz.overrideMethod (c$, "size", 
function () {
return this.associatedMap.elementCount;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.associatedMap.clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.contains (a)) {
this.associatedMap.remove ((a).getKey ());
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = this.associatedMap.getEntry ((a).getKey ());
return a.equals (b);
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.HashMap.HashMapIterator (((Clazz.isClassDefined ("java.util.HashMap$HashMapEntrySet$1") ? 0 : java.util.HashMap.HashMapEntrySet.$HashMap$HashMapEntrySet$1$ ()), Clazz.innerTypeInstance (java.util.HashMap$HashMapEntrySet$1, this, null)), this.associatedMap);
});
c$.$HashMap$HashMapEntrySet$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "HashMap$HashMapEntrySet$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023