Clazz.load (["java.util.Map"], "java.util.AbstractMap", ["java.lang.StringBuilder", "$.UnsupportedOperationException", "java.util.AbstractCollection", "$.AbstractSet", "$.Iterator"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$keySet = null;
this.valuesCollection = null;
Clazz.instantialize (this, arguments);
}, java.util, "AbstractMap", null, java.util.Map);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.entrySet ().clear ();
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
var b = this.entrySet ().iterator ();
if (a != null) {
while (b.hasNext ()) {
if (a.equals (b.next ().getKey ())) {
return true;
}}
} else {
while (b.hasNext ()) {
if (b.next ().getKey () == null) {
return true;
}}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "containsValue", 
function (a) {
var b = this.entrySet ().iterator ();
if (a != null) {
while (b.hasNext ()) {
if (a.equals (b.next ().getValue ())) {
return true;
}}
} else {
while (b.hasNext ()) {
if (b.next ().getValue () == null) {
return true;
}}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Map)) {
var b = a;
if (this.size () != b.size ()) {
return false;
}var c = b.entrySet ();
var d = this.entrySet ().iterator ();
while (d.hasNext ()) {
if (!c.contains (d.next ())) {
return false;
}}
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "get", 
function (a) {
var b = this.entrySet ().iterator ();
if (a != null) {
while (b.hasNext ()) {
var c = b.next ();
if (a.equals (c.getKey ())) {
return c.getValue ();
}}
} else {
while (b.hasNext ()) {
var c = b.next ();
if (c.getKey () == null) {
return c.getValue ();
}}
}return null;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a = 0;
var b = this.entrySet ().iterator ();
while (b.hasNext ()) {
a += b.next ().hashCode ();
}
return a;
});
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.size () == 0;
});
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.AbstractMap$1") ? 0 : java.util.AbstractMap.$AbstractMap$1$ ()), Clazz.innerTypeInstance (java.util.AbstractMap$1, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "put", 
function (a, b) {
throw  new UnsupportedOperationException ();
}, "~O,~O");
Clazz.overrideMethod (c$, "putAll", 
function (a) {
for (var entry, $entry = a.entrySet ().iterator (); $entry.hasNext () && ((entry = $entry.next ()) || true);) {
this.put (entry.getKey (), entry.getValue ());
}
}, "java.util.Map");
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.entrySet ().iterator ();
if (a != null) {
while (b.hasNext ()) {
var c = b.next ();
if (a.equals (c.getKey ())) {
b.remove ();
return c.getValue ();
}}
} else {
while (b.hasNext ()) {
var c = b.next ();
if (c.getKey () == null) {
b.remove ();
return c.getValue ();
}}
}return null;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.entrySet ().size ();
});
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.isEmpty ()) {
return "{}";
}var a =  new StringBuilder (this.size () * 28);
a.append ('{');
var b = this.entrySet ().iterator ();
while (b.hasNext ()) {
var c = b.next ();
var d = c.getKey ();
if (d !== this) {
a.append (d);
} else {
a.append ("(this Map)");
}a.append ('=');
var e = c.getValue ();
if (e !== this) {
a.append (e);
} else {
a.append ("(this Map)");
}if (b.hasNext ()) {
a.append (", ");
}}
a.append ('}');
return a.toString ();
});
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.AbstractMap$2") ? 0 : java.util.AbstractMap.$AbstractMap$2$ ()), Clazz.innerTypeInstance (java.util.AbstractMap$2, this, null));
}return this.valuesCollection;
});
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, java.util.AbstractMap, "clone", []);
a.$keySet = null;
a.valuesCollection = null;
return a;
});
c$.$AbstractMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "AbstractMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.AbstractMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.AbstractMap"].size ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return ((Clazz.isClassDefined ("java.util.AbstractMap$1$1") ? 0 : java.util.AbstractMap.$AbstractMap$1$1$ ()), Clazz.innerTypeInstance (java.util.AbstractMap$1$1, this, null));
});
c$ = Clazz.p0p ();
};
c$.$AbstractMap$1$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.setIterator = null;
Clazz.instantialize (this, arguments);
}, java.util, "AbstractMap$1$1", null, java.util.Iterator);
Clazz.prepareFields (c$, function () {
this.setIterator = this.b$["java.util.AbstractMap"].entrySet ().iterator ();
});
Clazz.overrideMethod (c$, "hasNext", 
function () {
return this.setIterator.hasNext ();
});
Clazz.overrideMethod (c$, "next", 
function () {
return this.setIterator.next ().getKey ();
});
Clazz.overrideMethod (c$, "remove", 
function () {
this.setIterator.remove ();
});
c$ = Clazz.p0p ();
};
c$.$AbstractMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "AbstractMap$2", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.AbstractMap"].size ();
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.AbstractMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return ((Clazz.isClassDefined ("java.util.AbstractMap$2$1") ? 0 : java.util.AbstractMap.$AbstractMap$2$1$ ()), Clazz.innerTypeInstance (java.util.AbstractMap$2$1, this, null));
});
c$ = Clazz.p0p ();
};
c$.$AbstractMap$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.setIterator = null;
Clazz.instantialize (this, arguments);
}, java.util, "AbstractMap$2$1", null, java.util.Iterator);
Clazz.prepareFields (c$, function () {
this.setIterator = this.b$["java.util.AbstractMap"].entrySet ().iterator ();
});
Clazz.overrideMethod (c$, "hasNext", 
function () {
return this.setIterator.hasNext ();
});
Clazz.overrideMethod (c$, "next", 
function () {
return this.setIterator.next ().getValue ();
});
Clazz.overrideMethod (c$, "remove", 
function () {
this.setIterator.remove ();
});
c$ = Clazz.p0p ();
};
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023