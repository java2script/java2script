Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.util.zip.DeflaterOutputStream", "$.ZipConstants", "java.util.ArrayList", "$.Hashtable", "java.util.zip.CRC32"], "java.util.zip.ZipOutputStream", ["com.jcraft.jzlib.ZStream", "java.io.IOException", "java.lang.Boolean", "$.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.Long", "java.util.zip.Deflater", "$.ZipException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.current = null;
this.xentries = null;
this.names = null;
this.crc = null;
this.written = 0;
this.locoff = 0;
this.comment = null;
this.method = 8;
this.finished = false;
this.$closed = false;
Clazz.instantialize (this, arguments);
}, java.util.zip, "ZipOutputStream", java.util.zip.DeflaterOutputStream, java.util.zip.ZipConstants);
Clazz.prepareFields (c$, function () {
this.xentries =  new java.util.ArrayList ();
this.names =  new java.util.Hashtable ();
this.crc =  new java.util.zip.CRC32 ();
});
c$.version = Clazz.defineMethod (c$, "version", 
function (a) {
switch (a.method) {
case 8:
return 20;
case 0:
return 10;
default:
throw  new java.util.zip.ZipException ("unsupported compression method");
}
}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.$closed) {
throw  new java.io.IOException ("Stream closed");
}});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.zip.ZipOutputStream, []);
});
Clazz.defineMethod (c$, "setZOS", 
function (a) {
this.setDOS (a, java.util.zip.ZipOutputStream.newDeflater ());
return this;
}, "java.io.OutputStream");
c$.newDeflater = Clazz.defineMethod (c$, "newDeflater", 
function () {
return ( new java.util.zip.Deflater (2147483647)).init (-1, 0, true);
});
Clazz.defineMethod (c$, "setComment", 
function (a) {
if (a != null) {
this.comment = com.jcraft.jzlib.ZStream.getBytes (a);
if (this.comment.length > 0xffff) throw  new IllegalArgumentException ("ZIP file comment too long.");
}}, "~S");
Clazz.defineMethod (c$, "putNextEntry", 
function (a) {
this.ensureOpen ();
if (this.current != null) {
this.closeEntry ();
}if (a.time == -1) {
a.setTime (System.currentTimeMillis ());
}if (a.method == -1) {
a.method = this.method;
}a.flag = 0;
switch (a.method) {
case 8:
if (a.size == -1 || a.csize == -1 || a.crc == -1) a.flag = 8;
break;
case 0:
if (a.size == -1) {
a.size = a.csize;
} else if (a.csize == -1) {
a.csize = a.size;
} else if (a.size != a.csize) {
throw  new java.util.zip.ZipException ("STORED entry where compressed != uncompressed size");
}if (a.size == -1 || a.crc == -1) {
throw  new java.util.zip.ZipException ("STORED entry missing size, compressed size, or crc-32");
}break;
default:
throw  new java.util.zip.ZipException ("unsupported compression method");
}
if (this.names.containsKey (a.name)) {
throw  new java.util.zip.ZipException ("duplicate entry: " + a.name);
}this.names.put (a.name, Boolean.TRUE);
a.flag |= 2048;
this.current = a;
this.current.offset = this.written;
this.xentries.add (this.current);
this.writeLOC (this.current);
}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "closeEntry", 
function () {
this.ensureOpen ();
if (this.current != null) {
var a = this.current;
switch (a.method) {
case 8:
this.deflater.finish ();
Clazz.superCall (this, java.util.zip.ZipOutputStream, "finish", []);
if ((a.flag & 8) == 0) {
if (a.size != this.deflater.getBytesRead ()) {
throw  new java.util.zip.ZipException ("invalid entry size (expected " + a.size + " but got " + this.deflater.getBytesRead () + " bytes)");
}if (a.csize != this.deflater.getBytesWritten ()) {
throw  new java.util.zip.ZipException ("invalid entry compressed size (expected " + a.csize + " but got " + this.deflater.getBytesWritten () + " bytes)");
}if (a.crc != this.crc.getValue ()) {
throw  new java.util.zip.ZipException ("invalid entry CRC-32 (expected 0x" + Long.toHexString (a.crc) + " but got 0x" + Long.toHexString (this.crc.getValue ()) + ")");
}} else {
a.size = this.deflater.getBytesRead ();
a.csize = this.deflater.getBytesWritten ();
a.crc = this.crc.getValue ();
this.writeEXT (a);
}this.deflater = java.util.zip.ZipOutputStream.newDeflater ();
this.written += a.csize;
break;
case 0:
if (a.size != this.written - this.locoff) {
throw  new java.util.zip.ZipException ("invalid entry size (expected " + a.size + " but got " + (this.written - this.locoff) + " bytes)");
}if (a.crc != this.crc.getValue ()) {
throw  new java.util.zip.ZipException ("invalid entry crc-32 (expected 0x" + Long.toHexString (a.crc) + " but got 0x" + Long.toHexString (this.crc.getValue ()) + ")");
}break;
default:
throw  new java.util.zip.ZipException ("invalid compression method");
}
this.crc.reset ();
this.current = null;
}});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
this.ensureOpen ();
if (b < 0 || c < 0 || b > a.length - c) {
throw  new IndexOutOfBoundsException ();
} else if (c == 0) {
return;
}if (this.current == null) {
throw  new java.util.zip.ZipException ("no current ZIP entry");
}var d = this.current;
switch (d.method) {
case 8:
Clazz.superCall (this, java.util.zip.ZipOutputStream, "write", [a, b, c]);
break;
case 0:
this.written += c;
if (this.written - this.locoff > d.size) {
throw  new java.util.zip.ZipException ("attempt to write past end of STORED entry");
}this.out.write (this.buffer, 0, c);
break;
default:
throw  new java.util.zip.ZipException ("invalid compression method");
}
this.crc.update (a, b, c);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "finish", 
function () {
this.ensureOpen ();
if (this.finished) {
return;
}if (this.current != null) {
this.closeEntry ();
}var a = this.written;
for (var xentry, $xentry = this.xentries.iterator (); $xentry.hasNext () && ((xentry = $xentry.next ()) || true);) this.writeCEN (xentry);

this.writeEND (a, this.written - a);
this.finished = true;
});
Clazz.defineMethod (c$, "close", 
function () {
if (!this.$closed) {
Clazz.superCall (this, java.util.zip.ZipOutputStream, "close", []);
this.$closed = true;
}});
Clazz.defineMethod (c$, "writeLOC", 
function (a) {
var b = a;
var c = b.flag;
var d = (b.extra != null) ? b.extra.length : 0;
var e = false;
this.writeInt (67324752);
if ((c & 8) == 8) {
this.writeShort (java.util.zip.ZipOutputStream.version (b));
this.writeShort (c);
this.writeShort (b.method);
this.writeInt (b.time);
this.writeInt (0);
this.writeInt (0);
this.writeInt (0);
} else {
if (b.csize >= 4294967295 || b.size >= 4294967295) {
e = true;
this.writeShort (45);
} else {
this.writeShort (java.util.zip.ZipOutputStream.version (b));
}this.writeShort (c);
this.writeShort (b.method);
this.writeInt (b.time);
this.writeInt (b.crc);
if (e) {
this.writeInt (4294967295);
this.writeInt (4294967295);
d += 20;
} else {
this.writeInt (b.csize);
this.writeInt (b.size);
}}var f = com.jcraft.jzlib.ZStream.getBytes (b.name);
this.writeShort (f.length);
this.writeShort (d);
this.writeBytes (f, 0, f.length);
if (e) {
this.writeShort (1);
this.writeShort (16);
this.writeLong (b.size);
this.writeLong (b.csize);
}if (b.extra != null) {
this.writeBytes (b.extra, 0, b.extra.length);
}this.locoff = this.written;
}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "writeEXT", 
function (a) {
this.writeInt (134695760);
this.writeInt (a.crc);
if (a.csize >= 4294967295 || a.size >= 4294967295) {
this.writeLong (a.csize);
this.writeLong (a.size);
} else {
this.writeInt (a.csize);
this.writeInt (a.size);
}}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "writeCEN", 
function (a) {
var b = a;
var c = b.flag;
var d = java.util.zip.ZipOutputStream.version (b);
var e = b.csize;
var f = b.size;
var g = a.offset;
var h = 0;
var i = false;
if (b.csize >= 4294967295) {
e = 4294967295;
h += 8;
i = true;
}if (b.size >= 4294967295) {
f = 4294967295;
h += 8;
i = true;
}if (a.offset >= 4294967295) {
g = 4294967295;
h += 8;
i = true;
}this.writeInt (33639248);
if (i) {
this.writeShort (45);
this.writeShort (45);
} else {
this.writeShort (d);
this.writeShort (d);
}this.writeShort (c);
this.writeShort (b.method);
this.writeInt (b.time);
this.writeInt (b.crc);
this.writeInt (e);
this.writeInt (f);
var j = com.jcraft.jzlib.ZStream.getBytes (b.name);
this.writeShort (j.length);
if (i) {
this.writeShort (h + 4 + (b.extra != null ? b.extra.length : 0));
} else {
this.writeShort (b.extra != null ? b.extra.length : 0);
}var k;
if (b.comment != null) {
k = com.jcraft.jzlib.ZStream.getBytes (b.comment);
this.writeShort (Math.min (k.length, 0xffff));
} else {
k = null;
this.writeShort (0);
}this.writeShort (0);
this.writeShort (0);
this.writeInt (0);
this.writeInt (g);
this.writeBytes (j, 0, j.length);
if (i) {
this.writeShort (1);
this.writeShort (h);
if (f == 4294967295) this.writeLong (b.size);
if (e == 4294967295) this.writeLong (b.csize);
if (g == 4294967295) this.writeLong (a.offset);
}if (b.extra != null) {
this.writeBytes (b.extra, 0, b.extra.length);
}if (k != null) {
this.writeBytes (k, 0, Math.min (k.length, 0xffff));
}}, "java.util.zip.ZipEntry");
Clazz.defineMethod (c$, "writeEND", 
function (a, b) {
var c = false;
var d = b;
var e = a;
if (d >= 4294967295) {
d = 4294967295;
c = true;
}if (e >= 4294967295) {
e = 4294967295;
c = true;
}var f = this.xentries.size ();
if (f >= 65535) {
f = 65535;
c = true;
}if (c) {
var g = this.written;
this.writeInt (101075792);
this.writeLong (44);
this.writeShort (45);
this.writeShort (45);
this.writeInt (0);
this.writeInt (0);
this.writeLong (this.xentries.size ());
this.writeLong (this.xentries.size ());
this.writeLong (b);
this.writeLong (a);
this.writeInt (117853008);
this.writeInt (0);
this.writeLong (g);
this.writeInt (1);
}this.writeInt (101010256);
this.writeShort (0);
this.writeShort (0);
this.writeShort (f);
this.writeShort (f);
this.writeInt (d);
this.writeInt (e);
if (this.comment != null) {
this.writeShort (this.comment.length);
this.writeBytes (this.comment, 0, this.comment.length);
} else {
this.writeShort (0);
}}, "~N,~N");
Clazz.defineMethod (c$, "writeShort", 
function (a) {
var b = this.out;
{
out.writeByteAsInt((v >>> 0) & 0xff);
out.writeByteAsInt((v >>> 8) & 0xff);
}this.written += 2;
}, "~N");
Clazz.defineMethod (c$, "writeInt", 
function (a) {
var b = this.out;
{
out.writeByteAsInt((v >>> 0) & 0xff);
out.writeByteAsInt((v >>> 8) & 0xff);
out.writeByteAsInt((v >>> 16) & 0xff);
out.writeByteAsInt((v >>> 24) & 0xff);
}this.written += 4;
}, "~N");
Clazz.defineMethod (c$, "writeLong", 
function (a) {
var b = this.out;
{
out.writeByteAsInt((v >>> 0) & 0xff);
out.writeByteAsInt((v >>> 8) & 0xff);
out.writeByteAsInt((v >>> 16) & 0xff);
out.writeByteAsInt((v >>> 24) & 0xff);
out.writeByteAsInt(0);
out.writeByteAsInt(0);
out.writeByteAsInt(0);
out.writeByteAsInt(0);
}this.written += 8;
}, "~N");
Clazz.defineMethod (c$, "writeBytes", 
function (a, b, c) {
this.out.write (a, b, c);
this.written += c;
}, "~A,~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023