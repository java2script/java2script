Clazz.load (["java.util.Hashtable"], "java.util.Properties", ["java.lang.NullPointerException", "$.StringBuffer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.builder = null;
this.defaults = null;
Clazz.instantialize (this, arguments);
}, java.util, "Properties", java.util.Hashtable);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.Properties, []);
this.defaults = a;
}, "java.util.Properties");
Clazz.defineMethod (c$, "dumpString", 
function (a, b, c) {
var d = 0;
if (!c && d < b.length && b.charAt (d) == ' ') {
a.append ("\\ ");
d++;
}for (; d < b.length; d++) {
var e = b.charAt (d);
switch (e) {
case '\t':
a.append ("\\t");
break;
case '\n':
a.append ("\\n");
break;
case '\f':
a.append ("\\f");
break;
case '\r':
a.append ("\\r");
break;
default:
if ("\\#!=:".indexOf (e) >= 0 || (c && e == ' ')) {
a.append ('\\');
}if (e >= ' ' && e <= '~') {
a.append (e);
} else {
var f = Integer.toHexString (e.charCodeAt (0));
a.append ("\\u");
for (var g = 0; g < 4 - f.length; g++) {
a.append ("0");
}
a.append (f);
}}
}
}, "StringBuilder,~S,~B");
Clazz.defineMethod (c$, "getProperty", 
function (a) {
var b = this.get (a);
var c = Clazz.instanceOf (b, String) ? b : null;
if (c == null && this.defaults != null) {
c = this.defaults.getProperty (a);
}return c;
}, "~S");
Clazz.defineMethod (c$, "getProperty", 
function (a, b) {
var c = this.get (a);
var d = Clazz.instanceOf (c, String) ? c : null;
if (d == null && this.defaults != null) {
d = this.defaults.getProperty (a);
}if (d == null) {
return b;
}return d;
}, "~S,~S");
Clazz.defineMethod (c$, "list", 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}var b =  new StringBuffer (80);
var c = this.propertyNames ();
while (c.hasMoreElements ()) {
var d = c.nextElement ();
b.append (d);
b.append ('=');
var e = this.get (d);
var f = this.defaults;
while (e == null) {
e = f.get (d);
f = f.defaults;
}
if (e.length > 40) {
b.append (e.substring (0, 37));
b.append ("...");
} else {
b.append (e);
}a.println (b.toString ());
b.setLength (0);
}
}, "java.io.PrintStream");
Clazz.defineMethod (c$, "list", 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}var b =  new StringBuffer (80);
var c = this.propertyNames ();
while (c.hasMoreElements ()) {
var d = c.nextElement ();
b.append (d);
b.append ('=');
var e = this.get (d);
var f = this.defaults;
while (e == null) {
e = f.get (d);
f = f.defaults;
}
if (e.length > 40) {
b.append (e.substring (0, 37));
b.append ("...");
} else {
b.append (e);
}a.println (b.toString ());
b.setLength (0);
}
}, "java.io.PrintWriter");
Clazz.defineMethod (c$, "load", 
function (a) {

}, "java.io.InputStream");
Clazz.defineMethod (c$, "propertyNames", 
function () {
if (this.defaults == null) {
return this.keys ();
}var b =  new java.util.Hashtable (this.defaults.size () + this.size ());
var c = this.defaults.propertyNames ();
while (c.hasMoreElements ()) {
b.put (c.nextElement (), b);
}
c = this.keys ();
while (c.hasMoreElements ()) {
b.put (c.nextElement (), b);
}
return b.keys ();
});
Clazz.defineMethod (c$, "save", 
function (a, b) {
try {
this.store (a, b);
} catch (e) {
if (Clazz.exceptionOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}, "java.io.OutputStream,~S");
Clazz.defineMethod (c$, "setProperty", 
function (a, b) {
return this.put (a, b);
}, "~S,~S");
Clazz.defineMethod (c$, "store", 
function (a, b) {

}, "java.io.OutputStream,~S");
Clazz.defineMethod (c$, "loadFromXML", 
function (c) {

}, "java.io.InputStream");
Clazz.defineMethod (c$, "storeToXML", 
function (d, e) {

}, "java.io.OutputStream,~S");
Clazz.defineMethod (c$, "storeToXML", 
function (f, g, h) {

}, "java.io.OutputStream,~S,~S");
Clazz.defineMethod (c$, "substitutePredefinedEntries", 
function (i) {
return i.replaceAll ("&", "&amp;").replaceAll ("<", "&lt;").replaceAll (">", "&gt;").replaceAll ("\u0027", "&apos;").replaceAll ("\"", "&quot;");
}, "~S");
Clazz.defineStatics (c$,
"lineSeparator", null);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023