Clazz.load (["java.util.HashMap"], "java.util.LinkedHashMap", ["java.lang.IllegalStateException", "java.util.AbstractCollection", "$.AbstractSet", "java.util.MapEntry.Type", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.accessOrder = false;
this.head = null;
this.tail = null;
Clazz.instantialize (this, arguments);
}, java.util, "LinkedHashMap", java.util.HashMap);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.LinkedHashMap);
this.accessOrder = false;
this.head = null;
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.LinkedHashMap, [a]);
this.accessOrder = false;
this.head = null;
}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.LinkedHashMap, [a, b]);
this.accessOrder = false;
this.head = null;
this.tail = null;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.LinkedHashMap, [a, b]);
this.accessOrder = c;
this.head = null;
this.tail = null;
}, "~N,~N,~B");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.LinkedHashMap, []);
this.accessOrder = false;
this.head = null;
this.tail = null;
this.putAll (a);
}, "java.util.Map");
Clazz.overrideMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.overrideMethod (c$, "get", 
function (a) {
var b = this.getEntry (a);
if (b == null) {
return null;
}if (this.accessOrder && this.tail !== b) {
var c = b.chainBackward;
var d = b.chainForward;
d.chainBackward = c;
if (c != null) {
c.chainForward = d;
} else {
this.head = d;
}b.chainForward = null;
b.chainBackward = this.tail;
this.tail.chainForward = b;
this.tail = b;
}return b.value;
}, "~O");
Clazz.overrideMethod (c$, "createEntry", 
function (a, b, c) {
var d =  new java.util.LinkedHashMap.LinkedHashMapEntry (a, c);
d.next = this.elementData[b];
this.elementData[b] = d;
this.linkEntry (d);
return d;
}, "~O,~N,~O");
Clazz.overrideMethod (c$, "put", 
function (a, b) {
var c = this.getModuloHash (a);
var d = this.findEntry (a, c);
if (d == null) {
this.modCount++;
if (++this.elementCount > this.threshold) {
this.rehash ();
c = a == null ? 0 : (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
}d = this.createEntry (a, c, null);
} else {
this.linkEntry (d);
}var e = d.value;
d.value = b;
if (this.removeEldestEntry (this.head)) {
this.remove (this.head.key);
}return e;
}, "~O,~O");
Clazz.defineMethod (c$, "linkEntry", 
function (a) {
if (this.tail === a) {
return;
}if (this.head == null) {
this.head = this.tail = a;
return;
}var b = a.chainBackward;
var c = a.chainForward;
if (b == null) {
if (c != null) {
if (this.accessOrder) {
this.head = c;
c.chainBackward = null;
a.chainBackward = this.tail;
a.chainForward = null;
this.tail.chainForward = a;
this.tail = a;
}} else {
a.chainBackward = this.tail;
a.chainForward = null;
this.tail.chainForward = a;
this.tail = a;
}return;
}if (c == null) {
return;
}if (this.accessOrder) {
b.chainForward = c;
c.chainBackward = b;
a.chainForward = null;
a.chainBackward = this.tail;
this.tail.chainForward = a;
this.tail = a;
}}, "java.util.LinkedHashMap.LinkedHashMapEntry");
Clazz.overrideMethod (c$, "entrySet", 
function () {
return  new java.util.LinkedHashMap.LinkedHashMapEntrySet (this);
});
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.LinkedHashMap$1") ? 0 : java.util.LinkedHashMap.$LinkedHashMap$1$ ()), Clazz.innerTypeInstance (java.util.LinkedHashMap$1, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.LinkedHashMap$2") ? 0 : java.util.LinkedHashMap.$LinkedHashMap$2$ ()), Clazz.innerTypeInstance (java.util.LinkedHashMap$2, this, null));
}return this.valuesCollection;
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.removeEntry (a);
if (b == null) {
return null;
}var c = b.chainBackward;
var d = b.chainForward;
if (c != null) {
c.chainForward = d;
} else {
this.head = d;
}if (d != null) {
d.chainBackward = c;
} else {
this.tail = c;
}return b.value;
}, "~O");
Clazz.defineMethod (c$, "removeEldestEntry", 
function (a) {
return false;
}, "java.util.Map.Entry");
Clazz.defineMethod (c$, "clear", 
function () {
Clazz.superCall (this, java.util.LinkedHashMap, "clear", []);
this.head = this.tail = null;
});
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, java.util.LinkedHashMap, "clone", []);
a.clear ();
for (var entry, $entry = this.entrySet ().iterator (); $entry.hasNext () && ((entry = $entry.next ()) || true);) {
a.put (entry.getKey (), entry.getValue ());
}
return a;
});
c$.$LinkedHashMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "LinkedHashMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.LinkedHashMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.LinkedHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.LinkedHashMap"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.b$["java.util.LinkedHashMap"].containsKey (a)) {
this.b$["java.util.LinkedHashMap"].remove (a);
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.LinkedHashMap.LinkedHashIterator (((Clazz.isClassDefined ("java.util.LinkedHashMap$1$1") ? 0 : java.util.LinkedHashMap.$LinkedHashMap$1$1$ ()), Clazz.innerTypeInstance (java.util.LinkedHashMap$1$1, this, null)), this.b$["java.util.LinkedHashMap"]);
});
c$ = Clazz.p0p ();
};
c$.$LinkedHashMap$1$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "LinkedHashMap$1$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.key;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$LinkedHashMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "LinkedHashMap$2", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.LinkedHashMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.LinkedHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.LinkedHashMap"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.LinkedHashMap.LinkedHashIterator (((Clazz.isClassDefined ("java.util.LinkedHashMap$2$1") ? 0 : java.util.LinkedHashMap.$LinkedHashMap$2$1$ ()), Clazz.innerTypeInstance (java.util.LinkedHashMap$2$1, this, null)), this.b$["java.util.LinkedHashMap"]);
});
c$ = Clazz.p0p ();
};
c$.$LinkedHashMap$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "LinkedHashMap$2$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.value;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.LinkedHashMap, "LinkedHashIterator", java.util.HashMap.HashMapIterator);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.LinkedHashMap.LinkedHashIterator, [a, b]);
this.entry = b.head;
}, "java.util.MapEntry.Type,java.util.LinkedHashMap");
Clazz.overrideMethod (c$, "hasNext", 
function () {
return (this.entry != null);
});
Clazz.overrideMethod (c$, "next", 
function () {
this.checkConcurrentMod ();
if (!this.hasNext ()) {
throw  new java.util.NoSuchElementException ();
}var a = this.type.get (this.entry);
this.lastEntry = this.entry;
this.entry = (this.entry).chainForward;
this.canRemove = true;
return a;
});
Clazz.overrideMethod (c$, "remove", 
function () {
this.checkConcurrentMod ();
if (!this.canRemove) {
throw  new IllegalStateException ();
}this.canRemove = false;
this.associatedMap.modCount++;
var a = this.associatedMap.getModuloHash (this.lastEntry.key);
var b = this.associatedMap.elementData[a];
if (b === this.lastEntry) {
this.associatedMap.elementData[a] = this.lastEntry.next;
} else {
while (b.next != null) {
if (b.next === this.lastEntry) {
break;
}b = b.next;
}
b.next = this.lastEntry.next;
}var c = this.lastEntry;
var d = c.chainBackward;
var e = c.chainForward;
var f = this.associatedMap;
if (d != null) {
d.chainForward = e;
if (e != null) {
e.chainBackward = d;
} else {
f.tail = d;
}} else {
f.head = e;
if (e != null) {
e.chainBackward = null;
} else {
f.tail = null;
}}this.associatedMap.elementCount--;
this.expectedModCount++;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.LinkedHashMap, "LinkedHashMapEntrySet", java.util.HashMap.HashMapEntrySet);
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.LinkedHashMap.LinkedHashIterator (((Clazz.isClassDefined ("java.util.LinkedHashMap$LinkedHashMapEntrySet$1") ? 0 : java.util.LinkedHashMap.LinkedHashMapEntrySet.$LinkedHashMap$LinkedHashMapEntrySet$1$ ()), Clazz.innerTypeInstance (java.util.LinkedHashMap$LinkedHashMapEntrySet$1, this, null)), this.hashMap ());
});
c$.$LinkedHashMap$LinkedHashMapEntrySet$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "LinkedHashMap$LinkedHashMapEntrySet$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.chainForward = null;
this.chainBackward = null;
Clazz.instantialize (this, arguments);
}, java.util.LinkedHashMap, "LinkedHashMapEntry", java.util.HashMap.Entry);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.LinkedHashMap.LinkedHashMapEntry, [a, b]);
this.chainForward = null;
this.chainBackward = null;
}, "~O,~O");
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, java.util.LinkedHashMap.LinkedHashMapEntry, "clone", []);
a.chainBackward = this.chainBackward;
a.chainForward = this.chainForward;
var b = a.next;
if (b != null) {
a.next = b.clone ();
}return a;
});
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023