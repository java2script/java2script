Clazz.load (["java.util.AbstractSet", "$.SortedSet", "$.TreeMap"], "java.util.TreeSet", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.backingMap = null;
Clazz.instantialize (this, arguments);
}, java.util, "TreeSet", java.util.AbstractSet, [java.util.SortedSet, Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeSet, []);
this.backingMap = a;
}, "java.util.SortedMap");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.TreeSet, []);
this.backingMap =  new java.util.TreeMap ();
});
Clazz.makeConstructor (c$, 
function (a) {
this.construct ();
this.addAll (a);
}, "java.util.Collection");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeSet, []);
this.backingMap =  new java.util.TreeMap (a);
}, "java.util.Comparator");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.comparator ());
var b = a.iterator ();
while (b.hasNext ()) {
this.add (b.next ());
}
}, "java.util.SortedSet");
Clazz.overrideMethod (c$, "add", 
function (a) {
return this.backingMap.put (a, a) == null;
}, "~O");
Clazz.overrideMethod (c$, "clear", 
function () {
this.backingMap.clear ();
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.TreeSet, "clone", []);
if (Clazz.instanceOf (this.backingMap, java.util.TreeMap)) {
a.backingMap = (this.backingMap).clone ();
} else {
a.backingMap =  new java.util.TreeMap (this.backingMap);
}return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "comparator", 
function () {
return this.backingMap.comparator ();
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.backingMap.containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "first", 
function () {
return this.backingMap.firstKey ();
});
Clazz.overrideMethod (c$, "headSet", 
function (a) {
var b = this.backingMap.comparator ();
if (b == null) {
(a).compareTo (a);
} else {
b.compare (a, a);
}return  new java.util.TreeSet (this.backingMap.headMap (a));
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.backingMap.isEmpty ();
});
Clazz.defineMethod (c$, "iterator", 
function () {
return this.backingMap.keySet ().iterator ();
});
Clazz.overrideMethod (c$, "last", 
function () {
return this.backingMap.lastKey ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
return this.backingMap.remove (a) != null;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.backingMap.size ();
});
Clazz.overrideMethod (c$, "subSet", 
function (a, b) {
var c = this.backingMap.comparator ();
if (c == null) {
if ((a).compareTo (b) <= 0) {
return  new java.util.TreeSet (this.backingMap.subMap (a, b));
}} else {
if (c.compare (a, b) <= 0) {
return  new java.util.TreeSet (this.backingMap.subMap (a, b));
}}throw  new IllegalArgumentException ();
}, "~O,~O");
Clazz.overrideMethod (c$, "tailSet", 
function (a) {
var b = this.backingMap.comparator ();
if (b == null) {
(a).compareTo (a);
} else {
b.compare (a, a);
}return  new java.util.TreeSet (this.backingMap.tailMap (a));
}, "~O");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023