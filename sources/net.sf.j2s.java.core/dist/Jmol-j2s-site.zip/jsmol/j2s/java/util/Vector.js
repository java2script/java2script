Clazz.load (["java.util.AbstractList", "$.List", "$.RandomAccess"], "java.util.Vector", ["java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.StringBuffer", "java.lang.reflect.Array", "java.util.Arrays", "$.Collections", "$.Enumeration", "$.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.elementCount = 0;
this.elementData = null;
this.capacityIncrement = 0;
Clazz.instantialize (this, arguments);
}, java.util, "Vector", java.util.AbstractList, [java.util.List, java.util.RandomAccess, Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function () {
this.construct (10, 0);
});
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a, 0);
}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.Vector, []);
this.elementCount = 0;
try {
this.elementData = this.newElementArray (a);
} catch (e) {
if (Clazz.exceptionOf (e, NegativeArraySizeException)) {
throw  new IllegalArgumentException ();
} else {
throw e;
}
}
this.capacityIncrement = b;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.size (), 0);
var b = a.iterator ();
while (b.hasNext ()) {
this.elementData[this.elementCount++] = b.next ();
}
}, "java.util.Collection");
Clazz.defineMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.defineMethod (c$, "add", 
function (a, b) {
this.insertElementAt (b, a);
}, "~N,~O");
Clazz.defineMethod (c$, "add", 
function (a) {
this.addElement (a);
return true;
}, "~O");
Clazz.defineMethod (c$, "addAll", 
function (a, b) {
if (0 <= a && a <= this.elementCount) {
var c = b.size ();
if (c == 0) {
return false;
}var d = c - (this.elementData.length - this.elementCount);
if (d > 0) {
this.growBy (d);
}var e = this.elementCount - a;
if (e > 0) {
System.arraycopy (this.elementData, a, this.elementData, a + c, e);
}var f = b.iterator ();
while (f.hasNext ()) {
this.elementData[a++] = f.next ();
}
this.elementCount += c;
this.modCount++;
return true;
}throw  new ArrayIndexOutOfBoundsException (a);
}, "~N,java.util.Collection");
Clazz.defineMethod (c$, "addAll", 
function (a) {
return this.addAll (this.elementCount, a);
}, "java.util.Collection");
Clazz.defineMethod (c$, "addElement", 
function (a) {
if (this.elementCount == this.elementData.length) {
this.growByOne ();
}this.elementData[this.elementCount++] = a;
this.modCount++;
}, "~O");
Clazz.defineMethod (c$, "capacity", 
function () {
return this.elementData.length;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.removeAllElements ();
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.Vector, "clone", []);
a.elementData = this.elementData.clone ();
return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.indexOf (a, 0) != -1;
}, "~O");
Clazz.defineMethod (c$, "copyInto", 
function (a) {
System.arraycopy (this.elementData, 0, a, 0, this.elementCount);
}, "~A");
Clazz.defineMethod (c$, "elementAt", 
function (a) {
if (a < this.elementCount) {
return this.elementData[a];
}throw  new ArrayIndexOutOfBoundsException (a);
}, "~N");
Clazz.defineMethod (c$, "elements", 
function () {
return ((Clazz.isClassDefined ("java.util.Vector$1") ? 0 : java.util.Vector.$Vector$1$ ()), Clazz.innerTypeInstance (java.util.Vector$1, this, null));
});
Clazz.defineMethod (c$, "ensureCapacity", 
function (a) {
if (this.elementData.length < a) {
var b = (this.capacityIncrement <= 0 ? this.elementData.length : this.capacityIncrement) + this.elementData.length;
this.grow (a > b ? a : b);
}}, "~N");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.List)) {
var b = a;
if (b.size () != this.size ()) {
return false;
}var c = 0;
var d = b.iterator ();
while (d.hasNext ()) {
var e = this.elementData[c++];
var f = d.next ();
if (!(e == null ? f == null : e.equals (f))) {
return false;
}}
return true;
}return false;
}, "~O");
Clazz.defineMethod (c$, "firstElement", 
function () {
if (this.elementCount > 0) {
return this.elementData[0];
}throw  new java.util.NoSuchElementException ();
});
Clazz.overrideMethod (c$, "get", 
function (a) {
return this.elementAt (a);
}, "~N");
Clazz.defineMethod (c$, "grow", 
function (a) {
var b = this.newElementArray (a);
System.arraycopy (this.elementData, 0, b, 0, this.elementCount);
this.elementData = b;
}, "~N");
Clazz.defineMethod (c$, "growByOne", 
function () {
var a = 0;
if (this.capacityIncrement <= 0) {
if ((a = this.elementData.length) == 0) {
a = 1;
}} else {
a = this.capacityIncrement;
}var b = this.newElementArray (this.elementData.length + a);
System.arraycopy (this.elementData, 0, b, 0, this.elementCount);
this.elementData = b;
});
Clazz.defineMethod (c$, "growBy", 
function (a) {
var b = 0;
if (this.capacityIncrement <= 0) {
if ((b = this.elementData.length) == 0) {
b = a;
}while (b < a) {
b += b;
}
} else {
b = (Clazz.doubleToInt (a / this.capacityIncrement)) * this.capacityIncrement;
if (b < a) {
b += this.capacityIncrement;
}}var c = this.newElementArray (this.elementData.length + b);
System.arraycopy (this.elementData, 0, c, 0, this.elementCount);
this.elementData = c;
}, "~N");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a = 1;
for (var b = 0; b < this.elementCount; b++) {
a = (31 * a) + (this.elementData[b] == null ? 0 : this.elementData[b].hashCode ());
}
return a;
});
Clazz.defineMethod (c$, "indexOf", 
function (a) {
return this.indexOf (a, 0);
}, "~O");
Clazz.defineMethod (c$, "indexOf", 
function (a, b) {
if (a != null) {
for (var c = b; c < this.elementCount; c++) {
if (a.equals (this.elementData[c])) {
return c;
}}
} else {
for (var c = b; c < this.elementCount; c++) {
if (this.elementData[c] == null) {
return c;
}}
}return -1;
}, "~O,~N");
Clazz.defineMethod (c$, "insertElementAt", 
function (a, b) {
if (0 <= b && b <= this.elementCount) {
if (this.elementCount == this.elementData.length) {
this.growByOne ();
}var c = this.elementCount - b;
if (c > 0) {
System.arraycopy (this.elementData, b, this.elementData, b + 1, c);
}this.elementData[b] = a;
this.elementCount++;
this.modCount++;
} else {
throw  new ArrayIndexOutOfBoundsException (b);
}}, "~O,~N");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.elementCount == 0;
});
Clazz.defineMethod (c$, "lastElement", 
function () {
try {
return this.elementData[this.elementCount - 1];
} catch (e) {
if (Clazz.exceptionOf (e, IndexOutOfBoundsException)) {
throw  new java.util.NoSuchElementException ();
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "lastIndexOf", 
function (a) {
return this.lastIndexOf (a, this.elementCount - 1);
}, "~O");
Clazz.defineMethod (c$, "lastIndexOf", 
function (a, b) {
if (b < this.elementCount) {
if (a != null) {
for (var c = b; c >= 0; c--) {
if (a.equals (this.elementData[c])) {
return c;
}}
} else {
for (var c = b; c >= 0; c--) {
if (this.elementData[c] == null) {
return c;
}}
}return -1;
}throw  new ArrayIndexOutOfBoundsException (b);
}, "~O,~N");
Clazz.defineMethod (c$, "remove", 
function (a) {
if (a < this.elementCount) {
var b = this.elementData[a];
this.elementCount--;
var c = this.elementCount - a;
if (c > 0) {
System.arraycopy (this.elementData, a + 1, this.elementData, a, c);
}this.elementData[this.elementCount] = null;
this.modCount++;
return b;
}throw  new ArrayIndexOutOfBoundsException (a);
}, "~N");
Clazz.defineMethod (c$, "remove", 
function (a) {
return this.removeElement (a);
}, "~O");
Clazz.defineMethod (c$, "removeAllElements", 
function () {
java.util.Arrays.fill (this.elementData, 0, this.elementCount, null);
this.modCount++;
this.elementCount = 0;
});
Clazz.defineMethod (c$, "removeElement", 
function (a) {
var b;
if ((b = this.indexOf (a, 0)) == -1) {
return false;
}this.removeElementAt (b);
return true;
}, "~O");
Clazz.defineMethod (c$, "removeElementAt", 
function (a) {
if (0 <= a && a < this.elementCount) {
this.elementCount--;
var b = this.elementCount - a;
if (b > 0) {
System.arraycopy (this.elementData, a + 1, this.elementData, a, b);
}this.elementData[this.elementCount] = null;
this.modCount++;
} else {
throw  new ArrayIndexOutOfBoundsException (a);
}}, "~N");
Clazz.overrideMethod (c$, "removeRange", 
function (a, b) {
if (a >= 0 && a <= b && b <= this.size ()) {
if (a == b) {
return;
}if (b != this.elementCount) {
System.arraycopy (this.elementData, b, this.elementData, a, this.elementCount - b);
var c = this.elementCount - (b - a);
java.util.Arrays.fill (this.elementData, c, this.elementCount, null);
this.elementCount = c;
} else {
java.util.Arrays.fill (this.elementData, a, this.elementCount, null);
this.elementCount = a;
}this.modCount++;
} else {
throw  new IndexOutOfBoundsException ();
}}, "~N,~N");
Clazz.overrideMethod (c$, "set", 
function (a, b) {
if (a < this.elementCount) {
var c = this.elementData[a];
this.elementData[a] = b;
return c;
}throw  new ArrayIndexOutOfBoundsException (a);
}, "~N,~O");
Clazz.defineMethod (c$, "setElementAt", 
function (a, b) {
if (b < this.elementCount) {
this.elementData[b] = a;
} else {
throw  new ArrayIndexOutOfBoundsException (b);
}}, "~O,~N");
Clazz.defineMethod (c$, "setSize", 
function (a) {
if (a == this.elementCount) {
return;
}this.ensureCapacity (a);
if (this.elementCount > a) {
java.util.Arrays.fill (this.elementData, a, this.elementCount, null);
}this.elementCount = a;
this.modCount++;
}, "~N");
Clazz.overrideMethod (c$, "size", 
function () {
return this.elementCount;
});
Clazz.overrideMethod (c$, "subList", 
function (a, b) {
return  new java.util.Collections.SynchronizedRandomAccessList (Clazz.superCall (this, java.util.Vector, "subList", [a, b]), this);
}, "~N,~N");
Clazz.defineMethod (c$, "toArray", 
function () {
var a =  new Array (this.elementCount);
System.arraycopy (this.elementData, 0, a, 0, this.elementCount);
return a;
});
Clazz.defineMethod (c$, "toArray", 
function (a) {
if (this.elementCount > a.length) {
var b = a.getClass ().getComponentType ();
a = java.lang.reflect.Array.newInstance (b, this.elementCount);
}System.arraycopy (this.elementData, 0, a, 0, this.elementCount);
if (this.elementCount < a.length) {
a[this.elementCount] = null;
}return a;
}, "~A");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.elementCount == 0) {
return "[]";
}var a = this.elementCount - 1;
var b =  new StringBuffer (this.size () * 16);
b.append ('[');
for (var c = 0; c < a; c++) {
if (this.elementData[c] === this) {
b.append ("(this Collection)");
} else {
b.append (this.elementData[c]);
}b.append (", ");
}
if (this.elementData[a] === this) {
b.append ("(this Collection)");
} else {
b.append (this.elementData[a]);
}b.append (']');
return b.toString ();
});
Clazz.defineMethod (c$, "trimToSize", 
function () {
if (this.elementData.length != this.elementCount) {
this.grow (this.elementCount);
}});
c$.$Vector$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.pos = 0;
Clazz.instantialize (this, arguments);
}, java.util, "Vector$1", null, java.util.Enumeration);
Clazz.overrideMethod (c$, "hasMoreElements", 
function () {
return this.pos < this.b$["java.util.Vector"].elementCount;
});
Clazz.overrideMethod (c$, "nextElement", 
function () {
{
if (this.pos < this.b$["java.util.Vector"].elementCount) {
return this.b$["java.util.Vector"].elementData[this.pos++];
}}throw  new java.util.NoSuchElementException ();
});
c$ = Clazz.p0p ();
};
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023