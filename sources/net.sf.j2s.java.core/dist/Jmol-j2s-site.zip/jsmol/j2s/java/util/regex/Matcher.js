Clazz.declarePackage ("java.util.regex");
Clazz.load (["java.util.regex.MatchResult"], "java.util.regex.Matcher", ["java.lang.IllegalArgumentException", "$.IndexOutOfBoundsException", "$.NullPointerException", "$.StringBuffer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.pat = null;
this.string = null;
this.leftBound = -1;
this.rightBound = -1;
this.appendPos = 0;
this.replacement = null;
this.processedRepl = null;
this.replacementParts = null;
this.results = null;
Clazz.instantialize (this, arguments);
}, java.util.regex, "Matcher", null, java.util.regex.MatchResult);
Clazz.defineMethod (c$, "appendReplacement", 
function (a, b) {
this.processedRepl = this.processReplacement (b);
a.append (this.string.subSequence (this.appendPos, this.start ()));
a.append (this.processedRepl);
this.appendPos = this.end ();
return this;
}, "StringBuffer,~S");
Clazz.defineMethod (c$, "processReplacement", 
function (a) {
if (this.replacement != null && this.replacement.equals (a)) {
if (this.replacementParts == null) {
return this.processedRepl;
} else {
var b =  new StringBuffer ();
for (var c = 0; c < this.replacementParts.length; c++) {
b.append (this.replacementParts[c]);
}
return b.toString ();
}} else {
this.replacement = a;
var b = a.toCharArray ();
var c =  new StringBuffer ();
this.replacementParts = null;
var d = 0;
var e = 0;
var f = false;
while (d < b.length) {
if (b[d] == '\\' && !f) {
f = true;
d++;
}if (f) {
c.append (b[d]);
f = false;
} else {
if (b[d] == '$') {
if (this.replacementParts == null) {
this.replacementParts =  new Array (0);
}try {
var g = Integer.parseInt ( String.instantialize (b, ++d, 1));
if (e != c.length ()) {
this.replacementParts[this.replacementParts.length] = c.subSequence (e, c.length ());
e = c.length ();
}this.replacementParts[this.replacementParts.length] = ((Clazz.isClassDefined ("java.util.regex.Matcher$1") ? 0 : java.util.regex.Matcher.$Matcher$1$ ()), Clazz.innerTypeInstance (java.util.regex.Matcher$1, this, Clazz.cloneFinals ("g", g)));
var h = this.group (g);
e += h.length;
c.append (h);
} catch (e$$) {
if (Clazz.exceptionOf (e$$, IndexOutOfBoundsException)) {
var iob = e$$;
{
throw iob;
}
} else if (Clazz.exceptionOf (e$$, Exception)) {
var e = e$$;
{
throw  new IllegalArgumentException ("Illegal regular expression format");
}
} else {
throw e$$;
}
}
} else {
c.append (b[d]);
}}d++;
}
if (this.replacementParts != null && e != c.length ()) {
this.replacementParts[this.replacementParts.length] = c.subSequence (e, c.length ());
}return c.toString ();
}}, "~S");
Clazz.defineMethod (c$, "reset", 
function (a) {
if (a == null) {
throw  new NullPointerException ("Empty new sequence!");
}this.string = a;
return this.reset ();
}, "CharSequence");
Clazz.defineMethod (c$, "reset", 
function () {
this.leftBound = 0;
this.rightBound = this.string.length;
this.appendPos = 0;
this.replacement = null;
{
var flags = "" + (this.pat.regexp.ignoreCase ? "i" : "")
+ (this.pat.regexp.global ? "g" : "")
+ (this.pat.regexp.multiline ? "m" : "");
this.pat.regexp = new RegExp (this.pat.regexp.source, flags);
}return this;
});
Clazz.defineMethod (c$, "region", 
function (a, b) {
if (a > b || a < 0 || b < 0 || a > this.string.length || b > this.string.length) {
throw  new IndexOutOfBoundsException (a + " is out of bound of " + b);
}this.leftBound = a;
this.rightBound = b;
this.results = null;
this.appendPos = 0;
this.replacement = null;
return this;
}, "~N,~N");
Clazz.defineMethod (c$, "appendTail", 
function (a) {
return a.append (this.string.subSequence (this.appendPos, this.string.length));
}, "StringBuffer");
Clazz.defineMethod (c$, "replaceFirst", 
function (a) {
this.reset ();
if (this.find ()) {
var b =  new StringBuffer ();
this.appendReplacement (b, a);
return this.appendTail (b).toString ();
}return this.string.toString ();
}, "~S");
Clazz.defineMethod (c$, "replaceAll", 
function (a) {
var b =  new StringBuffer ();
this.reset ();
while (this.find ()) {
this.appendReplacement (b, a);
}
return this.appendTail (b).toString ();
}, "~S");
Clazz.defineMethod (c$, "pattern", 
function () {
return this.pat;
});
Clazz.defineMethod (c$, "group", 
function (a) {
if (this.results == null || a < 0 || a > this.results.length) {
return null;
}return this.results[a];
}, "~N");
Clazz.defineMethod (c$, "group", 
function () {
return this.group (0);
});
Clazz.defineMethod (c$, "find", 
function (a) {
var b = this.string.length;
if (a < 0 || a > b) throw  new IndexOutOfBoundsException ("Out of bound " + a);
a = this.findAt (a);
return false;
}, "~N");
Clazz.defineMethod (c$, "findAt", 
function (a) {
return -1;
}, "~N");
Clazz.defineMethod (c$, "find", 
function () {
{
this.results = this.pat.regexp.exec (this.string.subSequence(this.leftBound, this.rightBound));
}return (this.results != null);
});
Clazz.defineMethod (c$, "start", 
function (a) {
var b = 0;
{
beginningIndex = this.pat.regexp.lastIndex;
}b -= this.results[0].length;
return b;
}, "~N");
Clazz.defineMethod (c$, "end", 
function (a) {
{
return this.pat.regexp.lastIndex;
}return -1;
}, "~N");
Clazz.defineMethod (c$, "matches", 
function () {
return this.find ();
});
c$.quoteReplacement = Clazz.defineMethod (c$, "quoteReplacement", 
function (a) {
if (a.indexOf ('\\') < 0 && a.indexOf ('$') < 0) return a;
var b =  new StringBuffer (a.length * 2);
var c;
var d = a.length;
for (var e = 0; e < d; e++) {
switch (c = a.charAt (e)) {
case '$':
b.append ('\\');
b.append ('$');
break;
case '\\':
b.append ('\\');
b.append ('\\');
break;
default:
b.append (c);
}
}
return b.toString ();
}, "~S");
Clazz.defineMethod (c$, "lookingAt", 
function () {
return false;
});
Clazz.defineMethod (c$, "start", 
function () {
return this.start (0);
});
Clazz.overrideMethod (c$, "groupCount", 
function () {
return this.results == null ? 0 : this.results.length;
});
Clazz.defineMethod (c$, "end", 
function () {
return this.end (0);
});
Clazz.defineMethod (c$, "toMatchResult", 
function () {
return this;
});
Clazz.defineMethod (c$, "useAnchoringBounds", 
function (a) {
return this;
}, "~B");
Clazz.defineMethod (c$, "hasAnchoringBounds", 
function () {
return false;
});
Clazz.defineMethod (c$, "useTransparentBounds", 
function (a) {
return this;
}, "~B");
Clazz.defineMethod (c$, "hasTransparentBounds", 
function () {
return false;
});
Clazz.defineMethod (c$, "regionStart", 
function () {
return this.leftBound;
});
Clazz.defineMethod (c$, "regionEnd", 
function () {
return this.rightBound;
});
Clazz.defineMethod (c$, "requireEnd", 
function () {
return false;
});
Clazz.defineMethod (c$, "hitEnd", 
function () {
return false;
});
Clazz.defineMethod (c$, "usePattern", 
function (a) {
if (a == null) {
throw  new IllegalArgumentException ("Empty pattern!");
}this.pat = a;
this.results = null;
return this;
}, "java.util.regex.Pattern");
Clazz.makeConstructor (c$, 
function (a, b) {
this.pat = a;
this.string = b;
this.leftBound = 0;
this.rightBound = this.string.toString ().length;
}, "java.util.regex.Pattern,CharSequence");
c$.$Matcher$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.grN = 0;
Clazz.instantialize (this, arguments);
}, java.util.regex, "Matcher$1");
Clazz.prepareFields (c$, function () {
this.grN = this.f$.g;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.b$["java.util.regex.Matcher"].group (this.grN);
});
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"MODE_FIND", 1,
"MODE_MATCH", 2);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023