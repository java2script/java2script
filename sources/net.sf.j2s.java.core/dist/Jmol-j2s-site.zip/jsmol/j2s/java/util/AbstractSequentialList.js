Clazz.load (["java.util.AbstractList"], "java.util.AbstractSequentialList", ["java.lang.IndexOutOfBoundsException"], function () {
c$ = Clazz.declareType (java.util, "AbstractSequentialList", java.util.AbstractList);
Clazz.defineMethod (c$, "add", 
function (a, b) {
this.listIterator (a).add (b);
}, "~N,~O");
Clazz.defineMethod (c$, "addAll", 
function (a, b) {
var c = this.listIterator (a);
var d = b.iterator ();
var e = c.nextIndex ();
while (d.hasNext ()) {
c.add (d.next ());
c.previous ();
}
return e != c.nextIndex ();
}, "~N,java.util.Collection");
Clazz.overrideMethod (c$, "get", 
function (a) {
try {
return this.listIterator (a).next ();
} catch (e) {
if (Clazz.exceptionOf (e, java.util.NoSuchElementException)) {
throw  new IndexOutOfBoundsException ();
} else {
throw e;
}
}
}, "~N");
Clazz.overrideMethod (c$, "iterator", 
function () {
return this.listIterator (0);
});
Clazz.defineMethod (c$, "remove", 
function (a) {
try {
var b = this.listIterator (a);
var c = b.next ();
b.remove ();
return c;
} catch (e) {
if (Clazz.exceptionOf (e, java.util.NoSuchElementException)) {
throw  new IndexOutOfBoundsException ();
} else {
throw e;
}
}
}, "~N");
Clazz.overrideMethod (c$, "set", 
function (a, b) {
var c = this.listIterator (a);
var d = c.next ();
c.set (b);
return d;
}, "~N,~O");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023