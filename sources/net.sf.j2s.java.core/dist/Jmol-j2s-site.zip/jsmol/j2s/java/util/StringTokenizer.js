Clazz.load (["java.util.Enumeration"], "java.util.StringTokenizer", ["java.lang.NullPointerException", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.string = null;
this.delimiters = null;
this.returnDelimiters = false;
this.position = 0;
Clazz.instantialize (this, arguments);
}, java.util, "StringTokenizer", null, java.util.Enumeration);
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a, " \t\n\r\f", false);
}, "~S");
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct (a, b, false);
}, "~S,~S");
Clazz.makeConstructor (c$, 
function (a, b, c) {
if (a != null) {
this.string = a;
this.delimiters = b;
this.returnDelimiters = c;
this.position = 0;
} else throw  new NullPointerException ();
}, "~S,~S,~B");
Clazz.defineMethod (c$, "countTokens", 
function () {
var a = 0;
var b = false;
for (var c = this.position, d = this.string.length; c < d; c++) {
if (this.delimiters.indexOf (this.string.charAt (c), 0) >= 0) {
if (this.returnDelimiters) a++;
if (b) {
a++;
b = false;
}} else {
b = true;
}}
if (b) a++;
return a;
});
Clazz.overrideMethod (c$, "hasMoreElements", 
function () {
return this.hasMoreTokens ();
});
Clazz.defineMethod (c$, "hasMoreTokens", 
function () {
var a = this.string.length;
if (this.position < a) {
if (this.returnDelimiters) return true;
for (var b = this.position; b < a; b++) if (this.delimiters.indexOf (this.string.charAt (b), 0) == -1) return true;

}return false;
});
Clazz.overrideMethod (c$, "nextElement", 
function () {
return this.nextToken ();
});
Clazz.defineMethod (c$, "nextToken", 
function () {
var a = this.position;
var b = this.string.length;
if (a < b) {
if (this.returnDelimiters) {
if (this.delimiters.indexOf (this.string.charAt (this.position), 0) >= 0) return String.valueOf (this.string.charAt (this.position++));
for (this.position++; this.position < b; this.position++) if (this.delimiters.indexOf (this.string.charAt (this.position), 0) >= 0) return this.string.substring (a, this.position);

return this.string.substring (a);
}while (a < b && this.delimiters.indexOf (this.string.charAt (a), 0) >= 0) a++;

this.position = a;
if (a < b) {
for (this.position++; this.position < b; this.position++) if (this.delimiters.indexOf (this.string.charAt (this.position), 0) >= 0) return this.string.substring (a, this.position);

return this.string.substring (a);
}}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "nextToken", 
function (a) {
this.delimiters = a;
return this.nextToken ();
}, "~S");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023