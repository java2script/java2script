Clazz.load (["java.lang.ref.WeakReference", "java.util.AbstractMap", "$.Iterator", "$.Map"], "java.util.WeakHashMap", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "java.lang.ref.ReferenceQueue", "java.util.AbstractCollection", "$.AbstractSet", "$.Arrays", "$.ConcurrentModificationException", "java.util.Map.Entry", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.referenceQueue = null;
this.elementCount = 0;
this.elementData = null;
this.loadFactor = 0;
this.threshold = 0;
this.modCount = 0;
if (!Clazz.isClassDefined ("java.util.WeakHashMap.HashIterator")) {
java.util.WeakHashMap.$WeakHashMap$HashIterator$ ();
}
Clazz.instantialize (this, arguments);
}, java.util, "WeakHashMap", java.util.AbstractMap, java.util.Map);
c$.newEntryArray = Clazz.defineMethod (c$, "newEntryArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.makeConstructor (c$, 
function () {
this.construct (16);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.WeakHashMap, []);
if (a >= 0) {
this.elementCount = 0;
this.elementData = java.util.WeakHashMap.newEntryArray (a == 0 ? 1 : a);
this.loadFactor = 7500;
this.computeMaxSize ();
this.referenceQueue =  new java.lang.ref.ReferenceQueue ();
} else {
throw  new IllegalArgumentException ();
}}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.WeakHashMap, []);
if (a >= 0 && b > 0) {
this.elementCount = 0;
this.elementData = java.util.WeakHashMap.newEntryArray (a == 0 ? 1 : a);
this.loadFactor = Clazz.floatToInt (b * 10000);
this.computeMaxSize ();
this.referenceQueue =  new java.lang.ref.ReferenceQueue ();
} else {
throw  new IllegalArgumentException ();
}}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.size () < 6 ? 11 : a.size () * 2);
this.putAllImpl (a);
}, "java.util.Map");
Clazz.overrideMethod (c$, "clear", 
function () {
if (this.elementCount > 0) {
this.elementCount = 0;
java.util.Arrays.fill (this.elementData, null);
this.modCount++;
while (this.referenceQueue.poll () != null) {
}
}});
Clazz.defineMethod (c$, "computeMaxSize", 
function () {
this.threshold = (Clazz.doubleToInt (this.elementData.length * this.loadFactor / 10000));
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
return this.getEntry (a) != null;
}, "~O");
Clazz.overrideMethod (c$, "entrySet", 
function () {
this.poll ();
return ((Clazz.isClassDefined ("java.util.WeakHashMap$1") ? 0 : java.util.WeakHashMap.$WeakHashMap$1$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$1, this, null));
});
Clazz.overrideMethod (c$, "keySet", 
function () {
this.poll ();
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.WeakHashMap$2") ? 0 : java.util.WeakHashMap.$WeakHashMap$2$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$2, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "values", 
function () {
this.poll ();
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.WeakHashMap$3") ? 0 : java.util.WeakHashMap.$WeakHashMap$3$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$3, this, null));
}return this.valuesCollection;
});
Clazz.overrideMethod (c$, "get", 
function (a) {
this.poll ();
if (a != null) {
var b = (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
var c = this.elementData[b];
while (c != null) {
if (a.equals (c.get ())) {
return c.value;
}c = c.$next;
}
return null;
}var b = this.elementData[0];
while (b != null) {
if (b.isNull) {
return b.value;
}b = b.$next;
}
return null;
}, "~O");
Clazz.defineMethod (c$, "getEntry", 
function (a) {
this.poll ();
if (a != null) {
var b = (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
var c = this.elementData[b];
while (c != null) {
if (a.equals (c.get ())) {
return c;
}c = c.$next;
}
return null;
}var b = this.elementData[0];
while (b != null) {
if (b.isNull) {
return b;
}b = b.$next;
}
return null;
}, "~O");
Clazz.overrideMethod (c$, "containsValue", 
function (a) {
this.poll ();
if (a != null) {
for (var b = this.elementData.length; --b >= 0; ) {
var c = this.elementData[b];
while (c != null) {
var d = c.get ();
if ((d != null || c.isNull) && a.equals (c.value)) {
return true;
}c = c.$next;
}
}
} else {
for (var b = this.elementData.length; --b >= 0; ) {
var c = this.elementData[b];
while (c != null) {
var d = c.get ();
if ((d != null || c.isNull) && c.value == null) {
return true;
}c = c.$next;
}
}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.size () == 0;
});
Clazz.defineMethod (c$, "poll", 
function () {
var a;
while ((a = this.referenceQueue.poll ()) != null) {
this.removeEntry (a);
}
});
Clazz.defineMethod (c$, "removeEntry", 
function (a) {
var b;
var c = null;
var d = (a.hash & 0x7FFFFFFF) % this.elementData.length;
b = this.elementData[d];
while (b != null) {
if (a === b) {
this.modCount++;
if (c == null) {
this.elementData[d] = b.$next;
} else {
c.$next = b.$next;
}this.elementCount--;
break;
}c = b;
b = b.$next;
}
}, "java.util.WeakHashMap.Entry");
Clazz.overrideMethod (c$, "put", 
function (a, b) {
this.poll ();
var c = 0;
var d;
if (a != null) {
c = (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
d = this.elementData[c];
while (d != null && !a.equals (d.get ())) {
d = d.$next;
}
} else {
d = this.elementData[0];
while (d != null && !d.isNull) {
d = d.$next;
}
}if (d == null) {
this.modCount++;
if (++this.elementCount > this.threshold) {
this.rehash ();
c = a == null ? 0 : (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
}d =  new java.util.WeakHashMap.Entry (a, b, this.referenceQueue);
d.$next = this.elementData[c];
this.elementData[c] = d;
return null;
}var e = d.value;
d.value = b;
return e;
}, "~O,~O");
Clazz.defineMethod (c$, "rehash", 
function () {
var a = this.elementData.length << 1;
if (a == 0) {
a = 1;
}var b = java.util.WeakHashMap.newEntryArray (a);
for (var c = 0; c < this.elementData.length; c++) {
var d = this.elementData[c];
while (d != null) {
var e = d.isNull ? 0 : (d.hash & 0x7FFFFFFF) % a;
var f = d.$next;
d.$next = b[e];
b[e] = d;
d = f;
}
}
this.elementData = b;
this.computeMaxSize ();
});
Clazz.overrideMethod (c$, "putAll", 
function (a) {
this.putAllImpl (a);
}, "java.util.Map");
Clazz.overrideMethod (c$, "remove", 
function (a) {
this.poll ();
var b = 0;
var c;
var d = null;
if (a != null) {
b = (a.hashCode () & 0x7FFFFFFF) % this.elementData.length;
c = this.elementData[b];
while (c != null && !a.equals (c.get ())) {
d = c;
c = c.$next;
}
} else {
c = this.elementData[0];
while (c != null && !c.isNull) {
d = c;
c = c.$next;
}
}if (c != null) {
this.modCount++;
if (d == null) {
this.elementData[b] = c.$next;
} else {
d.$next = c.$next;
}this.elementCount--;
return c.value;
}return null;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
this.poll ();
return this.elementCount;
});
Clazz.defineMethod (c$, "putAllImpl", 
function (a) {
if (a.entrySet () != null) {
Clazz.superCall (this, java.util.WeakHashMap, "putAll", [a]);
}}, "java.util.Map");
c$.$WeakHashMap$HashIterator$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.position = 0;
this.expectedModCount = 0;
this.currentEntry = null;
this.nextEntry = null;
this.nextKey = null;
this.type = null;
Clazz.instantialize (this, arguments);
}, java.util.WeakHashMap, "HashIterator", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
this.type = a;
this.expectedModCount = this.b$["java.util.WeakHashMap"].modCount;
}, "java.util.WeakHashMap.Entry.Type");
Clazz.overrideMethod (c$, "hasNext", 
function () {
if (this.nextEntry != null) {
return true;
}while (true) {
if (this.nextEntry == null) {
while (this.position < this.b$["java.util.WeakHashMap"].elementData.length) {
if ((this.nextEntry = this.b$["java.util.WeakHashMap"].elementData[this.position++]) != null) {
break;
}}
if (this.nextEntry == null) {
return false;
}}this.nextKey = this.nextEntry.get ();
if (this.nextKey != null || this.nextEntry.isNull) {
return true;
}this.nextEntry = this.nextEntry.$next;
}
});
Clazz.overrideMethod (c$, "next", 
function () {
if (this.expectedModCount == this.b$["java.util.WeakHashMap"].modCount) {
if (this.hasNext ()) {
this.currentEntry = this.nextEntry;
this.nextEntry = this.currentEntry.$next;
var a = this.type.get (this.currentEntry);
this.nextKey = null;
return a;
}throw  new java.util.NoSuchElementException ();
}throw  new java.util.ConcurrentModificationException ();
});
Clazz.overrideMethod (c$, "remove", 
function () {
if (this.expectedModCount == this.b$["java.util.WeakHashMap"].modCount) {
if (this.currentEntry != null) {
this.b$["java.util.WeakHashMap"].removeEntry (this.currentEntry);
this.currentEntry = null;
this.expectedModCount++;
} else {
throw  new IllegalStateException ();
}} else {
throw  new java.util.ConcurrentModificationException ();
}});
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.WeakHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.WeakHashMap"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.contains (a)) {
this.b$["java.util.WeakHashMap"].remove ((a).getKey ());
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = this.b$["java.util.WeakHashMap"].getEntry ((a).getKey ());
if (b != null) {
var c = b.get ();
if (c != null || b.isNull) {
return a.equals (b);
}}}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.WeakHashMap.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.WeakHashMap$1$1") ? 0 : java.util.WeakHashMap.$WeakHashMap$1$1$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$1$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$1$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$1$1", null, java.util.WeakHashMap.Entry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a;
}, "java.util.Map.Entry");
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$2", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.WeakHashMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.WeakHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.WeakHashMap"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.b$["java.util.WeakHashMap"].containsKey (a)) {
this.b$["java.util.WeakHashMap"].remove (a);
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.WeakHashMap.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.WeakHashMap$2$1") ? 0 : java.util.WeakHashMap.$WeakHashMap$2$1$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$2$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$2$1", null, java.util.WeakHashMap.Entry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.getKey ();
}, "java.util.Map.Entry");
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$3$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$3", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.WeakHashMap"].size ();
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.WeakHashMap"].clear ();
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.WeakHashMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.WeakHashMap.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.WeakHashMap$3$1") ? 0 : java.util.WeakHashMap.$WeakHashMap$3$1$ ()), Clazz.innerTypeInstance (java.util.WeakHashMap$3$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$WeakHashMap$3$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "WeakHashMap$3$1", null, java.util.WeakHashMap.Entry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.getValue ();
}, "java.util.Map.Entry");
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.hash = 0;
this.isNull = false;
this.value = null;
this.$next = null;
Clazz.instantialize (this, arguments);
}, java.util.WeakHashMap, "Entry", java.lang.ref.WeakReference, java.util.Map.Entry);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.WeakHashMap.Entry, [a, c]);
this.isNull = a == null;
this.hash = this.isNull ? 0 : a.hashCode ();
this.value = b;
}, "~O,~O,java.lang.ref.ReferenceQueue");
Clazz.overrideMethod (c$, "getKey", 
function () {
return Clazz.superCall (this, java.util.WeakHashMap.Entry, "get", []);
});
Clazz.overrideMethod (c$, "getValue", 
function () {
return this.value;
});
Clazz.overrideMethod (c$, "setValue", 
function (a) {
var b = this.value;
this.value = a;
return b;
}, "~O");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (!(Clazz.instanceOf (a, java.util.Map.Entry))) {
return false;
}var b = a;
var c = Clazz.superCall (this, java.util.WeakHashMap.Entry, "get", []);
return (c == null ? c === b.getKey () : c.equals (b.getKey ())) && (this.value == null ? this.value === b.getValue () : this.value.equals (b.getValue ()));
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.hash + (this.value == null ? 0 : this.value.hashCode ());
});
Clazz.overrideMethod (c$, "toString", 
function () {
return Clazz.superCall (this, java.util.WeakHashMap.Entry, "get", []) + "=" + this.value;
});
Clazz.declareInterface (java.util.WeakHashMap.Entry, "Type");
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023