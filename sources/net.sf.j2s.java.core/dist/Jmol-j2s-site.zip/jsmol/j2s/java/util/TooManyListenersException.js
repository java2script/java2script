Clazz.load (["java.lang.Exception"], "java.util.TooManyListenersException", null, function () {
var c$ = Clazz.declareType (java.util, "TooManyListenersException", Exception);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
