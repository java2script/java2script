Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.util.zip.InflaterInputStream", "$.CRC32"], "java.util.zip.GZIPInputStream", ["java.io.EOFException", "$.IOException", "java.util.zip.CheckedInputStream", "$.Inflater", "$.ZipException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.crc = null;
this.eos = false;
this.$closed = false;
this.tmpbuf = null;
Clazz.instantialize (this, arguments);
}, java.util.zip, "GZIPInputStream", java.util.zip.InflaterInputStream);
Clazz.prepareFields (c$, function () {
this.crc =  new java.util.zip.CRC32 ();
this.tmpbuf =  Clazz.newByteArray (128, 0);
});
Clazz.defineMethod (c$, "ensureOpen", 
function () {
if (this.$closed) {
throw  new java.io.IOException ("Stream closed");
}});
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.zip.GZIPInputStream, [a,  new java.util.zip.Inflater ().init (0, true), b]);
this.readHeader (a);
}, "java.io.InputStream,~N");
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
this.ensureOpen ();
if (this.eos) {
return -1;
}var d = this.readInf (a, b, c);
if (d == -1) {
if (this.readTrailer ()) this.eos = true;
 else return this.read (a, b, c);
} else {
this.crc.update (a, b, d);
}return d;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "close", 
function () {
if (!this.$closed) {
Clazz.superCall (this, java.util.zip.GZIPInputStream, "close", []);
this.eos = true;
this.$closed = true;
}});
Clazz.defineMethod (c$, "readHeader", 
function (a) {
var b =  new java.util.zip.CheckedInputStream (a).set (this.crc);
this.crc.reset ();
if (this.readUShort (b) != 35615) {
throw  new java.util.zip.ZipException ("Not in GZIP format");
}if (this.readUByte (b) != 8) {
throw  new java.util.zip.ZipException ("Unsupported compression method");
}var c = this.readUByte (b);
this.skipBytes (b, 6);
var d = 10;
if ((c & 4) == 4) {
var e = this.readUShort (b);
this.skipBytes (b, e);
d += e + 2;
}if ((c & 8) == 8) {
do {
d++;
} while (this.readUByte (b) != 0);
}if ((c & 16) == 16) {
do {
d++;
} while (this.readUByte (b) != 0);
}if ((c & 2) == 2) {
var e = this.crc.getValue () & 0xffff;
if (this.readUShort (b) != e) {
throw  new java.util.zip.ZipException ("Corrupt GZIP header");
}d += 2;
}this.crc.reset ();
return d;
}, "java.io.InputStream");
Clazz.defineMethod (c$, "readTrailer", 
function () {
return true;
});
Clazz.defineMethod (c$, "readUShort", 
function (a) {
var b = this.readUByte (a);
return (this.readUByte (a) << 8) | b;
}, "java.io.InputStream");
Clazz.defineMethod (c$, "readUByte", 
function (a) {
var b = a.readByteAsInt ();
if (b == -1) {
throw  new java.io.EOFException ();
}if (b < -1 || b > 255) {
throw  new java.io.IOException (this.$in.getClass ().getName () + ".read() returned value out of range -1..255: " + b);
}return b;
}, "java.io.InputStream");
Clazz.defineMethod (c$, "skipBytes", 
function (a, b) {
while (b > 0) {
var c = a.read (this.tmpbuf, 0, b < this.tmpbuf.length ? b : this.tmpbuf.length);
if (c == -1) {
throw  new java.io.EOFException ();
}b -= c;
}
}, "java.io.InputStream,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023