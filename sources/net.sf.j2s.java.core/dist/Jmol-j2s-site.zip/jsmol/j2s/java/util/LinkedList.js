Clazz.load (["java.util.AbstractSequentialList", "$.List", "$.ListIterator", "$.Queue"], "java.util.LinkedList", ["java.lang.IllegalStateException", "$.IndexOutOfBoundsException", "java.lang.reflect.Array", "java.util.ConcurrentModificationException", "$.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$size = 0;
this.voidLink = null;
Clazz.instantialize (this, arguments);
}, java.util, "LinkedList", java.util.AbstractSequentialList, [java.util.List, java.util.Queue, Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.LinkedList, []);
this.voidLink =  new java.util.LinkedList.Link (null, null, null);
this.voidLink.previous = this.voidLink;
this.voidLink.next = this.voidLink;
});
Clazz.makeConstructor (c$, 
function (a) {
this.construct ();
this.addAll (a);
}, "java.util.Collection");
Clazz.defineMethod (c$, "add", 
function (a, b) {
if (0 <= a && a <= this.$size) {
var c = this.voidLink;
if (a < (Clazz.doubleToInt (this.$size / 2))) {
for (var d = 0; d <= a; d++) {
c = c.next;
}
} else {
for (var d = this.$size; d > a; d--) {
c = c.previous;
}
}var d = c.previous;
var e =  new java.util.LinkedList.Link (b, d, c);
d.next = e;
c.previous = e;
this.$size++;
this.modCount++;
} else {
throw  new IndexOutOfBoundsException ();
}}, "~N,~O");
Clazz.defineMethod (c$, "add", 
function (a) {
var b = this.voidLink.previous;
var c =  new java.util.LinkedList.Link (a, b, this.voidLink);
this.voidLink.previous = c;
b.next = c;
this.$size++;
this.modCount++;
return true;
}, "~O");
Clazz.defineMethod (c$, "addAll", 
function (a, b) {
if (a < 0 || a > this.$size) {
throw  new IndexOutOfBoundsException ();
}var c = b.size ();
if (c == 0) {
return false;
}var d = this.voidLink;
if (a < (Clazz.doubleToInt (this.$size / 2))) {
for (var e = 0; e < a; e++) {
d = d.next;
}
} else {
for (var e = this.$size; e >= a; e--) {
d = d.previous;
}
}var e = d.next;
for (var e, $e = b.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var f =  new java.util.LinkedList.Link (e, d, null);
d.next = f;
d = f;
}
d.next = e;
e.previous = d;
this.$size += c;
this.modCount++;
return true;
}, "~N,java.util.Collection");
Clazz.defineMethod (c$, "addAll", 
function (a) {
var b = a.size ();
if (b == 0) {
return false;
}var c = this.voidLink.previous;
for (var e, $e = a.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var d =  new java.util.LinkedList.Link (e, c, null);
c.next = d;
c = d;
}
c.next = this.voidLink;
this.voidLink.previous = c;
this.$size += b;
this.modCount++;
return true;
}, "java.util.Collection");
Clazz.defineMethod (c$, "addFirst", 
function (a) {
var b = this.voidLink.next;
var c =  new java.util.LinkedList.Link (a, this.voidLink, b);
this.voidLink.next = c;
b.previous = c;
this.$size++;
this.modCount++;
}, "~O");
Clazz.defineMethod (c$, "addLast", 
function (a) {
var b = this.voidLink.previous;
var c =  new java.util.LinkedList.Link (a, b, this.voidLink);
this.voidLink.previous = c;
b.next = c;
this.$size++;
this.modCount++;
}, "~O");
Clazz.overrideMethod (c$, "clear", 
function () {
if (this.$size > 0) {
this.$size = 0;
this.voidLink.next = this.voidLink;
this.voidLink.previous = this.voidLink;
this.modCount++;
}});
Clazz.overrideMethod (c$, "clone", 
function () {
return  new java.util.LinkedList (this);
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
var b = this.voidLink.next;
if (a != null) {
while (b !== this.voidLink) {
if (a.equals (b.data)) {
return true;
}b = b.next;
}
} else {
while (b !== this.voidLink) {
if (b.data == null) {
return true;
}b = b.next;
}
}return false;
}, "~O");
Clazz.overrideMethod (c$, "get", 
function (a) {
if (0 <= a && a < this.$size) {
var b = this.voidLink;
if (a < (Clazz.doubleToInt (this.$size / 2))) {
for (var c = 0; c <= a; c++) {
b = b.next;
}
} else {
for (var c = this.$size; c > a; c--) {
b = b.previous;
}
}return b.data;
}throw  new IndexOutOfBoundsException ();
}, "~N");
Clazz.defineMethod (c$, "getFirst", 
function () {
var a = this.voidLink.next;
if (a !== this.voidLink) {
return a.data;
}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "getLast", 
function () {
var a = this.voidLink.previous;
if (a !== this.voidLink) {
return a.data;
}throw  new java.util.NoSuchElementException ();
});
Clazz.overrideMethod (c$, "indexOf", 
function (a) {
var b = 0;
var c = this.voidLink.next;
if (a != null) {
while (c !== this.voidLink) {
if (a.equals (c.data)) {
return b;
}c = c.next;
b++;
}
} else {
while (c !== this.voidLink) {
if (c.data == null) {
return b;
}c = c.next;
b++;
}
}return -1;
}, "~O");
Clazz.overrideMethod (c$, "lastIndexOf", 
function (a) {
var b = this.$size;
var c = this.voidLink.previous;
if (a != null) {
while (c !== this.voidLink) {
b--;
if (a.equals (c.data)) {
return b;
}c = c.previous;
}
} else {
while (c !== this.voidLink) {
b--;
if (c.data == null) {
return b;
}c = c.previous;
}
}return -1;
}, "~O");
Clazz.defineMethod (c$, "listIterator", 
function (a) {
return  new java.util.LinkedList.LinkIterator (this, a);
}, "~N");
Clazz.defineMethod (c$, "remove", 
function (a) {
if (0 <= a && a < this.$size) {
var b = this.voidLink;
if (a < (Clazz.doubleToInt (this.$size / 2))) {
for (var c = 0; c <= a; c++) {
b = b.next;
}
} else {
for (var c = this.$size; c > a; c--) {
b = b.previous;
}
}var c = b.previous;
var d = b.next;
c.next = d;
d.previous = c;
this.$size--;
this.modCount++;
return b.data;
}throw  new IndexOutOfBoundsException ();
}, "~N");
Clazz.defineMethod (c$, "remove", 
function (a) {
var b = this.voidLink.next;
if (a != null) {
while (b !== this.voidLink && !a.equals (b.data)) {
b = b.next;
}
} else {
while (b !== this.voidLink && b.data != null) {
b = b.next;
}
}if (b === this.voidLink) {
return false;
}var c = b.next;
var d = b.previous;
d.next = c;
c.previous = d;
this.$size--;
this.modCount++;
return true;
}, "~O");
Clazz.defineMethod (c$, "removeFirst", 
function () {
var a = this.voidLink.next;
if (a !== this.voidLink) {
var b = a.next;
this.voidLink.next = b;
b.previous = this.voidLink;
this.$size--;
this.modCount++;
return a.data;
}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "removeLast", 
function () {
var a = this.voidLink.previous;
if (a !== this.voidLink) {
var b = a.previous;
this.voidLink.previous = b;
b.next = this.voidLink;
this.$size--;
this.modCount++;
return a.data;
}throw  new java.util.NoSuchElementException ();
});
Clazz.overrideMethod (c$, "set", 
function (a, b) {
if (0 <= a && a < this.$size) {
var c = this.voidLink;
if (a < (Clazz.doubleToInt (this.$size / 2))) {
for (var d = 0; d <= a; d++) {
c = c.next;
}
} else {
for (var d = this.$size; d > a; d--) {
c = c.previous;
}
}var d = c.data;
c.data = b;
return d;
}throw  new IndexOutOfBoundsException ();
}, "~N,~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.$size;
});
Clazz.overrideMethod (c$, "offer", 
function (a) {
this.add (a);
return true;
}, "~O");
Clazz.overrideMethod (c$, "poll", 
function () {
return this.$size == 0 ? null : this.removeFirst ();
});
Clazz.defineMethod (c$, "remove", 
function () {
return this.removeFirst ();
});
Clazz.overrideMethod (c$, "peek", 
function () {
var a = this.voidLink.next;
return a === this.voidLink ? null : a.data;
});
Clazz.overrideMethod (c$, "element", 
function () {
return this.getFirst ();
});
Clazz.defineMethod (c$, "toArray", 
function () {
var a = 0;
var b =  new Array (this.$size);
var c = this.voidLink.next;
while (c !== this.voidLink) {
b[a++] = c.data;
c = c.next;
}
return b;
});
Clazz.defineMethod (c$, "toArray", 
function (a) {
var b = 0;
if (this.$size > a.length) {
var c = a.getClass ().getComponentType ();
a = java.lang.reflect.Array.newInstance (c, this.$size);
}var c = this.voidLink.next;
while (c !== this.voidLink) {
a[b++] = c.data;
c = c.next;
}
if (b < a.length) {
a[b] = null;
}return a;
}, "~A");
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.data = null;
this.previous = null;
this.next = null;
Clazz.instantialize (this, arguments);
}, java.util.LinkedList, "Link");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.data = a;
this.previous = b;
this.next = c;
}, "~O,java.util.LinkedList.Link,java.util.LinkedList.Link");
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.pos = 0;
this.expectedModCount = 0;
this.list = null;
this.link = null;
this.lastLink = null;
Clazz.instantialize (this, arguments);
}, java.util.LinkedList, "LinkIterator", null, java.util.ListIterator);
Clazz.makeConstructor (c$, 
function (a, b) {
this.list = a;
this.expectedModCount = this.list.modCount;
if (0 <= b && b <= this.list.$size) {
this.link = this.list.voidLink;
if (b < Clazz.doubleToInt (this.list.$size / 2)) {
for (this.pos = -1; this.pos + 1 < b; this.pos++) {
this.link = this.link.next;
}
} else {
for (this.pos = this.list.$size; this.pos >= b; this.pos--) {
this.link = this.link.previous;
}
}} else {
throw  new IndexOutOfBoundsException ();
}}, "java.util.LinkedList,~N");
Clazz.overrideMethod (c$, "add", 
function (a) {
if (this.expectedModCount == this.list.modCount) {
var b = this.link.next;
var c =  new java.util.LinkedList.Link (a, this.link, b);
this.link.next = c;
b.previous = c;
this.link = c;
this.lastLink = null;
this.pos++;
this.expectedModCount++;
this.list.$size++;
this.list.modCount++;
} else {
throw  new java.util.ConcurrentModificationException ();
}}, "~O");
Clazz.overrideMethod (c$, "hasNext", 
function () {
return this.link.next !== this.list.voidLink;
});
Clazz.overrideMethod (c$, "hasPrevious", 
function () {
return this.link !== this.list.voidLink;
});
Clazz.overrideMethod (c$, "next", 
function () {
if (this.expectedModCount == this.list.modCount) {
var a = this.link.next;
if (a !== this.list.voidLink) {
this.lastLink = this.link = a;
this.pos++;
return this.link.data;
}throw  new java.util.NoSuchElementException ();
}throw  new java.util.ConcurrentModificationException ();
});
Clazz.overrideMethod (c$, "nextIndex", 
function () {
return this.pos + 1;
});
Clazz.overrideMethod (c$, "previous", 
function () {
if (this.expectedModCount == this.list.modCount) {
if (this.link !== this.list.voidLink) {
this.lastLink = this.link;
this.link = this.link.previous;
this.pos--;
return this.lastLink.data;
}throw  new java.util.NoSuchElementException ();
}throw  new java.util.ConcurrentModificationException ();
});
Clazz.overrideMethod (c$, "previousIndex", 
function () {
return this.pos;
});
Clazz.overrideMethod (c$, "remove", 
function () {
if (this.expectedModCount == this.list.modCount) {
if (this.lastLink != null) {
var a = this.lastLink.next;
var b = this.lastLink.previous;
a.previous = b;
b.next = a;
if (this.lastLink === this.link) {
this.pos--;
}this.link = b;
this.lastLink = null;
this.expectedModCount++;
this.list.$size--;
this.list.modCount++;
} else {
throw  new IllegalStateException ();
}} else {
throw  new java.util.ConcurrentModificationException ();
}});
Clazz.overrideMethod (c$, "set", 
function (a) {
if (this.expectedModCount == this.list.modCount) {
if (this.lastLink != null) {
this.lastLink.data = a;
} else {
throw  new IllegalStateException ();
}} else {
throw  new java.util.ConcurrentModificationException ();
}}, "~O");
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023