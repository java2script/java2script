Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.util.zip.ZipConstants"], "java.util.zip.ZipEntry", ["java.lang.IllegalArgumentException", "$.InternalError", "$.NullPointerException", "java.util.Date"], function () {
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.name = null;
this.time = -1;
this.crc = -1;
this.size = -1;
this.csize = -1;
this.method = -1;
this.flag = 0;
this.extra = null;
this.comment = null;
Clazz.instantialize (this, arguments);
}, java.util.zip, "ZipEntry", null, [java.util.zip.ZipConstants, Cloneable]);
Clazz.makeConstructor (c$, 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}if (a.length > 0xFFFF) {
throw  new IllegalArgumentException ("entry name too long");
}this.name = a;
}, "~S");
Clazz.defineMethod (c$, "getName", 
function () {
return this.name;
});
Clazz.defineMethod (c$, "setTime", 
function (a) {
this.time = java.util.zip.ZipEntry.javaToDosTime (a);
}, "~N");
Clazz.defineMethod (c$, "getTime", 
function () {
return this.time != -1 ? java.util.zip.ZipEntry.dosToJavaTime (this.time) : -1;
});
Clazz.defineMethod (c$, "setSize", 
function (a) {
if (a < 0) {
throw  new IllegalArgumentException ("invalid entry size");
}this.size = a;
}, "~N");
Clazz.defineMethod (c$, "getSize", 
function () {
return this.size;
});
Clazz.defineMethod (c$, "getCompressedSize", 
function () {
return this.csize;
});
Clazz.defineMethod (c$, "setCompressedSize", 
function (a) {
this.csize = a;
}, "~N");
Clazz.defineMethod (c$, "setCrc", 
function (a) {
if (a < 0 || a > 0xFFFFFFFF) {
throw  new IllegalArgumentException ("invalid entry crc-32");
}this.crc = a;
}, "~N");
Clazz.defineMethod (c$, "getCrc", 
function () {
return this.crc;
});
Clazz.defineMethod (c$, "setMethod", 
function (a) {
if (a != 0 && a != 8) {
throw  new IllegalArgumentException ("invalid compression method");
}this.method = a;
}, "~N");
Clazz.defineMethod (c$, "getMethod", 
function () {
return this.method;
});
Clazz.defineMethod (c$, "setExtra", 
function (a) {
if (a != null && a.length > 0xFFFF) {
throw  new IllegalArgumentException ("invalid extra field length");
}this.extra = a;
}, "~A");
Clazz.defineMethod (c$, "getExtra", 
function () {
return this.extra;
});
Clazz.defineMethod (c$, "setComment", 
function (a) {
this.comment = a;
}, "~S");
Clazz.defineMethod (c$, "getComment", 
function () {
return this.comment;
});
Clazz.defineMethod (c$, "isDirectory", 
function () {
return this.name.endsWith ("/");
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.getName ();
});
c$.dosToJavaTime = Clazz.defineMethod (c$, "dosToJavaTime", 
function (a) {
var b =  new java.util.Date ((((a >> 25) & 0x7f) + 80), (((a >> 21) & 0x0f) - 1), ((a >> 16) & 0x1f), ((a >> 11) & 0x1f), ((a >> 5) & 0x3f), ((a << 1) & 0x3e));
return b.getTime ();
}, "~N");
c$.javaToDosTime = Clazz.defineMethod (c$, "javaToDosTime", 
function (a) {
var b =  new java.util.Date (a);
var c = b.getYear () + 1900;
if (c < 1980) {
return 2162688;
}return (c - 1980) << 25 | (b.getMonth () + 1) << 21 | b.getDate () << 16 | b.getHours () << 11 | b.getMinutes () << 5 | b.getSeconds () >> 1;
}, "~N");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.name.hashCode ();
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.zip.ZipEntry, "clone", []);
if (this.extra != null) {
a.extra =  Clazz.newByteArray (this.extra.length, 0);
System.arraycopy (this.extra, 0, a.extra, 0, this.extra.length);
}return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
throw  new InternalError ();
} else {
throw e;
}
}
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023