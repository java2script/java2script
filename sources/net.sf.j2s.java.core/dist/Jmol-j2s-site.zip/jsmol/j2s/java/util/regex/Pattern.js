Clazz.declarePackage ("java.util.regex");
Clazz.load (null, "java.util.regex.Pattern", ["java.lang.IllegalArgumentException", "$.StringBuffer", "java.util.regex.Matcher"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$flags = 0;
this.regexp = null;
Clazz.instantialize (this, arguments);
}, java.util.regex, "Pattern", null, java.io.Serializable);
Clazz.defineMethod (c$, "matcher", 
function (a) {
return  new java.util.regex.Matcher (this, a);
}, "CharSequence");
Clazz.defineMethod (c$, "split", 
function (a, b) {
var c =  new Array (0);
var d = this.matcher (a);
var e = 0;
var f = 0;
if (a.length == 0) {
return  Clazz.newArray (-1, [""]);
} else {
while (d.find () && (e + 1 < b || b <= 0)) {
c[c.length] = a.subSequence (f, d.start ()).toString ();
f = d.end ();
e++;
}
c[c.length] = a.subSequence (f, a.length).toString ();
e++;
if (b == 0) {
while (--e >= 0 && c[e].toString ().length == 0) {
res.length--;
}
}}return c;
}, "CharSequence,~N");
Clazz.defineMethod (c$, "split", 
function (a) {
return this.split (a, 0);
}, "CharSequence");
Clazz.defineMethod (c$, "pattern", 
function () {
{
return this.regexp.source;
}return null;
});
Clazz.defineMethod (c$, "toString", 
function () {
return this.pattern ();
});
Clazz.defineMethod (c$, "flags", 
function () {
return this.$flags;
});
c$.compile = Clazz.defineMethod (c$, "compile", 
function (a, b) {
if ((b != 0) && ((b | 239) != 239)) {
throw  new IllegalArgumentException ("Illegal flags");
}var c = "g";
if ((b & 8) != 0) {
c += "m";
}if ((b & 2) != 0) {
c += "i";
}var d =  new java.util.regex.Pattern ();
{
pattern.regexp = new RegExp(regex, flagStr);
}return d;
}, "~S,~N");
c$.compile = Clazz.defineMethod (c$, "compile", 
function (a) {
return java.util.regex.Pattern.compile (a, 0);
}, "~S");
c$.matches = Clazz.defineMethod (c$, "matches", 
function (a, b) {
return java.util.regex.Pattern.compile (a).matcher (b).matches ();
}, "~S,CharSequence");
c$.quote = Clazz.defineMethod (c$, "quote", 
function (a) {
var b =  new StringBuffer ().append ("\\Q");
var c = 0;
var d;
while ((d = a.indexOf ("\\E", c)) >= 0) {
b.append (a.substring (c, d + 2)).append ("\\\\E\\Q");
c = d + 2;
}
return b.append (a.substring (c)).append ("\\E").toString ();
}, "~S");
Clazz.makeConstructor (c$, 
function () {
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023