Clazz.load (["java.util.IllegalFormatException"], "java.util.UnknownFormatConversionException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.s = null;
Clazz.instantialize (this, arguments);
}, java.util, "UnknownFormatConversionException", java.util.IllegalFormatException);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.UnknownFormatConversionException, []);
this.s = a;
}, "~S");
Clazz.defineMethod (c$, "getConversion", 
function () {
return this.s;
});
Clazz.overrideMethod (c$, "getMessage", 
function () {
return "Conversion = '" + this.s + "'";
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023