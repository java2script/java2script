Clazz.load (["java.util.AbstractList", "$.RandomAccess"], "java.util.Arrays", ["java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.NullPointerException"], function () {
c$ = Clazz.declareType (java.util, "Arrays");
c$.sort = Clazz.defineMethod (c$, "sort", 
function (a) {
var aux = a.sort (function (o1, o2) {
if (typeof o1 == "string" || o1 instanceof Comparable){
return o1.compareTo (o2);
}
return o1 - o2;
});
for (var i = 0; i < a.length; i++) {
a[i] = aux[i];
}
}, "~A");
c$.sort = Clazz.defineMethod (c$, "sort", 
function (b, c, d) {
this.rangeCheck(a.length, fromIndex, toIndex);
var aux = new Array ();
for (var i = fromIndex; i < toIndex; i++) {
aux[i - fromIndex] = a[i];
}
aux = aux.sort (function (o1, o2) {
if (typeof o1 == "string" || o1 instanceof Comparable){
return o1.compareTo (o2);
}
return o1 - o2;
});
for (var i = fromIndex; i < toIndex; i++) {
a[i] = aux[i - fromIndex];
}
}, "~A,~N,~N");
c$.sort = Clazz.defineMethod (c$, "sort", 
function (e, f) {
var aux = a.sort (function (o1, o2) {
if (c != null) {
return c.compare (o1, o2);
} else if (typeof o1 == "string" || o1 instanceof Comparable){
return o1.compareTo (o2);
}
return o1 - o2;
});
for (var i = 0; i < a.length; i++) {
a[i] = aux[i];
}
}, "~A,java.util.Comparator");
c$.sort = Clazz.defineMethod (c$, "sort", 
function (g, h, i, j) {
this.rangeCheck(a.length, fromIndex, toIndex);
var aux = new Array ();
for (var i = fromIndex; i < toIndex; i++) {
aux[i - fromIndex] = a[i];
}
aux = aux.sort (function (o1, o2) {
if (c != null) {
return c.compare (o1, o2);
} else if (typeof o1 == "string" || o1 instanceof Comparable){
return o1.compareTo (o2);
}
return o1 - o2;
});
for (var i = fromIndex; i < toIndex; i++) {
a[i] = aux[i - fromIndex];
}
}, "~A,~N,~N,java.util.Comparator");
c$.rangeCheck = Clazz.defineMethod (c$, "rangeCheck", 
function (k, l, m) {
if (l > m) throw  new IllegalArgumentException ("fromIndex(" + l + ") > toIndex(" + m + ")");
if (l < 0) throw  new ArrayIndexOutOfBoundsException (l);
if (m > k) throw  new ArrayIndexOutOfBoundsException (m);
}, "~N,~N,~N");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
function (a, b) {
var c = 0;
var d = a.length - 1;
while (c <= d) {
var e = (c + d) >> 1;
var f = a[e];
if (f < b) c = e + 1;
 else if (f > b) d = e - 1;
 else return e;
}
return -(c + 1);
}, "~A,~N");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
function (a, b) {
var c = 0;
var d = a.length - 1;
while (c <= d) {
var e = (c + d) >> 1;
var f = a[e];
var g = (f).compareTo (b);
if (g < 0) c = e + 1;
 else if (g > 0) d = e - 1;
 else return e;
}
return -(c + 1);
}, "~A,~O");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
function (a, b, c) {
if (c == null) return java.util.Arrays.binarySearch (a, b);
var d = 0;
var e = a.length - 1;
while (d <= e) {
var f = (d + e) >> 1;
var g = a[f];
var h = c.compare (g, b);
if (h < 0) d = f + 1;
 else if (h > 0) e = f - 1;
 else return f;
}
return -(d + 1);
}, "~A,~O,java.util.Comparator");
c$.equals = Clazz.defineMethod (c$, "equals", 
function (a, b) {
if (a === b) return true;
if (a == null || b == null) return false;
var c = a.length;
if (b.length != c) return false;
for (var d = 0; d < c; d++) {
var e = a[d];
var f = b[d];
{
if(!(o1==null?o2==null:(o1.equals==null?o1==o2:o1.equals(o2))))return false;
}}
return true;
}, "~A,~A");
c$.fill = Clazz.defineMethod (c$, "fill", 
function (a, b) {
java.util.Arrays.fill (a, 0, a.length, b);
}, "~A,~O");
c$.fill = Clazz.defineMethod (c$, "fill", 
function (a, b, c, d) {
java.util.Arrays.rangeCheck (a.length, b, c);
for (var e = b; e < c; e++) a[e] = d;

}, "~A,~N,~N,~O");
c$.asList = Clazz.defineMethod (c$, "asList", 
function (a) {
return  new java.util.Arrays.ArrayList (a);
}, "~A");
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.a = null;
Clazz.instantialize (this, arguments);
}, java.util.Arrays, "ArrayList", java.util.AbstractList, [java.util.RandomAccess, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.Arrays.ArrayList, []);
if (a == null) throw  new NullPointerException ();
this.a = a;
}, "~A");
Clazz.overrideMethod (c$, "size", 
function () {
return this.a.length;
});
Clazz.defineMethod (c$, "toArray", 
function () {
return this.a.clone ();
});
Clazz.overrideMethod (c$, "get", 
function (a) {
return this.a[a];
}, "~N");
Clazz.overrideMethod (c$, "set", 
function (a, b) {
var c = this.a[a];
this.a[a] = b;
return c;
}, "~N,~O");
Clazz.overrideMethod (c$, "indexOf", 
function (a) {
if (a == null) {
for (var b = 0; b < this.a.length; b++) if (this.a[b] == null) return b;

} else {
for (var b = 0; b < this.a.length; b++) if (a.equals (this.a[b])) return b;

}return -1;
}, "~O");
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.indexOf (a) != -1;
}, "~O");
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023