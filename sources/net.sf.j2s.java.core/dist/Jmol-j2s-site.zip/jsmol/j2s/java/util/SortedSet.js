Clazz.load (["java.util.Set"], "java.util.SortedSet", null, function () {
Clazz.declareInterface (java.util, "SortedSet", java.util.Set);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023