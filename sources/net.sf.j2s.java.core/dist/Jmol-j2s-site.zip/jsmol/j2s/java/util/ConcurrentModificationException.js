Clazz.load (["java.lang.RuntimeException"], "java.util.ConcurrentModificationException", null, function () {
var c$ = Clazz.declareType (java.util, "ConcurrentModificationException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.ConcurrentModificationException, []);
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
