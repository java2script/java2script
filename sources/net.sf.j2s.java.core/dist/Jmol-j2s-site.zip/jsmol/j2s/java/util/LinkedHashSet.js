Clazz.load (["java.util.HashSet", "$.Set"], "java.util.LinkedHashSet", ["java.util.LinkedHashMap"], function () {
c$ = Clazz.declareType (java.util, "LinkedHashSet", java.util.HashSet, [java.util.Set, Cloneable, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.LinkedHashSet, [ new java.util.LinkedHashMap ()]);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.LinkedHashSet, [ new java.util.LinkedHashMap (a)]);
}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.LinkedHashSet, [ new java.util.LinkedHashMap (a, b)]);
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.LinkedHashSet, [ new java.util.LinkedHashMap (a.size () < 6 ? 11 : a.size () * 2)]);
for (var e, $e = a.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
this.add (e);
}
}, "java.util.Collection");
Clazz.overrideMethod (c$, "createBackingMap", 
function (a, b) {
return  new java.util.LinkedHashMap (a, b);
}, "~N,~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023