Clazz.load (["java.util.AbstractCollection", "$.AbstractMap", "$.AbstractSet", "$.Iterator", "$.MapEntry", "$.Set", "$.SortedMap"], "java.util.TreeMap", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "java.util.ConcurrentModificationException", "java.util.Map.Entry", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$size = 0;
this.root = null;
this.$comparator = null;
this.modCount = 0;
this.$entrySet = null;
Clazz.instantialize (this, arguments);
}, java.util, "TreeMap", java.util.AbstractMap, [java.util.SortedMap, Cloneable, java.io.Serializable]);
c$.toComparable = Clazz.defineMethod (c$, "toComparable", 
function (a) {
return a;
}, "~O");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap, []);
this.$comparator = a;
}, "java.util.Comparator");
Clazz.makeConstructor (c$, 
function (a) {
this.construct ();
this.putAll (a);
}, "java.util.Map");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.comparator ());
var b = a.entrySet ().iterator ();
if (b.hasNext ()) {
var c = b.next ();
var d =  new java.util.TreeMap.Entry (c.getKey (), c.getValue ());
this.root = d;
this.$size = 1;
while (b.hasNext ()) {
c = b.next ();
var e =  new java.util.TreeMap.Entry (c.getKey (), c.getValue ());
e.parent = d;
d.right = e;
this.$size++;
this.balance (e);
d = e;
}
}}, "java.util.SortedMap");
Clazz.defineMethod (c$, "balance", 
function (a) {
var b;
a.color = true;
while (a !== this.root && a.parent.color) {
if (a.parent === a.parent.parent.left) {
b = a.parent.parent.right;
if (b != null && b.color) {
a.parent.color = false;
b.color = false;
a.parent.parent.color = true;
a = a.parent.parent;
} else {
if (a === a.parent.right) {
a = a.parent;
this.leftRotate (a);
}a.parent.color = false;
a.parent.parent.color = true;
this.rightRotate (a.parent.parent);
}} else {
b = a.parent.parent.left;
if (b != null && b.color) {
a.parent.color = false;
b.color = false;
a.parent.parent.color = true;
a = a.parent.parent;
} else {
if (a === a.parent.left) {
a = a.parent;
this.rightRotate (a);
}a.parent.color = false;
a.parent.parent.color = true;
this.leftRotate (a.parent.parent);
}}}
this.root.color = false;
}, "java.util.TreeMap.Entry");
Clazz.overrideMethod (c$, "clear", 
function () {
this.root = null;
this.$size = 0;
this.modCount++;
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.TreeMap, "clone", []);
a.$entrySet = null;
if (this.root != null) {
a.root = this.root.clone (null);
}return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "comparator", 
function () {
return this.$comparator;
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
return this.find (a) != null;
}, "~O");
Clazz.defineMethod (c$, "containsValue", 
function (a) {
if (this.root != null) {
return this.containsValue (this.root, a);
}return false;
}, "~O");
Clazz.defineMethod (c$, "containsValue", 
function (a, b) {
if (b == null ? a.value == null : b.equals (a.value)) {
return true;
}if (a.left != null) {
if (this.containsValue (a.left, b)) {
return true;
}}if (a.right != null) {
if (this.containsValue (a.right, b)) {
return true;
}}return false;
}, "java.util.TreeMap.Entry,~O");
Clazz.overrideMethod (c$, "entrySet", 
function () {
if (this.$entrySet == null) {
this.$entrySet = ((Clazz.isClassDefined ("java.util.TreeMap$1") ? 0 : java.util.TreeMap.$TreeMap$1$ ()), Clazz.innerTypeInstance (java.util.TreeMap$1, this, null));
}return this.$entrySet;
});
Clazz.defineMethod (c$, "find", 
function (a) {
var b;
var c = a;
var d = null;
if (this.$comparator == null) {
d = java.util.TreeMap.toComparable (c);
}var e = this.root;
while (e != null) {
b = d != null ? d.compareTo (e.key) : this.$comparator.compare (c, e.key);
if (b == 0) {
return e;
}e = b < 0 ? e.left : e.right;
}
return null;
}, "~O");
Clazz.defineMethod (c$, "findAfter", 
function (a) {
var b = a;
var c;
var d = null;
if (this.$comparator == null) {
d = java.util.TreeMap.toComparable (b);
}var e = this.root;
var f = null;
while (e != null) {
c = d != null ? d.compareTo (e.key) : this.$comparator.compare (b, e.key);
if (c == 0) {
return e;
}if (c < 0) {
f = e;
e = e.left;
} else {
e = e.right;
}}
return f;
}, "~O");
Clazz.defineMethod (c$, "findBefore", 
function (a) {
var b;
var c = null;
if (this.$comparator == null) {
c = java.util.TreeMap.toComparable (a);
}var d = this.root;
var e = null;
while (d != null) {
b = c != null ? c.compareTo (d.key) : this.$comparator.compare (a, d.key);
if (b <= 0) {
d = d.left;
} else {
e = d;
d = d.right;
}}
return e;
}, "~O");
Clazz.overrideMethod (c$, "firstKey", 
function () {
if (this.root != null) {
return java.util.TreeMap.minimum (this.root).key;
}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "fixup", 
function (a) {
var b;
while (a !== this.root && !a.color) {
if (a === a.parent.left) {
b = a.parent.right;
if (b == null) {
a = a.parent;
continue;
}if (b.color) {
b.color = false;
a.parent.color = true;
this.leftRotate (a.parent);
b = a.parent.right;
if (b == null) {
a = a.parent;
continue;
}}if ((b.left == null || !b.left.color) && (b.right == null || !b.right.color)) {
b.color = true;
a = a.parent;
} else {
if (b.right == null || !b.right.color) {
b.left.color = false;
b.color = true;
this.rightRotate (b);
b = a.parent.right;
}b.color = a.parent.color;
a.parent.color = false;
b.right.color = false;
this.leftRotate (a.parent);
a = this.root;
}} else {
b = a.parent.left;
if (b == null) {
a = a.parent;
continue;
}if (b.color) {
b.color = false;
a.parent.color = true;
this.rightRotate (a.parent);
b = a.parent.left;
if (b == null) {
a = a.parent;
continue;
}}if ((b.left == null || !b.left.color) && (b.right == null || !b.right.color)) {
b.color = true;
a = a.parent;
} else {
if (b.left == null || !b.left.color) {
b.right.color = false;
b.color = true;
this.leftRotate (b);
b = a.parent.left;
}b.color = a.parent.color;
a.parent.color = false;
b.left.color = false;
this.rightRotate (a.parent);
a = this.root;
}}}
a.color = false;
}, "java.util.TreeMap.Entry");
Clazz.overrideMethod (c$, "get", 
function (a) {
var b = this.find (a);
if (b != null) {
return b.value;
}return null;
}, "~O");
Clazz.overrideMethod (c$, "headMap", 
function (a) {
if (this.$comparator == null) {
java.util.TreeMap.toComparable (a).compareTo (a);
} else {
this.$comparator.compare (a, a);
}return  new java.util.TreeMap.SubMap (this, a);
}, "~O");
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet = ((Clazz.isClassDefined ("java.util.TreeMap$2") ? 0 : java.util.TreeMap.$TreeMap$2$ ()), Clazz.innerTypeInstance (java.util.TreeMap$2, this, null));
}return this.$keySet;
});
Clazz.overrideMethod (c$, "lastKey", 
function () {
if (this.root != null) {
return java.util.TreeMap.maximum (this.root).key;
}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "leftRotate", 
function (a) {
var b = a.right;
a.right = b.left;
if (b.left != null) {
b.left.parent = a;
}b.parent = a.parent;
if (a.parent == null) {
this.root = b;
} else {
if (a === a.parent.left) {
a.parent.left = b;
} else {
a.parent.right = b;
}}b.left = a;
a.parent = b;
}, "java.util.TreeMap.Entry");
c$.maximum = Clazz.defineMethod (c$, "maximum", 
function (a) {
while (a.right != null) {
a = a.right;
}
return a;
}, "java.util.TreeMap.Entry");
c$.minimum = Clazz.defineMethod (c$, "minimum", 
function (a) {
while (a.left != null) {
a = a.left;
}
return a;
}, "java.util.TreeMap.Entry");
c$.predecessor = Clazz.defineMethod (c$, "predecessor", 
function (a) {
if (a.left != null) {
return java.util.TreeMap.maximum (a.left);
}var b = a.parent;
while (b != null && a === b.left) {
a = b;
b = b.parent;
}
return b;
}, "java.util.TreeMap.Entry");
Clazz.overrideMethod (c$, "put", 
function (a, b) {
var c = this.rbInsert (a);
var d = c.value;
c.value = b;
return d;
}, "~O,~O");
Clazz.defineMethod (c$, "rbDelete", 
function (a) {
var b = a.left == null || a.right == null ? a : java.util.TreeMap.successor (a);
var c = b.left != null ? b.left : b.right;
if (c != null) {
c.parent = b.parent;
}if (b.parent == null) {
this.root = c;
} else if (b === b.parent.left) {
b.parent.left = c;
} else {
b.parent.right = c;
}this.modCount++;
if (b !== a) {
a.key = b.key;
a.value = b.value;
}if (!b.color && this.root != null) {
if (c == null) {
this.fixup (b.parent);
} else {
this.fixup (c);
}}this.$size--;
}, "java.util.TreeMap.Entry");
Clazz.defineMethod (c$, "rbInsert", 
function (a) {
var b = 0;
var c = null;
if (this.$size != 0) {
var d = null;
if (this.$comparator == null) {
d = java.util.TreeMap.toComparable (a);
}var e = this.root;
while (e != null) {
c = e;
b = d != null ? d.compareTo (e.key) : this.$comparator.compare (a, e.key);
if (b == 0) {
return e;
}e = b < 0 ? e.left : e.right;
}
}this.$size++;
this.modCount++;
var d =  new java.util.TreeMap.Entry (a);
if (c == null) {
return this.root = d;
}d.parent = c;
if (b < 0) {
c.left = d;
} else {
c.right = d;
}this.balance (d);
return d;
}, "~O");
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = this.find (a);
if (b == null) {
return null;
}var c = b.value;
this.rbDelete (b);
return c;
}, "~O");
Clazz.defineMethod (c$, "rightRotate", 
function (a) {
var b = a.left;
a.left = b.right;
if (b.right != null) {
b.right.parent = a;
}b.parent = a.parent;
if (a.parent == null) {
this.root = b;
} else {
if (a === a.parent.right) {
a.parent.right = b;
} else {
a.parent.left = b;
}}b.right = a;
a.parent = b;
}, "java.util.TreeMap.Entry");
Clazz.overrideMethod (c$, "size", 
function () {
return this.$size;
});
Clazz.overrideMethod (c$, "subMap", 
function (a, b) {
if (this.$comparator == null) {
if (java.util.TreeMap.toComparable (a).compareTo (b) <= 0) {
return  new java.util.TreeMap.SubMap (a, this, b);
}} else {
if (this.$comparator.compare (a, b) <= 0) {
return  new java.util.TreeMap.SubMap (a, this, b);
}}throw  new IllegalArgumentException ();
}, "~O,~O");
c$.successor = Clazz.defineMethod (c$, "successor", 
function (a) {
if (a.right != null) {
return java.util.TreeMap.minimum (a.right);
}var b = a.parent;
while (b != null && a === b.right) {
a = b;
b = b.parent;
}
return b;
}, "java.util.TreeMap.Entry");
Clazz.overrideMethod (c$, "tailMap", 
function (a) {
if (this.$comparator == null) {
java.util.TreeMap.toComparable (a).compareTo (a);
} else {
this.$comparator.compare (a, a);
}return  new java.util.TreeMap.SubMap (a, this);
}, "~O");
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection = ((Clazz.isClassDefined ("java.util.TreeMap$3") ? 0 : java.util.TreeMap.$TreeMap$3$ ()), Clazz.innerTypeInstance (java.util.TreeMap$3, this, null));
}return this.valuesCollection;
});
c$.$TreeMap$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "TreeMap$1", java.util.AbstractSet);
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.TreeMap"].$size;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.TreeMap"].clear ();
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = a;
var c = this.b$["java.util.TreeMap"].get (b.getKey ());
var d = b.getValue ();
return c == null ? d == null : c.equals (d);
}return false;
}, "~O");
Clazz.defineMethod (c$, "iterator", 
function () {
return  new java.util.TreeMap.UnboundedEntryIterator (this.b$["java.util.TreeMap"]);
});
c$ = Clazz.p0p ();
};
c$.$TreeMap$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "TreeMap$2", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.TreeMap"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.TreeMap"].$size;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.TreeMap"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.TreeMap.UnboundedKeyIterator (this.b$["java.util.TreeMap"]);
});
c$ = Clazz.p0p ();
};
c$.$TreeMap$3$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "TreeMap$3", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.TreeMap"].containsValue (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.TreeMap"].$size;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.TreeMap"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return  new java.util.TreeMap.UnboundedValueIterator (this.b$["java.util.TreeMap"]);
});
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.parent = null;
this.left = null;
this.right = null;
this.color = false;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "Entry", java.util.MapEntry);
Clazz.defineMethod (c$, "clone", 
function (a) {
var b = Clazz.superCall (this, java.util.TreeMap.Entry, "clone", []);
b.parent = a;
if (this.left != null) {
b.left = this.left.clone (b);
}if (this.right != null) {
b.right = this.right.clone (b);
}return b;
}, "java.util.TreeMap.Entry");
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.backingMap = null;
this.expectedModCount = 0;
this.node = null;
this.lastNode = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "AbstractMapIterator");
Clazz.makeConstructor (c$, 
function (a, b) {
this.backingMap = a;
this.expectedModCount = a.modCount;
this.node = b;
}, "java.util.TreeMap,java.util.TreeMap.Entry");
Clazz.defineMethod (c$, "hasNext", 
function () {
return this.node != null;
});
Clazz.defineMethod (c$, "remove", 
function () {
if (this.expectedModCount == this.backingMap.modCount) {
if (this.lastNode != null) {
this.backingMap.rbDelete (this.lastNode);
this.lastNode = null;
this.expectedModCount++;
} else {
throw  new IllegalStateException ();
}} else {
throw  new java.util.ConcurrentModificationException ();
}});
Clazz.defineMethod (c$, "makeNext", 
function () {
if (this.expectedModCount != this.backingMap.modCount) {
throw  new java.util.ConcurrentModificationException ();
} else if (this.node == null) {
throw  new java.util.NoSuchElementException ();
}this.lastNode = this.node;
this.node = java.util.TreeMap.successor (this.node);
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "UnboundedEntryIterator", java.util.TreeMap.AbstractMapIterator, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.UnboundedEntryIterator, [a, a.root == null ? null : java.util.TreeMap.minimum (a.root)]);
}, "java.util.TreeMap");
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
return this.lastNode;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "UnboundedKeyIterator", java.util.TreeMap.AbstractMapIterator, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.UnboundedKeyIterator, [a, a.root == null ? null : java.util.TreeMap.minimum (a.root)]);
}, "java.util.TreeMap");
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
return this.lastNode.key;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "UnboundedValueIterator", java.util.TreeMap.AbstractMapIterator, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.UnboundedValueIterator, [a, a.root == null ? null : java.util.TreeMap.minimum (a.root)]);
}, "java.util.TreeMap");
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
return this.lastNode.value;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.endKey = null;
this.cmp = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "ComparatorBoundedIterator", java.util.TreeMap.AbstractMapIterator);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.TreeMap.ComparatorBoundedIterator, [a, b]);
this.endKey = c;
this.cmp = a.comparator ();
}, "java.util.TreeMap,java.util.TreeMap.Entry,~O");
Clazz.defineMethod (c$, "cleanNext", 
function () {
if (this.node != null && this.cmp.compare (this.endKey, this.node.key) <= 0) {
this.node = null;
}});
Clazz.overrideMethod (c$, "hasNext", 
function () {
return (this.node != null && this.endKey != null) && (this.cmp.compare (this.node.key, this.endKey) < 0);
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparatorBoundedEntryIterator", java.util.TreeMap.ComparatorBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparatorBoundedKeyIterator", java.util.TreeMap.ComparatorBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode.key;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparatorBoundedValueIterator", java.util.TreeMap.ComparatorBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode.value;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.endKey = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "ComparableBoundedIterator", java.util.TreeMap.AbstractMapIterator);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.TreeMap.ComparableBoundedIterator, [a, b]);
this.endKey = c;
}, "java.util.TreeMap,java.util.TreeMap.Entry,Comparable");
Clazz.defineMethod (c$, "cleanNext", 
function () {
if ((this.node != null) && (this.endKey.compareTo (this.node.key) <= 0)) {
this.node = null;
}});
Clazz.overrideMethod (c$, "hasNext", 
function () {
return (this.node != null) && (this.endKey.compareTo (this.node.key) > 0);
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparableBoundedEntryIterator", java.util.TreeMap.ComparableBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparableBoundedKeyIterator", java.util.TreeMap.ComparableBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode.key;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.declareType (java.util.TreeMap, "ComparableBoundedValueIterator", java.util.TreeMap.ComparableBoundedIterator, java.util.Iterator);
Clazz.overrideMethod (c$, "next", 
function () {
this.makeNext ();
this.cleanNext ();
return this.lastNode.value;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.backingMap = null;
this.hasStart = false;
this.hasEnd = false;
this.startKey = null;
this.endKey = null;
this.$entrySet = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "SubMap", java.util.AbstractMap, [java.util.SortedMap, java.io.Serializable]);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.TreeMap.SubMap, []);
this.backingMap = b;
this.hasStart = true;
this.startKey = a;
}, "~O,java.util.TreeMap");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.TreeMap.SubMap, []);
this.backingMap = b;
this.hasStart = this.hasEnd = true;
this.startKey = a;
this.endKey = c;
}, "~O,java.util.TreeMap,~O");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.TreeMap.SubMap, []);
this.backingMap = a;
this.hasEnd = true;
this.endKey = b;
}, "java.util.TreeMap,~O");
Clazz.defineMethod (c$, "checkRange", 
function (a) {
var b = this.backingMap.$comparator;
if (b == null) {
var c = java.util.TreeMap.toComparable (a);
if (this.hasStart && c.compareTo (this.startKey) < 0) {
throw  new IllegalArgumentException ();
}if (this.hasEnd && c.compareTo (this.endKey) >= 0) {
throw  new IllegalArgumentException ();
}} else {
if (this.hasStart && this.backingMap.comparator ().compare (a, this.startKey) < 0) {
throw  new IllegalArgumentException ();
}if (this.hasEnd && this.backingMap.comparator ().compare (a, this.endKey) >= 0) {
throw  new IllegalArgumentException ();
}}}, "~O");
Clazz.defineMethod (c$, "isInRange", 
function (a) {
var b = this.backingMap.$comparator;
if (b == null) {
var c = java.util.TreeMap.toComparable (a);
if (this.hasStart && c.compareTo (this.startKey) < 0) {
return false;
}if (this.hasEnd && c.compareTo (this.endKey) >= 0) {
return false;
}} else {
if (this.hasStart && b.compare (a, this.startKey) < 0) {
return false;
}if (this.hasEnd && b.compare (a, this.endKey) >= 0) {
return false;
}}return true;
}, "~O");
Clazz.defineMethod (c$, "checkUpperBound", 
function (a) {
if (this.hasEnd) {
var b = this.backingMap.$comparator;
if (b == null) {
return (java.util.TreeMap.toComparable (a).compareTo (this.endKey) < 0);
}return (b.compare (a, this.endKey) < 0);
}return true;
}, "~O");
Clazz.defineMethod (c$, "checkLowerBound", 
function (a) {
if (this.hasStart) {
var b = this.backingMap.$comparator;
if (b == null) {
return (java.util.TreeMap.toComparable (a).compareTo (this.startKey) >= 0);
}return (b.compare (a, this.startKey) >= 0);
}return true;
}, "~O");
Clazz.overrideMethod (c$, "comparator", 
function () {
return this.backingMap.comparator ();
});
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
if (this.isInRange (a)) {
return this.backingMap.containsKey (a);
}return false;
}, "~O");
Clazz.overrideMethod (c$, "entrySet", 
function () {
if (this.$entrySet == null) {
this.$entrySet =  new java.util.TreeMap.SubMapEntrySet (this);
}return this.$entrySet;
});
Clazz.overrideMethod (c$, "firstKey", 
function () {
var a = this.firstEntry ();
if (a != null) {
return a.key;
}throw  new java.util.NoSuchElementException ();
});
Clazz.defineMethod (c$, "firstEntry", 
function () {
if (!this.hasStart) {
var a = this.backingMap.root;
return (a == null) ? null : java.util.TreeMap.minimum (this.backingMap.root);
}var a = this.backingMap.findAfter (this.startKey);
if (a != null && this.checkUpperBound (a.key)) {
return a;
}return null;
});
Clazz.overrideMethod (c$, "get", 
function (a) {
if (this.isInRange (a)) {
return this.backingMap.get (a);
}return null;
}, "~O");
Clazz.overrideMethod (c$, "headMap", 
function (a) {
this.checkRange (a);
if (this.hasStart) {
return  new java.util.TreeMap.SubMap (this.startKey, this.backingMap, a);
}return  new java.util.TreeMap.SubMap (this.backingMap, a);
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
if (this.hasStart) {
var a = this.backingMap.findAfter (this.startKey);
return a == null || !this.checkUpperBound (a.key);
}return this.backingMap.findBefore (this.endKey) == null;
});
Clazz.overrideMethod (c$, "keySet", 
function () {
if (this.$keySet == null) {
this.$keySet =  new java.util.TreeMap.SubMapKeySet (this);
}return this.$keySet;
});
Clazz.overrideMethod (c$, "lastKey", 
function () {
if (!this.hasEnd) {
return this.backingMap.lastKey ();
}var a = this.backingMap.findBefore (this.endKey);
if (a != null && this.checkLowerBound (a.key)) {
return a.key;
}throw  new java.util.NoSuchElementException ();
});
Clazz.overrideMethod (c$, "put", 
function (a, b) {
if (this.isInRange (a)) {
return this.backingMap.put (a, b);
}throw  new IllegalArgumentException ();
}, "~O,~O");
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.isInRange (a)) {
return this.backingMap.remove (a);
}return null;
}, "~O");
Clazz.overrideMethod (c$, "subMap", 
function (a, b) {
this.checkRange (a);
this.checkRange (b);
var c = this.backingMap.comparator ();
if (c == null) {
if (java.util.TreeMap.toComparable (a).compareTo (b) <= 0) {
return  new java.util.TreeMap.SubMap (a, this.backingMap, b);
}} else {
if (c.compare (a, b) <= 0) {
return  new java.util.TreeMap.SubMap (a, this.backingMap, b);
}}throw  new IllegalArgumentException ();
}, "~O,~O");
Clazz.overrideMethod (c$, "tailMap", 
function (a) {
this.checkRange (a);
if (this.hasEnd) {
return  new java.util.TreeMap.SubMap (a, this.backingMap, this.endKey);
}return  new java.util.TreeMap.SubMap (a, this.backingMap);
}, "~O");
Clazz.overrideMethod (c$, "values", 
function () {
if (this.valuesCollection == null) {
this.valuesCollection =  new java.util.TreeMap.SubMapValuesCollection (this);
}return this.valuesCollection;
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.subMap = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "SubMapEntrySet", java.util.AbstractSet, java.util.Set);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.SubMapEntrySet, []);
this.subMap = a;
}, "java.util.TreeMap.SubMap");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.subMap.isEmpty ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
var a = this.subMap.firstEntry ();
if (this.subMap.hasEnd) {
var b = this.subMap.comparator ();
if (b == null) {
return  new java.util.TreeMap.ComparableBoundedEntryIterator (this.subMap.backingMap, a, java.util.TreeMap.toComparable (this.subMap.endKey));
}return  new java.util.TreeMap.ComparatorBoundedEntryIterator (this.subMap.backingMap, a, this.subMap.endKey);
}return  new java.util.TreeMap.UnboundedEntryIterator (this.subMap.backingMap, a);
});
Clazz.overrideMethod (c$, "size", 
function () {
var a = 0;
var b = this.iterator ();
while (b.hasNext ()) {
a++;
b.next ();
}
return a;
});
Clazz.overrideMethod (c$, "contains", 
function (a) {
if (Clazz.instanceOf (a, java.util.Map.Entry)) {
var b = a;
var c = b.getKey ();
if (this.subMap.isInRange (c)) {
var d = this.subMap.get (c);
var e = b.getValue ();
return d == null ? e == null : d.equals (e);
}}return false;
}, "~O");
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.subMap = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "SubMapKeySet", java.util.AbstractSet, java.util.Set);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.SubMapKeySet, []);
this.subMap = a;
}, "java.util.TreeMap.SubMap");
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.subMap.containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.subMap.isEmpty ();
});
Clazz.overrideMethod (c$, "size", 
function () {
var a = 0;
var b = this.iterator ();
while (b.hasNext ()) {
a++;
b.next ();
}
return a;
});
Clazz.overrideMethod (c$, "iterator", 
function () {
var a = this.subMap.firstEntry ();
if (this.subMap.hasEnd) {
var b = this.subMap.comparator ();
if (b == null) {
return  new java.util.TreeMap.ComparableBoundedKeyIterator (this.subMap.backingMap, a, java.util.TreeMap.toComparable (this.subMap.endKey));
}return  new java.util.TreeMap.ComparatorBoundedKeyIterator (this.subMap.backingMap, a, this.subMap.endKey);
}return  new java.util.TreeMap.UnboundedKeyIterator (this.subMap.backingMap, a);
});
c$ = Clazz.p0p ();
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.subMap = null;
Clazz.instantialize (this, arguments);
}, java.util.TreeMap, "SubMapValuesCollection", java.util.AbstractCollection);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.TreeMap.SubMapValuesCollection, []);
this.subMap = a;
}, "java.util.TreeMap.SubMap");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.subMap.isEmpty ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
var a = this.subMap.firstEntry ();
if (this.subMap.hasEnd) {
var b = this.subMap.comparator ();
if (b == null) {
return  new java.util.TreeMap.ComparableBoundedValueIterator (this.subMap.backingMap, a, java.util.TreeMap.toComparable (this.subMap.endKey));
}return  new java.util.TreeMap.ComparatorBoundedValueIterator (this.subMap.backingMap, a, this.subMap.endKey);
}return  new java.util.TreeMap.UnboundedValueIterator (this.subMap.backingMap, a);
});
Clazz.overrideMethod (c$, "size", 
function () {
var a = 0;
for (var b = this.iterator (); b.hasNext (); ) {
b.next ();
a++;
}
return a;
});
c$ = Clazz.p0p ();
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023