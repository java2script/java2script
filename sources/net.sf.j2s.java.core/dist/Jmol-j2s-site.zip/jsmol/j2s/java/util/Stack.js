Clazz.load (["java.util.Vector"], "java.util.Stack", ["java.util.EmptyStackException"], function () {
c$ = Clazz.declareType (java.util, "Stack", java.util.Vector);
Clazz.defineMethod (c$, "empty", 
function () {
return this.elementCount == 0;
});
Clazz.defineMethod (c$, "peek", 
function () {
try {
return this.elementData[this.elementCount - 1];
} catch (e) {
if (Clazz.exceptionOf (e, IndexOutOfBoundsException)) {
throw  new java.util.EmptyStackException ();
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "pop", 
function () {
try {
var a = this.elementCount - 1;
var b = this.elementData[a];
this.removeElementAt (a);
return b;
} catch (e) {
if (Clazz.exceptionOf (e, IndexOutOfBoundsException)) {
throw  new java.util.EmptyStackException ();
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "push", 
function (a) {
this.addElement (a);
return a;
}, "~O");
Clazz.defineMethod (c$, "search", 
function (a) {
var b = this.lastIndexOf (a);
if (b >= 0) return (this.elementCount - b);
return -1;
}, "~O");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023