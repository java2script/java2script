Clazz.load (["java.util.Collection"], "java.util.List", null, function () {
Clazz.declareInterface (java.util, "List", java.util.Collection);
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023