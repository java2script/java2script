Clazz.load (["java.util.AbstractCollection", "$.Set"], "java.util.AbstractSet", null, function () {
c$ = Clazz.declareType (java.util, "AbstractSet", java.util.AbstractCollection, java.util.Set);
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Set)) {
var b = a;
return this.size () == b.size () && this.containsAll (b);
}return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a = 0;
var b = this.iterator ();
while (b.hasNext ()) {
var c = b.next ();
a += c == null ? 0 : c.hashCode ();
}
return a;
});
Clazz.overrideMethod (c$, "removeAll", 
function (a) {
var b = false;
if (this.size () <= a.size ()) {
var c = this.iterator ();
while (c.hasNext ()) {
if (a.contains (c.next ())) {
c.remove ();
b = true;
}}
} else {
var c = a.iterator ();
while (c.hasNext ()) {
b = this.remove (c.next ()) || b;
}
}return b;
}, "java.util.Collection");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023