Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.Deflater"], "java.util.zip.Deflater", null, function () {
c$ = Clazz.declareType (java.util.zip, "Deflater", com.jcraft.jzlib.Deflater);
Clazz.makeConstructor (c$, 
function (a) {
if (a != 2147483647) this.init (a, 0, false);
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023