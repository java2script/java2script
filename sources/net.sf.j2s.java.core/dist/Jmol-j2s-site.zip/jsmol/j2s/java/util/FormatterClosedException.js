Clazz.load (["java.lang.IllegalStateException"], "java.util.FormatterClosedException", null, function () {
c$ = Clazz.declareType (java.util, "FormatterClosedException", IllegalStateException, java.io.Serializable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.FormatterClosedException, []);
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023