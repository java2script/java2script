Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.DeflaterOutputStream"], "java.util.zip.DeflaterOutputStream", null, function () {
c$ = Clazz.declareType (java.util.zip, "DeflaterOutputStream", com.jcraft.jzlib.DeflaterOutputStream);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.zip.DeflaterOutputStream, []);
});
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.zip.DeflaterOutputStream, []);
this.setDOS (a, b);
}, "java.io.ByteArrayOutputStream,java.util.zip.Deflater");
Clazz.defineMethod (c$, "setDOS", 
function (a, b) {
this.jzSetDOS (a, b, 0, true);
}, "java.io.OutputStream,java.util.zip.Deflater");
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023