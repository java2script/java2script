Clazz.load (["java.util.Dictionary", "$.Enumeration", "$.Iterator", "$.Map", "$.MapEntry", "$.NoSuchElementException"], "java.util.Hashtable", ["java.lang.IllegalArgumentException", "$.IllegalStateException", "$.NullPointerException", "$.StringBuilder", "java.util.AbstractCollection", "$.AbstractSet", "$.Arrays", "$.Collections", "$.ConcurrentModificationException", "java.util.MapEntry.Type"], function () {
c$ = Clazz.decorateAsClass (function () {
this.elementCount = 0;
this.elementData = null;
this.loadFactor = 0;
this.threshold = 0;
this.firstSlot = 0;
this.lastSlot = -1;
this.modCount = 0;
if (!Clazz.isClassDefined ("java.util.Hashtable.HashIterator")) {
java.util.Hashtable.$Hashtable$HashIterator$ ();
}
if (!Clazz.isClassDefined ("java.util.Hashtable.HashEnumerator")) {
java.util.Hashtable.$Hashtable$HashEnumerator$ ();
}
Clazz.instantialize (this, arguments);
}, java.util, "Hashtable", java.util.Dictionary, [java.util.Map, Cloneable, java.io.Serializable]);
c$.newEntry = Clazz.defineMethod (c$, "newEntry", 
function (a, b, c) {
return  new java.util.Hashtable.Entry (a, b);
}, "~O,~O,~N");
Clazz.makeConstructor (c$, 
function () {
this.construct (11);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, java.util.Hashtable, []);
if (a >= 0) {
this.elementCount = 0;
this.elementData = this.newElementArray (a == 0 ? 1 : a);
this.firstSlot = this.elementData.length;
this.loadFactor = 0.75;
this.computeMaxSize ();
} else {
throw  new IllegalArgumentException ();
}}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.Hashtable, []);
if (a >= 0 && b > 0) {
this.elementCount = 0;
this.firstSlot = a;
this.elementData = this.newElementArray (a == 0 ? 1 : a);
this.loadFactor = b;
this.computeMaxSize ();
} else {
throw  new IllegalArgumentException ();
}}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.size () < 6 ? 11 : (Clazz.doubleToInt (a.size () * 4 / 3)) + 11);
this.putAll (a);
}, "java.util.Map");
Clazz.defineMethod (c$, "newElementArray", 
function (a) {
return  new Array (a);
}, "~N");
Clazz.overrideMethod (c$, "clear", 
function () {
this.elementCount = 0;
java.util.Arrays.fill (this.elementData, null);
this.modCount++;
});
Clazz.defineMethod (c$, "clone", 
function () {
try {
var a = Clazz.superCall (this, java.util.Hashtable, "clone", []);
a.elementData = this.elementData.clone ();
var b;
for (var c = this.elementData.length; --c >= 0; ) {
if ((b = this.elementData[c]) != null) {
a.elementData[c] = b.clone ();
}}
return a;
} catch (e) {
if (Clazz.exceptionOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "computeMaxSize", 
function () {
this.threshold = Clazz.floatToInt (this.elementData.length * this.loadFactor);
});
Clazz.defineMethod (c$, "contains", 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}for (var b = this.elementData.length; --b >= 0; ) {
var c = this.elementData[b];
while (c != null) {
if (a.equals (c.value)) {
return true;
}c = c.next;
}
}
return false;
}, "~O");
Clazz.overrideMethod (c$, "containsKey", 
function (a) {
return this.getEntry (a) != null;
}, "~O");
Clazz.overrideMethod (c$, "containsValue", 
function (a) {
return this.contains (a);
}, "~O");
Clazz.overrideMethod (c$, "elements", 
function () {
if (this.elementCount == 0) {
return java.util.Hashtable.EMPTY_ENUMERATION;
}return Clazz.innerTypeInstance (java.util.Hashtable.HashEnumerator, this, null, false);
});
Clazz.overrideMethod (c$, "entrySet", 
function () {
return  new java.util.Collections.SynchronizedSet (((Clazz.isClassDefined ("java.util.Hashtable$2") ? 0 : java.util.Hashtable.$Hashtable$2$ ()), Clazz.innerTypeInstance (java.util.Hashtable$2, this, null)), this);
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) {
return true;
}if (Clazz.instanceOf (a, java.util.Map)) {
var b = a;
if (this.size () != b.size ()) {
return false;
}var c = this.entrySet ();
for (var e, $e = b.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
if (!c.contains (e)) {
return false;
}}
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "get", 
function (a) {
var b = a.hashCode ();
var c = (b & 0x7FFFFFFF) % this.elementData.length;
var d = this.elementData[c];
while (d != null) {
if (d.equalsKey (a, b)) {
return d.value;
}d = d.next;
}
return null;
}, "~O");
Clazz.defineMethod (c$, "getEntry", 
function (a) {
var b = a.hashCode ();
var c = (b & 0x7FFFFFFF) % this.elementData.length;
var d = this.elementData[c];
while (d != null) {
if (d.equalsKey (a, b)) {
return d;
}d = d.next;
}
return null;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a = 0;
var b = this.entrySet ().iterator ();
while (b.hasNext ()) {
var c = b.next ();
var d = c.getKey ();
var e = c.getValue ();
var f = (d !== this ? d.hashCode () : 0) ^ (e !== this ? (e != null ? e.hashCode () : 0) : 0);
a += f;
}
return a;
});
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.elementCount == 0;
});
Clazz.overrideMethod (c$, "keys", 
function () {
if (this.elementCount == 0) {
return java.util.Hashtable.EMPTY_ENUMERATION;
}return Clazz.innerTypeInstance (java.util.Hashtable.HashEnumerator, this, null, true);
});
Clazz.overrideMethod (c$, "keySet", 
function () {
return  new java.util.Collections.SynchronizedSet (((Clazz.isClassDefined ("java.util.Hashtable$3") ? 0 : java.util.Hashtable.$Hashtable$3$ ()), Clazz.innerTypeInstance (java.util.Hashtable$3, this, null)), this);
});
Clazz.overrideMethod (c$, "put", 
function (a, b) {
if (a != null && b != null) {
var c = a.hashCode ();
var d = (c & 0x7FFFFFFF) % this.elementData.length;
var e = this.elementData[d];
while (e != null && !e.equalsKey (a, c)) {
e = e.next;
}
if (e == null) {
this.modCount++;
if (++this.elementCount > this.threshold) {
this.rehash ();
d = (c & 0x7FFFFFFF) % this.elementData.length;
}if (d < this.firstSlot) {
this.firstSlot = d;
}if (d > this.lastSlot) {
this.lastSlot = d;
}e = java.util.Hashtable.newEntry (a, b, c);
e.next = this.elementData[d];
this.elementData[d] = e;
return null;
}var f = e.value;
e.value = b;
return f;
}throw  new NullPointerException ();
}, "~O,~O");
Clazz.overrideMethod (c$, "putAll", 
function (a) {
for (var entry, $entry = a.entrySet ().iterator (); $entry.hasNext () && ((entry = $entry.next ()) || true);) {
this.put (entry.getKey (), entry.getValue ());
}
}, "java.util.Map");
Clazz.defineMethod (c$, "rehash", 
function () {
var a = (this.elementData.length << 1) + 1;
if (a == 0) {
a = 1;
}var b = a;
var c = -1;
var d = this.newElementArray (a);
for (var e = this.lastSlot + 1; --e >= this.firstSlot; ) {
var f = this.elementData[e];
while (f != null) {
var g = (f.getKeyHash () & 0x7FFFFFFF) % a;
if (g < b) {
b = g;
}if (g > c) {
c = g;
}var h = f.next;
f.next = d[g];
d[g] = f;
f = h;
}
}
this.firstSlot = b;
this.lastSlot = c;
this.elementData = d;
this.computeMaxSize ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
var b = a.hashCode ();
var c = (b & 0x7FFFFFFF) % this.elementData.length;
var d = null;
var e = this.elementData[c];
while (e != null && !e.equalsKey (a, b)) {
d = e;
e = e.next;
}
if (e != null) {
this.modCount++;
if (d == null) {
this.elementData[c] = e.next;
} else {
d.next = e.next;
}this.elementCount--;
var f = e.value;
e.value = null;
return f;
}return null;
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.elementCount;
});
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.isEmpty ()) {
return "{}";
}var a =  new StringBuilder (this.size () * 28);
a.append ('{');
for (var b = this.lastSlot; b >= this.firstSlot; b--) {
var c = this.elementData[b];
while (c != null) {
if (c.key !== this) {
a.append (c.key);
} else {
a.append ("(this Map)");
}a.append ('=');
if (c.value !== this) {
a.append (c.value);
} else {
a.append ("(this Map)");
}a.append (", ");
c = c.next;
}
}
if (this.elementCount > 0) {
a.setLength (a.length () - 2);
}a.append ('}');
return a.toString ();
});
Clazz.overrideMethod (c$, "values", 
function () {
return  new java.util.Collections.SynchronizedCollection (((Clazz.isClassDefined ("java.util.Hashtable$4") ? 0 : java.util.Hashtable.$Hashtable$4$ ()), Clazz.innerTypeInstance (java.util.Hashtable$4, this, null)), this);
});
c$.$Hashtable$HashIterator$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.position = 0;
this.expectedModCount = 0;
this.type = null;
this.lastEntry = null;
this.lastPosition = 0;
this.canRemove = false;
Clazz.instantialize (this, arguments);
}, java.util.Hashtable, "HashIterator", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
this.type = a;
this.position = this.b$["java.util.Hashtable"].lastSlot;
this.expectedModCount = this.b$["java.util.Hashtable"].modCount;
}, "java.util.MapEntry.Type");
Clazz.overrideMethod (c$, "hasNext", 
function () {
if (this.lastEntry != null && this.lastEntry.next != null) {
return true;
}while (this.position >= this.b$["java.util.Hashtable"].firstSlot) {
if (this.b$["java.util.Hashtable"].elementData[this.position] == null) {
this.position--;
} else {
return true;
}}
return false;
});
Clazz.overrideMethod (c$, "next", 
function () {
if (this.expectedModCount == this.b$["java.util.Hashtable"].modCount) {
if (this.lastEntry != null) {
this.lastEntry = this.lastEntry.next;
}if (this.lastEntry == null) {
while (this.position >= this.b$["java.util.Hashtable"].firstSlot && (this.lastEntry = this.b$["java.util.Hashtable"].elementData[this.position]) == null) {
this.position--;
}
if (this.lastEntry != null) {
this.lastPosition = this.position;
this.position--;
}}if (this.lastEntry != null) {
this.canRemove = true;
return this.type.get (this.lastEntry);
}throw  new java.util.NoSuchElementException ();
}throw  new java.util.ConcurrentModificationException ();
});
Clazz.overrideMethod (c$, "remove", 
function () {
if (this.expectedModCount == this.b$["java.util.Hashtable"].modCount) {
if (this.canRemove) {
this.canRemove = false;
{
var a = false;
var b = this.b$["java.util.Hashtable"].elementData[this.lastPosition];
if (b === this.lastEntry) {
this.b$["java.util.Hashtable"].elementData[this.lastPosition] = b.next;
a = true;
} else {
while (b != null && b.next !== this.lastEntry) {
b = b.next;
}
if (b != null) {
b.next = this.lastEntry.next;
a = true;
}}if (a) {
this.b$["java.util.Hashtable"].modCount++;
this.b$["java.util.Hashtable"].elementCount--;
this.expectedModCount++;
return;
}}} else {
throw  new IllegalStateException ();
}}throw  new java.util.ConcurrentModificationException ();
});
c$ = Clazz.p0p ();
};
c$.$Hashtable$HashEnumerator$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.key = false;
this.start = 0;
this.entry = null;
Clazz.instantialize (this, arguments);
}, java.util.Hashtable, "HashEnumerator", null, java.util.Enumeration);
Clazz.makeConstructor (c$, 
function (a) {
this.key = a;
this.start = this.b$["java.util.Hashtable"].lastSlot + 1;
}, "~B");
Clazz.overrideMethod (c$, "hasMoreElements", 
function () {
if (this.entry != null) {
return true;
}while (--this.start >= this.b$["java.util.Hashtable"].firstSlot) {
if (this.b$["java.util.Hashtable"].elementData[this.start] != null) {
this.entry = this.b$["java.util.Hashtable"].elementData[this.start];
return true;
}}
return false;
});
Clazz.overrideMethod (c$, "nextElement", 
function () {
if (this.hasMoreElements ()) {
var a = this.key ? this.entry.key : this.entry.value;
this.entry = this.entry.next;
return a;
}throw  new java.util.NoSuchElementException ();
});
c$ = Clazz.p0p ();
};
c$.$Hashtable$2$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$2", java.util.AbstractSet);
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.Hashtable"].elementCount;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.Hashtable"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.contains (a)) {
this.b$["java.util.Hashtable"].remove ((a).getKey ());
return true;
}return false;
}, "~O");
Clazz.defineMethod (c$, "contains", 
function (a) {
var b = this.b$["java.util.Hashtable"].getEntry ((a).getKey ());
return a.equals (b);
}, "~O");
Clazz.defineMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.Hashtable.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.Hashtable$2$1") ? 0 : java.util.Hashtable.$Hashtable$2$1$ ()), Clazz.innerTypeInstance (java.util.Hashtable$2$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$Hashtable$2$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$2$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$Hashtable$3$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$3", java.util.AbstractSet);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.Hashtable"].containsKey (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.Hashtable"].elementCount;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.Hashtable"].clear ();
});
Clazz.overrideMethod (c$, "remove", 
function (a) {
if (this.b$["java.util.Hashtable"].containsKey (a)) {
this.b$["java.util.Hashtable"].remove (a);
return true;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.Hashtable.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.Hashtable$3$1") ? 0 : java.util.Hashtable.$Hashtable$3$1$ ()), Clazz.innerTypeInstance (java.util.Hashtable$3$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$Hashtable$3$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$3$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.key;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$Hashtable$4$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$4", java.util.AbstractCollection);
Clazz.overrideMethod (c$, "contains", 
function (a) {
return this.b$["java.util.Hashtable"].contains (a);
}, "~O");
Clazz.overrideMethod (c$, "size", 
function () {
return this.b$["java.util.Hashtable"].elementCount;
});
Clazz.overrideMethod (c$, "clear", 
function () {
this.b$["java.util.Hashtable"].clear ();
});
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (java.util.Hashtable.HashIterator, this, null, ((Clazz.isClassDefined ("java.util.Hashtable$4$1") ? 0 : java.util.Hashtable.$Hashtable$4$1$ ()), Clazz.innerTypeInstance (java.util.Hashtable$4$1, this, null)));
});
c$ = Clazz.p0p ();
};
c$.$Hashtable$4$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$4$1", null, java.util.MapEntry.Type);
Clazz.overrideMethod (c$, "get", 
function (a) {
return a.value;
}, "java.util.MapEntry");
c$ = Clazz.p0p ();
};
c$.$Hashtable$1$ = function () {
Clazz.pu$h(self.c$);
c$ = Clazz.declareAnonymous (java.util, "Hashtable$1", null, java.util.Enumeration);
Clazz.overrideMethod (c$, "hasMoreElements", 
function () {
return false;
});
Clazz.overrideMethod (c$, "nextElement", 
function () {
throw  new java.util.NoSuchElementException ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h(self.c$);
c$ = Clazz.decorateAsClass (function () {
this.next = null;
this.hashcode = 0;
Clazz.instantialize (this, arguments);
}, java.util.Hashtable, "Entry", java.util.MapEntry);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, java.util.Hashtable.Entry, [a, b]);
this.hashcode = a.hashCode ();
}, "~O,~O");
Clazz.defineMethod (c$, "clone", 
function () {
var a = Clazz.superCall (this, java.util.Hashtable.Entry, "clone", []);
if (this.next != null) {
a.next = this.next.clone ();
}return a;
});
Clazz.overrideMethod (c$, "setValue", 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}var b = this.value;
this.value = a;
return b;
}, "~O");
Clazz.defineMethod (c$, "getKeyHash", 
function () {
return this.key.hashCode ();
});
Clazz.defineMethod (c$, "equalsKey", 
function (a, b) {
return this.hashcode == a.hashCode () && this.key.equals (a);
}, "~O,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.key + "=" + this.value;
});
c$ = Clazz.p0p ();
c$.EMPTY_ENUMERATION = c$.prototype.EMPTY_ENUMERATION = ((Clazz.isClassDefined ("java.util.Hashtable$1") ? 0 : java.util.Hashtable.$Hashtable$1$ ()), Clazz.innerTypeInstance (java.util.Hashtable$1, this, null));
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023