Clazz.declarePackage ("java.util.regex");
Clazz.load (["java.lang.IllegalArgumentException"], "java.util.regex.PatternSyntaxException", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.desc = null;
this.pattern = null;
this.index = -1;
Clazz.instantialize (this, arguments);
}, java.util.regex, "PatternSyntaxException", IllegalArgumentException);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, java.util.regex.PatternSyntaxException, []);
this.desc = a;
this.pattern = b;
this.index = c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getPattern", 
function () {
return this.pattern;
});
Clazz.overrideMethod (c$, "getMessage", 
function () {
var a = this.desc;
if (this.index >= 0) {
a += " near index " + this.index;
}a += "\r\n" + this.pattern;
if (this.index >= 0) {
a += "\r\n";
for (var b = 0; b < this.index; b++) a += ' ';

a += '^';
}return a;
});
Clazz.defineMethod (c$, "getDescription", 
function () {
return this.desc;
});
Clazz.defineMethod (c$, "getIndex", 
function () {
return this.index;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023