Clazz.load (["java.util.Vector"], "java.util.Observable", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.observers = null;
this.changed = false;
Clazz.instantialize (this, arguments);
}, java.util, "Observable");
Clazz.prepareFields (c$, function () {
this.observers =  new java.util.Vector ();
});
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "addObserver", 
function (a) {
if (a == null) {
throw  new NullPointerException ();
}if (!this.observers.contains (a)) this.observers.addElement (a);
}, "java.util.Observer");
Clazz.defineMethod (c$, "clearChanged", 
function () {
this.changed = false;
});
Clazz.defineMethod (c$, "countObservers", 
function () {
return this.observers.size ();
});
Clazz.defineMethod (c$, "deleteObserver", 
function (a) {
this.observers.removeElement (a);
}, "java.util.Observer");
Clazz.defineMethod (c$, "deleteObservers", 
function () {
this.observers.setSize (0);
});
Clazz.defineMethod (c$, "hasChanged", 
function () {
return this.changed;
});
Clazz.defineMethod (c$, "notifyObservers", 
function () {
this.notifyObservers (null);
});
Clazz.defineMethod (c$, "notifyObservers", 
function (a) {
if (this.changed) {
var b = this.observers.clone ();
var c = b.size ();
for (var d = 0; d < c; d++) {
b.elementAt (d).update (this, a);
}
this.clearChanged ();
}}, "~O");
Clazz.defineMethod (c$, "setChanged", 
function () {
this.changed = true;
});
});
;//5.0.1-v1 Sun Nov 12 11:47:43 CST 2023