(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newInterface(P$, "A2SContainer");
})();
//Created 2018-06-26 10:02:38
