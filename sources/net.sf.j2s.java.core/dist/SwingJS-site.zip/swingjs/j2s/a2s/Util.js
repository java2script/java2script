(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Util");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'drawString$java_awt_Graphics$S$I$I', function (g, text, x, y) {
{
g.drawStringUnique(text, x, y);
}
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 04:33:10 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
