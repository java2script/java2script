(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
//Created 2018-06-25 11:48:48
