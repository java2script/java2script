(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
//Created 2018-06-26 10:03:22
