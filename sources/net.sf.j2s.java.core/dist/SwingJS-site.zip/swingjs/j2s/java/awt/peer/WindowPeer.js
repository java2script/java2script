(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "WindowPeer", null, null, 'java.awt.peer.ContainerPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-06-24 09:51:46
