(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "OpenType");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-12-19 08:23:58 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
