(function(){var P$=Clazz.newPackage("java.awt"),I$=[['java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BorderLayout", null, null, ['java.awt.LayoutManager2', 'java.io.Serializable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hgap = 0;
this.vgap = 0;
this.north = null;
this.west = null;
this.east = null;
this.south = null;
this.center = null;
this.firstLine = null;
this.lastLine = null;
this.firstItem = null;
this.lastItem = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I.apply(this, [0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (hgap, vgap) {
C$.$init$.apply(this);
this.hgap=hgap;
this.vgap=vgap;
}, 1);

Clazz.newMeth(C$, 'getHgap', function () {
return this.hgap;
});

Clazz.newMeth(C$, 'setHgap$I', function (hgap) {
this.hgap=hgap;
});

Clazz.newMeth(C$, 'getVgap', function () {
return this.vgap;
});

Clazz.newMeth(C$, 'setVgap$I', function (vgap) {
this.vgap=vgap;
});

Clazz.newMeth(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'getLayoutComponent$O', function (constraints) {
if ("Center".equals$O(constraints)) {
return this.center;
} else if ("North".equals$O(constraints)) {
return this.north;
} else if ("South".equals$O(constraints)) {
return this.south;
} else if ("West".equals$O(constraints)) {
return this.west;
} else if ("East".equals$O(constraints)) {
return this.east;
} else if ("First".equals$O(constraints)) {
return this.firstLine;
} else if ("Last".equals$O(constraints)) {
return this.lastLine;
} else if ("Before".equals$O(constraints)) {
return this.firstItem;
} else if ("After".equals$O(constraints)) {
return this.lastItem;
} else {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["cannot get component: unknown constraint: " + constraints]);
}});

Clazz.newMeth(C$, 'getLayoutComponent$java_awt_Container$O', function (target, constraints) {
var ltr = target.getComponentOrientation().isLeftToRight();
var result = null;
if ("North".equals$O(constraints)) {
result=(this.firstLine != null ) ? this.firstLine : this.north;
} else if ("South".equals$O(constraints)) {
result=(this.lastLine != null ) ? this.lastLine : this.south;
} else if ("West".equals$O(constraints)) {
result=ltr ? this.firstItem : this.lastItem;
if (result == null ) {
result=this.west;
}} else if ("East".equals$O(constraints)) {
result=ltr ? this.lastItem : this.firstItem;
if (result == null ) {
result=this.east;
}} else if ("Center".equals$O(constraints)) {
result=this.center;
} else {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["cannot get component: invalid constraint: " + constraints]);
}return result;
});

Clazz.newMeth(C$, 'getConstraints$java_awt_Component', function (comp) {
if (comp == null ) {
return null;
}if (comp === this.center ) {
return "Center";
} else if (comp === this.north ) {
return "North";
} else if (comp === this.south ) {
return "South";
} else if (comp === this.west ) {
return "West";
} else if (comp === this.east ) {
return "East";
} else if (comp === this.firstLine ) {
return "First";
} else if (comp === this.lastLine ) {
return "Last";
} else if (comp === this.firstItem ) {
return "Before";
} else if (comp === this.lastItem ) {
return "After";
}return null;
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'maximumLayoutSize$java_awt_Container', function (target) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[2147483647, 2147483647]);
});

Clazz.newMeth(C$, 'getLayoutAlignmentX$java_awt_Container', function (parent) {
return 0.5;
});

Clazz.newMeth(C$, 'getLayoutAlignmentY$java_awt_Container', function (parent) {
return 0.5;
});

Clazz.newMeth(C$, 'invalidateLayout$java_awt_Container', function (target) {
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'getChild$S$Z', function (key, ltr) {
var result = null;
if (key == "North") {
result=(this.firstLine != null ) ? this.firstLine : this.north;
} else if (key == "South") {
result=(this.lastLine != null ) ? this.lastLine : this.south;
} else if (key == "West") {
result=ltr ? this.firstItem : this.lastItem;
if (result == null ) {
result=this.west;
}} else if (key == "East") {
result=ltr ? this.lastItem : this.firstItem;
if (result == null ) {
result=this.east;
}} else if (key == "Center") {
result=this.center;
}if (result != null  && !result.visible ) {
result=null;
}return result;
});

Clazz.newMeth(C$, 'toString', function () {
return this.getClass().getName() + "[hgap=" + this.hgap + ",vgap=" + this.vgap + "]" ;
});
})();
//Created 2018-06-25 10:56:47
