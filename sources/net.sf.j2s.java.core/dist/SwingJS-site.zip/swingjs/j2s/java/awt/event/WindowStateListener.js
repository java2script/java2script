(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "WindowStateListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-20 09:57:36 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
