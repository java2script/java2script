(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[['java.awt.Point']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DragSourceEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.locationSpecified = false;
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_dnd_DragSourceContext', function (dsc) {
C$.superclazz.c$.apply(this, [dsc]);
C$.$init$.apply(this);
this.locationSpecified=false;
this.x=0;
this.y=0;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_dnd_DragSourceContext$I$I', function (dsc, x, y) {
C$.superclazz.c$.apply(this, [dsc]);
C$.$init$.apply(this);
this.locationSpecified=true;
this.x=x;
this.y=y;
}, 1);

Clazz.newMeth(C$, 'getDragSourceContext', function () {
return this.getSource();
});

Clazz.newMeth(C$, 'getLocation', function () {
if (this.locationSpecified) {
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[this.x, this.y]);
} else {
return null;
}});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 04:33:17 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
