(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
var C$=Clazz.newInterface(P$, "Printable");
C$.PAGE_EXISTS = 0;
C$.NO_SUCH_PAGE = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.PAGE_EXISTS = 0;
C$.NO_SUCH_PAGE = 1;
}
})();
//Created 2018-07-23 15:12:06 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
