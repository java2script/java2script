(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "FlowLayout", null, null, ['java.awt.LayoutManager', 'java.io.Serializable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.align = 0;
this.newAlign = 0;
this.hgap = 0;
this.vgap = 0;
this.alignOnBaseline = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I$I.apply(this, [1, 5, 5]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (align) {
C$.c$$I$I$I.apply(this, [align, 5, 5]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I', function (align, hgap, vgap) {
C$.$init$.apply(this);
this.hgap=hgap;
this.vgap=vgap;
this.setAlignment$I(align);
}, 1);

Clazz.newMeth(C$, 'getAlignment', function () {
return this.newAlign;
});

Clazz.newMeth(C$, 'setAlignment$I', function (align) {
this.newAlign=align;
switch (align) {
case 3:
this.align=0;
break;
case 4:
this.align=2;
break;
default:
this.align=align;
break;
}
});

Clazz.newMeth(C$, 'getHgap', function () {
return this.hgap;
});

Clazz.newMeth(C$, 'setHgap$I', function (hgap) {
this.hgap=hgap;
});

Clazz.newMeth(C$, 'getVgap', function () {
return this.vgap;
});

Clazz.newMeth(C$, 'setVgap$I', function (vgap) {
this.vgap=vgap;
});

Clazz.newMeth(C$, 'setAlignOnBaseline$Z', function (alignOnBaseline) {
this.alignOnBaseline=alignOnBaseline;
});

Clazz.newMeth(C$, 'getAlignOnBaseline', function () {
return this.alignOnBaseline;
});

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'moveComponents$java_awt_Container$I$I$I$I$I$I$Z$Z$IA$IA', function (target, x, y, width, height, rowStart, rowEnd, ltr, useBaseline, ascent, descent) {
switch (this.newAlign) {
case 0:
x+=ltr ? 0 : width;
break;
case 1:
x+=(width/2|0);
break;
case 2:
x+=ltr ? width : 0;
break;
case 3:
break;
case 4:
x+=width;
break;
}
var maxAscent = 0;
var nonbaselineHeight = 0;
var baselineOffset = 0;
if (useBaseline) {
var maxDescent = 0;
for (var i = rowStart; i < rowEnd; i++) {
var m = target.getComponent$I(i);
if (m.visible) {
if (ascent[i] >= 0) {
maxAscent=Math.max(maxAscent, ascent[i]);
maxDescent=Math.max(maxDescent, descent[i]);
} else {
nonbaselineHeight=Math.max(m.getHeight(), nonbaselineHeight);
}}}
height=Math.max(maxAscent + maxDescent, nonbaselineHeight);
baselineOffset=((height - maxAscent - maxDescent )/2|0);
}for (var i = rowStart; i < rowEnd; i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var cy;
if (useBaseline && ascent[i] >= 0 ) {
cy=y + baselineOffset + maxAscent  - ascent[i];
} else {
cy=y + ((height - m.height)/2|0);
}if (ltr) {
m.setLocation$I$I(x, cy);
} else {
m.setLocation$I$I(target.width - x - m.width , cy);
}x+=m.width + this.hgap;
}}
return height;
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'toString', function () {
var str = "";
switch (this.align) {
case 0:
str=",align=left";
break;
case 1:
str=",align=center";
break;
case 2:
str=",align=right";
break;
case 3:
str=",align=leading";
break;
case 4:
str=",align=trailing";
break;
}
return this.getClass().getName() + "[hgap=" + this.hgap + ",vgap=" + this.vgap + str + "]" ;
});
})();
//Created 2018-06-25 10:56:49
