(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Stroke");
})();
//Created 2018-07-06 06:23:16
