(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RasterOp");
})();
//Created 2018-07-03 09:27:00
