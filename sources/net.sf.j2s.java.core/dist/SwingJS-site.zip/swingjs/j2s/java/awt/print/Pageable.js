(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
var C$=Clazz.newInterface(P$, "Pageable");
C$.UNKNOWN_NUMBER_OF_PAGES = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.UNKNOWN_NUMBER_OF_PAGES = -1;
}
})();
//Created 2018-06-25 14:16:08
