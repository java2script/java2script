(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Shape");
})();
//Created 2018-07-03 06:24:46
