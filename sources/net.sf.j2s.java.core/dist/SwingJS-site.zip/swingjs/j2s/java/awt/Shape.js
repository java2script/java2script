(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Shape");
})();
//Created 2018-06-24 05:58:39
