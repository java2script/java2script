(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "TextField", null, 'a2s.TextField');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$S$I.apply(this, ["", 0]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.c$$S$I.apply(this, [text, (text != null ) ? text.length$() : 0]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (columns) {
C$.c$$S$I.apply(this, ["", columns]);
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (text, columns) {
C$.superclazz.c$$S$I.apply(this, [text, columns]);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-23 15:17:44 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
