(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "MenuContainer");
})();
//Created 2018-06-24 06:15:06
