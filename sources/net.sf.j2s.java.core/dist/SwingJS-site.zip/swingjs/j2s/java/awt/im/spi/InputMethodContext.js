(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethodContext", null, null, 'java.awt.im.InputMethodRequests');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-10 13:57:33 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
