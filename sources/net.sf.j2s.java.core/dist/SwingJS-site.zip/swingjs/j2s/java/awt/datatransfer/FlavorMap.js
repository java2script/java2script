(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "FlavorMap");
})();
//Created 2018-07-06 15:25:55
