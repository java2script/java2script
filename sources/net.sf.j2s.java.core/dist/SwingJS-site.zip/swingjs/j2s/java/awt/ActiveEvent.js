(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ActiveEvent");
})();
//Created 2018-06-22 06:02:25
