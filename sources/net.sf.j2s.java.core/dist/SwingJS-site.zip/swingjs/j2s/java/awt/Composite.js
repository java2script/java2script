(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Composite");
})();
//Created 2018-06-26 10:02:56
