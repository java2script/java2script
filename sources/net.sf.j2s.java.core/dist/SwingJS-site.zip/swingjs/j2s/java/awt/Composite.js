(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Composite");
})();
//Created 2018-06-28 09:48:00
