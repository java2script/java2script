(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "FramePeer", null, null, 'java.awt.peer.WindowPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-06-26 10:03:21
