(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PopupMenu", null, 'swingjs.a2s.PopupMenu');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (label) {
;C$.superclazz.c$$S.apply(this,[label]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-01-14 18:17:04 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
