(function(){var P$=Clazz.newPackage("java.awt"),I$=[[0,'java.util.Vector','java.awt.GraphicsEnvironment','java.awt.AWTEventMulticaster','java.awt.event.ItemListener','java.awt.event.ActionListener']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "List", null, 'javax.swing.JList', 'java.awt.ItemSelectable');
C$.nameCounter=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.nameCounter=0;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.items=null;
this.rows=0;
this.multipleMode=false;
this.selected=null;
this.visibleIndex=0;
this.actionListener=null;
this.itemListener=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.items=Clazz.new_(Clazz.load('java.util.Vector'));
this.rows=0;
this.multipleMode=false;
this.selected=Clazz.array(Integer.TYPE, [0]);
this.visibleIndex=-1;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$Z.apply(this, [0, false]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (rows) {
C$.c$$I$Z.apply(this, [rows, false]);
}, 1);

Clazz.newMeth(C$, 'c$$I$Z', function (rows, multipleMode) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
Clazz.load('java.awt.GraphicsEnvironment').checkHeadless$();
this.rows=(rows != 0) ? rows : 4;
this.multipleMode=multipleMode;
}, 1);

Clazz.newMeth(C$, 'constructComponentName$', function () {
{
return "list" + C$.nameCounter++;
}});

Clazz.newMeth(C$, 'addNotify$', function () {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
C$.superclazz.prototype.addNotify$.apply(this, []);
}});

Clazz.newMeth(C$, 'removeNotify$', function () {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
var peer=this.peer;
if (peer != null ) {
this.selected=peer.getSelectedIndexes$();
}C$.superclazz.prototype.removeNotify$.apply(this, []);
}});

Clazz.newMeth(C$, 'getItemCount$', function () {
return this.countItems$();
});

Clazz.newMeth(C$, 'countItems$', function () {
return this.items.size$();
});

Clazz.newMeth(C$, 'getItem$I', function (index) {
return this.getItemImpl$I(index);
});

Clazz.newMeth(C$, 'getItemImpl$I', function (index) {
return this.items.elementAt$I(index);
});

Clazz.newMeth(C$, 'getItems$', function () {
var itemCopies=Clazz.array(String, [this.items.size$()]);
this.items.copyInto$OA(itemCopies);
return itemCopies;
});

Clazz.newMeth(C$, 'add$S', function (item) {
this.addItem$S(item);
});

Clazz.newMeth(C$, 'addItem$S', function (item) {
this.addItem$S$I(item, -1);
});

Clazz.newMeth(C$, 'add$S$I', function (item, index) {
this.addItem$S$I(item, index);
});

Clazz.newMeth(C$, 'addItem$S$I', function (item, index) {
if (index < -1 || index >= this.items.size$() ) {
index=-1;
}if (item == null ) {
item="";
}if (index == -1) {
this.items.addElement$TE(item);
} else {
this.items.insertElementAt$TE$I(item, index);
}var peer=this.peer;
if (peer != null ) {
peer.add$S$I(item, index);
}});

Clazz.newMeth(C$, 'replaceItem$S$I', function (newValue, index) {
this.remove$I(index);
this.add$S$I(newValue, index);
});

Clazz.newMeth(C$, 'removeAll$', function () {
this.clear$();
});

Clazz.newMeth(C$, 'clear$', function () {
var peer=this.peer;
if (peer != null ) {
peer.removeAll$();
}this.items=Clazz.new_($I$(1));
this.selected=Clazz.array(Integer.TYPE, [0]);
});

Clazz.newMeth(C$, 'remove$S', function (item) {
var index=this.items.indexOf$O(item);
if (index < 0) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["item " + item + " not found in list" ]);
} else {
this.remove$I(index);
}});

Clazz.newMeth(C$, 'remove$I', function (position) {
this.delItem$I(position);
});

Clazz.newMeth(C$, 'delItem$I', function (position) {
this.delItems$I$I(position, position);
});

Clazz.newMeth(C$, 'getSelectedIndex$', function () {
var sel=this.getSelectedIndexes$();
return (sel.length == 1) ? sel[0] : -1;
});

Clazz.newMeth(C$, 'getSelectedIndexes$', function () {
var peer=this.peer;
if (peer != null ) {
this.selected=peer.getSelectedIndexes$();
}return this.selected.clone$();
});

Clazz.newMeth(C$, 'getSelectedItem$', function () {
var index=this.getSelectedIndex$();
return (index < 0) ? null : this.getItem$I(index);
});

Clazz.newMeth(C$, 'getSelectedItems$', function () {
var sel=this.getSelectedIndexes$();
var str=Clazz.array(String, [sel.length]);
for (var i=0; i < sel.length; i++) {
str[i]=this.getItem$I(sel[i]);
}
return str;
});

Clazz.newMeth(C$, 'getSelectedObjects$', function () {
return this.getSelectedItems$();
});

Clazz.newMeth(C$, 'select$I', function (index) {
var peer;
do {
peer=this.peer;
if (peer != null ) {
peer.select$I(index);
return;
}{
var alreadySelected=false;
for (var i=0; i < this.selected.length; i++) {
if (this.selected[i] == index) {
alreadySelected=true;
break;
}}
if (!alreadySelected) {
if (!this.multipleMode) {
this.selected=Clazz.array(Integer.TYPE, [1]);
this.selected[0]=index;
} else {
var newsel=Clazz.array(Integer.TYPE, [this.selected.length + 1]);
System.arraycopy$O$I$O$I$I(this.selected, 0, newsel, 0, this.selected.length);
newsel[this.selected.length]=index;
this.selected=newsel;
}}}} while (peer !== this.peer );
});

Clazz.newMeth(C$, 'deselect$I', function (index) {
var peer=this.peer;
if (peer != null ) {
if (this.isMultipleMode$() || (this.getSelectedIndex$() == index) ) {
peer.deselect$I(index);
}}for (var i=0; i < this.selected.length; i++) {
if (this.selected[i] == index) {
var newsel=Clazz.array(Integer.TYPE, [this.selected.length - 1]);
System.arraycopy$O$I$O$I$I(this.selected, 0, newsel, 0, i);
System.arraycopy$O$I$O$I$I(this.selected, i + 1, newsel, i, this.selected.length - (i + 1));
this.selected=newsel;
return;
}}
});

Clazz.newMeth(C$, 'isIndexSelected$I', function (index) {
return this.isSelected$I(index);
});

Clazz.newMeth(C$, 'isSelected$I', function (index) {
var sel=this.getSelectedIndexes$();
for (var i=0; i < sel.length; i++) {
if (sel[i] == index) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'getRows$', function () {
return this.rows;
});

Clazz.newMeth(C$, 'isMultipleMode$', function () {
return this.allowsMultipleSelections$();
});

Clazz.newMeth(C$, 'allowsMultipleSelections$', function () {
return this.multipleMode;
});

Clazz.newMeth(C$, 'setMultipleMode$Z', function (b) {
this.setMultipleSelections$Z(b);
});

Clazz.newMeth(C$, 'setMultipleSelections$Z', function (b) {
if (b != this.multipleMode ) {
this.multipleMode=b;
var peer=this.peer;
if (peer != null ) {
peer.setMultipleMode$Z(b);
}}});

Clazz.newMeth(C$, 'getVisibleIndex$', function () {
return this.visibleIndex;
});

Clazz.newMeth(C$, 'makeVisible$I', function (index) {
this.visibleIndex=index;
var peer=this.peer;
if (peer != null ) {
peer.makeVisible$I(index);
}});

Clazz.newMeth(C$, 'getPreferredSize$I', function (rows) {
return this.preferredSize$I(rows);
});

Clazz.newMeth(C$, 'preferredSize$I', function (rows) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
var peer=this.peer;
return (peer != null ) ? peer.getPreferredSize$I(rows) : C$.superclazz.prototype.preferredSize$.apply(this, []);
}});

Clazz.newMeth(C$, 'getPreferredSize$', function () {
return this.preferredSize$();
});

Clazz.newMeth(C$, 'preferredSize$', function () {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
return (this.rows > 0) ? this.preferredSize$I(this.rows) : C$.superclazz.prototype.preferredSize$.apply(this, []);
}});

Clazz.newMeth(C$, 'getMinimumSize$I', function (rows) {
return this.minimumSize$I(rows);
});

Clazz.newMeth(C$, 'minimumSize$I', function (rows) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
var peer=this.peer;
return (peer != null ) ? peer.getMinimumSize$I(rows) : C$.superclazz.prototype.minimumSize$.apply(this, []);
}});

Clazz.newMeth(C$, 'getMinimumSize$', function () {
return this.minimumSize$();
});

Clazz.newMeth(C$, 'minimumSize$', function () {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getTreeLock$());
{
return (this.rows > 0) ? this.minimumSize$I(this.rows) : C$.superclazz.prototype.minimumSize$.apply(this, []);
}});

Clazz.newMeth(C$, 'addItemListener$java_awt_event_ItemListener', function (l) {
if (l == null ) {
return;
}this.itemListener=Clazz.load('java.awt.AWTEventMulticaster').add$java_awt_event_ItemListener$java_awt_event_ItemListener(this.itemListener, l);
this.newEventsOnly=true;
});

Clazz.newMeth(C$, 'removeItemListener$java_awt_event_ItemListener', function (l) {
if (l == null ) {
return;
}this.itemListener=$I$(3).remove$java_awt_event_ItemListener$java_awt_event_ItemListener(this.itemListener, l);
});

Clazz.newMeth(C$, 'getItemListeners$', function () {
return this.getListeners$Class(Clazz.getClass(Clazz.load('java.awt.event.ItemListener'),['itemStateChanged$java_awt_event_ItemEvent']));
});

Clazz.newMeth(C$, 'addActionListener$java_awt_event_ActionListener', function (l) {
if (l == null ) {
return;
}this.actionListener=$I$(3).add$java_awt_event_ActionListener$java_awt_event_ActionListener(this.actionListener, l);
this.newEventsOnly=true;
});

Clazz.newMeth(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
if (l == null ) {
return;
}this.actionListener=$I$(3).remove$java_awt_event_ActionListener$java_awt_event_ActionListener(this.actionListener, l);
});

Clazz.newMeth(C$, 'getActionListeners$', function () {
return this.getListeners$Class(Clazz.getClass(Clazz.load('java.awt.event.ActionListener'),['actionPerformed$java_awt_event_ActionEvent']));
});

Clazz.newMeth(C$, 'getListeners$Class', function (listenerType) {
var l=null;
if (listenerType === Clazz.getClass($I$(5),['actionPerformed$java_awt_event_ActionEvent']) ) {
l=this.actionListener;
} else if (listenerType === Clazz.getClass($I$(4),['itemStateChanged$java_awt_event_ItemEvent']) ) {
l=this.itemListener;
} else {
return C$.superclazz.prototype.getListeners$Class.apply(this, [listenerType]);
}return $I$(3).getListeners$java_util_EventListener$Class(l, listenerType);
});

Clazz.newMeth(C$, 'eventEnabled$java_awt_AWTEvent', function (e) {
switch (e.id) {
case 1001:
if ((this.eventMask & 128) != 0 || this.actionListener != null  ) {
return true;
}return false;
case 701:
if ((this.eventMask & 512) != 0 || this.itemListener != null  ) {
return true;
}return false;
default:
break;
}
return C$.superclazz.prototype.eventEnabled$java_awt_AWTEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'processEvent$java_awt_AWTEvent', function (e) {
if (Clazz.instanceOf(e, "java.awt.event.ItemEvent")) {
this.processItemEvent$java_awt_event_ItemEvent(e);
return;
} else if (Clazz.instanceOf(e, "java.awt.event.ActionEvent")) {
this.processActionEvent$java_awt_event_ActionEvent(e);
return;
}C$.superclazz.prototype.processEvent$java_awt_AWTEvent.apply(this, [e]);
});

Clazz.newMeth(C$, 'processItemEvent$java_awt_event_ItemEvent', function (e) {
var listener=this.itemListener;
if (listener != null ) {
listener.itemStateChanged$(e);
}});

Clazz.newMeth(C$, 'processActionEvent$java_awt_event_ActionEvent', function (e) {
var listener=this.actionListener;
if (listener != null ) {
listener.actionPerformed$(e);
}});

Clazz.newMeth(C$, 'paramString$', function () {
return C$.superclazz.prototype.paramString$.apply(this, []) + ",selected=" + this.getSelectedItem$() ;
});

Clazz.newMeth(C$, 'delItems$I$I', function (start, end) {
for (var i=end; i >= start; i--) {
this.items.removeElementAt$I(i);
}
var peer=this.peer;
if (peer != null ) {
peer.delItems$I$I(start, end);
}});
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-21 05:10:45 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
