(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
//Created 2018-06-29 13:46:47
