(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
//Created 2018-06-25 14:15:55
