(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newClass(P$, "UnsupportedFlavorException", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_datatransfer_DataFlavor', function (flavor) {
C$.superclazz.c$$S.apply(this, [(flavor != null ) ? flavor.getHumanPresentableName() : null]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-03 04:34:12
