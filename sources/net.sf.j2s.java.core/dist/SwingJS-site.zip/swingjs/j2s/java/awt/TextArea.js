(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "TextArea", null, 'swingjs.a2s.TextArea');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (rows, columns) {
C$.superclazz.c$$I$I.apply(this, [rows, columns]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I$I', function (text, rows, columns) {
C$.superclazz.c$$S$I$I.apply(this, [text, rows, columns]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I$I$I', function (text, rows, columns, scrollbars) {
C$.superclazz.c$$S$I$I$I.apply(this, [text, rows, columns, scrollbars]);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-05-15 18:39:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
