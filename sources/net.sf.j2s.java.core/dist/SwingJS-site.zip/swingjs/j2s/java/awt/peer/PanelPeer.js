(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "PanelPeer", null, null, 'java.awt.peer.LightweightPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-02 08:48:51
