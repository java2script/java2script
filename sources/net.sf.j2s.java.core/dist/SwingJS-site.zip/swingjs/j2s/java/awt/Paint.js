(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Paint", null, null, 'java.awt.Transparency');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-04 12:36:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
