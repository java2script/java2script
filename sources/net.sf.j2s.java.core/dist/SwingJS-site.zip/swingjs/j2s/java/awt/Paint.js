(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Paint", null, null, 'java.awt.Transparency');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-03 04:34:09
