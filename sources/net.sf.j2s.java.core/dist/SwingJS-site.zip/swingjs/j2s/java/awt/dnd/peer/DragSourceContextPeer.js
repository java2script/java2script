(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
//Created 2018-06-24 06:15:10
