(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
//Created 2018-07-02 08:48:45
