(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
//Created 2018-07-06 06:23:18
