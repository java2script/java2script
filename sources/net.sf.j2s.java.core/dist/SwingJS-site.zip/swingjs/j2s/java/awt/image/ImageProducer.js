(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageProducer");
})();
//Created 2018-07-03 06:24:56
