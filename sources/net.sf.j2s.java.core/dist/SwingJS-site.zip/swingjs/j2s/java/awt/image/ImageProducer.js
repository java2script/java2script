(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ImageProducer");
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-01-18 07:39:12 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
