(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ComponentListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-01-17 16:59:08 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
