(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "CompositeContext");
})();
//Created 2018-06-23 07:12:17
