(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "CompositeContext");
})();
//Created 2018-06-29 13:46:41
