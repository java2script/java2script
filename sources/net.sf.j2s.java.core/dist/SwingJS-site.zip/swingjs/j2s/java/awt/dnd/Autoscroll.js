(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
var C$=Clazz.newInterface(P$, "Autoscroll");
})();
//Created 2018-07-03 09:26:52
