(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
var C$=Clazz.newInterface(P$, "Autoscroll");
})();
//Created 2018-06-23 07:12:26
