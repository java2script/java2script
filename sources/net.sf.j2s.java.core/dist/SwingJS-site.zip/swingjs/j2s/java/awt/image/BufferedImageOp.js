(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
//Created 2018-06-26 10:03:17
