(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
//Created 2018-06-24 05:58:47
