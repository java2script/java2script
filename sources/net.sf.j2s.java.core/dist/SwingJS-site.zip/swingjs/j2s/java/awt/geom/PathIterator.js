(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathIterator");
})();
//Created 2018-06-24 05:58:46
