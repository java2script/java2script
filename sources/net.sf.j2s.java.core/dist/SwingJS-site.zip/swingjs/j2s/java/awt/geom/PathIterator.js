(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathIterator");
})();
//Created 2018-06-27 09:44:10
