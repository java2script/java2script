(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathIterator");
})();
//Created 2018-07-03 04:34:18
