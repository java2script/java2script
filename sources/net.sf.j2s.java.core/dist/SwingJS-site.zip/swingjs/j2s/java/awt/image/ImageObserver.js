(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageObserver");
})();
//Created 2018-07-06 06:23:21
