(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "FlavorTable", null, null, 'java.awt.datatransfer.FlavorMap');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-03 09:26:51
