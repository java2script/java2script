(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FlavorTable", null, null, 'java.awt.datatransfer.FlavorMap');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-10 13:57:30 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
