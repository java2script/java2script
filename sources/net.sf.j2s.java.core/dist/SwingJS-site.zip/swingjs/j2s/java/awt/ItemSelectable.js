(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ItemSelectable");
})();
//Created 2018-07-03 04:34:08
