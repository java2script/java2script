(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ItemSelectable");
})();
//Created 2018-06-25 14:15:53
