(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Adjustable");
})();
//Created 2018-06-29 13:46:40
