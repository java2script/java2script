(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Adjustable");
})();
//Created 2018-07-04 04:47:24
