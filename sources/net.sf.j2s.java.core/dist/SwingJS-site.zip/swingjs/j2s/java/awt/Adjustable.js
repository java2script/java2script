(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Adjustable");
})();
//Created 2018-06-24 05:58:31
