(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RenderedImage");
})();
//Created 2018-06-22 06:02:39
