(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RenderedImage");
})();
//Created 2018-06-26 10:03:20
