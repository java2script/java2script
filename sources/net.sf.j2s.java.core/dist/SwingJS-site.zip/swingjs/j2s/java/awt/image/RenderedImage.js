(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderedImage");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-20 12:13:16 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
