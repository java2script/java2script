(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RenderedImage");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-09-04 12:36:13 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
