(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "LightweightPeer", null, null, 'java.awt.peer.ContainerPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-03 07:59:12
