(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
//Created 2018-06-25 10:56:55
