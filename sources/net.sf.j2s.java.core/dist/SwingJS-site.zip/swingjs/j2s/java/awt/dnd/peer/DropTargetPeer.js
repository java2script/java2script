(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
//Created 2018-07-03 06:24:50
