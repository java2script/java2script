(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-03-23 13:02:41 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
