(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
//Created 2018-06-22 06:02:33
