(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
//Created 2018-06-26 10:03:21
