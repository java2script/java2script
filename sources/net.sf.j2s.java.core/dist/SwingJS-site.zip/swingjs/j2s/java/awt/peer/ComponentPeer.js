(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
//Created 2018-07-03 06:24:58
