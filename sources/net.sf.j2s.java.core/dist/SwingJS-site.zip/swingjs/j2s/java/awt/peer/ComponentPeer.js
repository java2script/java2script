(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
//Created 2018-07-06 06:23:21
