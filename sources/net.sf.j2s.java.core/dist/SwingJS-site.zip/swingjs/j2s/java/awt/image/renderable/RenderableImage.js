(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
var C$=Clazz.newInterface(P$, "RenderableImage");
})();
//Created 2018-06-29 13:46:54
