(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
var C$=Clazz.newInterface(P$, "RenderableImage");
})();
//Created 2018-06-24 06:15:16
