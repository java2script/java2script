(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
var C$=Clazz.newInterface(P$, "RenderableImage");
})();
//Created 2018-07-04 04:47:44
