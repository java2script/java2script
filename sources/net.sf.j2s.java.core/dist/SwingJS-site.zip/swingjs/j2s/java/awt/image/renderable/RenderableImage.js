(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
var C$=Clazz.newInterface(P$, "RenderableImage");
})();
//Created 2018-07-06 15:26:00
