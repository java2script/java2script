(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "GridLayout", null, null, ['java.awt.LayoutManager', 'java.io.Serializable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hgap = 0;
this.vgap = 0;
this.rows = 0;
this.cols = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I$I$I.apply(this, [1, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (rows, cols) {
C$.c$$I$I$I$I.apply(this, [rows, cols, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I', function (rows, cols, hgap, vgap) {
C$.$init$.apply(this);
if ((rows == 0) && (cols == 0) ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["rows and cols cannot both be zero"]);
}this.rows=rows;
this.cols=cols;
this.hgap=hgap;
this.vgap=vgap;
}, 1);

Clazz.newMeth(C$, 'getRows', function () {
return this.rows;
});

Clazz.newMeth(C$, 'setRows$I', function (rows) {
if ((rows == 0) && (this.cols == 0) ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["rows and cols cannot both be zero"]);
}this.rows=rows;
});

Clazz.newMeth(C$, 'getColumns', function () {
return this.cols;
});

Clazz.newMeth(C$, 'setColumns$I', function (cols) {
if ((cols == 0) && (this.rows == 0) ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["rows and cols cannot both be zero"]);
}this.cols=cols;
});

Clazz.newMeth(C$, 'getHgap', function () {
return this.hgap;
});

Clazz.newMeth(C$, 'setHgap$I', function (hgap) {
this.hgap=hgap;
});

Clazz.newMeth(C$, 'getVgap', function () {
return this.vgap;
});

Clazz.newMeth(C$, 'setVgap$I', function (vgap) {
this.vgap=vgap;
});

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (parent) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (parent) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (parent) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/});

Clazz.newMeth(C$, 'toString', function () {
return this.getClass().getName() + "[hgap=" + this.hgap + ",vgap=" + this.vgap + ",rows=" + this.rows + ",cols=" + this.cols + "]" ;
});
})();
//Created 2018-06-25 10:56:51
