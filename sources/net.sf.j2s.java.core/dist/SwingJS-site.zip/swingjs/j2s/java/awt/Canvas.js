(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "Canvas", null, 'swingjs.a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (config) {
C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this, [config]);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.4.06');//Created 2019-01-28 12:15:48 Java2ScriptVisitor version 3.2.4.06 net.sf.j2s.core.jar version 3.2.4.06
