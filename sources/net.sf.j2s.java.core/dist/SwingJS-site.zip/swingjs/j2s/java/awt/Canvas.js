(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Canvas", null, 'swingjs.a2s.Canvas');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration',  function (config) {
;C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this,[config]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-27 18:07:59 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
