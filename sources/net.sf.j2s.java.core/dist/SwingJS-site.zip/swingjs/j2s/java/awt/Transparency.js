(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Transparency");
})();
//Created 2018-06-26 10:03:06
