(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
var C$=Clazz.newClass(P$, "LineMetrics");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-06-24 09:51:41
