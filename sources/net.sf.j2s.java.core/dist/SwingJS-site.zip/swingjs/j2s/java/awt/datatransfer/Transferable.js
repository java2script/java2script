(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "Transferable");
})();
//Created 2018-06-27 09:44:05
