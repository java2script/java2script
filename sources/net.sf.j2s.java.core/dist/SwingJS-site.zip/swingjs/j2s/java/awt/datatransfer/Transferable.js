(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "Transferable");
})();
//Created 2018-07-02 08:48:44
