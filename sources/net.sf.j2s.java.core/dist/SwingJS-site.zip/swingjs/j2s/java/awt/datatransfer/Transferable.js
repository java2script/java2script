(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "Transferable");
})();
//Created 2018-06-24 06:15:08
