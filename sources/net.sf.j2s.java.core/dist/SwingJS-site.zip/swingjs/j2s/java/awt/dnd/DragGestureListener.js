(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DragGestureListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-01-17 16:59:07 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
