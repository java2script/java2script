(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "TypeVariable", null, null, 'java.lang.reflect.Type');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-07-22 21:38:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
