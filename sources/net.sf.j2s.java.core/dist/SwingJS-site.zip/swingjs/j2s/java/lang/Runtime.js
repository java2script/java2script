(function(){var P$=java.lang,I$=[['java.lang.Runtime','Shutdown','java.lang.RuntimePermission','ApplicationShutdownHooks','java.util.StringTokenizer','java.io.File','java.lang.UnsatisfiedLinkError']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(java.lang, "Runtime");
C$.currentRuntime = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.currentRuntime = Clazz.new_((I$[1]||$incl$(1)));
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getRuntime', function () {
return Runtime.currentRuntime;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'exit$I', function (status) {
var security = System.getSecurityManager();
if (security != null ) {
security.checkExit$I(status);
}(I$[2]||$incl$(2)).exit$I(status);
});

Clazz.newMeth(C$, 'addShutdownHook$Thread', function (hook) {
var sm = System.getSecurityManager();
if (sm != null ) {
sm.checkPermission$java_security_Permission(Clazz.new_((I$[3]||$incl$(3)).c$$S,["shutdownHooks"]));
}(I$[4]||$incl$(4)).add$Thread(hook);
});

Clazz.newMeth(C$, 'removeShutdownHook$Thread', function (hook) {
var sm = System.getSecurityManager();
if (sm != null ) {
sm.checkPermission$java_security_Permission(Clazz.new_((I$[3]||$incl$(3)).c$$S,["shutdownHooks"]));
}return (I$[4]||$incl$(4)).remove$Thread(hook);
});

Clazz.newMeth(C$, 'halt$I', function (status) {
var sm = System.getSecurityManager();
if (sm != null ) {
sm.checkExit$I(status);
}(I$[2]||$incl$(2)).halt$I(status);
});

Clazz.newMeth(C$, 'runFinalizersOnExit$Z', function (value) {
var security = System.getSecurityManager();
if (security != null ) {
try {
security.checkExit$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.SecurityException")){
throw Clazz.new_(Clazz.load('java.lang.SecurityException').c$$S,["runFinalizersOnExit"]);
} else {
throw e;
}
}
}(I$[2]||$incl$(2)).setRunFinalizersOnExit$Z(value);
}, 1);

Clazz.newMeth(C$, 'exec$S', function (command) {
return this.exec$S$SA$java_io_File(command, null, null);
});

Clazz.newMeth(C$, 'exec$S$SA', function (command, envp) {
return this.exec$S$SA$java_io_File(command, envp, null);
});

Clazz.newMeth(C$, 'exec$S$SA$java_io_File', function (command, envp, dir) {
if (command.length$() == 0) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Empty command"]);
var st = Clazz.new_((I$[5]||$incl$(5)).c$$S,[command]);
var cmdarray = Clazz.array(java.lang.String, [st.countTokens()]);
for (var i = 0; st.hasMoreTokens(); i++) cmdarray[i]=st.nextToken();

return this.exec$SA$SA$java_io_File(cmdarray, envp, dir);
});

Clazz.newMeth(C$, 'exec$SA', function (cmdarray) {
return this.exec$SA$SA$java_io_File(cmdarray, null, null);
});

Clazz.newMeth(C$, 'exec$SA$SA', function (cmdarray, envp) {
return this.exec$SA$SA$java_io_File(cmdarray, envp, null);
});

Clazz.newMeth(C$, 'exec$SA$SA$java_io_File', function (cmdarray, envp, dir) {

alert("Runtime.exec is not implemented. "+cmdarray[0]);
return null;
});

Clazz.newMeth(C$, 'availableProcessors', function () {
return 2147483647;
});

Clazz.newMeth(C$, 'freeMemory', function () {
return 2147483647;
});

Clazz.newMeth(C$, 'totalMemory', function () {
return 2147483647;
});

Clazz.newMeth(C$, 'maxMemory', function () {
return 2147483647;
});

Clazz.newMeth(C$, 'gc', function () {
});

Clazz.newMeth(C$, 'runFinalization0', function () {
}, 1);

Clazz.newMeth(C$, 'runFinalization', function () {
Runtime.runFinalization0();
});

Clazz.newMeth(C$, 'traceInstructions$Z', function (on) {
});

Clazz.newMeth(C$, 'traceMethodCalls$Z', function (on) {
});

Clazz.newMeth(C$, 'load$S', function (filename) {
this.load0$Class$S(null, filename);
});

Clazz.newMeth(C$, 'load0$Class$S', function (fromClass, filename) {
if (!(Clazz.new_((I$[6]||$incl$(6)).c$$S,[filename]).isAbsolute())) {
throw Clazz.new_((I$[7]||$incl$(7)).c$$S,["Expecting an absolute path of the library: " + filename]);
}ClassLoader.loadLibrary$Class$S$Z(fromClass, filename, true);
});

Clazz.newMeth(C$, 'loadLibrary$S', function (libname) {
this.loadLibrary0$Class$S(null, libname);
});

Clazz.newMeth(C$, 'loadLibrary0$Class$S', function (fromClass, libname) {
if (libname.indexOf((I$[6]||$incl$(6)).separatorChar.$c()) != -1) {
throw Clazz.new_((I$[7]||$incl$(7)).c$$S,["Directory separator should not appear in library name: " + libname]);
}ClassLoader.loadLibrary$Class$S$Z(fromClass, libname, false);
});

Clazz.newMeth(C$, 'getLocalizedInputStream$java_io_InputStream', function ($in) {
return $in;
});

Clazz.newMeth(C$, 'getLocalizedOutputStream$java_io_OutputStream', function (out) {
return out;
});
})();
//Created 2018-06-22 06:02:45
