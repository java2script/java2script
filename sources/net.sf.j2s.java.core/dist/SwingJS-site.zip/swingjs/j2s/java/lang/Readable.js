(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Readable");
})();
//Created 2018-06-29 13:47:00
