(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Readable");
})();
//Created 2018-07-03 06:25:05
