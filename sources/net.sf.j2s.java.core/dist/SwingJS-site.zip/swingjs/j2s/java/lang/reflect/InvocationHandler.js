(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "InvocationHandler");
})();
//Created 2018-06-29 13:47:01
