(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newClass(P$, "Constructor", null, 'java.lang.reflect.AccessibleObject', ['java.lang.reflect.GenericDeclaration', 'java.lang.reflect.Member']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.Class_ = null;
this.parameterTypes = null;
this.exceptionTypes = null;
this.modifiers = 0;
this.signature = null;
this.constr = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$Class$ClassA$ClassA$I', function (declaringClass, parameterTypes, checkedExceptions, modifiers) {
Clazz.super_(C$, this,1);
this.Class_=declaringClass;
this.parameterTypes=parameterTypes;
this.exceptionTypes=checkedExceptions;
this.modifiers=modifiers;
this.signature="c$";
if (";Integer;Long;Short;Byte;Float;Double;".indexOf(";" + declaringClass.getName() + ";" ) >= 0) parameterTypes=null;
this.parameterTypes=parameterTypes;
if (parameterTypes != null ) {
for (var i = 0; i < parameterTypes.length; i++) {
var code = null;
this.signature += "$" + code;
}
}this.constr=this.Class_.$clazz$[this.signature] ||null;
}, 1);

Clazz.newMeth(C$, 'getTypeParameters', function () {
return null;
});

Clazz.newMeth(C$, 'toGenericString', function () {
return null;
});

Clazz.newMeth(C$, 'getGenericParameterTypes', function () {
return null;
});

Clazz.newMeth(C$, 'getGenericExceptionTypes', function () {
return null;
});

Clazz.newMeth(C$, 'getParameterAnnotations', function () {
return null;
});

Clazz.newMeth(C$, 'isVarArgs', function () {
return false;
});

Clazz.newMeth(C$, 'isSynthetic', function () {
return false;
});

Clazz.newMeth(C$, 'equals$O', function (object) {
if (object != null  && Clazz.instanceOf(object, "java.lang.reflect.Constructor") ) {
var other = object;
if (this.getDeclaringClass() === other.getDeclaringClass() ) {
var params1 = this.parameterTypes;
var params2 = other.parameterTypes;
if (params1.length == params2.length) {
for (var i = 0; i < params1.length; i++) {
if (params1[i] !== params2[i] ) return false;
}
return true;
}}}return false;
});

Clazz.newMeth(C$, 'getDeclaringClass', function () {
return this.Class_;
});

Clazz.newMeth(C$, 'getExceptionTypes', function () {
return this.exceptionTypes;
});

Clazz.newMeth(C$, 'getModifiers', function () {
return this.modifiers;
});

Clazz.newMeth(C$, 'getName', function () {
return this.getDeclaringClass().getName();
});

Clazz.newMeth(C$, 'getParameterTypes', function () {
return this.parameterTypes;
});

Clazz.newMeth(C$, 'hashCode', function () {
return this.getDeclaringClass().getName().hashCode();
});

Clazz.newMeth(C$, 'newInstance$OA', function (args) {
{
var instance = null;
if (this.constr) { var a = (args ? new Array(args.length) : []);
if (args) { for (var i = args.length; --i >= 0;) { a[i] = (this.parameterTypes[i].__PRIMITIVE ? args[i].valueOf() : args[i]);
} } var instance = Clazz.new_(this.constr, a);
} if (instance == null) newMethodNotFoundException(this.Class_.$clazz$, this.signature);
return instance;
}
});

Clazz.newMeth(C$, 'toString', function () {
return this.Class_.getName() + "." + this.signature ;
});
})();
//Created 2018-07-21 04:25:33 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
