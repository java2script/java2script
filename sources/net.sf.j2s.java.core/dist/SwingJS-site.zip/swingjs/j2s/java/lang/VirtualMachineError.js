(function(){var P$=java.lang,I$=[];
var C$=Clazz.newClass(P$, "VirtualMachineError", null, 'Error');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$$S.apply(this, [message]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Throwable', function (message, cause) {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$$S$Throwable.apply(this, [message, cause]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$Throwable', function (cause) {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$$Throwable.apply(this, [cause]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-13 09:29:45 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
