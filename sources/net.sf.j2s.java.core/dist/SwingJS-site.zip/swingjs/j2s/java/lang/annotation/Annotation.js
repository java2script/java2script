(function(){var P$=java.lang.annotation,I$=[];
var C$=Clazz.newInterface(P$, "Annotation");
})();
//Created 2018-06-26 10:03:33
