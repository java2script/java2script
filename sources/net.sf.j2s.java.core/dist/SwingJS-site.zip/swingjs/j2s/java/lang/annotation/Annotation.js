(function(){var P$=java.lang.annotation,I$=[];
var C$=Clazz.newInterface(P$, "Annotation");
})();
//Created 2018-06-19 10:02:51
