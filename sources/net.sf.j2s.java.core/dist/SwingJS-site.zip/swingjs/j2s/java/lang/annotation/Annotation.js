(function(){var P$=java.lang.annotation,I$=[];
var C$=Clazz.newInterface(P$, "Annotation");
})();
//Created 2018-07-03 09:27:09
