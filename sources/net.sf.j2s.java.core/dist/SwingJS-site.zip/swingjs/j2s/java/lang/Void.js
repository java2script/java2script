(function(){var P$=java.lang,I$=[];
var C$=Clazz.newClass(java.lang, "Void");
C$.TYPE = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.TYPE = null;
{

java.lang.Void.TYPE = java.lang.Void;
}
;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-06-23 07:12:48
