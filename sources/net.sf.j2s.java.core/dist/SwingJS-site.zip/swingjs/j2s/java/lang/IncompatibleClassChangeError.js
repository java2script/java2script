(function(){var P$=java.lang,I$=[];
var C$=Clazz.newClass(P$, "IncompatibleClassChangeError", null, 'LinkageError');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (s) {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$$S.apply(this, [s]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-13 09:29:41 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
