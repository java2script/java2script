(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "AnnotatedElement");

Clazz.newMeth(C$, 'isAnnotationPresent$Class', function (annotationClass) {
return this.getAnnotation$Class(annotationClass) != null ;
});

Clazz.newMeth(C$, 'getAnnotationsByType$Class', function (annotationClass) {
return null;
});

Clazz.newMeth(C$, 'getDeclaredAnnotation$Class', function (annotationClass) {
return null;
});

Clazz.newMeth(C$, 'getDeclaredAnnotationsByType$Class', function (annotationClass) {
return null;
});
})();
//Created 2018-07-22 21:38:54 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
