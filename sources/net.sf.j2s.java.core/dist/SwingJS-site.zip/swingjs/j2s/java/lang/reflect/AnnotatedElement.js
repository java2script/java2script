(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "AnnotatedElement");
})();
//Created 2018-06-25 11:48:53
