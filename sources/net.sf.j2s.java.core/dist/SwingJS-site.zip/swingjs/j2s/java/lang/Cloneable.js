(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Cloneable");
})();
//Created 2018-06-25 10:57:07
