(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Cloneable");
})();
//Created 2018-07-03 09:27:07
