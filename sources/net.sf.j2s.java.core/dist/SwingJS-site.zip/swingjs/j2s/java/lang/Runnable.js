(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Runnable");
})();
//Created 2018-06-19 10:02:50
