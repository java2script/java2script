(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "CharSequence");
})();
//Created 2018-06-24 06:15:19
