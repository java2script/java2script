(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "CharSequence");
})();
//Created 2018-06-25 14:16:12
