(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "CharSequence");
})();
//Created 2018-07-02 08:48:56
