(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "GenericDeclaration");
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-22 06:04:25 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
