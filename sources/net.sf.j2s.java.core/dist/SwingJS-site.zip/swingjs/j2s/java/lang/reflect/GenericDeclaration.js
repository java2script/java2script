(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "GenericDeclaration");
})();
//Created 2018-07-03 04:34:32
