(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "GenericDeclaration");
})();
//Created 2018-07-03 06:25:07
