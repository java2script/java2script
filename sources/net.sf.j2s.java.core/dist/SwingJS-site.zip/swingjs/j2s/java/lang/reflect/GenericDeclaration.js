(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "GenericDeclaration");
})();
//Created 2018-07-02 08:48:58
