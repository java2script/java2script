(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newClass(P$, "Modifier");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isAbstract$I', function (modifiers) {
return ((modifiers & 1024) != 0);
}, 1);

Clazz.newMeth(C$, 'isFinal$I', function (modifiers) {
return ((modifiers & 16) != 0);
}, 1);

Clazz.newMeth(C$, 'isInterface$I', function (modifiers) {
return ((modifiers & 512) != 0);
}, 1);

Clazz.newMeth(C$, 'isNative$I', function (modifiers) {
return ((modifiers & 256) != 0);
}, 1);

Clazz.newMeth(C$, 'isPrivate$I', function (modifiers) {
return ((modifiers & 2) != 0);
}, 1);

Clazz.newMeth(C$, 'isProtected$I', function (modifiers) {
return ((modifiers & 4) != 0);
}, 1);

Clazz.newMeth(C$, 'isPublic$I', function (modifiers) {
return ((modifiers & 1) != 0);
}, 1);

Clazz.newMeth(C$, 'isStatic$I', function (modifiers) {
return ((modifiers & 8) != 0);
}, 1);

Clazz.newMeth(C$, 'isStrict$I', function (modifiers) {
return ((modifiers & 2048) != 0);
}, 1);

Clazz.newMeth(C$, 'isSynchronized$I', function (modifiers) {
return ((modifiers & 32) != 0);
}, 1);

Clazz.newMeth(C$, 'isTransient$I', function (modifiers) {
return ((modifiers & 128) != 0);
}, 1);

Clazz.newMeth(C$, 'isVolatile$I', function (modifiers) {
return ((modifiers & 64) != 0);
}, 1);

Clazz.newMeth(C$, 'toString$I', function (modifiers) {
var sb = Clazz.array(java.lang.String, [0]);
if (P$.Modifier.isPublic$I(modifiers)) sb[sb.length]="public";
if (P$.Modifier.isProtected$I(modifiers)) sb[sb.length]="protected";
if (P$.Modifier.isPrivate$I(modifiers)) sb[sb.length]="private";
if (P$.Modifier.isAbstract$I(modifiers)) sb[sb.length]="abstract";
if (P$.Modifier.isStatic$I(modifiers)) sb[sb.length]="static";
if (P$.Modifier.isFinal$I(modifiers)) sb[sb.length]="final";
if (P$.Modifier.isTransient$I(modifiers)) sb[sb.length]="transient";
if (P$.Modifier.isVolatile$I(modifiers)) sb[sb.length]="volatile";
if (P$.Modifier.isSynchronized$I(modifiers)) sb[sb.length]="synchronized";
if (P$.Modifier.isNative$I(modifiers)) sb[sb.length]="native";
if (P$.Modifier.isStrict$I(modifiers)) sb[sb.length]="strictfp";
if (P$.Modifier.isInterface$I(modifiers)) sb[sb.length]="interface";
if (sb.length > 0) {
return sb.join (" ");
}
return "";
}, 1);
})();
;Clazz.setTVer('3.2.2.03');//Created 2018-08-09 14:39:34 Java2ScriptVisitor version 3.2.2.03 net.sf.j2s.core.jar version 3.2.2.03
