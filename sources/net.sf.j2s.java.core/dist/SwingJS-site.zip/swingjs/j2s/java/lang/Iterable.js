(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Iterable");
})();
//Created 2018-06-24 09:51:51
