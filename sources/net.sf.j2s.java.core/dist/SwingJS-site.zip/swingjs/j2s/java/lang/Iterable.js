(function(){var P$=java.lang,I$=[['java.util.Objects','java.util.Spliterators']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newInterface(java.lang, "Iterable");

Clazz.newMeth(C$, 'forEach$java_util_function_Consumer', function (action) {
(I$[1]||$incl$(1)).requireNonNull$TT(action);
for (var t, $t = this.iterator$(); $t.hasNext$()&&((t=($t.next$())),1);) {
action.accept$(t);
}
});

Clazz.newMeth(C$, 'spliterator$', function () {
return (I$[2]||$incl$(2)).spliteratorUnknownSize$java_util_Iterator$I(this.iterator$(), 0);
});
})();
;Clazz.setTVer('3.2.2.01');//Created 2018-07-30 17:44:18 Jav2ScriptVisitor version 3.2.2.01 net.sf.j2s.core.jar version 3.2.2.01
