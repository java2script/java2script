(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Iterable");
})();
//Created 2018-06-27 09:44:18
