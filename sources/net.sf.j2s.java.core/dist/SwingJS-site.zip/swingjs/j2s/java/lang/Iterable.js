(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Iterable");
})();
//Created 2018-06-22 06:02:44
