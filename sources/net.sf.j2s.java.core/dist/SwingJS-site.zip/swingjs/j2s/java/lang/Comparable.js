(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Comparable");
})();
//Created 2018-06-24 09:51:50
