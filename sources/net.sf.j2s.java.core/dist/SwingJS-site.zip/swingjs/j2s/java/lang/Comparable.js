(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Comparable");
})();
//Created 2018-06-25 14:16:13
