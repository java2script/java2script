(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Appendable");
})();
//Created 2018-07-04 04:47:48
