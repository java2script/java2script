(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Appendable");
})();
//Created 2018-06-25 10:57:06
