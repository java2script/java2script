(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Appendable");
})();
//Created 2018-06-23 07:12:43
