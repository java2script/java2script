(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Appendable");
})();
//Created 2018-07-02 08:48:55
