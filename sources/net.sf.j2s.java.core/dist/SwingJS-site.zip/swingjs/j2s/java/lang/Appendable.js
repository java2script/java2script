(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Appendable");
})();
//Created 2018-06-24 05:58:55
