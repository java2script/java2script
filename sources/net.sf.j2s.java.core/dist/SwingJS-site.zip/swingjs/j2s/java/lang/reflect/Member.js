(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "Member");
})();
//Created 2018-06-19 10:02:51
