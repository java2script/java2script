(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "Member");
})();
//Created 2018-06-24 09:51:52
