(function(){var P$=Clazz.newPackage("java.math"),I$=[];
var C$=Clazz.newClass(P$, "BigDecimal");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 21:38:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
