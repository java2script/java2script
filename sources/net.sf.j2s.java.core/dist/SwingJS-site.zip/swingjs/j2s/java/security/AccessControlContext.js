(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "AccessControlContext");
})();
//Created 2018-06-29 13:47:02
