(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "AccessControlContext");
})();
//Created 2018-06-22 06:02:47
