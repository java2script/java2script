(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "AccessControlContext");
})();
//Created 2018-07-20 08:34:01 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
