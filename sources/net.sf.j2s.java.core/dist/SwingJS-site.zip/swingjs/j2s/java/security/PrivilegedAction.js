(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "PrivilegedAction");
})();
//Created 2018-06-25 11:48:54
