(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "PrivilegedAction");
})();
//Created 2018-06-24 05:59:00
