(function(){var P$=Clazz.newPackage("java.net"),I$=[];
var C$=Clazz.newInterface(P$, "URLStreamHandlerFactory");
})();
//Created 2018-07-03 04:34:33
