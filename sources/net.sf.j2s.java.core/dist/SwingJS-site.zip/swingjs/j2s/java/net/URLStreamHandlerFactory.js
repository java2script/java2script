(function(){var P$=Clazz.newPackage("java.net"),I$=[];
var C$=Clazz.newInterface(P$, "URLStreamHandlerFactory");
})();
//Created 2018-06-24 05:59:00
