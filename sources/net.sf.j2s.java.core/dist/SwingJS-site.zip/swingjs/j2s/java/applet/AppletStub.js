(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
//Created 2018-06-23 07:12:15
