(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
//Created 2018-06-25 14:15:46
