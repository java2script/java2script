(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
//Created 2018-07-06 06:23:12
