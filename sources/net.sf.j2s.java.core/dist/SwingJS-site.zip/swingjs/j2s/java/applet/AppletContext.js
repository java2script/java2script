(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletContext");
})();
//Created 2018-07-03 04:34:02
