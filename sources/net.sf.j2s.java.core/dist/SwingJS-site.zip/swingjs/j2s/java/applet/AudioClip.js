(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AudioClip");
})();
//Created 2018-07-04 04:47:23
