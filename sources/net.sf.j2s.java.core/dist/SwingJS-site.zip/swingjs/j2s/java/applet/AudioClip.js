(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AudioClip");
})();
;Clazz.setTVer('5.0.1-v2');//Created 2023-12-16 00:57:04 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
