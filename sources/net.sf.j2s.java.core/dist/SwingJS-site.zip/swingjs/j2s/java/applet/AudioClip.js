(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AudioClip");
})();
//Created 2018-06-24 05:58:30
