(function(){var P$=java.io,I$=[[0,'java.util.concurrent.atomic.AtomicInteger']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "FileDescriptor");
C$.$in = null;
C$.out = null;
C$.err = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.$in = Clazz.new_(C$.c$$I,[0]);
C$.out = Clazz.new_(C$.c$$I,[1]);
C$.err = Clazz.new_(C$.c$$I,[2]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fd = 0;
this.useCount = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.fd=-1;
this.useCount=Clazz.new_($I$(1));
}, 1);

Clazz.newMeth(C$, 'c$$I', function (fd) {
C$.$init$.apply(this);
this.fd=fd;
this.useCount=Clazz.new_($I$(1));
}, 1);

Clazz.newMeth(C$, 'valid$', function () {
return this.fd != -1;
});

Clazz.newMeth(C$, 'incrementAndGetUseCount$', function () {
return this.useCount.incrementAndGet$();
});

Clazz.newMeth(C$, 'decrementAndGetUseCount$', function () {
return this.useCount.decrementAndGet$();
});
})();
;Clazz.setTVer('3.2.2.03');//Created 2018-08-09 14:39:30 Java2ScriptVisitor version 3.2.2.03 net.sf.j2s.core.jar version 3.2.2.03
