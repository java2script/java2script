(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Flushable");
})();
//Created 2018-07-06 15:26:01
