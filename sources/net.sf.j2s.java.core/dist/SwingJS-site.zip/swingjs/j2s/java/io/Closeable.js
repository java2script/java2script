(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Closeable");
})();
//Created 2018-06-27 09:44:15
