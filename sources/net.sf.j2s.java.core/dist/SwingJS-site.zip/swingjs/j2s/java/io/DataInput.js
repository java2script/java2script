(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataInput");
})();
//Created 2018-07-03 04:34:24
