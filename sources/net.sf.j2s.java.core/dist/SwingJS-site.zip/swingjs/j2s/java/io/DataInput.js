(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataInput");
})();
//Created 2018-06-22 06:02:41
