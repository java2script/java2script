(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataInput");
})();
//Created 2018-07-03 09:27:03
