(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "FilenameFilter");
})();
//Created 2018-06-23 07:12:41
