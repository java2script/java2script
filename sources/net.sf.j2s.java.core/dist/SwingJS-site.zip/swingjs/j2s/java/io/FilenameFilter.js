(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "FilenameFilter");
})();
//Created 2018-06-24 06:15:18
