(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "FilenameFilter");
})();
//Created 2018-07-04 04:47:47
