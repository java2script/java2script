(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Serializable");
})();
//Created 2018-07-06 06:23:24
