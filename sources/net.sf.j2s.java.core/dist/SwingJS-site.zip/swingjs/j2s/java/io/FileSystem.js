(function(){var P$=java.io,I$=[];
var C$=Clazz.newClass(P$, "FileSystem");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getFileSystem', function () {
return Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'getSeparator', function () {
return "/";
});

Clazz.newMeth(C$, 'getPathSeparator', function () {
return "/";
});

Clazz.newMeth(C$);
})();
//Created 2018-07-22 04:33:23 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
