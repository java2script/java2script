(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataOutput");
})();
//Created 2018-06-23 07:12:40
