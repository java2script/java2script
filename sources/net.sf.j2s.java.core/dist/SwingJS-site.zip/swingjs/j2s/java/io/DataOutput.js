(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataOutput");
})();
//Created 2018-06-29 13:46:57
