(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataOutput");
})();
//Created 2018-07-03 07:59:14
