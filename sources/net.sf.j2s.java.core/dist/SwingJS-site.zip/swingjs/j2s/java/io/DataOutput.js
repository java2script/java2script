(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataOutput");
})();
//Created 2018-06-25 10:57:04
