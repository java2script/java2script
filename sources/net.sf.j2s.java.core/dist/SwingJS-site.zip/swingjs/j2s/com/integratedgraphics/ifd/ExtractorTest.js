(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd"),I$=[[0,'com.integratedgraphics.ifd.Extractor','java.io.File','org.iupac.fairdata.contrib.fairspec.FAIRSpecUtilities','org.iupac.fairdata.common.IFDConst']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExtractorTest", null, 'com.integratedgraphics.ifd.Extractor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['createFindingAidJSONList','stopOnAnyFailure','debugReadOnly'],'I',['first','last'],'S',['$sourceDir'],'O',['testSet','String[]']]]

Clazz.newMeth(C$, 'c$$S$java_io_File$java_io_File$S',  function (key, ifdExtractScriptFile, targetDir, localSourceDir) {
Clazz.super_(C$, this);
this.log$S("!ExtractorTest\n ifdExtractScriptFIle= " + ifdExtractScriptFile + "\n localSourceDir = " + localSourceDir + "\n targetDir = " + targetDir.getAbsolutePath$() );
var findingAidFileName=(key == null  ? "" : key);
if (C$.superclazz.prototype.extractAndCreateFindingAid$java_io_File$S$java_io_File$S.apply(this, [ifdExtractScriptFile, localSourceDir, targetDir, findingAidFileName]) == null  && !$I$(1).allowNoPubInfo ) {
throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["Test failed"]);
}this.log$S("!ExtractorTest extracted " + this.manifestCount + " files (" + Long.$s(this.extractedByteCount) + " bytes)" + "; ignored " + this.ignoredCount + " files (" + Long.$s(this.ignoredByteCount) + " bytes)" );
}, 1);

Clazz.newMeth(C$, 'runExtractionTests$I$I$S$S$SA',  function (first, last, targetDir, sourceDir, args) {
var i0=first;
var i1=Math.max(first, last);
var failed=0;
var key=null;
var fname;
switch (args.length) {
default:
case 3:
sourceDir=args[2];
case 2:
targetDir=args[1];
case 1:
fname=args[0];
break;
case 0:
fname=null;
}
$I$(1,"logStatic$S",["ExtractorTest.runExtractionTests output to " + Clazz.new_($I$(2,1).c$$S,[targetDir]).getAbsolutePath$()]);
Clazz.new_($I$(2,1).c$$S,[targetDir]).mkdirs$();
var json="";
$I$(3).setLogging$S(targetDir + "/extractor.log");
$I$(1).errorLog="";
var n=0;
var job=null;
for (var itest=(args.length == 0 ? i0 : 0); itest <= (args.length == 0 ? i1 : 0); itest++) {
$I$(1).testID=itest;
if (args.length == 0) {
job=key=C$.testSet[itest];
$I$(1).logStatic$S("ExtractorTest.runExtractionTests found Test " + itest + " " + job );
var pt=key.indexOf$S("/");
if (pt >= 0) key=key.substring$I$I(0, pt);
fname="./extract/" + key + "/IFD-extract.json" ;
}if (json.length$() == 0) {
json="{\"findingaids\":[\n";
} else {
json+=",\n";
}++n;
json+="\"" + key + "\"" ;
var t0=System.currentTimeMillis$();
try {
var ifdExtractScriptFile=Clazz.new_($I$(2,1).c$$S,[fname]);
var targetPath=Clazz.new_($I$(2,1).c$$S,[targetDir]);
var sourcePath=Clazz.new_($I$(2,1).c$$S,[sourceDir]).getAbsolutePath$();
Clazz.new_(C$.c$$S$java_io_File$java_io_File$S,[key, ifdExtractScriptFile, targetPath, sourcePath]);
$I$(1).logStatic$S("ExtractorTest.runExtractionTests ok " + key);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
++failed;
System.err.println$S("ExtractorTest.runExtractionTests Exception " + e + " for test " + itest );
e.printStackTrace$();
if (C$.stopOnAnyFailure) break;
} else {
throw e;
}
}
$I$(1,"logStatic$S",["!!ExtractorTest.runExtractionTests job " + job + " time/sec=" + new Double((Long.$sub(System.currentTimeMillis$(),t0)) / 1000.0).toString() ]);
}
$I$(1,"logStatic$S",["!! DONE total=" + n + " failed=" + failed ]);
json+="\n]}\n";
try {
if (C$.createFindingAidJSONList && !$I$(1).readOnly ) {
var f=Clazz.new_($I$(2,1).c$$S,[targetDir + "/_IFD_findingaids.json"]);
$I$(3,"writeBytesToFile$BA$java_io_File",[json.getBytes$(), f]);
$I$(1,"logStatic$S",["ExtractorTest.runExtractionTests File " + f.getAbsolutePath$() + " created \n" + json ]);
} else {
$I$(1).logStatic$S("ExtractorTest.runExtractionTests _IFD_findingaids.json was not created for\n" + json);
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
$I$(1).logStatic$S("");
System.out.flush$();
System.err.println$S($I$(1).errorLog);
System.err.flush$();
var flags="\n first = " + first + " last = " + last + "\n stopOnAnyFailure = " + C$.stopOnAnyFailure + "\n debugging = " + $I$(1).debugging + " readOnly = " + $I$(1).readOnly + " debugReadOnly = " + C$.debugReadOnly + "\n allowNoPubInfo = " + $I$(1).allowNoPubInfo + " skipPubInfo = " + $I$(1).skipPubInfo + "\n sourceDir = " + sourceDir + " targetDir = " + targetDir + "\n createZippedCollection = " + $I$(1).createZippedCollection + " createFindingAidJSONList = " + C$.createFindingAidJSONList + "\n IFD version " + $I$(4).IFD_VERSION + "\n" ;
System.err.flush$();
$I$(1).logStatic$S("!ExtractorTest.runExtractionTests flags " + flags);
$I$(1).logStatic$S("!ExtractorText done");
$I$(3).setLogging$S(null);
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.$sourceDir="c:/temp/iupac/zip";
C$.debugReadOnly=false;
$I$(1).addPublicationMetadata=false;
var dataciteUp=true;
$I$(1).createZippedCollection=!C$.debugReadOnly;
C$.createFindingAidJSONList=!C$.debugReadOnly;
C$.stopOnAnyFailure=true;
$I$(1).readOnly=C$.debugReadOnly;
$I$(1).debugging=false;
$I$(1).createFindingAidsOnly=false;
$I$(1).allowNoPubInfo=true;
$I$(1).skipPubInfo=!dataciteUp || C$.debugReadOnly ;
if (C$.first == C$.last) {
C$.createFindingAidJSONList=false;
}var targetDir="./site/ifd";
if (targetDir != null ) Clazz.new_($I$(2,1).c$$S,[targetDir]).mkdir$();
C$.runExtractionTests$I$I$S$S$SA(C$.first, C$.last, targetDir, C$.$sourceDir, args);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.first=0;
C$.last=0;
C$.testSet=Clazz.array(String, -1, ["acs.joc.0c00770/22567817", "acs.orglett.0c00624/21947274", "acs.orglett.0c00788/22125318", "acs.orglett.0c00874/22233351", "acs.orglett.0c00967/22111341", "acs.orglett.0c01022/22195341", "acs.orglett.0c01197/22491647", "acs.orglett.0c01277/22613762", "acs.orglett.0c01297/22612484", "acs.orglett.0c00755/22150197", "acs.orglett.0c01153/22284726,22284729", "acs.orglett.0c00571/21975525", "acs.orglett.0c01043/22232721"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-05-01 05:25:53 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
