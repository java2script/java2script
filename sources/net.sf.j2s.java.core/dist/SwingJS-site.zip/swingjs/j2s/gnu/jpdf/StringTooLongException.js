(function(){var P$=Clazz.newPackage("gnu.jpdf"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "StringTooLongException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['msg']]]

Clazz.newMeth(C$, 'c$$S',  function (msg) {
Clazz.super_(C$, this);
this.msg=msg;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return this.msg;
});

Clazz.newMeth(C$, 'getMessage$',  function () {
return this.msg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2023-12-16 00:57:03 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
