(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Transferable");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-02-23 09:51:07 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
