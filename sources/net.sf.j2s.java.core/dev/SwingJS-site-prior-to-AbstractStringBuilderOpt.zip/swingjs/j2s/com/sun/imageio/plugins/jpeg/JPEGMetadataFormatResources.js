(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.jpeg"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JPEGMetadataFormatResources", null, 'java.util.ListResourceBundle');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['commonContents','Object[][]']]]

C$.$static$=function(){C$.$static$=0;
C$.commonContents=Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["dqt", "A Define Quantization Table(s) marker segment"]), Clazz.array(java.lang.Object, -1, ["dqtable", "A single quantization table"]), Clazz.array(java.lang.Object, -1, ["dht", "A Define Huffman Table(s) marker segment"]), Clazz.array(java.lang.Object, -1, ["dhtable", "A single Huffman table"]), Clazz.array(java.lang.Object, -1, ["dri", "A Define Restart Interval marker segment"]), Clazz.array(java.lang.Object, -1, ["com", "A Comment marker segment.  The user object contains the actual bytes."]), Clazz.array(java.lang.Object, -1, ["unknown", "An unrecognized marker segment.  The user object contains the data not including length."]), Clazz.array(java.lang.Object, -1, ["dqtable/elementPrecision", "The number of bits in each table element (0 = 8, 1 = 16)"]), Clazz.array(java.lang.Object, -1, ["dgtable/qtableId", "The table id"]), Clazz.array(java.lang.Object, -1, ["dhtable/class", "Indicates whether this is a DC (0) or an AC (1) table"]), Clazz.array(java.lang.Object, -1, ["dhtable/htableId", "The table id"]), Clazz.array(java.lang.Object, -1, ["dri/interval", "The restart interval in MCUs"]), Clazz.array(java.lang.Object, -1, ["com/comment", "The comment as a string (used only if user object is null)"]), Clazz.array(java.lang.Object, -1, ["unknown/MarkerTag", "The tag identifying this marker segment"])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-02-23 09:50:50 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
