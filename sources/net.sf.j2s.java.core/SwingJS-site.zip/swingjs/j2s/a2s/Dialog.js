(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Dialog", null, 'javax.swing.JDialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$a2s_Frame$S$Z', function (c, title, isModal) {
C$.superclazz.c$$java_awt_Frame$S$Z.apply(this, [c, title, isModal]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-05-24 08:44:59
