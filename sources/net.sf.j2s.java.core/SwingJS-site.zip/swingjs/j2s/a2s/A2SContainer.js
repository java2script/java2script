(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newInterface(P$, "A2SContainer");
})();
//Created 2018-05-21 09:05:49
