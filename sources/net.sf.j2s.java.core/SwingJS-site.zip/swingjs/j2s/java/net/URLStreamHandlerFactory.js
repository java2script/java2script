(function(){var P$=Clazz.newPackage("java.net"),I$=[];
var C$=Clazz.newInterface(P$, "URLStreamHandlerFactory");
})();
//Created 2018-02-24 16:54:51
