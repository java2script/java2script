(function(){var P$=Clazz.newPackage("java.net"),I$=[];
var C$=Clazz.newInterface(P$, "URLStreamHandlerFactory");
})();
//Created 2018-05-21 09:06:21
