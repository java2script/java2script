(function(){var P$=Clazz.newPackage("java.net"),I$=[];
var C$=Clazz.newInterface(P$, "URLStreamHandlerFactory");
})();
//Created 2018-03-14 22:51:18
