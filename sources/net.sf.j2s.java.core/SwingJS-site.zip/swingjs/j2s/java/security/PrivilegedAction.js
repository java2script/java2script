(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "PrivilegedAction");
})();
//Created 2018-05-21 09:06:21
