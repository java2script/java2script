(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "PrivilegedAction");
})();
//Created 2018-02-22 01:09:38
