(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "PrivilegedAction");
})();
//Created 2018-03-14 22:51:18
