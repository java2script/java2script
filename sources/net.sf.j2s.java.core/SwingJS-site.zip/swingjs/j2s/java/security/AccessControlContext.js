(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "AccessControlContext");
})();
//Created 2018-02-25 18:53:06
