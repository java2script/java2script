(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Externalizable", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-25 18:52:57
