(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Externalizable", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-08 10:02:04
