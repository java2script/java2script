(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Flushable");
})();
//Created 2018-03-14 22:51:12
