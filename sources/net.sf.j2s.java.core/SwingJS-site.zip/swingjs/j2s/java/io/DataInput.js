(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataInput");
})();
//Created 2018-05-21 09:06:15
