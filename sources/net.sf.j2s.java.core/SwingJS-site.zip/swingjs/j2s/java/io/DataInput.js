(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataInput");
})();
//Created 2018-02-24 16:54:46
