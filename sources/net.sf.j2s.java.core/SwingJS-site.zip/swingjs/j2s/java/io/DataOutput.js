(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "DataOutput");
})();
//Created 2018-02-25 18:52:57
