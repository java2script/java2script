(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Closeable");
})();
//Created 2018-05-15 01:02:04
