(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "FilenameFilter");
})();
//Created 2018-05-20 23:54:17
