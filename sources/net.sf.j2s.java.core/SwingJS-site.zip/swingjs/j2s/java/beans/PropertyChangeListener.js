(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyChangeListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-22 01:09:28
