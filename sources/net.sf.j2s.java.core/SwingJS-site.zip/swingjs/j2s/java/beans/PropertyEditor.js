(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
//Created 2018-02-16 11:29:01
