(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
//Created 2018-05-15 01:01:48
