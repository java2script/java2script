(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
//Created 2018-05-20 23:53:56
