(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AudioClip");
})();
//Created 2018-03-03 22:34:05
