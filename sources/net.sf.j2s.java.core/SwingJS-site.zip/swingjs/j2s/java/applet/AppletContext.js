(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletContext");
})();
//Created 2018-02-08 10:01:45
