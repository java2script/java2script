(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-05-20 23:54:08
