(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "KeyListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-22 01:09:18
