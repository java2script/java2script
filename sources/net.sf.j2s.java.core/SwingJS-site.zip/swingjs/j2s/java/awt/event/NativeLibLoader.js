(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newClass(P$, "NativeLibLoader");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'loadLibraries', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-25 18:52:49
