(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newClass(P$, "HierarchyBoundsAdapter", null, null, 'java.awt.event.HierarchyBoundsListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'ancestorMoved$java_awt_event_HierarchyEvent', function (e) {
});

Clazz.newMeth(C$, 'ancestorResized$java_awt_event_HierarchyEvent', function (e) {
});

Clazz.newMeth(C$);
})();
//Created 2018-05-15 01:01:57
