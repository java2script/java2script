(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Composite");
})();
//Created 2018-05-15 01:01:49
