(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
var C$=Clazz.newInterface(P$, "Printable");
C$.PAGE_EXISTS = 0;
C$.NO_SUCH_PAGE = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.PAGE_EXISTS = 0;
C$.NO_SUCH_PAGE = 1;
}
})();
//Created 2018-02-25 18:52:55
