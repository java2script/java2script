(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "Transferable");
})();
//Created 2018-02-22 01:09:15
