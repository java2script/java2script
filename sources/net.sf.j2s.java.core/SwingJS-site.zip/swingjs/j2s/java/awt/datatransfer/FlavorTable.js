(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "FlavorTable", null, null, 'java.awt.datatransfer.FlavorMap');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-05-24 08:45:14
