(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "FlavorMap");
})();
//Created 2018-05-15 01:01:55
