(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
//Created 2018-05-20 23:54:05
