(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
//Created 2018-02-16 11:28:22
