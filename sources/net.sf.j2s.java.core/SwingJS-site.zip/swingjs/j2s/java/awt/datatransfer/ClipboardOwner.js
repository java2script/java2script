(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
//Created 2018-05-15 01:01:54
