(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
//Created 2018-05-15 01:01:56
