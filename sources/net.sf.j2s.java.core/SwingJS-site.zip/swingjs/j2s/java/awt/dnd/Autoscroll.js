(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
var C$=Clazz.newInterface(P$, "Autoscroll");
})();
//Created 2018-02-24 16:54:38
