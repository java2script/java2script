(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "WindowPeer", null, null, 'java.awt.peer.ContainerPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-03-16 05:15:34
