(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ContainerPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-24 16:54:45
