(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DialogPeer", null, null, 'java.awt.peer.WindowPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-05-15 01:02:02
