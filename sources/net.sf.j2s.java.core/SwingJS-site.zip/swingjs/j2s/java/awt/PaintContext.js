(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "PaintContext");
})();
//Created 2018-03-14 22:50:58
