(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "LayoutManager");
})();
//Created 2018-05-15 01:01:52
