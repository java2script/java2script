(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "LayoutManager");
})();
//Created 2018-03-03 22:34:11
