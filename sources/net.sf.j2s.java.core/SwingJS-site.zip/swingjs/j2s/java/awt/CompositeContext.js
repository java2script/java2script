(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "CompositeContext");
})();
//Created 2018-05-21 09:05:58
