(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "CompositeContext");
})();
//Created 2018-02-22 01:09:05
