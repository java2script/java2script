(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Adjustable");
})();
//Created 2018-05-20 23:53:56
