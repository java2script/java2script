(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "PrintJob");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'finalize', function () {
this.end();
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:54:36
