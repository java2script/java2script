(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Conditional");
})();
//Created 2018-03-16 05:15:02
