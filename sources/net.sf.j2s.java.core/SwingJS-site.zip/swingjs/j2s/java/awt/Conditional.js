(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Conditional");
})();
//Created 2018-02-08 10:01:47
