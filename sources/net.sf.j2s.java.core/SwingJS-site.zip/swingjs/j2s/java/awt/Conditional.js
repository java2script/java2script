(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Conditional");
})();
//Created 2018-02-25 18:52:38
