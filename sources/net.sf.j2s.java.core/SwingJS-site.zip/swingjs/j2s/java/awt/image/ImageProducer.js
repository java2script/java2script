(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageProducer");
})();
//Created 2018-05-21 09:06:12
