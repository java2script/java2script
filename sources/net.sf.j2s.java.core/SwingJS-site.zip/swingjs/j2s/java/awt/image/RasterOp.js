(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RasterOp");
})();
//Created 2018-03-03 22:34:24
