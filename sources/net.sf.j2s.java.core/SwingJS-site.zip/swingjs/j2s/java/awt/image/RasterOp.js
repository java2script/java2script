(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RasterOp");
})();
//Created 2018-05-20 23:54:14
