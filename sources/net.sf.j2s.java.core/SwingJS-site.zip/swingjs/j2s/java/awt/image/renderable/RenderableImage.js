(function(){var P$=Clazz.newPackage("java.awt.image.renderable"),I$=[];
var C$=Clazz.newInterface(P$, "RenderableImage");
})();
//Created 2018-05-21 09:06:13
