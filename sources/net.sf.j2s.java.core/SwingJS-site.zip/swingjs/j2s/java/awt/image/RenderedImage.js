(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RenderedImage");
})();
//Created 2018-05-24 08:45:27
