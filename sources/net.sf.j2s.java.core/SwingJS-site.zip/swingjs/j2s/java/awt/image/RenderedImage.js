(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RenderedImage");
})();
//Created 2018-02-16 11:28:54
