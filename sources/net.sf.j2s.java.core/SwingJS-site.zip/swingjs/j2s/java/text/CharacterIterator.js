(function(){var P$=Clazz.newPackage("java.text"),I$=[];
var C$=Clazz.newInterface(P$, "CharacterIterator", null, null, 'Cloneable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-16 11:29:30
