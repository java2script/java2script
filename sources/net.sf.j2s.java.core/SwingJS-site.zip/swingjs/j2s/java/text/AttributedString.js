(function(){var P$=Clazz.newPackage("java.text"),I$=[['java.lang.InternalError','java.util.Hashtable',['java.text.AttributedString','.AttributeMap'],'java.util.HashSet','java.text.AttributeEntry','java.lang.StringBuffer','java.util.Vector',['java.text.AttributedString','.AttributedStringIterator']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AttributedString", function(){
Clazz.newInstance(this, arguments,0,C$);
});
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.text = null;
this.runArraySize = 0;
this.runCount = 0;
this.runStarts = null;
this.runAttributes = null;
this.runAttributeValues = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_text_AttributedCharacterIteratorA', function (iterators) {
C$.$init$.apply(this);
if (iterators == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException').c$$S,["Iterators must not be null"]);
}if (iterators.length == 0) {
this.text = "";
} else {
var buffer = Clazz.new_((I$[6]||$incl$(6)));
for (var counter = 0; counter < iterators.length; counter++) {
p$.appendContents$StringBuffer$java_text_CharacterIterator.apply(this, [buffer, iterators[counter]]);
}
this.text = buffer.toString();
if (this.text.length$() > 0) {
var offset = 0;
var last = null;
for (var counter = 0; counter < iterators.length; counter++) {
var iterator = iterators[counter];
var start = iterator.getBeginIndex();
var end = iterator.getEndIndex();
var index = start;
while (index < end){
iterator.setIndex$I(index);
var attrs = iterator.getAttributes();
if (C$.mapsDiffer$java_util_Map$java_util_Map(last, attrs)) {
p$.setAttributes$java_util_Map$I.apply(this, [attrs, index - start + offset]);
}last = attrs;
index = iterator.getRunLimit();
}
offset = offset+((end - start));
}
}}}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.$init$.apply(this);
if (text == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}this.text = text;
}, 1);

Clazz.newMeth(C$, 'c$$S$java_util_Map', function (text, attributes) {
C$.$init$.apply(this);
if (text == null  || attributes == null  ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}this.text = text;
if (text.length$() == 0) {
if (attributes.isEmpty()) return;
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Can\'t add attribute to 0-length text"]);
}var attributeCount = attributes.size();
if (attributeCount > 0) {
p$.createRunAttributeDataVectors.apply(this, []);
var newRunAttributes = Clazz.new_((I$[7]||$incl$(7)).c$$I,[attributeCount]);
var newRunAttributeValues = Clazz.new_((I$[7]||$incl$(7)).c$$I,[attributeCount]);
this.runAttributes[0] = newRunAttributes;
this.runAttributeValues[0] = newRunAttributeValues;
var iterator = attributes.entrySet().iterator();
while (iterator.hasNext()){
var entry = iterator.next();
newRunAttributes.addElement$TE(entry.getKey());
newRunAttributeValues.addElement$TE(entry.getValue());
}
}}, 1);

Clazz.newMeth(C$, 'c$$java_text_AttributedCharacterIterator', function (text) {
C$.c$$java_text_AttributedCharacterIterator$I$I$java_text_AttributedCharacterIterator_AttributeA.apply(this, [text, text.getBeginIndex(), text.getEndIndex(), null]);
}, 1);

Clazz.newMeth(C$, 'c$$java_text_AttributedCharacterIterator$I$I', function (text, beginIndex, endIndex) {
C$.c$$java_text_AttributedCharacterIterator$I$I$java_text_AttributedCharacterIterator_AttributeA.apply(this, [text, beginIndex, endIndex, null]);
}, 1);

Clazz.newMeth(C$, 'c$$java_text_AttributedCharacterIterator$I$I$java_text_AttributedCharacterIterator_AttributeA', function (text, beginIndex, endIndex, attributes) {
C$.$init$.apply(this);
if (text == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}var textBeginIndex = text.getBeginIndex();
var textEndIndex = text.getEndIndex();
if (beginIndex < textBeginIndex || endIndex > textEndIndex  || beginIndex > endIndex ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid substring range"]);
var textBuffer = Clazz.new_((I$[6]||$incl$(6)));
text.setIndex$I(beginIndex);
for (var c = text.current(); text.getIndex() < endIndex; c = text.next()) textBuffer.append$C(c);

this.text = textBuffer.toString();
if (beginIndex == endIndex) return;
var keys = Clazz.new_((I$[4]||$incl$(4)));
if (attributes == null ) {
keys.addAll$java_util_Collection(text.getAllAttributeKeys());
} else {
for (var i = 0; i < attributes.length; i++) keys.add$TE(attributes[i]);

keys.retainAll$java_util_Collection(text.getAllAttributeKeys());
}if (keys.isEmpty()) return;
var itr = keys.iterator();
while (itr.hasNext()){
var attributeKey = itr.next();
text.setIndex$I(textBeginIndex);
while (text.getIndex() < endIndex){
var start = text.getRunStart$java_text_AttributedCharacterIterator_Attribute(attributeKey);
var limit = text.getRunLimit$java_text_AttributedCharacterIterator_Attribute(attributeKey);
var value = text.getAttribute$java_text_AttributedCharacterIterator_Attribute(attributeKey);
if (value != null ) {
if (Clazz.instanceOf(value, "java.text.Annotation")) {
if (start >= beginIndex && limit <= endIndex ) {
this.addAttribute$java_text_AttributedCharacterIterator_Attribute$O$I$I(attributeKey, value, start - beginIndex, limit - beginIndex);
} else {
if (limit > endIndex) break;
}} else {
if (start >= endIndex) break;
if (limit > beginIndex) {
if (start < beginIndex) start = beginIndex;
if (limit > endIndex) limit = endIndex;
if (start != limit) {
this.addAttribute$java_text_AttributedCharacterIterator_Attribute$O$I$I(attributeKey, value, start - beginIndex, limit - beginIndex);
}}}}text.setIndex$I(limit);
}
}
}, 1);

Clazz.newMeth(C$, 'addAttribute$java_text_AttributedCharacterIterator_Attribute$O', function (attribute, value) {
if (attribute == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}var len = this.length$();
if (len == 0) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Can\'t add attribute to 0-length text"]);
}p$.addAttributeImpl$java_text_AttributedCharacterIterator_Attribute$O$I$I.apply(this, [attribute, value, 0, len]);
});

Clazz.newMeth(C$, 'addAttribute$java_text_AttributedCharacterIterator_Attribute$O$I$I', function (attribute, value, beginIndex, endIndex) {
if (attribute == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}if (beginIndex < 0 || endIndex > this.length$()  || beginIndex >= endIndex ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid substring range"]);
}p$.addAttributeImpl$java_text_AttributedCharacterIterator_Attribute$O$I$I.apply(this, [attribute, value, beginIndex, endIndex]);
});

Clazz.newMeth(C$, 'addAttributes$java_util_Map$I$I', function (attributes, beginIndex, endIndex) {
if (attributes == null ) {
throw Clazz.new_(Clazz.load('java.lang.NullPointerException'));
}if (beginIndex < 0 || endIndex > this.length$()  || beginIndex > endIndex ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid substring range"]);
}if (beginIndex == endIndex) {
if (attributes.isEmpty()) return;
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Can\'t add attribute to 0-length text"]);
}if (this.runCount == 0) {
p$.createRunAttributeDataVectors.apply(this, []);
}var beginRunIndex = p$.ensureRunBreak$I.apply(this, [beginIndex]);
var endRunIndex = p$.ensureRunBreak$I.apply(this, [endIndex]);
var iterator = attributes.entrySet().iterator();
while (iterator.hasNext()){
var entry = iterator.next();
p$.addAttributeRunData$java_text_AttributedCharacterIterator_Attribute$O$I$I.apply(this, [entry.getKey(), entry.getValue(), beginRunIndex, endRunIndex]);
}
});

Clazz.newMeth(C$, 'addAttributeImpl$java_text_AttributedCharacterIterator_Attribute$O$I$I', function (attribute, value, beginIndex, endIndex) {
if (this.runCount == 0) {
p$.createRunAttributeDataVectors.apply(this, []);
}var beginRunIndex = p$.ensureRunBreak$I.apply(this, [beginIndex]);
var endRunIndex = p$.ensureRunBreak$I.apply(this, [endIndex]);
p$.addAttributeRunData$java_text_AttributedCharacterIterator_Attribute$O$I$I.apply(this, [attribute, value, beginRunIndex, endRunIndex]);
});

Clazz.newMeth(C$, 'createRunAttributeDataVectors', function () {
var newRunStarts = Clazz.array(Integer.TYPE, [10]);
var newRunAttributes = Clazz.array((I$[7]||$incl$(7)), [10]);
var newRunAttributeValues = Clazz.array((I$[7]||$incl$(7)), [10]);
this.runStarts = newRunStarts;
this.runAttributes = newRunAttributes;
this.runAttributeValues = newRunAttributeValues;
this.runArraySize = 10;
this.runCount = 1;
});

Clazz.newMeth(C$, 'ensureRunBreak$I', function (offset) {
return p$.ensureRunBreak$I$Z.apply(this, [offset, true]);
});

Clazz.newMeth(C$, 'ensureRunBreak$I$Z', function (offset, copyAttrs) {
if (offset == this.length$()) {
return this.runCount;
}var runIndex = 0;
while (runIndex < this.runCount && this.runStarts[runIndex] < offset ){
runIndex++;
}
if (runIndex < this.runCount && this.runStarts[runIndex] == offset ) {
return runIndex;
}if (this.runCount == this.runArraySize) {
var newArraySize = this.runArraySize + 10;
var newRunStarts = Clazz.array(Integer.TYPE, [newArraySize]);
var newRunAttributes = Clazz.array((I$[7]||$incl$(7)), [newArraySize]);
var newRunAttributeValues = Clazz.array((I$[7]||$incl$(7)), [newArraySize]);
for (var i = 0; i < this.runArraySize; i++) {
newRunStarts[i] = this.runStarts[i];
newRunAttributes[i] = this.runAttributes[i];
newRunAttributeValues[i] = this.runAttributeValues[i];
}
this.runStarts = newRunStarts;
this.runAttributes = newRunAttributes;
this.runAttributeValues = newRunAttributeValues;
this.runArraySize = newArraySize;
}var newRunAttributes = null;
var newRunAttributeValues = null;
if (copyAttrs) {
var oldRunAttributes = this.runAttributes[runIndex - 1];
var oldRunAttributeValues = this.runAttributeValues[runIndex - 1];
if (oldRunAttributes != null ) {
newRunAttributes = oldRunAttributes.clone();
}if (oldRunAttributeValues != null ) {
newRunAttributeValues = oldRunAttributeValues.clone();
}}this.runCount++;
for (var i = this.runCount - 1; i > runIndex; i--) {
this.runStarts[i] = this.runStarts[i - 1];
this.runAttributes[i] = this.runAttributes[i - 1];
this.runAttributeValues[i] = this.runAttributeValues[i - 1];
}
this.runStarts[runIndex] = offset;
this.runAttributes[runIndex] = newRunAttributes;
this.runAttributeValues[runIndex] = newRunAttributeValues;
return runIndex;
});

Clazz.newMeth(C$, 'addAttributeRunData$java_text_AttributedCharacterIterator_Attribute$O$I$I', function (attribute, value, beginRunIndex, endRunIndex) {
for (var i = beginRunIndex; i < endRunIndex; i++) {
var keyValueIndex = -1;
if (this.runAttributes[i] == null ) {
var newRunAttributes = Clazz.new_((I$[7]||$incl$(7)));
var newRunAttributeValues = Clazz.new_((I$[7]||$incl$(7)));
this.runAttributes[i] = newRunAttributes;
this.runAttributeValues[i] = newRunAttributeValues;
} else {
keyValueIndex = this.runAttributes[i].indexOf$O(attribute);
}if (keyValueIndex == -1) {
var oldSize = this.runAttributes[i].size();
this.runAttributes[i].addElement$TE(attribute);
try {
this.runAttributeValues[i].addElement$TE(value);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
this.runAttributes[i].setSize$I(oldSize);
this.runAttributeValues[i].setSize$I(oldSize);
} else {
throw e;
}
}
} else {
this.runAttributeValues[i].set$I$TE(keyValueIndex, value);
}}
});

Clazz.newMeth(C$, 'getIterator', function () {
return this.getIterator$java_text_AttributedCharacterIterator_AttributeA$I$I(null, 0, this.length$());
});

Clazz.newMeth(C$, 'getIterator$java_text_AttributedCharacterIterator_AttributeA', function (attributes) {
return this.getIterator$java_text_AttributedCharacterIterator_AttributeA$I$I(attributes, 0, this.length$());
});

Clazz.newMeth(C$, 'getIterator$java_text_AttributedCharacterIterator_AttributeA$I$I', function (attributes, beginIndex, endIndex) {
return Clazz.new_((I$[8]||$incl$(8)).c$$java_text_AttributedCharacterIterator_AttributeA$I$I, [this, null, attributes, beginIndex, endIndex]);
});

Clazz.newMeth(C$, 'length$', function () {
return this.text.length$();
});

Clazz.newMeth(C$, 'charAt$I', function (index) {
return this.text.charAt(index);
});

Clazz.newMeth(C$, 'getAttribute$java_text_AttributedCharacterIterator_Attribute$I', function (attribute, runIndex) {
var currentRunAttributes = this.runAttributes[runIndex];
var currentRunAttributeValues = this.runAttributeValues[runIndex];
if (currentRunAttributes == null ) {
return null;
}var attributeIndex = currentRunAttributes.indexOf$O(attribute);
if (attributeIndex != -1) {
return currentRunAttributeValues.elementAt$I(attributeIndex);
} else {
return null;
}});

Clazz.newMeth(C$, 'getAttributeCheckRange$java_text_AttributedCharacterIterator_Attribute$I$I$I', function (attribute, runIndex, beginIndex, endIndex) {
var value = p$.getAttribute$java_text_AttributedCharacterIterator_Attribute$I.apply(this, [attribute, runIndex]);
if (Clazz.instanceOf(value, "java.text.Annotation")) {
if (beginIndex > 0) {
var currIndex = runIndex;
var runStart = this.runStarts[currIndex];
while (runStart >= beginIndex && C$.valuesMatch$O$O(value, p$.getAttribute$java_text_AttributedCharacterIterator_Attribute$I.apply(this, [attribute, currIndex - 1])) ){
currIndex--;
runStart = this.runStarts[currIndex];
}
if (runStart < beginIndex) {
return null;
}}var textLength = this.length$();
if (endIndex < textLength) {
var currIndex = runIndex;
var runLimit = (currIndex < this.runCount - 1) ? this.runStarts[currIndex + 1] : textLength;
while (runLimit <= endIndex && C$.valuesMatch$O$O(value, p$.getAttribute$java_text_AttributedCharacterIterator_Attribute$I.apply(this, [attribute, currIndex + 1])) ){
currIndex++;
runLimit = (currIndex < this.runCount - 1) ? this.runStarts[currIndex + 1] : textLength;
}
if (runLimit > endIndex) {
return null;
}}}return value;
});

Clazz.newMeth(C$, 'attributeValuesMatch$java_util_Set$I$I', function (attributes, runIndex1, runIndex2) {
var iterator = attributes.iterator();
while (iterator.hasNext()){
var key = iterator.next();
if (!C$.valuesMatch$O$O(p$.getAttribute$java_text_AttributedCharacterIterator_Attribute$I.apply(this, [key, runIndex1]), p$.getAttribute$java_text_AttributedCharacterIterator_Attribute$I.apply(this, [key, runIndex2]))) {
return false;
}}
return true;
});

Clazz.newMeth(C$, 'valuesMatch$O$O', function (value1, value2) {
if (value1 == null ) {
return value2 == null ;
} else {
return value1.equals$O(value2);
}}, 1);

Clazz.newMeth(C$, 'appendContents$StringBuffer$java_text_CharacterIterator', function (buf, iterator) {
var index = iterator.getBeginIndex();
var end = iterator.getEndIndex();
while (index < end){
iterator.setIndex$I(index++);
buf.append$C(iterator.current());
}
});

Clazz.newMeth(C$, 'setAttributes$java_util_Map$I', function (attrs, offset) {
if (this.runCount == 0) {
p$.createRunAttributeDataVectors.apply(this, []);
}var index = p$.ensureRunBreak$I$Z.apply(this, [offset, false]);
var size;
if (attrs != null  && (size = attrs.size()) > 0 ) {
var runAttrs = Clazz.new_((I$[7]||$incl$(7)).c$$I,[size]);
var runValues = Clazz.new_((I$[7]||$incl$(7)).c$$I,[size]);
var iterator = attrs.entrySet().iterator();
while (iterator.hasNext()){
var entry = iterator.next();
runAttrs.add$TE(entry.getKey());
runValues.add$TE(entry.getValue());
}
this.runAttributes[index] = runAttrs;
this.runAttributeValues[index] = runValues;
}});

Clazz.newMeth(C$, 'mapsDiffer$java_util_Map$java_util_Map', function (last, attrs) {
if (last == null ) {
return (attrs != null  && attrs.size() > 0 );
}return (!last.equals$O(attrs));
}, 1);
;
(function(){var C$=Clazz.newClass(P$.AttributedString, "AttributedStringIterator", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.text.AttributedCharacterIterator');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.beginIndex = 0;
this.endIndex = 0;
this.currentIndex = 0;
this.currentRunIndex = 0;
this.currentRunStart = 0;
this.currentRunLimit = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_text_AttributedCharacterIterator_AttributeA$I$I', function (attributes, beginIndex, endIndex) {
C$.$init$.apply(this);
if (beginIndex < 0 || beginIndex > endIndex  || endIndex > this.this$0.length$() ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid substring range"]);
}this.beginIndex = beginIndex;
this.endIndex = endIndex;
this.currentIndex = beginIndex;
p$.updateRunInfo.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'equals$O', function (obj) {
if (this === obj ) {
return true;
}if (!(Clazz.instanceOf(obj, "java.text.AttributedString.AttributedStringIterator"))) {
return false;
}var that = obj;
if (this.this$0 !== that.getString() ) return false;
if (this.currentIndex != that.currentIndex || this.beginIndex != that.beginIndex  || this.endIndex != that.endIndex ) return false;
return true;
});

Clazz.newMeth(C$, 'hashCode', function () {
return this.this$0.text.hashCode() ^ this.currentIndex ^ this.beginIndex ^ this.endIndex ;
});

Clazz.newMeth(C$, 'clone', function () {
try {
var other = Clazz.clone(this);
return other;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.CloneNotSupportedException")){
throw Clazz.new_((I$[1]||$incl$(1)));
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'first', function () {
return p$.internalSetIndex$I.apply(this, [this.beginIndex]);
});

Clazz.newMeth(C$, 'last', function () {
if (this.endIndex == this.beginIndex) {
return p$.internalSetIndex$I.apply(this, [this.endIndex]);
} else {
return p$.internalSetIndex$I.apply(this, [this.endIndex - 1]);
}});

Clazz.newMeth(C$, 'current', function () {
if (this.currentIndex == this.endIndex) {
return "\uffff";
} else {
return this.this$0.charAt$I.apply(this.this$0, [this.currentIndex]);
}});

Clazz.newMeth(C$, 'next', function () {
if (this.currentIndex < this.endIndex) {
return p$.internalSetIndex$I.apply(this, [this.currentIndex + 1]);
} else {
return "\uffff";
}});

Clazz.newMeth(C$, 'previous', function () {
if (this.currentIndex > this.beginIndex) {
return p$.internalSetIndex$I.apply(this, [this.currentIndex - 1]);
} else {
return "\uffff";
}});

Clazz.newMeth(C$, 'setIndex$I', function (position) {
if (position < this.beginIndex || position > this.endIndex ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid index"]);
return p$.internalSetIndex$I.apply(this, [position]);
});

Clazz.newMeth(C$, 'getBeginIndex', function () {
return this.beginIndex;
});

Clazz.newMeth(C$, 'getEndIndex', function () {
return this.endIndex;
});

Clazz.newMeth(C$, 'getIndex', function () {
return this.currentIndex;
});

Clazz.newMeth(C$, 'getRunStart', function () {
return this.currentRunStart;
});

Clazz.newMeth(C$, 'getRunStart$java_text_AttributedCharacterIterator_Attribute', function (attribute) {
if (this.currentRunStart == this.beginIndex || this.currentRunIndex == -1 ) {
return this.currentRunStart;
} else {
var value = this.getAttribute$java_text_AttributedCharacterIterator_Attribute(attribute);
var runStart = this.currentRunStart;
var runIndex = this.currentRunIndex;
while (runStart > this.beginIndex && P$.AttributedString.valuesMatch$O$O(value, this.this$0.getAttribute$java_text_AttributedCharacterIterator_Attribute$I(attribute, runIndex - 1)) ){
runIndex--;
runStart = this.this$0.runStarts[runIndex];
}
if (runStart < this.beginIndex) {
runStart = this.beginIndex;
}return runStart;
}});

Clazz.newMeth(C$, 'getRunStart$java_util_Set', function (attributes) {
if (this.currentRunStart == this.beginIndex || this.currentRunIndex == -1 ) {
return this.currentRunStart;
} else {
var runStart = this.currentRunStart;
var runIndex = this.currentRunIndex;
while (runStart > this.beginIndex && this.this$0.attributeValuesMatch$java_util_Set$I$I(attributes, this.currentRunIndex, runIndex - 1) ){
runIndex--;
runStart = this.this$0.runStarts[runIndex];
}
if (runStart < this.beginIndex) {
runStart = this.beginIndex;
}return runStart;
}});

Clazz.newMeth(C$, 'getRunLimit', function () {
return this.currentRunLimit;
});

Clazz.newMeth(C$, 'getRunLimit$java_text_AttributedCharacterIterator_Attribute', function (attribute) {
if (this.currentRunLimit == this.endIndex || this.currentRunIndex == -1 ) {
return this.currentRunLimit;
} else {
var value = this.getAttribute$java_text_AttributedCharacterIterator_Attribute(attribute);
var runLimit = this.currentRunLimit;
var runIndex = this.currentRunIndex;
while (runLimit < this.endIndex && P$.AttributedString.valuesMatch$O$O(value, this.this$0.getAttribute$java_text_AttributedCharacterIterator_Attribute$I(attribute, runIndex + 1)) ){
runIndex++;
runLimit = runIndex < this.this$0.runCount - 1 ? this.this$0.runStarts[runIndex + 1] : this.endIndex;
}
if (runLimit > this.endIndex) {
runLimit = this.endIndex;
}return runLimit;
}});

Clazz.newMeth(C$, 'getRunLimit$java_util_Set', function (attributes) {
if (this.currentRunLimit == this.endIndex || this.currentRunIndex == -1 ) {
return this.currentRunLimit;
} else {
var runLimit = this.currentRunLimit;
var runIndex = this.currentRunIndex;
while (runLimit < this.endIndex && this.this$0.attributeValuesMatch$java_util_Set$I$I(attributes, this.currentRunIndex, runIndex + 1) ){
runIndex++;
runLimit = runIndex < this.this$0.runCount - 1 ? this.this$0.runStarts[runIndex + 1] : this.endIndex;
}
if (runLimit > this.endIndex) {
runLimit = this.endIndex;
}return runLimit;
}});

Clazz.newMeth(C$, 'getAttributes', function () {
if (this.this$0.runAttributes == null  || this.currentRunIndex == -1  || this.this$0.runAttributes[this.currentRunIndex] == null  ) {
return Clazz.new_((I$[2]||$incl$(2)));
}return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I, [this, null, this.currentRunIndex, this.beginIndex, this.endIndex]);
});

Clazz.newMeth(C$, 'getAllAttributeKeys', function () {
if (this.this$0.runAttributes == null ) {
return Clazz.new_((I$[4]||$incl$(4)));
}{
var keys = Clazz.new_((I$[4]||$incl$(4)));
var i = 0;
while (i < this.this$0.runCount){
if (this.this$0.runStarts[i] < this.endIndex && (i == this.this$0.runCount - 1 || this.this$0.runStarts[i + 1] > this.beginIndex ) ) {
var currentRunAttributes = this.this$0.runAttributes[i];
if (currentRunAttributes != null ) {
var j = currentRunAttributes.size();
while (j-- > 0){
keys.add$TE(currentRunAttributes.get$I(j));
}
}}i++;
}
return keys;
}});

Clazz.newMeth(C$, 'getAttribute$java_text_AttributedCharacterIterator_Attribute', function (attribute) {
var runIndex = this.currentRunIndex;
if (runIndex < 0) {
return null;
}return this.this$0.getAttributeCheckRange$java_text_AttributedCharacterIterator_Attribute$I$I$I(attribute, runIndex, this.beginIndex, this.endIndex);
});

Clazz.newMeth(C$, 'getString', function () {
return this.this$0;
});

Clazz.newMeth(C$, 'internalSetIndex$I', function (position) {
this.currentIndex = position;
if (position < this.currentRunStart || position >= this.currentRunLimit ) {
p$.updateRunInfo.apply(this, []);
}if (this.currentIndex == this.endIndex) {
return "\uffff";
} else {
return this.this$0.charAt$I.apply(this.this$0, [position]);
}});

Clazz.newMeth(C$, 'updateRunInfo', function () {
if (this.currentIndex == this.endIndex) {
this.currentRunStart = this.currentRunLimit = this.endIndex;
this.currentRunIndex = -1;
} else {
{
var runIndex = -1;
while (runIndex < this.this$0.runCount - 1 && this.this$0.runStarts[runIndex + 1] <= this.currentIndex )runIndex++;

this.currentRunIndex = runIndex;
if (runIndex >= 0) {
this.currentRunStart = this.this$0.runStarts[runIndex];
if (this.currentRunStart < this.beginIndex) this.currentRunStart = this.beginIndex;
} else {
this.currentRunStart = this.beginIndex;
}if (runIndex < this.this$0.runCount - 1) {
this.currentRunLimit = this.this$0.runStarts[runIndex + 1];
if (this.currentRunLimit > this.endIndex) this.currentRunLimit = this.endIndex;
} else {
this.currentRunLimit = this.endIndex;
}}}});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.AttributedString, "AttributeMap", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.util.AbstractMap');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.runIndex = 0;
this.beginIndex = 0;
this.endIndex = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I', function (runIndex, beginIndex, endIndex) {
Clazz.super_(C$, this,1);
this.runIndex = runIndex;
this.beginIndex = beginIndex;
this.endIndex = endIndex;
}, 1);

Clazz.newMeth(C$, 'entrySet', function () {
var set = Clazz.new_((I$[4]||$incl$(4)));
{
var size = this.this$0.runAttributes[this.runIndex].size();
for (var i = 0; i < size; i++) {
var key = this.this$0.runAttributes[this.runIndex].get$I(i);
var value = this.this$0.runAttributeValues[this.runIndex].get$I(i);
if (Clazz.instanceOf(value, "java.text.Annotation")) {
value = this.this$0.getAttributeCheckRange$java_text_AttributedCharacterIterator_Attribute$I$I$I(key, this.runIndex, this.beginIndex, this.endIndex);
if (value == null ) {
continue;
}}var entry = Clazz.new_((I$[5]||$incl$(5)).c$$java_text_AttributedCharacterIterator_Attribute$O,[key, value]);
set.add$TE(entry);
}
}return set;
});

Clazz.newMeth(C$, 'get$O', function (key) {
return this.this$0.getAttributeCheckRange$java_text_AttributedCharacterIterator_Attribute$I$I$I(key, this.runIndex, this.beginIndex, this.endIndex);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-08 10:02:09
