(function(){var P$=java.lang,I$=[];
var C$=Clazz.newClass(java.lang, "ThreadDeath", null, 'Error');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);
})();
//Created 2018-05-15 01:02:08
