(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Comparable");
})();
//Created 2018-05-21 09:06:18
