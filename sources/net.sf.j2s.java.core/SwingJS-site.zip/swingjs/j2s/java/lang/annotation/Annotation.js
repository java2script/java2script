(function(){var P$=java.lang.annotation,I$=[];
var C$=Clazz.newInterface(P$, "Annotation");
})();
//Created 2018-02-24 16:54:50
