(function(){var P$=java.lang.annotation,I$=[];
var C$=Clazz.newInterface(P$, "Annotation");
})();
//Created 2018-03-03 22:34:33
