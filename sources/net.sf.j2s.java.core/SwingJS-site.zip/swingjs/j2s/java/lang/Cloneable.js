(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Cloneable");
})();
//Created 2018-05-24 08:45:37
