(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Cloneable");
})();
//Created 2018-02-25 18:53:01
