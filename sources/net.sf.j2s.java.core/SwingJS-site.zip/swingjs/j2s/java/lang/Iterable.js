(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Iterable");
})();
//Created 2018-03-16 05:15:44
