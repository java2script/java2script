(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Iterable");
})();
//Created 2018-05-20 23:54:21
