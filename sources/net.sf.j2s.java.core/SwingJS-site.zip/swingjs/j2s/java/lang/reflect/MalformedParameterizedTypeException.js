(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newClass(P$, "MalformedParameterizedTypeException", null, 'RuntimeException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-05-24 08:45:40
