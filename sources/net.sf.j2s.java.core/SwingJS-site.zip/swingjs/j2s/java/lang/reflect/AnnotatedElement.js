(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "AnnotatedElement");
})();
//Created 2018-03-14 22:51:17
