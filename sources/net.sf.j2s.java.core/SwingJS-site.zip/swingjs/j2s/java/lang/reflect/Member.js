(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "Member");
})();
//Created 2018-05-21 09:06:20
