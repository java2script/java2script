(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "Member");
})();
//Created 2018-02-24 16:54:51
