(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "TypeVariable", null, null, 'java.lang.reflect.Type');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-22 01:09:37
