(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newClass(P$, "Field", null, 'java.lang.reflect.AccessibleObject', 'java.lang.reflect.Member');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'isSynthetic', function () {
return false;
});

Clazz.newMeth(C$, 'toGenericString', function () {
return null;
});

Clazz.newMeth(C$, 'isEnumConstant', function () {
return false;
});

Clazz.newMeth(C$, 'getGenericType', function () {
return null;
});

Clazz.newMeth(C$, 'equals$O', function (object) {
return false;
});

Clazz.newMeth(C$, 'get$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.get(Ljava/lang/Object;)Ljava/lang/Object;|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getBoolean$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getBoolean(Ljava/lang/Object;)Z|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getByte$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getByte(Ljava/lang/Object;)B|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getChar$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getChar(Ljava/lang/Object;)C|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getDeclaringClass', function () {
return null;
});

Clazz.newMeth(C$, 'getDouble$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getDouble(Ljava/lang/Object;)D|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getFloat$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getFloat(Ljava/lang/Object;)F|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getInt$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getInt(Ljava/lang/Object;)I|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getLong$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getLong(Ljava/lang/Object;)J|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getModifiers', function () {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getModifiers()I');
}
);

Clazz.newMeth(C$, 'getName', function () {
return null;
});

Clazz.newMeth(C$, 'getShort$O', function (object) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getShort(Ljava/lang/Object;)S|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'getSignature', function () {
alert('native method must be replaced! Ljava/lang/reflect/Field;.getSignature()Ljava/lang/String;');
}
);

Clazz.newMeth(C$, 'getType', function () {
return null;
});

Clazz.newMeth(C$, 'hashCode', function () {
return 0;
});

Clazz.newMeth(C$, 'set$O$O', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.set(Ljava/lang/Object;Ljava/lang/Object;)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setBoolean$O$Z', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setBoolean(Ljava/lang/Object;Z)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setByte$O$B', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setByte(Ljava/lang/Object;B)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setChar$O$C', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setChar(Ljava/lang/Object;C)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setDouble$O$D', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setDouble(Ljava/lang/Object;D)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setFloat$O$F', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setFloat(Ljava/lang/Object;F)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setInt$O$I', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setInt(Ljava/lang/Object;I)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setLong$O$J', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setLong(Ljava/lang/Object;J)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'setShort$O$H', function (object, value) {
alert('native method must be replaced! Ljava/lang/reflect/Field;.setShort(Ljava/lang/Object;S)V|Ljava/lang/IllegalAccessException;|Ljava/lang/IllegalArgumentException;');
}
);

Clazz.newMeth(C$, 'toString', function () {
return null;
});

Clazz.newMeth(C$);
})();
//Created 2018-05-21 09:06:20
