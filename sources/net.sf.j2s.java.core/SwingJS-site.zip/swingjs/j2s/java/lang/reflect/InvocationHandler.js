(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "InvocationHandler");
})();
//Created 2018-02-25 18:53:04
