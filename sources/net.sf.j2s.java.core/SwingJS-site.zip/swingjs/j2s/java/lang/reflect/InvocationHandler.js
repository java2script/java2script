(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "InvocationHandler");
})();
//Created 2018-05-20 23:54:22
