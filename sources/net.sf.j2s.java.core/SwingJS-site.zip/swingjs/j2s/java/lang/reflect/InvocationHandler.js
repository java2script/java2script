(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "InvocationHandler");
})();
//Created 2018-03-14 22:51:17
