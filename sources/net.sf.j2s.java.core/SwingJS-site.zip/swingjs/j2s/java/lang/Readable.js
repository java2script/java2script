(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Readable");
})();
//Created 2018-02-24 16:54:49
