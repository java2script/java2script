(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Readable");
})();
//Created 2018-02-08 10:02:07
