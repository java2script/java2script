(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Readable");
})();
//Created 2018-03-14 22:51:15
