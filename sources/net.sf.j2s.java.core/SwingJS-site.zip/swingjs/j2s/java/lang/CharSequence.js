(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "CharSequence");
})();
//Created 2018-03-14 22:51:14
