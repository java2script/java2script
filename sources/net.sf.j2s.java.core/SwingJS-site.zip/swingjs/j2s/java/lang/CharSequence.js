(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "CharSequence");
})();
//Created 2018-05-21 09:06:17
