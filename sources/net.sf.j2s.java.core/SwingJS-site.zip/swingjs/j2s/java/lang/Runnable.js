(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(java.lang, "Runnable");
})();
//Created 2018-02-22 01:09:33
