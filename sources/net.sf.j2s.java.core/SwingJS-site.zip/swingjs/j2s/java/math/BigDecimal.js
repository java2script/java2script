(function(){var P$=Clazz.newPackage("java.math"),I$=[];
var C$=Clazz.newClass(P$, "BigDecimal");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-03-14 22:51:18
