Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.GZIPException", null, function () {
var c$ = Clazz.declareType (com.jcraft.jzlib, "GZIPException", java.io.IOException);
});
;//5.0.1-v1 Sun Nov 19 16:48:01 CST 2023
