Clazz.declarePackage("com.jcraft.jzlib");
Clazz.load(["java.io.IOException"], "com.jcraft.jzlib.GZIPException", null, function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "GZIPException", java.io.IOException);
});
;//5.0.1-v2 Tue Jan 09 13:49:22 CST 2024
