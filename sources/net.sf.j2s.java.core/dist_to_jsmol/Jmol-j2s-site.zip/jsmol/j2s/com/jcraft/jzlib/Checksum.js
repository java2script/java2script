Clazz.declarePackage("com.jcraft.jzlib");
Clazz.declareInterface(com.jcraft.jzlib, "Checksum");
;//5.0.1-v2 Thu Feb 08 09:49:36 CST 2024
