Clazz.declarePackage("com.jcraft.jzlib");
Clazz.declareInterface(com.jcraft.jzlib, "Checksum");
;//5.0.1-v2 Wed Dec 06 13:23:02 MST 2023
