Clazz.declarePackage("com.jcraft.jzlib");
Clazz.declareInterface(com.jcraft.jzlib, "Checksum");
;//5.0.1-v2 Mon Jan 29 13:39:14 CST 2024
