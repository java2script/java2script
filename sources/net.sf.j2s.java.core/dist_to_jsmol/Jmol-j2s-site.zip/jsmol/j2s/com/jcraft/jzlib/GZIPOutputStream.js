Clazz.declarePackage ("com.jcraft.jzlib");
var c$ = Clazz.declareType (com.jcraft.jzlib, "GZIPOutputStream");
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
