Clazz.declarePackage ("com.jcraft.jzlib");
var c$ = Clazz.declareType (com.jcraft.jzlib, "GZIPOutputStream");
;//5.0.1-v2 Sat Nov 25 15:58:06 CST 2023
