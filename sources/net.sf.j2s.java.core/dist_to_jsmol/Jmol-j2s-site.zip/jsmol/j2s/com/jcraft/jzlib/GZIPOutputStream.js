Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "GZIPOutputStream", null);
})();
;//5.0.1-v2 Sat Apr 06 02:44:31 CDT 2024
