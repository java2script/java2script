Clazz.declarePackage("com.jcraft.jzlib");
Clazz.load(["java.io.IOException"], "com.jcraft.jzlib.ZStreamException", null, function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "ZStreamException", java.io.IOException);
});
;//5.0.1-v2 Thu Feb 08 09:49:36 CST 2024
