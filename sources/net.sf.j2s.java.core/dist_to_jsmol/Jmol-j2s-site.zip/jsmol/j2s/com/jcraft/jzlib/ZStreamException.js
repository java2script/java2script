Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.ZStreamException", null, function () {
var c$ = Clazz.declareType (com.jcraft.jzlib, "ZStreamException", java.io.IOException);
});
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
