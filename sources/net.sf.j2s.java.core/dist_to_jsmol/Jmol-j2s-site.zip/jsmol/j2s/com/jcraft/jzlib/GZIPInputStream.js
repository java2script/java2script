Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "GZIPInputStream", null);
})();
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
