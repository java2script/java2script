Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "GZIPInputStream", null);
})();
;//5.0.1-v2 Mon Jan 29 13:39:14 CST 2024
