Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, com.jcraft.jzlib, "GZIPInputStream", null);
})();
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
