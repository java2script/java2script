Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function(){
return "1.1.0";
});
})();
;//5.0.1-v2 Wed Dec 06 13:23:02 MST 2023
