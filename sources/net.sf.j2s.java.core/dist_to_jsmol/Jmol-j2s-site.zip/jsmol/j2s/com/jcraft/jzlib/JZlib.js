Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function () {
return "1.1.0";
});
})();
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
