Clazz.declarePackage ("com.jcraft.jzlib");
var c$ = Clazz.declareType (com.jcraft.jzlib, "JZlib");
c$.version = Clazz.defineMethod (c$, "version", 
function () {
return "1.1.0";
});
;//5.0.1-v2 Sat Nov 25 17:52:34 CST 2023
