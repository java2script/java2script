Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function(){
return "1.1.0";
});
})();
;//5.0.1-v2 Sat Apr 06 02:44:31 CDT 2024
