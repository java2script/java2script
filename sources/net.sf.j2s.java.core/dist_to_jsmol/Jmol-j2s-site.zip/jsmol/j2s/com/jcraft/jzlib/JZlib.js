Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function(){
return "1.1.0";
});
})();
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
