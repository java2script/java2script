Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function(){
return "1.1.0";
});
})();
;//5.0.1-v2 Thu Feb 08 09:49:36 CST 2024
