Clazz.declarePackage ("com.jcraft.jzlib");
var c$ = Clazz.declareType (com.jcraft.jzlib, "JZlib");
c$.version = Clazz.defineMethod (c$, "version", 
function () {
return "1.1.0";
});
;//5.0.1-v2 Sat Nov 25 15:58:06 CST 2023
