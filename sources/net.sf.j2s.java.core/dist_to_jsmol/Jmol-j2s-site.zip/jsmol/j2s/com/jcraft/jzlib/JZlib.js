Clazz.declarePackage ("com.jcraft.jzlib");
var c$ = Clazz.declareType (com.jcraft.jzlib, "JZlib");
c$.version = Clazz.defineMethod (c$, "version", 
function () {
return "1.1.0";
});
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
