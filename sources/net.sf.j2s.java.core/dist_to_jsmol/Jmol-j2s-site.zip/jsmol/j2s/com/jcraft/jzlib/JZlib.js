Clazz.declarePackage("com.jcraft.jzlib");
(function(){
var c$ = Clazz.declareType(com.jcraft.jzlib, "JZlib", null);
c$.version = Clazz.defineMethod(c$, "version", 
function(){
return "1.1.0";
});
})();
;//5.0.1-v2 Mon Apr 08 08:45:17 CDT 2024
