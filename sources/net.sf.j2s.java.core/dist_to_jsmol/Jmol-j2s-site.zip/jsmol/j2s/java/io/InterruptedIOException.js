Clazz.load (["java.io.IOException"], "java.io.InterruptedIOException", null, function () {
var c$ = Clazz.decorateAsClass (function () {
this.bytesTransferred = 0;
Clazz.instantialize (this, arguments);
}, java.io, "InterruptedIOException", java.io.IOException);
});
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
