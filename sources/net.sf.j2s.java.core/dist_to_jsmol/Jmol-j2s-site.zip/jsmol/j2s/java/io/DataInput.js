Clazz.declareInterface(java.io, "DataInput");
;//5.0.1-v2 Mon Jan 29 13:54:34 CST 2024
