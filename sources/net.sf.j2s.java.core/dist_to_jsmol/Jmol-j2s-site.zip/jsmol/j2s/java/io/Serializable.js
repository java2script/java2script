Clazz.declareInterface (java.io, "Serializable");
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
