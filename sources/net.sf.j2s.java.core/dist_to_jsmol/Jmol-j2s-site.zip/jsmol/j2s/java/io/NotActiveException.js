Clazz.load (["java.io.ObjectStreamException"], "java.io.NotActiveException", null, function () {
var c$ = Clazz.declareType (java.io, "NotActiveException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Sun Nov 19 16:48:01 CST 2023
