Clazz.load (["java.io.IOException"], "java.io.SyncFailedException", null, function () {
var c$ = Clazz.declareType (java.io, "SyncFailedException", java.io.IOException);
});
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
