Clazz.load (["java.io.ObjectStreamException"], "java.io.StreamCorruptedException", null, function () {
var c$ = Clazz.declareType (java.io, "StreamCorruptedException", java.io.ObjectStreamException);
});
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
