Clazz.load (["java.io.ObjectStreamException"], "java.io.OptionalDataException", null, function () {
var c$ = Clazz.decorateAsClass (function () {
this.eof = false;
this.length = 0;
Clazz.instantialize (this, arguments);
}, java.io, "OptionalDataException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
