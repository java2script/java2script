Clazz.load (["java.io.ObjectStreamException"], "java.io.OptionalDataException", null, function () {
var c$ = Clazz.decorateAsClass (function () {
this.eof = false;
this.length = 0;
Clazz.instantialize (this, arguments);
}, java.io, "OptionalDataException", java.io.ObjectStreamException);
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
