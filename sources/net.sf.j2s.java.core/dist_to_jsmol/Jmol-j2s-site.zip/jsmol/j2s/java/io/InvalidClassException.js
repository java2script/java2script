Clazz.load (["java.io.ObjectStreamException"], "java.io.InvalidClassException", null, function () {
var c$ = Clazz.decorateAsClass (function () {
this.classname = null;
Clazz.instantialize (this, arguments);
}, java.io, "InvalidClassException", java.io.ObjectStreamException);
Clazz.makeConstructor (c$, 
function (className, detailMessage) {
Clazz.superConstructor (this, java.io.InvalidClassException, [detailMessage]);
this.classname = className;
}, "~S,~S");
Clazz.defineMethod (c$, "getMessage", 
function () {
var msg = Clazz.superCall (this, java.io.InvalidClassException, "getMessage", []);
if (this.classname != null) {
msg = this.classname + ';' + ' ' + msg;
}return msg;
});
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
