Clazz.declareInterface(java.io, "Externalizable", java.io.Serializable);
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
