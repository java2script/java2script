Clazz.load (["java.io.IOException"], "java.io.UTFDataFormatException", null, function () {
var c$ = Clazz.declareType (java.io, "UTFDataFormatException", java.io.IOException);
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
