Clazz.load (["java.lang.AutoCloseable"], "java.io.Closeable", null, function () {
Clazz.declareInterface (java.io, "Closeable", AutoCloseable);
});
;//5.0.1-v2 Sat Nov 25 17:52:34 CST 2023
