Clazz.load (["java.lang.AutoCloseable"], "java.io.Closeable", null, function () {
Clazz.declareInterface (java.io, "Closeable", AutoCloseable);
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
