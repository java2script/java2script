Clazz.load (["java.lang.AutoCloseable"], "java.io.Closeable", null, function () {
Clazz.declareInterface (java.io, "Closeable", AutoCloseable);
});
;//5.0.1-v1 Sun Nov 19 16:48:01 CST 2023
