Clazz.declareInterface(java.io, "Closeable", AutoCloseable);
;//5.0.1-v2 Tue Mar 19 00:29:33 CDT 2024
