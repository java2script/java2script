Clazz.load (["java.lang.Exception"], "java.io.IOException", null, function () {
var c$ = Clazz.declareType (java.io, "IOException", Exception);
});
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
