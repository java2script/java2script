Clazz.declarePackage("java.net");
Clazz.declareInterface(java.net, "URLStreamHandlerFactory");
;//5.0.1-v2 Sat Apr 06 02:44:31 CDT 2024
