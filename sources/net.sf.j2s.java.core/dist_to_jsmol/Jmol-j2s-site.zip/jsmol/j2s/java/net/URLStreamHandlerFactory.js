Clazz.declarePackage("java.net");
Clazz.declareInterface(java.net, "URLStreamHandlerFactory");
;//5.0.1-v2 Mon Jan 29 13:39:14 CST 2024
