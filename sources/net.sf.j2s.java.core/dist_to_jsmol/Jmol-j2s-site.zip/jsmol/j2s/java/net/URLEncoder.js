Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(s);
}, "~S");
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
