Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(arguments[0]);
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s, enc) {
return encodeURIComponent(arguments[0]);
}, "~S,~S");
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
