Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(s);
}, "~S");
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
