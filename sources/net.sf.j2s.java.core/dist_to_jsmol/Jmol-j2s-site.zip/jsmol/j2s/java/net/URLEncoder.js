Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(s);
}, "~S");
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
