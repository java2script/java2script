Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLDecoder");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (s) {
return decodeURIComponent(s);
}, "~S");
;//5.0.1-v1 Sun Nov 19 16:48:01 CST 2023
