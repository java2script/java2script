Clazz.declarePackage("java.net");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, java.net, "URLDecoder", null);
c$.decode = Clazz.defineMethod(c$, "decode", 
function (s) {
return decodeURIComponent(s);
}, "~S");
})();
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
