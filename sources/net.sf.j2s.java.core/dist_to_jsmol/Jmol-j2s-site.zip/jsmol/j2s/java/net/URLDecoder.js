Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLDecoder");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (s) {
return decodeURIComponent(s);
}, "~S");
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
