Clazz.declarePackage("java.net");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor(c$, 
function () {
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
})();
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
