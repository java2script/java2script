Clazz.declarePackage("java.net");
Clazz.load(["java.io.IOException"], "java.net.UnknownServiceException", null, function(){
var c$ = Clazz.declareType(java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
});
;//5.0.1-v2 Tue Jan 09 13:49:22 CST 2024
