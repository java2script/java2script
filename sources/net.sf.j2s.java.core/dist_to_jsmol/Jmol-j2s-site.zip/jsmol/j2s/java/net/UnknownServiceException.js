Clazz.declarePackage("java.net");
Clazz.load(["java.io.IOException"], "java.net.UnknownServiceException", null, function(){
var c$ = Clazz.declareType(java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
});
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
