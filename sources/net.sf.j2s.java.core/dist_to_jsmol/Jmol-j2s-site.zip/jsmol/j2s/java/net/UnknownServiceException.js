Clazz.declarePackage("java.net");
Clazz.load(["java.io.IOException"], "java.net.UnknownServiceException", null, function(){
var c$ = Clazz.declareType(java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
});
;//5.0.1-v2 Mon Jan 29 13:39:14 CST 2024
