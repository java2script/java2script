Clazz.declarePackage("java.net");
Clazz.load(["java.io.IOException"], "java.net.UnknownServiceException", null, function(){
var c$ = Clazz.declareType(java.net, "UnknownServiceException", java.io.IOException);
Clazz.makeConstructor(c$, 
function(){
Clazz.superConstructor (this, java.net.UnknownServiceException, []);
});
});
;//5.0.1-v2 Mon Apr 08 08:45:17 CDT 2024
