(function(){
var c$ = Clazz.declareType(java.util, "Dictionary", null);
})();
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
