(function(){
var c$ = Clazz.declareType(java.util, "Dictionary", null);
})();
;//5.0.1-v2 Tue Mar 19 00:29:33 CDT 2024
