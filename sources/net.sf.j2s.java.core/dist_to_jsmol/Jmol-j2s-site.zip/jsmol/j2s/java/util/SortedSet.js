Clazz.load (["java.util.Set"], "java.util.SortedSet", null, function () {
Clazz.declareInterface (java.util, "SortedSet", java.util.Set);
});
;//5.0.1-v2 Sat Nov 25 17:52:34 CST 2023
