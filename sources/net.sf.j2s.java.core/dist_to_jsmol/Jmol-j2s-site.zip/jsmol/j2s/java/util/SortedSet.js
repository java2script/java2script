Clazz.load (["java.util.Set"], "java.util.SortedSet", null, function () {
Clazz.declareInterface (java.util, "SortedSet", java.util.Set);
});
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
