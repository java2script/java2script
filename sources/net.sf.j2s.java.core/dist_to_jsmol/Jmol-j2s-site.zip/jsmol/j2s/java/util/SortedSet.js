Clazz.declareInterface(java.util, "SortedSet", java.util.Set);
;//5.0.1-v2 Tue Jan 09 13:49:22 CST 2024
