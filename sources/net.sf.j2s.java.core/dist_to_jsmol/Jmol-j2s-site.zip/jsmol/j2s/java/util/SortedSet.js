Clazz.load (["java.util.Set"], "java.util.SortedSet", null, function () {
Clazz.declareInterface (java.util, "SortedSet", java.util.Set);
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
