Clazz.declareInterface (java.util, "EventListener");
;//5.0.1-v1 Sun Nov 19 16:48:01 CST 2023
