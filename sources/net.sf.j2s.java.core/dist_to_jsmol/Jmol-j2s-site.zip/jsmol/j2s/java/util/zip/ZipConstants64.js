Clazz.declarePackage ("java.util.zip");
var c$ = Clazz.declareType (java.util.zip, "ZipConstants64");
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
