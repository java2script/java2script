Clazz.declareInterface(java.util, "Set", java.util.Collection);
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
