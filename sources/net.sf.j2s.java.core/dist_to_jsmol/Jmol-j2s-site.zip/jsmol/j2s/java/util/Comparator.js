Clazz.declareInterface(java.util, "Comparator");
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
