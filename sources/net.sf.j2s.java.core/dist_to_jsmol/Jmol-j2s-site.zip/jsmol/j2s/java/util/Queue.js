Clazz.declareInterface(java.util, "Queue", java.util.Collection);
;//5.0.1-v2 Wed Dec 06 13:23:02 MST 2023
