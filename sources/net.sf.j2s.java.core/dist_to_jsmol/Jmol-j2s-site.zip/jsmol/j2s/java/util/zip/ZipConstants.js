Clazz.declarePackage ("java.util.zip");
var c$ = Clazz.declareInterface (java.util.zip, "ZipConstants");
Clazz.defineStatics (c$,
"LOCSIG", 0x04034b50,
"EXTSIG", 0x08074b50,
"CENSIG", 0x02014b50,
"ENDSIG", 0x06054b50);
;//5.0.1-v2 Sat Nov 25 15:58:06 CST 2023
