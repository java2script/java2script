Clazz.declareInterface (java.util, "RandomAccess");
;//5.0.1-v2 Sat Nov 25 15:58:06 CST 2023
