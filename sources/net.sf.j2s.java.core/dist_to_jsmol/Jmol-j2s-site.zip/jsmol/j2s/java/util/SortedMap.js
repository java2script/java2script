Clazz.declareInterface(java.util, "SortedMap", java.util.Map);
;//5.0.1-v2 Tue Mar 19 00:29:33 CDT 2024
