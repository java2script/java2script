Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.CRC32"], "java.util.zip.CRC32", null, function () {
var c$ = Clazz.declareType (java.util.zip, "CRC32", com.jcraft.jzlib.CRC32);
});
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
