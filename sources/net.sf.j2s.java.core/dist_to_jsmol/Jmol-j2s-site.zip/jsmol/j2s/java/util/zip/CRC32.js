Clazz.declarePackage("java.util.zip");
Clazz.load(["com.jcraft.jzlib.CRC32"], "java.util.zip.CRC32", null, function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, java.util.zip, "CRC32", com.jcraft.jzlib.CRC32);
});
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
