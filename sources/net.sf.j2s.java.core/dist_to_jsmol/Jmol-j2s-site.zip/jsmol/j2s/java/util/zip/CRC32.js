Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.CRC32"], "java.util.zip.CRC32", null, function () {
var c$ = Clazz.declareType (java.util.zip, "CRC32", com.jcraft.jzlib.CRC32);
});
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
