Clazz.declareInterface (java.util, "Observer");
;//5.0.1-v1 Wed Nov 15 09:17:46 CST 2023
