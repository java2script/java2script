Clazz.declareInterface(java.util, "Observer");
;//5.0.1-v2 Mon Apr 08 08:45:17 CDT 2024
