Clazz.declareInterface(java.util, "Observer");
;//5.0.1-v2 Tue Jan 09 13:49:22 CST 2024
