Clazz.declareInterface(java.util, "Enumeration");
;//5.0.1-v2 Tue Nov 28 12:57:10 CST 2023
