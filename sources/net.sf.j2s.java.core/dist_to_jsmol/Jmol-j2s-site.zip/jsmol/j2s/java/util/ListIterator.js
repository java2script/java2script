Clazz.load (["java.util.Iterator"], "java.util.ListIterator", null, function () {
Clazz.declareInterface (java.util, "ListIterator", java.util.Iterator);
});
;//5.0.1-v2 Sat Nov 25 17:52:34 CST 2023
