Clazz.load (["java.util.Iterator"], "java.util.ListIterator", null, function () {
Clazz.declareInterface (java.util, "ListIterator", java.util.Iterator);
});
;//5.0.1-v2 Wed Nov 22 23:08:48 CST 2023
