(function(){
var c$ = Clazz.declareInterface(java.util, "Map");
Clazz.declareInterface(java.util.Map, "Entry");
c$.NOT_SIMPLE = 0;
c$.INVALID_KEY = 1;
c$.NO_SUCH_KEY = 2;
c$.HAS_KEY = 3;
})();
;//5.0.1-v2 Thu Feb 08 09:49:36 CST 2024
