Clazz.declarePackage("java.util.zip");
Clazz.load(["java.io.IOException"], "java.util.zip.ZipException", null, function(){
var c$ = Clazz.declareType(java.util.zip, "ZipException", java.io.IOException);
});
;//5.0.1-v2 Mon Apr 08 08:45:17 CDT 2024
