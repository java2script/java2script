Clazz.declarePackage("java.util.zip");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, java.util.zip, "ZipException", java.io.IOException);
})();
;//5.0.1-v2 Mon Nov 27 23:33:50 CST 2023
