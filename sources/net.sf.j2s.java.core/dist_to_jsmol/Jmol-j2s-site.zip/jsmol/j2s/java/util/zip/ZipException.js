Clazz.declarePackage("java.util.zip");
Clazz.load(["java.io.IOException"], "java.util.zip.ZipException", null, function(){
var c$ = Clazz.declareType(java.util.zip, "ZipException", java.io.IOException);
});
;//5.0.1-v2 Thu Nov 30 17:49:15 CST 2023
