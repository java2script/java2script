Clazz.declarePackage ("java.util.regex");
var c$ = Clazz.decorateAsClass (function () {
this.pat = null;
this.string = null;
this.strString = null;
this.leftBound = -1;
this.rightBound = -1;
this.results = null;
Clazz.instantialize (this, arguments);
}, java.util.regex, "Matcher");
Clazz.makeConstructor (c$, 
function (pat, cs) {
this.pat = pat;
this.string = cs;
this.strString = cs.toString ();
this.leftBound = 0;
this.rightBound = this.strString.length;
}, "java.util.regex.Pattern,CharSequence");
Clazz.defineMethod (c$, "find", 
function () {
var s = (this.rightBound == this.strString.length ? this.strString : this.strString.substring (0, this.rightBound));
var lb = this.leftBound;
{
this.pat.regexp.lastIndex = this.leftBound;
this.results = this.pat.regexp.exec(s);
this.leftBound = this.pat.regexp.lastIndex;
}return (this.results != null);
});
Clazz.defineMethod (c$, "start", 
function () {
{
return 0;
}});
Clazz.defineMethod (c$, "start", 
function (groupIndex) {
System.err.println ("Matcher.start(groupIndex) not implemented");
return this.start ();
}, "~N");
Clazz.defineMethod (c$, "end", 
function (groupIndex) {
System.err.println ("Matcher.end(groupIndex) not implemented");
return this.end ();
}, "~N");
Clazz.defineMethod (c$, "end", 
function () {
{
return this.pat.regexp.lastIndex;
}});
Clazz.defineMethod (c$, "group", 
function (groupIndex) {
if (this.results == null || groupIndex < 0 || groupIndex > this.results.length) {
return null;
}return this.results[groupIndex];
}, "~N");
Clazz.defineMethod (c$, "group", 
function () {
return this.group (0);
});
;//5.0.1-v1 Fri Nov 17 11:08:42 CST 2023
