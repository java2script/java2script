Clazz.declareInterface (java.util, "Collection", Iterable);
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
