Clazz.declareInterface(java.util, "Collection", Iterable);
;//5.0.1-v2 Wed Dec 06 13:23:02 MST 2023
