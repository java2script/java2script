Clazz.load (["java.util.Collection"], "java.util.List", null, function () {
Clazz.declareInterface (java.util, "List", java.util.Collection);
});
;//5.0.1-v2 Sat Nov 25 17:52:34 CST 2023
