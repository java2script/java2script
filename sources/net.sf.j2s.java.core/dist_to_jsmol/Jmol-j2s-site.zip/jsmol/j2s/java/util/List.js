Clazz.load (["java.util.Collection"], "java.util.List", null, function () {
Clazz.declareInterface (java.util, "List", java.util.Collection);
});
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
