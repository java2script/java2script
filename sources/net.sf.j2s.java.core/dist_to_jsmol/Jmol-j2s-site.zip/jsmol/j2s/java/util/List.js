Clazz.load (["java.util.Collection"], "java.util.List", null, function () {
Clazz.declareInterface (java.util, "List", java.util.Collection);
});
;//5.0.1-v2 Wed Nov 22 08:02:17 CST 2023
