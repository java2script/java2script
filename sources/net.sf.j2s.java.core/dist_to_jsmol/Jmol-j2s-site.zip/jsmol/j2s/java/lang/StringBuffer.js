Clazz.load (["java.lang.AbstractStringBuilder", "$.Appendable"], "java.lang.StringBuffer", ["java.lang.Character", "$.Double", "$.Float", "$.Long"], function () {
var c$ = Clazz.declareType (java.lang, "StringBuffer", AbstractStringBuilder, [Appendable, java.io.Serializable, CharSequence]);
Clazz.makeConstructor (c$, 
function (cs) {
if (cs == null) {
throw new NullPointerException();
}
Clazz.superConstructor(this, StringBuffer, [cs.toString()]);
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (b) {
return this.append (b ? "true" : "false");
}, "~B");
Clazz.defineMethod (c$, "append", 
function (ch) {
append0 ();
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (d) {
return this.append (Double.toString (d));
}, "~N");
Clazz.defineMethod (c$, "append", 
function (obj) {
if (obj == null) {
this.appendNull ();
} else {
append0 ();
}return this;
}, "~O");
Clazz.defineMethod (c$, "append", 
function (string) {
append0 ();
return this;
}, "~S");
Clazz.defineMethod (c$, "append", 
function (sb) {
if (sb == null) {
this.appendNull ();
} else {
{
append0 ();
}}return this;
}, "StringBuffer");
Clazz.defineMethod (c$, "append", 
function (chars) {
append0 ();
return this;
}, "~A");
Clazz.defineMethod (c$, "append", 
function (chars, start, length) {
append0 ();
return this;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "append", 
function (s) {
if (s == null) {
this.appendNull ();
} else {
append0 ();
}return this;
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (s, start, end) {
append0 ();
return this;
}, "CharSequence,~N,~N");
Clazz.overrideMethod (c$, "appendCodePoint", 
function (codePoint) {
return this.append (Character.toChars (codePoint));
}, "~N");
Clazz.overrideMethod (c$, "$delete", 
function (start, end) {
delete0 ();
return this;
}, "~N,~N");
Clazz.overrideMethod (c$, "deleteCharAt", 
function (location) {
deleteCharAt0 ();
return this;
}, "~N");
Clazz.defineMethod (c$, "insert", 
function (index, ch) {
insert0 ();
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (index, b) {
return this.insert (index, b ? "true" : "false");
}, "~N,~B");
Clazz.defineMethod (c$, "insert", 
function (index, i) {
return this.insert (index, Integer.toString (i));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (index, l) {
return this.insert (index, Long.toString (l));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (index, d) {
return this.insert (index, Double.toString (d));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (index, f) {
return this.insert (index, Float.toString (f));
}, "~N,~N");
Clazz.defineMethod (c$, "insert", 
function (index, obj) {
return this.insert (index, obj == null ? "null" : obj.toString ());
}, "~N,~O");
Clazz.defineMethod (c$, "insert", 
function (index, string) {
insert0 ();
return this;
}, "~N,~S");
Clazz.defineMethod (c$, "insert", 
function (index, chars) {
insert0 ();
return this;
}, "~N,~A");
Clazz.defineMethod (c$, "insert", 
function (index, chars, start, length) {
insert0 ();
return this;
}, "~N,~A,~N,~N");
Clazz.defineMethod (c$, "insert", 
function (index, s) {
insert0 ();
return this;
}, "~N,CharSequence");
Clazz.defineMethod (c$, "insert", 
function (index, s, start, end) {
insert0 ();
return this;
}, "~N,CharSequence,~N,~N");
Clazz.overrideMethod (c$, "replace", 
function (start, end, string) {
replace0 ();
return this;
}, "~N,~N,~S");
Clazz.overrideMethod (c$, "reverse", 
function () {
reverse0 ();
return this;
});
Clazz.overrideMethod (c$, "subSequence", 
function (start, end) {
return Clazz.superCall (this, StringBuffer, "substring", [start, end]);
}, "~N,~N");
});
;//5.0.1-v1 Fri Nov 17 16:13:55 CST 2023
