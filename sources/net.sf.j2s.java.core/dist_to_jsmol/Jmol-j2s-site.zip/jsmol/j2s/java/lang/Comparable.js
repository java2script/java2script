Clazz.declareInterface (java.lang, "Comparable");
;//5.0.1-v1 Fri Nov 17 10:34:38 CST 2023
