(function(){var P$=Clazz.newPackage("javajs.util"),I$=[];
var C$=Clazz.newClass(P$, "P3i", null, 'javajs.util.T3i');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'new3$I$I$I', function (x, y, z) {
var pt = Clazz.new_(C$);
pt.x = x;
pt.y = y;
pt.z = z;
return pt;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:45:48
