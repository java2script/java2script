(function(){var P$=Clazz.newPackage("javajs.util"),I$=[['javajs.util.AU','javajs.util.Rdr']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AjaxURLConnection", null, 'java.net.URLConnection');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.bytesOut = null;
this.postOut = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.postOut = "";
}, 1);

Clazz.newMeth(C$, 'c$$java_net_URL', function (url) {
C$.superclazz.c$$java_net_URL.apply(this, [url]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'doAjax$Z', function (isBinary) {
var jmol = null;
{
jmol = J2S || Jmol;
}return jmol._doAjax(this.url, this.postOut, this.bytesOut, isBinary);
});

Clazz.newMeth(C$, 'connect', function () {
});

Clazz.newMeth(C$, 'outputBytes$BA', function (bytes) {
this.bytesOut = bytes;
});

Clazz.newMeth(C$, 'outputString$S', function (post) {
this.postOut = post;
});

Clazz.newMeth(C$, 'getInputStream', function () {
var bis = C$.getAttachedStreamData$java_net_URL(this.url);
if (bis != null ) return bis;
var o = p$.doAjax$Z.apply(this, [true]);
return ((I$[1]||$incl$(1)).isAB$O(o) ? (I$[2]||$incl$(2)).getBIS$BA(o) : Clazz.instanceOf(o, "javajs.util.SB") ? (I$[2]||$incl$(2)).getBIS$BA((I$[2]||$incl$(2)).getBytesFromSB$javajs_util_SB(o)) : Clazz.instanceOf(o, "java.lang.String") ? (I$[2]||$incl$(2)).getBIS$BA((o).getBytes()) : bis);
});

Clazz.newMeth(C$, 'getAttachedStreamData$java_net_URL', function (url) {
var bis = null;
{
bis = url._streamData;
}if (bis != null ) (bis).resetStream();
return bis;
}, 1);

Clazz.newMeth(C$, 'getContents', function () {
return p$.doAjax$Z.apply(this, [false]);
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:45:46
