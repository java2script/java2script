(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newInterface(P$, "GenericCifDataParser");
})();
//Created 2017-12-22 10:45:44
