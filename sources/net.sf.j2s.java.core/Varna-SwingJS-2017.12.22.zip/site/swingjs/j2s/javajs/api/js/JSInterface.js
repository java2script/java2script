(function(){var P$=Clazz.newPackage("javajs.api.js"),I$=[];
var C$=Clazz.newInterface(P$, "JSInterface");
})();
//Created 2017-12-22 10:45:45
