(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newClass(P$, "GenericZipInputStream", null, 'java.util.zip.ZipInputStream', 'javajs.api.ZInputStream');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_io_InputStream', function ($in) {
C$.superclazz.c$$java_io_InputStream.apply(this, [$in]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:45:44
