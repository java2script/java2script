(function(){var P$=Clazz.newPackage("javax.sound.sampled"),I$=[];
var C$=Clazz.newInterface(P$, "SourceDataLine", null, null, 'javax.sound.sampled.DataLine');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 10:45:51
