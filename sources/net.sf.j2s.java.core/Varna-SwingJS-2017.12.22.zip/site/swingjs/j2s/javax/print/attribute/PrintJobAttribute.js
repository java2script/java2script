(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
var C$=Clazz.newInterface(P$, "PrintJobAttribute", null, null, 'javax.print.attribute.Attribute');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 10:45:50
