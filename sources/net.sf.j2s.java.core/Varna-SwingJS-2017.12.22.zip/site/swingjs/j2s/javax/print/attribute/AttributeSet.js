(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[];
var C$=Clazz.newInterface(P$, "AttributeSet");
})();
//Created 2017-12-22 10:45:49
