(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[['javax.print.attribute.DocAttribute']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "HashDocAttributeSet", null, 'javax.print.attribute.HashAttributeSet', ['javax.print.attribute.DocAttributeSet', 'java.io.Serializable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$Class.apply(this, [Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_DocAttribute', function (attribute) {
C$.superclazz.c$$javax_print_attribute_Attribute$Class.apply(this, [attribute, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_DocAttributeA', function (attributes) {
C$.superclazz.c$$javax_print_attribute_AttributeA$Class.apply(this, [attributes, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_DocAttributeSet', function (attributes) {
C$.superclazz.c$$javax_print_attribute_AttributeSet$Class.apply(this, [attributes, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-22 10:45:50
