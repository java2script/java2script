(function(){var P$=Clazz.newPackage("javax.print.attribute"),I$=[['javax.print.attribute.PrintRequestAttribute']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "HashPrintRequestAttributeSet", null, 'javax.print.attribute.HashAttributeSet', ['javax.print.attribute.PrintRequestAttributeSet', 'java.io.Serializable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$Class.apply(this, [Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_PrintRequestAttribute', function (attribute) {
C$.superclazz.c$$javax_print_attribute_Attribute$Class.apply(this, [attribute, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_PrintRequestAttributeA', function (attributes) {
C$.superclazz.c$$javax_print_attribute_AttributeA$Class.apply(this, [attributes, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$javax_print_attribute_PrintRequestAttributeSet', function (attributes) {
C$.superclazz.c$$javax_print_attribute_AttributeSet$Class.apply(this, [attributes, Clazz.getClass((I$[1]||$incl$(1)),[])]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-22 10:45:50
