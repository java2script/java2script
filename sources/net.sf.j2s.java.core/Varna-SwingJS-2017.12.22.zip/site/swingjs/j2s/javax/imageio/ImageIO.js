(function(){var P$=Clazz.newPackage("javax.imageio"),I$=[['swingjs.JSUtil','java.awt.Toolkit','java.io.BufferedInputStream','javajs.api.Interface','java.awt.image.RenderedImage']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ImageIO", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.PNG = 0;
C$.JPG = 0;
C$.GIF = 0;
C$.BMP = 0;
C$.readerTypes = null;
C$.readerMap = null;
C$.readerFormatNames = null;
C$.readerSuffixes = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.PNG = 0;
C$.JPG = 1;
C$.GIF = 2;
C$.BMP = 3;
C$.readerTypes = Clazz.array(java.lang.String, -1, ["image/png", "image/jpeg", "image/x-png", "image/vnd.wap.wbmp", "image/gif", "image/bmp"]);
C$.readerMap = Clazz.array(Integer.TYPE, -1, [C$.PNG, C$.JPG, C$.PNG, C$.BMP, C$.GIF, C$.BMP]);
C$.readerFormatNames = Clazz.array(java.lang.String, -1, ["jpg", "BMP", "bmp", "JPG", "wbmp", "jpeg", "png", "PNG", "JPEG", "WBMP", "GIF", "gif"]);
C$.readerSuffixes = Clazz.array(java.lang.String, -1, ["jpg", "bmp", "jpeg", "wbmp", "png", "gif"]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'setUseCache$Z', function (useCache) {
}, 1);

Clazz.newMeth(C$, 'getUseCache', function () {
return false;
}, 1);

Clazz.newMeth(C$, 'setCacheDirectory$java_io_File', function (cacheDirectory) {
}, 1);

Clazz.newMeth(C$, 'getCacheDirectory', function () {
return null;
}, 1);

Clazz.newMeth(C$, 'getReaderFormatNames', function () {
return C$.readerFormatNames;
}, 1);

Clazz.newMeth(C$, 'getReaderMIMETypes', function () {
return C$.readerTypes;
}, 1);

Clazz.newMeth(C$, 'getReaderFileSuffixes', function () {
return C$.readerSuffixes;
}, 1);

Clazz.newMeth(C$, 'read$java_io_InputStream', function (input) {
return (I$[2]||$incl$(2)).getDefaultToolkit().createImage$BA((I$[1]||$incl$(1)).getSignedStreamBytes$java_io_BufferedInputStream(Clazz.instanceOf(input, "java.io.BufferedInputStream") ? input : Clazz.new_((I$[3]||$incl$(3)).c$$java_io_InputStream,[input])));
}, 1);

Clazz.newMeth(C$, 'read$java_net_URL', function (input) {
return C$.read$java_io_InputStream(input.openStream());
}, 1);

Clazz.newMeth(C$, 'read$javax_imageio_stream_ImageInputStream', function (stream) {
(I$[1]||$incl$(1)).notImplemented$S("ImageIO.read(ImageInputStream");
return null;
}, 1);

Clazz.newMeth(C$, 'write$java_awt_image_RenderedImage$S$javax_imageio_stream_ImageOutputStream', function (im, formatName, output) {
(I$[1]||$incl$(1)).notImplemented$S("ImageIO.write(RenderedImage, String, ImageOutputStream");
return false;
}, 1);

Clazz.newMeth(C$, 'write$java_awt_image_RenderedImage$S$java_io_File', function (im, formatName, output) {
if (im == null  || output == null   || formatName == null  ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ImageIO.write(RenderedImage,String,File)"]);
}var writer = C$.getWriter$java_awt_image_RenderedImage$S(im, formatName);
return (writer != null  && writer.write$S$java_io_OutputStream(output.getName(), null) );
}, 1);

Clazz.newMeth(C$, 'write$java_awt_image_RenderedImage$S$java_io_OutputStream', function (im, formatName, output) {
if (im == null  || output == null   || formatName == null  ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ImageIO.write(RenderedImage,String,OutputStream)"]);
}var writer = C$.getWriter$java_awt_image_RenderedImage$S(im, formatName);
return (writer != null  && writer.write$S$java_io_OutputStream(null, output) );
}, 1);

Clazz.newMeth(C$, 'getWriter$java_awt_image_RenderedImage$S', function (im, formatName) {
try {
return (I$[4]||$incl$(4)).getInstanceWithParams$S$ClassA$OA("javax.imageio.ImageWriter", Clazz.array(java.lang.Class, -1, [Clazz.getClass((I$[5]||$incl$(5)),['copyData$java_awt_image_WritableRaster','getColorModel','getData','getData$java_awt_Rectangle','getHeight','getMinTileX','getMinTileY','getMinX','getMinY','getNumXTiles','getNumYTiles','getProperty$S','getPropertyNames','getSampleModel','getSources','getTile$I$I','getTileGridXOffset','getTileGridYOffset','getTileHeight','getTileWidth','getWidth']), Clazz.getClass(java.lang.String)]), Clazz.array(java.lang.Object, -1, [im, formatName]));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return null;
} else {
throw e;
}
}
}, 1);
;
(function(){var C$=Clazz.newClass(P$.ImageIO, "CacheInfo", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.useCache = false;
this.hasPermission = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.useCache = false;
this.hasPermission = Boolean.TRUE;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getUseCache', function () {
return this.useCache;
});

Clazz.newMeth(C$, 'setUseCache$Z', function (useCache) {
this.useCache = useCache;
});

Clazz.newMeth(C$, 'getCacheDirectory', function () {
return null;
});

Clazz.newMeth(C$, 'setCacheDirectory$java_io_File', function (cacheDirectory) {
(I$[1]||$incl$(1)).notImplemented$S(null);
});

Clazz.newMeth(C$, 'getHasPermission', function () {
return this.hasPermission;
});

Clazz.newMeth(C$, 'setHasPermission$Boolean', function (hasPermission) {
this.hasPermission = hasPermission;
});
})()

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:45:49
