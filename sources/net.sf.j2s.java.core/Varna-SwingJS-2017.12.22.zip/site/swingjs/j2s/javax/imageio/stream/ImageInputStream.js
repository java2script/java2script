(function(){var P$=Clazz.newPackage("javax.imageio.stream"),I$=[];
var C$=Clazz.newInterface(P$, "ImageInputStream");
})();
//Created 2017-12-22 10:45:49
