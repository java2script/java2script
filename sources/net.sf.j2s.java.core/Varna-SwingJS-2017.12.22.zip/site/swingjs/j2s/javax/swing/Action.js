(function(){var P$=Clazz.newPackage("javax.swing"),I$=[];
var C$=Clazz.newInterface(P$, "Action", null, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 10:45:52
