(function(){var P$=Clazz.newPackage("javax.swing.filechooser"),I$=[];
var C$=Clazz.newClass(P$, "FileFilter");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$SA', function (options) {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'accept$java_io_File', function (f) {
return true;
});

Clazz.newMeth(C$, 'getDescription', function () {
return "not implemented";
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:46:16
