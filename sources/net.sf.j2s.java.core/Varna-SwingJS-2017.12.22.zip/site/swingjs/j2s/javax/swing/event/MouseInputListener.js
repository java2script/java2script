(function(){var P$=Clazz.newPackage("javax.swing.event"),I$=[];
var C$=Clazz.newInterface(P$, "MouseInputListener", null, null, ['java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 10:46:15
