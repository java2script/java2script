(function(){var P$=Clazz.newPackage("javax.swing.filechooser"),I$=[];
var C$=Clazz.newClass(P$, "FileView");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getName$java_io_File', function (f) {
return f.getName();
});

Clazz.newMeth(C$, 'getDescription$java_io_File', function (f) {
return null;
});

Clazz.newMeth(C$, 'getTypeDescription$java_io_File', function (f) {
return null;
});

Clazz.newMeth(C$, 'getIcon$java_io_File', function (f) {
return null;
});

Clazz.newMeth(C$, 'isTraversable$java_io_File', function (f) {
return null;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:46:16
