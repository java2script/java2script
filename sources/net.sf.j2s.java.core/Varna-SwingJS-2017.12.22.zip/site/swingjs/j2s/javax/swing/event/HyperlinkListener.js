(function(){var P$=Clazz.newPackage("javax.swing.event"),I$=[];
var C$=Clazz.newInterface(P$, "HyperlinkListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 10:46:14
