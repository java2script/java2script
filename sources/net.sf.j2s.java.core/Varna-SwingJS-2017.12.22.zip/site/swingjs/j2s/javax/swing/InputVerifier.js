(function(){var P$=Clazz.newPackage("javax.swing"),I$=[];
var C$=Clazz.newClass(P$, "InputVerifier");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'shouldYieldFocus$javax_swing_JComponent', function (input) {
return this.verify$javax_swing_JComponent(input);
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:45:54
