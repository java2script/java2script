(function(){var P$=Clazz.newPackage("javax.swing.event"),I$=[];
var C$=Clazz.newClass(P$, "PopupMenuEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$O', function (source) {
C$.superclazz.c$.apply(this, [source]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 10:46:15
