(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newInterface(P$, "TreeAlignLabelDistanceSymmetric", null, null, 'fr.orsay.lri.varna.models.treealign.TreeAlignLabelDistanceAsymmetric');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2017-12-22 22:38:27
