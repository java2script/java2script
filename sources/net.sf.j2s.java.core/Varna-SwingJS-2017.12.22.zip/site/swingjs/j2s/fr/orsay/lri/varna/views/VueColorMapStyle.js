(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[['javax.swing.JLabel','fr.orsay.lri.varna.components.GradientEditorPanel','java.awt.Dimension','javax.swing.JPanel','javax.swing.JTextField','java.awt.Font','fr.orsay.lri.varna.views.VueColorMapStyle$1',['fr.orsay.lri.varna.models.rna.ModeleColorMap','.NamedColorMapTypes'],'java.util.Arrays','fr.orsay.lri.varna.views.VueColorMapStyle$2','javax.swing.JComboBox','javax.swing.BoxLayout']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VueColorMapStyle", null, 'javax.swing.JPanel', ['java.awt.event.ActionListener', 'java.awt.event.ItemListener', 'java.beans.PropertyChangeListener']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vp = null;
this._gp = null;
this._cb = null;
this._code = null;
this._backup = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel', function (vp) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this._vp = vp;
p$.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init', function () {
var gradientCaption = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Click gradient to add new color..."]);
this._gp = Clazz.new_((I$[2]||$incl$(2)).c$$fr_orsay_lri_varna_models_rna_ModeleColorMap,[this._vp.getColorMap().clone()]);
this._backup = this._vp.getColorMap();
this._gp.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[300, 70]));
this._gp.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
var codePanel = Clazz.new_((I$[4]||$incl$(4)));
var codeCaption = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Param. code: "]);
this._code = Clazz.new_((I$[5]||$incl$(5)).c$$S,[""]);
this._code.setFont$java_awt_Font((I$[6]||$incl$(6)).decode$S("Monospaced-PLAIN-12"));
this._code.setEditable$Z(false);
this._code.addFocusListener$java_awt_event_FocusListener(((
(function(){var C$=Clazz.newClass(P$, "VueColorMapStyle$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.FocusListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'focusGained$java_awt_event_FocusEvent', function (arg0) {
this.b$['fr.orsay.lri.varna.views.VueColorMapStyle']._code.setSelectionStart$I(0);
this.b$['fr.orsay.lri.varna.views.VueColorMapStyle']._code.setSelectionEnd$I(this.b$['fr.orsay.lri.varna.views.VueColorMapStyle']._code.getText().length$());
});

Clazz.newMeth(C$, 'focusLost$java_awt_event_FocusEvent', function (arg0) {
});
})()
), Clazz.new_((I$[7]||$incl$(7)).$init$, [this, null])));
var palettes = (I$[8]||$incl$(8)).values();
(I$[9]||$incl$(9)).sort$TTA$java_util_Comparator(palettes, ((
(function(){var C$=Clazz.newClass(P$, "VueColorMapStyle$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['compare$fr_orsay_lri_varna_models_rna_ModeleColorMap_NamedColorMapTypes$fr_orsay_lri_varna_models_rna_ModeleColorMap_NamedColorMapTypes','compare$TT$TT'], function (arg0, arg1) {
return arg0.getId().compareTo$S(arg1.getId());
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
var finalArray = Clazz.array(java.lang.Object, [palettes.length + 1]);
var selected = -1;
for (var i = 0; i < palettes.length; i++) {
if (palettes[i].getColorMap().equals$fr_orsay_lri_varna_models_rna_ModeleColorMap(this._vp.getColorMap())) {
selected = i;
}finalArray[i] = palettes[i];
}
var custom =  String.instantialize("Custom...");
finalArray[palettes.length] = custom;
this._cb = Clazz.new_((I$[11]||$incl$(11)).c$$TEA,[finalArray]);
if (selected != -1) {
this._cb.setSelectedIndex$I(selected);
this._code.setText$S(palettes[selected].getId());
} else {
this._cb.setSelectedItem$O(new Integer(finalArray.length - 1));
this._code.setText$S(this._gp.getColorMap().getParamEncoding());
}this._cb.addItemListener$java_awt_event_ItemListener(this);
codePanel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[12]||$incl$(12)).c$$java_awt_Container$I,[codePanel, 2]));
codePanel.add$java_awt_Component(codeCaption);
codePanel.add$java_awt_Component(this._code);
this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[12]||$incl$(12)).c$$java_awt_Container$I,[this, 1]));
this.add$java_awt_Component(this._cb);
this.add$java_awt_Component(gradientCaption);
this.add$java_awt_Component(this._gp);
this.add$java_awt_Component(codePanel);
});

Clazz.newMeth(C$, 'cancelChanges', function () {
this._vp.setColorMap$fr_orsay_lri_varna_models_rna_ModeleColorMap(this._backup);
});

Clazz.newMeth(C$, 'getColorMap', function () {
return this._gp.getColorMap();
});

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
});

Clazz.newMeth(C$, 'refreshCode', function () {
var selected = -1;
var n = null;
for (var i = 0; i < this._cb.getItemCount() - 1; i++) {
var o = this._cb.getItemAt$I(i);
if (Clazz.instanceOf(o, "fr.orsay.lri.varna.models.rna.ModeleColorMap.NamedColorMapTypes")) {
var ni = o;
if (ni.getColorMap().equals$fr_orsay_lri_varna_models_rna_ModeleColorMap(this._gp.getColorMap())) {
selected = i;
n = ni;
}}}
if (selected != -1) {
this._code.setText$S(n.getId());
this._cb.setSelectedIndex$I(selected);
} else {
this._code.setText$S(this._gp.getColorMap().getParamEncoding());
}this._vp.setColorMap$fr_orsay_lri_varna_models_rna_ModeleColorMap(this._gp.getColorMap());
this._gp.repaint();
});

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent', function (arg0) {
if (arg0.getStateChange() == 1) {
var o = arg0.getItem();
if (Clazz.instanceOf(o, "fr.orsay.lri.varna.models.rna.ModeleColorMap.NamedColorMapTypes")) {
var n = (o);
this._gp.setColorMap$fr_orsay_lri_varna_models_rna_ModeleColorMap(n.getColorMap().clone());
p$.refreshCode.apply(this, []);
}}});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (arg0) {
if (arg0.getPropertyName().equals$O("PaletteChanged")) {
this._cb.setSelectedIndex$I(this._cb.getItemCount() - 1);
p$.refreshCode.apply(this, []);
};});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:38:30
