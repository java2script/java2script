(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newInterface(P$, "VueVARNAGraphics");
})();
//Created 2017-12-22 22:38:05
