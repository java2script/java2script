(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.controlers"),I$=[];
var C$=Clazz.newClass(P$, "ControleurBlinkingThread", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._period = 0;
this._parent = null;
this._minVal = 0;
this._maxVal = 0;
this._val = 0;
this._incr = 0;
this._increasing = false;
this._active = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this._increasing = true;
this._active = false;
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel', function (vp) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$J$D$D$D$D.apply(this, [vp, 50, 0, 1.0, 0.0, 0.2]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$J$D$D$D$D', function (vp, period, minVal, maxVal, val, incr) {
Clazz.super_(C$, this,1);
this._parent = vp;
this._period = period;
this._minVal = minVal;
this._maxVal = maxVal;
this._incr = incr;
}, 1);

Clazz.newMeth(C$, 'setActive$Z', function (b) {
if (this._active == b ) {
} else {
this._active = b;
if (this._active) {
this.interrupt();
}}});

Clazz.newMeth(C$, 'getActive', function () {
return this._active;
});

Clazz.newMeth(C$, 'getVal', function () {
return this._val;
});

Clazz.newMeth(C$, 'run', function () {
if (true) return;
while (true){
try {
if (this._active) {
Thread.sleep$J(this._period);
if (this._increasing) {
this._val = Math.min(this._val + this._incr, this._maxVal);
if (this._val == this._maxVal ) {
this._increasing = false;
}} else {
this._val = Math.max(this._val - this._incr, this._minVal);
if (this._val == this._minVal ) {
this._increasing = true;
}}this._parent.repaint();
} else {
Thread.sleep$J(10000);
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:37:46
