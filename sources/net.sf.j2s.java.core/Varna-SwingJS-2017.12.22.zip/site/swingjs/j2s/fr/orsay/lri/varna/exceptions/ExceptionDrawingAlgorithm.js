(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.exceptions"),I$=[];
var C$=Clazz.newClass(P$, "ExceptionDrawingAlgorithm", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (message) {
C$.superclazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);
})();
//Created 2017-12-22 22:37:48
