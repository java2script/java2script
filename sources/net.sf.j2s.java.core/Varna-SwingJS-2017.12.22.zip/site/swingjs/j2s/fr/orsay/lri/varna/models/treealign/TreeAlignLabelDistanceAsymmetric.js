(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.treealign"),I$=[];
var C$=Clazz.newInterface(P$, "TreeAlignLabelDistanceAsymmetric");
})();
//Created 2017-12-22 22:38:27
