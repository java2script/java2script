(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[['fr.orsay.lri.varna.views.PrintTestFrame','fr.orsay.lri.varna.views.PrintPanel','javax.print.attribute.HashPrintRequestAttributeSet','javax.swing.JPanel','javax.swing.JButton','java.awt.print.PrinterJob','javax.swing.JOptionPane','fr.orsay.lri.varna.views.PrintTestFrame$1','fr.orsay.lri.varna.views.PrintTestFrame$2',['java.awt.geom.Rectangle2D','.Double'],'java.awt.Font','java.awt.geom.GeneralPath','java.awt.font.TextLayout','java.awt.geom.AffineTransform',['java.awt.geom.Point2D','.Double'],['java.awt.geom.Line2D','.Double']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PrintTest");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var frame = Clazz.new_((I$[1]||$incl$(1)));
frame.setDefaultCloseOperation$I(3);
frame.show();
}, 1);

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:38:29
