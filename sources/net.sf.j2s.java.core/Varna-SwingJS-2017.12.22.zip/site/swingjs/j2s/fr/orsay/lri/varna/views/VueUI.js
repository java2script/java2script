(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[['fr.orsay.lri.varna.applications.FileNameExtensionFilter','javax.swing.undo.UndoableEditSupport','java.util.Hashtable',['fr.orsay.lri.varna.models.VARNAEdits','.RedrawEdit'],'fr.orsay.lri.varna.views.VueRNAList','javax.swing.JOptionPane','javax.swing.JFileChooser','fr.orsay.lri.varna.factories.RNAFactory','fr.orsay.lri.varna.exceptions.ExceptionFileFormatOrSyntax','fr.orsay.lri.varna.views.VueColorMapStyle','fr.orsay.lri.varna.views.VueLoadColorMapValues','fr.orsay.lri.varna.views.VueBaseValues','fr.orsay.lri.varna.views.VueManualInput','fr.orsay.lri.varna.models.rna.RNA','fr.orsay.lri.varna.models.VARNAConfig','java.util.ArrayList','fr.orsay.lri.varna.applications.VARNAPrinter','java.util.Arrays','fr.orsay.lri.varna.views.VueBorder','javax.swing.JColorChooser','java.awt.Point','fr.orsay.lri.varna.views.VueZoom','fr.orsay.lri.varna.views.VueGlobalRescale',['fr.orsay.lri.varna.models.VARNAEdits','.RescaleRNAEdit'],'fr.orsay.lri.varna.views.VueGlobalRotation',['fr.orsay.lri.varna.models.VARNAEdits','.RotateRNAEdit'],'fr.orsay.lri.varna.views.VueStyleBP','fr.orsay.lri.varna.views.VueFont','fr.orsay.lri.varna.views.VueSpaceBetweenBases','fr.orsay.lri.varna.views.VueBPHeightIncrement','fr.orsay.lri.varna.views.VueNumPeriod','fr.orsay.lri.varna.views.VueBPType','fr.orsay.lri.varna.views.VueBPThickness','fr.orsay.lri.varna.views.VueJPEG','java.awt.image.BufferedImage','java.awt.geom.AffineTransform','javax.imageio.ImageIO','java.io.File','javax.imageio.stream.FileImageOutputStream','javax.imageio.IIOImage','fr.orsay.lri.varna.exceptions.ExceptionExportFailed','fr.orsay.lri.varna.views.VueBases','fr.orsay.lri.varna.views.VueAboutPanel',['fr.orsay.lri.varna.models.annotations.TextAnnotation','.AnchorType'],'fr.orsay.lri.varna.views.VueAnnotation','fr.orsay.lri.varna.models.annotations.TextAnnotation',['java.awt.geom.Point2D','.Double'],'fr.orsay.lri.varna.models.rna.ModeleBase','fr.orsay.lri.varna.models.annotations.HighlightRegionAnnotation','fr.orsay.lri.varna.views.VueHighlightRegionEdit','fr.orsay.lri.varna.models.annotations.ChemProbAnnotation','fr.orsay.lri.varna.views.VueChemProbAnnotation','fr.orsay.lri.varna.views.VueBPList','fr.orsay.lri.varna.views.VueListeAnnotations',['fr.orsay.lri.varna.models.VARNAEdits','.AddBPEdit'],'java.util.HashSet',['fr.orsay.lri.varna.models.VARNAEdits','.RemoveBPEdit'],['fr.orsay.lri.varna.models.VARNAEdits','.BasesShiftEdit'],['fr.orsay.lri.varna.models.VARNAEdits','.SingleBaseMoveEdit'],['fr.orsay.lri.varna.models.VARNAEdits','.HelixFlipEdit'],['fr.orsay.lri.varna.models.VARNAEdits','.HelixRotateEdit']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VueUI");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vp = null;
this._fileChooserDirectory = null;
this._undoableEditSupport = null;
this._varnaFilter = null;
this._bpseqFilter = null;
this._ctFilter = null;
this._dbnFilter = null;
this._jpgFilter = null;
this._pngFilter = null;
this._epsFilter = null;
this._svgFilter = null;
this._xfigFilter = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this._fileChooserDirectory = null;
this._varnaFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["VARNA Session File", "varna", "VARNA"]);
this._bpseqFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["BPSeq (CRW) File", "bpseq", "BPSEQ"]);
this._ctFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["Connect (MFold) File", "ct", "CT"]);
this._dbnFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S$S$S,["Dot-bracket notation (Vienna) File", "dbn", "DBN", "faa", "FAA"]);
this._jpgFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S$S$S,["JPEG Picture", "jpeg", "jpg", "JPG", "JPEG"]);
this._pngFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["PNG Picture", "png", "PNG"]);
this._epsFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["EPS File", "eps", "EPS"]);
this._svgFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S,["SVG Picture", "svg", "SVG"]);
this._xfigFilter = Clazz.new_((I$[1]||$incl$(1)).c$$S$S$S$S$S,["XFig Diagram", "fig", "xfig", "FIG", "XFIG"]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel', function (vp) {
C$.$init$.apply(this);
this._vp = vp;
this._undoableEditSupport = Clazz.new_((I$[2]||$incl$(2)).c$$O,[this._vp]);
}, 1);

Clazz.newMeth(C$, 'addUndoableEditListener$javax_swing_undo_UndoManager', function (manager) {
this._undoableEditSupport.addUndoableEditListener$javax_swing_event_UndoableEditListener(manager);
});

Clazz.newMeth(C$, 'UIToggleColorMap', function () {
if (this._vp.isModifiable()) {
this._vp.setColorMapVisible$Z(!this._vp.getColorMapVisible());
this._vp.repaint();
}});

Clazz.newMeth(C$, 'backupAllCoords', function () {
var tmp = Clazz.new_((I$[3]||$incl$(3)));
for (var i = 0; i < this._vp.getRNA().getSize(); i++) {
tmp.put$TK$TV(new Integer(i), this._vp.getRNA().getCoords$I(i));
}
return tmp;
});

Clazz.newMeth(C$, 'UIToggleFlatExteriorLoop', function () {
if (this._vp.isModifiable() && this._vp.getRNA().get_drawMode() == 2 ) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel$Z,[2, this._vp, !this._vp.getFlatExteriorLoop()]));
this._vp.setFlatExteriorLoop$Z(!this._vp.getFlatExteriorLoop());
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 2);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UIRadiate', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[2, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 2);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UIMOTIFView', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[6, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 6);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UILine', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[4, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 4);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UICircular', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[1, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 1);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UINAView', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[3, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 3);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UIVARNAView', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[5, this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), 5);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'UIReset', function () {
if (this._vp.isModifiable()) {
var bck = this.backupAllCoords();
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[4]||$incl$(4)).c$$I$fr_orsay_lri_varna_VARNAPanel,[this._vp.getRNA().get_drawMode(), this._vp]));
this._vp.reset();
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA$I(this._vp.getRNA(), this._vp.getRNA().get_drawMode());
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(bck);
}});

Clazz.newMeth(C$, 'savePath$javax_swing_JFileChooser', function (jfc) {
this._fileChooserDirectory = jfc.getCurrentDirectory();
});

Clazz.newMeth(C$, 'loadPath$javax_swing_JFileChooser', function (jfc) {
if (this._fileChooserDirectory != null ) {
jfc.setCurrentDirectory$java_io_File(this._fileChooserDirectory);
}});

Clazz.newMeth(C$, 'UIChooseRNAs$java_util_ArrayList', function (rnas) {
if (rnas.size() > 5) {
var vl = Clazz.new_((I$[5]||$incl$(5)).c$$java_util_ArrayList,[rnas]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vl, "Select imported sequence/structures", 2) == 0) {
for (var r, $r = vl.getSelectedRNAs().iterator (); $r.hasNext () && ((r = $r.next ()) || true);) {
try {
r.drawRNA$fr_orsay_lri_varna_models_VARNAConfig(this._vp.getConfig());
} catch (e) {
if (Clazz.exceptionOf(e, "fr.orsay.lri.varna.exceptions.ExceptionNAViewAlgorithm")){
e.printStackTrace();
} else {
throw e;
}
}
this._vp.showRNA$fr_orsay_lri_varna_models_rna_RNA(r);
}
this._vp.repaint();
}} else {
for (var r, $r = rnas.iterator (); $r.hasNext () && ((r = $r.next ()) || true);) {
try {
r.drawRNA$fr_orsay_lri_varna_models_VARNAConfig(this._vp.getConfig());
} catch (e) {
if (Clazz.exceptionOf(e, "fr.orsay.lri.varna.exceptions.ExceptionNAViewAlgorithm")){
e.printStackTrace();
} else {
throw e;
}
}
this._vp.showRNA$fr_orsay_lri_varna_models_rna_RNA(r);
}
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIFile', function () {
if (this._vp.isModifiable()) {
var fc = Clazz.new_((I$[7]||$incl$(7)));
fc.setFileSelectionMode$I(0);
fc.setDialogTitle$S("Open...");
p$.loadPath$javax_swing_JFileChooser.apply(this, [fc]);
if (fc.showOpenDialog$java_awt_Component(this._vp) == 0) {
try {
p$.savePath$javax_swing_JFileChooser.apply(this, [fc]);
var path = fc.getSelectedFile().getAbsolutePath();
if (!path.toLowerCase().endsWith$S(".varna")) {
var rnas = (I$[8]||$incl$(8)).loadSecStr$S(path);
if (rnas.isEmpty()) {
throw Clazz.new_((I$[9]||$incl$(9)).c$$S,["No RNA could be parsed from that source."]);
} else {
this.UIChooseRNAs$java_util_ArrayList(rnas);
}} else {
var bck = this._vp.loadSession$S(path);
}} catch (e$$) {
if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionExportFailed")){
var e1 = e$$;
{
this._vp.errorDialog$Exception(e1);
}
} else if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionPermissionDenied")){
var e1 = e$$;
{
this._vp.errorDialog$Exception(e1);
}
} else if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionLoadingFailed")){
var e1 = e$$;
{
this._vp.errorDialog$Exception(e1);
}
} else if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionFileFormatOrSyntax")){
var e1 = e$$;
{
this._vp.errorDialog$Exception(e1);
}
} else if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionUnmatchedClosingParentheses")){
var e1 = e$$;
{
this._vp.errorDialog$Exception(e1);
}
} else if (Clazz.exceptionOf(e$$, "java.io.FileNotFoundException")){
var e = e$$;
{
this._vp.errorDialog$Exception(e);
}
} else {
throw e$$;
}
}
}}});

Clazz.newMeth(C$, 'UISetColorMapStyle', function () {
var cms = Clazz.new_((I$[10]||$incl$(10)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, cms, "Choose color map style", 2) == 0) {
this._vp.setColorMap$fr_orsay_lri_varna_models_rna_ModeleColorMap(cms.getColorMap());
} else {
cms.cancelChanges();
}});

Clazz.newMeth(C$, 'UILoadColorMapValues', function () {
var cms = Clazz.new_((I$[11]||$incl$(11)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, cms, "Load base values", 2) == 0) {
try {
this._vp.setColorMapVisible$Z(true);
this._vp.readValues$java_io_Reader(cms.getReader());
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
this._vp.errorDialog$Exception(e);
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'UISetColorMapValues', function () {
var cms = Clazz.new_((I$[12]||$incl$(12)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, cms, "Choose base values", 2) == 0) {
} else {
cms.cancelChanges();
}});

Clazz.newMeth(C$, 'UIManualInput', function () {
if (this._vp.isModifiable()) {
var manualInput = Clazz.new_((I$[13]||$incl$(13)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, manualInput.getPanel(), "Input sequence/structure", 2) == 0) {
if (this._vp.getRNA().getSize() == 0) {
}try {
var r = Clazz.new_((I$[14]||$incl$(14)));
var cfg = Clazz.new_((I$[15]||$incl$(15)));
r.setRNA$S$S(manualInput.getTseq().getText(), manualInput.getTstr().getText());
r.drawRNA$I$fr_orsay_lri_varna_models_VARNAConfig(this._vp.getRNA().get_drawMode(), cfg);
this._vp.drawRNAInterpolated$fr_orsay_lri_varna_models_rna_RNA(r);
this._vp.repaint();
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionFileFormatOrSyntax")){
var e = e$$;
{
e.printStackTrace();
}
} else if (Clazz.exceptionOf(e$$, "fr.orsay.lri.varna.exceptions.ExceptionNAViewAlgorithm")){
var e = e$$;
{
e.printStackTrace();
}
} else {
throw e$$;
}
}
}}});

Clazz.newMeth(C$, 'UISetTitle', function () {
if (this._vp.isModifiable()) {
var res = (I$[6]||$incl$(6)).showInputDialog$java_awt_Component$O$O(this._vp, "Input title", this._vp.getTitle());
if (res != null ) {
this._vp.setTitle$S(res);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetColorMapCaption', function () {
if (this._vp.isModifiable()) {
var res = (I$[6]||$incl$(6)).showInputDialog$java_awt_Component$O$O(this._vp, "Input new color map caption", this._vp.getColorMapCaption());
if (res != null ) {
this._vp.setColorMapCaption$S(res);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetBaseCharacter', function () {
if (this._vp.isModifiable()) {
var i = (this._vp.getNearestBase()).intValue();
if (this._vp.isComparisonMode()) {
var res = (I$[6]||$incl$(6)).showInputDialog$java_awt_Component$O$O(this._vp, "Input base", (this._vp.getRNA().get_listeBases().get$I(i)).getBases());
if (res != null ) {
var mb = this._vp.getRNA().get_listeBases().get$I(i);
var bck = mb.getBase1() + "|" + mb.getBase2() ;
mb.setBase1$Character(new Character(((res.length$() > 0) ? res.charAt(0) : ' ')));
mb.setBase2$Character(new Character(((res.length$() > 1) ? res.charAt(1) : ' ')));
this._vp.repaint();
this._vp.fireSequenceChanged$I$S$S(i, bck, res);
}} else {
var res = (I$[6]||$incl$(6)).showInputDialog$java_awt_Component$O$O(this._vp, "Input base", (this._vp.getRNA().get_listeBases().get$I(i)).getBase());
if (res != null ) {
var mb = this._vp.getRNA().get_listeBases().get$I(i);
var bck = mb.getBase();
mb.setBase$S(res);
this._vp.repaint();
this._vp.fireSequenceChanged$I$S$S(i, bck, res);
}}}});

Clazz.newMeth(C$, 'UIExport', function () {
var v = Clazz.new_((I$[16]||$incl$(16)));
v.add$TE(this._epsFilter);
v.add$TE(this._svgFilter);
v.add$TE(this._xfigFilter);
v.add$TE(this._jpgFilter);
v.add$TE(this._pngFilter);
var dest = this.UIChooseOutputFile$java_util_ArrayList(v);
if (dest != null ) {
var extLower = dest.substring(dest.lastIndexOf('.')).toLowerCase();
if (extLower.equals$O(".eps")) {
this._vp.getRNA().saveRNAEPS$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
} else if (extLower.equals$O(".svg")) {
this._vp.getRNA().saveRNASVG$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
} else if (extLower.equals$O(".fig") || extLower.equals$O("xfig") ) {
this._vp.getRNA().saveRNAXFIG$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
} else if (extLower.equals$O(".png")) {
this.saveToPNG$S(dest);
} else if (extLower.equals$O("jpg") || extLower.equals$O("jpeg") ) {
this.saveToJPEG$S(dest);
}}});

Clazz.newMeth(C$, 'UIExportJPEG', function () {
var dest = this.UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._jpgFilter);
if (dest != null ) {
this.saveToJPEG$S(dest);
}});

Clazz.newMeth(C$, 'UIPrint', function () {
(I$[17]||$incl$(17)).printComponent$java_awt_Component(this._vp);
});

Clazz.newMeth(C$, 'UIExportPNG', function () {
var dest = this.UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._pngFilter);
if (dest != null ) {
this.saveToPNG$S(dest);
}});

Clazz.newMeth(C$, 'UIExportXFIG', function () {
var dest = this.UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._xfigFilter);
if (dest != null ) {
this._vp.getRNA().saveRNAXFIG$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
}});

Clazz.newMeth(C$, 'UIExportEPS', function () {
var dest = this.UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._epsFilter);
if (dest != null ) {
this._vp.getRNA().saveRNAEPS$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
}});

Clazz.newMeth(C$, 'UIExportSVG', function () {
var dest = this.UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._svgFilter);
if (dest != null ) {
this._vp.getRNA().saveRNASVG$S$fr_orsay_lri_varna_models_VARNAConfig(dest, this._vp.getConfig());
}});

Clazz.newMeth(C$, 'UISaveAsDBN', function () {
var name = this._vp.getVARNAUI().UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._dbnFilter);
if (name != null ) this._vp.getRNA().saveAsDBN$S$S(name, this._vp.getTitle());
});

Clazz.newMeth(C$, 'UISaveAsCT', function () {
var name = this._vp.getVARNAUI().UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._ctFilter);
if (name != null ) this._vp.getRNA().saveAsCT$S$S(name, this._vp.getTitle());
});

Clazz.newMeth(C$, 'UISaveAsBPSEQ', function () {
var name = this._vp.getVARNAUI().UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter(this._bpseqFilter);
if (name != null ) this._vp.getRNA().saveAsBPSEQ$S$S(name, this._vp.getTitle());
});

Clazz.newMeth(C$, 'UISaveAs', function () {
var v = Clazz.new_((I$[16]||$incl$(16)));
v.add$TE(this._bpseqFilter);
v.add$TE(this._dbnFilter);
v.add$TE(this._ctFilter);
v.add$TE(this._varnaFilter);
var dest = this.UIChooseOutputFile$java_util_ArrayList(v);
if (dest != null ) {
var extLower = dest.substring(dest.lastIndexOf('.')).toLowerCase();
if (extLower.endsWith$S("bpseq")) {
this._vp.getRNA().saveAsBPSEQ$S$S(dest, this._vp.getTitle());
} else if (extLower.endsWith$S("ct")) {
this._vp.getRNA().saveAsCT$S$S(dest, this._vp.getTitle());
} else if (extLower.endsWith$S("dbn") || extLower.endsWith$S("faa") ) {
this._vp.getRNA().saveAsDBN$S$S(dest, this._vp.getTitle());
} else if (extLower.endsWith$S("varna")) {
this._vp.saveSession$S(dest);
}}});

Clazz.newMeth(C$, 'UIChooseOutputFile$fr_orsay_lri_varna_applications_FileNameExtensionFilter', function (filtre) {
var v = Clazz.new_((I$[16]||$incl$(16)));
v.add$TE(filtre);
return this.UIChooseOutputFile$java_util_ArrayList(v);
});

Clazz.newMeth(C$, 'UIChooseOutputFile$java_util_ArrayList', function (filtre) {
var fc = Clazz.new_((I$[7]||$incl$(7)));
p$.loadPath$javax_swing_JFileChooser.apply(this, [fc]);
var absolutePath = null;
for (var i = 0; i < filtre.size(); i++) {
fc.addChoosableFileFilter$javax_swing_filechooser_FileFilter(filtre.get$I(i));
}
fc.setFileSelectionMode$I(0);
fc.setDialogTitle$S("Save...");
if (fc.showSaveDialog$java_awt_Component(this._vp) == 0) {
p$.savePath$javax_swing_JFileChooser.apply(this, [fc]);
absolutePath = fc.getSelectedFile().getAbsolutePath();
var extension = this._vp.getPopupMenu().get_controleurMenu().getExtension$java_io_File(fc.getSelectedFile());
var f = fc.getFileFilter();
if (Clazz.instanceOf(f, "fr.orsay.lri.varna.applications.FileNameExtensionFilter")) {
var listeExtension = Clazz.new_((I$[16]||$incl$(16)));
listeExtension.addAll$java_util_Collection((I$[18]||$incl$(18)).asList$TTA((f).getExtensions()));
if (!listeExtension.contains$O(extension)) {
absolutePath += "." + listeExtension.get$I(0);
}}}return absolutePath;
});

Clazz.newMeth(C$, 'UISetBorder', function () {
var border = Clazz.new_((I$[19]||$incl$(19)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
var oldBorder = this._vp.getBorderSize();
this._vp.drawBBox$Z(true);
this._vp.drawBorder$Z(true);
this._vp.repaint();
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, border.getPanel(), "Set new border size", 2) != 0) {
this._vp.setBorderSize$java_awt_Dimension(oldBorder);
}this._vp.drawBorder$Z(false);
this._vp.drawBBox$Z(false);
this._vp.repaint();
});

Clazz.newMeth(C$, 'UISetBackground', function () {
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose new background color", this._vp.getBackground());
if (c != null ) {
this._vp.setBackground$java_awt_Color(c);
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIZoomIn', function () {
var _actualZoom = this._vp.getZoom();
var _actualAmount = this._vp.getZoomIncrement();
var _actualTranslation = this._vp.getTranslation();
var newZoom = Math.min(60.0, _actualZoom * _actualAmount);
var ratio = newZoom / _actualZoom;
var newTrans = Clazz.new_((I$[21]||$incl$(21)).c$$I$I,[((_actualTranslation.x * ratio)|0), ((_actualTranslation.y * ratio)|0)]);
this._vp.setZoom$O(new Double(newZoom));
this._vp.setTranslation$java_awt_Point(newTrans);
this._vp.checkTranslation();
this._vp.repaint();
});

Clazz.newMeth(C$, 'UIZoomOut', function () {
var _actualZoom = this._vp.getZoom();
var _actualAmount = this._vp.getZoomIncrement();
var _actualTranslation = this._vp.getTranslation();
var newZoom = Math.max(_actualZoom / _actualAmount, 0.5);
var ratio = newZoom / _actualZoom;
var newTrans = Clazz.new_((I$[21]||$incl$(21)).c$$I$I,[((_actualTranslation.x * ratio)|0), ((_actualTranslation.y * ratio)|0)]);
this._vp.setZoom$O(new Double(newZoom));
this._vp.setTranslation$java_awt_Point(newTrans);
this._vp.checkTranslation();
this._vp.repaint();
});

Clazz.newMeth(C$, 'UICustomZoom', function () {
var zoom = Clazz.new_((I$[22]||$incl$(22)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
var oldZoom = this._vp.getZoom();
var oldZoomAmount = this._vp.getZoomIncrement();
this._vp.drawBBox$Z(true);
this._vp.repaint();
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, zoom.getPanel(), "Set zoom", 2) != 0) {
this._vp.setZoom$O(new Double(oldZoom));
this._vp.setZoomIncrement$D(oldZoomAmount);
}this._vp.drawBBox$Z(false);
this._vp.repaint();
});

Clazz.newMeth(C$, 'UIGlobalRescale', function () {
if (this._vp.isModifiable()) {
if (this._vp.getRNA().get_listeBases().size() > 0) {
var rescale = Clazz.new_((I$[23]||$incl$(23)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, rescale.getPanel(), "Rescales the whole RNA (No redraw)", 2) != 0) {
this.UIGlobalRescale$D(1.0 / rescale.getScale());
}this._vp.drawBBox$Z(false);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UIGlobalRescale$D', function (d) {
if (this._vp.isModifiable()) {
if (this._vp.getRNA().get_listeBases().size() > 0) {
this._vp.globalRescale$D(d);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[24]||$incl$(24)).c$$D$fr_orsay_lri_varna_VARNAPanel,[d, this._vp]));
}}});

Clazz.newMeth(C$, 'UIGlobalRotation', function () {
if (this._vp.isModifiable()) {
if (this._vp.getRNA().get_listeBases().size() > 0) {
this._vp.drawBBox$Z(true);
this._vp.repaint();
var rotation = Clazz.new_((I$[25]||$incl$(25)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, rotation.getPanel(), "Rotates the whole RNA", 2) != 0) {
this.UIGlobalRotation$D(-rotation.getAngle());
}this._vp.drawBBox$Z(false);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UIGlobalRotation$D', function (d) {
if (this._vp.isModifiable()) {
if (this._vp.getRNA().get_listeBases().size() > 0) {
this._vp.globalRotation$Double(new Double(d));
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[26]||$incl$(26)).c$$D$fr_orsay_lri_varna_VARNAPanel,[d, this._vp]));
}}});

Clazz.newMeth(C$, 'UISetBPStyle', function () {
if (this._vp.getRNA().get_listeBases().size() > 0) {
var bpstyle = Clazz.new_((I$[27]||$incl$(27)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
var bck = this._vp.getBPStyle();
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, bpstyle.getPanel(), "Set main base pair style", 2) != 0) {
this._vp.setBPStyle$fr_orsay_lri_varna_models_VARNAConfig_BP_STYLE(bck);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetTitleColor', function () {
if (this._vp.isModifiable()) {
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose new title color", this._vp.getTitleColor());
if (c != null ) {
this._vp.setTitleColor$java_awt_Color(c);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetBackboneColor', function () {
if (this._vp.isModifiable()) {
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose new backbone color", this._vp.getBackboneColor());
if (c != null ) {
this._vp.setBackboneColor$java_awt_Color(c);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetTitleFont', function () {
if (this._vp.isModifiable()) {
var font = Clazz.new_((I$[28]||$incl$(28)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, font.getPanel(), "New Title font", 2) == 0) {
this._vp.setTitleFont$java_awt_Font(font.getFont());
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetSpaceBetweenBases', function () {
if (this._vp.isModifiable()) {
var vsbb = Clazz.new_((I$[29]||$incl$(29)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
var oldSpace = new Double(this._vp.getSpaceBetweenBases());
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vsbb.getPanel(), "Set the space between each base", 2) != 0) {
this._vp.setSpaceBetweenBases$D((oldSpace).doubleValue());
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA(this._vp.getRNA());
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetBPHeightIncrement', function () {
if (this._vp.isModifiable()) {
var vsbb = Clazz.new_((I$[30]||$incl$(30)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
var oldSpace = new Double(this._vp.getBPHeightIncrement());
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vsbb.getPanel(), "Set the vertical increment in linear mode", 2) != 0) {
this._vp.setBPHeightIncrement$D((oldSpace).doubleValue());
this._vp.drawRNA$fr_orsay_lri_varna_models_rna_RNA(this._vp.getRNA());
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UISetNumPeriod', function () {
if (this._vp.getRNA().get_listeBases().size() != 0) {
var oldNumPeriod = this._vp.getNumPeriod();
var vnp = Clazz.new_((I$[31]||$incl$(31)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vnp.getPanel(), "Set new numbering period", 2) != 0) {
this._vp.setNumPeriod$I(oldNumPeriod);
this._vp.repaint();
}}});

Clazz.newMeth(C$, 'UIEditBasePair', function () {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().get_listeBases().get$I((this._vp.getNearestBase()).intValue());
if (mb.getElementStructure() != -1) {
var msbp = mb.getStyleBP();
var bck5 = msbp.getEdgePartner5();
var bck3 = msbp.getEdgePartner3();
var bcks = msbp.getStericity();
var vbpt = Clazz.new_((I$[32]||$incl$(32)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_rna_ModeleBP,[this._vp, msbp]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vbpt.getPanel(), "Set base pair L/W type", 2) != 0) {
msbp.setEdge5$fr_orsay_lri_varna_models_rna_ModeleBP_Edge(bck5);
msbp.setEdge3$fr_orsay_lri_varna_models_rna_ModeleBP_Edge(bck3);
msbp.setStericity$fr_orsay_lri_varna_models_rna_ModeleBP_Stericity(bcks);
this._vp.repaint();
}}}});

Clazz.newMeth(C$, 'UIColorBasePair', function () {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().get_listeBases().get$I((this._vp.getNearestBase()).intValue());
if (mb.getElementStructure() != -1) {
var msbp = mb.getStyleBP();
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose custom base pair color", msbp.getStyle().getColor$java_awt_Color(this._vp.getConfig()._bondColor));
if (c != null ) {
msbp.getStyle().setCustomColor$java_awt_Color(c);
this._vp.repaint();
}}}});

Clazz.newMeth(C$, 'UIThicknessBasePair', function () {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().get_listeBases().get$I((this._vp.getNearestBase()).intValue());
if (mb.getElementStructure() != -1) {
var msbp = mb.getStyleBP();
var bases = Clazz.new_((I$[16]||$incl$(16)));
bases.add$TE(msbp);
var vbpt = Clazz.new_((I$[33]||$incl$(33)).c$$fr_orsay_lri_varna_VARNAPanel$java_util_ArrayList,[this._vp, bases]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, vbpt.getPanel(), "Set base pair(s) thickness", 2) != 0) {
vbpt.restoreThicknesses();
this._vp.repaint();
}}}});

Clazz.newMeth(C$, 'saveToPNG$S', function (filename) {
var jpeg = Clazz.new_((I$[34]||$incl$(34)).c$$Z$Z,[true, false]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, jpeg.getPanel(), "Set resolution", 2) == 0) {
var scale = new Double(jpeg.getScaleSlider().getValue() / 100.0);
var myImage = Clazz.new_((I$[35]||$incl$(35)).c$$I$I$I,[(Math.round(this._vp.getWidth() * (scale).doubleValue())|0), (Math.round(this._vp.getHeight() * (scale).doubleValue())|0), 3]);
var g2 = myImage.createGraphics();
var AF = Clazz.new_((I$[36]||$incl$(36)));
AF.setToScale$D$D((scale).doubleValue(), (scale).doubleValue());
g2.setTransform$java_awt_geom_AffineTransform(AF);
this._vp.paintComponent$java_awt_Graphics$Z(g2, !this._vp.getConfig()._drawBackground);
g2.dispose();
try {
(I$[37]||$incl$(37)).write$java_awt_image_RenderedImage$S$java_io_File(myImage, "PNG", Clazz.new_((I$[38]||$incl$(38)).c$$S,[filename]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
e.printStackTrace();
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'saveToJPEG$S', function (filename) {
var jpeg = Clazz.new_((I$[34]||$incl$(34)).c$$Z$Z,[true, true]);
if ((I$[6]||$incl$(6)).showConfirmDialog$java_awt_Component$O$S$I(this._vp, jpeg.getPanel(), "Set resolution/quality", 2) == 0) {
var scale;
if (jpeg.getScaleSlider().getValue() == 0) scale = new Double(0.01);
 else scale = new Double(jpeg.getScaleSlider().getValue() / 100.0);
var myImage = Clazz.new_((I$[35]||$incl$(35)).c$$I$I$I,[(Math.round(this._vp.getWidth() * (scale).doubleValue())|0), (Math.round(this._vp.getHeight() * (scale).doubleValue())|0), 1]);
var g2 = myImage.createGraphics();
var AF = Clazz.new_((I$[36]||$incl$(36)));
AF.setToScale$D$D((scale).doubleValue(), (scale).doubleValue());
g2.setTransform$java_awt_geom_AffineTransform(AF);
this._vp.paintComponent$java_awt_Graphics(g2);
try {
var out = Clazz.new_((I$[39]||$incl$(39)).c$$java_io_File,[Clazz.new_((I$[38]||$incl$(38)).c$$S,[filename])]);
var writer = (I$[37]||$incl$(37)).getImageWritersByFormatName$S("jpeg").next();
var params = writer.getDefaultWriteParam();
params.setCompressionMode$I(2);
params.setCompressionQuality$F(jpeg.getQualitySlider().getValue() / 100.0);
writer.setOutput$O(out);
var myIIOImage = Clazz.new_((I$[40]||$incl$(40)).c$$java_awt_image_RenderedImage$java_util_List$javax_imageio_metadata_IIOMetadata,[myImage, null, null]);
writer.write$javax_imageio_metadata_IIOMetadata$javax_imageio_IIOImage$javax_imageio_ImageWriteParam(null, myIIOImage, params);
out.close();
} catch (e) {
if (Clazz.exceptionOf(e, "java.io.IOException")){
throw Clazz.new_((I$[41]||$incl$(41)).c$$S$S,[e.getMessage(), filename]);
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'UIToggleShowNCBP', function () {
if (this._vp.isModifiable()) {
this._vp.setShowNonCanonicalBP$Z(!this._vp.getShowNonCanonicalBP());
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIToggleColorSpecialBases', function () {
this._vp.setColorNonStandardBases$Z(!this._vp.getColorSpecialBases());
this._vp.repaint();
});

Clazz.newMeth(C$, 'UIToggleColorGapsBases', function () {
this._vp.setColorGapsBases$Z(!this._vp.getColorGapsBases());
this._vp.repaint();
});

Clazz.newMeth(C$, 'UIToggleShowNonPlanar', function () {
if (this._vp.isModifiable()) {
this._vp.setShowNonPlanarBP$Z(!this._vp.getShowNonPlanarBP());
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIToggleShowWarnings', function () {
this._vp.setShowWarnings$Z(!this._vp.getShowWarnings());
this._vp.repaint();
});

Clazz.newMeth(C$, 'UIPickSpecialBasesColor', function () {
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose new special bases color", this._vp.getNonStandardBasesColor());
if (c != null ) {
this._vp.setNonStandardBasesColor$java_awt_Color(c);
this._vp.setColorNonStandardBases$Z(true);
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIPickGapsBasesColor', function () {
var c = (I$[20]||$incl$(20)).showDialog$java_awt_Component$S$java_awt_Color(this._vp, "Choose new gaps bases color", this._vp.getGapsBasesColor());
if (c != null ) {
this._vp.setGapsBasesColor$java_awt_Color(c);
this._vp.setColorGapsBases$Z(true);
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIBaseTypeColor', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[42]||$incl$(42)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 1]);
}});

Clazz.newMeth(C$, 'UIToggleModifiable', function () {
this._vp.setModifiable$Z(!this._vp.isModifiable());
});

Clazz.newMeth(C$, 'UIBasePairTypeColor', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[42]||$incl$(42)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 3]);
}});

Clazz.newMeth(C$, 'UIBaseAllColor', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[42]||$incl$(42)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 2]);
}});

Clazz.newMeth(C$, 'UIAbout', function () {
var about = Clazz.new_((I$[43]||$incl$(43)));
(I$[6]||$incl$(6)).showMessageDialog$java_awt_Component$O$S$I(this._vp, about, "About VARNA 3.9", -1);
about.gracefulStop();
});

Clazz.newMeth(C$, 'UIAutoAnnotateHelices', function () {
if (this._vp.isModifiable()) {
this._vp.getRNA().autoAnnotateHelices();
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAutoAnnotateStrandEnds', function () {
if (this._vp.isModifiable()) {
this._vp.getRNA().autoAnnotateStrandEnds();
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAutoAnnotateInteriorLoops', function () {
if (this._vp.isModifiable()) {
this._vp.getRNA().autoAnnotateInteriorLoops();
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAutoAnnotateTerminalLoops', function () {
if (this._vp.isModifiable()) {
this._vp.getRNA().autoAnnotateTerminalLoops();
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAnnotationRemoveFromAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation', function (textAnnotation) {
if (this._vp.isModifiable()) {
this._vp.set_selectedAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(null);
this._vp.getListeAnnotations().remove$O(textAnnotation);
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAnnotationEditFromAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation', function (textAnnotation) {
var vue;
if (textAnnotation.getType() === (I$[44]||$incl$(44)).POSITION ) vue = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnotation, false]);
 else vue = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z$Z,[this._vp, textAnnotation, true, false]);
vue.show();
});

Clazz.newMeth(C$, 'UIAnnotationAddFromStructure$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType$java_util_ArrayList', function (type, listeIndex) {
var textAnnot;
var listeBase;
var vue;
switch (type) {
case (I$[44]||$incl$(44)).BASE:
textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$fr_orsay_lri_varna_models_rna_ModeleBase,["", this._vp.getRNA().get_listeBases().get$I((listeIndex.get$I(0)).intValue())]);
vue = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
vue.show();
break;
case (I$[44]||$incl$(44)).LOOP:
listeBase = Clazz.new_((I$[16]||$incl$(16)));
for (var i, $i = listeIndex.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
listeBase.add$TE(this._vp.getRNA().get_listeBases().get$I((i).intValue()));
}
textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,["", listeBase, type]);
vue = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
vue.show();
break;
case (I$[44]||$incl$(44)).HELIX:
listeBase = Clazz.new_((I$[16]||$incl$(16)));
for (var i, $i = listeIndex.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
listeBase.add$TE(this._vp.getRNA().get_listeBases().get$I((i).intValue()));
}
textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,["", listeBase, type]);
vue = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
vue.show();
break;
default:
this._vp.errorDialog$Exception(Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Unknown structure type"]));
break;
}
});

Clazz.newMeth(C$, 'UIAnnotationEditFromStructure$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType$java_util_ArrayList', function (type, listeIndex) {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().get_listeBases().get$I((listeIndex.get$I(0)).intValue());
var ta = this._vp.getRNA().getAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType$fr_orsay_lri_varna_models_rna_ModeleBase(type, mb);
if (ta != null ) this.UIAnnotationEditFromAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(ta);
}});

Clazz.newMeth(C$, 'UIAnnotationRemoveFromStructure$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType$java_util_ArrayList', function (type, listeIndex) {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().get_listeBases().get$I((listeIndex.get$I(0)).intValue());
var ta = this._vp.getRNA().getAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType$fr_orsay_lri_varna_models_rna_ModeleBase(type, mb);
if (ta != null ) this.UIAnnotationRemoveFromAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(ta);
}});

Clazz.newMeth(C$, 'UIAnnotationsAddPosition$I$I', function (x, y) {
if (this._vp.isModifiable()) {
var p = this._vp.panelToLogicPoint$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
var annotationAdd = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$I$I,[this._vp, (p.x|0), (p.y|0)]);
annotationAdd.show();
}});

Clazz.newMeth(C$, 'UIAnnotationsAddBase$I$I', function (x, y) {
if (this._vp.isModifiable()) {
var mb = this._vp.getBaseAt$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
if (mb != null ) {
this._vp.highlightSelectedBase$fr_orsay_lri_varna_models_rna_ModeleBase(mb);
var textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$fr_orsay_lri_varna_models_rna_ModeleBase,["", mb]);
var annotationAdd = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
annotationAdd.show();
}}});

Clazz.newMeth(C$, 'UIAnnotationsAddLoop$I$I', function (x, y) {
if (this._vp.isModifiable()) {
try {
var mb = this._vp.getBaseAt$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
if (mb != null ) {
var v = this._vp.getRNA().getLoopBases$I(mb.getIndex());
var mbs = this._vp.getRNA().getBasesAt$java_util_Collection(v);
var textAnnot;
textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,["", mbs, (I$[44]||$incl$(44)).LOOP]);
this._vp.setSelection$java_util_Collection(mbs);
var annotationAdd = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
annotationAdd.show();
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'extractMaxContiguousPortion$java_util_ArrayList', function (m) {
var tab = Clazz.array((I$[48]||$incl$(48)), [this._vp.getRNA().getSize()]);
for (var i = 0; i < tab.length; i++) {
tab[i] = null;
}
for (var mb, $mb = m.iterator (); $mb.hasNext () && ((mb = $mb.next ()) || true);) {
tab[mb.getIndex()] = mb;
}
var best = Clazz.new_((I$[16]||$incl$(16)));
var current = Clazz.new_((I$[16]||$incl$(16)));
for (var i = 0; i < tab.length; i++) {
if (tab[i] != null ) {
current.add$TE(tab[i]);
} else {
if (current.size() > best.size()) best = current;
current = Clazz.new_((I$[16]||$incl$(16)));
}}
if (current.size() > best.size()) {
best = current;
}return best;
});

Clazz.newMeth(C$, 'UIAnnotationsAddRegion$I$I', function (x, y) {
if (this._vp.isModifiable()) {
var mb = this._vp.getSelection().getBases();
if (mb.size() == 0) {
var m = this._vp.getBaseAt$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
mb.add$TE(m);
}mb = p$.extractMaxContiguousPortion$java_util_ArrayList.apply(this, [p$.extractMaxContiguousPortion$java_util_ArrayList.apply(this, [mb])]);
this._vp.setSelection$java_util_Collection(mb);
var regionAnnot = Clazz.new_((I$[49]||$incl$(49)).c$$java_util_ArrayList,[mb]);
this._vp.addHighlightRegion$fr_orsay_lri_varna_models_annotations_HighlightRegionAnnotation(regionAnnot);
var annotationAdd = Clazz.new_((I$[50]||$incl$(50)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_HighlightRegionAnnotation,[this._vp, regionAnnot]);
if (!annotationAdd.show()) {
this._vp.removeHighlightRegion$fr_orsay_lri_varna_models_annotations_HighlightRegionAnnotation(regionAnnot);
}this._vp.clearSelection();
}});

Clazz.newMeth(C$, 'UIAnnotationsAddChemProb$I$I', function (x, y) {
if (this._vp.isModifiable() && this._vp.getRNA().getSize() > 1 ) {
var p = this._vp.panelToLogicPoint$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
var m1 = this._vp.getBaseAt$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
var best = null;
if (m1.getIndex() - 1 >= 0) {
best = this._vp.getRNA().getBaseAt$I(m1.getIndex() - 1);
}if (m1.getIndex() + 1 < this._vp.getRNA().getSize()) {
var m2 = this._vp.getRNA().getBaseAt$I(m1.getIndex() + 1);
if (best == null ) {
best = m2;
} else {
if (best.getCoords().distance$java_awt_geom_Point2D(p) > m2.getCoords().distance$java_awt_geom_Point2D(p) ) {
best = m2;
}}}var tab = Clazz.new_((I$[16]||$incl$(16)));
tab.add$TE(m1);
tab.add$TE(best);
this._vp.setSelection$java_util_Collection(tab);
var regionAnnot = Clazz.new_((I$[51]||$incl$(51)).c$$fr_orsay_lri_varna_models_rna_ModeleBase$fr_orsay_lri_varna_models_rna_ModeleBase,[m1, best]);
this._vp.getRNA().addChemProbAnnotation$fr_orsay_lri_varna_models_annotations_ChemProbAnnotation(regionAnnot);
var annotationAdd = Clazz.new_((I$[52]||$incl$(52)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_ChemProbAnnotation,[this._vp, regionAnnot]);
if (!annotationAdd.show()) {
this._vp.getRNA().removeChemProbAnnotation$fr_orsay_lri_varna_models_annotations_ChemProbAnnotation(regionAnnot);
}this._vp.clearSelection();
}});

Clazz.newMeth(C$, 'UIAnnotationsAddHelix$I$I', function (x, y) {
if (this._vp.isModifiable()) {
try {
var mb = this._vp.getBaseAt$java_awt_geom_Point2D_Double(Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
if (mb != null ) {
var v = this._vp.getRNA().findHelix$I(mb.getIndex());
var mbs = this._vp.getRNA().getBasesAt$java_util_Collection(v);
var textAnnot;
textAnnot = Clazz.new_((I$[46]||$incl$(46)).c$$S$java_util_ArrayList$fr_orsay_lri_varna_models_annotations_TextAnnotation_AnchorType,["", mbs, (I$[44]||$incl$(44)).HELIX]);
this._vp.setSelection$java_util_Collection(mbs);
var annotationAdd = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z,[this._vp, textAnnot, true]);
annotationAdd.show();
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'UIToggleGaspinMode', function () {
if (this._vp.isModifiable()) {
this._vp.toggleDrawOutlineBases();
this._vp.toggleFillBases();
this._vp.repaint();
}});

Clazz.newMeth(C$, 'UIAnnotationsAdd', function () {
if (this._vp.isModifiable()) {
var annotationAdd = Clazz.new_((I$[45]||$incl$(45)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
annotationAdd.show();
}});

Clazz.newMeth(C$, 'UIEditAllBasePairs', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[53]||$incl$(53)).c$$fr_orsay_lri_varna_VARNAPanel,[this._vp]);
}});

Clazz.newMeth(C$, 'UIEditAllBases', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[42]||$incl$(42)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 2]);
}});

Clazz.newMeth(C$, 'UIAnnotationsRemove', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[54]||$incl$(54)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 0]);
}});

Clazz.newMeth(C$, 'UIAnnotationsEdit', function () {
if (this._vp.isModifiable()) {
Clazz.new_((I$[54]||$incl$(54)).c$$fr_orsay_lri_varna_VARNAPanel$I,[this._vp, 1]);
}});

Clazz.newMeth(C$, 'UIAddBP$I$I$fr_orsay_lri_varna_models_rna_ModeleBP', function (i, j, ms) {
if (this._vp.isModifiable()) {
this._vp.getRNA().addBP$I$I$fr_orsay_lri_varna_models_rna_ModeleBP(i, j, ms);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[55]||$incl$(55)).c$$I$I$fr_orsay_lri_varna_models_rna_ModeleBP$fr_orsay_lri_varna_VARNAPanel,[i, j, ms, this._vp]));
this._vp.repaint();
var tmp = Clazz.new_((I$[56]||$incl$(56)));
tmp.add$TE(ms);
this._vp.fireStructureChanged$java_util_Set$java_util_Set$java_util_Set(Clazz.new_((I$[56]||$incl$(56)).c$$java_util_Collection,[this._vp.getRNA().getAllBPs()]), tmp, Clazz.new_((I$[56]||$incl$(56))));
}});

Clazz.newMeth(C$, 'UIRemoveBP$fr_orsay_lri_varna_models_rna_ModeleBP', function (ms) {
if (this._vp.isModifiable()) {
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[57]||$incl$(57)).c$$I$I$fr_orsay_lri_varna_models_rna_ModeleBP$fr_orsay_lri_varna_VARNAPanel,[ms.getIndex5(), ms.getIndex3(), ms, this._vp]));
this._vp.getRNA().removeBP$fr_orsay_lri_varna_models_rna_ModeleBP(ms);
this._vp.repaint();
var tmp = Clazz.new_((I$[56]||$incl$(56)));
tmp.add$TE(ms);
this._vp.fireStructureChanged$java_util_Set$java_util_Set$java_util_Set(Clazz.new_((I$[56]||$incl$(56)).c$$java_util_Collection,[this._vp.getRNA().getAllBPs()]), Clazz.new_((I$[56]||$incl$(56))), tmp);
}});

Clazz.newMeth(C$, 'UIShiftBaseCoord$java_util_ArrayList$D$D', function (indices, dx, dy) {
if (this._vp.isModifiable()) {
var backupPos = Clazz.new_((I$[3]||$incl$(3)));
for (var index, $index = indices.iterator (); $index.hasNext () && ((index = $index.next ()) || true);) {
var mb = this._vp.getRNA().getBaseAt$I(index);
var d = mb.getCoords();
backupPos.put$TK$TV(new Integer(index), d);
this._vp.getRNA().setCoord$I$D$D(index, d.x + dx, d.y + dy);
this._vp.getRNA().setCenter$I$D$D(index, mb.getCenter().x + dx, mb.getCenter().y + dy);
}
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[58]||$incl$(58)).c$$java_util_ArrayList$D$D$fr_orsay_lri_varna_VARNAPanel,[indices, dx, dy, this._vp]));
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(backupPos);
}});

Clazz.newMeth(C$, 'UIShiftBaseCoord$java_util_ArrayList$java_awt_geom_Point2D_Double', function (indices, dv) {
this.UIShiftBaseCoord$java_util_ArrayList$D$D(indices, dv.x, dv.y);
});

Clazz.newMeth(C$, 'UIMoveSingleBase$I$D$D', function (index, nx, ny) {
if (this._vp.isModifiable()) {
var mb = this._vp.getRNA().getBaseAt$I(index);
var d = mb.getCoords();
var backupPos = Clazz.new_((I$[3]||$incl$(3)));
backupPos.put$TK$TV(new Integer(index), d);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[59]||$incl$(59)).c$$I$D$D$fr_orsay_lri_varna_VARNAPanel,[index, nx, ny, this._vp]));
this._vp.getRNA().setCoord$I$D$D(index, nx, ny);
this._vp.repaint();
this._vp.fireLayoutChanged$java_util_Hashtable(backupPos);
}});

Clazz.newMeth(C$, 'UIMoveSingleBase$I$java_awt_geom_Point2D_Double', function (index, dv) {
this.UIMoveSingleBase$I$D$D(index, dv.x, dv.y);
});

Clazz.newMeth(C$, 'UISetBaseCenter$I$D$D', function (index, x, y) {
this.UISetBaseCenter$I$java_awt_geom_Point2D_Double(index, Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[x, y]));
});

Clazz.newMeth(C$, 'UISetBaseCenter$I$java_awt_geom_Point2D_Double', function (index, p) {
if (this._vp.isModifiable()) {
this._vp.getRNA().setCenter$I$java_awt_geom_Point2D_Double(index, p);
}});

Clazz.newMeth(C$, 'UIUndo', function () {
this._vp.undo();
});

Clazz.newMeth(C$, 'UIRedo', function () {
this._vp.redo();
});

Clazz.newMeth(C$, 'UIMoveHelixAtom$I$java_awt_geom_Point2D_Double', function (index, newPos) {
if (this._vp.isModifiable() && (index >= 0) && (index < this._vp.getRNA().get_listeBases().size())  ) {
var indexTo = this._vp.getRNA().get_listeBases().get$I(index).getElementStructure();
var h = this._vp.getRNA().getHelixInterval$I(index);
var ml = this._vp.getRNA().getMultiLoop$I(h.x);
var i = ml.x;
if (indexTo != -1) {
if (i == 0) {
if (this.shouldFlip$I$java_awt_geom_Point2D_Double(index, newPos)) {
this.UIFlipHelix$java_awt_Point(h);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[60]||$incl$(60)).c$$java_awt_Point$fr_orsay_lri_varna_VARNAPanel,[h, this._vp]));
}} else {
this.UIRotateHelixAtom$I$java_awt_geom_Point2D_Double(index, newPos);
}}this._vp.fireLayoutChanged();
}});

Clazz.newMeth(C$, 'project$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double', function (O, Ox, C) {
var OC = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[C.x - O.x, C.y - O.y]);
var normOX = (Ox.x * OC.x + Ox.y * OC.y);
var OX = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[(normOX * Ox.x), (normOX * Ox.y)]);
var XC = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[OC.x - OX.x, OC.y - OX.y]);
var OCP = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[OX.x - XC.x, OX.y - XC.y]);
var CP = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[O.x + OCP.x, O.y + OCP.y]);
return CP;
});

Clazz.newMeth(C$, 'UIFlipHelix$java_awt_Point', function (h) {
var hBeg = h.x;
var hEnd = h.y;
var A = this._vp.getRNA().getCoords$I(hBeg);
var B = this._vp.getRNA().getCoords$I(hEnd);
var AB = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[B.x - A.x, B.y - A.y]);
var normAB = Math.sqrt(AB.x * AB.x + AB.y * AB.y);
var O = A;
var Ox = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[AB.x / normAB, AB.y / normAB]);
var old = Clazz.new_((I$[3]||$incl$(3)));
for (var i = hBeg + 1; i < hEnd; i++) {
var P = this._vp.getRNA().getCoords$I(i);
var nP = p$.project$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double.apply(this, [O, Ox, P]);
old.put$TK$TV(new Integer(i), nP);
this._vp.getRNA().setCoord$I$java_awt_geom_Point2D_Double(i, nP);
var Center = this._vp.getRNA().getCenter$I(i);
this._vp.getVARNAUI().UISetBaseCenter$I$java_awt_geom_Point2D_Double(i, p$.project$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double.apply(this, [O, Ox, Center]));
}
this._vp.fireLayoutChanged$java_util_Hashtable(old);
});

Clazz.newMeth(C$, 'shouldFlip$I$java_awt_geom_Point2D_Double', function (index, P) {
var h = this._vp.getRNA().getHelixInterval$I(index);
var A = this._vp.getRNA().getCoords$I(h.x);
var B = this._vp.getRNA().getCoords$I(h.y);
var C = this._vp.getRNA().getCoords$I(h.x + 1);
var hAB = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[B.y - A.y, -(B.x - A.x)]);
var AC = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[C.x - A.x, C.y - A.y]);
var AP = Clazz.new_((I$[47]||$incl$(47)).c$$D$D,[P.x - A.x, P.y - A.y]);
var signC = (hAB.x * AC.x + hAB.y * AC.y);
var signP = (hAB.x * AP.x + hAB.y * AP.y);
return (signC * signP < 0.0 );
});

Clazz.newMeth(C$, 'UIRotateHelixAtom$I$java_awt_geom_Point2D_Double', function (index, newPos) {
var h = this._vp.getRNA().getHelixInterval$I(index);
var ml = this._vp.getRNA().getMultiLoop$I(h.x);
var i = ml.x;
var prevIndex = h.x;
var nextIndex = h.y;
while (i <= ml.y){
var j = this._vp.getRNA().get_listeBases().get$I(i).getElementStructure();
if ((j != -1) && (i < h.x) ) {
prevIndex = i;
}if ((j != -1) && (i > h.y) && (nextIndex == h.y)  ) {
nextIndex = i;
}if ((j > i) && (j < ml.y) ) {
i = this._vp.getRNA().get_listeBases().get$I(i).getElementStructure();
} else {
i++;
}}
var oldPos = this._vp.getRNA().getCoords$I(index);
var limitLoopLeft;
var limitLoopRight;
var limitLeft;
var limitRight;
var helixStart;
var helixStop;
var isDirect = this._vp.getRNA().testDirectionality$I$I$I(ml.x, ml.y, h.x);
if (isDirect) {
limitLoopLeft = this._vp.getRNA().getCoords$I(ml.y);
limitLoopRight = this._vp.getRNA().getCoords$I(ml.x);
limitLeft = this._vp.getRNA().getCoords$I(prevIndex);
limitRight = this._vp.getRNA().getCoords$I(nextIndex);
helixStart = this._vp.getRNA().getCoords$I(h.x);
helixStop = this._vp.getRNA().getCoords$I(h.y);
} else {
limitLoopLeft = this._vp.getRNA().getCoords$I(ml.x);
limitLoopRight = this._vp.getRNA().getCoords$I(ml.y);
limitLeft = this._vp.getRNA().getCoords$I(nextIndex);
limitRight = this._vp.getRNA().getCoords$I(prevIndex);
helixStart = this._vp.getRNA().getCoords$I(h.y);
helixStop = this._vp.getRNA().getCoords$I(h.x);
}var center = this._vp.getRNA().get_listeBases().get$I(h.x).getCenter();
var base = ((I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, limitLoopRight) + (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, limitLoopLeft)) / 2.0;
var pLimR = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, limitLeft) - base;
var pHelR = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, helixStart) - base;
var pNew = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, newPos) - base;
var pOld = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, oldPos) - base;
var pHelL = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, helixStop) - base;
var pLimL = (I$[14]||$incl$(14)).computeAngle$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double(center, limitRight) - base;
while (pLimR < 0.0 )pLimR += 6.283185307179586;

while (pHelR < pLimR )pHelR += 6.283185307179586;

while ((pNew < pHelR ))pNew += 6.283185307179586;

while ((pOld < pHelR ))pOld += 6.283185307179586;

while ((pHelL < pOld ))pHelL += 6.283185307179586;

while ((pLimL < pHelL ))pLimL += 6.283185307179586;

var minDelta = p$.normalizeAngle$D.apply(this, [(pLimR - pHelR) + 0.25]);
var maxDelta = p$.normalizeAngle$D.apply(this, [(pLimL - pHelL) - 0.25]);
while (maxDelta < minDelta )maxDelta += 6.283185307179586;

var delta = p$.normalizeAngle$D.apply(this, [pNew - pOld]);
while (delta < minDelta )delta += 6.283185307179586;

if (delta > maxDelta ) {
var distanceMax = delta - maxDelta;
var distanceMin = minDelta - (delta - 6.283185307179586);
if (distanceMin < distanceMax ) {
delta = minDelta;
} else {
delta = maxDelta;
}}var corrected = (I$[14]||$incl$(14)).correctHysteresis$D((delta + base + (pHelR + pHelL) / 2.0 ));
delta = corrected - (base + (pHelR + pHelL) / 2.0);
this._undoableEditSupport.postEdit$javax_swing_undo_UndoableEdit(Clazz.new_((I$[61]||$incl$(61)).c$$D$D$D$D$java_awt_Point$java_awt_Point$fr_orsay_lri_varna_VARNAPanel,[delta, base, pLimL, pLimR, h, ml, this._vp]));
this.UIRotateEverything$D$D$D$D$java_awt_Point$java_awt_Point(delta, base, pLimL, pLimR, h, ml);
});

Clazz.newMeth(C$, 'UIRotateEverything$D$D$D$D$java_awt_Point$java_awt_Point', function (delta, base, pLimL, pLimR, h, ml) {
var backupPos = Clazz.new_((I$[3]||$incl$(3)));
this._vp.getRNA().rotateEverything$D$D$D$D$java_awt_Point$java_awt_Point$java_util_Hashtable(delta, base, pLimL, pLimR, h, ml, backupPos);
this._vp.fireLayoutChanged$java_util_Hashtable(backupPos);
});

Clazz.newMeth(C$, 'normalizeAngle$D', function (angle) {
return p$.normalizeAngle$D$D.apply(this, [angle, 0.0]);
});

Clazz.newMeth(C$, 'normalizeAngle$D$D', function (angle, base) {
while (angle < base ){
angle += 6.283185307179586;
}
while (angle >= 6.283185307179586 - base ){
angle -= 6.283185307179586;
}
return angle;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:38:31
