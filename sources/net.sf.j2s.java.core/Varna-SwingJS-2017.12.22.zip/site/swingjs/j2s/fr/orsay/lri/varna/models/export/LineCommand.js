(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.models.export"),I$=[];
var C$=Clazz.newClass(P$, "LineCommand", null, 'fr.orsay.lri.varna.models.export.GraphicElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._orig = null;
this._dest = null;
this._thickness = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_geom_Point2D_Double$java_awt_geom_Point2D_Double$D', function (orig, dest, thickness) {
Clazz.super_(C$, this,1);
this._orig = orig;
this._dest = dest;
this._thickness = thickness;
}, 1);

Clazz.newMeth(C$, 'get_orig', function () {
return this._orig;
});

Clazz.newMeth(C$, 'get_dest', function () {
return this._dest;
});

Clazz.newMeth(C$, 'get_thickness', function () {
return this._thickness;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:37:53
