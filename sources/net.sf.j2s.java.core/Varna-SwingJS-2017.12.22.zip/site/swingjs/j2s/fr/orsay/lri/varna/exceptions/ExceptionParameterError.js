(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.exceptions"),I$=[];
var C$=Clazz.newClass(P$, "ExceptionParameterError", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._errorMessage = null;
this._details = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (errorMessage, details) {
Clazz.super_(C$, this,1);
this._errorMessage = errorMessage;
this._details = details;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (details) {
Clazz.super_(C$, this,1);
this._errorMessage = "";
this._details = details;
}, 1);

Clazz.newMeth(C$, 'getError', function () {
return this._errorMessage;
});

Clazz.newMeth(C$, 'getMessage', function () {
return this._details;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:37:50
