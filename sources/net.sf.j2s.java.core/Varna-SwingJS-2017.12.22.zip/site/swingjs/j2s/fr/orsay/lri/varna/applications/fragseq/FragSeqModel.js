(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications.fragseq"),I$=[];
var C$=Clazz.newClass(P$, "FragSeqModel", null, null, 'Comparable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['compareTo$fr_orsay_lri_varna_applications_fragseq_FragSeqModel','compareTo$TT'], function (o) {
return 0;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:36:55
