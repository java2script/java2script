(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.views"),I$=[['fr.orsay.lri.varna.models.annotations.TextAnnotation',['fr.orsay.lri.varna.models.annotations.TextAnnotation','.AnchorType'],'fr.orsay.lri.varna.controlers.ControleurVueAnnotation','javax.swing.JPanel','java.awt.GridLayout','java.awt.FlowLayout','javax.swing.JSlider','java.awt.Dimension','javax.swing.JLabel','fr.orsay.lri.varna.controlers.ControleurSliderLabel','java.awt.BorderLayout','javax.swing.JTextArea',['javax.swing.plaf.basic.BasicBorders','.FieldBorder'],'java.awt.Color','fr.orsay.lri.varna.views.VueFont','javax.swing.JButton','javax.swing.JOptionPane']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VueAnnotation");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._vp = null;
this.ySlider = null;
this.xSlider = null;
this.colorButton = null;
this.textArea = null;
this.panel = null;
this.textAnnotation = null;
this.textAnnotationSave = null;
this.vueFont = null;
this._controleurVueAnnotation = null;
this.newAnnotation = false;
this.limited = false;
this.position = null;
this.rotationSlider = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$Z', function (vp, limited) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$I$I$Z.apply(this, [vp, ((vp.getExtendedRNABBox().x + vp.getExtendedRNABBox().width / 2.0)|0), ((vp.getExtendedRNABBox().y + vp.getExtendedRNABBox().height / 2.0)|0), limited]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel', function (vp) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$Z.apply(this, [vp, false]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$I$I', function (vp, x, y) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$I$I$Z.apply(this, [vp, x, y, false]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$I$I$Z', function (vp, x, y, limited) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z$Z.apply(this, [vp, Clazz.new_((I$[1]||$incl$(1)).c$$S$D$D,["", x, y]), false, true]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z', function (vp, textAnnot, newAnnotation) {
C$.c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z$Z.apply(this, [vp, textAnnot, (textAnnot.getType() !== (I$[2]||$incl$(2)).POSITION ), newAnnotation]);
}, 1);

Clazz.newMeth(C$, 'c$$fr_orsay_lri_varna_VARNAPanel$fr_orsay_lri_varna_models_annotations_TextAnnotation$Z$Z', function (vp, textAnnot, reduite, newAnnotation) {
C$.$init$.apply(this);
this.limited = reduite;
this.newAnnotation = newAnnotation;
this._vp = vp;
this.textAnnotation = textAnnot;
this.textAnnotationSave = this.textAnnotation.clone();
if (!this._vp.getListeAnnotations().contains$O(textAnnot)) {
this._vp.addAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(this.textAnnotation);
}this._controleurVueAnnotation = Clazz.new_((I$[3]||$incl$(3)).c$$fr_orsay_lri_varna_views_VueAnnotation,[this]);
this.position = this.textAnnotation.getCenterPosition();
var py = Clazz.new_((I$[4]||$incl$(4)));
var px = Clazz.new_((I$[4]||$incl$(4)));
this.panel = Clazz.new_((I$[4]||$incl$(4)));
this.panel.setLayout$java_awt_LayoutManager(Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[0, 1]));
py.setLayout$java_awt_LayoutManager(Clazz.new_((I$[6]||$incl$(6)).c$$I,[0]));
px.setLayout$java_awt_LayoutManager(Clazz.new_((I$[6]||$incl$(6)).c$$I,[0]));
this.ySlider = Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I$I,[0, 0, ((this._vp.getExtendedRNABBox().height)|0), Math.max(0, Math.min(((this._vp.getExtendedRNABBox().height)|0), ((this.position.y - this._vp.getExtendedRNABBox().y)|0)))]);
this.ySlider.setMajorTickSpacing$I(500);
this.ySlider.setMinorTickSpacing$I(100);
this.ySlider.setPaintTicks$Z(true);
this.ySlider.setPaintLabels$Z(true);
this.ySlider.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[400, this.ySlider.getPreferredSize().height]));
var yValueLabel = Clazz.new_((I$[9]||$incl$(9)).c$$S,[String.valueOf((this.position.y|0) - this._vp.getExtendedRNABBox().y)]);
yValueLabel.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[50, yValueLabel.getPreferredSize().height]));
this.ySlider.addChangeListener$javax_swing_event_ChangeListener(Clazz.new_((I$[10]||$incl$(10)).c$$javax_swing_JLabel$Z,[yValueLabel, false]));
this.ySlider.addChangeListener$javax_swing_event_ChangeListener(this._controleurVueAnnotation);
this.xSlider = Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I$I,[0, 0, ((this._vp.getExtendedRNABBox().width)|0), Math.max(0, Math.min((this._vp.getExtendedRNABBox().width|0), ((this.position.x - this._vp.getExtendedRNABBox().x)|0)))]);
this.xSlider.setMajorTickSpacing$I(500);
this.xSlider.setMinorTickSpacing$I(100);
this.xSlider.setPaintTicks$Z(true);
this.xSlider.setPaintLabels$Z(true);
this.xSlider.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[400, this.xSlider.getPreferredSize().height]));
var xValueLabel = Clazz.new_((I$[9]||$incl$(9)).c$$S,[String.valueOf((this.position.x|0) - this._vp.getExtendedRNABBox().x)]);
xValueLabel.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[50, xValueLabel.getPreferredSize().height]));
this.xSlider.addChangeListener$javax_swing_event_ChangeListener(Clazz.new_((I$[10]||$incl$(10)).c$$javax_swing_JLabel$Z,[xValueLabel, false]));
this.xSlider.addChangeListener$javax_swing_event_ChangeListener(this._controleurVueAnnotation);
var labelY = Clazz.new_((I$[9]||$incl$(9)).c$$S,["Y:"]);
var labelX = Clazz.new_((I$[9]||$incl$(9)).c$$S,["X:"]);
py.add$java_awt_Component(labelY);
py.add$java_awt_Component(this.ySlider);
py.add$java_awt_Component(yValueLabel);
px.add$java_awt_Component(labelX);
px.add$java_awt_Component(this.xSlider);
px.add$java_awt_Component(xValueLabel);
var panelTexte = Clazz.new_((I$[4]||$incl$(4)));
panelTexte.setLayout$java_awt_LayoutManager(Clazz.new_((I$[11]||$incl$(11))));
this.textArea = Clazz.new_((I$[12]||$incl$(12)).c$$S,[this.textAnnotation.getTexte()]);
this.textArea.addCaretListener$javax_swing_event_CaretListener(this._controleurVueAnnotation);
this.textArea.setPreferredSize$java_awt_Dimension(panelTexte.getSize());
var border = Clazz.new_((I$[13]||$incl$(13)).c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[(I$[14]||$incl$(14)).black, (I$[14]||$incl$(14)).black, (I$[14]||$incl$(14)).black, (I$[14]||$incl$(14)).black]);
this.textArea.setBorder$javax_swing_border_Border(border);
var labelTexte = Clazz.new_((I$[9]||$incl$(9)).c$$S,["Text:"]);
panelTexte.add$java_awt_Component$O(this.textArea, "Center");
panelTexte.add$java_awt_Component$O(labelTexte, "North");
this.panel.add$java_awt_Component(panelTexte);
this.vueFont = Clazz.new_((I$[15]||$incl$(15)).c$$java_awt_Font,[textAnnot.getFont()]);
this.vueFont.getBoxPolice().addActionListener$java_awt_event_ActionListener(this._controleurVueAnnotation);
this.vueFont.getSizeSlider().addChangeListener$javax_swing_event_ChangeListener(this._controleurVueAnnotation);
this.vueFont.getStylesBox().addActionListener$java_awt_event_ActionListener(this._controleurVueAnnotation);
this.colorButton = Clazz.new_((I$[16]||$incl$(16)).c$$S,["Set color"]);
this.colorButton.setActionCommand$S("setcolor");
this.colorButton.setForeground$java_awt_Color(textAnnot.getColor());
this.colorButton.addActionListener$java_awt_event_ActionListener(this._controleurVueAnnotation);
var fontAndColor = Clazz.new_((I$[4]||$incl$(4)));
fontAndColor.add$java_awt_Component(this.vueFont.getPanel());
fontAndColor.add$java_awt_Component(this.colorButton);
this.panel.add$java_awt_Component(fontAndColor);
var rotationPanel = Clazz.new_((I$[4]||$incl$(4)));
this.rotationSlider = Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I$I,[0, -360, 360, (this.textAnnotation.getAngleInDegres()|0)]);
this.rotationSlider.setMajorTickSpacing$I(60);
this.rotationSlider.setPaintTicks$Z(true);
this.rotationSlider.setPaintLabels$Z(true);
this.rotationSlider.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[500, 50]));
var rotationLabel = Clazz.new_((I$[9]||$incl$(9)).c$$S,[String.valueOf(0)]);
rotationLabel.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[50, rotationLabel.getPreferredSize().height]));
this.rotationSlider.addChangeListener$javax_swing_event_ChangeListener(Clazz.new_((I$[10]||$incl$(10)).c$$javax_swing_JLabel$Z,[rotationLabel, false]));
this.rotationSlider.addChangeListener$javax_swing_event_ChangeListener(this._controleurVueAnnotation);
var labelZ = Clazz.new_((I$[9]||$incl$(9)).c$$S,["Rotation (degrees):"]);
rotationPanel.add$java_awt_Component(labelZ);
rotationPanel.add$java_awt_Component(this.rotationSlider);
rotationPanel.add$java_awt_Component(rotationLabel);
if (this.limited) {
this.ySlider.setEnabled$Z(false);
this.xSlider.setEnabled$Z(false);
this.rotationSlider.setEnabled$Z(false);
}this.textArea.requestFocusInWindow();
}, 1);

Clazz.newMeth(C$, 'applyFont', function () {
this.textAnnotation.setFont$java_awt_Font(this.vueFont.getFont());
});

Clazz.newMeth(C$, 'update', function () {
p$.applyFont.apply(this, []);
if (this.textAnnotation.getType() === (I$[2]||$incl$(2)).POSITION ) this.textAnnotation.setAncrage$D$D(this.xSlider.getValue() + this._vp.getExtendedRNABBox().x, this.ySlider.getValue() + this._vp.getExtendedRNABBox().y);
this.textAnnotation.setText$S(this.textArea.getText());
this.textAnnotation.setAngleInDegres$D(this.rotationSlider.getValue());
this._vp.clearSelection();
this._vp.repaint();
});

Clazz.newMeth(C$, 'getPanel', function () {
return this.panel;
});

Clazz.newMeth(C$, 'getTextAnnotation', function () {
return this.textAnnotation;
});

Clazz.newMeth(C$, 'get_vp', function () {
return this._vp;
});

Clazz.newMeth(C$, 'show', function () {
this._vp.set_selectedAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(this.textAnnotation);
this._vp.highlightSelectedAnnotation();
if ((I$[17]||$incl$(17)).showConfirmDialog$java_awt_Component$O$S$I$I(this._vp, this.getPanel(), "Add/edit annotation", 2, -1) == 0) {
this.update();
} else {
if (this.newAnnotation) {
this._vp.set_selectedAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(null);
if (!this._vp.removeAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(this.textAnnotation)) this._vp.errorDialog$Exception(Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Impossible de supprimer"]));
} else {
this.textAnnotation.copy$fr_orsay_lri_varna_models_annotations_TextAnnotation(this.textAnnotationSave);
}}this._vp.resetAnnotationHighlight();
this._vp.set_selectedAnnotation$fr_orsay_lri_varna_models_annotations_TextAnnotation(null);
this._vp.repaint();
});

Clazz.newMeth(C$, 'isLimited', function () {
return this.limited;
});

Clazz.newMeth(C$, 'setLimited$Z', function (limited) {
this.limited = limited;
});

Clazz.newMeth(C$, 'isNewAnnotation', function () {
return this.newAnnotation;
});

Clazz.newMeth(C$, 'updateColor$java_awt_Color', function (c) {
this.colorButton.setForeground$java_awt_Color(c);
this.textAnnotation.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:38:29
