(function(){var P$=Clazz.newPackage("fr.orsay.lri.varna.applications"),I$=[['java.util.Hashtable']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FileNameExtensionFilter", null, 'javax.swing.filechooser.FileFilter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this._exts = null;
this._desc = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this._exts = Clazz.new_((I$[1]||$incl$(1)));
this._desc = "";
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (desc, ext1) {
Clazz.super_(C$, this,1);
this._desc = desc;
this._exts.put$TK$TV(ext1, new Integer(0));
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S', function (desc, ext1, ext2) {
C$.c$$S$S.apply(this, [desc, ext1]);
this._exts.put$TK$TV(ext2, new Integer(1));
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S$S', function (desc, ext1, ext2, ext3) {
C$.c$$S$S$S.apply(this, [desc, ext1, ext2]);
this._exts.put$TK$TV(ext3, new Integer(2));
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S$S$S', function (desc, ext1, ext2, ext3, ext4) {
C$.c$$S$S$S$S.apply(this, [desc, ext1, ext2, ext3]);
this._exts.put$TK$TV(ext4, new Integer(3));
}, 1);

Clazz.newMeth(C$, 'accept$java_io_File', function (path) {
var name = path.getName();
if (path.isDirectory()) return true;
var index = name.lastIndexOf(".");
if (index != -1) {
var suffix = name.substring(index + 1);
if (this._exts.containsKey$O(suffix)) {
return true;
}}return false;
});

Clazz.newMeth(C$, 'getDescription', function () {
return this._desc;
});

Clazz.newMeth(C$, 'getExtensions', function () {
var exts = Clazz.array(java.lang.String, [this._exts.size()]);
var k = this._exts.keys();
var n = 0;
while (k.hasMoreElements()){
exts[n] = k.nextElement();
n++;
}
return exts;
});

Clazz.newMeth(C$);
})();
//Created 2017-12-22 22:36:33
