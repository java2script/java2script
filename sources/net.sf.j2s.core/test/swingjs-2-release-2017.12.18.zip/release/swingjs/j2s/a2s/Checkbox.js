(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Checkbox", null, 'javax.swing.JCheckBox');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'newRadioButton$S$javax_swing_ButtonGroup$Z', function (string, bg, b) {
var rb = Clazz.new_((I$[0]||(I$[0]=Clazz.load('javax.swing.JRadioButton'))).c$$S$Z,[string, b]);
bg.add$javax_swing_AbstractButton(rb);
return rb;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (string) {
C$.superclazz.c$$S$Z.apply(this, [string, false]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (string, b) {
C$.superclazz.c$$S$Z.apply(this, [string, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getState', function () {
return this.isSelected();
});

Clazz.newMeth(C$, 'setState$Z', function (b) {
this.setSelected$Z(b);
});
})();
//Created 2017-12-17 19:28:41
