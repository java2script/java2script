(function(){var P$=Clazz.newPackage("com.falstad.circuit");
var C$=Clazz.newInterface(P$, "Editable");
})();
//Created 2017-12-17 19:28:19
