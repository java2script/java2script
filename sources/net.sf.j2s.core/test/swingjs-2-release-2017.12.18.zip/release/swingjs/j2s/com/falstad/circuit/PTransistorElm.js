(function(){var P$=Clazz.newPackage("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass(P$, "PTransistorElm", null, 'com.falstad.circuit.TransistorElm');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (xx, yy) {
C$.superclazz.c$$I$I$Z.apply(this, [xx, yy, true]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getDumpClass', function () {
return Clazz.getClass((I$[0]||(I$[0]=Clazz.load('com.falstad.circuit.TransistorElm'))));
});

Clazz.newMeth(C$);
})();
//Created 2017-12-17 19:28:21
