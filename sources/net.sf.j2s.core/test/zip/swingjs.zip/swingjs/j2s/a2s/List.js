Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JList"], "a2s.List", null, function () {
c$ = Clazz.declareType (a2s, "List", javax.swing.JList);
});
