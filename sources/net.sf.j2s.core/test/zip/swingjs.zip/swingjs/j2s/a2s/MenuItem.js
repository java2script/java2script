Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JMenuItem"], "a2s.MenuItem", null, function () {
c$ = Clazz.declareType (a2s, "MenuItem", javax.swing.JMenuItem);
});
