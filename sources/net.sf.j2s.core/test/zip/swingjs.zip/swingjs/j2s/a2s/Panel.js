Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JPanel"], "a2s.Panel", ["a2s.A2SEvent"], function () {
c$ = Clazz.declareType (a2s, "Panel", javax.swing.JPanel);
Clazz.defineMethod (c$, "add", 
function (comp) {
Clazz.superCall (this, a2s.Panel, "add", [comp]);
return a2s.A2SEvent.addComponent (this.getTopLevelAncestor (), comp);
}, "java.awt.Component");
});
