Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JScrollBar"], "a2s.Scrollbar", null, function () {
c$ = Clazz.declareType (a2s, "Scrollbar", javax.swing.JScrollBar);
});
