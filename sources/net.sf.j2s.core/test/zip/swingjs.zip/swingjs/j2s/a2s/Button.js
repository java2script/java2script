Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JButton", "java.awt.Insets"], "a2s.Button", null, function () {
c$ = Clazz.declareType (a2s, "Button", javax.swing.JButton);
Clazz.overrideMethod (c$, "getMargin", 
function () {
return a2s.Button.awtInsets;
});
c$.awtInsets = c$.prototype.awtInsets =  new java.awt.Insets (0, 6, 0, 6);
});
