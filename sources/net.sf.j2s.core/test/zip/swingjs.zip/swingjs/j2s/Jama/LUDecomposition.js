Clazz.declarePackage ("Jama");
Clazz.load (null, "Jama.LUDecomposition", ["Jama.Matrix", "java.lang.IllegalArgumentException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.LU = null;
this.m = 0;
this.n = 0;
this.pivsign = 0;
this.piv = null;
Clazz.instantialize (this, arguments);
}, Jama, "LUDecomposition", null, java.io.Serializable);
Clazz.makeConstructor (c$, 
function (A) {
this.LU = A.getArrayCopy ();
this.m = A.getRowDimension ();
this.n = A.getColumnDimension ();
this.piv =  Clazz.newIntArray (this.m, 0);
for (var i = 0; i < this.m; i++) {
this.piv[i] = i;
}
this.pivsign = 1;
var LUrowi;
var LUcolj =  Clazz.newDoubleArray (this.m, 0);
for (var j = 0; j < this.n; j++) {
for (var i = 0; i < this.m; i++) {
LUcolj[i] = this.LU[i][j];
}
for (var i = 0; i < this.m; i++) {
LUrowi = this.LU[i];
var kmax = Math.min (i, j);
var s = 0.0;
for (var k = 0; k < kmax; k++) {
s += LUrowi[k] * LUcolj[k];
}
LUrowi[j] = LUcolj[i] -= s;
}
var p = j;
for (var i = j + 1; i < this.m; i++) {
if (Math.abs (LUcolj[i]) > Math.abs (LUcolj[p])) {
p = i;
}}
if (p != j) {
for (var k = 0; k < this.n; k++) {
var t = this.LU[p][k];
this.LU[p][k] = this.LU[j][k];
this.LU[j][k] = t;
}
var k = this.piv[p];
this.piv[p] = this.piv[j];
this.piv[j] = k;
this.pivsign = -this.pivsign;
}if ( new Boolean (j < this.m & this.LU[j][j] != 0.0).valueOf ()) {
for (var i = j + 1; i < this.m; i++) {
this.LU[i][j] /= this.LU[j][j];
}
}}
}, "Jama.Matrix");
Clazz.defineMethod (c$, "isNonsingular", 
function () {
for (var j = 0; j < this.n; j++) {
if (this.LU[j][j] == 0) return false;
}
return true;
});
Clazz.defineMethod (c$, "getL", 
function () {
var X =  new Jama.Matrix (this.m, this.n);
var L = X.getArray ();
for (var i = 0; i < this.m; i++) {
for (var j = 0; j < this.n; j++) {
if (i > j) {
L[i][j] = this.LU[i][j];
} else if (i == j) {
L[i][j] = 1.0;
} else {
L[i][j] = 0.0;
}}
}
return X;
});
Clazz.defineMethod (c$, "getU", 
function () {
var X =  new Jama.Matrix (this.n, this.n);
var U = X.getArray ();
for (var i = 0; i < this.n; i++) {
for (var j = 0; j < this.n; j++) {
if (i <= j) {
U[i][j] = this.LU[i][j];
} else {
U[i][j] = 0.0;
}}
}
return X;
});
Clazz.defineMethod (c$, "getPivot", 
function () {
var p =  Clazz.newIntArray (this.m, 0);
for (var i = 0; i < this.m; i++) {
p[i] = this.piv[i];
}
return p;
});
Clazz.defineMethod (c$, "getDoublePivot", 
function () {
var vals =  Clazz.newDoubleArray (this.m, 0);
for (var i = 0; i < this.m; i++) {
vals[i] = this.piv[i];
}
return vals;
});
Clazz.defineMethod (c$, "det", 
function () {
if (this.m != this.n) {
throw  new IllegalArgumentException ("Matrix must be square.");
}var d = this.pivsign;
for (var j = 0; j < this.n; j++) {
d *= this.LU[j][j];
}
return d;
});
Clazz.defineMethod (c$, "solve", 
function (B) {
if (B.getRowDimension () != this.m) {
throw  new IllegalArgumentException ("Matrix row dimensions must agree.");
}if (!this.isNonsingular ()) {
throw  new RuntimeException ("Matrix is singular.");
}var nx = B.getColumnDimension ();
var Xmat = B.getMatrix (this.piv, 0, nx - 1);
var X = Xmat.getArray ();
for (var k = 0; k < this.n; k++) {
for (var i = k + 1; i < this.n; i++) {
for (var j = 0; j < nx; j++) {
X[i][j] -= X[k][j] * this.LU[i][k];
}
}
}
for (var k = this.n - 1; k >= 0; k--) {
for (var j = 0; j < nx; j++) {
X[k][j] /= this.LU[k][k];
}
for (var i = 0; i < k; i++) {
for (var j = 0; j < nx; j++) {
X[i][j] -= X[k][j] * this.LU[i][k];
}
}
}
return Xmat;
}, "Jama.Matrix");
});
