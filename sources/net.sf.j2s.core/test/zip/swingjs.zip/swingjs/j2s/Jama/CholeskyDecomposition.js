Clazz.declarePackage ("Jama");
Clazz.load (null, "Jama.CholeskyDecomposition", ["Jama.Matrix", "java.lang.IllegalArgumentException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.L = null;
this.n = 0;
this.isspd = false;
Clazz.instantialize (this, arguments);
}, Jama, "CholeskyDecomposition", null, java.io.Serializable);
Clazz.makeConstructor (c$, 
function (Arg) {
var A = Arg.getArray ();
this.n = Arg.getRowDimension ();
this.L =  Clazz.newDoubleArray (this.n, this.n, 0);
this.isspd = (Arg.getColumnDimension () == this.n);
for (var j = 0; j < this.n; j++) {
var Lrowj = this.L[j];
var d = 0.0;
for (var k = 0; k < j; k++) {
var Lrowk = this.L[k];
var s = 0.0;
for (var i = 0; i < k; i++) {
s += Lrowk[i] * Lrowj[i];
}
Lrowj[k] = s = (A[j][k] - s) / this.L[k][k];
d = d + s * s;
this.isspd =  new Boolean (this.isspd & (A[k][j] == A[j][k])).valueOf ();
}
d = A[j][j] - d;
this.isspd =  new Boolean (this.isspd & (d > 0.0)).valueOf ();
this.L[j][j] = Math.sqrt (Math.max (d, 0.0));
for (var k = j + 1; k < this.n; k++) {
this.L[j][k] = 0.0;
}
}
}, "Jama.Matrix");
Clazz.defineMethod (c$, "isSPD", 
function () {
return this.isspd;
});
Clazz.defineMethod (c$, "getL", 
function () {
return  new Jama.Matrix (this.L, this.n, this.n);
});
Clazz.defineMethod (c$, "solve", 
function (B) {
if (B.getRowDimension () != this.n) {
throw  new IllegalArgumentException ("Matrix row dimensions must agree.");
}if (!this.isspd) {
throw  new RuntimeException ("Matrix is not symmetric positive definite.");
}var X = B.getArrayCopy ();
var nx = B.getColumnDimension ();
for (var k = 0; k < this.n; k++) {
for (var j = 0; j < nx; j++) {
for (var i = 0; i < k; i++) {
X[k][j] -= X[i][j] * this.L[k][i];
}
X[k][j] /= this.L[k][k];
}
}
for (var k = this.n - 1; k >= 0; k--) {
for (var j = 0; j < nx; j++) {
for (var i = k + 1; i < this.n; i++) {
X[k][j] -= X[i][j] * this.L[i][k];
}
X[k][j] /= this.L[k][k];
}
}
return  new Jama.Matrix (X, this.n, nx);
}, "Jama.Matrix");
});
