Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.TransistorElm"], "com.falstad.Circuit.PTransistorElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "PTransistorElm", com.falstad.Circuit.TransistorElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.PTransistorElm, [xx, yy, true]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.TransistorElm;
});
});
