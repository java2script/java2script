Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["java.lang.Enum"], "com.falstad.Circuit.ImportExportDialog", null, function () {
Clazz.declareInterface (com.falstad.Circuit, "ImportExportDialog");
Clazz.pu$h(c$);
c$ = Clazz.declareType (com.falstad.Circuit.ImportExportDialog, "Action", Enum);
Clazz.defineEnumConstant (c$, "IMPORT", 0, []);
Clazz.defineEnumConstant (c$, "EXPORT", 1, []);
c$ = Clazz.p0p ();
});
