Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.ImportExportDialog"], "com.falstad.Circuit.ImportExportFileDialog", ["java.awt.FileDialog", "$.Frame", "java.io.File", "$.FileInputStream", "$.FileOutputStream", "java.nio.channels.FileChannel", "java.nio.charset.Charset"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cframe = null;
this.type = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "ImportExportFileDialog", null, com.falstad.Circuit.ImportExportDialog);
Clazz.makeConstructor (c$, 
function (f, type) {
this.type = type;
this.cframe = f;
}, "com.falstad.Circuit.CirSim,com.falstad.Circuit.ImportExportDialog.Action");
Clazz.overrideMethod (c$, "setDump", 
function (dump) {
com.falstad.Circuit.ImportExportFileDialog.circuitDump = dump;
}, "~S");
Clazz.defineMethod (c$, "getDump", 
function () {
return com.falstad.Circuit.ImportExportFileDialog.circuitDump;
});
Clazz.overrideMethod (c$, "execute", 
function () {
var fd =  new java.awt.FileDialog ( new java.awt.Frame (), (this.type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) ? "Save File" : "Open File", (this.type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) ? 1 : 0);
fd.setDirectory (com.falstad.Circuit.ImportExportFileDialog.directory);
fd.setVisible (true);
var file = fd.getFile ();
var dir = fd.getDirectory ();
if (dir != null) com.falstad.Circuit.ImportExportFileDialog.directory = dir;
if (file == null) return;
System.err.println (dir + java.io.File.separator + file);
if (this.type === com.falstad.Circuit.ImportExportDialog.Action.EXPORT) {
try {
com.falstad.Circuit.ImportExportFileDialog.writeFile (dir + file);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
e.printStackTrace ();
} else {
throw e;
}
}
} else {
try {
var dump = com.falstad.Circuit.ImportExportFileDialog.readFile (dir + file);
com.falstad.Circuit.ImportExportFileDialog.circuitDump = dump;
this.cframe.readSetup (com.falstad.Circuit.ImportExportFileDialog.circuitDump);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
e.printStackTrace ();
} else {
throw e;
}
}
}});
c$.readFile = Clazz.defineMethod (c$, "readFile", 
 function (path) {
var stream = null;
try {
stream =  new java.io.FileInputStream ( new java.io.File (path));
var fc = stream.getChannel ();
var bb = fc.map (java.nio.channels.FileChannel.MapMode.READ_ONLY, 0, fc.size ());
return java.nio.charset.Charset.forName ("UTF-8").decode (bb).toString ();
} finally {
stream.close ();
}
}, "~S");
c$.writeFile = Clazz.defineMethod (c$, "writeFile", 
 function (path) {
var stream = null;
try {
stream =  new java.io.FileOutputStream ( new java.io.File (path));
var fc = stream.getChannel ();
var bb = java.nio.charset.Charset.forName ("UTF-8").encode (com.falstad.Circuit.ImportExportFileDialog.circuitDump);
fc.write (bb);
} finally {
stream.close ();
}
}, "~S");
Clazz.defineStatics (c$,
"circuitDump", null,
"directory", ".");
});
