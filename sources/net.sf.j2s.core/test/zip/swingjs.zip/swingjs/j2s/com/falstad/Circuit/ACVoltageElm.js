Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.VoltageElm"], "com.falstad.Circuit.ACVoltageElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "ACVoltageElm", com.falstad.Circuit.VoltageElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.ACVoltageElm, [xx, yy, 1]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.VoltageElm;
});
});
