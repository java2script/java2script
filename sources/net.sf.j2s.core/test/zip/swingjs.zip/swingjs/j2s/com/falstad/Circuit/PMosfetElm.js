Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.MosfetElm"], "com.falstad.Circuit.PMosfetElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "PMosfetElm", com.falstad.Circuit.MosfetElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.PMosfetElm, [xx, yy, true]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.MosfetElm;
});
});
