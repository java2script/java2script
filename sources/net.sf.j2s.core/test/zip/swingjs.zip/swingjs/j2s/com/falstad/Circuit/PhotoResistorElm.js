Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.CircuitElm"], "com.falstad.Circuit.PhotoResistorElm", ["a2s.Label", "$.Scrollbar", "com.falstad.Circuit.CirSim", "$.EditInfo", "java.awt.Point", "java.lang.Double"], function () {
c$ = Clazz.decorateAsClass (function () {
this.minresistance = 0;
this.maxresistance = 0;
this.resistance = 0;
this.slider = null;
this.label = null;
this.ps3 = null;
this.ps4 = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "PhotoResistorElm", com.falstad.Circuit.CircuitElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.PhotoResistorElm, [xx, yy]);
this.maxresistance = 1e9;
this.minresistance = 1e3;
this.createSlider ();
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (xa, ya, xb, yb, f, st) {
Clazz.superConstructor (this, com.falstad.Circuit.PhotoResistorElm, [xa, ya, xb, yb, f]);
this.minresistance =  new Double (st.nextToken ()).doubleValue ();
this.maxresistance =  new Double (st.nextToken ()).doubleValue ();
this.createSlider ();
}, "~N,~N,~N,~N,~N,java.util.StringTokenizer");
Clazz.overrideMethod (c$, "nonLinear", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 190;
});
Clazz.defineMethod (c$, "dump", 
function () {
return Clazz.superCall (this, com.falstad.Circuit.PhotoResistorElm, "dump", []) + " " + this.minresistance + " " + this.maxresistance;
});
Clazz.defineMethod (c$, "createSlider", 
function () {
com.falstad.Circuit.CircuitElm.sim.main.add (this.label =  new a2s.Label ("Light Level", 0));
var value = 50;
com.falstad.Circuit.CircuitElm.sim.main.add (this.slider =  new a2s.Scrollbar (0, value, 1, 0, 101));
com.falstad.Circuit.CircuitElm.sim.main.validate ();
});
Clazz.defineMethod (c$, "setPoints", 
function () {
Clazz.superCall (this, com.falstad.Circuit.PhotoResistorElm, "setPoints", []);
this.calcLeads (32);
this.ps3 =  new java.awt.Point ();
this.ps4 =  new java.awt.Point ();
});
Clazz.overrideMethod (c$, "$delete", 
function () {
com.falstad.Circuit.CircuitElm.sim.main.remove (this.label);
com.falstad.Circuit.CircuitElm.sim.main.remove (this.slider);
});
Clazz.overrideMethod (c$, "draw", 
function (g) {
var i;
var v1 = this.volts[0];
var v2 = this.volts[1];
this.setBbox (this.point1, this.point2, 6);
this.draw2Leads (g);
this.setPowerColor (g, true);
this.doDots (g);
this.drawPosts (g);
}, "java.awt.Graphics");
Clazz.overrideMethod (c$, "calculateCurrent", 
function () {
var vd = this.volts[0] - this.volts[1];
this.current = vd / this.resistance;
});
Clazz.overrideMethod (c$, "startIteration", 
function () {
var vd = this.volts[0] - this.volts[1];
this.resistance = this.minresistance;
});
Clazz.overrideMethod (c$, "doStep", 
function () {
com.falstad.Circuit.CircuitElm.sim.stampResistor (this.nodes[0], this.nodes[1], this.resistance);
});
Clazz.overrideMethod (c$, "stamp", 
function () {
com.falstad.Circuit.CircuitElm.sim.stampNonLinear (this.nodes[0]);
com.falstad.Circuit.CircuitElm.sim.stampNonLinear (this.nodes[1]);
});
Clazz.overrideMethod (c$, "getInfo", 
function (arr) {
arr[0] = "spark gap";
this.getBasicInfo (arr);
arr[3] = "R = " + com.falstad.Circuit.CircuitElm.getUnitText (this.resistance, com.falstad.Circuit.CirSim.ohmString);
arr[4] = "Ron = " + com.falstad.Circuit.CircuitElm.getUnitText (this.minresistance, com.falstad.Circuit.CirSim.ohmString);
arr[5] = "Roff = " + com.falstad.Circuit.CircuitElm.getUnitText (this.maxresistance, com.falstad.Circuit.CirSim.ohmString);
}, "~A");
Clazz.overrideMethod (c$, "getEditInfo", 
function (n) {
if (n == 0) return  new com.falstad.Circuit.EditInfo ("Min resistance (ohms)", this.minresistance, 0, 0);
if (n == 1) return  new com.falstad.Circuit.EditInfo ("Max resistance (ohms)", this.maxresistance, 0, 0);
return null;
}, "~N");
Clazz.overrideMethod (c$, "setEditValue", 
function (n, ei) {
if (ei.value > 0 && n == 0) this.minresistance = ei.value;
if (ei.value > 0 && n == 1) this.maxresistance = ei.value;
}, "~N,com.falstad.Circuit.EditInfo");
});
