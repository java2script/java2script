Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.MosfetElm"], "com.falstad.Circuit.NMosfetElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "NMosfetElm", com.falstad.Circuit.MosfetElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.NMosfetElm, [xx, yy, false]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.MosfetElm;
});
});
