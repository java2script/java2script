Clazz.declarePackage ("JU");
Clazz.load (["java.net.URLConnection"], "JU.AjaxURLConnection", ["JU.AU", "$.Rdr", "$.SB"], function () {
c$ = Clazz.decorateAsClass (function () {
this.bytesOut = null;
this.postOut = "";
Clazz.instantialize (this, arguments);
}, JU, "AjaxURLConnection", java.net.URLConnection);
Clazz.defineMethod (c$, "doAjax", 
 function (isBinary) {
var jmol = null;
{
jmol = J2S || Jmol;
}return jmol._doAjax (this.url, this.postOut, this.bytesOut, isBinary);
}, "~B");
Clazz.overrideMethod (c$, "connect", 
function () {
});
Clazz.defineMethod (c$, "outputBytes", 
function (bytes) {
this.bytesOut = bytes;
}, "~A");
Clazz.defineMethod (c$, "outputString", 
function (post) {
this.postOut = post;
}, "~S");
Clazz.overrideMethod (c$, "getInputStream", 
function () {
var bis = JU.AjaxURLConnection.getAttachedStreamData (this.url);
if (bis != null) return bis;
var o = this.doAjax (true);
return (JU.AU.isAB (o) ? JU.Rdr.getBIS (o) : Clazz.instanceOf (o, JU.SB) ? JU.Rdr.getBIS (JU.Rdr.getBytesFromSB (o)) : Clazz.instanceOf (o, String) ? JU.Rdr.getBIS ((o).getBytes ()) : bis);
});
c$.getAttachedStreamData = Clazz.defineMethod (c$, "getAttachedStreamData", 
function (url) {
var bis = null;
var bytes = null;
{
bis = url._streamData;
bytes = url.__bytes;
}if (bis != null) (bis).resetStream ();
 else if (bytes != null) bis = JU.Rdr.getBIS (bytes);
return bis;
}, "java.net.URL");
Clazz.defineMethod (c$, "getContents", 
function () {
return this.doAjax (false);
});
});
