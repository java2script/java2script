Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (null, "com.falstad.Circuit.ImportExportDialogFactory", ["com.falstad.Circuit.ImportExportDialogSwingJS"], function () {
c$ = Clazz.declareType (com.falstad.Circuit, "ImportExportDialogFactory");
c$.Create = Clazz.defineMethod (c$, "Create", 
function (f, type) {
var isJS = false;
{
isJS = true;
}if (isJS) {
return  new com.falstad.Circuit.ImportExportDialogSwingJS (f, type);
} else if (f.applet != null) {
return  new com.falstad.Circuit.ImportExportClipboardDialog (f, type);
} else {
return  new com.falstad.Circuit.ImportExportFileDialog (f, type);
}}, "com.falstad.Circuit.CirSim,com.falstad.Circuit.ImportExportDialog.Action");
});
