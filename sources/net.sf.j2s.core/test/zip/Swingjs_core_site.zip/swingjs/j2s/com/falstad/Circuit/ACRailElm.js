Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.RailElm"], "com.falstad.Circuit.ACRailElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "ACRailElm", com.falstad.Circuit.RailElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.ACRailElm, [xx, yy, 1]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.RailElm;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return 0;
});
});
