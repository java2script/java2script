Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.RailElm"], "com.falstad.Circuit.VarRailElm", ["a2s.Label", "$.Scrollbar", "com.falstad.Circuit.CircuitElm", "$.EditInfo"], function () {
c$ = Clazz.decorateAsClass (function () {
this.slider = null;
this.label = null;
this.sliderText = null;
Clazz.instantialize (this, arguments);
}, com.falstad.Circuit, "VarRailElm", com.falstad.Circuit.RailElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.VarRailElm, [xx, yy, 6]);
this.sliderText = "Voltage";
this.frequency = this.maxVoltage;
this.createSlider ();
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (xa, ya, xb, yb, f, st) {
Clazz.superConstructor (this, com.falstad.Circuit.VarRailElm, [xa, ya, xb, yb, f, st]);
this.sliderText = st.nextToken ();
while (st.hasMoreTokens ()) this.sliderText += ' ' + st.nextToken ();

this.createSlider ();
}, "~N,~N,~N,~N,~N,java.util.StringTokenizer");
Clazz.defineMethod (c$, "dump", 
function () {
return Clazz.superCall (this, com.falstad.Circuit.VarRailElm, "dump", []) + " " + this.sliderText;
});
Clazz.overrideMethod (c$, "getDumpType", 
function () {
return 172;
});
Clazz.defineMethod (c$, "createSlider", 
function () {
this.waveform = 6;
com.falstad.Circuit.CircuitElm.sim.main.add (this.label =  new a2s.Label (this.sliderText, 0));
var value = Clazz.doubleToInt ((this.frequency - this.bias) * 100 / (this.maxVoltage - this.bias));
com.falstad.Circuit.CircuitElm.sim.main.add (this.slider =  new a2s.Scrollbar (0, value, 1, 0, 101));
com.falstad.Circuit.CircuitElm.sim.main.validate ();
});
Clazz.overrideMethod (c$, "getVoltage", 
function () {
this.frequency = this.slider.getValue () * (this.maxVoltage - this.bias) / 100. + this.bias;
return this.frequency;
});
Clazz.overrideMethod (c$, "$delete", 
function () {
com.falstad.Circuit.CircuitElm.sim.main.remove (this.label);
com.falstad.Circuit.CircuitElm.sim.main.remove (this.slider);
});
Clazz.overrideMethod (c$, "getEditInfo", 
function (n) {
if (n == 0) return  new com.falstad.Circuit.EditInfo ("Min Voltage", this.bias, -20, 20);
if (n == 1) return  new com.falstad.Circuit.EditInfo ("Max Voltage", this.maxVoltage, -20, 20);
if (n == 2) {
var ei =  new com.falstad.Circuit.EditInfo ("Slider Text", 0, -1, -1);
ei.text = this.sliderText;
return ei;
}return null;
}, "~N");
Clazz.overrideMethod (c$, "setEditValue", 
function (n, ei) {
if (n == 0) this.bias = ei.value;
if (n == 1) this.maxVoltage = ei.value;
if (n == 2) {
this.sliderText = ei.textf.getText ();
this.label.setText (this.sliderText);
}}, "~N,com.falstad.Circuit.EditInfo");
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return 0;
});
});
