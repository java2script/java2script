Clazz.declarePackage ("com.falstad.Circuit");
Clazz.load (["com.falstad.Circuit.RailElm"], "com.falstad.Circuit.SquareRailElm", null, function () {
c$ = Clazz.declareType (com.falstad.Circuit, "SquareRailElm", com.falstad.Circuit.RailElm);
Clazz.makeConstructor (c$, 
function (xx, yy) {
Clazz.superConstructor (this, com.falstad.Circuit.SquareRailElm, [xx, yy, 2]);
}, "~N,~N");
Clazz.overrideMethod (c$, "getDumpClass", 
function () {
return com.falstad.Circuit.RailElm;
});
Clazz.overrideMethod (c$, "getShortcut", 
function () {
return 0;
});
});
