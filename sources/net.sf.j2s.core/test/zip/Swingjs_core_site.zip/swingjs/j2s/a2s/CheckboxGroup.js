Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.ButtonGroup"], "a2s.CheckboxGroup", null, function () {
c$ = Clazz.declareType (a2s, "CheckboxGroup", javax.swing.ButtonGroup);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, a2s.CheckboxGroup, []);
});
Clazz.defineMethod (c$, "getSelectedCheckbox", 
function () {
for (var e = this.getElements (); e.hasMoreElements (); ) {
var ab = e.nextElement ();
if (ab.isSelected ()) return ab;
}
return null;
});
});
