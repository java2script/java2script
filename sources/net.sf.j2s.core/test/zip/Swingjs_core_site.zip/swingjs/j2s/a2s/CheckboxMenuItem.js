Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JCheckBoxMenuItem"], "a2s.CheckboxMenuItem", null, function () {
c$ = Clazz.declareType (a2s, "CheckboxMenuItem", javax.swing.JCheckBoxMenuItem);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, a2s.CheckboxMenuItem, []);
});
Clazz.overrideMethod (c$, "getState", 
function () {
return this.isSelected ();
});
Clazz.overrideMethod (c$, "setState", 
function (tf) {
this.setSelected (tf);
}, "~B");
});
