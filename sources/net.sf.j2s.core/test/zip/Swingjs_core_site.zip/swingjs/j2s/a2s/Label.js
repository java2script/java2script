Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JLabel"], "a2s.Label", null, function () {
c$ = Clazz.declareType (a2s, "Label", javax.swing.JLabel);
Clazz.defineMethod (c$, "setAlignment", 
function (alignment) {
this.setAlignmentX (alignment);
}, "~N");
});
