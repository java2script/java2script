Clazz.declarePackage ("a2s");
Clazz.load (["javax.swing.JMenuBar"], "a2s.MenuBar", null, function () {
c$ = Clazz.declareType (a2s, "MenuBar", javax.swing.JMenuBar);
});
