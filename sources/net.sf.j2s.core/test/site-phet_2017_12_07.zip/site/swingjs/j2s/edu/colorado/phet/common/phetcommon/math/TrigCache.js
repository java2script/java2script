(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math");
var C$=Clazz.newClass$(P$, "TrigCache");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this._sineValues = null;
this._cosineValues = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (cacheSize) {
C$.$init$.apply(this);
p$.initCache$I.apply(this, [cacheSize]);
}, 1);

Clazz.newMethod$(C$, 'initCache$I', function (cacheSize) {
var deltaRadians = (6.283185307179586 / cacheSize);
this._sineValues =  Clazz.newArray$(Double.TYPE, [cacheSize]);
this._cosineValues =  Clazz.newArray$(Double.TYPE, [cacheSize]);
for (var i = 0; i < cacheSize; i++) {
this._sineValues[i] = Math.sin(i * deltaRadians);
this._cosineValues[i] = Math.cos(i * deltaRadians);
}
});

Clazz.newMethod$(C$, 'sin$D', function (radians) {
var deltaRadians = (6.283185307179586 / this._sineValues.length);
var adjustedRadians = Math.abs(radians) % 6.283185307179586;
var index = (Math.round(adjustedRadians / deltaRadians)|0);
if (index > this._sineValues.length - 1) {
index = 0;
}var value = this._sineValues[index];
if (radians < 0 ) {
value = -value;
}return value;
});

Clazz.newMethod$(C$, 'cos$D', function (radians) {
var deltaRadians = (6.283185307179586 / this._cosineValues.length);
var adjustedRadians = Math.abs(radians) % 6.283185307179586;
var index = (Math.round(adjustedRadians / deltaRadians)|0);
if (index > this._sineValues.length - 1) {
index = 0;
}var value = this._cosineValues[index];
return value;
});

Clazz.newMethod$(C$, 'main', function (args) {
var cacheSize = 1000;
var minRadians = -12.566370614359172;
var maxRadians = 12.566370614359172;
var deltaRadians = 0.06283185307179587;
var acceptableError = 1.0E-8;
System.out.println$S("trig cache size is 1000");
System.out.println$S("test range is -12.566370614359172 to 12.566370614359172 radians, in 0.06283185307179587 radian intervals");
System.out.println$S("acceptable error is 1.0E-8 radians");
System.out.println$S("unacceptable errors will be printed to System.out");
System.out.println$S("begin test...");
var trigCache = Clazz.new(C$.c$$I,[1000]);
for (var radians = -12.566370614359172; radians <= 12.566370614359172 ; radians += 0.06283185307179587) {
var sinApproximate = trigCache.sin$D(radians);
var sinActual = Math.sin(radians);
var sinError = Math.abs(sinApproximate - sinActual);
if (sinError > 1.0E-8 ) {
System.out.println$S("ERROR: radians=" + new Double(radians).toString() + " sinApproximate=" + new Double(sinApproximate).toString() + " sinActual=" + new Double(sinActual).toString() + " error=" + new Double(sinError).toString() );
}var cosApproximate = trigCache.cos$D(radians);
var cosActual = Math.cos(radians);
var cosError = Math.abs(cosApproximate - cosActual);
if (cosError > 1.0E-8 ) {
System.out.println$S("ERROR: radians=" + new Double(radians).toString() + " cosApproximate=" + new Double(cosApproximate).toString() + " cosActual=" + new Double(cosActual).toString() + " error=" + new Double(cosError).toString() );
}}
System.out.println$S("end test");
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
