(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "SphereF", function(){
Clazz.newInstance$(this, arguments,0,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.center = null;
this.radius = 0;
}, 1);

Clazz.newMethod$(C$, 'hashCode', function () {
return Float.floatToIntBits(this.radius) ^ this.center.hashCode();
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.SphereF"))) {
return false;
}var m = o;
return (m.radius == this.radius  && m.center.x == this.center.x   && m.center.y == this.center.y   && m.center.z == this.center.z  );
});

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$F', function (center, radius) {
C$.$init$.apply(this);
this.center = center;
this.radius = radius;
}, 1);

Clazz.newMethod$(C$, 'intersect$edu_colorado_phet_common_phetcommon_math_Ray3F$F', function (ray, epsilon) {
var raydir = ray.dir;
var pos = ray.pos;
var centerToRay = pos.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center);
var tmp = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(centerToRay);
var centerToRayDistSq = centerToRay.magnitudeSquared();
var det = 4 * tmp * tmp  - 4 * (centerToRayDistSq - this.radius * this.radius);
if (det < epsilon ) {
return null;
}var base = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center) - raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(pos);
var sqt = (Math.sqrt(det) / 2);
var ta = base - sqt;
var tb = base + sqt;
if (tb < epsilon ) {
return null;
}var hitPositionB = ray.pointAtDistance$F(tb);
var normalB = hitPositionB.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
if (ta < epsilon ) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.SphereF').SphereIntersectionResult))).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[tb, hitPositionB, normalB.negated(), false]);
} else {
var hitPositionA = ray.pointAtDistance$F(ta);
var normalA = hitPositionA.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
return Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.SphereF').SphereIntersectionResult))).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[ta, hitPositionA, normalA, true]);
}});

Clazz.newMethod$(C$, 'intersections$edu_colorado_phet_common_phetcommon_math_Ray3F$F', function (ray, epsilon) {
var result = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
var raydir = ray.dir;
var pos = ray.pos;
var centerToRay = pos.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center);
var tmp = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(centerToRay);
var centerToRayDistSq = centerToRay.magnitudeSquared();
var det = 4 * tmp * tmp  - 4 * (centerToRayDistSq - this.radius * this.radius);
if (det < epsilon ) {
return result;
}var base = raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center) - raydir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(pos);
var sqt = (Math.sqrt(det) / 2);
var ta = base - sqt;
var tb = base + sqt;
if (tb < epsilon ) {
return result;
}var hitPositionB = ray.pointAtDistance$F(tb);
var normalB = hitPositionB.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
var hitPositionA = ray.pointAtDistance$F(ta);
var normalA = hitPositionA.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.center).normalized();
var resultB = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.SphereF').SphereIntersectionResult))).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[tb, hitPositionB, normalB.negated(), false]);
var resultA = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.SphereF').SphereIntersectionResult))).c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z,[ta, hitPositionA, normalA, true]);
if (ta < epsilon ) {
return (I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).asList$TTA([resultB, resultA]);
} else {
return (I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).asList$TTA([resultA, resultB]);
}});

Clazz.newMethod$(C$, 'getCenter', function () {
return this.center;
});

Clazz.newMethod$(C$, 'getRadius', function () {
return this.radius;
});
;
(function(){var C$=Clazz.newClass$(P$.SphereF, "SphereIntersectionResult", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.distance = 0;
this.hitPoint = null;
this.normal = null;
this.fromOutside = false;
}, 1);

Clazz.newMethod$(C$, 'c$$F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$Z', function (distance, hitPoint, normal, fromOutside) {
C$.$init$.apply(this);
this.distance = distance;
this.hitPoint = hitPoint;
this.normal = normal;
this.fromOutside = fromOutside;
}, 1);

Clazz.newMethod$(C$, 'getDistance', function () {
return this.distance;
});

Clazz.newMethod$(C$, 'getHitPoint', function () {
return this.hitPoint;
});

Clazz.newMethod$(C$, 'getNormal', function () {
return this.normal;
});

Clazz.newMethod$(C$, 'isFromOutside', function () {
return this.fromOutside;
});

Clazz.newMethod$(C$);
})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
