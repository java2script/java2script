(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newClass$(P$, "Notifier", null, null, 'edu.colorado.phet.common.phetcommon.model.event.INotifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.notifier = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.event.AbstractNotifier'))));
}, 1);

Clazz.newMethod$(C$, ['updateListeners$TT'], function (value) {
this.notifier.updateListeners$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1(((
(function(){var C$=Clazz.newClass$(P$, "Notifier$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, ['$apply$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1','$apply$TT'], function (listener) {
listener.$apply$TT(this.$finals.value);
});
})()
), Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.event.Notifier$1'))).$init$, [this, {value: value}])));
});

Clazz.newMethod$(C$, 'addListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.notifier.addListener$TT(listener);
});

Clazz.newMethod$(C$, 'addUpdateListener$edu_colorado_phet_common_phetcommon_model_event_UpdateListener$Z', function (listener, fireOnAdd) {
this.notifier.addListener$TT(listener);
if (fireOnAdd) {
listener.update();
}});

Clazz.newMethod$(C$, 'removeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.notifier.removeListener$TT(listener);
});

Clazz.newMethod$(C$, 'getListeners', function () {
return this.notifier.getListeners();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
