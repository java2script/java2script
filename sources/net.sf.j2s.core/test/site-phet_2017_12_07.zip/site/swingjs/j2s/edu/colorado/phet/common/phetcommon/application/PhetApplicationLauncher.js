(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "PhetApplicationLauncher", function(){
Clazz.newInstance$(this, arguments,0,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'launchSim$SA$S$Class', function (commandLineArgs, project, phetApplicationClass) {
this.launchSim$SA$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(commandLineArgs, project, Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher').ReflectionApplicationConstructor))).c$$Class,[phetApplicationClass]));
});

Clazz.newMethod$(C$, 'launchSim$SA$S$S$Class', function (commandLineArgs, project, flavor, phetApplicationClass) {
this.launchSim$SA$S$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(commandLineArgs, project, flavor, Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher').ReflectionApplicationConstructor))).c$$Class,[phetApplicationClass]));
});

Clazz.newMethod$(C$, 'launchSim$SA$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (commandLineArgs, project, applicationConstructor) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig'))).c$$SA$S,[commandLineArgs, project]), applicationConstructor);
});

Clazz.newMethod$(C$, 'launchSim$SA$S$S$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (commandLineArgs, project, flavor, applicationConstructor) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig'))).c$$SA$S$S,[commandLineArgs, project, flavor]), applicationConstructor);
});

Clazz.newMethod$(C$, 'launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$Class', function (config, phetApplicationClass) {
this.launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(config, Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher').ReflectionApplicationConstructor))).c$$Class,[phetApplicationClass]));
});

Clazz.newMethod$(C$, 'launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (config, applicationConstructor) {
(I$[2]||(I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "PhetApplicationLauncher$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.$finals.config.getLookAndFeel().initLookAndFeel();
{
}if (this.$finals.applicationConstructor != null ) {
var app = this.$finals.applicationConstructor.getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig(this.$finals.config);
app.startApplication();
} else {
Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["No applicationconstructor specified"]).printStackTrace();
}});
})()
), Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher$1'))).$init$, [this, {config: config, applicationConstructor: applicationConstructor}])));
});
;
(function(){var C$=Clazz.newClass$(P$.PhetApplicationLauncher, "ReflectionApplicationConstructor", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
}, null, 'edu.colorado.phet.common.phetcommon.application.ApplicationConstructor');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.phetApplicationClass = null;
}, 1);

Clazz.newMethod$(C$, 'c$$Class', function (phetApplicationClass) {
C$.$init$.apply(this);
this.phetApplicationClass = phetApplicationClass;
}, 1);

Clazz.newMethod$(C$, 'getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
try {
return this.phetApplicationClass.getConstructor$ClassA( Clazz.newArray$(java.lang.Class, -1, [config.getClass()])).newInstance$OA( Clazz.newArray$(java.lang.Object, -1, [config]));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
});

Clazz.newMethod$(C$);
})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
