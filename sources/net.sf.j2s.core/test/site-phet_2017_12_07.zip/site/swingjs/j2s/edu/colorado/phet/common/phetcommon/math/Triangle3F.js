(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "Triangle3F", function(){
Clazz.newInstance$(this, arguments,0,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.a = null;
this.b = null;
this.c = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (a, b, c) {
C$.$init$.apply(this);
this.a = a;
this.b = b;
this.c = c;
}, 1);

Clazz.newMethod$(C$, 'getPlane', function () {
return (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PlaneF'))).fromTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(this.a, this.b, this.c);
});

Clazz.newMethod$(C$, 'getNormal', function () {
return this.b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a).cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a)).normalized();
});

Clazz.newMethod$(C$, 'getArea', function () {
return Math.abs(((this.a.x - this.c.x) * (this.b.y - this.c.y) - (this.b.x - this.c.x) * (this.a.y - this.c.y)) / 2.0);
});

Clazz.newMethod$(C$, 'intersectWith$edu_colorado_phet_common_phetcommon_math_Ray3F', function (ray) {
var plane = this.getPlane();
if (plane == null ) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').None))));
}var planePoint = plane.intersectWithRay$edu_colorado_phet_common_phetcommon_math_Ray3F(ray);
var v0 = this.c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var v1 = this.b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var v2 = planePoint.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.a);
var dot00 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v0);
var dot01 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v1);
var dot02 = v0.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v2);
var dot11 = v1.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v1);
var dot12 = v1.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(v2);
var p = 1 / (dot00 * dot11 - dot01 * dot01);
var u = (dot11 * dot02 - dot01 * dot12) * p;
var v = (dot00 * dot12 - dot01 * dot02) * p;
var hit = (u >= 0 ) && (v >= 0 ) && (u + v <= 1 )  ;
if (hit) {
return Clazz.new((I$[2]||(I$[2]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').Some))).c$$TT,[Clazz.new((I$[3]||(I$[3]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.Triangle3F').TriangleIntersectionResult))).c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F,[planePoint, plane.normal.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(ray.dir) > 0  ? plane.normal.negated() : plane.normal])]);
} else {
return Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').None))));
}});
;
(function(){var C$=Clazz.newClass$(P$.Triangle3F, "TriangleIntersectionResult", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.point = null;
this.normal = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (point, normal) {
C$.$init$.apply(this);
this.point = point;
this.normal = normal;
}, 1);

Clazz.newMethod$(C$);
})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
