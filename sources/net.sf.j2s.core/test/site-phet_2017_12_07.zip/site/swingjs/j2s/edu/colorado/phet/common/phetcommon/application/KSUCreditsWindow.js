(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "KSUCreditsWindow", null, 'javax.swing.JWindow');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.TRANSLATED_BY = (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetCommonResources'))).getString$S("Common.About.CreditsDialog.TranslationCreditsTitle");
};

C$.TRANSLATED_BY = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame', function (parent) {
C$.superClazz.c$$java_awt_Frame.apply(this, [parent]);
C$.$init$.apply(this);
var label = Clazz.new((I$[1]||(I$[1]=Clazz.load('javax.swing.JLabel'))).c$$S,[C$.TRANSLATED_BY]);
label.setFont$java_awt_Font(Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.PhetFont'))).c$$I,[18]));
var logo = Clazz.new((I$[1]||(I$[1]=Clazz.load('javax.swing.JLabel'))).c$$javax_swing_Icon,[Clazz.new((I$[3]||(I$[3]=Clazz.load('javax.swing.ImageIcon'))).c$$java_awt_Image,[(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetCommonResources'))).getImage$S("logos/ECSME-KSU-logos.jpg")])]);
var panel = Clazz.new((I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.view.VerticalLayoutPanel'))));
var margin = 12;
panel.setBorder$javax_swing_border_Border(Clazz.new((I$[5]||(I$[5]=Clazz.load('javax.swing.border.CompoundBorder'))).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new((I$[6]||(I$[6]=Clazz.load('javax.swing.border.LineBorder'))).c$$java_awt_Color$I,[(I$[7]||(I$[7]=Clazz.load('java.awt.Color'))).BLACK, 1]), Clazz.new((I$[8]||(I$[8]=Clazz.load('javax.swing.border.EmptyBorder'))).c$$I$I$I$I,[margin, margin, margin, margin])]));
panel.add$java_awt_Component(label);
panel.add$java_awt_Component((I$[9]||(I$[9]=Clazz.load('javax.swing.Box'))).createVerticalStrut$I(5));
panel.add$java_awt_Component(logo);
this.setContentPane$java_awt_Container(panel);
this.pack();
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass$(P$, "KSUCreditsWindow$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
this.b$['edu.colorado.phet.common.phetcommon.application.KSUCreditsWindow'].dispose();
});
})()
), Clazz.new((I$[10]||(I$[10]=Clazz.load('java.awt.event.MouseAdapter'))), [this, null],P$.KSUCreditsWindow$1)));
}, 1);

Clazz.newMethod$(C$, 'show$java_awt_Frame', function (parent) {
var window = Clazz.new(C$.c$$java_awt_Frame,[parent]);
(I$[11]||(I$[11]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.SwingUtils'))).centerInParent$java_awt_Component(window);
window.setVisible$Z(true);
var timer = Clazz.new((I$[12]||(I$[12]=Clazz.load('javax.swing.Timer'))).c$$I$java_awt_event_ActionListener,[4000, ((
(function(){var C$=Clazz.newClass$(P$, "KSUCreditsWindow$2", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.$finals.window.isDisplayable()) {
this.$finals.window.dispose();
}});
})()
), Clazz.new((I$[13]||(I$[13]=Clazz.load('edu.colorado.phet.common.phetcommon.application.KSUCreditsWindow$2'))).$init$, [this, {window: window}]))]);
timer.setRepeats$Z(false);
timer.start();
return window;
}, 1);

Clazz.newMethod$(C$, 'main', function (args) {
var window = Clazz.new(C$.c$$java_awt_Frame,[null]);
(I$[11]||(I$[11]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.SwingUtils'))).centerWindowOnScreen$java_awt_Window(window);
window.setVisible$Z(true);
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
