(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass$(P$, "ConstrainedIntegerProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ConstrainedProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.min = 0;
this.max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_util_IntegerRange', function (range) {
C$.c$$I$I$I.apply(this, [range.getMin(), range.getMax(), range.getDefault()]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I', function (min, max, value) {
C$.superClazz.c$$TT.apply(this, [new Integer(value)]);
C$.$init$.apply(this);
this.min = min;
this.max = max;
if (!this.isValid$Integer(new Integer(value))) {
this.handleInvalidValue$TT(new Integer(value));
}}, 1);

Clazz.newMethod$(C$, ['isValid$Integer','isValid$TT'], function (value) {
return ((value).intValue() >= this.min  && (value).intValue() <= this.max  );
});

Clazz.newMethod$(C$, 'getMin', function () {
return this.min;
});

Clazz.newMethod$(C$, 'getMax', function () {
return this.max;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
