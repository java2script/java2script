(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractVector2F", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'magnitude', function () {
return Math.sqrt(this.magnitudeSquared());
});

Clazz.newMethod$(C$, 'magnitudeSquared', function () {
return this.getX() * this.getX() + this.getY() * this.getY();
});

Clazz.newMethod$(C$, 'dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
var result = 0;
result += this.getX() * v.getX();
result += this.getY() * v.getY();
return result;
});

Clazz.newMethod$(C$, 'getAngle', function () {
return Math.atan2(this.getY(), this.getX());
});

Clazz.newMethod$(C$, 'distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
var dx = this.getX() - v.getX();
var dy = this.getY() - v.getY();
return Math.sqrt(dx * dx + dy * dy);
});

Clazz.newMethod$(C$, 'getCrossProductScalar$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return (this.magnitude() * v.magnitude() * Math.sin(this.getAngle() - v.getAngle()) );
});

Clazz.newMethod$(C$, 'normalized', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$F$F,[this.getX() / magnitude, this.getY() / magnitude]);
});

Clazz.newMethod$(C$, 'getInstanceOfMagnitude$F', function (magnitude) {
return this.times$F(magnitude / this.magnitude());
});

Clazz.newMethod$(C$, 'times$F', function (scale) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$F$F,[this.getX() * scale, this.getY() * scale]);
});

Clazz.newMethod$(C$, 'plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return this.plus$F$F(v.getX(), v.getY());
});

Clazz.newMethod$(C$, 'plus$java_awt_geom_Dimension2D', function (delta) {
return this.plus$F$F(delta.getWidth(), delta.getHeight());
});

Clazz.newMethod$(C$, 'plus$F$F', function (x, y) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$F$F,[this.getX() + x, this.getY() + y]);
});

Clazz.newMethod$(C$, 'getPerpendicularVector', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$F$F,[this.getY(), -this.getX()]);
});

Clazz.newMethod$(C$, 'minus$F$F', function (x, y) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$F$F,[this.getX() - x, this.getY() - y]);
});

Clazz.newMethod$(C$, 'minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2F', function (v) {
return this.minus$F$F(v.getX(), v.getY());
});

Clazz.newMethod$(C$, 'getRotatedInstance$F', function (angle) {
return (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).createPolar$F$F(this.magnitude(), this.getAngle() + angle);
});

Clazz.newMethod$(C$, 'to2F', function () {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX(), this.getY()]);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
