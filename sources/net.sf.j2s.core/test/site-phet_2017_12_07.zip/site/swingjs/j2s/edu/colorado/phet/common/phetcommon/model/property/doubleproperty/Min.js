(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property.doubleproperty"),I$=[];
var C$=Clazz.newClass$(P$, "Min", null, 'edu.colorado.phet.common.phetcommon.model.property.doubleproperty.CompositeDoubleProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (a, b) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "Min$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$apply', function () {
return new Double(Math.min((this.$finals.a.get()).doubleValue(), (this.$finals.b.get()).doubleValue()));
});
})()
), Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.doubleproperty.Min$1'))).$init$, [this, {a: a, b: b}])), [a, b]]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
