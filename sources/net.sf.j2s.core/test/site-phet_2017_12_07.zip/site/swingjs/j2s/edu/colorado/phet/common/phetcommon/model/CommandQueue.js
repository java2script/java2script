(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newClass$(P$, "CommandQueue", null, null, 'edu.colorado.phet.common.phetcommon.model.Command');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.al = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, 'size', function () {
return this.al.size();
});

Clazz.newMethod$(C$, 'doIt', function () {
while (!this.al.isEmpty()){
p$.commandAt$I.apply(this, [0]).doIt();
this.al.remove$I(0);
}
});

Clazz.newMethod$(C$, 'commandAt$I', function (i) {
return this.al.get$I(i);
});

Clazz.newMethod$(C$, 'addCommand$edu_colorado_phet_common_phetcommon_model_Command', function (c) {
this.al.add$TE(c);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
