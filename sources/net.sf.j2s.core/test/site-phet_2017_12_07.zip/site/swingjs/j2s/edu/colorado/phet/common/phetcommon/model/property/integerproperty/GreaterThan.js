(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property.integerproperty"),I$=[];
var C$=Clazz.newClass$(P$, "GreaterThan", null, 'edu.colorado.phet.common.phetcommon.model.property.CompositeBooleanProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I', function (a, b) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "GreaterThan$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$apply', function () {
return new Boolean((this.$finals.a.get()).intValue() > this.$finals.b );
});
})()
), Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.GreaterThan$1'))).$init$, [this, {a: a, b: b}])), [a]]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:05
