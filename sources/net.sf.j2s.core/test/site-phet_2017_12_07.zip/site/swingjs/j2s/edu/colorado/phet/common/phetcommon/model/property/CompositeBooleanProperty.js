(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass$(P$, "CompositeBooleanProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.CompositeProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function ($function, properties) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [$function, properties]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'or$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.Or'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMethod$(C$, 'and$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.And'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
