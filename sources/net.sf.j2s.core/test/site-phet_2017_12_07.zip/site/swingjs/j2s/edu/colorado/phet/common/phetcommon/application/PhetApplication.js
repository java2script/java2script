(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "PhetApplication", null, null, 'edu.colorado.phet.common.phetcommon.util.IProguardKeepClass');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.phetApplications = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
};

C$.phetApplications = null;

Clazz.newMethod$(C$, '$init$', function () {
this.applicationStarted = false;
this.exitStrategy = ((
(function(){var C$=Clazz.newClass$(P$, "PhetApplication$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.VoidFunction0', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$apply', function () {
(I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.view.PhetExit'))).exit();
});
})()
), Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplication$1'))).$init$, [this, null]));
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
C$.c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_view_ITabbedModulePane.apply(this, [config, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_view_ITabbedModulePane', function (phetApplicationConfig, tabbedPane) {
C$.$init$.apply(this);
this.phetApplicationConfig = phetApplicationConfig;
this.tabbedModulePane = tabbedPane;
this.moduleManager = Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.application.ModuleManager'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
this.phetFrame = this.createPhetFrame();
phetApplicationConfig.getFrameSetup().initialize$javax_swing_JFrame(this.phetFrame);
this.parseArgs$SA(phetApplicationConfig.getCommandLineArgs());
C$.phetApplications.add$TE(this);
}, 1);

Clazz.newMethod$(C$, 'getTabbedModulePane', function () {
if (this.tabbedModulePane == null ) this.tabbedModulePane = (I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.Interface'))).getInstance$S$Z("edu.colorado.phet.common.phetcommon.view.JTabbedModulePane", false);
return this.tabbedModulePane;
});

Clazz.newMethod$(C$, 'isDeveloperControlsEnabled', function () {
return (I$[5]||(I$[5]=Clazz.load('edu.colorado.phet.common.phetcommon.util.CommandLineUtils'))).contains$SA$S(this.phetApplicationConfig.getCommandLineArgs(), "-dev");
});

Clazz.newMethod$(C$, 'getSimInfo', function () {
return this.phetApplicationConfig;
});

Clazz.newMethod$(C$, 'getInstance', function () {
return C$.phetApplications.get$I(C$.phetApplications.size() - 1);
}, 1);

Clazz.newMethod$(C$, 'createPhetFrame', function () {
return Clazz.new((I$[6]||(I$[6]=Clazz.load('edu.colorado.phet.common.phetcommon.view.PhetFrame'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
});

Clazz.newMethod$(C$, 'parseArgs$SA', function (args) {
});

Clazz.newMethod$(C$, 'startApplication', function () {
if (!this.applicationStarted) {
this.applicationStarted = true;
if (this.moduleManager.numModules() == 0) {
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["No modules in module manager"]);
}this.phetFrame.addWindowFocusListener$java_awt_event_WindowFocusListener(((
(function(){var C$=Clazz.newClass$(P$, "PhetApplication$2", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'windowGainedFocus$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].initializeModuleReferenceSizes.apply(this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'], []);
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].phetFrame.removeWindowFocusListener$java_awt_event_WindowFocusListener(this);
});
})()
), Clazz.new((I$[7]||(I$[7]=Clazz.load('java.awt.event.WindowAdapter'))), [this, null],P$.PhetApplication$2)));
if (this.isDeveloperControlsEnabled()) {
var startModuleNumber = this.phetApplicationConfig.getOptionArg$S("-startModule");
if (startModuleNumber != null ) {
this.setStartModule$edu_colorado_phet_common_phetcommon_application_Module(this.getModule$I((Integer.$valueOf(startModuleNumber)).intValue()));
}}this.moduleManager.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.getStartModule());
this.phetFrame.setVisible$Z(true);
this.moduleManager.getActiveModule().getHelpPanel().revalidate();
this.updateLogoVisibility();
} else {
System.out.println$S("WARNING: PhetApplication.startApplication was called more than once.");
}});

Clazz.newMethod$(C$, 'updateLogoVisibility', function () {
for (var i = 0; i < this.moduleManager.numModules(); i++) {
if (this.moduleAt$I(i).isLogoPanelVisible() && this.phetFrame.getTabbedModulePane() != null   && this.phetFrame.getTabbedModulePane().getLogoVisible() ) {
this.moduleAt$I(i).setLogoPanelVisible$Z(false);
}}
});

Clazz.newMethod$(C$, 'initializeModuleReferenceSizes', function () {
for (var i = 0; i < this.moduleManager.numModules(); i++) {
(this.moduleManager.moduleAt$I(i)).setReferenceSize();
}
});

Clazz.newMethod$(C$, 'getPhetFrame', function () {
return this.phetFrame;
});

Clazz.newMethod$(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
this.moduleManager.setModules$edu_colorado_phet_common_phetcommon_application_ModuleA(modules);
});

Clazz.newMethod$(C$, 'removeModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.removeModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMethod$(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.addModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMethod$(C$, 'moduleAt$I', function (i) {
return this.moduleManager.moduleAt$I(i);
});

Clazz.newMethod$(C$, 'getModule$I', function (i) {
return this.moduleAt$I(i);
});

Clazz.newMethod$(C$, 'setActiveModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMethod$(C$, 'setActiveModule$I', function (i) {
this.moduleManager.setActiveModule$I(i);
});

Clazz.newMethod$(C$, 'getStartModule', function () {
var developmentModule = this.getDevelopmentModule();
if (developmentModule.isSome()) {
return this.moduleAt$I((developmentModule.get()).intValue());
} else {
return this.moduleManager.getStartModule();
}});

Clazz.newMethod$(C$, 'setStartModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.moduleManager.setStartModule$edu_colorado_phet_common_phetcommon_application_Module(module);
});

Clazz.newMethod$(C$, 'addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleManager.addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver(moduleObserver);
});

Clazz.newMethod$(C$, 'removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleManager.removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver(moduleObserver);
});

Clazz.newMethod$(C$, 'indexOf$edu_colorado_phet_common_phetcommon_application_Module', function (m) {
return this.moduleManager.indexOf$edu_colorado_phet_common_phetcommon_application_Module(m);
});

Clazz.newMethod$(C$, 'numModules', function () {
return this.moduleManager.numModules();
});

Clazz.newMethod$(C$, 'getActiveModule', function () {
return this.moduleManager.getActiveModule();
});

Clazz.newMethod$(C$, 'addModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (m) {
for (var i = 0; i < m.length; i++) {
this.addModule$edu_colorado_phet_common_phetcommon_application_Module(m[i]);
}
});

Clazz.newMethod$(C$, 'getModules', function () {
return this.moduleManager.getModules();
});

Clazz.newMethod$(C$, 'pause', function () {
this.getActiveModule().deactivate();
});

Clazz.newMethod$(C$, 'resume', function () {
this.getActiveModule().activate();
});

Clazz.newMethod$(C$, 'showAboutDialog', function () {
if (this.aboutDialog == null ) {
this.aboutDialog = Clazz.new((I$[8]||(I$[8]=Clazz.load('edu.colorado.phet.common.phetcommon.dialogs.PhetAboutDialog'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication,[this]);
this.aboutDialog.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass$(P$, "PhetApplication$3", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].aboutDialog.dispose();
});

Clazz.newMethod$(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PhetApplication'].aboutDialog = null;
});
})()
), Clazz.new((I$[7]||(I$[7]=Clazz.load('java.awt.event.WindowAdapter'))), [this, null],P$.PhetApplication$3)));
this.aboutDialog.setVisible$Z(true);
}});

Clazz.newMethod$(C$, 'setControlPanelBackground$java_awt_Color', function (color) {
for (var module, $module = 0, $$module = this.getModules(); $module < $$module.length && ((module = $$module[$module]) || true); $module++) {
module.setControlPanelBackground$java_awt_Color(color);
module.setClockControlPanelBackground$java_awt_Color(color);
module.setHelpPanelBackground$java_awt_Color(color);
}
});

Clazz.newMethod$(C$, 'save', function () {
});

Clazz.newMethod$(C$, 'load', function () {
});

Clazz.newMethod$(C$, 'setExitStrategy$edu_colorado_phet_common_phetcommon_util_function_VoidFunction0', function (exitStrategy) {
this.exitStrategy = exitStrategy;
});

Clazz.newMethod$(C$, 'exit', function () {
this.exitStrategy.$apply();
});

Clazz.newMethod$(C$, 'getDevelopmentModule', function () {
if (this.phetApplicationConfig.isDev()) {
var index = (I$[9]||(I$[9]=Clazz.load('java.util.Arrays'))).asList$TTA(this.phetApplicationConfig.getCommandLineArgs()).indexOf$O("-module");
if (index >= 0 && index + 1 < this.phetApplicationConfig.getCommandLineArgs().length ) {
var moduleIndexString = this.phetApplicationConfig.getCommandLineArgs()[index + 1];
var moduleIndex = Integer.parseInt(moduleIndexString);
return Clazz.new((I$[10]||(I$[10]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').Some))).c$$TT,[new Integer(moduleIndex)]);
}}return Clazz.new((I$[11]||(I$[11]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').None))));
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
