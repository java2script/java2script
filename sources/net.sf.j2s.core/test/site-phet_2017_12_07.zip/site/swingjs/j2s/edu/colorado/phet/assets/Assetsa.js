(function(){var P$=Clazz.newPackage$("edu.colorado.phet.assets");
var C$=Clazz.newClass$(P$, "Assetsa");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'main', function (args) {
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-05 20:16:21
