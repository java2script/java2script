(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application");
var C$=Clazz.newInterface$(P$, "ModuleObserver", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

})();
//Created 2017-12-07 06:41:00
