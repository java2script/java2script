(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractVector2D", null, null, 'java.io.Serializable');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'magnitude', function () {
return Math.sqrt(this.magnitudeSquared());
});

Clazz.newMethod$(C$, 'magnitudeSquared', function () {
return this.getX() * this.getX() + this.getY() * this.getY();
});

Clazz.newMethod$(C$, 'dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
var result = 0;
result += this.getX() * v.getX();
result += this.getY() * v.getY();
return result;
});

Clazz.newMethod$(C$, 'getAngle', function () {
return Math.atan2(this.getY(), this.getX());
});

Clazz.newMethod$(C$, 'toPoint2D', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))).c$$D$D,[this.getX(), this.getY()]);
});

Clazz.newMethod$(C$, 'distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
var dx = this.getX() - v.getX();
var dy = this.getY() - v.getY();
return Math.sqrt(dx * dx + dy * dy);
});

Clazz.newMethod$(C$, 'distance2$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
var dx = this.getX() - v.getX();
var dy = this.getY() - v.getY();
return dx * dx + dy * dy;
});

Clazz.newMethod$(C$, 'distance$java_awt_geom_Point2D', function (point) {
return this.distance$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D(Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$java_awt_geom_Point2D,[point]));
});

Clazz.newMethod$(C$, 'toDimension', function () {
return Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.view.Dimension2DDouble'))).c$$D$D,[this.getX(), this.getY()]);
});

Clazz.newMethod$(C$, 'getDestination$java_awt_geom_Point2D', function (startPt) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))).c$$D$D,[startPt.getX() + this.getX(), startPt.getY() + this.getY()]);
});

Clazz.newMethod$(C$, 'getCrossProductScalar$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
return (this.magnitude() * v.magnitude() * Math.sin(this.getAngle() - v.getAngle()) );
});

Clazz.newMethod$(C$, 'normalized', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX() / magnitude, this.getY() / magnitude]);
});

Clazz.newMethod$(C$, 'getInstanceOfMagnitude$D', function (magnitude) {
return this.times$D(magnitude / this.magnitude());
});

Clazz.newMethod$(C$, 'times$D', function (scale) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX() * scale, this.getY() * scale]);
});

Clazz.newMethod$(C$, 'plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
return this.plus$D$D(v.getX(), v.getY());
});

Clazz.newMethod$(C$, 'plus$java_awt_geom_Dimension2D', function (delta) {
return this.plus$D$D(delta.getWidth(), delta.getHeight());
});

Clazz.newMethod$(C$, 'plus$D$D', function (x, y) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX() + x, this.getY() + y]);
});

Clazz.newMethod$(C$, 'plus$java_awt_geom_Point2D', function (p) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX() + p.getX(), this.getY() + p.getY()]);
});

Clazz.newMethod$(C$, 'getPerpendicularVector', function () {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getY(), -this.getX()]);
});

Clazz.newMethod$(C$, 'minus$D$D', function (x, y) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.getX() - x, this.getY() - y]);
});

Clazz.newMethod$(C$, 'minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
return this.minus$D$D(v.getX(), v.getY());
});

Clazz.newMethod$(C$, 'getRotatedInstance$D', function (angle) {
return (I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).createPolar$D$D(this.magnitude(), this.getAngle() + angle);
});

Clazz.newMethod$(C$, 'negated', function () {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[-this.getX(), -this.getY()]);
});

Clazz.newMethod$(C$, 'to2F', function () {
return Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2F'))).c$$D$D,[this.getX(), this.getY()]);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
