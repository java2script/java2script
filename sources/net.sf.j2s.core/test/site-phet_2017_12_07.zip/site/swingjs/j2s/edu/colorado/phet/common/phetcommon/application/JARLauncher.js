(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application");
var C$=Clazz.newClass$(P$, "JARLauncher", null, null, 'edu.colorado.phet.common.phetcommon.util.IProguardKeepClass');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
