(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math.vector");
var C$=Clazz.newClass$(P$, "Vector4D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector4D');

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.ZERO = Clazz.new(C$);
C$.X_UNIT = Clazz.new(C$.c$$D$D$D$D,[1, 0, 0, 0]);
C$.Y_UNIT = Clazz.new(C$.c$$D$D$D$D,[0, 1, 0, 0]);
C$.Z_UNIT = Clazz.new(C$.c$$D$D$D$D,[0, 0, 1, 0]);
C$.W_UNIT = Clazz.new(C$.c$$D$D$D$D,[0, 0, 0, 1]);
};

C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;
C$.Z_UNIT = null;
C$.W_UNIT = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.w = 0;
}, 1);

Clazz.newMethod$(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ^ Float.floatToIntBits(this.w) ;
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector4D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z   && m.w == this.w  );
});

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (v) {
C$.c$$D$D$D.apply(this, [v.getX(), v.getY(), v.getZ()]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D', function (x, y, z) {
C$.c$$D$D$D$D.apply(this, [x, y, z, 1]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D$D', function (x, y, z, w) {
Clazz.super(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
this.w = w;
}, 1);

Clazz.newMethod$(C$, 'getX', function () {
return this.x;
});

Clazz.newMethod$(C$, 'getY', function () {
return this.y;
});

Clazz.newMethod$(C$, 'getZ', function () {
return this.z;
});

Clazz.newMethod$(C$, 'getW', function () {
return this.w;
});
})();
//Created 2017-12-07 06:41:03
