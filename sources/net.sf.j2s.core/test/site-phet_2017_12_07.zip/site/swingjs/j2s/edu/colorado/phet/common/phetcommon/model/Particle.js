(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newClass$(P$, "Particle", null, 'edu.colorado.phet.common.phetcommon.util.SimpleObservable', 'edu.colorado.phet.common.phetcommon.model.ModelElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.position = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))));
this.velocity = Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))));
this.acceleration = Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))));
this.type = 3;
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.prevAccelerationX = 0;
this.prevAccelerationY = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'clone', function () {
var clone = Clazz.clone(this);
clone.position = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))).c$$D$D,[this.position.x, this.position.y]);
clone.velocity = Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))).c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D,[this.velocity]);
clone.acceleration = Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))).c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D,[this.acceleration]);
return clone;
});

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (position, velocity, acceleration) {
Clazz.super(C$, this,1);
this.position.x = position.getX();
this.position.y = position.getY();
this.setVelocityNoObs$D$D(velocity.getX(), velocity.getY());
this.setAccelerationNoObs$D$D(acceleration.getX(), acceleration.getY());
}, 1);

Clazz.newMethod$(C$, 'getPosition', function () {
return this.position;
});

Clazz.newMethod$(C$, 'setPosition$D$D', function (x, y) {
this.setPositionP$D$D(x, y);
});

Clazz.newMethod$(C$, 'setPositionP$D$D', function (x, y) {
this.position.x = x;
this.position.y = y;
this.notifyObservers();
});

Clazz.newMethod$(C$, 'setPositionNoObs$D$D', function (x, y) {
this.position.x = x;
this.position.y = y;
});

Clazz.newMethod$(C$, 'setPosition$java_awt_geom_Point2D', function (position) {
this.setPositionP$D$D(position.getX(), position.getY());
});

Clazz.newMethod$(C$, 'getVelocity', function () {
return this.velocity;
});

Clazz.newMethod$(C$, 'setVelocity$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (velocity) {
this.setVelocity$D$D(velocity.getX(), velocity.getY());
});

Clazz.newMethod$(C$, 'setVelocity$D$D', function (vx, vy) {
this.velocity.setComponents$D$D(vx, vy);
this.notifyObservers();
});

Clazz.newMethod$(C$, 'setVelocityNoObs$D$D', function (vx, vy) {
this.velocity.setComponents$D$D(vx, vy);
});

Clazz.newMethod$(C$, 'getSpeed', function () {
return this.velocity.magnitude();
});

Clazz.newMethod$(C$, 'getAcceleration', function () {
return this.acceleration;
});

Clazz.newMethod$(C$, 'setAcceleration$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (acceleration) {
this.setAccelerationXY$D$D(acceleration.getX(), acceleration.getY());
});

Clazz.newMethod$(C$, 'setAccelerationXY$D$D', function (ax, ay) {
if (ax == this.acceleration.getX()  && ay == this.acceleration.getY()  ) {
this.prevAccelerationX = this.acceleration.getX();
this.prevAccelerationY = this.acceleration.getY();
return;
}this.setAccelerationNoObs$D$D(ax, ay);
this.notifyObservers();
});

Clazz.newMethod$(C$, 'setAccelerationNoObs$D$D', function (ax, ay) {
this.prevAccelerationX = this.acceleration.getX();
this.prevAccelerationY = this.acceleration.getY();
this.acceleration.setComponents$D$D(ax, ay);
});

Clazz.newMethod$(C$, 'stepInTime$D', function (dt) {
this.stepInTimeP$D(dt);
});

Clazz.newMethod$(C$, 'stepInTimeP$D', function (dt) {
var ax = this.acceleration.getX();
var ay = this.acceleration.getY();
var vx = this.velocity.getX();
var vy = this.velocity.getY();
this.position.x += dt * vx + dt * dt * ax  / 2;
this.position.y += dt * vy + dt * dt * ay  / 2;
vx += dt * (ax + this.prevAccelerationX) / 2;
vy += dt * (ay + this.prevAccelerationY) / 2;
this.setVelocityNoObs$D$D(vx, vy);
this.prevAccelerationX = ax;
this.prevAccelerationY = ay;
if ((this.type & 4371) != 4371) this.notifyObservers();
});

Clazz.newMethod$(C$, 'translate$D$D', function (dx, dy) {
this.setPositionP$D$D(this.position.x + dx, this.position.y + dy);
});

Clazz.newMethod$(C$, 'center$java_awt_geom_Rectangle2D_Double', function (bounds) {
this.position.x = bounds.x + bounds.width / 2 + Math.random();
this.position.y = bounds.y + bounds.height / 2 + Math.random();
return this;
});

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});
})();
//Created 2017-12-07 06:41:03
