(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "ProbabilisticChooser", function(){
Clazz.newInstance$(this, arguments,0,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.RANDOM = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.Random'))));
};

C$.RANDOM = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this._entries = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_ProbabilisticChooser_EntryA', function (entries) {
C$.$init$.apply(this);
this._entries =  Clazz.newArray$((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.ProbabilisticChooser').Entry))), [entries.length]);
var pTotal = 0;
for (var i = 0; i < entries.length; i++) {
pTotal += entries[i].getWeight();
}
var fNorm = 1 / pTotal;
var p = 0;
for (var i = 0; i < entries.length; i++) {
p += entries[i].getWeight() * fNorm;
this._entries[i] = Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.ProbabilisticChooser').Entry))).c$$O$D,[entries[i].getObject(), p]);
}
}, 1);

Clazz.newMethod$(C$, 'get', function () {
return this.get$D(C$.RANDOM.nextDouble());
});

Clazz.newMethod$(C$, 'get$D', function (p) {
var result = null;
for (var i = 0; i < this._entries.length && result == null  ; i++) {
var entry = this._entries[i];
if (p <= entry.getWeight() ) {
result = entry.getObject();
}}
return result;
});

Clazz.newMethod$(C$, 'getEntries', function () {
return this._entries;
});
;
(function(){var C$=Clazz.newClass$(P$.ProbabilisticChooser, "Entry", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.object = null;
this.weight = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$O$D', function (object, weight) {
C$.$init$.apply(this);
this.object = object;
this.weight = weight;
}, 1);

Clazz.newMethod$(C$, 'getObject', function () {
return this.object;
});

Clazz.newMethod$(C$, 'getWeight', function () {
return this.weight;
});

Clazz.newMethod$(C$);
})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
