(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock");
var C$=Clazz.newClass$(P$, "ClockAdapter", null, null, 'edu.colorado.phet.common.phetcommon.model.clock.ClockListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMethod$(C$, 'clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMethod$(C$, 'clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMethod$(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMethod$(C$, 'simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
