(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math");
var C$=Clazz.newClass$(P$, "SerializablePoint2D", null, ['java.awt.geom.Point2D','java.awt.geom.Point2D.Double'], 'java.io.Externalizable');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D', function (x, y) {
C$.superClazz.c$$D$D.apply(this, [x, y]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D', function (pt) {
C$.c$$D$D.apply(this, [pt.getX(), pt.getY()]);
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "(" + new Double(this.getX()).toString() + ", " + new Double(this.getY()).toString() + ")" ;
});

Clazz.newMethod$(C$, 'readExternal$java_io_ObjectInput', function ($in) {
this.x = $in.readDouble();
this.y = $in.readDouble();
});

Clazz.newMethod$(C$, 'writeExternal$java_io_ObjectOutput', function (out) {
out.writeDouble$D(this.x);
out.writeDouble$D(this.y);
});
})();
//Created 2017-12-07 06:41:02
