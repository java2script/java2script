(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newClass$(P$, "Clock", null, null, 'edu.colorado.phet.common.phetcommon.model.clock.IClock');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.listeners = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
this.lastSimulationTime = 0.0;
this.simulationTime = 0.0;
this.lastWallTime = 0;
this.wallTime = 0;
this.firstPanel = -1;
this.firstModule = -1;
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.timingStrategy = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (timingStrategy) {
C$.$init$.apply(this);
this.timingStrategy = timingStrategy;
}, 1);

Clazz.newMethod$(C$, 'addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
var pt = this.listeners.size();
if (Clazz.instanceOf(clockListener, "edu.colorado.phet.common.phetcommon.model.clock.ApparatusPanelClockListener")) {
if (this.firstPanel < 0) this.firstPanel = pt;
 else pt = this.firstPanel;
} else if (Clazz.instanceOf(clockListener, "edu.colorado.phet.common.phetcommon.model.clock.ModuleClockListener")) {
if (this.firstModule < 0) this.firstModule = pt;
 else pt = this.firstModule;
} else if (this.firstModule > 0 && this.firstPanel > 0 ) {
pt = Math.min(this.firstModule++, this.firstPanel++);
} else if (this.firstModule > 0) {
pt = this.firstModule++;
} else if (this.firstPanel > 0) {
pt = this.firstPanel++;
}this.listeners.add$I$TE(pt, clockListener);
});

Clazz.newMethod$(C$, 'removeClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.listeners.remove$O(clockListener);
});

Clazz.newMethod$(C$, 'addSimulationTimeChangeListener$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (listener) {
this.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(((
(function(){var C$=Clazz.newClass$(P$, "Clock$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
this.$finals.listener.$apply$TT(new Double(clockEvent.getSimulationTimeChange()));
});
})()
), Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockAdapter'))), [this, {listener: listener}],P$.Clock$1)));
});

Clazz.newMethod$(C$, 'resetSimulationTime', function () {
this.setSimulationTime$D(0.0);
this.notifySimulationTimeReset();
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMethod$(C$, 'tick$D', function (simulationTimeChange) {
this.lastWallTime = this.wallTime;
this.wallTime = System.currentTimeMillis();
{
document.title = (this.wallTime - this.lastWallTime);
}p$.setSimulationTimeNoUpdate$D.apply(this, [this.simulationTime + simulationTimeChange]);
this.notifyClockTicked();
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMethod$(C$, 'doTick', function () {
this.tick$D(this.timingStrategy.getSimulationTimeChangeWT$J$J(this.lastWallTime, this.wallTime));
});

Clazz.newMethod$(C$, 'stepClockWhilePaused', function () {
this.tick$D(this.timingStrategy.getSimulationTimeChangeForPausedClock());
});

Clazz.newMethod$(C$, 'stepClockBackWhilePaused', function () {
this.tick$D(-this.timingStrategy.getSimulationTimeChangeForPausedClock());
});

Clazz.newMethod$(C$, 'setSimulationTimeNoUpdate$D', function (simulationTime) {
this.lastSimulationTime = this.simulationTime;
this.simulationTime = simulationTime;
});

Clazz.newMethod$(C$, 'getWallTimeChange', function () {
return this.wallTime - this.lastWallTime;
});

Clazz.newMethod$(C$, 'getSimulationTimeChange', function () {
return this.simulationTime - this.lastSimulationTime;
});

Clazz.newMethod$(C$, 'getSimulationTime', function () {
return this.simulationTime;
});

Clazz.newMethod$(C$, 'getWallTime', function () {
return this.wallTime;
});

Clazz.newMethod$(C$, 'setSimulationTime$D', function (simulationTime) {
p$.setSimulationTimeNoUpdate$D.apply(this, [simulationTime]);
p$.testNotifySimulationTimeChange.apply(this, []);
});

Clazz.newMethod$(C$, 'getTimingStrategy', function () {
return this.timingStrategy;
});

Clazz.newMethod$(C$, 'setTimingStrategy$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (timingStrategy) {
this.timingStrategy = timingStrategy;
});

Clazz.newMethod$(C$, 'notifyClockTicked', function () {
var clockEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0, n = this.listeners.size(); i < n; i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMethod$(C$, 'notifyClockPaused', function () {
var clockEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMethod$(C$, 'notifyClockStarted', function () {
var clockEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMethod$(C$, 'notifySimulationTimeReset', function () {
var clockEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMethod$(C$, 'testNotifySimulationTimeChange', function () {
if (this.getSimulationTimeChange() != 0.0 ) {
this.notifySimulationTimeChanged();
}});

Clazz.newMethod$(C$, 'notifySimulationTimeChanged', function () {
var clockEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
for (var i = 0; i < this.listeners.size(); i++) {
var clockListener = this.listeners.get$I(i);
clockListener.simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
}
});

Clazz.newMethod$(C$, 'stop', function () {
this.pause();
});

Clazz.newMethod$(C$, 'containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
return this.listeners.contains$O(clockListener);
});

Clazz.newMethod$(C$, 'removeAllClockListeners', function () {
this.listeners.clear();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
