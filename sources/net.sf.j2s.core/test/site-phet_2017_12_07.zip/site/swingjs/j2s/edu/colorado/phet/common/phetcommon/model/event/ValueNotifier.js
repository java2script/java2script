(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.event");
var C$=Clazz.newClass$(P$, "ValueNotifier", null, 'edu.colorado.phet.common.phetcommon.model.event.Notifier');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.value = null;
}, 1);

Clazz.newMethod$(C$, ['c$$TT'], function (value) {
Clazz.super(C$, this,1);
this.value = value;
}, 1);

Clazz.newMethod$(C$, 'updateListeners', function () {
this.updateListeners$TT(this.value);
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.value;
});

Clazz.newMethod$(C$, ['setValue$TT'], function (value) {
this.value = value;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
