(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock");
var C$=Clazz.newInterface$(P$, "ClockListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

})();
//Created 2017-12-07 06:41:03
