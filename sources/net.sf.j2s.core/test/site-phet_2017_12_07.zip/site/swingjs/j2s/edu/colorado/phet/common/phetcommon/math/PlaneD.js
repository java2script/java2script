(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "PlaneD");

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.XY = Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector3D'))).Z_UNIT, 0]);
C$.XZ = Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector3D'))).Y_UNIT, 0]);
C$.YZ = Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector3D'))).X_UNIT, 0]);
};

C$.XY = null;
C$.XZ = null;
C$.YZ = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.normal = null;
this.distance = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D', function (normal, distance) {
C$.$init$.apply(this);
this.normal = normal;
this.distance = distance;
}, 1);

Clazz.newMethod$(C$, 'intersectWithRay$edu_colorado_phet_common_phetcommon_math_Ray3D', function (ray) {
return ray.pointAtDistance$D(ray.distanceToPlane$edu_colorado_phet_common_phetcommon_math_PlaneD(this));
});

Clazz.newMethod$(C$, 'fromTriangle$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$edu_colorado_phet_common_phetcommon_math_vector_Vector3D', function (a, b, c) {
var normal = (c.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a)).cross$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(b.minus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a));
if (normal.magnitude() == 0 ) {
return null;
}normal = normal.normalized();
return Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3D$D,[normal, normal.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3D(a)]);
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
