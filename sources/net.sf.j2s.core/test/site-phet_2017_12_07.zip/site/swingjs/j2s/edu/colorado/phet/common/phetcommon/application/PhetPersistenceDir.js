(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application");
var C$=Clazz.newClass$(P$, "PhetPersistenceDir", null, 'java.io.File');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, [System.getProperty("user.home") + System.getProperty("file.separator") + ".phet" ]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-07 06:41:01
