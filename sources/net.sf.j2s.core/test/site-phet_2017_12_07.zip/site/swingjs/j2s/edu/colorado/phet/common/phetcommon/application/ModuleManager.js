(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "ModuleManager");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.modules = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
this.moduleObservers = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.activeModule = null;
this.phetApplication = null;
this.startModule = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplication', function (phetApplication) {
C$.$init$.apply(this);
this.phetApplication = phetApplication;
this.startModule = null;
}, 1);

Clazz.newMethod$(C$, 'moduleAt$I', function (i) {
return this.modules.get$I(i);
});

Clazz.newMethod$(C$, 'getActiveModule', function () {
return this.activeModule;
});

Clazz.newMethod$(C$, 'numModules', function () {
return this.modules.size();
});

Clazz.newMethod$(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (this.modules.size() == 0) {
this.startModule = module;
}this.modules.add$TE(module);
p$.notifyModuleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.application.ModuleEvent'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
});

Clazz.newMethod$(C$, 'removeModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.modules.remove$O(module);
if (module === this.startModule ) {
this.startModule = null;
if (this.modules.size() > 0) {
this.startModule = this.moduleAt$I(0);
}}if (this.getActiveModule() === module ) {
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.modules.size() == 0 ? null : this.modules.get$I(0));
}p$.notifyModuleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.application.ModuleEvent'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
});

Clazz.newMethod$(C$, 'indexOf$edu_colorado_phet_common_phetcommon_application_Module', function (m) {
return this.modules.indexOf$O(m);
});

Clazz.newMethod$(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
while (this.numModules() > 0){
var module = this.moduleAt$I(0);
this.removeModule$edu_colorado_phet_common_phetcommon_application_Module(module);
}
this.addAllModules$edu_colorado_phet_common_phetcommon_application_ModuleA(modules);
});

Clazz.newMethod$(C$, 'addAllModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (modules) {
for (var i = 0; i < modules.length; i++) {
this.addModule$edu_colorado_phet_common_phetcommon_application_Module(modules[i]);
}
});

Clazz.newMethod$(C$, 'getModules', function () {
var moduleArray =  Clazz.newArray$((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.application.Module'))), [this.modules.size()]);
for (var i = 0; i < this.modules.size(); i++) {
moduleArray[i] = this.modules.get$I(i);
}
return moduleArray;
});

Clazz.newMethod$(C$, 'setActiveModule$I', function (i) {
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(this.moduleAt$I(i));
});

Clazz.newMethod$(C$, 'setActiveModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (module == null ) {
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["Active module can\'t be null."]);
}if (this.activeModule !== module ) {
this.deactivateCurrentModule();
p$.activate$edu_colorado_phet_common_phetcommon_application_Module.apply(this, [module]);
p$.notifyActiveModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent.apply(this, [Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.application.ModuleEvent'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module,[p$.getPhetApplication.apply(this, []), module])]);
p$.verifyActiveState.apply(this, []);
}});

Clazz.newMethod$(C$, 'verifyActiveState', function () {
var numActiveModules = p$.getNumActiveModules.apply(this, []);
var numClocksRunning = p$.getNumClocksRunning.apply(this, []);
var clockShared = p$.isClockShared.apply(this, []);
if (numActiveModules != 1) {
Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,["multiple modules are running: active modules=" + numActiveModules]).printStackTrace();
}if (numClocksRunning > 1) {
var runningModules = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
for (var module, $module = this.modules.iterator (); $module.hasNext () && ((module = $module.next ()) || true);) {
if (module.getClock().isRunning()) {
runningModules.add$TE(module.getName());
}}
Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,["multiple clocks are running: running clocks=" + numClocksRunning + ", in modules " + runningModules ]).printStackTrace();
}if (numClocksRunning == 1 && !this.activeModule.getClock().isRunning() ) {
Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,["a clock is running that does not belong to the active module"]).printStackTrace();
}if (clockShared) {
Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,["Multiple modules are using the same clock instance."]).printStackTrace();
}});

Clazz.newMethod$(C$, 'isClockShared', function () {
for (var i = 0; i < this.modules.size(); i++) {
for (var k = 0; k < this.modules.size(); k++) {
if (k != i) {
var clock1 = this.modules.get$I(i).getClock();
var clock2 = this.modules.get$I(k).getClock();
if (clock1 === clock2 ) {
return true;
}}}
}
return false;
});

Clazz.newMethod$(C$, 'getNumActiveModules', function () {
var count = 0;
for (var i = 0; i < this.modules.size(); i++) {
if (this.modules.get$I(i).isActive()) {
count++;
}}
return count;
});

Clazz.newMethod$(C$, 'getNumClocksRunning', function () {
var runningClocks = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
for (var i = 0; i < this.modules.size(); i++) {
var clock = this.modules.get$I(i).getClock();
if (clock.isRunning()) {
if (!runningClocks.contains$O(clock)) {
runningClocks.add$TE(clock);
}}}
return runningClocks.size();
});

Clazz.newMethod$(C$, 'addModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (observer) {
this.moduleObservers.add$TE(observer);
});

Clazz.newMethod$(C$, 'getPhetApplication', function () {
return this.phetApplication;
});

Clazz.newMethod$(C$, 'activate$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.activeModule = module;
if (module != null ) {
module.activate();
this.setActiveModule$edu_colorado_phet_common_phetcommon_application_Module(module);
}});

Clazz.newMethod$(C$, 'deactivateCurrentModule', function () {
if (this.activeModule != null ) {
this.activeModule.deactivate();
}});

Clazz.newMethod$(C$, 'notifyModuleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.moduleAdded$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMethod$(C$, 'notifyActiveModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.activeModuleChanged$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMethod$(C$, 'notifyModuleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent', function (event) {
for (var i = 0; i < this.moduleObservers.size(); i++) {
var moduleObserver = this.moduleObservers.get$I(i);
moduleObserver.moduleRemoved$edu_colorado_phet_common_phetcommon_application_ModuleEvent(event);
}
});

Clazz.newMethod$(C$, 'getStartModule', function () {
return this.startModule;
});

Clazz.newMethod$(C$, 'setStartModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
if (!this.modules.contains$O(module)) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["start module has not been added"]);
}this.startModule = module;
});

Clazz.newMethod$(C$, 'removeModuleObserver$edu_colorado_phet_common_phetcommon_application_ModuleObserver', function (moduleObserver) {
this.moduleObservers.remove$O(moduleObserver);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
