(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.audio"),I$=[];
var C$=Clazz.newClass$(P$, "PhetAudioClip");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.url = null;
this.playing = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (resourceName) {
C$.c$$java_net_URL.apply(this, [(I$[0]||(I$[0]=Clazz.load('Thread'))).currentThread().getContextClassLoader().getResource$S(resourceName)]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_net_URL', function (url) {
C$.$init$.apply(this);
this.url = url;
}, 1);

Clazz.newMethod$(C$, 'play', function () {
p$.startAudioThread.apply(this, []);
});

Clazz.newMethod$(C$, 'isPlaying', function () {
return this.playing;
});

Clazz.newMethod$(C$, 'startAudioThread', function () {
var playingThread = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.lang.Thread'))).c$$Runnable,[((
(function(){var C$=Clazz.newClass$(P$, "PhetAudioClip$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
try {
this.b$['edu.colorado.phet.common.phetcommon.audio.PhetAudioClip'].processAudio.apply(this.b$['edu.colorado.phet.common.phetcommon.audio.PhetAudioClip'], []);
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
e.printStackTrace();
} else {
throw e;
}
}
});
})()
), Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.audio.PhetAudioClip$1'))).$init$, [this, null]))]);
playingThread.setDaemon$Z(true);
playingThread.start();
});

Clazz.newMethod$(C$, 'processAudio', function () {
this.playing = true;
try {
{
swingjs.JSToolkit.playAudioFile$java_net-URL(this.url);
}} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
e.printStackTrace();
} else {
throw e;
}
} finally {
this.playing = false;
}
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
