(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math");
var C$=Clazz.newClass$(P$, "MutableComplex", null, 'edu.colorado.phet.common.phetcommon.math.Complex');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$D$D', function (real, imaginary) {
C$.superClazz.c$$D$D.apply(this, [real, imaginary]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_math_Complex.apply(this, [c]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'copy', function () {
return C$.superClazz.prototype.copy.apply(this, []);
});

Clazz.newMethod$(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.setValue$D$D(c._real, c._imaginary);
});

Clazz.newMethod$(C$, 'setValue$D$D', function (real, imag) {
this._real = real;
this._imaginary = imag;
});

Clazz.newMethod$(C$, 'setValue$D', function (real) {
this.setValue$D$D(real, 0);
});

Clazz.newMethod$(C$, 'zero', function () {
this.setValue$D$D(0, 0);
});

Clazz.newMethod$(C$, 'add$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.add$D$D(c._real, c._imaginary);
});

Clazz.newMethod$(C$, 'add$D$D', function (real, imaginary) {
this._real += real;
this._imaginary += imaginary;
});

Clazz.newMethod$(C$, 'add$D', function (real) {
this.add$D$D(real, 0);
});

Clazz.newMethod$(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.subtract$D$D(c._real, c._imaginary);
});

Clazz.newMethod$(C$, 'subtract$D$D', function (real, imaginary) {
this._real -= real;
this._imaginary -= imaginary;
});

Clazz.newMethod$(C$, 'subtract$D', function (real) {
this.subtract$D$D(real, 0);
});

Clazz.newMethod$(C$, 'multiply$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.multiply$D$D(c._real, c._imaginary);
});

Clazz.newMethod$(C$, 'multiply$D$D', function (real, imaginary) {
var newReal = this._real * real - this._imaginary * imaginary;
var newImaginary = this._real * imaginary + this._imaginary * real;
this._real = newReal;
this._imaginary = newImaginary;
});

Clazz.newMethod$(C$, 'multiply$D', function (real) {
this.multiply$D$D(real, 0);
});

Clazz.newMethod$(C$, 'divide$edu_colorado_phet_common_phetcommon_math_Complex', function (c) {
this.divide$D$D(c._real, c._imaginary);
});

Clazz.newMethod$(C$, 'divide$D$D', function (real, imaginary) {
var q = real * real + imaginary * imaginary;
var g = this._real * real + this._imaginary * imaginary;
var h = this._imaginary * real - this._real * imaginary;
this._real = g / q;
this._imaginary = h / q;
});

Clazz.newMethod$(C$, 'divide$D', function (real) {
this.divide$D$D(real, 0);
});

Clazz.newMethod$(C$, 'scale$D', function (scale) {
this._real *= scale;
this._imaginary *= scale;
});

Clazz.newMethod$(C$, 'exp', function () {
var multiplier = Math.exp(this._real);
this._real = multiplier * Math.cos(this._imaginary);
this._imaginary = multiplier * Math.sin(this._imaginary);
});
})();
//Created 2017-12-07 06:41:02
