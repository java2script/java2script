(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "Bounds3F");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.width = 0;
this.height = 0;
this.depth = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$F$F$F$F$F$F', function (x, y, z, width, height, depth) {
C$.$init$.apply(this);
this.x = x;
this.y = y;
this.z = z;
this.width = width;
this.height = height;
this.depth = depth;
}, 1);

Clazz.newMethod$(C$, 'fromMinMax$F$F$F$F$F$F', function (minX, maxX, minY, maxY, minZ, maxZ) {
return Clazz.new(C$.c$$F$F$F$F$F$F,[minX, minY, minZ, maxX - minX, maxY - minY, maxZ - minZ]);
}, 1);

Clazz.newMethod$(C$, 'getDepth', function () {
return this.depth;
});

Clazz.newMethod$(C$, 'getHeight', function () {
return this.height;
});

Clazz.newMethod$(C$, 'getWidth', function () {
return this.width;
});

Clazz.newMethod$(C$, 'getX', function () {
return this.x;
});

Clazz.newMethod$(C$, 'getY', function () {
return this.y;
});

Clazz.newMethod$(C$, 'getZ', function () {
return this.z;
});

Clazz.newMethod$(C$, 'getMinX', function () {
return this.x;
});

Clazz.newMethod$(C$, 'getMinY', function () {
return this.y;
});

Clazz.newMethod$(C$, 'getMinZ', function () {
return this.z;
});

Clazz.newMethod$(C$, 'getMaxX', function () {
return this.x + this.width;
});

Clazz.newMethod$(C$, 'getMaxY', function () {
return this.y + this.height;
});

Clazz.newMethod$(C$, 'getMaxZ', function () {
return this.z + this.depth;
});

Clazz.newMethod$(C$, 'getPosition', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector3F'))).c$$F$F$F,[this.x, this.y, this.z]);
});

Clazz.newMethod$(C$, 'getExtent', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector3F'))).c$$F$F$F,[this.x + this.width, this.y + this.height, this.z + this.depth]);
});

Clazz.newMethod$(C$, 'getCenter', function () {
return this.getPosition().plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.getExtent()).times$F(0.5);
});

Clazz.newMethod$(C$, 'getCenterX', function () {
return this.getCenter().x;
});

Clazz.newMethod$(C$, 'getCenterY', function () {
return this.getCenter().y;
});

Clazz.newMethod$(C$, 'getCenterZ', function () {
return this.getCenter().z;
});

Clazz.newMethod$(C$, 'intersectedBy$edu_colorado_phet_common_phetcommon_math_Ray3F', function (ray) {
var tmin;
var tmax;
var tymin;
var tymax;
var tzmin;
var tzmax;
var t0 = 1.0E-6;
var t1 = Infinity;
if (ray.dir.x >= 0 ) {
tmin = (this.getMinX() - ray.pos.x) / ray.dir.x;
tmax = (this.getMaxX() - ray.pos.x) / ray.dir.x;
} else {
tmin = (this.getMaxX() - ray.pos.x) / ray.dir.x;
tmax = (this.getMinX() - ray.pos.x) / ray.dir.x;
}if (ray.dir.y >= 0 ) {
tymin = (this.getMinY() - ray.pos.y) / ray.dir.y;
tymax = (this.getMaxY() - ray.pos.y) / ray.dir.y;
} else {
tymin = (this.getMaxY() - ray.pos.y) / ray.dir.y;
tymax = (this.getMinY() - ray.pos.y) / ray.dir.y;
}if ((tmin > tymax ) || (tymin > tmax ) ) {
return false;
}if (tymin > tmin ) {
tmin = tymin;
}if (tymax < tmax ) {
tmax = tymax;
}if (ray.dir.z >= 0 ) {
tzmin = (this.getMinZ() - ray.pos.z) / ray.dir.z;
tzmax = (this.getMaxZ() - ray.pos.z) / ray.dir.z;
} else {
tzmin = (this.getMaxZ() - ray.pos.z) / ray.dir.z;
tzmax = (this.getMinZ() - ray.pos.z) / ray.dir.z;
}if ((tmin > tzmax ) || (tzmin > tmax ) ) {
return false;
}if (tzmin > tmin ) {
tmin = tzmin;
}if (tzmax < tmax ) {
tmax = tzmax;
}return ((tmin < t1 ) && (tmax > t0 ) );
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
