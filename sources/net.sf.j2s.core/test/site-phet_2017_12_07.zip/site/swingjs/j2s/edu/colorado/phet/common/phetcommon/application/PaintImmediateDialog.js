(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "PaintImmediateDialog", function(){
Clazz.newInstance$(this, arguments,0,C$);
}, 'javax.swing.JDialog');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.timer = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame', function (frame) {
C$.superClazz.c$$java_awt_Frame.apply(this, [frame]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S', function (frame, title) {
C$.superClazz.c$$java_awt_Frame$S.apply(this, [frame, title]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog', function (owner) {
C$.superClazz.c$$java_awt_Dialog.apply(this, [owner]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S', function (owner, title) {
C$.superClazz.c$$java_awt_Dialog$S.apply(this, [owner, title]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$Z', function (owner, modal) {
C$.superClazz.c$$java_awt_Frame$Z.apply(this, [owner, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$Z', function (owner, modal) {
C$.superClazz.c$$java_awt_Dialog$Z.apply(this, [owner, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S$Z', function (owner, title, modal) {
C$.superClazz.c$$java_awt_Frame$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S$Z', function (owner, title, modal) {
C$.superClazz.c$$java_awt_Dialog$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
p$.initPaintImmediateDialog.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'initPaintImmediateDialog', function () {
this.timer = Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog').PaintImmediateTimer))).c$$javax_swing_JDialog,[this]);
this.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass$(P$, "PaintImmediateDialog$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'windowOpened$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog'].timer.start();
});

Clazz.newMethod$(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
this.b$['edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog'].timer.stop();
});
})()
), Clazz.new((I$[2]||(I$[2]=Clazz.load('java.awt.event.WindowAdapter'))), [this, null],P$.PaintImmediateDialog$1)));
});
;
(function(){var C$=Clazz.newClass$(P$.PaintImmediateDialog, "PaintImmediateTimer", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
}, 'javax.swing.Timer');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JDialog', function (dialog) {
C$.superClazz.c$$I$java_awt_event_ActionListener.apply(this, [250, ((
(function(){var C$=Clazz.newClass$(P$, "PaintImmediateDialog$PaintImmediateTimer$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var component = this.$finals.dialog.getContentPane();
component.paintImmediately$I$I$I$I(0, 0, component.getWidth(), component.getHeight());
if (false) {
System.out.println$S("PaintImmediateTimer: paintImmediately");
}});
})()
), Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog$PaintImmediateTimer$1'))).$init$, [this, {dialog: dialog}]))]);
C$.$init$.apply(this);
this.setRepeats$Z(true);
}, 1);

Clazz.newMethod$(C$, 'start', function () {
if (true) {
C$.superClazz.prototype.start.apply(this, []);
if (false) {
System.out.println$S("PaintImmediateTimer: timer started");
}}});

Clazz.newMethod$(C$, 'stop', function () {
if (true) {
C$.superClazz.prototype.stop.apply(this, []);
if (false) {
System.out.println$S("PaintImmediateTimer: timer stopped");
}}});

Clazz.newMethod$(C$);
})()
})();
//Created 2017-12-07 06:41:01
