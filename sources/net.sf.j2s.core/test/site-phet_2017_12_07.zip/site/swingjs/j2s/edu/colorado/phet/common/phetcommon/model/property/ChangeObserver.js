(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property");
var C$=Clazz.newInterface$(P$, "ChangeObserver");

})();
//Created 2017-12-07 06:41:04
