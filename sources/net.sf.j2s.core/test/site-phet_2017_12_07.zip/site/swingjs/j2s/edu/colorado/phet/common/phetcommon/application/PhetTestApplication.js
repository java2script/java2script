(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "PhetTestApplication");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.modules = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.args = null;
this.frameSetup = null;
this.appConstructor = null;
}, 1);

Clazz.newMethod$(C$, 'c$$SA', function (args) {
C$.c$$SA$edu_colorado_phet_common_phetcommon_view_util_FrameSetup.apply(this, [args, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$SA$edu_colorado_phet_common_phetcommon_view_util_FrameSetup', function (args, frameSetup) {
C$.$init$.apply(this);
this.args = p$.processArgs$SA.apply(this, [args]);
this.frameSetup = frameSetup;
}, 1);

Clazz.newMethod$(C$, 'processArgs$SA', function (args) {
var list = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[(I$[1]||(I$[1]=Clazz.load('java.util.Arrays'))).asList$TTA(args)]);
list.add$TE("-statistics-off");
list.add$TE("-updates-off");
return list.toArray$TTA( Clazz.newArray$(java.lang.String, [list.size()]));
});

Clazz.newMethod$(C$, 'addModule$edu_colorado_phet_common_phetcommon_application_Module', function (module) {
this.modules.add$TE(module);
});

Clazz.newMethod$(C$, 'setApplicationConstructor$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor', function (appConstructor) {
this.appConstructor = appConstructor;
});

Clazz.newMethod$(C$, 'startApplication', function () {
var config = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationConfig'))).c$$SA$S,[this.args, "phetcommon"]);
if (this.frameSetup != null ) {
config.setFrameSetup$edu_colorado_phet_common_phetcommon_view_util_FrameSetup(this.frameSetup);
}if (this.appConstructor == null ) {
this.appConstructor = ((
(function(){var C$=Clazz.newClass$(P$, "PhetTestApplication$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.application.ApplicationConstructor', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getApplication$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig', function (config) {
var phetApplication = ((
(function(){var C$=Clazz.newClass$(P$, "PhetTestApplication$1$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplication'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);
})()
), Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplication'))).c$$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig, [this, null, config],P$.PhetTestApplication$1$1));
phetApplication.setModules$edu_colorado_phet_common_phetcommon_application_ModuleA(this.b$['edu.colorado.phet.common.phetcommon.application.PhetTestApplication'].modules.toArray$TTA( Clazz.newArray$((I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.application.Module'))), [this.b$['edu.colorado.phet.common.phetcommon.application.PhetTestApplication'].modules.size()])));
return phetApplication;
});
})()
), Clazz.new((I$[5]||(I$[5]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetTestApplication$1'))).$init$, [this, null]));
}Clazz.new((I$[6]||(I$[6]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplicationLauncher')))).launchSim$edu_colorado_phet_common_phetcommon_application_PhetApplicationConfig$edu_colorado_phet_common_phetcommon_application_ApplicationConstructor(config, this.appConstructor);
});

Clazz.newMethod$(C$, 'setModules$edu_colorado_phet_common_phetcommon_application_ModuleA', function (m) {
this.modules.addAll$java_util_Collection((I$[1]||(I$[1]=Clazz.load('java.util.Arrays'))).asList$TTA(m));
});

Clazz.newMethod$(C$, 'getPhetFrame', function () {
return (I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.application.PhetApplication'))).getInstance().getPhetFrame();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
