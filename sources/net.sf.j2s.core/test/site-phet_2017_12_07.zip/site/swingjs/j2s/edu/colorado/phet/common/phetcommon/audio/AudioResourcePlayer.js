(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.audio"),I$=[];
var C$=Clazz.newClass$(P$, "AudioResourcePlayer");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.simResourceLoader = null;
this.enabled = false;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_resources_PhetResources$Z', function (simResourceLoader, enabled) {
C$.$init$.apply(this);
this.simResourceLoader = simResourceLoader;
this.enabled = enabled;
}, 1);

Clazz.newMethod$(C$, 'isEnabled', function () {
return this.enabled;
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (isEnabled) {
this.enabled = isEnabled;
});

Clazz.newMethod$(C$, 'playSimAudio$S', function (resourceName) {
if (this.isEnabled()) {
this.simResourceLoader.getAudioClip$S(resourceName).play();
}});

Clazz.newMethod$(C$, 'playCommonAudio$S', function (resourceName) {
if (this.isEnabled()) {
(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetCommonResources'))).getInstance().getAudioClip$S(resourceName).play();
}});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
