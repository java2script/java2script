(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon");
var C$=Clazz.newClass$(P$, "Interface");

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.instances = "";
};

C$.instances = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getInstanceWithParams$S$ClassA$OA', function (name, classes, params) {
try {
var cl = Clazz._4Name(name);
var x = cl.getConstructor$ClassA(classes);
return x.newInstance$OA(params);
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'getInstance$S$Z', function (name, isQuiet) {
var x = null;
{
Clazz._isQuiet = isQuiet;
}try {
if (!isQuiet && C$.instances.indexOf(name + ";") <= 0 ) {
System.out.println$S("swingjs.api.Interface creating instance of " + name);
C$.instances += name + ";";
}var y = Clazz._4Name(name);
if (y != null ) x = y.newInstance();
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S("Swingjs.api.Interface Error creating instance for " + name + ": \n" + e );
} else {
throw e;
}
} finally {
{
Clazz._isQuiet = false;
}}
return x;
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
