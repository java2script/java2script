(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "Optimization1D");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'goldenSectionSearch$edu_colorado_phet_common_phetcommon_util_function_Function1$D$D$D', function (f, lowBound, highBound, epsilon) {
var K = 1.618034;
var interval = (highBound - lowBound) / 1.618034;
var xa = highBound - interval;
var xb = lowBound + interval;
var fa = (f.$apply$TU(new Double(xa))).doubleValue();
var fb = (f.$apply$TU(new Double(xb))).doubleValue();
while (true){
if (fa >= fb ) {
lowBound = xa;
xa = xb;
xb = lowBound + interval / 1.618034;
fa = fb;
fb = (f.$apply$TU(new Double(xb))).doubleValue();
} else {
highBound = xb;
xb = xa;
xa = highBound - interval / 1.618034;
fb = fa;
fa = (f.$apply$TU(new Double(xa))).doubleValue();
}if (interval * 1.618034 < epsilon  || xa > xb  ) {
var x;
if (fa > fb ) {
x = 0.5 * (xb + highBound);
} else if (fa == fb ) {
x = 0.5 * (xa + xb);
} else {
x = 0.5 * (lowBound + xa);
}return x;
}interval = interval / 1.618034;
}
}, 1);

Clazz.newMethod$(C$, 'main', function (args) {
System.out.println$D(C$.goldenSectionSearch$edu_colorado_phet_common_phetcommon_util_function_Function1$D$D$D(((
(function(){var C$=Clazz.newClass$(P$, "Optimization1D$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.function.Function1', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, ['$apply$Double','$apply$TU'], function (x) {
return new Double(((x).doubleValue() - 0.5) * ((x).doubleValue() - 0.5) + 2);
});
})()
), Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.Optimization1D$1'))).$init$, [this, null])), 0, 1, 0.01));
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
