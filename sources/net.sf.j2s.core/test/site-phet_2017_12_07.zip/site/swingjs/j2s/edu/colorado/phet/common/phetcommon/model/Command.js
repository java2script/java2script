(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model");
var C$=Clazz.newInterface$(P$, "Command");

})();
//Created 2017-12-07 06:41:03
