(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newClass$(P$, "Bucket");


Clazz.newMethod$(C$, '$init$', function () {
this.position = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.holeShape = null;
this.containerShape = null;
this.baseColor = null;
this.captionText = null;
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$java_awt_geom_Dimension2D$java_awt_Color$S', function (x, y, size, baseColor, caption) {
C$.c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S.apply(this, [Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))).c$$D$D,[x, y]), size, baseColor, caption]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D_Double$java_awt_geom_Dimension2D$java_awt_Color$S', function (position, size, baseColor, caption) {
C$.$init$.apply(this);
this.position.x = position.x;
this.position.y = position.y;
this.baseColor = baseColor;
this.captionText = caption;
this.holeShape = Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('java.awt.geom.Ellipse2D').Double))).c$$D$D$D$D,[-size.getWidth() / 2, -size.getHeight() * 0.25 / 2, size.getWidth(), size.getHeight() * 0.25]);
var containerHeight = size.getHeight() * 0.875;
var containerPath = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.DoubleGeneralPath'))));
containerPath.moveTo$D$D(-size.getWidth() * 0.5, 0);
containerPath.lineTo$D$D(-size.getWidth() * 0.4, -containerHeight * 0.8);
containerPath.curveTo$D$D$D$D$D$D(-size.getWidth() * 0.3, -containerHeight * 0.8 - size.getHeight() * 0.25 * 0.6 , size.getWidth() * 0.3, -containerHeight * 0.8 - size.getHeight() * 0.25 * 0.6 , size.getWidth() * 0.4, -containerHeight * 0.8);
containerPath.lineTo$D$D(size.getWidth() * 0.5, 0);
containerPath.closePath();
var containerArea = Clazz.new((I$[3]||(I$[3]=Clazz.load('java.awt.geom.Area'))).c$$java_awt_Shape,[containerPath.getGeneralPath()]);
containerArea.subtract$java_awt_geom_Area(Clazz.new((I$[3]||(I$[3]=Clazz.load('java.awt.geom.Area'))).c$$java_awt_Shape,[this.holeShape]));
this.containerShape = containerArea;
}, 1);

Clazz.newMethod$(C$, 'getPosition', function () {
return this.position;
});

Clazz.newMethod$(C$, 'setPosition$java_awt_geom_Point2D_Double', function (position) {
this.position = position;
});

Clazz.newMethod$(C$, 'getHoleShape', function () {
return this.holeShape;
});

Clazz.newMethod$(C$, 'getContainerShape', function () {
return this.containerShape;
});

Clazz.newMethod$(C$, 'getBaseColor', function () {
return this.baseColor;
});

Clazz.newMethod$(C$, 'getCaptionText', function () {
return this.captionText;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
