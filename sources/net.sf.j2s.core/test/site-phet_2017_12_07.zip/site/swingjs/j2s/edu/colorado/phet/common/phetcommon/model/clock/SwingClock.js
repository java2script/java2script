(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newClass$(P$, "SwingClock", null, 'edu.colorado.phet.common.phetcommon.model.clock.Clock');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.timer = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$D', function (delay, dt) {
C$.c$$I$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy.apply(this, [delay, Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.TimingStrategy').Constant))).c$$D,[dt])]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy', function (delay, timingStrategy) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_model_clock_TimingStrategy.apply(this, [timingStrategy]);
C$.$init$.apply(this);
var actionListener = ((
(function(){var C$=Clazz.newClass$(P$, "SwingClock$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (!this.b$['edu.colorado.phet.common.phetcommon.model.clock.SwingClock'].isPaused()) {
this.b$['edu.colorado.phet.common.phetcommon.model.clock.SwingClock'].doTick();
}});
})()
), Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.SwingClock$1'))).$init$, [this, null]));
this.timer = Clazz.new((I$[2]||(I$[2]=Clazz.load('javax.swing.Timer'))).c$$I$java_awt_event_ActionListener,[delay, actionListener]);
}, 1);

Clazz.newMethod$(C$, 'setCoalesce$Z', function (coalesce) {
this.timer.setCoalesce$Z(coalesce);
});

Clazz.newMethod$(C$, 'start', function () {
if (this.isPaused()) {
this.timer.start();
C$.superClazz.prototype.notifyClockStarted.apply(this, []);
}});

Clazz.newMethod$(C$, 'pause', function () {
if (this.isRunning()) {
this.timer.stop();
C$.superClazz.prototype.notifyClockPaused.apply(this, []);
}});

Clazz.newMethod$(C$, 'isPaused', function () {
return !this.timer.isRunning();
});

Clazz.newMethod$(C$, 'isRunning', function () {
return this.timer.isRunning();
});

Clazz.newMethod$(C$, 'setDelay$I', function (delay) {
this.timer.setDelay$I(delay);
});

Clazz.newMethod$(C$, 'getDelay', function () {
return this.timer.getDelay();
});

Clazz.newMethod$(C$, 'getTimer', function () {
return this.timer;
});

Clazz.newMethod$(C$, 'main', function (args) {
var startTime = System.currentTimeMillis();
var timer = Clazz.new((I$[2]||(I$[2]=Clazz.load('javax.swing.Timer'))).c$$I$java_awt_event_ActionListener,[1000, ((
(function(){var C$=Clazz.newClass$(P$, "SwingClock$2", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
System.out.println$S("System.currentTimeMillis() = " + (System.currentTimeMillis() - this.$finals.startTime));
try {
(I$[3]||(I$[3]=Clazz.load('Thread'))).sleep$J(1100);
} catch (e1) {
if (Clazz.exceptionOf(e1, InterruptedException)){
e1.printStackTrace();
} else {
throw e1;
}
}
});
})()
), Clazz.new((I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.SwingClock$2'))).$init$, [this, {startTime: startTime}]))]);
timer.setCoalesce$Z(false);
timer.start();
Clazz.new((I$[5]||(I$[5]=Clazz.load('javax.swing.JFrame')))).setVisible$Z(true);
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
