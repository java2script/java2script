(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass$(P$, "MutableVector2D", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector2D');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMethod$(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y);
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y  );
});

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
C$.c$$D$D.apply(this, [v.getX(), v.getY()]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D', function (x, y) {
Clazz.super(C$, this,1);
this.x = x;
this.y = y;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D', function (p) {
C$.c$$D$D.apply(this, [p.getX(), p.getY()]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D$java_awt_geom_Point2D', function (src, dst) {
Clazz.super(C$, this,1);
this.x = dst.getX() - src.getX();
this.y = dst.getY() - src.getY();
}, 1);

Clazz.newMethod$(C$, 'add$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
this.x += v.getX();
this.y += v.getY();
return this;
});

Clazz.newMethod$(C$, 'normalize', function () {
var magnitude = this.magnitude();
if (magnitude == 0 ) {
throw Clazz.new(Clazz.load('java.lang.UnsupportedOperationException').c$$S,["Cannot normalize a zero-magnitude vector."]);
}return this.scale$D(1.0 / magnitude);
});

Clazz.newMethod$(C$, 'scale$D', function (scale) {
this.x *= scale;
this.y *= scale;
return this;
});

Clazz.newMethod$(C$, 'setX$D', function (x) {
this.x = x;
});

Clazz.newMethod$(C$, 'setY$D', function (y) {
this.y = y;
});

Clazz.newMethod$(C$, 'setComponents$D$D', function (x, y) {
this.x = x;
this.y = y;
});

Clazz.newMethod$(C$, 'setValue$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (value) {
this.setComponents$D$D(value.getX(), value.getY());
});

Clazz.newMethod$(C$, 'setMagnitudeAndAngle$D$D', function (magnitude, angle) {
this.setComponents$D$D(Math.cos(angle) * magnitude, Math.sin(angle) * magnitude);
});

Clazz.newMethod$(C$, 'setMagnitude$D', function (magnitude) {
this.setMagnitudeAndAngle$D$D(magnitude, this.getAngle());
});

Clazz.newMethod$(C$, 'setAngle$D', function (angle) {
this.setMagnitudeAndAngle$D$D(this.magnitude(), angle);
});

Clazz.newMethod$(C$, 'subtract$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D', function (v) {
this.x -= v.getX();
this.y -= v.getY();
return this;
});

Clazz.newMethod$(C$, 'rotate$D', function (theta) {
var r = this.magnitude();
var alpha = this.getAngle();
var gamma = alpha + theta;
var xPrime = r * Math.cos(gamma);
var yPrime = r * Math.sin(gamma);
this.setComponents$D$D(xPrime, yPrime);
return this;
});

Clazz.newMethod$(C$, 'negate', function () {
this.setComponents$D$D(-this.getX(), -this.getY());
return this;
});

Clazz.newMethod$(C$, 'getY', function () {
return this.y;
});

Clazz.newMethod$(C$, 'getX', function () {
return this.x;
});

Clazz.newMethod$(C$, 'addXY$D$D', function (x, y) {
this.x += x;
this.y += y;
});

Clazz.newMethod$(C$, 'createPolar$D$D', function (magnitude, angle) {
return (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).createPolar$D$D(magnitude, angle);
}, 1);

Clazz.newMethod$(C$, 'main', function (args) {
var v = Clazz.new(C$.c$$D$D,[0, 0]);
System.out.println$S("v = " + v);
System.out.println$S("v.hashCode() = " + v.hashCode());
var b = Clazz.new(C$.c$$D$D,[1, 2]);
var c = Clazz.new(C$.c$$D$D,[0, 0]);
System.out.println$S("v.equals( b ) = " + v.equals$O(b) + " (should be false)" );
System.out.println$S("v.equals( c ) = " + v.equals$O(c) + " (should be true)" );
}, 1);
})();
//Created 2017-12-07 06:41:03
