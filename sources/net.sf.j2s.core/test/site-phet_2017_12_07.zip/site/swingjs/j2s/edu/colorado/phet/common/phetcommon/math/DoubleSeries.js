(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "DoubleSeries");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.data = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.maxSize = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (maxSize) {
C$.$init$.apply(this);
this.maxSize = maxSize;
}, 1);

Clazz.newMethod$(C$, 'add$D', function (value) {
this.data.add$TE( new Double(value));
if (this.data.size() > this.maxSize) {
this.data.remove$I(0);
}});

Clazz.newMethod$(C$, 'average', function () {
return p$.sum.apply(this, []) / this.getSampleCount();
});

Clazz.newMethod$(C$, 'getSampleCount', function () {
return this.data.size();
});

Clazz.newMethod$(C$, 'sum', function () {
var sum = 0;
for (var i = 0; i < this.data.size(); i++) {
sum += (this.data.get$I(i)).doubleValue();
}
return sum;
});

Clazz.newMethod$(C$, 'clear', function () {
this.data.clear();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
