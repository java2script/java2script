(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model");
var C$=Clazz.newInterface$(P$, "IBucketSphere", function(){
});

;
(function(){var C$=Clazz.newInterface$(P$.IBucketSphere, "Listener", function(){
}, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

})()
;
(function(){var C$=Clazz.newClass$(P$.IBucketSphere, "Adapter", function(){
Clazz.newInstance$(this, arguments[0],false,C$);
}, null, [['edu.colorado.phet.common.phetcommon.model.IBucketSphere','edu.colorado.phet.common.phetcommon.model.IBucketSphere.Listener']]);

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, ['grabbedByUser$TT'], function (particle) {
});

Clazz.newMethod$(C$, ['droppedByUser$TT'], function (particle) {
});

Clazz.newMethod$(C$, ['removedFromModel$TT'], function (particle) {
});

Clazz.newMethod$(C$);
})()
})();
//Created 2017-12-07 06:41:03
