(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.dialogs");
var C$=Clazz.newClass$(P$, "StackTraceDialog", null, 'edu.colorado.phet.common.phetcommon.application.PaintImmediateDialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
