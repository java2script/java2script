(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math.vector"),I$=[];
var C$=Clazz.newClass$(P$, "Vector3F", null, 'edu.colorado.phet.common.phetcommon.math.vector.AbstractVector3F');

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.ZERO = Clazz.new(C$);
C$.X_UNIT = Clazz.new(C$.c$$F$F$F,[1, 0, 0]);
C$.Y_UNIT = Clazz.new(C$.c$$F$F$F,[0, 1, 0]);
C$.Z_UNIT = Clazz.new(C$.c$$F$F$F,[0, 0, 1]);
};

C$.ZERO = null;
C$.X_UNIT = null;
C$.Y_UNIT = null;
C$.Z_UNIT = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMethod$(C$, 'hashCode', function () {
return Float.floatToIntBits(this.x) ^ Float.floatToIntBits(this.y) ^ Float.floatToIntBits(this.z) ;
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "edu.colorado.phet.common.phetcommon.math.vector.Vector3F"))) {
return false;
}var m = o;
return (m.x == this.x  && m.y == this.y   && m.z == this.z  );
});

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$F$F$F.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector2F', function (v) {
Clazz.super(C$, this,1);
this.x = v.x;
this.y = v.y;
this.z = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$F$F$F', function (x, y, z) {
Clazz.super(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D', function (x, y, z) {
Clazz.super(C$, this,1);
this.x = x;
this.y = y;
this.z = z;
}, 1);

Clazz.newMethod$(C$, 'getX', function () {
return this.x;
});

Clazz.newMethod$(C$, 'getY', function () {
return this.y;
});

Clazz.newMethod$(C$, 'getZ', function () {
return this.z;
});

Clazz.newMethod$(C$, 'slerp$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$F', function (start, end, ratio) {
return (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.QuaternionF'))).slerp$edu_colorado_phet_common_phetcommon_math_QuaternionF$edu_colorado_phet_common_phetcommon_math_QuaternionF$F(Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.QuaternionF')))), (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.QuaternionF'))).getRotationQuaternion$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(start, end), ratio).times$edu_colorado_phet_common_phetcommon_math_vector_Vector3F(start);
}, 1);
})();
//Created 2017-12-07 06:41:03
