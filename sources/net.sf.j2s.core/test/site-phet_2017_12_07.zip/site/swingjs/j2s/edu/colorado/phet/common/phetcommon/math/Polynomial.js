(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "Polynomial");

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.ZERO = Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[ Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), -1, [(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).ZERO])]);
};

C$.ZERO = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.terms = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (constant) {
C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA.apply(this, [ Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), -1, [Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).c$$I,[constant])])]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Collection', function (sparseTerms) {
C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA.apply(this, [sparseTerms.toArray$TTA( Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), [sparseTerms.size()]))]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA', function (sparseTerms) {
C$.$init$.apply(this);
if (sparseTerms.length == 0) {
this.terms =  Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), -1, [(I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).ZERO]);
} else {
var min = 2147483647;
var max = -2147483648;
for (var i = 0; i < sparseTerms.length; i++) {
var sparseTerm = sparseTerms[i];
if (sparseTerm.getPower() < min) {
min = sparseTerm.getPower();
}if (sparseTerm.getPower() > max) {
max = sparseTerm.getPower();
}}
var total = max + 1;
this.terms =  Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), [total]);
for (var i = 0; i < this.terms.length; i++) {
this.terms[i] = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).c$$I$I,[i, 0]);
}
for (var i = 0; i < sparseTerms.length; i++) {
var sparseTerm = sparseTerms[i];
var pow = sparseTerm.getPower();
this.terms[pow] = this.terms[pow].plus$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(sparseTerm);
}
}}, 1);

Clazz.newMethod$(C$, 'parsePolynomial$S', function (sparseTerms) {
var polynomialTerms = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
var matcher = (I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).EXPR_PATTERN.matcher$CharSequence(sparseTerms);
while (matcher.find()){
polynomialTerms.add$TE((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))).parsePolynomialTerm$S(matcher.group()));
}
return Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[polynomialTerms.toArray$TTA( Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), [polynomialTerms.size()]))]);
}, 1);

Clazz.newMethod$(C$, 'getTerms', function () {
return this.terms.clone();
});

Clazz.newMethod$(C$, 'eval$D', function (x) {
var sum = 0.0;
for (var i = 0; i < this.terms.length; i++) {
sum += this.terms[i].eval$D(x);
}
return sum;
});

Clazz.newMethod$(C$, 'plus$edu_colorado_phet_common_phetcommon_math_Polynomial', function (that) {
var allTerms = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
allTerms.addAll$java_util_Collection((I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).asList$TTA(this.terms));
allTerms.addAll$java_util_Collection((I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).asList$TTA(that.terms));
return Clazz.new(C$.c$$java_util_Collection,[allTerms]);
});

Clazz.newMethod$(C$, 'derive$I', function (times) {
var p = this;
for (var i = 0; i < times; i++) {
p = p.derive();
}
return p;
});

Clazz.newMethod$(C$, 'derive', function () {
var terms = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
terms.addAll$java_util_Collection((I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).asList$TTA(this.terms));
for (var i = 0; i < terms.size(); i++) {
terms.set$I$TE(i, terms.get$I(i).derive());
}
return Clazz.new(C$.c$$java_util_Collection,[terms]);
});

Clazz.newMethod$(C$, 'times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm', function (term) {
var mulTerms =  Clazz.newArray$((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.PolynomialTerm'))), [this.terms.length]);
for (var i = 0; i < this.terms.length; i++) {
mulTerms[i] = term.times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(this.terms[i]);
}
return Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_PolynomialTermA,[mulTerms]);
});

Clazz.newMethod$(C$, 'times$edu_colorado_phet_common_phetcommon_math_Polynomial', function (that) {
var allTerms = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
for (var i = 0; i < this.terms.length; i++) {
for (var j = 0; j < that.terms.length; j++) {
allTerms.add$TE(this.terms[i].times$edu_colorado_phet_common_phetcommon_math_PolynomialTerm(that.terms[j]));
}
}
return Clazz.new(C$.c$$java_util_Collection,[allTerms]);
});

Clazz.newMethod$(C$, 'pow$I', function (n) {
if (n < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException'));
}var result = Clazz.new(C$.c$$I,[1]);
for (var i = 0; i < n; i++) {
result = result.times$edu_colorado_phet_common_phetcommon_math_Polynomial(this);
}
return result;
});

Clazz.newMethod$(C$, 'toString', function () {
var buffer = Clazz.new((I$[3]||(I$[3]=Clazz.load('java.lang.StringBuffer'))));
for (var i = 0; i < this.terms.length; i++) {
var isFirst = i == 0;
if (!isFirst) {
buffer.append$S(" + ");
}buffer.append$S(this.terms[i].toString());
}
return buffer.toString();
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass() !== o.getClass()  ) {
return false;
}var that = o;
if (!(I$[2]||(I$[2]=Clazz.load('java.util.Arrays'))).equals$OA$OA(this.terms, that.terms)) {
return false;
}return true;
});

Clazz.newMethod$(C$, 'hashCode', function () {
var hashCode = 0;
for (var i = 0; i < this.terms.length; i++) {
hashCode = hashCode+(this.terms[i].hashCode());
}
return hashCode;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
