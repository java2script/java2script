(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "SoftwareAgreement");
var p$=C$.prototype;

C$.instance = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.version = 0;
this.content = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
var p = p$.readProperties.apply(this, []);
this.version = p.getInt$S$I("version", -1);
try {
this.content = p$.readContent.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'readContent', function () {
var inStream = (I$[0]||(I$[0]=Clazz.load('Thread'))).currentThread().getContextClassLoader().getResourceAsStream$S("software-agreement.htm");
var bufferedReader = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.io.BufferedReader'))).c$$java_io_Reader,[Clazz.new((I$[2]||(I$[2]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream,[inStream])]);
var s = "";
var line = bufferedReader.readLine();
while (line != null ){
s += line + "\n";
line = bufferedReader.readLine();
}
return s;
});

Clazz.newMethod$(C$, 'getInstance', function () {
if (C$.instance == null ) {
C$.instance = Clazz.new(C$);
}return C$.instance;
}, 1);

Clazz.newMethod$(C$, 'getVersion', function () {
return this.version;
});

Clazz.newMethod$(C$, 'getContent', function () {
return this.content;
});

Clazz.newMethod$(C$, 'readProperties', function () {
var p = Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetProperties'))));
var inStream = (I$[0]||(I$[0]=Clazz.load('Thread'))).currentThread().getContextClassLoader().getResourceAsStream$S("software-agreement.properties");
if (inStream != null ) {
try {
p.load$java_io_InputStream(inStream);
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
System.err.println$S("exception reading software agreement: software-agreement.properties");
e.printStackTrace();
} else {
throw e;
}
}
} else {
System.err.println$S("missing software agreement: software-agreement.properties");
}return p;
});
})();
//Created 2017-12-07 06:41:01
