(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math");
var C$=Clazz.newClass$(P$, "Ray3F");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.pos = null;
this.dir = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F', function (pos, dir) {
C$.$init$.apply(this);
this.pos = pos;
this.dir = dir.magnitude() == 1  ? dir : dir.normalized();
}, 1);

Clazz.newMethod$(C$, 'shifted$F', function (distance) {
return Clazz.new(C$.c$$edu_colorado_phet_common_phetcommon_math_vector_Vector3F$edu_colorado_phet_common_phetcommon_math_vector_Vector3F,[this.pointAtDistance$F(distance), this.dir]);
});

Clazz.newMethod$(C$, 'pointAtDistance$F', function (distance) {
return this.pos.plus$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(this.dir.times$F(distance));
});

Clazz.newMethod$(C$, 'distanceToPlane$edu_colorado_phet_common_phetcommon_math_PlaneF', function (plane) {
return (plane.distance - this.pos.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(plane.normal)) / this.dir.dot$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector3F(plane.normal);
});

Clazz.newMethod$(C$, 'toString', function () {
return this.pos.toString() + " => " + this.dir.toString() ;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
