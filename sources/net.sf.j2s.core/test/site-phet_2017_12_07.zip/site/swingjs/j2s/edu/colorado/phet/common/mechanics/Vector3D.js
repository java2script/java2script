(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass$(P$, "Vector3D", null, 'edu.colorado.phet.common.mechanics.PhysicalVector');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'createCrossProduct$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (v1, v2) {
var z = v1.magnitude() * v2.magnitude() * Math.sin(v2.getAngle() - v1.getAngle()) ;
return Clazz.new(C$.c$$D$D$D,[0, 0, z]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (vector) {
C$.c$$D$D$D.apply(this, [vector.getX(), vector.getY(), 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_mechanics_Vector3D', function (vector) {
C$.c$$D$D$D.apply(this, [vector.getX(), vector.getY(), vector.getZ()]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D', function (x, y, z) {
C$.superClazz.c$$I.apply(this, [3]);
C$.$init$.apply(this);
this.setX$D(x);
this.setY$D(y);
this.setZ$D(z);
if (Double.isNaN(x)) {
System.out.println$S("Vector2D constructor: x was NaN");
}if (Double.isNaN(y)) {
System.out.println$S("Vector2D constructor: y was NaN");
}}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "[ " + new Double(this.getX()).toString() + " " + new Double(this.getY()).toString() + " " + new Double(this.getZ()).toString() + "]" ;
});

Clazz.newMethod$(C$, 'setComponents$D$D$D', function (x, y, z) {
this.setX$D(x);
this.setY$D(y);
this.setZ$D(z);
return this;
});

Clazz.newMethod$(C$, 'setComponents$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
this.setComponents$D$D$D(that.getX(), that.getY(), that.getZ());
return this;
});

Clazz.newMethod$(C$, 'getX', function () {
return this.getScalarAt$I(0);
});

Clazz.newMethod$(C$, 'setX$D', function (x) {
this.setScalarAt$I$D(0, x);
});

Clazz.newMethod$(C$, 'getY', function () {
return this.getScalarAt$I(1);
});

Clazz.newMethod$(C$, 'setY$D', function (y) {
this.setScalarAt$I$D(1, y);
});

Clazz.newMethod$(C$, 'getZ', function () {
return this.getScalarAt$I(2);
});

Clazz.newMethod$(C$, 'setZ$D', function (z) {
this.setScalarAt$I$D(2, z);
});

Clazz.newMethod$(C$, 'add$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
return C$.superClazz.prototype.add$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [that, this]);
});

Clazz.newMethod$(C$, 'normalize', function () {
return C$.superClazz.prototype.generalNormalize.apply(this, []);
});

Clazz.newMethod$(C$, 'multiply$D', function (scale) {
return C$.superClazz.prototype.multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [scale, this]);
});

Clazz.newMethod$(C$, 'subtract$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
return C$.superClazz.prototype.subtract$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector.apply(this, [that, this]);
});

Clazz.newMethod$(C$, 'subtract$D$D$D', function (x, y, z) {
var temp = Clazz.new(C$.c$$D$D$D,[x, y, z]);
return this.subtract$edu_colorado_phet_common_mechanics_Vector3D(temp);
});

Clazz.newMethod$(C$, 'crossProduct$edu_colorado_phet_common_mechanics_Vector3D', function (that) {
var result = Clazz.new(C$.c$$D$D$D,[this.getY() * that.getZ() - this.getZ() * that.getY(), -this.getX() * that.getZ() + this.getZ() * that.getX(), this.getX() * that.getY() - this.getY() * that.getX()]);
return result;
});
})();
//Created 2017-12-07 06:41:00
