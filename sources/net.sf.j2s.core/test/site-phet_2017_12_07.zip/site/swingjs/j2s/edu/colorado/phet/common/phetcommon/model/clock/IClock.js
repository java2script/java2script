(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock");
var C$=Clazz.newInterface$(P$, "IClock");

})();
//Created 2017-12-07 06:41:03
