(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.event"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractNotifier");


Clazz.newMethod$(C$, '$init$', function () {
this.listeners = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.LinkedList'))));
}, 1);

Clazz.newMethod$(C$, 'addListener$TT', function (listener) {
this.listeners.add$TE(listener);
});

Clazz.newMethod$(C$, 'removeListener$TT', function (listener) {
this.listeners.remove$O(listener);
});

Clazz.newMethod$(C$, 'updateListeners$edu_colorado_phet_common_phetcommon_util_function_VoidFunction1', function (callback) {
for (var listener, $listener = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[this.listeners]).iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
callback.$apply$TT(listener);
}
});

Clazz.newMethod$(C$, 'getListeners', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.LinkedList'))).c$$java_util_Collection,[this.listeners]);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
