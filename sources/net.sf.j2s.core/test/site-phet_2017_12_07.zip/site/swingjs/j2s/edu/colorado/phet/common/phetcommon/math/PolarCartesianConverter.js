(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math");
var C$=Clazz.newClass$(P$, "PolarCartesianConverter");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getX$D$D', function (radius, angle) {
return radius * Math.cos(angle);
}, 1);

Clazz.newMethod$(C$, 'getY$D$D', function (radius, angle) {
return radius * Math.sin(angle);
}, 1);

Clazz.newMethod$(C$, 'getRadius$D$D', function (x, y) {
return Math.sqrt((x * x) + (y * y));
}, 1);

Clazz.newMethod$(C$, 'getAngle$D$D', function (x, y) {
return Math.atan2(y, x);
}, 1);
})();
//Created 2017-12-07 06:41:02
