(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass$(P$, "CompositeProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ObservableProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.$function = null;
this.observer = null;
this.properties = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function ($function, properties) {
C$.superClazz.c$$TT.apply(this, [$function.$apply()]);
C$.$init$.apply(this);
this.$function = $function;
this.properties = properties;
this.observer = ((
(function(){var C$=Clazz.newClass$(P$, "CompositeProperty$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'edu.colorado.phet.common.phetcommon.util.SimpleObserver', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'update', function () {
this.b$['edu.colorado.phet.common.phetcommon.model.property.CompositeProperty'].notifyIfChanged();
});
})()
), Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.CompositeProperty$1'))).$init$, [this, null]));
for (var property, $property = 0, $$property = properties; $property < $$property.length && ((property = $$property[$property]) || true); $property++) {
property.addObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver(this.observer);
}
}, 1);

Clazz.newMethod$(C$, 'cleanup', function () {
for (var property, $property = 0, $$property = this.properties; $property < $$property.length && ((property = $$property[$property]) || true); $property++) {
property.removeObserver$edu_colorado_phet_common_phetcommon_util_SimpleObserver(this.observer);
}
});

Clazz.newMethod$(C$, 'get', function () {
return this.$function.$apply();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
