(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "PhetApplicationConfig", null, null, 'edu.colorado.phet.common.phetcommon.application.ISimInfo');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.DEFAULT_FRAME_SETUP = Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.view.util.FrameSetup').CenteredWithSize))).c$$I$I,[1024, 768]);
};

C$.DEFAULT_FRAME_SETUP = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.commandLineArgs = null;
this.flavor = null;
this.resourceLoader = null;
this.frameSetup = null;
this.phetLookAndFeel = null;
}, 1);

Clazz.newMethod$(C$, 'c$$SA$S', function (commandLineArgs, project) {
C$.c$$SA$S$S.apply(this, [commandLineArgs, project, project]);
}, 1);

Clazz.newMethod$(C$, 'c$$SA$S$S', function (commandLineArgs, project, flavor) {
C$.$init$.apply(this);
this.commandLineArgs = commandLineArgs;
var language = this.getOptionArg$S("--locale");
if (language != null ) C$.setDefaultLocale$S(language);
this.flavor = flavor;
this.resourceLoader = Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetResources'))).c$$S,[project]);
this.frameSetup = C$.DEFAULT_FRAME_SETUP;
this.phetLookAndFeel = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.view.PhetLookAndFeel'))));
}, 1);

Clazz.newMethod$(C$, 'setDefaultLocale$S', function (language) {
var region;
var country;
language = language.$replace('-', '_');
if (language.length$() == 0 || language.equalsIgnoreCase$S("en") ) language = "en_US";
var i = language.indexOf('_');
if (i > 0) {
country = language.substring(0, i);
region = language.substring(i + 1);
} else {
country = language;
region = "";
}region = region.toUpperCase();
(I$[3]||(I$[3]=Clazz.load('java.util.Locale'))).setDefault$java_util_Locale(Clazz.new((I$[3]||(I$[3]=Clazz.load('java.util.Locale'))).c$$S$S,[language, country]));
}, 1);

Clazz.newMethod$(C$, 'getCommandLineArgs', function () {
return this.commandLineArgs;
});

Clazz.newMethod$(C$, 'hasCommandLineArg$S', function (arg) {
return (I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.StringUtil'))).contains$SA$S(this.commandLineArgs, arg);
});

Clazz.newMethod$(C$, 'getOptionArg$S', function (option) {
var s = (I$[5]||(I$[5]=Clazz.load('java.util.Arrays'))).asList$TTA(this.commandLineArgs).indexOf$O(option);
if (s >= 0 && s <= this.commandLineArgs.length - 2  && !this.commandLineArgs[s + 1].startsWith$S("-") ) {
return this.commandLineArgs[s + 1];
} else {
return null;
}});

Clazz.newMethod$(C$, 'setFrameSetup$edu_colorado_phet_common_phetcommon_view_util_FrameSetup', function (frameSetup) {
this.frameSetup = frameSetup;
});

Clazz.newMethod$(C$, 'getFrameSetup', function () {
return this.frameSetup;
});

Clazz.newMethod$(C$, 'getFlavor', function () {
return this.flavor;
});

Clazz.newMethod$(C$, 'setLookAndFeel$edu_colorado_phet_common_phetcommon_view_PhetLookAndFeel', function (phetLookAndFeel) {
this.phetLookAndFeel = phetLookAndFeel;
});

Clazz.newMethod$(C$, 'getLookAndFeel', function () {
return this.phetLookAndFeel;
});

Clazz.newMethod$(C$, 'getResourceLoader', function () {
return this.resourceLoader;
});

Clazz.newMethod$(C$, 'getProjectName', function () {
return this.resourceLoader.getProjectName();
});

Clazz.newMethod$(C$, 'isPreferencesEnabled', function () {
return this.isStatisticsFeatureIncluded() || this.isUpdatesFeatureIncluded() ;
});

Clazz.newMethod$(C$, 'getDistributionTag', function () {
return this.resourceLoader.getDistributionTag();
});

Clazz.newMethod$(C$, 'getName', function () {
return this.resourceLoader.getName$S(this.flavor);
});

Clazz.newMethod$(C$, 'getVersionForTitleBar', function () {
return this.getVersion().formatForTitleBar();
});

Clazz.newMethod$(C$, 'getVersion', function () {
return this.resourceLoader.getVersion();
});

Clazz.newMethod$(C$, 'isDev', function () {
return this.hasCommandLineArg$S("-dev");
});

Clazz.newMethod$(C$, 'getLocale', function () {
return (I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.resources.PhetResources'))).readLocale();
});

Clazz.newMethod$(C$, 'isUpdatesFeatureIncluded', function () {
return false;
});

Clazz.newMethod$(C$, 'isStatisticsFeatureIncluded', function () {
return false;
});

Clazz.newMethod$(C$, 'isUpdatesEnabled', function () {
return false;
});

Clazz.newMethod$(C$, 'isStatisticsEnabled', function () {
return false;
});

Clazz.newMethod$(C$, 'isSponsorFeatureEnabled', function () {
return !this.hasCommandLineArg$S("-sponsor-off");
});

Clazz.newMethod$(C$, 'isAskFeatureEnabled', function () {
return this.hasCommandLineArg$S("-ask");
});

Clazz.newMethod$(C$, 'getProjectJarName$S', function (project) {
return project + "_all.jar";
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
