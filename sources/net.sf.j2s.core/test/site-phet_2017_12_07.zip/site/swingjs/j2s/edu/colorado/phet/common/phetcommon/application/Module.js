(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application"),I$=[];
var C$=Clazz.newClass$(P$, "Module", function(){
Clazz.newInstance$(this, arguments,0,C$);
}, null, 'edu.colorado.phet.common.phetcommon.model.Resettable');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.active = false;
this.clockRunningWhenActive = true;
this.listeners = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.name = null;
this.model = null;
this.clock = null;
this.moduleRunner = null;
this.modulePanel = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock', function (name, clock) {
C$.c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock$Z.apply(this, [name, clock, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$edu_colorado_phet_common_phetcommon_model_clock_IClock$Z', function (name, clock, startsPaused) {
C$.$init$.apply(this);
this.name = name;
this.clock = clock;
this.setModel$edu_colorado_phet_common_phetcommon_model_BaseModel(Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.BaseModel')))));
this.modulePanel = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.view.ModulePanel'))));
this.setClockControlPanel$javax_swing_JComponent(this.createClockControlPanel$edu_colorado_phet_common_phetcommon_model_clock_IClock(clock));
this.setLogoPanel$javax_swing_JComponent(Clazz.new((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.view.LogoPanel')))));
this.setHelpPanel$javax_swing_JComponent(Clazz.new((I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.view.HelpPanel'))).c$$edu_colorado_phet_common_phetcommon_application_Module,[this]));
this.moduleRunner = ((
(function(){var C$=Clazz.newClass$(P$, "Module$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ModuleClockAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
this.b$['edu.colorado.phet.common.phetcommon.application.Module'].handleClockTick$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(clockEvent);
});
})()
), Clazz.new((I$[5]||(I$[5]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ModuleClockAdapter'))), [this, null],P$.Module$1));
clock.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(this.moduleRunner);
this.clockRunningWhenActive = !startsPaused;
this.updateHelpPanelVisible();
}, 1);

Clazz.newMethod$(C$, 'createClockControlPanel$edu_colorado_phet_common_phetcommon_model_clock_IClock', function (clock) {
return Clazz.new((I$[6]||(I$[6]=Clazz.load('edu.colorado.phet.common.phetcommon.view.ClockControlPanel'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[clock]);
});

Clazz.newMethod$(C$, 'getClock', function () {
return this.clock;
});

Clazz.newMethod$(C$, 'handleClockTick$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
this.handleUserInput();
this.model.update$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(event);
this.updateGraphics$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(event);
});

Clazz.newMethod$(C$, 'setClockRunningWhenActive$Z', function (b) {
this.clockRunningWhenActive = b;
if (this.isActive()) {
if (this.clockRunningWhenActive) {
this.clock.start();
} else {
this.clock.pause();
}}});

Clazz.newMethod$(C$, 'getClockRunningWhenActive', function () {
if (this.isActive()) {
this.clockRunningWhenActive = this.clock.isRunning();
}return this.clockRunningWhenActive;
});

Clazz.newMethod$(C$, 'setModel$edu_colorado_phet_common_phetcommon_model_BaseModel', function (model) {
this.model = model;
});

Clazz.newMethod$(C$, 'getModel', function () {
return this.model;
});

Clazz.newMethod$(C$, 'addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (modelElement) {
this.getModel().addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement(modelElement);
});

Clazz.newMethod$(C$, 'getModulePanel', function () {
return this.modulePanel;
});

Clazz.newMethod$(C$, 'setMonitorPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setMonitorPanel$javax_swing_JComponent(panel);
});

Clazz.newMethod$(C$, 'setSimulationPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setSimulationPanel$javax_swing_JComponent(panel);
if (panel != null ) {
var window = (I$[7]||(I$[7]=Clazz.load('javax.swing.SwingUtilities'))).getWindowAncestor$java_awt_Component(panel);
if (window != null ) {
window.invalidate();
window.validate();
window.doLayout();
}}});

Clazz.newMethod$(C$, 'getSimulationPanel', function () {
return this.modulePanel.getSimulationPanel();
});

Clazz.newMethod$(C$, 'setClockControlPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setClockControlPanel$javax_swing_JComponent(panel);
});

Clazz.newMethod$(C$, 'getClockControlPanel', function () {
return this.modulePanel.getClockControlPanel();
});

Clazz.newMethod$(C$, 'setLogoPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setLogoPanel$javax_swing_JComponent(panel);
});

Clazz.newMethod$(C$, 'getLogoPanel', function () {
var logoPanel = null;
var panel = this.modulePanel.getLogoPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.LogoPanel") ) {
logoPanel = panel;
}return logoPanel;
});

Clazz.newMethod$(C$, 'setControlPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setControlPanel$javax_swing_JComponent(panel);
});

Clazz.newMethod$(C$, 'getControlPanel', function () {
var controlPanel = null;
var panel = this.modulePanel.getControlPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.ControlPanel") ) {
controlPanel = panel;
}return controlPanel;
});

Clazz.newMethod$(C$, 'setHelpPanel$javax_swing_JComponent', function (panel) {
this.modulePanel.setHelpPanel$javax_swing_JComponent(panel);
});

Clazz.newMethod$(C$, 'getHelpPanel', function () {
var helpPanel = null;
var panel = this.modulePanel.getHelpPanel();
if (panel != null  && Clazz.instanceOf(panel, "edu.colorado.phet.common.phetcommon.view.HelpPanel") ) {
helpPanel = panel;
}return helpPanel;
});

Clazz.newMethod$(C$, 'hasHelp', function () {
return false;
});

Clazz.newMethod$(C$, 'hasMegaHelp', function () {
return false;
});

Clazz.newMethod$(C$, 'setHelpEnabled$Z', function (enabled) {
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
helpPanel.setHelpEnabled$Z(enabled);
}});

Clazz.newMethod$(C$, 'isHelpEnabled', function () {
var enabled = false;
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
enabled = helpPanel.isHelpEnabled();
}return enabled;
});

Clazz.newMethod$(C$, 'showMegaHelp', function () {
});

Clazz.newMethod$(C$, 'setLogoPanelVisible$Z', function (visible) {
var logoPanel = this.modulePanel.getLogoPanel();
if (logoPanel != null ) {
logoPanel.setVisible$Z(visible);
}});

Clazz.newMethod$(C$, 'isLogoPanelVisible', function () {
var visible = false;
var logoPanel = this.modulePanel.getLogoPanel();
if (logoPanel != null ) {
visible = logoPanel.isVisible();
}return visible;
});

Clazz.newMethod$(C$, 'activate', function () {
if (!this.isWellFormed()) {
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["Module missing important data, module=" + this]);
}if (this.clockRunningWhenActive) {
this.clock.start();
}this.updateHelpPanelVisible();
this.active = true;
for (var i = 0; i < this.listeners.size(); i++) {
(this.listeners.get$I(i)).activated();
}
});

Clazz.newMethod$(C$, 'updateHelpPanelVisible', function () {
var helpPanel = this.getHelpPanel();
if (helpPanel != null ) {
helpPanel.setVisible$Z(this.hasHelp());
}});

Clazz.newMethod$(C$, 'addListener$edu_colorado_phet_common_phetcommon_application_Module_Listener', function (listener) {
this.listeners.add$TE(listener);
});

Clazz.newMethod$(C$, 'removeListener$edu_colorado_phet_common_phetcommon_application_Module_Listener', function (listener) {
this.listeners.remove$O(listener);
});

Clazz.newMethod$(C$, 'addRepaintOnActivateBehavior', function () {
this.addListener$edu_colorado_phet_common_phetcommon_application_Module_Listener(((
(function(){var C$=Clazz.newClass$(P$, "Module$2", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, [['edu.colorado.phet.common.phetcommon.application.Module','edu.colorado.phet.common.phetcommon.application.Module.Listener']], 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'activated', function () {
this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().paintImmediately$I$I$I$I(0, 0, this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().getWidth(), this.b$['edu.colorado.phet.common.phetcommon.application.Module'].getModulePanel().getHeight());
});

Clazz.newMethod$(C$, 'deactivated', function () {
});
})()
), Clazz.new((I$[8]||(I$[8]=Clazz.load('edu.colorado.phet.common.phetcommon.application.Module$2'))).$init$, [this, null])));
});

Clazz.newMethod$(C$, 'getTabUserComponent', function () {
return (I$[9]||(I$[9]=Clazz.load('edu.colorado.phet.common.phetcommon.simsharing.messages.UserComponents'))).tab;
});

Clazz.newMethod$(C$, 'deactivate', function () {
this.clockRunningWhenActive = this.getClock().isRunning();
this.clock.pause();
this.active = false;
for (var i = 0; i < this.listeners.size(); i++) {
(this.listeners.get$I(i)).deactivated();
}
});

Clazz.newMethod$(C$, 'isActive', function () {
return this.active;
});

Clazz.newMethod$(C$, 'isWellFormed', function () {
var result = true;
result = (result&& (this.getModel() != null ));
result = (result&& (this.getSimulationPanel() != null ));
return result;
});

Clazz.newMethod$(C$, 'setName$S', function (name) {
this.name = name;
});

Clazz.newMethod$(C$, 'getName', function () {
return this.name;
});

Clazz.newMethod$(C$, 'toString', function () {
return "name=" + this.name + ", model=" + this.model + ", simulationPanel=" + this.getSimulationPanel() ;
});

Clazz.newMethod$(C$, 'setReferenceSize', function () {
});

Clazz.newMethod$(C$, 'handleUserInput', function () {
});

Clazz.newMethod$(C$, 'updateGraphics$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
});

Clazz.newMethod$(C$, 'setControlPanelBackground$java_awt_Color', function (color) {
if (this.getControlPanel() != null ) {
var excludedClasses =  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass((I$[10]||(I$[10]=Clazz.load('javax.swing.text.JTextComponent'))))]);
this.setControlPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMethod$(C$, 'setControlPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getControlPanel() != null ) {
(I$[11]||(I$[11]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.SwingUtils'))).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getControlPanel(), color, excludedClasses, false);
}});

Clazz.newMethod$(C$, 'setClockControlPanelBackground$java_awt_Color', function (color) {
if (this.getClockControlPanel() != null ) {
var excludedClasses =  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass((I$[10]||(I$[10]=Clazz.load('javax.swing.text.JTextComponent'))))]);
this.setClockControlPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMethod$(C$, 'setClockControlPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getClockControlPanel() != null ) {
(I$[11]||(I$[11]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.SwingUtils'))).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getClockControlPanel(), color, excludedClasses, false);
}});

Clazz.newMethod$(C$, 'setHelpPanelBackground$java_awt_Color', function (color) {
if (this.getHelpPanel() != null ) {
var excludedClasses =  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass((I$[10]||(I$[10]=Clazz.load('javax.swing.text.JTextComponent'))))]);
this.setHelpPanelBackground$java_awt_Color$ClassA(color, excludedClasses);
}});

Clazz.newMethod$(C$, 'setHelpPanelBackground$java_awt_Color$ClassA', function (color, excludedClasses) {
if (this.getHelpPanel() != null ) {
(I$[11]||(I$[11]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.SwingUtils'))).setBackgroundDeep$java_awt_Component$java_awt_Color$ClassA$Z(this.getHelpPanel(), color, excludedClasses, false);
}});

Clazz.newMethod$(C$, 'reset', function () {
});
;
(function(){var C$=Clazz.newInterface$(P$.Module, "Listener", function(){
}, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
