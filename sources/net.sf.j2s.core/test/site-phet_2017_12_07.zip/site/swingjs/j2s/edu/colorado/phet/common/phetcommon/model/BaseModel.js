(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model"),I$=[];
var C$=Clazz.newClass$(P$, "BaseModel");


Clazz.newMethod$(C$, '$init$', function () {
this.commandList = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.CommandQueue'))));
this.modelElements = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.nElements = 0;
}, 1);

Clazz.newMethod$(C$, 'addModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (aps) {
this.addModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement(aps);
});

Clazz.newMethod$(C$, 'addModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement', function (aps) {
this.modelElements.add$TE(aps);
this.nElements++;
});

Clazz.newMethod$(C$, 'modelElementAt$I', function (i) {
return this.modelElements.get$I(i);
});

Clazz.newMethod$(C$, 'containsModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (modelElement) {
return this.modelElements.contains$O(modelElement);
});

Clazz.newMethod$(C$, 'numModelElements', function () {
return this.nElements;
});

Clazz.newMethod$(C$, 'removeModelElement$edu_colorado_phet_common_phetcommon_model_ModelElement', function (m) {
this.removeModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement(m);
});

Clazz.newMethod$(C$, 'removeModelElementBM$edu_colorado_phet_common_phetcommon_model_ModelElement', function (m) {
this.modelElements.remove$O(m);
this.nElements--;
});

Clazz.newMethod$(C$, 'removeAllModelElements', function () {
this.modelElements.clear();
this.nElements = 0;
});

Clazz.newMethod$(C$, 'execute$edu_colorado_phet_common_phetcommon_model_Command', function (cmd) {
this.commandList.addCommand$edu_colorado_phet_common_phetcommon_model_Command(cmd);
});

Clazz.newMethod$(C$, 'update$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (event) {
this.commandList.doIt();
this.stepInTime$D(event.getSimulationTimeChange());
});

Clazz.newMethod$(C$, 'stepInTime$D', function (dt) {
for (var i = 0; i < this.nElements; i++) {
this.modelElements.get$I(i).stepInTime$D(dt);
}
});

Clazz.newMethod$(C$, 'selectForAny$ClassA', function (modelElementClasses) {
var elements = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))));
for (var i = 0, nClasses = modelElementClasses.length; i < this.nElements; i++) {
for (var j = 0; j < nClasses; j++) {
var c = modelElementClasses[j];
var element = this.modelElements.get$I(i);
if (c.isAssignableFrom$Class(element.getClass())) {
elements.add$TE(element);
}}
}
return elements;
});

Clazz.newMethod$(C$, 'selectFor$Class', function (modelElementClass) {
var elements = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[this.modelElements.size()]);
C$.selectFor$java_util_List$Class$java_util_List(this.modelElements, modelElementClass, elements);
return elements;
});

Clazz.newMethod$(C$, 'selectFor$ClassA', function (classes) {
var elements = Clazz.new((I$[1]||(I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[this.modelElements.size()]);
for (var i = 0; i < classes.length; i++) {
var c = classes[i];
C$.selectFor$java_util_List$Class$java_util_List(this.modelElements, c, elements);
}
return elements;
});

Clazz.newMethod$(C$, 'selectFor$java_util_List$Class$java_util_List', function (modelElements, modelElementClass, elements) {
for (var i = modelElements.size(); --i >= 0; ) {
var element = modelElements.get$I(i);
if (modelElementClass.isAssignableFrom$Class(element.getClass())) {
elements.add$TE(element);
}}
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:03
