(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "MedianFilter");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.source = null;
this.target = null;
}, 1);

Clazz.newMethod$(C$, 'c$$DA', function (data) {
C$.$init$.apply(this);
this.source = data;
this.target =  Clazz.newArray$(Double.TYPE, [this.source.length]);
}, 1);

Clazz.newMethod$(C$, 'getMedian$DA', function (data) {
var workingData =  Clazz.newArray$(Double.TYPE, [data.length]);
for (var i = 0; i < data.length; i++) {
workingData[i] = data[i];
}
return C$.getMedianInternal$DA(workingData);
}, 1);

Clazz.newMethod$(C$, 'getMedianInternal$DA', function (data) {
(I$[0]||(I$[0]=Clazz.load('java.util.Arrays'))).sort$DA(data);
return data[(data.length/2|0)];
}, 1);

Clazz.newMethod$(C$, 'filter$I', function (width) {
var temp =  Clazz.newArray$(Double.TYPE, [width]);
for (var i = 0; i < this.source.length - width + 1; i++) {
for (var k = 0; k < width; k++) {
temp[k] = this.source[i + k];
}
this.target[i + (width/2|0)] = C$.getMedianInternal$DA(temp);
}
for (var i = 0; i < (width/2|0); i++) {
this.target[i] = this.target[(width/2|0)];
}
for (var i = this.target.length - (width/2|0); i < this.target.length; i++) {
this.target[i] = this.target[this.target.length - (width/2|0) - 1];
}
for (var i = 0; i < this.source.length; i++) {
this.source[i] = this.target[i];
}
return this.source;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
