(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property"),I$=[];
var C$=Clazz.newClass$(P$, "BooleanProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.Property');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$Boolean', function (value) {
C$.superClazz.c$$TT.apply(this, [value]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'and$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.And'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMethod$(C$, 'or$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (p) {
return Clazz.new((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.Or'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[[this, p]]);
});

Clazz.newMethod$(C$, 'toggle', function () {
this.set$TT(new Boolean(!(this.get()).booleanValue()));
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
