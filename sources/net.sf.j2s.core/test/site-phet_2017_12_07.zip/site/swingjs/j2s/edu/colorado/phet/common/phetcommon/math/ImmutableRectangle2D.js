(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "ImmutableRectangle2D");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.width = 0;
this.height = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$D$D', function (width, height) {
C$.c$$D$D$D$D.apply(this, [0, 0, width, height]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D$D', function (x, y, width, height) {
C$.$init$.apply(this);
this.x = x;
this.y = y;
this.width = width;
this.height = height;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Shape', function (shape) {
C$.$init$.apply(this);
var r = shape.getBounds2D();
this.x = r.getX();
this.y = r.getY();
this.width = r.getWidth();
this.height = r.getHeight();
}, 1);

Clazz.newMethod$(C$, 'getCenter', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.Vector2D'))).c$$D$D,[this.x + this.width / 2, this.y + this.height / 2]);
});

Clazz.newMethod$(C$, 'contains$java_awt_geom_Point2D', function (point2D) {
return (I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.RectangleUtils'))).containsR4XY$D$D$D$D$D$D(this.x, this.y, this.width, this.height, point2D.getX(), point2D.getY());
});

Clazz.newMethod$(C$, 'contains$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (position) {
return (I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.RectangleUtils'))).containsR4XY$D$D$D$D$D$D(this.x, this.y, this.width, this.height, position.getX(), position.getY());
});

Clazz.newMethod$(C$, 'contains$java_awt_geom_Rectangle2D', function (rectangle) {
return (I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.view.util.RectangleUtils'))).containsRect$D$D$D$D$D$D$D$D(this.x, this.y, this.width, this.height, rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight());
});

Clazz.newMethod$(C$, 'toString', function () {
return "x=" + new Double(this.x).toString() + ", y=" + new Double(this.y).toString() + ", width = " + new Double(this.width).toString() + ", height = " + new Double(this.height).toString() ;
});

Clazz.newMethod$(C$, 'toShape', function () {
return Clazz.new((I$[2]||(I$[2]=Clazz.load(Clazz.load('java.awt.geom.Rectangle2D').Double))).c$$D$D$D$D,[this.x, this.y, this.width, this.height]);
});

Clazz.newMethod$(C$, 'getClosestPoint$java_awt_geom_Point2D', function (point) {
var newPoint = Clazz.new((I$[3]||(I$[3]=Clazz.load(Clazz.load('java.awt.geom.Point2D').Double))).c$$D$D,[point.getX(), point.getY()]);
if (newPoint.getX() < this.x ) {
newPoint.x = this.x;
}if (newPoint.getX() > this.x + this.width ) {
newPoint.x = this.x + this.width;
}if (newPoint.getY() < this.y ) {
newPoint.y = this.y;
}if (newPoint.getY() > this.y + this.height ) {
newPoint.y = this.y + this.height;
}return newPoint;
});

Clazz.newMethod$(C$, 'toRectangle2D', function () {
return Clazz.new((I$[2]||(I$[2]=Clazz.load(Clazz.load('java.awt.geom.Rectangle2D').Double))).c$$D$D$D$D,[this.x, this.y, this.width, this.height]);
});

Clazz.newMethod$(C$, 'getMaxX', function () {
return this.x + this.width;
});

Clazz.newMethod$(C$, 'getMaxY', function () {
return this.y + this.height;
});

Clazz.newMethod$(C$, 'shrink$D', function (delta) {
return Clazz.new(C$.c$$D$D$D$D,[this.x + delta / 2, this.y + delta / 2, this.width - delta, this.height - delta]);
});

Clazz.newMethod$(C$, 'union$edu_colorado_phet_common_phetcommon_math_ImmutableRectangle2D', function (immutableRectangle2D1) {
return Clazz.new(C$.c$$java_awt_Shape,[this.toRectangle2D().createUnion$java_awt_geom_Rectangle2D(immutableRectangle2D1.toRectangle2D())]);
});

Clazz.newMethod$(C$, 'toRoundedRectangle$D$D', function (arcW, arcH) {
return Clazz.new((I$[4]||(I$[4]=Clazz.load(Clazz.load('java.awt.geom.RoundRectangle2D').Double))).c$$D$D$D$D$D$D,[this.x, this.y, this.width, this.height, arcW, arcH]);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:01
