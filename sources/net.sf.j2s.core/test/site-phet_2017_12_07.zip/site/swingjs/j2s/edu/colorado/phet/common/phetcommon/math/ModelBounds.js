(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "ModelBounds", null, 'edu.colorado.phet.common.phetcommon.model.property.Property');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$TT.apply(this, [Clazz.new((I$[0]||(I$[0]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.util.Option').None))))]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getClosestPoint$java_awt_geom_Point2D', function (point) {
if (this.get().isNone()) {
return point;
} else {
return this.get().get().getClosestPoint$java_awt_geom_Point2D(point);
}});

Clazz.newMethod$(C$, 'contains$edu_colorado_phet_common_phetcommon_math_vector_Vector2D', function (value) {
if (this.get().isNone()) {
return true;
} else {
return this.get().get().contains$java_awt_geom_Point2D(value.toPoint2D());
}});
})();
//Created 2017-12-07 06:41:02
