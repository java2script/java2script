(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property");
var C$=Clazz.newClass$(P$, "ConstrainedDoubleProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.ConstrainedProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.min = 0;
this.max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D', function (min, max, value) {
C$.superClazz.c$$TT.apply(this, [new Double(value)]);
C$.$init$.apply(this);
this.min = min;
this.max = max;
if (!this.isValid$Double(new Double(value))) {
this.handleInvalidValue$TT(new Double(value));
}}, 1);

Clazz.newMethod$(C$, ['isValid$Double','isValid$TT'], function (value) {
return ((value).doubleValue() >= this.min  && (value).doubleValue() <= this.max  );
});

Clazz.newMethod$(C$, 'getMin', function () {
return this.min;
});

Clazz.newMethod$(C$, 'getMax', function () {
return this.max;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
