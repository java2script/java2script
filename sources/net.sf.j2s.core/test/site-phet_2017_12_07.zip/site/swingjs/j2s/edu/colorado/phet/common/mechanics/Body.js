(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass$(P$, "Body", null, 'edu.colorado.phet.common.phetcommon.model.Particle');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.lastColidedBody = null;
this.momentum = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.theta = 0;
this.omega = 0;
this.alpha = 0;
this.prevAlpha = 0;
this.mass = 0;
this.container = null;
this.vtemp = null;
}, 1);

Clazz.newMethod$(C$, 'clone', function () {
var clone = C$.superClazz.prototype.clone.apply(this, []);
clone.lastColidedBody = this.lastColidedBody == null  ? null : this.lastColidedBody.clone();
clone.momentum = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))).c$$edu_colorado_phet_common_phetcommon_math_vector_AbstractVector2D,[this.momentum]);
return clone;
});

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.type = 1;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$D$D', function (location, velocity, acceleration, mass, charge) {
C$.superClazz.c$$java_awt_geom_Point2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D.apply(this, [location, velocity, acceleration]);
C$.$init$.apply(this);
this.type = 1;
this.setMass$D(mass);
}, 1);

Clazz.newMethod$(C$, 'getKineticEnergy', function () {
return (this.getMass() * this.getVelocity().magnitudeSquared() / 2) + (this.omega == 0  ? 0 : this.getMomentOfInertia() * this.omega * this.omega  / 2);
});

Clazz.newMethod$(C$, 'stepInTime$D', function (dt) {
this.stepInTimeB$D(dt);
});

Clazz.newMethod$(C$, 'stepInTimeB$D', function (dt) {
this.theta = this.theta + dt * this.omega + dt * dt * this.alpha  / 2;
this.omega = this.omega + dt * (this.alpha + this.prevAlpha) / 2;
this.prevAlpha = this.alpha;
this.stepInTimeP$D(dt);
this.momentum.setComponents$D$D(this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass());
});

Clazz.newMethod$(C$, 'getSpeed', function () {
return this.getVelocity().magnitude();
});

Clazz.newMethod$(C$, 'getTheta', function () {
return this.theta;
});

Clazz.newMethod$(C$, 'setTheta$D', function (theta) {
this.theta = theta;
});

Clazz.newMethod$(C$, 'getOmega', function () {
return this.omega;
});

Clazz.newMethod$(C$, 'setOmega$D', function (omega) {
this.omega = omega;
});

Clazz.newMethod$(C$, 'getAlpha', function () {
return this.alpha;
});

Clazz.newMethod$(C$, 'setAlpha$D', function (alpha) {
this.alpha = alpha;
});

Clazz.newMethod$(C$, 'getMass', function () {
return this.mass;
});

Clazz.newMethod$(C$, 'setMass$D', function (mass) {
this.mass = mass;
});

Clazz.newMethod$(C$, 'getMomentum', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))).c$$D$D,[this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass()]);
});

Clazz.newMethod$(C$, 'getMomentumNoCopy', function () {
if (this.vtemp == null ) this.vtemp = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.math.vector.MutableVector2D'))));
this.vtemp.setComponents$D$D(this.getVelocity().getX() * this.getMass(), this.getVelocity().getY() * this.getMass());
return this.vtemp;
});

Clazz.newMethod$(C$, 'setMomentum$edu_colorado_phet_common_phetcommon_math_vector_MutableVector2D', function (momentum) {
this.setVelocityNoObs$D$D(momentum.getX() / this.getMass(), momentum.getY() / this.getMass());
});

Clazz.newMethod$(C$, 'getLastColidedBody', function () {
return this.lastColidedBody;
});

Clazz.newMethod$(C$, 'setLastColidedBody$edu_colorado_phet_common_phetcommon_model_Particle', function (lastColidedBody) {
this.lastColidedBody = lastColidedBody;
});
})();
//Created 2017-12-07 06:41:00
