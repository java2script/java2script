(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.application");
var C$=Clazz.newClass$(P$, "ModuleEvent");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.phetApplication = null;
this.module = null;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_application_PhetApplication$edu_colorado_phet_common_phetcommon_application_Module', function (phetApplication, module) {
C$.$init$.apply(this);
this.phetApplication = phetApplication;
this.module = module;
}, 1);

Clazz.newMethod$(C$, 'getModule', function () {
return this.module;
});

Clazz.newMethod$(C$, 'getPhetApplication', function () {
return this.phetApplication;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
