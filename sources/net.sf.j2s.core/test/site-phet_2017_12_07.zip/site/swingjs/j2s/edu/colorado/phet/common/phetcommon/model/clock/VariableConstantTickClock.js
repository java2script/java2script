(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.clock"),I$=[];
var C$=Clazz.newClass$(P$, "VariableConstantTickClock", null, null, ['edu.colorado.phet.common.phetcommon.model.clock.IClock', 'edu.colorado.phet.common.phetcommon.model.clock.ClockListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
this.clockEventChannel = Clazz.new((I$[0]||(I$[0]=Clazz.load('edu.colorado.phet.common.phetcommon.util.EventChannel'))).c$$Class,[Clazz.getClass((I$[1]||(I$[1]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockListener'))),['clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent','simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent'])]);
this.clockListenerProxy = this.clockEventChannel.getListenerProxy();
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.wrappedClock = null;
this.dt = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_model_clock_IClock$D', function (clock, dt) {
C$.$init$.apply(this);
this.wrappedClock = clock;
this.wrappedClock.addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(this);
this.dt = dt;
}, 1);

Clazz.newMethod$(C$, 'setDt$D', function (dt) {
this.dt = dt;
});

Clazz.newMethod$(C$, 'clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockTicked$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMethod$(C$, 'clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockStarted$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMethod$(C$, 'clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.clockPaused$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMethod$(C$, 'simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.simulationTimeChanged$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMethod$(C$, 'simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent', function (clockEvent) {
var proxyEvent = Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.clock.ClockEvent'))).c$$edu_colorado_phet_common_phetcommon_model_clock_IClock,[this]);
this.clockListenerProxy.simulationTimeReset$edu_colorado_phet_common_phetcommon_model_clock_ClockEvent(proxyEvent);
});

Clazz.newMethod$(C$, 'getSimulationTimeChange', function () {
return this.dt;
});

Clazz.newMethod$(C$, 'addClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.clockEventChannel.addListener$java_util_EventListener(clockListener);
});

Clazz.newMethod$(C$, 'removeClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
this.clockEventChannel.removeListener$java_util_EventListener(clockListener);
});

Clazz.newMethod$(C$, 'start', function () {
this.wrappedClock.start();
});

Clazz.newMethod$(C$, 'pause', function () {
this.wrappedClock.pause();
});

Clazz.newMethod$(C$, 'isPaused', function () {
return this.wrappedClock.isPaused();
});

Clazz.newMethod$(C$, 'isRunning', function () {
return this.wrappedClock.isRunning();
});

Clazz.newMethod$(C$, 'resetSimulationTime', function () {
this.wrappedClock.resetSimulationTime();
});

Clazz.newMethod$(C$, 'getWallTime', function () {
return this.wrappedClock.getWallTime();
});

Clazz.newMethod$(C$, 'getWallTimeChange', function () {
return this.wrappedClock.getWallTimeChange();
});

Clazz.newMethod$(C$, 'getSimulationTime', function () {
return this.wrappedClock.getSimulationTime();
});

Clazz.newMethod$(C$, 'setSimulationTime$D', function (simulationTime) {
this.wrappedClock.setSimulationTime$D(simulationTime);
});

Clazz.newMethod$(C$, 'stepClockWhilePaused', function () {
this.wrappedClock.stepClockWhilePaused();
});

Clazz.newMethod$(C$, 'stepClockBackWhilePaused', function () {
this.wrappedClock.stepClockBackWhilePaused();
});

Clazz.newMethod$(C$, 'containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener', function (clockListener) {
return this.wrappedClock.containsClockListener$edu_colorado_phet_common_phetcommon_model_clock_ClockListener(clockListener);
});

Clazz.newMethod$(C$, 'removeAllClockListeners', function () {
this.clockEventChannel.removeAllListeners();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:04
