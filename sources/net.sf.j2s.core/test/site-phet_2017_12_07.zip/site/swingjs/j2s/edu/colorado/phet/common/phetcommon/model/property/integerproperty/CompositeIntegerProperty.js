(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.model.property.integerproperty"),I$=[];
var C$=Clazz.newClass$(P$, "CompositeIntegerProperty", null, 'edu.colorado.phet.common.phetcommon.model.property.CompositeProperty');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function ($function, properties) {
C$.superClazz.c$$edu_colorado_phet_common_phetcommon_util_function_Function0$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA.apply(this, [$function, properties]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'plus$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA', function (b) {
var all = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
all.add$TE(this);
all.addAll$java_util_Collection((I$[1]||(I$[1]=Clazz.load('java.util.Arrays'))).asList$TTA(b));
return Clazz.new((I$[2]||(I$[2]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.Plus'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservablePropertyA,[all.toArray$TTA( Clazz.newArray$((I$[3]||(I$[3]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.ObservableProperty'))), [0]))]);
});

Clazz.newMethod$(C$, 'dividedBy$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty', function (volume) {
return Clazz.new((I$[4]||(I$[4]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.DividedBy'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, volume]);
});

Clazz.newMethod$(C$, 'greaterThan$I', function (value) {
return Clazz.new((I$[5]||(I$[5]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.GreaterThan'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, value]);
});

Clazz.newMethod$(C$, 'times$I', function (b) {
return Clazz.new((I$[6]||(I$[6]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.Times'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, Clazz.new((I$[7]||(I$[7]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.Property'))).c$$TT,[new Integer(b)])]);
});

Clazz.newMethod$(C$, 'greaterThanOrEqualTo$I', function (b) {
return Clazz.new((I$[8]||(I$[8]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.GreaterThanOrEqualTo'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, b]);
});

Clazz.newMethod$(C$, 'lessThan$I', function (b) {
return Clazz.new((I$[9]||(I$[9]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.LessThan'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$I,[this, b]);
});

Clazz.newMethod$(C$, 'max$edu_colorado_phet_common_phetcommon_model_property_integerproperty_CompositeIntegerProperty', function (b) {
return Clazz.new((I$[10]||(I$[10]=Clazz.load('edu.colorado.phet.common.phetcommon.model.property.integerproperty.Max'))).c$$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty$edu_colorado_phet_common_phetcommon_model_property_ObservableProperty,[this, b]);
});
})();
//Created 2017-12-07 06:41:04
