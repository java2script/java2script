(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.phetcommon.math"),I$=[];
var C$=Clazz.newClass$(P$, "ModelViewTransform1D", function(){
Clazz.newInstance$(this, arguments,0,C$);
});


Clazz.newMethod$(C$, '$init$', function () {
this.transformListeners = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.$modelToView = null;
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$I$I', function (minModel, maxModel, minView, maxView) {
C$.$init$.apply(this);
this.$modelToView = Clazz.new((I$[1]||(I$[1]=Clazz.load(Clazz.load('edu.colorado.phet.common.phetcommon.math.Function').LinearFunction))).c$$D$D$D$D,[minModel, maxModel, minView, maxView]);
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return this.$modelToView.toString();
});

Clazz.newMethod$(C$, 'c$$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D', function (m) {
C$.c$$D$D$I$I.apply(this, [m.getMinModel(), m.getMaxModel(), m.getMinView(), m.getMaxView()]);
}, 1);

Clazz.newMethod$(C$, 'setTransform$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D', function (m) {
this.$modelToView.setInput$D$D(m.getMinModel(), m.getMaxModel());
this.$modelToView.setOutput$D$D(m.getMinView(), m.getMaxView());
});

Clazz.newMethod$(C$, 'getMinModel', function () {
return this.$modelToView.getMinInput();
});

Clazz.newMethod$(C$, 'getMaxModel', function () {
return this.$modelToView.getMaxInput();
});

Clazz.newMethod$(C$, 'getMinView', function () {
return (this.$modelToView.getMinOutput()|0);
});

Clazz.newMethod$(C$, 'getMaxView', function () {
return (this.$modelToView.getMaxOutput()|0);
});

Clazz.newMethod$(C$, 'modelToView$D', function (x) {
return (this.$modelToView.evaluate$D(x)|0);
});

Clazz.newMethod$(C$, 'modelToViewDifferential$D', function (dModel) {
return this.modelToView$D(dModel) - this.modelToView$D(0);
});

Clazz.newMethod$(C$, 'viewToModelDifferential$I', function (dView) {
return this.viewToModel$I(dView) - this.viewToModel$I(0);
});

Clazz.newMethod$(C$, 'viewToModel$I', function (x) {
return this.$modelToView.createInverse().evaluate$D(x);
});

Clazz.newMethod$(C$, 'addListener$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D_Observer', function (observer) {
this.transformListeners.add$TE(observer);
});

Clazz.newMethod$(C$, 'update', function () {
for (var i = 0; i < this.transformListeners.size(); i++) {
var observer = this.transformListeners.get$I(i);
observer.transformChanged$edu_colorado_phet_common_phetcommon_math_ModelViewTransform1D(this);
}
});

Clazz.newMethod$(C$, 'setModelRange$D$D', function (minModel, maxModel) {
if (this.$modelToView.getMinInput() != minModel  || this.$modelToView.getMinInput() != maxModel  ) {
this.$modelToView.setInput$D$D(minModel, maxModel);
this.update();
}});

Clazz.newMethod$(C$, 'setViewRange$I$I', function (minView, maxView) {
if (this.$modelToView.getMinOutput() != minView  && this.$modelToView.getMaxOutput() != maxView  ) {
this.$modelToView.setOutput$D$D(minView, maxView);
this.update();
}});
;
(function(){var C$=Clazz.newInterface$(P$.ModelViewTransform1D, "Observer", function(){
});

})()

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:02
