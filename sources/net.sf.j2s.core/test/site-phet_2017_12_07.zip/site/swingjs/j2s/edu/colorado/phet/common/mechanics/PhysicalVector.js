(function(){var P$=Clazz.newPackage$("edu.colorado.phet.common.mechanics"),I$=[];
var C$=Clazz.newClass$(P$, "PhysicalVector");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.scalars = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (numDimensions) {
C$.$init$.apply(this);
this.scalars =  Clazz.newArray$(Double.TYPE, [numDimensions]);
}, 1);

Clazz.newMethod$(C$, 'getScalarAt$I', function (idx) {
return this.scalars[idx];
});

Clazz.newMethod$(C$, 'setScalarAt$I$D', function (idx, value) {
this.scalars[idx] = value;
});

Clazz.newMethod$(C$, 'equals$O', function (obj) {
var result = true;
if (this.getClass() !== obj.getClass() ) {
result = false;
} else {
var that = obj;
for (var i = 0; result == true  && i < this.scalars.length ; i++) {
if (this.scalars[i] != that.scalars[i] ) {
result = false;
}}
}return result;
});

Clazz.newMethod$(C$, 'getMagnitudeSq', function () {
var sum = 0;
for (var i = 0; i < this.scalars.length; i++) {
sum += this.scalars[i] * this.scalars[i];
}
return sum;
});

Clazz.newMethod$(C$, 'getMagnitude', function () {
return Math.sqrt(this.getMagnitudeSq());
});

Clazz.newMethod$(C$, 'getLength', function () {
return this.getMagnitude();
});

Clazz.newMethod$(C$, 'add$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector', function (that, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] + that.scalars[i];
}
return result;
});

Clazz.newMethod$(C$, 'generalNormalize', function () {
var length = this.getMagnitude();
return this.multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector(1.0 / length, this);
});

Clazz.newMethod$(C$, 'multiply$D$edu_colorado_phet_common_mechanics_PhysicalVector', function (scale, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] * scale;
}
return result;
});

Clazz.newMethod$(C$, 'dot$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
var result = 0;
for (var i = 0; i < this.scalars.length; i++) {
result += this.scalars[i] * that.scalars[i];
}
return result;
});

Clazz.newMethod$(C$, 'distance$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
return Math.sqrt(this.distanceSquared$edu_colorado_phet_common_mechanics_PhysicalVector(that));
});

Clazz.newMethod$(C$, 'distanceSquared$edu_colorado_phet_common_mechanics_PhysicalVector', function (that) {
if (this.scalars.length != that.scalars.length) {
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["Vectors of different dimensionalities set to PhysicalVector.distanceSquared"]);
}var result = 0;
for (var i = 0; i < this.scalars.length; i++) {
var diff = this.scalars[i] - that.scalars[i];
result += diff * diff;
}
return result;
});

Clazz.newMethod$(C$, 'subtract$edu_colorado_phet_common_mechanics_PhysicalVector$edu_colorado_phet_common_mechanics_PhysicalVector', function (that, result) {
for (var i = 0; i < this.scalars.length; i++) {
result.scalars[i] = this.scalars[i] - that.scalars[i];
}
return result;
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:41:00
