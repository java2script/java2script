(function(){var C$=Clazz.newClass$(null, "assets");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-05 20:07:26
