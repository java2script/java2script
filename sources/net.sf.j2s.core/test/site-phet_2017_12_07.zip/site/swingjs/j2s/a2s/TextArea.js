(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "TextArea", null, 'javax.swing.JScrollPane');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.ta = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (rows, cols) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setViewportView$java_awt_Component(this.ta = Clazz.new((I$[0]||(I$[0]=Clazz.load('javax.swing.JTextArea'))).c$$I$I,[rows, cols]));
this.awtDefaults();
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setViewportView$java_awt_Component(this.ta = Clazz.new((I$[0]||(I$[0]=Clazz.load('javax.swing.JTextArea')))));
this.awtDefaults();
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setViewportView$java_awt_Component(this.ta = Clazz.new((I$[0]||(I$[0]=Clazz.load('javax.swing.JTextArea'))).c$$S$I$I,[text, 0, 9]));
this.awtDefaults();
}, 1);

Clazz.newMethod$(C$, 'c$$S$I$I', function (text, rows, cols) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setViewportView$java_awt_Component(this.ta = Clazz.new((I$[0]||(I$[0]=Clazz.load('javax.swing.JTextArea'))).c$$S$I$I,[text, rows, cols]));
this.awtDefaults();
}, 1);

Clazz.newMethod$(C$, 'awtDefaults', function () {
});

Clazz.newMethod$(C$, 'getText', function () {
return this.ta.getText();
});

Clazz.newMethod$(C$, 'setEditable$Z', function (b) {
this.ta.setEditable$Z(b);
});

Clazz.newMethod$(C$, 'selectAll', function () {
this.ta.selectAll();
});

Clazz.newMethod$(C$, 'setText$S', function (t) {
this.ta.setText$S(t);
});

Clazz.newMethod$(C$, 'insertText$S$I', function (str, pos) {
this.ta.insert$S$I(str, pos);
});

Clazz.newMethod$(C$, 'insert$S$I', function (str, pos) {
this.ta.insert$S$I(str, pos);
});

Clazz.newMethod$(C$, 'appendText$S', function (str) {
this.ta.append$S(str);
});

Clazz.newMethod$(C$, 'append$S', function (str) {
this.ta.append$S(str);
});

Clazz.newMethod$(C$, 'replaceRange$S$I$I', function (str, start, end) {
this.ta.replaceRange$S$I$I(str, start, end);
});

Clazz.newMethod$(C$, 'replaceText$S$I$I', function (str, start, end) {
this.ta.replaceRange$S$I$I(str, start, end);
});

Clazz.newMethod$(C$, 'setColumns$I', function (columns) {
this.ta.setColumns$I(columns);
});

Clazz.newMethod$(C$, 'setRows$I', function (rows) {
this.ta.setRows$I(rows);
});

Clazz.newMethod$(C$, 'getColumns', function () {
return this.ta.getColumns();
});

Clazz.newMethod$(C$, 'getRows', function () {
return this.ta.getRows();
});
})();
//Created 2017-12-07 06:16:09
