(function(){var P$=Clazz.newPackage$("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass$(P$, "ACVoltageElm", null, 'com.falstad.circuit.VoltageElm');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (xx, yy) {
C$.superClazz.c$$I$I$I.apply(this, [xx, yy, 1]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getDumpClass', function () {
return Clazz.getClass((I$[0]||(I$[0]=Clazz.load('com.falstad.circuit.VoltageElm'))));
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-05 07:18:17
