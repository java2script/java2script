(function(){var P$=Clazz.newPackage$("com.falstad"),I$=[];
var C$=Clazz.newClass$(P$, "CircOsc", null, 'a2s.Applet', 'java.awt.event.ComponentListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

C$.ogf = null;

Clazz.newMethod$(C$, '$init$', function () {
this.started = false;
this.security = false;
}, 1);

Clazz.newMethod$(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMethod$(C$, 'init', function () {
this.showFrame();
});

Clazz.newMethod$(C$, 'main', function (args) {
C$.ogf = Clazz.new((I$[1]||(I$[1]=Clazz.load('com.falstad.CircOscFrame'))).c$$com_falstad_CircOsc,[null]);
C$.ogf.init();
}, 1);

Clazz.newMethod$(C$, 'showFrame', function () {
if (C$.ogf == null ) {
this.started = true;
try {
C$.ogf = Clazz.new((I$[1]||(I$[1]=Clazz.load('com.falstad.CircOscFrame'))).c$$com_falstad_CircOsc,[this]);
C$.ogf.init();
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
e.printStackTrace();
C$.ogf = null;
this.security = true;
this.repaint();
} else {
throw e;
}
}
this.repaint();
}});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
C$.superClazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (this.security) s = "Security exception, use nosound version";
 else if (!this.started) s = "Applet is starting.";
 else if (C$.ogf == null ) s = "Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMethod$(C$, 'componentHidden$java_awt_event_ComponentEvent', function (e) {
});

Clazz.newMethod$(C$, 'componentMoved$java_awt_event_ComponentEvent', function (e) {
});

Clazz.newMethod$(C$, 'componentShown$java_awt_event_ComponentEvent', function (e) {
});

Clazz.newMethod$(C$, 'componentResized$java_awt_event_ComponentEvent', function (e) {
});

Clazz.newMethod$(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
this.repaint();
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-05 07:18:02
