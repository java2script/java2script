(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Frame", null, 'javax.swing.JFrame');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (title) {
C$.superClazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
C$.superClazz.c$$java_awt_GraphicsConfiguration.apply(this, [gc]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S$java_awt_GraphicsConfiguration', function (title, gc) {
C$.superClazz.c$$S$java_awt_GraphicsConfiguration.apply(this, [title, gc]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'remove$I', function (i) {
{
this.removeInt(i);
}});

Clazz.newMethod$(C$, 'setMenuBar$a2s_MenuBar', function (m) {
this.setJMenuBar$javax_swing_JMenuBar(m);
});

Clazz.newMethod$(C$, 'unsetMenuBar', function () {
this.setJMenuBar$javax_swing_JMenuBar(null);
});

Clazz.newMethod$(C$, 'getMenubar', function () {
return this.getJMenuBar();
});
})();
//Created 2017-12-05 07:17:58
