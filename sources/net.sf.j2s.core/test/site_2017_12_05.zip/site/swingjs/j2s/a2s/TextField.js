(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "TextField", null, 'javax.swing.JTextField');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (width) {
C$.superClazz.c$$I.apply(this, [width]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.superClazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (text, width) {
C$.superClazz.c$$S$I.apply(this, [text, width]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'addTextListener$java_awt_event_TextListener', function (textListener) {
this.getDocument().addDocumentListener$javax_swing_event_DocumentListener(((
(function(){var C$=Clazz.newClass$(P$, "TextField$1", function(){Clazz.newInstance$(this, arguments[0],1,C$);}, null, 'javax.swing.event.DocumentListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_event_DocumentEvent', function (e) {
});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_event_DocumentEvent', function (e) {
});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent', function (e) {
this.$finals.textListener.textValueChanged$java_awt_event_TextEvent(Clazz.new((I$[0]||(I$[0]=Clazz.load('java.awt.event.TextEvent'))).c$$O$I,[this, 0]));
});
})()
), Clazz.new((I$[1]||(I$[1]=Clazz.load('a2s.TextField$1'))).$init$, [this, {textListener: textListener}])));
});
})();
//Created 2017-12-05 07:17:58
