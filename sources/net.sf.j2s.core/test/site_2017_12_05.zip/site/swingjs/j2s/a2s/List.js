(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "List", null, 'javax.swing.JList');
var o$;
C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-12-05 07:17:58
