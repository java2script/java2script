(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Button", null, 'javax.swing.JButton');

C$.$clinit$ = function() {Clazz.load(C$, 1);;
C$.awtInsets = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 6, 0, 6]);
};

C$.awtInsets = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.superClazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getMargin', function () {
return C$.awtInsets;
});
})();
//Created 2017-12-05 07:17:58
