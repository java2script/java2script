(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "ScrollPane", null, 'javax.swing.JScrollPane');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-05 07:17:58
