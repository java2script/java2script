(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Checkbox", null, 'javax.swing.JCheckBox');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'newRadioButton$S$javax_swing_ButtonGroup$Z', function (string, bg, b) {
var rb = Clazz.new((I$[0]||(I$[0]=Clazz.load('javax.swing.JRadioButton'))).c$$S$Z,[string, b]);
bg.add$javax_swing_AbstractButton(rb);
return rb;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (string) {
C$.superClazz.c$$S$Z.apply(this, [string, false]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (string, b) {
C$.superClazz.c$$S$Z.apply(this, [string, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getState', function () {
return this.isSelected();
});

Clazz.newMethod$(C$, 'setState$Z', function (b) {
this.setSelected$Z(b);
});
})();
//Created 2017-12-05 07:17:58
