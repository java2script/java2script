(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Label", null, 'javax.swing.JLabel');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.superClazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (text, center) {
C$.superClazz.c$$S$I.apply(this, [text, center]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setAlignment$I', function (alignment) {
this.setAlignmentX$F(alignment);
});
})();
//Created 2017-12-05 07:17:58
