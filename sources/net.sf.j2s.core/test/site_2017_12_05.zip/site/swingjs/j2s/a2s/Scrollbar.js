(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Scrollbar", null, 'javax.swing.JScrollBar');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (direction) {
C$.superClazz.c$$I.apply(this, [direction]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I$I', function (orientation, value, extent, min, max) {
C$.superClazz.c$$I$I$I$I$I.apply(this, [orientation, value, extent, min, max]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setValue$I', function (n) {
C$.superClazz.prototype.setValue$I.apply(this, [n]);
});

Clazz.newMethod$(C$, 'getMinimum', function () {
return C$.superClazz.prototype.getMinimum.apply(this, []);
});

Clazz.newMethod$(C$, 'getMaximum', function () {
return C$.superClazz.prototype.getMaximum.apply(this, []);
});

Clazz.newMethod$(C$, 'getValue', function () {
return C$.superClazz.prototype.getValue.apply(this, []);
});
})();
//Created 2017-12-05 07:17:58
