(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "LayoutManager");
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-01 17:54:04 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
