(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
var C$=Clazz.newInterface(P$, "OpenType");
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-27 12:09:09 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
