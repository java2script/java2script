(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageObserver");
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-16 15:42:42 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
