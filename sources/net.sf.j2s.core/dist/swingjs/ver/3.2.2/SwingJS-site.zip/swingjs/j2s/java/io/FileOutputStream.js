(function(){var P$=java.io,p$1={},I$=[[0,'java.io.File','javajs.util.OC']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "FileOutputStream", null, 'java.io.OutputStream');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.out=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.c$$java_io_File$Z.apply(this, [name != null  ? Clazz.new_(Clazz.load('java.io.File').c$$S,[name]) : null, false]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (name, append) {
C$.c$$java_io_File$Z.apply(this, [name != null  ? Clazz.new_($I$(1).c$$S,[name]) : null, append]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (file) {
C$.c$$java_io_File$Z.apply(this, [file, false]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$Z', function (file, append) {
Clazz.super_(C$, this,1);
var name=(file != null  ? file.getPath$() : null);
if (name == null ) {
throw Clazz.new_(Clazz.load('NullPointerException'));
}if (append) {
p$1.openAppend$S.apply(this, [name]);
} else {
p$1.open$S.apply(this, [name]);
}}, 1);

Clazz.newMeth(C$, 'c$$java_io_FileDescriptor', function (fdObj) {
C$.c$$java_io_File$Z.apply(this, [Clazz.new_($I$(1).c$$S,["output"]), false]);
}, 1);

Clazz.newMeth(C$, 'open$S', function (name) {
this.out=Clazz.new_(Clazz.load('javajs.util.OC'));
this.out.setParams$javajs_api_BytePoster$S$Z$java_io_OutputStream(null, name, false, null);
}, p$1);

Clazz.newMeth(C$, 'openAppend$S', function (name) {
System.out.println$S("FileOutputStream disabled -- no JSToolkit");
}, p$1);

Clazz.newMeth(C$, 'writeBytes$BA$I$I', function (b, off, len) {
this.out.write$BA$I$I(b, off, len);
}, p$1);

Clazz.newMeth(C$, 'write$I', function (b) {
this.out.writeByteAsInt$I(b);
});

Clazz.newMeth(C$, 'write$BA', function (b) {
p$1.writeBytes$BA$I$I.apply(this, [b, 0, b.length]);
});

Clazz.newMeth(C$, 'write$BA$I$I', function (b, off, len) {
p$1.writeBytes$BA$I$I.apply(this, [b, off, len]);
});

Clazz.newMeth(C$, 'close$', function () {
this.out.closeChannel$();
});

Clazz.newMeth(C$, 'finalize$', function () {
this.close$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-19 23:02:50 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
