(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletContext");
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-16 17:33:09 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
