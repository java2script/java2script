(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newClass(P$, "HierarchyBoundsAdapter", null, null, 'java.awt.event.HierarchyBoundsListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'ancestorMoved$java_awt_event_HierarchyEvent', function (e) {
});

Clazz.newMeth(C$, 'ancestorResized$java_awt_event_HierarchyEvent', function (e) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-16 17:33:16 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
