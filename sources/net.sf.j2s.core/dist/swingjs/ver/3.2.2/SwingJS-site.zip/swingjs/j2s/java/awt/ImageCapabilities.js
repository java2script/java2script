(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "ImageCapabilities", null, null, 'Cloneable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.accelerated=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.accelerated=false;
}, 1);

Clazz.newMeth(C$, 'c$$Z', function (accelerated) {
C$.$init$.apply(this);
this.accelerated=accelerated;
}, 1);

Clazz.newMeth(C$, 'isAccelerated$', function () {
return this.accelerated;
});

Clazz.newMeth(C$, 'isTrueVolatile$', function () {
return false;
});

Clazz.newMeth(C$, 'clone$', function () {
try {
return Clazz.clone(this);
} catch (e) {
if (Clazz.exceptionOf(e,"CloneNotSupportedException")){
throw Clazz.new_(Clazz.load('InternalError'));
} else {
throw e;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-18 19:27:17 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
