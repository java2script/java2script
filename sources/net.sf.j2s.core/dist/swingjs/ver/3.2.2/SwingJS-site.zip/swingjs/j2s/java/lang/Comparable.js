(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Comparable");
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-16 17:33:23 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
