(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "PaintContext");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-16 07:12:34 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
