(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-09-16 12:53:57 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
