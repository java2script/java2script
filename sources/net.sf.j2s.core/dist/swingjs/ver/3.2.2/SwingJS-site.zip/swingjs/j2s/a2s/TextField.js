(function(){var P$=Clazz.newPackage("a2s"),I$=[[0,'java.awt.event.TextEvent']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TextField", null, 'javax.swing.JTextField');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (width) {
C$.superclazz.c$$I.apply(this, [width]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (text, width) {
C$.superclazz.c$$S$I.apply(this, [text, width]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'addTextListener$java_awt_event_TextListener', function (textListener) {
this.getDocument$().addDocumentListener$javax_swing_event_DocumentListener(((P$.TextField$1||
(function(){var C$=Clazz.newClass(P$, "TextField$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'javax.swing.event.DocumentListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'insertUpdate$javax_swing_event_DocumentEvent', function (e) {
this.$finals$.textListener.textValueChanged$(Clazz.new_(Clazz.load('java.awt.event.TextEvent').c$$O$I,[this, 0]));
});

Clazz.newMeth(C$, 'removeUpdate$javax_swing_event_DocumentEvent', function (e) {
this.$finals$.textListener.textValueChanged$(Clazz.new_($I$(1).c$$O$I,[this, 0]));
});

Clazz.newMeth(C$, 'changedUpdate$javax_swing_event_DocumentEvent', function (e) {
this.$finals$.textListener.textValueChanged$(Clazz.new_($I$(1).c$$O$I,[this, 0]));
});
})()
), Clazz.new_(P$.TextField$1.$init$, [this, {textListener: textListener}])));
});
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-18 19:27:12 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
