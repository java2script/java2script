(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathIterator");
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-18 19:27:23 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
