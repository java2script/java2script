(function(){var P$=Clazz.newPackage("java.awt"),I$=[['sun.util.logging.PlatformLogger','sun.awt.AttributeValue',['sun.util.logging.PlatformLogger','.Level']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AttributeValue");
C$.log = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.log = (I$[1]||$incl$(1)).getLogger$S("java.awt.AttributeValue");
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.value = 0;
this.names = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$SA', function (value, names) {
C$.$init$.apply(this);
if ((I$[2]||$incl$(2)).log.isLoggable$sun_util_logging_PlatformLogger_Level((I$[3]||$incl$(3)).FINEST)) {
(I$[2]||$incl$(2)).log.finest$S("value = " + value + ", names = " + names );
}if ((I$[2]||$incl$(2)).log.isLoggable$sun_util_logging_PlatformLogger_Level((I$[3]||$incl$(3)).FINER)) {
if ((value < 0) || (names == null ) || (value >= names.length)  ) {
(I$[2]||$incl$(2)).log.finer$S("Assertion failed");
}}this.value=value;
this.names=names;
}, 1);

Clazz.newMeth(C$, 'hashCode', function () {
return this.value;
});

Clazz.newMeth(C$, 'toString', function () {
return this.names[this.value];
});

Clazz.newMeth(C$);
})();
//Created 2018-07-24 17:01:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
