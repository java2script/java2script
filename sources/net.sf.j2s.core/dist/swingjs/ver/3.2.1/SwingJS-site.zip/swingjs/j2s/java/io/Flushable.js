(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Flushable");
})();
//Created 2018-07-24 10:41:45 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
