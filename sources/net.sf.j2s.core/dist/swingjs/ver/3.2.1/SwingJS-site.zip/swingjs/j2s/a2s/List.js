(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "List", null, 'javax.swing.JList');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-07-24 12:15:27 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
