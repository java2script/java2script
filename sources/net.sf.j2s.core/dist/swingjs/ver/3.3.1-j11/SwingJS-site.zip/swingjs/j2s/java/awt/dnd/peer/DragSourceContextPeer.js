(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-06-27 22:47:54 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
