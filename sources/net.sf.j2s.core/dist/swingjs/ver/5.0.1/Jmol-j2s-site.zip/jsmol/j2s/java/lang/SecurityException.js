Clazz.load (["java.lang.RuntimeException"], "java.lang.SecurityException", null, function () {
var c$ = Clazz.declareType (java.lang, "SecurityException", RuntimeException);
Clazz.makeConstructor (c$, 
function (cause) {
Clazz.superConstructor (this, SecurityException, [(cause == null ? null : cause.toString ()), cause]);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
