Clazz.declareInterface (java.util, "Map");
Clazz.declareInterface (java.util.Map, "Entry");
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
