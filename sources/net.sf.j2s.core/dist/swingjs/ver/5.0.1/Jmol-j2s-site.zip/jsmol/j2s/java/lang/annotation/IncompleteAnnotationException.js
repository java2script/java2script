Clazz.load (["java.lang.RuntimeException"], "java.lang.annotation.IncompleteAnnotationException", ["org.apache.harmony.luni.util.Msg"], function () {
var c$ = Clazz.decorateAsClass (function () {
this.$annotationType = null;
this.$elementName = null;
Clazz.instantialize (this, arguments);
}, java.lang.annotation, "IncompleteAnnotationException", RuntimeException);
Clazz.makeConstructor (c$, 
function (annotationType, elementName) {
Clazz.superConstructor (this, java.lang.annotation.IncompleteAnnotationException, [org.apache.harmony.luni.util.Msg.getString ("annotation.0", elementName, annotationType)]);
this.$annotationType = annotationType;
this.$elementName = elementName;
}, "Class,~S");
Clazz.defineMethod (c$, "annotationType", 
function () {
return this.$annotationType;
});
Clazz.defineMethod (c$, "elementName", 
function () {
return this.$elementName;
});
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
