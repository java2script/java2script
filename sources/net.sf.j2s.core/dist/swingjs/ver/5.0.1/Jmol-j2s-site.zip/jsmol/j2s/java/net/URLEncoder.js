Clazz.declarePackage ("java.net");
var c$ = Clazz.declareType (java.net, "URLEncoder");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return encodeURIComponent(arguments[0]);
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s, enc) {
return encodeURIComponent(arguments[0]);
}, "~S,~S");
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
