Clazz.declarePackage ("java.util.zip");
Clazz.load (["com.jcraft.jzlib.Inflater"], "java.util.zip.Inflater", null, function () {
c$ = Clazz.declareType (java.util.zip, "Inflater", com.jcraft.jzlib.Inflater);
Clazz.defineMethod (c$, "initialize", 
function (nowrap) {
return this.init (0, nowrap);
}, "~B");
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023