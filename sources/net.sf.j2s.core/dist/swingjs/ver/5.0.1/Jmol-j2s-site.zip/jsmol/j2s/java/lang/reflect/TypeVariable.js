Clazz.load (["java.lang.reflect.Type"], "java.lang.reflect.TypeVariable", null, function () {
Clazz.declareInterface (java.lang.reflect, "TypeVariable", java.lang.reflect.Type);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
