Clazz.load (["java.lang.ClassFormatError"], "java.lang.UnsupportedClassVersionError", null, function () {
var c$ = Clazz.declareType (java.lang, "UnsupportedClassVersionError", ClassFormatError);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
