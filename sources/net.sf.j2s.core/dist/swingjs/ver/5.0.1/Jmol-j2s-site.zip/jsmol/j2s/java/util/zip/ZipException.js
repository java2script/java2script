Clazz.declarePackage ("java.util.zip");
Clazz.load (["java.io.IOException"], "java.util.zip.ZipException", null, function () {
var c$ = Clazz.declareType (java.util.zip, "ZipException", java.io.IOException);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
