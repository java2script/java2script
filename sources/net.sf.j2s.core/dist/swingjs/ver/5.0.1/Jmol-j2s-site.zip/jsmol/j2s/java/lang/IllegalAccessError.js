Clazz.load (["java.lang.IncompatibleClassChangeError"], "java.lang.IllegalAccessError", null, function () {
c$ = Clazz.declareType (java.lang, "IllegalAccessError", IncompatibleClassChangeError);
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023