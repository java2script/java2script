Clazz.load (["java.io.IOException"], "java.io.UnsupportedEncodingException", null, function () {
c$ = Clazz.declareType (java.io, "UnsupportedEncodingException", java.io.IOException);
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023