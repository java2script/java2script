Clazz.load (["java.lang.Error"], "java.lang.ThreadDeath", null, function () {
var c$ = Clazz.declareType (java.lang, "ThreadDeath", Error);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, ThreadDeath, []);
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
