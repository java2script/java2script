Clazz.load (["java.io.ObjectStreamException"], "java.io.InvalidObjectException", null, function () {
var c$ = Clazz.declareType (java.io, "InvalidObjectException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
