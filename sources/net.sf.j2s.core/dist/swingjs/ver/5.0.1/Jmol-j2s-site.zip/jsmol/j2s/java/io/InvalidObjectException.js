Clazz.load (["java.io.ObjectStreamException"], "java.io.InvalidObjectException", null, function () {
var c$ = Clazz.declareType (java.io, "InvalidObjectException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
