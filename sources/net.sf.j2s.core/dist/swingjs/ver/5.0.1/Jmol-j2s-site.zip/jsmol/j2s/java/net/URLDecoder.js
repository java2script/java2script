Clazz.declarePackage ("java.net");
Clazz.load (null, "java.net.URLDecoder", ["java.lang.NullPointerException"], function () {
var c$ = Clazz.declareType (java.net, "URLDecoder");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (s) {
return decodeURIComponent(arguments[0]);
}, "~S");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (s, enc) {
if (enc == null) {
throw  new NullPointerException ();
}{
return decodeURIComponent(arguments[0]);
}return null;
}, "~S,~S");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
