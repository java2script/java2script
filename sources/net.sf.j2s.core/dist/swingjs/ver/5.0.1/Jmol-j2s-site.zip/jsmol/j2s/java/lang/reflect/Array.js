Array.getComponentType = function () {
return Object;
}; var c$ = Clazz.declareType (java.lang.reflect, "Array");
c$.newInstance = Clazz.defineMethod (c$, "newInstance", 
function (componentType, size) {
return Clazz.newArray (length);
}, "Class,~N");
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
