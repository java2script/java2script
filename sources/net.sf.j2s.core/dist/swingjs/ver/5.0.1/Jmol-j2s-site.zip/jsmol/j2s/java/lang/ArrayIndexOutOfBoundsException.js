Clazz.load (["java.lang.IndexOutOfBoundsException"], "java.lang.ArrayIndexOutOfBoundsException", null, function () {
c$ = Clazz.declareType (java.lang, "ArrayIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (index) {
Clazz.superConstructor (this, ArrayIndexOutOfBoundsException, ["Array index out of range: " + index]);
}, "~N");
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023