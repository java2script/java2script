Clazz.load (["java.lang.IndexOutOfBoundsException"], "java.lang.ArrayIndexOutOfBoundsException", null, function () {
var c$ = Clazz.declareType (java.lang, "ArrayIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (index) {
Clazz.superConstructor (this, ArrayIndexOutOfBoundsException, ["Array index out of range: " + index]);
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
