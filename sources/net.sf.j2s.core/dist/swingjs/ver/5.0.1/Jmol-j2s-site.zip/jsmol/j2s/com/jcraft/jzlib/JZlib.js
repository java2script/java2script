Clazz.declarePackage ("com.jcraft.jzlib");
c$ = Clazz.declareType (com.jcraft.jzlib, "JZlib");
c$.version = Clazz.defineMethod (c$, "version", 
function () {
return "1.1.0";
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023