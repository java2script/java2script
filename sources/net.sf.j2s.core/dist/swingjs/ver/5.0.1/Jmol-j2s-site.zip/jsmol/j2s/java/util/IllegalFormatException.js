Clazz.load (["java.lang.IllegalArgumentException"], "java.util.IllegalFormatException", null, function () {
c$ = Clazz.declareType (java.util, "IllegalFormatException", IllegalArgumentException, java.io.Serializable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.IllegalFormatException, []);
});
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023