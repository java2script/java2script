Clazz.declarePackage ("java.net");
Clazz.load (["java.io.IOException"], "java.net.MalformedURLException", null, function () {
var c$ = Clazz.declareType (java.net, "MalformedURLException", java.io.IOException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.net.MalformedURLException, []);
});
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
