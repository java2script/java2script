Clazz.declarePackage ("java.net");
Clazz.load (["java.io.IOException"], "java.net.MalformedURLException", null, function () {
var c$ = Clazz.declareType (java.net, "MalformedURLException", java.io.IOException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.net.MalformedURLException, []);
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
