Clazz.load (["java.lang.RuntimeException"], "java.lang.TypeNotPresentException", null, function () {
var c$ = Clazz.decorateAsClass (function () {
this.$typeName = null;
Clazz.instantialize (this, arguments);
}, java.lang, "TypeNotPresentException", RuntimeException);
Clazz.makeConstructor (c$, 
function (typeName, cause) {
Clazz.superConstructor (this, TypeNotPresentException, ["Type " + typeName + " not present", cause]);
this.$typeName = typeName;
}, "~S,Throwable");
Clazz.defineMethod (c$, "typeName", 
function () {
return this.$typeName;
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
