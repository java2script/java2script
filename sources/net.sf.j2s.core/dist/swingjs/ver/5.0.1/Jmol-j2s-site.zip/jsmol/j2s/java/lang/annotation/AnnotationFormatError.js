Clazz.load (["java.lang.Error"], "java.lang.annotation.AnnotationFormatError", null, function () {
c$ = Clazz.declareType (java.lang.annotation, "AnnotationFormatError", Error);
Clazz.makeConstructor (c$, 
function (cause) {
Clazz.superConstructor (this, java.lang.annotation.AnnotationFormatError, [cause == null ? null : cause.toString (), cause]);
}, "Throwable");
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023