Clazz.load (["java.lang.Error"], "java.lang.annotation.AnnotationFormatError", null, function () {
var c$ = Clazz.declareType (java.lang.annotation, "AnnotationFormatError", Error);
Clazz.makeConstructor (c$, 
function (cause) {
Clazz.superConstructor (this, java.lang.annotation.AnnotationFormatError, [cause == null ? null : cause.toString (), cause]);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
