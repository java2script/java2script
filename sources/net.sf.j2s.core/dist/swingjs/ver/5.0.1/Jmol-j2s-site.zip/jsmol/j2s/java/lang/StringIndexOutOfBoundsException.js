Clazz.load (["java.lang.IndexOutOfBoundsException"], "java.lang.StringIndexOutOfBoundsException", null, function () {
var c$ = Clazz.declareType (java.lang, "StringIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (index) {
Clazz.superConstructor (this, StringIndexOutOfBoundsException, ["String index out of range: " + index]);
}, "~N");
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
