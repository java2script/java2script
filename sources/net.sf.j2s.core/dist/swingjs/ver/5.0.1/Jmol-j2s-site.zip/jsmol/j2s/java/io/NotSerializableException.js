Clazz.load (["java.io.ObjectStreamException"], "java.io.NotSerializableException", null, function () {
var c$ = Clazz.declareType (java.io, "NotSerializableException", java.io.ObjectStreamException);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
