Clazz.load (["java.lang.LinkageError"], "java.lang.VerifyError", null, function () {
var c$ = Clazz.declareType (java.lang, "VerifyError", LinkageError);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
