Clazz.load (["java.lang.RuntimeException"], "java.lang.reflect.MalformedParameterizedTypeException", null, function () {
var c$ = Clazz.declareType (java.lang.reflect, "MalformedParameterizedTypeException", RuntimeException);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
