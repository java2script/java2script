Clazz.load (["java.lang.RuntimeException"], "java.lang.IllegalArgumentException", null, function () {
c$ = Clazz.declareType (java.lang, "IllegalArgumentException", RuntimeException);
Clazz.makeConstructor (c$, 
function (cause) {
Clazz.superConstructor (this, IllegalArgumentException, [(cause == null ? null : cause.toString ()), cause]);
}, "Throwable");
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023