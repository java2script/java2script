Clazz.declarePackage ("org.apache.harmony.luni.util");
Clazz.load (["java.util.Locale", "org.apache.harmony.luni.util.MsgHelp"], "org.apache.harmony.luni.util.Msg", null, function () {
var c$ = Clazz.declareType (org.apache.harmony.luni.util, "Msg");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg) {
if (org.apache.harmony.luni.util.Msg.bundle == null) return msg;
try {
return org.apache.harmony.luni.util.Msg.bundle.getString (msg);
} catch (e) {
if (Clazz.exceptionOf (e, java.util.MissingResourceException)) {
return msg;
} else {
throw e;
}
}
}, "~S");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg, arg) {
return org.apache.harmony.luni.util.Msg.getString (msg,  Clazz.newArray (-1, [arg]));
}, "~S,~O");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg, arg) {
return org.apache.harmony.luni.util.Msg.getString (msg,  Clazz.newArray (-1, [Integer.toString (arg)]));
}, "~S,~N");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg, arg) {
return org.apache.harmony.luni.util.Msg.getString (msg,  Clazz.newArray (-1, [String.valueOf (arg)]));
}, "~S,~S");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg, arg1, arg2) {
return org.apache.harmony.luni.util.Msg.getString (msg,  Clazz.newArray (-1, [arg1, arg2]));
}, "~S,~O,~O");
c$.getString = Clazz.defineMethod (c$, "getString", 
function (msg, args) {
var format = msg;
if (org.apache.harmony.luni.util.Msg.bundle != null) {
try {
format = org.apache.harmony.luni.util.Msg.bundle.getString (msg);
} catch (e) {
if (Clazz.exceptionOf (e, java.util.MissingResourceException)) {
} else {
throw e;
}
}
}return org.apache.harmony.luni.util.MsgHelp.format (format, args);
}, "~S,~A");
Clazz.defineStatics (c$,
"bundle", null);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
