Clazz.declareInterface (java.util, "Collection", Iterable);
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
