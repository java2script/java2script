Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.load (["java.io.IOException"], "com.jcraft.jzlib.ZStreamException", null, function () {
var c$ = Clazz.declareType (com.jcraft.jzlib, "ZStreamException", java.io.IOException);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
