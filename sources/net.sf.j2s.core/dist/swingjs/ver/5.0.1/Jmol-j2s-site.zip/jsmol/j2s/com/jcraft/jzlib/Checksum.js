Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.declareInterface (com.jcraft.jzlib, "Checksum");
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
