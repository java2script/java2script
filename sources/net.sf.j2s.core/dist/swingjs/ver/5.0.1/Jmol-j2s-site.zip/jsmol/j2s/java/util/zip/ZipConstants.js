Clazz.declarePackage ("java.util.zip");
c$ = Clazz.declareInterface (java.util.zip, "ZipConstants");
Clazz.defineStatics (c$,
"LOCSIG", 0x04034b50,
"EXTSIG", 0x08074b50,
"CENSIG", 0x02014b50,
"ENDSIG", 0x06054b50);
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023