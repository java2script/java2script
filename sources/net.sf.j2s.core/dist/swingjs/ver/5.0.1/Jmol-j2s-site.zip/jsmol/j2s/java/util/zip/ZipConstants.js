Clazz.declarePackage ("java.util.zip");
var c$ = Clazz.declareInterface (java.util.zip, "ZipConstants");
Clazz.defineStatics (c$,
"LOCSIG", 0x04034b50,
"EXTSIG", 0x08074b50,
"CENSIG", 0x02014b50,
"ENDSIG", 0x06054b50);
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
