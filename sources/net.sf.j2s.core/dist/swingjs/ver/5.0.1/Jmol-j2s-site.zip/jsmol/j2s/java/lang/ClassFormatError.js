Clazz.load (["java.lang.LinkageError"], "java.lang.ClassFormatError", null, function () {
c$ = Clazz.declareType (java.lang, "ClassFormatError", LinkageError);
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023