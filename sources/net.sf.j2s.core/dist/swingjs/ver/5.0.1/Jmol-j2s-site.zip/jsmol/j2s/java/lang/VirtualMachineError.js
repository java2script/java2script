Clazz.load (["java.lang.Error"], "java.lang.VirtualMachineError", null, function () {
var c$ = Clazz.declareType (java.lang, "VirtualMachineError", Error);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
