Clazz.load (["java.lang.Error"], "java.lang.AssertionError", ["java.lang.Double", "$.Float", "$.Long", "$.Throwable"], function () {
var c$ = Clazz.declareType (java.lang, "AssertionError", Error);
Clazz.makeConstructor (c$, 
function (detailMessage) {
Clazz.superConstructor (this, AssertionError, [String.valueOf (detailMessage), (Clazz.instanceOf (detailMessage, Throwable) ? detailMessage : null)]);
}, "~O");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (String.valueOf (detailMessage));
}, "~B");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (String.valueOf (detailMessage));
}, "~S");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (Integer.toString (detailMessage));
}, "~N");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (Long.toString (detailMessage));
}, "~N");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (Float.toString (detailMessage));
}, "~N");
Clazz.makeConstructor (c$, 
function (detailMessage) {
this.construct (Double.toString (detailMessage));
}, "~N");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
