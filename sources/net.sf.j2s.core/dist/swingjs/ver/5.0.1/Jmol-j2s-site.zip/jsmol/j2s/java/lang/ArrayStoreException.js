Clazz.load (["java.lang.RuntimeException"], "java.lang.ArrayStoreException", null, function () {
var c$ = Clazz.declareType (java.lang, "ArrayStoreException", RuntimeException);
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
