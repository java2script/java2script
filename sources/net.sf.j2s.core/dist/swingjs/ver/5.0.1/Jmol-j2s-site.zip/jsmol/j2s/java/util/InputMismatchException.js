Clazz.load (["java.util.NoSuchElementException"], "java.util.InputMismatchException", null, function () {
c$ = Clazz.declareType (java.util, "InputMismatchException", java.util.NoSuchElementException, java.io.Serializable);
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023