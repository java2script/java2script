Clazz.load (null, "java.lang.Void", ["java.lang.RuntimeException"], function () {
var c$ = Clazz.declareType (java.lang, "Void");
Clazz.defineStatics (c$,
"TYPE", null);
{
java.lang.Void.TYPE = java.lang.Void;
}});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
