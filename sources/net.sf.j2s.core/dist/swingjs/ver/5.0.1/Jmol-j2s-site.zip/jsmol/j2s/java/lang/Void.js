Clazz.load (null, "java.lang.Void", ["java.lang.RuntimeException"], function () {
c$ = Clazz.declareType (java.lang, "Void");
Clazz.defineStatics (c$,
"TYPE", null);
{
java.lang.Void.TYPE = java.lang.Void;
}});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023