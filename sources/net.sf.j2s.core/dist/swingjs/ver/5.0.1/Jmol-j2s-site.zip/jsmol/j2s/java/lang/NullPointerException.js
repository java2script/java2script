Clazz.load (["java.lang.RuntimeException"], "java.lang.NullPointerException", null, function () {
var c$ = Clazz.declareType (java.lang, "NullPointerException", RuntimeException);
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
