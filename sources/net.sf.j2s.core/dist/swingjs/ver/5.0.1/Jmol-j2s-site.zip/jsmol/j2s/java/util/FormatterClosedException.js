Clazz.load (["java.lang.IllegalStateException"], "java.util.FormatterClosedException", null, function () {
var c$ = Clazz.declareType (java.util, "FormatterClosedException", IllegalStateException, java.io.Serializable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.FormatterClosedException, []);
});
});
;//5.0.1-v1 Mon Nov 13 07:32:07 CST 2023
