Clazz.load (["java.lang.RuntimeException"], "java.util.ConcurrentModificationException", null, function () {
var c$ = Clazz.declareType (java.util, "ConcurrentModificationException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.ConcurrentModificationException, []);
});
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
