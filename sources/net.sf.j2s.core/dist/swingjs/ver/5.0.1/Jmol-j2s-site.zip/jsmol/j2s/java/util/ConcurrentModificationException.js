Clazz.load (["java.lang.RuntimeException"], "java.util.ConcurrentModificationException", null, function () {
c$ = Clazz.declareType (java.util, "ConcurrentModificationException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, java.util.ConcurrentModificationException, []);
});
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023