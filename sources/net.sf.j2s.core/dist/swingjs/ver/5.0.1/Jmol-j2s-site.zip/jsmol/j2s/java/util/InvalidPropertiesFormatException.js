Clazz.load (["java.io.IOException"], "java.util.InvalidPropertiesFormatException", ["java.io.NotSerializableException"], function () {
var c$ = Clazz.declareType (java.util, "InvalidPropertiesFormatException", java.io.IOException);
Clazz.makeConstructor (c$, 
function (c) {
Clazz.superConstructor (this, java.util.InvalidPropertiesFormatException, []);
this.initCause (c);
}, "Throwable");
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
