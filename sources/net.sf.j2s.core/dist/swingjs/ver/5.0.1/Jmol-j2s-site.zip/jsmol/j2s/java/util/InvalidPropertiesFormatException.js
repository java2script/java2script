Clazz.load (["java.io.IOException"], "java.util.InvalidPropertiesFormatException", ["java.io.NotSerializableException"], function () {
c$ = Clazz.declareType (java.util, "InvalidPropertiesFormatException", java.io.IOException);
Clazz.makeConstructor (c$, 
function (c) {
Clazz.superConstructor (this, java.util.InvalidPropertiesFormatException, []);
this.initCause (c);
}, "Throwable");
});
;//5.0.1-v1 Sat Nov 11 18:40:51 CST 2023