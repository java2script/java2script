Clazz.load (["java.lang.reflect.AccessibleObject", "$.Member"], "java.lang.reflect.Field", null, function () {
var c$ = Clazz.declareType (java.lang.reflect, "Field", java.lang.reflect.AccessibleObject, java.lang.reflect.Member);
Clazz.overrideMethod (c$, "isSynthetic", 
function () {
return false;
});
Clazz.defineMethod (c$, "toGenericString", 
function () {
return null;
});
Clazz.defineMethod (c$, "isEnumConstant", 
function () {
return false;
});
Clazz.defineMethod (c$, "getGenericType", 
function () {
return null;
});
Clazz.overrideMethod (c$, "equals", 
function (object) {
return false;
}, "~O");
Clazz.overrideMethod (c$, "getDeclaringClass", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getName", 
function () {
return null;
});
Clazz.defineMethod (c$, "getType", 
function () {
return null;
});
Clazz.overrideMethod (c$, "hashCode", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return null;
});
});
;//5.0.1-v1 Sun Nov 12 22:14:33 CST 2023
