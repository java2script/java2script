(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "UnsupportedFlavorException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_awt_datatransfer_DataFlavor',  function (flavor) {
;C$.superclazz.c$$S.apply(this,[(flavor != null ) ? flavor.getHumanPresentableName$() : null]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2023-12-10 19:11:45 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
