(function(){var P$=Clazz.newPackage("com.jcraft.jzlib"),I$=[[0,'com.jcraft.jzlib.Adler32']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ZStream");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['next_in_index','avail_in','next_out_index','avail_out','data_type'],'J',['total_in','total_out'],'S',['msg'],'O',['next_in','byte[]','+next_out','dstate','com.jcraft.jzlib.Deflate','istate','com.jcraft.jzlib.Inflate','checksum','com.jcraft.jzlib.Checksum']]]

Clazz.newMeth(C$, 'setAdler32$',  function () {
this.checksum=Clazz.new_($I$(1,1));
});

Clazz.newMeth(C$, 'inflate$I',  function (f) {
if (this.istate == null ) return -2;
return this.istate.inflate$I(f);
});

Clazz.newMeth(C$, 'deflate$I',  function (flush) {
if (this.dstate == null ) {
return -2;
}return this.dstate.deflate$I(flush);
});

Clazz.newMeth(C$, 'flush_pending$',  function () {
var len=this.dstate.pending;
if (len > this.avail_out) len=this.avail_out;
if (len == 0) return;
System.arraycopy$O$I$O$I$I(this.dstate.pending_buf, this.dstate.pending_out, this.next_out, this.next_out_index, len);
this.next_out_index+=len;
this.dstate.pending_out+=len;
(this.total_out=Long.$add(this.total_out,(len)));
this.avail_out-=len;
this.dstate.pending-=len;
if (this.dstate.pending == 0) {
this.dstate.pending_out=0;
}});

Clazz.newMeth(C$, 'read_buf$BA$I$I',  function (buf, start, size) {
var len=this.avail_in;
if (len > size) len=size;
if (len == 0) return 0;
this.avail_in-=len;
if (this.dstate.wrap != 0) {
this.checksum.update$BA$I$I(this.next_in, this.next_in_index, len);
}System.arraycopy$O$I$O$I$I(this.next_in, this.next_in_index, buf, start, len);
this.next_in_index+=len;
(this.total_in=Long.$add(this.total_in,(len)));
return len;
});

Clazz.newMeth(C$, 'getAdler$',  function () {
return this.checksum.getValue$();
});

Clazz.newMeth(C$, 'free$',  function () {
this.next_in=null;
this.next_out=null;
this.msg=null;
});

Clazz.newMeth(C$, 'setOutput$BA$I$I',  function (buf, off, len) {
this.next_out=buf;
this.next_out_index=off;
this.avail_out=len;
});

Clazz.newMeth(C$, 'setInput$BA$I$I$Z',  function (buf, off, len, append) {
if (len <= 0 && append  && this.next_in != null  ) return;
if (this.avail_in > 0 && append ) {
var tmp=Clazz.array(Byte.TYPE, [this.avail_in + len]);
System.arraycopy$O$I$O$I$I(this.next_in, this.next_in_index, tmp, 0, this.avail_in);
System.arraycopy$O$I$O$I$I(buf, off, tmp, this.avail_in, len);
this.next_in=tmp;
this.next_in_index=0;
this.avail_in+=len;
} else {
this.next_in=buf;
this.next_in_index=off;
this.avail_in=len;
}});

Clazz.newMeth(C$, 'getAvailIn$',  function () {
return this.avail_in;
});

Clazz.newMeth(C$, 'getTotalOut$',  function () {
return this.total_out;
});

Clazz.newMeth(C$, 'getTotalIn$',  function () {
return this.total_in;
});

Clazz.newMeth(C$, 'getBytes$S',  function (s) {
{
var x = [];
for (var i = 0; i < s.length;i++) { var pt = s.charCodeAt(i);
if (pt <= 0x7F) { x.push(pt);
} else if (pt <= 0x7FF) { x.push(0xC0|((pt>>6)&0x1F));
x.push(0x80|(pt&0x3F));
} else if (pt <= 0xFFFF) { x.push(0xE0|((pt>>12)&0xF));
x.push(0x80|((pt>>6)&0x3F));
x.push(0x80|(pt&0x3F));
} else { x.push(0x3F); // '?'
} } return (Int32Array != Array ? new Int32Array(x) : x);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-11 18:26:29 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
