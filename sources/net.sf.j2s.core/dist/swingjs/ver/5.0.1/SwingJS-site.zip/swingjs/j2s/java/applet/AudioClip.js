(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AudioClip");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-15 14:54:47 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
