(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DropTargetPeer");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-15 14:54:56 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
