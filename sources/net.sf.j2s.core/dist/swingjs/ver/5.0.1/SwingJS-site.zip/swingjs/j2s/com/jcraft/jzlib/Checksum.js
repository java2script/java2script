(function(){var P$=Clazz.newPackage("com.jcraft.jzlib"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Checksum");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-11 18:26:28 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
