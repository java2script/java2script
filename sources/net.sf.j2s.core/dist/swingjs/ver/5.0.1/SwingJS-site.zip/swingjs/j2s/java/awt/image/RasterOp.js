(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "RasterOp");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-11 18:43:49 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
