(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BMPConstants");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-15 14:54:40 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
