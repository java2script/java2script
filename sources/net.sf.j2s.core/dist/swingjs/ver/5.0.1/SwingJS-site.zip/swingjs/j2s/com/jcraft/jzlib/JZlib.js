(function(){var P$=Clazz.newPackage("com.jcraft.jzlib"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JZlib");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'version$',  function () {
return "1.1.0";
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-11 18:26:29 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
