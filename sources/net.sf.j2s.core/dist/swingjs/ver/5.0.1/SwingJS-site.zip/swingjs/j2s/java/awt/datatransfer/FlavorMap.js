(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FlavorMap");
})();
;Clazz.setTVer('3.3.1-v7');//Created 2023-11-08 21:43:14 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
