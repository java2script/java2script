(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FlavorMap");
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-15 14:54:55 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
