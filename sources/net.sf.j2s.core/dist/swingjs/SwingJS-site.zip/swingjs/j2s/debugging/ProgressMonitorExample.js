(function(){var P$=Clazz.newPackage("debugging"),I$=[[0,'javax.swing.UIManager','Thread','javax.swing.ProgressMonitor','java.util.concurrent.TimeUnit',['test.components.ProgressMonitorExample','.AsyncTask'],'test.components.ProgressMonitorExample','javax.swing.JButton','javax.swing.JFrame','java.awt.Dimension']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProgressMonitorExample", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['AsyncTask',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createStartTaskActionListenerOrig$java_awt_Component', function (parent) {
$I$(1).put$O$O("ProgressMonitor.progressText", "Test Progress");
return ((P$.ProgressMonitorExample$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ProgressMonitorExample$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$O'], function (ae) {
Clazz.new_([((P$.ProgressMonitorExample$lambda1$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "ProgressMonitorExample$lambda1$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$', function () {
var pm=Clazz.new_($I$(3,1).c$$java_awt_Component$O$S$I$I,[this.$finals$.parent, "Test Task", "Task starting", 0, 100]);
pm.setMillisToDecideToPopup$I(100);
pm.setMillisToPopup$I(100);
for (var i=1; i <= 100; i++) {
pm.setNote$S("Task step: " + i);
pm.setProgress$I(i);
try {
$I$(4).MILLISECONDS.sleep$J(200);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
System.err.println$O(e);
} else {
throw e;
}
}
}
pm.setNote$S("Task finished");
});
})()
), Clazz.new_(P$.ProgressMonitorExample$lambda1$lambda2.$init$,[this, {parent:this.$finals$.parent}]))],$I$(2,1).c$$Runnable).start$();
});
})()
), Clazz.new_(P$.ProgressMonitorExample$lambda2.$init$,[this, {parent:parent}]));
}, 1);





Clazz.newMeth(C$, 'createStartTaskActionListener$java_awt_Component', function (parent) {
return ((P$.ProgressMonitorExample$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "ProgressMonitorExample$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$O'], function (ae) {
Clazz.new_([((P$.ProgressMonitorExample$lambda3$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "ProgressMonitorExample$lambda3$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, 'run$', function () {
Clazz.new_($I$(5,1).c$$java_awt_Component$S$I$I$I,[this.$finals$.parent, "Test Progress", 200, 1, 100]).execute$();
});
})()
), Clazz.new_(P$.ProgressMonitorExample$lambda3$lambda4.$init$,[this, {parent:this.$finals$.parent}]))],$I$(2,1).c$$Runnable).start$();
});
})()
), Clazz.new_(P$.ProgressMonitorExample$lambda4.$init$,[this, {parent:parent}]));
}, 1);






Clazz.newMeth(C$, 'main$SA', function (args) {
var frame=$I$(6).createFrame$S("ProgressMonitor Example");
var button=Clazz.new_($I$(7,1).c$$S,["start task"]);
button.addActionListener$java_awt_event_ActionListener($I$(6).createStartTaskActionListener$java_awt_Component(frame));
frame.add$java_awt_Component$O(button, "North");
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'createFrame$S', function (title) {
var frame=Clazz.new_($I$(8,1).c$$S,[title]);
frame.setDefaultCloseOperation$I(3);
frame.setSize$java_awt_Dimension(Clazz.new_($I$(9,1).c$$I$I,[800, 700]));
return frame;
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ProgressMonitorExample, "AsyncTask", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'javajs.async.AsyncSwingWorker');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_awt_Component$S$I$I$I', function (owner, title, delayMillis, min, max) {
;C$.superclazz.c$$java_awt_Component$S$I$I$I.apply(this,[owner, title, delayMillis, min, max]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'initAsync$', function () {
this.progressMonitor.setMillisToDecideToPopup$I(100);
this.progressMonitor.setMillisToPopup$I(100);
});

Clazz.newMeth(C$, 'doInBackgroundAsync$I', function (i) {
return ++i;
});

Clazz.newMeth(C$, 'doneAsync$', function () {
});

Clazz.newMeth(C$, 'getNote$I', function (progress) {
return "Task step: " + progress;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-05-01 10:40:46 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
