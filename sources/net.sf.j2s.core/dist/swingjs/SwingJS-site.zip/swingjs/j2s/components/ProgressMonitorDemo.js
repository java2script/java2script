(function(){var P$=Clazz.newPackage("components"),I$=[[0,'java.util.Random','Thread','java.awt.Toolkit','java.awt.BorderLayout','javax.swing.JButton','javax.swing.JTextArea','java.awt.Insets','javax.swing.JScrollPane','javax.swing.BorderFactory','javax.swing.ProgressMonitor',['test.components.ProgressMonitorDemo','.Task'],'javax.swing.JFrame','test.components.ProgressMonitorDemo','javax.swing.SwingUtilities']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ProgressMonitorDemo", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'javax.swing.JPanel', ['java.awt.event.ActionListener', 'java.beans.PropertyChangeListener']);
C$.$classes$=[['Task',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['progressMonitor','javax.swing.ProgressMonitor','startButton','javax.swing.JButton','taskOutput','javax.swing.JTextArea','task','test.components.ProgressMonitorDemo.Task']]]

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$$java_awt_LayoutManager.apply(this,[Clazz.new_($I$(4,1))]);C$.$init$.apply(this);
this.startButton=Clazz.new_($I$(5,1).c$$S,["Start"]);
this.startButton.setActionCommand$S("start");
this.startButton.addActionListener$java_awt_event_ActionListener(this);
this.taskOutput=Clazz.new_($I$(6,1).c$$I$I,[5, 20]);
this.taskOutput.setMargin$java_awt_Insets(Clazz.new_($I$(7,1).c$$I$I$I$I,[5, 5, 5, 5]));
this.taskOutput.setEditable$Z(false);
this.add$java_awt_Component$O(this.startButton, "First");
this.add$java_awt_Component$O(Clazz.new_($I$(8,1).c$$java_awt_Component,[this.taskOutput]), "Center");
this.setBorder$javax_swing_border_Border($I$(9).createEmptyBorder$I$I$I$I(20, 20, 20, 20));
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (evt) {
this.progressMonitor=Clazz.new_($I$(10,1).c$$java_awt_Component$O$S$I$I,[this, "Running a Long Task", "", 0, 100]);
this.progressMonitor.setProgress$I(0);
this.task=Clazz.new_($I$(11,1),[this, null]);
this.task.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
this.task.execute$();
this.startButton.setEnabled$Z(false);
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (evt) {
if ("progress" === evt.getPropertyName$() ) {
var progress=(evt.getNewValue$()).valueOf();
this.progressMonitor.setProgress$I(progress);
var message=String.format$S$OA("Completed %d%%.\n", [new Integer(progress)]);
this.progressMonitor.setNote$S(message);
this.taskOutput.append$S(message);
if (this.progressMonitor.isCanceled$() || this.task.isDone$() ) {
$I$(3).getDefaultToolkit$().beep$();
if (this.progressMonitor.isCanceled$()) {
this.task.cancel$Z(true);
this.taskOutput.append$S("Task canceled.\n");
} else {
this.taskOutput.append$S("Task completed.\n");
}this.startButton.setEnabled$Z(true);
}}});

Clazz.newMeth(C$, 'createAndShowGUI$', function () {
var frame=Clazz.new_($I$(12,1).c$$S,["ProgressMonitorDemo"]);
frame.setDefaultCloseOperation$I(3);
var newContentPane=Clazz.new_($I$(13,1));
newContentPane.setOpaque$Z(true);
frame.setContentPane$java_awt_Container(newContentPane);
frame.pack$();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
$I$(14,"invokeLater$Runnable",[((P$.test.components.ProgressMonitorDemo$5776||
(function(){/*a*/var C$=Clazz.newClass(P$, "test.components.ProgressMonitorDemo$5776", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
$I$(13).createAndShowGUI$();
});
})()
), Clazz.new_(test.components.ProgressMonitorDemo$5776.$init$,[this, null]))]);
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ProgressMonitorDemo, "Task", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'javax.swing.SwingWorker');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'doInBackground$', function () {
var random=Clazz.new_($I$(1,1));
var progress=0;
this.setProgress$I(0);
try {
$I$(2).sleep$J(1000);
while (progress < 100 && !this.isCancelled$() ){
$I$(2,"sleep$J",[random.nextInt$I(1000)]);
progress+=random.nextInt$I(10);
this.setProgress$I(Math.min(progress, 100));
}
} catch (ignore) {
if (Clazz.exceptionOf(ignore,"InterruptedException")){
} else {
throw ignore;
}
}
return null;
});

Clazz.newMeth(C$, 'done$', function () {
$I$(3).getDefaultToolkit$().beep$();
this.b$['test.components.ProgressMonitorDemo'].startButton.setEnabled$Z(true);
this.b$['test.components.ProgressMonitorDemo'].progressMonitor.setProgress$I(0);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-30 11:18:28 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
