(function(){var P$=Clazz.newPackage("components"),p$1={},I$=[[0,'java.awt.GridLayout','javax.swing.JTable','java.awt.Dimension','java.awt.event.MouseAdapter','javax.swing.JScrollPane','javax.swing.JFrame','javax.swing.SwingUtilities']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SimpleTableDemo", null, 'javax.swing.JPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.DEBUG=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.DEBUG=false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$java_awt_LayoutManager.apply(this, [Clazz.new_(Clazz.load('java.awt.GridLayout').c$$I$I,[1, 0])]);
C$.$init$.apply(this);
var columnNames=Clazz.array(String, -1, ["First Name", "Last Name", "Sport", "# of Years", "Vegetarian"]);
var data=Clazz.array(java.lang.Object, -2, [Clazz.array(java.lang.Object, -1, ["Kathy", "Smith", "Snowboarding",  new Integer(5),  Boolean.from(false)]), Clazz.array(java.lang.Object, -1, ["John", "Doe", "Rowing",  new Integer(3),  Boolean.from(true)]), Clazz.array(java.lang.Object, -1, ["Sue", "Black", "Knitting",  new Integer(2),  Boolean.from(false)]), Clazz.array(java.lang.Object, -1, ["Jane", "White", "Speed reading",  new Integer(20),  Boolean.from(true)]), Clazz.array(java.lang.Object, -1, ["Joe", "Brown", "Pool",  new Integer(10),  Boolean.from(false)])]);
var table=Clazz.new_(Clazz.load('javax.swing.JTable').c$$OAA$OA,[data, columnNames]);
table.setPreferredScrollableViewportSize$java_awt_Dimension(Clazz.new_(Clazz.load('java.awt.Dimension').c$$I$I,[500, 70]));
table.setFillsViewportHeight$Z(true);
if (this.DEBUG) {
table.addMouseListener$java_awt_event_MouseListener(((P$.SimpleTableDemo$1||
(function(){var C$=Clazz.newClass(P$, "SimpleTableDemo$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
p$1.printDebugData$javax_swing_JTable.apply(this.b$['components.SimpleTableDemo'], [this.$finals$.table]);
});
})()
), Clazz.new_(Clazz.load('java.awt.event.MouseAdapter'), [this, {table: table}],P$.SimpleTableDemo$1)));
}var scrollPane=Clazz.new_(Clazz.load('javax.swing.JScrollPane').c$$java_awt_Component,[table]);
this.add$java_awt_Component(scrollPane);
}, 1);

Clazz.newMeth(C$, 'printDebugData$javax_swing_JTable', function (table) {
var numRows=table.getRowCount$();
var numCols=table.getColumnCount$();
var model=table.getModel$();
System.out.println$S("Value of data: ");
for (var i=0; i < numRows; i++) {
System.out.print$S("    row " + i + ":" );
for (var j=0; j < numCols; j++) {
System.out.print$S("  " + model.getValueAt$I$I(i, j));
}
System.out.println$();
}
System.out.println$S("--------------------------");
}, p$1);

Clazz.newMeth(C$, 'createAndShowGUI$', function () {
var frame=Clazz.new_(Clazz.load('javax.swing.JFrame').c$$S,["SimpleTableDemo"]);
frame.setDefaultCloseOperation$I(3);
var newContentPane=Clazz.new_(C$);
newContentPane.setOpaque$Z(true);
frame.setContentPane$java_awt_Container(newContentPane);
frame.pack$();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
Clazz.load('javax.swing.SwingUtilities').invokeLater$Runnable(((P$.SimpleTableDemo$2||
(function(){var C$=Clazz.newClass(P$, "SimpleTableDemo$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run$', function () {
P$.SimpleTableDemo.createAndShowGUI$();
});
})()
), Clazz.new_(P$.SimpleTableDemo$2.$init$, [this, null])));
}, 1);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-12-09 14:32:16 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
