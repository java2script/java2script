(function(){var P$=Clazz.newPackage("jalview.xml.binding.jalview"),I$=[[0,'javax.xml.namespace.QName','test.jaxb.Annotation']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ObjectFactory");
C$._WebServiceParameterSet_QNAME=null;
C$._JalviewModel_QNAME=null;
C$._JalviewUserColours_QNAME=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._WebServiceParameterSet_QNAME=Clazz.new_(Clazz.load('javax.xml.namespace.QName').c$$S$S,["www.jalview.org/xml/wsparamset", "WebServiceParameterSet"]);
C$._JalviewModel_QNAME=Clazz.new_($I$(1).c$$S$S,["www.jalview.org", "JalviewModel"]);
C$._JalviewUserColours_QNAME=Clazz.new_($I$(1).c$$S$S,["www.jalview.org/colours", "JalviewUserColours"]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'createAnnotation$', function () {
return Clazz.new_(Clazz.load('test.jaxb.Annotation'));
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-11-01 07:02:53 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
