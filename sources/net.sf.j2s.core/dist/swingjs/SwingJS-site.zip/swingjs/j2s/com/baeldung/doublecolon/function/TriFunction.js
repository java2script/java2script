(function(){var P$=Clazz.newPackage("com.baeldung.doublecolon.function"),I$=[[0,'java.util.Objects']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newInterface(P$, "TriFunction");
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'andThen$java_util_function_Function', function (after) {
$I$(1).requireNonNull$TT(after);
return ((P$.TriFunction$lambda1||
(function(){var C$=Clazz.newClass(P$, "TriFunction$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.baeldung.doublecolon.function.TriFunction', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$'], function (a, b, c) { return (this.$finals$.after.apply$(this.apply$(a, b, c)));});
})()
), Clazz.new_(P$.TriFunction$lambda1.$init$, [this, {after: after}]));
});
};})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 11:42:54 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
