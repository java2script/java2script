(function(){var P$=Clazz.newPackage("com.baeldung.doublecolon"),I$=[[0,'java.util.ArrayList']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ComputerUtils");
C$.after2010Predicate=null;
C$.blackPredicate=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.after2010Predicate=(P$.ComputerUtils$lambda1$||(P$.ComputerUtils$lambda1$=(((P$.ComputerUtils$lambda1||
(function(){var C$=Clazz.newClass(P$, "ComputerUtils$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.baeldung.doublecolon.function.ComputerPredicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, 'filter$', function (c) { return (((c.getAge$()).intValue$() > 2010 ));});
})()
), Clazz.new_(P$.ComputerUtils$lambda1.$init$, [this, null])))));
C$.blackPredicate=(P$.ComputerUtils$lambda2$||(P$.ComputerUtils$lambda2$=(((P$.ComputerUtils$lambda2||
(function(){var C$=Clazz.newClass(P$, "ComputerUtils$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'com.baeldung.doublecolon.function.ComputerPredicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_E*/
Clazz.newMeth(C$, 'filter$', function (c) { return ("black".equals$O(c.getColor$()));});
})()
), Clazz.new_(P$.ComputerUtils$lambda2.$init$, [this, null])))));
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'filter$java_util_List$com_baeldung_doublecolon_function_ComputerPredicate', function (inventory, p) {
var result=Clazz.new_($I$(1));
inventory.stream$().filter$java_util_function_Predicate((P$.ComputerUtils$lambda3$||(P$.ComputerUtils$lambda3$=((function($class$){((P$.ComputerUtils$lambda3||
(function(){var C$=Clazz.newClass(P$, "ComputerUtils$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_M*/
Clazz.newMeth(C$, 'test$', function (t) { return $class$.filter$.apply($class$,[t])});
})()
)); return Clazz.new_(P$.ComputerUtils$lambda3.$init$, [this, null])})(p))))).forEach$java_util_function_Consumer((P$.ComputerUtils$lambda4$||(P$.ComputerUtils$lambda4$=((function($class$){((P$.ComputerUtils$lambda4||
(function(){var C$=Clazz.newClass(P$, "ComputerUtils$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_M*/
Clazz.newMeth(C$, 'accept$', function (t) { return $class$.add$TE.apply($class$,[t])});
})()
)); return Clazz.new_(P$.ComputerUtils$lambda4.$init$, [this, null])})(result)))));
return result;
}, 1);

Clazz.newMeth(C$, 'repair$com_baeldung_doublecolon_Computer', function (computer) {
if ((computer.getHealty$()).intValue$() < 50 ) {
computer.setHealty$Integer(new Integer(100));
}}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 11:42:54 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
