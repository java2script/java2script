(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.common"),I$=[[0,'java.awt.color.ColorSpace','com.sun.imageio.plugins.common.BogusColorSpace','java.awt.image.ComponentColorModel','java.awt.image.DirectColorModel','java.awt.image.IndexColorModel','com.sun.imageio.plugins.common.I18N','java.awt.image.DataBuffer','javax.imageio.ImageTypeSpecifier']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ImageUtil");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'createColorModel$java_awt_image_SampleModel', function (sampleModel) {
if (sampleModel == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["sampleModel == null!"]);
}let dataType=sampleModel.getDataType$();
switch (dataType) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 5:
break;
default:
return null;
}
let colorModel=null;
let sampleSize=sampleModel.getSampleSize$();
if (Clazz.instanceOf(sampleModel, "java.awt.image.ComponentSampleModel")) {
let numBands=sampleModel.getNumBands$();
let colorSpace=null;
if (numBands <= 2) {
colorSpace=$I$(1).getInstance$I(1003);
} else if (numBands <= 4) {
colorSpace=$I$(1).getInstance$I(1000);
} else {
colorSpace=Clazz.new_($I$(2,1).c$$I,[numBands]);
}let hasAlpha=(numBands == 2) || (numBands == 4) ;
let isAlphaPremultiplied=false;
let transparency=hasAlpha ? 3 : 1;
colorModel=Clazz.new_($I$(3,1).c$$java_awt_color_ColorSpace$IA$Z$Z$I$I,[colorSpace, sampleSize, hasAlpha, isAlphaPremultiplied, transparency, dataType]);
} else if (sampleModel.getNumBands$() <= 4 && Clazz.instanceOf(sampleModel, "java.awt.image.SinglePixelPackedSampleModel") ) {
let sppsm=sampleModel;
let bitMasks=sppsm.getBitMasks$();
let rmask=0;
let gmask=0;
let bmask=0;
let amask=0;
let numBands=bitMasks.length;
if (numBands <= 2) {
rmask=gmask=bmask=bitMasks[0];
if (numBands == 2) {
amask=bitMasks[1];
}} else {
rmask=bitMasks[0];
gmask=bitMasks[1];
bmask=bitMasks[2];
if (numBands == 4) {
amask=bitMasks[3];
}}let bits=0;
for (let i=0; i < sampleSize.length; i++) {
bits+=sampleSize[i];
}
return Clazz.new_($I$(4,1).c$$I$I$I$I$I,[bits, rmask, gmask, bmask, amask]);
} else if (Clazz.instanceOf(sampleModel, "java.awt.image.MultiPixelPackedSampleModel")) {
let bitsPerSample=sampleSize[0];
let numEntries=1 << bitsPerSample;
let map=Clazz.array(Byte.TYPE, [numEntries]);
for (let i=0; i < numEntries; i++) {
map[i]=(((i * 255/(numEntries - 1)|0))|0);
}
colorModel=Clazz.new_($I$(5,1).c$$I$I$BA$BA$BA,[bitsPerSample, numEntries, map, map, map]);
}return colorModel;
}, 1);

Clazz.newMeth(C$, 'getPackedBinaryData$java_awt_image_Raster$java_awt_Rectangle', function (raster, rect) {
let sm=raster.getSampleModel$();
if (!C$.isBinary$java_awt_image_SampleModel(sm)) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(6).getString$S("ImageUtil0")]);
}let rectX=rect.x;
let rectY=rect.y;
let rectWidth=rect.width;
let rectHeight=rect.height;
let dataBuffer=raster.getDataBuffer$();
let dx=rectX - raster.getSampleModelTranslateX$();
let dy=rectY - raster.getSampleModelTranslateY$();
let mpp=sm;
let lineStride=mpp.getScanlineStride$();
let eltOffset=dataBuffer.getOffset$() + mpp.getOffset$I$I(dx, dy);
let bitOffset=mpp.getBitOffset$I(dx);
let numBytesPerRow=((rectWidth + 7)/8|0);
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte") && eltOffset == 0  && bitOffset == 0  && numBytesPerRow == lineStride  && (dataBuffer).getData$().length == numBytesPerRow * rectHeight ) {
return (dataBuffer).getData$();
}let binaryDataArray=Clazz.array(Byte.TYPE, [numBytesPerRow * rectHeight]);
let b=0;
if (bitOffset == 0) {
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
let stride=numBytesPerRow;
let offset=0;
for (let y=0; y < rectHeight; y++) {
System.arraycopy$O$I$O$I$I(data, eltOffset, binaryDataArray, offset, stride);
offset+=stride;
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let xRemaining=rectWidth;
let i=eltOffset;
while (xRemaining > 8){
let datum=data[i++];
binaryDataArray[b++]=(((datum >>> 8) & 255)|0);
binaryDataArray[b++]=((datum & 255)|0);
xRemaining-=16;
}
if (xRemaining > 0) {
binaryDataArray[b++]=(((data[i] >>> 8) & 255)|0);
}eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let xRemaining=rectWidth;
let i=eltOffset;
while (xRemaining > 24){
let datum=data[i++];
binaryDataArray[b++]=(((datum >>> 24) & 255)|0);
binaryDataArray[b++]=(((datum >>> 16) & 255)|0);
binaryDataArray[b++]=(((datum >>> 8) & 255)|0);
binaryDataArray[b++]=((datum & 255)|0);
xRemaining-=32;
}
let shift=24;
while (xRemaining > 0){
binaryDataArray[b++]=(((data[i] >>> shift) & 255)|0);
shift-=8;
xRemaining-=8;
}
eltOffset+=lineStride;
}
}} else {
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
if ((bitOffset & 7) == 0) {
let stride=numBytesPerRow;
let offset=0;
for (let y=0; y < rectHeight; y++) {
System.arraycopy$O$I$O$I$I(data, eltOffset, binaryDataArray, offset, stride);
offset+=stride;
eltOffset+=lineStride;
}
} else {
let leftShift=bitOffset & 7;
let rightShift=8 - leftShift;
for (let y=0; y < rectHeight; y++) {
let i=eltOffset;
let xRemaining=rectWidth;
while (xRemaining > 0){
if (xRemaining > rightShift) {
binaryDataArray[b++]=((((data[i++] & 255) << leftShift) | ((data[i] & 255) >>> rightShift))|0);
} else {
binaryDataArray[b++]=(((data[i] & 255) << leftShift)|0);
}xRemaining-=8;
}
eltOffset+=lineStride;
}
}} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let bOffset=bitOffset;
for (let x=0; x < rectWidth; x+=8, bOffset+=8) {
let i=eltOffset + (bOffset/16|0);
let mod=bOffset % 16;
let left=data[i] & 65535;
if (mod <= 8) {
binaryDataArray[b++]=((left >>> (8 - mod))|0);
} else {
let delta=mod - 8;
let right=data[i + 1] & 65535;
binaryDataArray[b++]=(((left << delta) | (right >>> (16 - delta)))|0);
}}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let bOffset=bitOffset;
for (let x=0; x < rectWidth; x+=8, bOffset+=8) {
let i=eltOffset + (bOffset/32|0);
let mod=bOffset % 32;
let left=data[i];
if (mod <= 24) {
binaryDataArray[b++]=((left >>> (24 - mod))|0);
} else {
let delta=mod - 24;
let right=data[i + 1];
binaryDataArray[b++]=(((left << delta) | (right >>> (32 - delta)))|0);
}}
eltOffset+=lineStride;
}
}}return binaryDataArray;
}, 1);

Clazz.newMeth(C$, 'getUnpackedBinaryData$java_awt_image_Raster$java_awt_Rectangle', function (raster, rect) {
let sm=raster.getSampleModel$();
if (!C$.isBinary$java_awt_image_SampleModel(sm)) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(6).getString$S("ImageUtil0")]);
}let rectX=rect.x;
let rectY=rect.y;
let rectWidth=rect.width;
let rectHeight=rect.height;
let dataBuffer=raster.getDataBuffer$();
let dx=rectX - raster.getSampleModelTranslateX$();
let dy=rectY - raster.getSampleModelTranslateY$();
let mpp=sm;
let lineStride=mpp.getScanlineStride$();
let eltOffset=dataBuffer.getOffset$() + mpp.getOffset$I$I(dx, dy);
let bitOffset=mpp.getBitOffset$I(dx);
let bdata=Clazz.array(Byte.TYPE, [rectWidth * rectHeight]);
let maxY=rectY + rectHeight;
let maxX=rectX + rectWidth;
let k=0;
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
for (let y=rectY; y < maxY; y++) {
let bOffset=eltOffset * 8 + bitOffset;
for (let x=rectX; x < maxX; x++) {
let b=data[(bOffset/8|0)];
bdata[k++]=(((b >>> (7 - bOffset & 7)) & 1)|0);
bOffset++;
}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
for (let y=rectY; y < maxY; y++) {
let bOffset=eltOffset * 16 + bitOffset;
for (let x=rectX; x < maxX; x++) {
let s=data[(bOffset/16|0)];
bdata[k++]=(((s >>> (15 - bOffset % 16)) & 1)|0);
bOffset++;
}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
for (let y=rectY; y < maxY; y++) {
let bOffset=eltOffset * 32 + bitOffset;
for (let x=rectX; x < maxX; x++) {
let i=data[(bOffset/32|0)];
bdata[k++]=(((i >>> (31 - bOffset % 32)) & 1)|0);
bOffset++;
}
eltOffset+=lineStride;
}
}return bdata;
}, 1);

Clazz.newMeth(C$, 'setPackedBinaryData$BA$java_awt_image_WritableRaster$java_awt_Rectangle', function (binaryDataArray, raster, rect) {
let sm=raster.getSampleModel$();
if (!C$.isBinary$java_awt_image_SampleModel(sm)) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(6).getString$S("ImageUtil0")]);
}let rectX=rect.x;
let rectY=rect.y;
let rectWidth=rect.width;
let rectHeight=rect.height;
let dataBuffer=raster.getDataBuffer$();
let dx=rectX - raster.getSampleModelTranslateX$();
let dy=rectY - raster.getSampleModelTranslateY$();
let mpp=sm;
let lineStride=mpp.getScanlineStride$();
let eltOffset=dataBuffer.getOffset$() + mpp.getOffset$I$I(dx, dy);
let bitOffset=mpp.getBitOffset$I(dx);
let b=0;
if (bitOffset == 0) {
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
if (data === binaryDataArray ) {
return;
}let stride=((rectWidth + 7)/8|0);
let offset=0;
for (let y=0; y < rectHeight; y++) {
System.arraycopy$O$I$O$I$I(binaryDataArray, offset, data, eltOffset, stride);
offset+=stride;
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let xRemaining=rectWidth;
let i=eltOffset;
while (xRemaining > 8){
data[i++]=((((binaryDataArray[b++] & 255) << 8) | (binaryDataArray[b++] & 255))|0);
xRemaining-=16;
}
if (xRemaining > 0) {
data[i++]=(((binaryDataArray[b++] & 255) << 8)|0);
}eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let xRemaining=rectWidth;
let i=eltOffset;
while (xRemaining > 24){
data[i++]=(((binaryDataArray[b++] & 255) << 24) | ((binaryDataArray[b++] & 255) << 16) | ((binaryDataArray[b++] & 255) << 8) | (binaryDataArray[b++] & 255) );
xRemaining-=32;
}
let shift=24;
while (xRemaining > 0){
data[i]|=((binaryDataArray[b++] & 255) << shift);
shift-=8;
xRemaining-=8;
}
eltOffset+=lineStride;
}
}} else {
let stride=((rectWidth + 7)/8|0);
let offset=0;
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
if ((bitOffset & 7) == 0) {
for (let y=0; y < rectHeight; y++) {
System.arraycopy$O$I$O$I$I(binaryDataArray, offset, data, eltOffset, stride);
offset+=stride;
eltOffset+=lineStride;
}
} else {
let rightShift=bitOffset & 7;
let leftShift=8 - rightShift;
let leftShift8=8 + leftShift;
let mask=($b$[0] = (255 << leftShift), $b$[0]);
let mask1=($b$[0] = ~mask, $b$[0]);
for (let y=0; y < rectHeight; y++) {
let i=eltOffset;
let xRemaining=rectWidth;
while (xRemaining > 0){
let datum=binaryDataArray[b++];
if (xRemaining > leftShift8) {
data[i]=(((data[i] & mask) | ((datum & 255) >>> rightShift))|0);
data[++i]=(((datum & 255) << leftShift)|0);
} else if (xRemaining > leftShift) {
data[i]=(((data[i] & mask) | ((datum & 255) >>> rightShift))|0);
i++;
data[i]=(((data[i] & mask1) | ((datum & 255) << leftShift))|0);
} else {
let remainMask=(1 << leftShift - xRemaining) - 1;
data[i]=(((data[i] & (mask | remainMask)) | (datum & 255) >>> rightShift & ~remainMask)|0);
}xRemaining-=8;
}
eltOffset+=lineStride;
}
}} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
let rightShift=bitOffset & 7;
let leftShift=8 - rightShift;
let leftShift16=16 + leftShift;
let mask=($s$[0] = (~(255 << leftShift)), $s$[0]);
let mask1=($s$[0] = (65535 << leftShift), $s$[0]);
let mask2=($s$[0] = ~mask1, $s$[0]);
for (let y=0; y < rectHeight; y++) {
let bOffset=bitOffset;
let xRemaining=rectWidth;
for (let x=0; x < rectWidth; x+=8, bOffset+=8, xRemaining-=8) {
let i=eltOffset + (bOffset >> 4);
let mod=bOffset & 15;
let datum=binaryDataArray[b++] & 255;
if (mod <= 8) {
if (xRemaining < 8) {
datum&=255 << 8 - xRemaining;
}data[i]=(((data[i] & mask) | (datum << leftShift))|0);
} else if (xRemaining > leftShift16) {
data[i]=(((data[i] & mask1) | ((datum >>> rightShift) & 65535))|0);
data[++i]=(((datum << leftShift) & 65535)|0);
} else if (xRemaining > leftShift) {
data[i]=(((data[i] & mask1) | ((datum >>> rightShift) & 65535))|0);
i++;
data[i]=(((data[i] & mask2) | ((datum << leftShift) & 65535))|0);
} else {
let remainMask=(1 << leftShift - xRemaining) - 1;
data[i]=(((data[i] & (mask1 | remainMask)) | ((datum >>> rightShift) & 65535 & ~remainMask ))|0);
}}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
let rightShift=bitOffset & 7;
let leftShift=8 - rightShift;
let leftShift32=32 + leftShift;
let mask=-1 << leftShift;
let mask1=~mask;
for (let y=0; y < rectHeight; y++) {
let bOffset=bitOffset;
let xRemaining=rectWidth;
for (let x=0; x < rectWidth; x+=8, bOffset+=8, xRemaining-=8) {
let i=eltOffset + (bOffset >> 5);
let mod=bOffset & 31;
let datum=binaryDataArray[b++] & 255;
if (mod <= 24) {
let shift=24 - mod;
if (xRemaining < 8) {
datum&=255 << 8 - xRemaining;
}data[i]=(data[i] & (~(255 << shift))) | (datum << shift);
} else if (xRemaining > leftShift32) {
data[i]=(data[i] & mask) | (datum >>> rightShift);
data[++i]=datum << leftShift;
} else if (xRemaining > leftShift) {
data[i]=(data[i] & mask) | (datum >>> rightShift);
i++;
data[i]=(data[i] & mask1) | (datum << leftShift);
} else {
let remainMask=(1 << leftShift - xRemaining) - 1;
data[i]=(data[i] & (mask | remainMask)) | (datum >>> rightShift & ~remainMask);
}}
eltOffset+=lineStride;
}
}}}, 1);

Clazz.newMeth(C$, 'setUnpackedBinaryData$BA$java_awt_image_WritableRaster$java_awt_Rectangle', function (bdata, raster, rect) {
let sm=raster.getSampleModel$();
if (!C$.isBinary$java_awt_image_SampleModel(sm)) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(6).getString$S("ImageUtil0")]);
}let rectX=rect.x;
let rectY=rect.y;
let rectWidth=rect.width;
let rectHeight=rect.height;
let dataBuffer=raster.getDataBuffer$();
let dx=rectX - raster.getSampleModelTranslateX$();
let dy=rectY - raster.getSampleModelTranslateY$();
let mpp=sm;
let lineStride=mpp.getScanlineStride$();
let eltOffset=dataBuffer.getOffset$() + mpp.getOffset$I$I(dx, dy);
let bitOffset=mpp.getBitOffset$I(dx);
let k=0;
if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferByte")) {
let data=(dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let bOffset=eltOffset * 8 + bitOffset;
for (let x=0; x < rectWidth; x++) {
if (bdata[k++] != 0) {
data[(bOffset/8|0)]|=((1 << (7 - bOffset & 7))|0);
}bOffset++;
}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") || Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferUShort") ) {
let data=Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferShort") ? (dataBuffer).getData$() : (dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let bOffset=eltOffset * 16 + bitOffset;
for (let x=0; x < rectWidth; x++) {
if (bdata[k++] != 0) {
data[(bOffset/16|0)]|=((1 << (15 - bOffset % 16))|0);
}bOffset++;
}
eltOffset+=lineStride;
}
} else if (Clazz.instanceOf(dataBuffer, "java.awt.image.DataBufferInt")) {
let data=(dataBuffer).getData$();
for (let y=0; y < rectHeight; y++) {
let bOffset=eltOffset * 32 + bitOffset;
for (let x=0; x < rectWidth; x++) {
if (bdata[k++] != 0) {
data[(bOffset/32|0)]|=(1 << (31 - bOffset % 32));
}bOffset++;
}
eltOffset+=lineStride;
}
}}, 1);

Clazz.newMeth(C$, 'isBinary$java_awt_image_SampleModel', function (sm) {
return Clazz.instanceOf(sm, "java.awt.image.MultiPixelPackedSampleModel") && (sm).getPixelBitStride$() == 1  && sm.getNumBands$() == 1 ;
}, 1);

Clazz.newMeth(C$, 'createColorModel$java_awt_color_ColorSpace$java_awt_image_SampleModel', function (colorSpace, sampleModel) {
let colorModel=null;
if (sampleModel == null ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,[$I$(6).getString$S("ImageUtil1")]);
}let numBands=sampleModel.getNumBands$();
if (numBands < 1 || numBands > 4 ) {
return null;
}let dataType=sampleModel.getDataType$();
if (Clazz.instanceOf(sampleModel, "java.awt.image.ComponentSampleModel")) {
if (dataType < 0 || dataType > 5 ) {
return null;
}if (colorSpace == null ) colorSpace=numBands <= 2 ? $I$(1).getInstance$I(1003) : $I$(1).getInstance$I(1000);
let useAlpha=(numBands == 2) || (numBands == 4) ;
let transparency=useAlpha ? 3 : 1;
let premultiplied=false;
let dataTypeSize=$I$(7).getDataTypeSize$I(dataType);
let bits=Clazz.array(Integer.TYPE, [numBands]);
for (let i=0; i < numBands; i++) {
bits[i]=dataTypeSize;
}
colorModel=Clazz.new_($I$(3,1).c$$java_awt_color_ColorSpace$IA$Z$Z$I$I,[colorSpace, bits, useAlpha, premultiplied, transparency, dataType]);
} else if (Clazz.instanceOf(sampleModel, "java.awt.image.SinglePixelPackedSampleModel")) {
let sppsm=sampleModel;
let bitMasks=sppsm.getBitMasks$();
let rmask=0;
let gmask=0;
let bmask=0;
let amask=0;
numBands=bitMasks.length;
if (numBands <= 2) {
rmask=gmask=bmask=bitMasks[0];
if (numBands == 2) {
amask=bitMasks[1];
}} else {
rmask=bitMasks[0];
gmask=bitMasks[1];
bmask=bitMasks[2];
if (numBands == 4) {
amask=bitMasks[3];
}}let sampleSize=sppsm.getSampleSize$();
let bits=0;
for (let i=0; i < sampleSize.length; i++) {
bits+=sampleSize[i];
}
if (colorSpace == null ) colorSpace=$I$(1).getInstance$I(1000);
colorModel=Clazz.new_([colorSpace, bits, rmask, gmask, bmask, amask, false, sampleModel.getDataType$()],$I$(4,1).c$$java_awt_color_ColorSpace$I$I$I$I$I$Z$I);
} else if (Clazz.instanceOf(sampleModel, "java.awt.image.MultiPixelPackedSampleModel")) {
let bits=(sampleModel).getPixelBitStride$();
let size=1 << bits;
let comp=Clazz.array(Byte.TYPE, [size]);
for (let i=0; i < size; i++) comp[i]=(((255 * i/(size - 1)|0))|0);

colorModel=Clazz.new_($I$(5,1).c$$I$I$BA$BA$BA,[bits, size, comp, comp, comp]);
}return colorModel;
}, 1);

Clazz.newMeth(C$, 'getElementSize$java_awt_image_SampleModel', function (sm) {
let elementSize=$I$(7,"getDataTypeSize$I",[sm.getDataType$()]);
if (Clazz.instanceOf(sm, "java.awt.image.MultiPixelPackedSampleModel")) {
let mppsm=sm;
return mppsm.getSampleSize$I(0) * mppsm.getNumBands$();
} else if (Clazz.instanceOf(sm, "java.awt.image.ComponentSampleModel")) {
return sm.getNumBands$() * elementSize;
} else if (Clazz.instanceOf(sm, "java.awt.image.SinglePixelPackedSampleModel")) {
return elementSize;
}return elementSize * sm.getNumBands$();
}, 1);

Clazz.newMeth(C$, 'getTileSize$java_awt_image_SampleModel', function (sm) {
let elementSize=$I$(7,"getDataTypeSize$I",[sm.getDataType$()]);
if (Clazz.instanceOf(sm, "java.awt.image.MultiPixelPackedSampleModel")) {
let mppsm=sm;
return (mppsm.getScanlineStride$() * mppsm.getHeight$() + ((mppsm.getDataBitOffset$() + elementSize - 1)/elementSize|0)) * (((elementSize + 7)/8|0));
} else if (Clazz.instanceOf(sm, "java.awt.image.ComponentSampleModel")) {
let csm=sm;
let bandOffsets=csm.getBandOffsets$();
let maxBandOff=bandOffsets[0];
for (let i=1; i < bandOffsets.length; i++) maxBandOff=Math.max(maxBandOff, bandOffsets[i]);

let size=0;
let pixelStride=csm.getPixelStride$();
let scanlineStride=csm.getScanlineStride$();
if (maxBandOff >= 0) size+=maxBandOff + 1;
if (pixelStride > 0) size+=pixelStride * (sm.getWidth$() - 1);
if (scanlineStride > 0) size+=scanlineStride * (sm.getHeight$() - 1);
let bankIndices=csm.getBankIndices$();
maxBandOff=bankIndices[0];
for (let i=1; i < bankIndices.length; i++) maxBandOff=Math.max(maxBandOff, bankIndices[i]);

return size * (maxBandOff + 1) * (((elementSize + 7)/8|0)) ;
} else if (Clazz.instanceOf(sm, "java.awt.image.SinglePixelPackedSampleModel")) {
let sppsm=sm;
let size=sppsm.getScanlineStride$() * (sppsm.getHeight$() - 1) + sppsm.getWidth$();
return size * (((elementSize + 7)/8|0));
}return 0;
}, 1);

Clazz.newMeth(C$, 'getBandSize$java_awt_image_SampleModel', function (sm) {
let elementSize=$I$(7,"getDataTypeSize$I",[sm.getDataType$()]);
if (Clazz.instanceOf(sm, "java.awt.image.ComponentSampleModel")) {
let csm=sm;
let pixelStride=csm.getPixelStride$();
let scanlineStride=csm.getScanlineStride$();
let size=Math.min(pixelStride, scanlineStride);
if (pixelStride > 0) size+=pixelStride * (sm.getWidth$() - 1);
if (scanlineStride > 0) size+=scanlineStride * (sm.getHeight$() - 1);
return size * (((elementSize + 7)/8|0));
} else return C$.getTileSize$java_awt_image_SampleModel(sm);
}, 1);

Clazz.newMeth(C$, 'isIndicesForGrayscale$BA$BA$BA', function (r, g, b) {
if (r.length != g.length || r.length != b.length ) return false;
let size=r.length;
if (size != 256) return false;
for (let i=0; i < size; i++) {
let temp=($b$[0] = i, $b$[0]);
if (r[i] != temp || g[i] != temp  || b[i] != temp ) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'convertObjectToString$O', function (obj) {
if (obj == null ) return "";
let s="";
if (Clazz.instanceOf(obj, Clazz.array(Byte.TYPE, -1))) {
let bArray=obj;
for (let i=0; i < bArray.length; i++) s += bArray[i] + " ";

return s;
}if (Clazz.instanceOf(obj, Clazz.array(Integer.TYPE, -1))) {
let iArray=obj;
for (let i=0; i < iArray.length; i++) s += iArray[i] + " ";

return s;
}if (Clazz.instanceOf(obj, Clazz.array(Short.TYPE, -1))) {
let sArray=obj;
for (let i=0; i < sArray.length; i++) s += sArray[i] + " ";

return s;
}return obj.toString();
}, 1);

Clazz.newMeth(C$, 'canEncodeImage$javax_imageio_ImageWriter$javax_imageio_ImageTypeSpecifier', function (writer, type) {
let spi=writer.getOriginatingProvider$();
if (type != null  && spi != null   && !spi.canEncodeImage$javax_imageio_ImageTypeSpecifier(type) ) {
throw Clazz.new_(Clazz.load('javax.imageio.IIOException').c$$S,[$I$(6).getString$S("ImageUtil2") + " " + writer.getClass$().getName$() ]);
}}, 1);

Clazz.newMeth(C$, 'canEncodeImage$javax_imageio_ImageWriter$java_awt_image_ColorModel$java_awt_image_SampleModel', function (writer, colorModel, sampleModel) {
let type=null;
if (colorModel != null  && sampleModel != null  ) type=Clazz.new_($I$(8,1).c$$java_awt_image_ColorModel$java_awt_image_SampleModel,[colorModel, sampleModel]);
C$.canEncodeImage$javax_imageio_ImageWriter$javax_imageio_ImageTypeSpecifier(writer, type);
}, 1);

Clazz.newMeth(C$, 'imageIsContiguous$java_awt_image_RenderedImage', function (image) {
let sm;
if (Clazz.instanceOf(image, "java.awt.image.BufferedImage")) {
let ras=(image).getRaster$();
sm=ras.getSampleModel$();
} else {
sm=image.getSampleModel$();
}if (Clazz.instanceOf(sm, "java.awt.image.ComponentSampleModel")) {
let csm=sm;
if (csm.getPixelStride$() != csm.getNumBands$()) {
return false;
}let bandOffsets=csm.getBandOffsets$();
for (let i=0; i < bandOffsets.length; i++) {
if (bandOffsets[i] != i) {
return false;
}}
let bankIndices=csm.getBankIndices$();
for (let i=0; i < bandOffsets.length; i++) {
if (bankIndices[i] != 0) {
return false;
}}
return true;
}return C$.isBinary$java_awt_image_SampleModel(sm);
}, 1);
let $b$ = new Int8Array(1);
let $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.10-v1');//Created 2020-07-08 11:10:05 Java2ScriptVisitor version 3.2.10-v1 net.sf.j2s.core.jar version 3.2.10-v1
