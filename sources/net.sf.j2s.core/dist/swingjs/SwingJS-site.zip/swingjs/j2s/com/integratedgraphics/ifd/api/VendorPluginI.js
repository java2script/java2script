(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd.api"),I$=[[0,'java.util.ArrayList','org.iupac.fairdata.contrib.fairspec.FAIRSpecUtilities','com.integratedgraphics.ifd.Extractor',['com.integratedgraphics.ifd.api.VendorPluginI','.VendorInfo']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*i*/var C$=Clazz.newInterface(P$, "VendorPluginI", function(){
}, null, 'org.iupac.fairdata.extract.PropertyManagerI');
C$.$classes$=[['VendorInfo',9]];

C$.$clinit$=2;

C$.$fields$=[[]
,['O',['vendorPlugins','java.util.List','+activeVendors']]]

Clazz.newMeth(C$, 'init$',  function () {
if (C$.activeVendors.size$() > 0) return;
var vendors=null;
try {
vendors=$I$(2,"getJSONResource$Class$S",[Clazz.getClass($I$(3)), "extractor.config.json"]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
return;
} else {
throw e;
}
}
var knownVendors=vendors.get$O("knownVendors");
for (var i=0, n=knownVendors.size$(); i < n; i++) {
var sv=knownVendors.get$I(i);
var v;
try {
v=Clazz.forName(sv).getDeclaredConstructor$ClassA(Clazz.array(Class, -1, [])).newInstance$OA(Clazz.array(java.lang.Object, -1, []));
if (v.isEnabled$()) {
C$.addVendor$com_integratedgraphics_ifd_api_VendorPluginI(v);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("! IFDVendorPluginI Trying to instatiation of " + sv + " failed." );
e.printStackTrace$java_io_PrintStream(System.err);
} else {
throw e;
}
}
}
}, 1);

Clazz.newMeth(C$, 'addVendor$com_integratedgraphics_ifd_api_VendorPluginI',  function (v) {
C$.activeVendors.add$O(Clazz.new_([v, C$.activeVendors.size$()],$I$(4,1).c$$com_integratedgraphics_ifd_api_VendorPluginI$I));
System.out.println$S("! IFDVendorPluginI vendorPlugin " + v.getClass$().getName$() + " active" );
}, 1);

Clazz.newMeth(C$, 'registerIFDVendorPlugin$Class',  function (plugin) {
try {
var v=plugin.getDeclaredConstructor$ClassA(Clazz.array(Class, -1, [])).newInstance$OA(Clazz.array(java.lang.Object, -1, []));
C$.vendorPlugins.add$O(v);
System.out.println$S("! IFDVendorPluginI vendorPlugin " + plugin + " registered" );
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.vendorPlugins=Clazz.new_($I$(1,1));
C$.activeVendors=Clazz.new_($I$(1,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.VendorPluginI, "VendorInfo", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index'],'S',['vrezip','vcache'],'O',['vendor','com.integratedgraphics.ifd.api.VendorPluginI']]]

Clazz.newMeth(C$, 'c$$com_integratedgraphics_ifd_api_VendorPluginI$I',  function (vendor, index) {
;C$.$init$.apply(this);
this.vendor=vendor;
this.index=index;
vendor.setIndex$I(index);
var p=vendor.getRezipRegex$();
this.vrezip=(p == null  ? null : "(?<rezip" + index + ">" + p + ")" );
p=vendor.getParamRegex$();
this.vcache=(p == null  ? null : "(?<param" + index + ">" + p + ")" );
}, 1);

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-23 05:42:35 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
