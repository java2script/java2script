(function(){var P$=Clazz.newPackage("com.sun.xml.bind"),I$=[];
var C$=Clazz.newClass(P$, "IDResolver");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'startDocument$javax_xml_bind_ValidationEventHandler', function (eventHandler) {
});

Clazz.newMeth(C$, 'endDocument$', function () {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-09 06:44:52 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
