(function(){var P$=Clazz.newPackage("com.sun.xml.bind"),I$=[[0,'java.util.logging.Logger']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Util");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getClassLogger$', function () {
try {
var trace=Clazz.new_(Clazz.load('Exception')).getStackTrace$();
return Clazz.load('java.util.logging.Logger').getLogger$S(trace[1].getClassName$());
} catch (e) {
if (Clazz.exceptionOf(e,"SecurityException")){
return $I$(1).getLogger$S("com.sun.xml.bind");
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getSystemProperty$S', function (name) {
try {
return System.getProperty$S(name);
} catch (e) {
if (Clazz.exceptionOf(e,"SecurityException")){
return null;
} else {
throw e;
}
}
}, 1);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-09 06:44:53 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
