(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd"),I$=[[0,'com.integratedgraphics.ifd.Extractor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExtractorTest", null, 'com.integratedgraphics.ifd.Extractor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'setSourceTargetArgs$SA$S$S$S',  function (args, sourceArchive, targetDir, flags) {
var a=Clazz.array(String, [4]);
if (args.length > 0) a[0]=args[0];
if (args.length < 2 || args[1] == null  ) a[1]=sourceArchive;
if (args.length < 3 || args[2] == null  ) a[2]=targetDir;
if (args.length < 4 || args[3] == null  ) a[3]=flags;
return a;
}, 1);

Clazz.newMeth(C$, 'runTests$SA',  function (args) {
C$.runUCLTest$SA(args);
}, 1);

Clazz.newMeth(C$, 'runUCLTest$SA',  function (args) {
var testSet=Clazz.array(String, -1, ["c:/temp/henry/v6/IFD-extract.json"]);
var sourceArchive="c:/temp/henry/v6/archive.tar.gz";
var targetDir="c:/temp/henry/v6/ifd";
args=C$.setSourceTargetArgs$SA$S$S$S(args, sourceArchive, targetDir, "-cleanTargetDir");
$I$(1).runExtraction$SA$SA$I$I(args, testSet, -1, -1);
}, 1);

Clazz.newMeth(C$, 'runACSTest$SA',  function (args) {
var testSet=Clazz.array(String, -1, ["22567817#./extract/acs.joc.0c00770/IFD-extract.json", "21947274#./extract/acs.orglett.0c00624/IFD-extract.json", "22125318#./extract/acs.orglett.0c00788/IFD-extract.json", "22233351#./extract/acs.orglett.0c00874/IFD-extract.json", "22111341#./extract/acs.orglett.0c00967/IFD-extract.json", "22195341#./extract/acs.orglett.0c01022/IFD-extract.json", "22491647#./extract/acs.orglett.0c01197/IFD-extract.json", "22613762#./extract/acs.orglett.0c01277/IFD-extract.json", "22612484#./extract/acs.orglett.0c01297/IFD-extract.json", "22150197#./extract/acs.orglett.0c00755/IFD-extract.json", "22284726,22284729#./extract/acs.orglett.0c01153/IFD-extract.json", "21975525#./extract/acs.orglett.0c00571/IFD-extract.json", "22232721#./extract/acs.orglett.0c01043/IFD-extract.json"]);
var first=0;
var last=0;
var sourceArchive="c:/temp/iupac/zip";
var targetDir="c:/temp/iupac/ifd";
args=C$.setSourceTargetArgs$SA$S$S$S(args, sourceArchive, targetDir, "-datacitedown;-cleanTargetDir");
$I$(1).runExtraction$SA$SA$I$I(args, testSet, first, last);
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.runTests$SA(args);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-21 14:29:55 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
