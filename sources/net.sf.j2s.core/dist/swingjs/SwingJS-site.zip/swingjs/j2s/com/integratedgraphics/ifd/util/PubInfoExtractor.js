(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd.util"),I$=[[0,'java.util.LinkedHashMap','org.iupac.fairdata.util.JSJSONParser','org.iupac.fairdata.contrib.fairspec.FAIRSpecUtilities']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PubInfoExtractor");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getCrossrefMetadataUrl$S',  function (puburi) {
if (puburi != null  && puburi.startsWith$S("https://doi.org/") ) {
return "https://api.crossref.org/works/" + puburi.substring$I(16);
}return null;
}, 1);

Clazz.newMeth(C$, 'getCrossciteMetadataUrl$S',  function (puburi) {
if (puburi != null  && puburi.startsWith$S("https://doi.org/") ) {
return "https://api.datacite.org/dois/" + puburi.substring$I(16);
}return null;
}, 1);

Clazz.newMeth(C$, 'getPubInfo$S$Z',  function (puburi, addPublicationMetadata) {
if (puburi == null ) return null;
var info=Clazz.new_($I$(1,1));
var map=Clazz.new_($I$(1,1));
var dataCite=null;
var crossRef=null;
var crUrl=C$.getCrossrefMetadataUrl$S(puburi);
System.out.println$S("PubInfoExtractor: " + crUrl);
try {
crossRef=Clazz.new_($I$(2,1)).parseMap$S$Z($I$(3).getURLContentsAsString$S(crUrl), false);
if (crossRef != null ) {
C$.extractCrossRefInfo$java_util_Map$java_util_Map(info, crossRef);
map=Clazz.new_($I$(1,1));
map.put$O$O("registrationAgency", "Crossref");
map.put$O$O("metadataUrl", crUrl);
if (addPublicationMetadata) map.put$O$O("metadata", crossRef);
}} catch (t) {
crossRef=null;
System.err.println$O(t);
}
if (crossRef == null ) {
var dcUrl=C$.getCrossciteMetadataUrl$S(puburi);
System.out.println$S("PubInfoExtractor: " + dcUrl);
try {
dataCite=$I$(3).getJSONURL$S(dcUrl);
if (dataCite != null ) {
C$.extractCrossCiteInfo$java_util_Map$java_util_Map(info, dataCite);
map=Clazz.new_($I$(1,1));
map.put$O$O("registrationAgency", "DataCite");
map.put$O$O("metadataUrl", dcUrl);
if (addPublicationMetadata) map.put$O$O("metadata", dataCite);
}} catch (t) {
System.err.println$O(t);
}
}C$.put$java_util_Map$S$O(info, "metadataSource", map);
return info;
}, 1);

Clazz.newMeth(C$, 'extractCrossRefInfo$java_util_Map$java_util_Map',  function (info, json) {
info.clear$();
var message=C$.getMap$java_util_Map$SA(json, Clazz.array(String, -1, ["message"]));
var title=C$.getValue$java_util_Map$S$S(message, "title", null);
C$.put$java_util_Map$S$O(info, "title", title);
var doi=C$.getObject$java_util_Map$SA(message, Clazz.array(String, -1, ["published-print", "DOI"]));
var author=C$.getList$java_util_Map$SA(message, Clazz.array(String, -1, ["author"]));
var s="";
if (author != null ) for (var i=0; i < author.size$(); i++) {
var au=author.get$I(i);
var name=C$.getValue$java_util_Map$S$S(au, "given", "") + " " + C$.getValue$java_util_Map$S$S(au, "family", "") ;
s+=", " + name;
}
if (s.length$() > 0) {
C$.put$java_util_Map$S$O(info, "authors", s.substring$I(2));
}C$.put$java_util_Map$S$O(info, "doi", doi);
C$.put$java_util_Map$S$O(info, "url", (C$.getList$java_util_Map$SA(message, Clazz.array(String, -1, ["link"])).get$I(0)).get$O("URL"));
}, 1);

Clazz.newMeth(C$, 'extractCrossCiteInfo$java_util_Map$java_util_Map',  function (info, crossCite) {
C$.put$java_util_Map$S$O(info, "title", (C$.getList$java_util_Map$SA(crossCite, Clazz.array(String, -1, ["titles"])).get$I(0)).get$O("title"));
var s="";
var creators=C$.getList$java_util_Map$SA(crossCite, Clazz.array(String, -1, ["creators"]));
for (var i=0; i < creators.size$(); i++) {
var au=creators.get$I(i);
var name=C$.getValue$java_util_Map$S$S(au, "givenName", "") + " " + C$.getValue$java_util_Map$S$S(au, "familyName", "") ;
s+=", " + name.trim$();
}
if (s.length$() > 0) {
C$.put$java_util_Map$S$O(info, "authors", s.substring$I(2));
}C$.put$java_util_Map$S$O(info, "doi", C$.getValue$java_util_Map$S$S(crossCite, "doi", ""));
C$.put$java_util_Map$S$O(info, "url", C$.getValue$java_util_Map$S$S(crossCite, "url", ""));
}, 1);

Clazz.newMeth(C$, 'put$java_util_Map$S$O',  function (info, key, value) {
if (value != null ) info.put$O$O(key, value);
}, 1);

Clazz.newMeth(C$, 'getValue$java_util_Map$S$S',  function (au, key, defValue) {
var o=au.get$O(key);
return (o == null  ? defValue : o.toString());
}, 1);

Clazz.newMeth(C$, 'getMap$java_util_Map$SA',  function (json, keys) {
return C$.getObject$java_util_Map$SA(json, keys);
}, 1);

Clazz.newMeth(C$, 'getList$java_util_Map$SA',  function (json, keys) {
return C$.getObject$java_util_Map$SA(json, keys);
}, 1);

Clazz.newMeth(C$, 'getObject$java_util_Map$SA',  function (json, keys) {
for (var i=0; i < keys.length - 1; i++) {
json=json.get$O(keys[i]);
}
return json.get$O(keys[keys.length - 1]);
}, 1);

Clazz.newMeth(C$, 'extractOuterXML$S$S',  function (key, xml) {
if (xml == null ) return null;
var p=xml.indexOf$S("<" + key);
var p2=key.indexOf$S(" ");
p2=xml.indexOf$S$I("</" + (p2 < 0 ? key : key.substring$I$I(0, p2)) + (key.endsWith$S(">") ? "" : ">") , p);
if (p2 < 0) return null;
p2=xml.indexOf$S$I(">", p2) + 1;
return xml.substring$I$I(p, p2);
}, 1);

Clazz.newMeth(C$, 'extractXML$S$S$IA',  function (key, xml, pt) {
if (xml == null ) return null;
if (pt == null ) pt=Clazz.array(Integer.TYPE, [1]);
var p=xml.indexOf$S$I("<" + key, pt[0]);
if (p < 0 || (p=xml.indexOf$S$I(">", p) + 1) <= 0 ) return null;
var p2=key.indexOf$S(" ");
p2=xml.indexOf$S$I("</" + (p2 < 0 ? key : key.substring$I$I(0, p2)) + (key.endsWith$S(">") ? "" : ">") , p);
if (p2 < 0) return null;
pt[0]=p2 + key.length$() + 2 ;
return xml.substring$I$I(p, p2);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-23 05:42:35 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
