Integrated Graphics is a registered business assumed name
registered in the state of Minnesota by Robert Hanson.

