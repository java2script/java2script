(function(){var P$=Clazz.newPackage("com.baeldung.doublecolon.function"),I$=[];
var C$=Clazz.newInterface(P$, "ComputerPredicate");
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 11:42:54 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
