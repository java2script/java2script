(function(){var P$=Clazz.newPackage("com.sun.jna"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Library");
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-17 16:36:45 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
