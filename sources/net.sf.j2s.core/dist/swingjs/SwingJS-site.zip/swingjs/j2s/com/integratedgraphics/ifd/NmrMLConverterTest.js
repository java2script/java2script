(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd"),I$=[[0,'com.integratedgraphics.ifd.vendor.varian.NmrMLVarianAcquStreamReader','org.iupac.fairdata.contrib.fairspec.FAIRSpecUtilities','java.io.FileInputStream','com.integratedgraphics.ifd.vendor.jeol.NmrMLJeolAcquStreamReader','java.io.File','com.integratedgraphics.ifd.util.DefaultVendorPlugin']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NmrMLConverterTest");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
try {
var fis;
var acq;
fis=C$.newStream$S("test/varian/sucrose_1h/procpar");
var varian=Clazz.new_($I$(1,1).c$$java_io_InputStream,[fis]);
acq=varian.read$();
fis.close$();
C$.setParams$I$org_nmrml_parser_Acqu(varian.getDimension$(), acq);
fis=C$.newStream$S("test/varian/agilent_2d/procpar");
varian=Clazz.new_($I$(1,1).c$$java_io_InputStream,[fis]);
acq=varian.read$();
fis.close$();
C$.setParams$I$org_nmrml_parser_Acqu(varian.getDimension$(), acq);
var filename="test/jeol/1d_1d-13C.jdf";
var bytes=$I$(2,"getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z",[Clazz.new_($I$(3,1).c$$S,[filename]), -1, null, true, true]);
var jeol=Clazz.new_($I$(4,1).c$$BA,[bytes]);
acq=jeol.read$();
fis.close$();
C$.setParams$I$org_nmrml_parser_Acqu(jeol.getDimension$(), acq);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'newStream$S',  function (f) {
var inputFolder=Clazz.new_($I$(5,1).c$$S,[f]).getAbsolutePath$();
return Clazz.new_($I$(3,1).c$$S,[inputFolder]);
}, 1);

Clazz.newMeth(C$, 'setParams$I$org_nmrml_parser_Acqu',  function (dim, acq) {
C$.report$S$O("DIM", Integer.valueOf$I(dim));
var freq=acq.getTransmiterFreq$();
C$.report$S$O("F1", Double.valueOf$D(freq));
var nuc=acq.getObservedNucleus$();
nuc=$I$(6).fixNucleus$S(nuc);
C$.report$S$O("N1", nuc);
var nominalFreq=$I$(6).getNominalFrequency$D$S(freq, nuc);
C$.report$S$O("SF", Integer.valueOf$I(nominalFreq));
var solvent=acq.getSolvent$();
C$.report$S$O("SOLVENT", solvent);
var pp=acq.getPulseProgram$();
C$.report$S$O("PP", pp);
var probe=acq.getProbehead$();
C$.report$S$O("PROBE", probe);
}, 1);

Clazz.newMeth(C$, 'report$S$O',  function (key, val) {
System.out.println$S(key + " = " + val );
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-23 05:42:35 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
