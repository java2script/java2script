(function(){var P$=Clazz.newPackage("com.sun.xml.bind"),I$=[[0,['com.sun.xml.bind.v2.runtime.reflect.Accessor','.ReadOnlyFieldReflection'],['com.sun.xml.bind.v2.runtime.reflect.Accessor','.FieldReflection'],['com.sun.xml.bind.v2.runtime.reflect.Accessor','.SetterOnlyReflection'],['com.sun.xml.bind.v2.runtime.reflect.Accessor','.GetterOnlyReflection'],['com.sun.xml.bind.v2.runtime.reflect.Accessor','.GetterSetterReflection']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "AccessorFactoryImpl", null, null, 'com.sun.xml.bind.InternalAccessorFactory');
C$.instance=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.instance=Clazz.new_(C$);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getInstance$', function () {
return C$.instance;
}, 1);

Clazz.newMeth(C$, 'createFieldAccessor$Class$reflect_Field$Z', function (bean, field, readOnly) {
return readOnly ? Clazz.new_(Clazz.load(['com.sun.xml.bind.v2.runtime.reflect.Accessor','.ReadOnlyFieldReflection']).c$$reflect_Field,[field]) : Clazz.new_(Clazz.load(['com.sun.xml.bind.v2.runtime.reflect.Accessor','.FieldReflection']).c$$reflect_Field,[field]);
});

Clazz.newMeth(C$, 'createFieldAccessor$Class$reflect_Field$Z$Z', function (bean, field, readOnly, supressWarning) {
return readOnly ? Clazz.new_($I$(1).c$$reflect_Field$Z,[field, supressWarning]) : Clazz.new_($I$(2).c$$reflect_Field$Z,[field, supressWarning]);
});

Clazz.newMeth(C$, 'createPropertyAccessor$Class$reflect_Method$reflect_Method', function (bean, getter, setter) {
if (getter == null ) {
return Clazz.new_(Clazz.load(['com.sun.xml.bind.v2.runtime.reflect.Accessor','.SetterOnlyReflection']).c$$reflect_Method,[setter]);
}if (setter == null ) {
return Clazz.new_(Clazz.load(['com.sun.xml.bind.v2.runtime.reflect.Accessor','.GetterOnlyReflection']).c$$reflect_Method,[getter]);
}return Clazz.new_(Clazz.load(['com.sun.xml.bind.v2.runtime.reflect.Accessor','.GetterSetterReflection']).c$$reflect_Method$reflect_Method,[getter, setter]);
});
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-09 06:44:51 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
