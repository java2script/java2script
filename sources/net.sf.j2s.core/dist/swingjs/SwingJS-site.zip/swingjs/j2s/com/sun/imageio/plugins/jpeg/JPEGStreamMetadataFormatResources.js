(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.jpeg"),I$=[[0,'com.sun.imageio.plugins.jpeg.JPEGMetadataFormatResources']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JPEGStreamMetadataFormatResources", null, 'com.sun.imageio.plugins.jpeg.JPEGMetadataFormatResources');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getContents$',  function () {
var commonCopy=Clazz.array(java.lang.Object, [$I$(1).commonContents.length, 2]);
for (var i=0; i < $I$(1).commonContents.length; i++) {
commonCopy[i][0]=$I$(1).commonContents[i][0];
commonCopy[i][1]=$I$(1).commonContents[i][1];
}
return commonCopy;
});
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:50:09 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
