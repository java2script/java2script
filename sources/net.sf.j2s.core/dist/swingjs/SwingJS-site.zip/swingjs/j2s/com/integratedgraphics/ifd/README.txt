package com.integratedgraphics.ifd 

Preliminary Java/SwingJS implementation of developing IUPAC FAIRSpec specifications 
for the FAIR management of spectroscopic data in chemistry.

 Copyright 2021 Integrated Graphics and Robert M. Hanson

