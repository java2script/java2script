(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd"),p$1={},I$=[[0,'java.io.BufferedInputStream','org.iupac.fairdata.util.ZipUtil','java.util.zip.ZipInputStream',['com.integratedgraphics.ifd.Extractor','.ArchiveEntry'],'java.util.Arrays','java.util.ArrayList','StringBuffer','java.util.regex.Pattern','com.integratedgraphics.ifd.Extractor','org.iupac.fairdata.common.IFDConst','org.iupac.fairdata.contrib.fairspec.FAIRSpecUtilities','java.util.LinkedHashMap','org.iupac.fairdata.contrib.fairspec.FAIRSpecFindingAid','com.integratedgraphics.ifd.api.VendorPluginI',['com.integratedgraphics.ifd.Extractor','.FileList'],'java.util.BitSet','com.integratedgraphics.ifd.util.PubInfoExtractor','org.iupac.fairdata.util.IFDDefaultJSONSerializer','org.iupac.fairdata.extract.DefaultStructureHelper','org.iupac.fairdata.util.JSJSONParser','org.iupac.fairdata.contrib.fairspec.FAIRSpecExtractorHelper','java.net.URL','java.io.File','org.apache.commons.io.FileUtils','java.io.FileOutputStream','java.io.FileInputStream',['com.integratedgraphics.ifd.Extractor','.ObjectParser'],['com.integratedgraphics.ifd.Extractor','.ArchiveInputStream'],'java.io.ByteArrayOutputStream',['com.integratedgraphics.ifd.Extractor','.CacheRepresentation'],'org.iupac.fairdata.core.IFDReference','java.util.HashMap',['com.integratedgraphics.ifd.Extractor','.AWrap'],'java.util.zip.ZipOutputStream','java.util.zip.ZipEntry']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Extractor", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'org.iupac.fairdata.extract.ExtractorI');
C$.$classes$=[['ArchiveEntry',10],['ArchiveInputStream',10],['CacheRepresentation',10],['AWrap',10],['FileList',10],['ObjectParser',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.debugging=false;
this.readOnly=false;
this.createFindingAidsOnly=false;
this.allowNoPubInfo=true;
this.skipPubInfo=false;
this.addPublicationMetadata=false;
this.createZippedCollection=true;
this.IFDZipContents=Clazz.new_($I$(12,1));
this.products=Clazz.new_($I$(6,1));
this.lstManifest=Clazz.new_($I$(15,1).c$$S,["manifest"]);
this.lstIgnored=Clazz.new_($I$(15,1).c$$S,["ignored"]);
this.lstRejected=Clazz.new_($I$(15,1).c$$S,["rejected"]);
this.htLocalizedNameToObject=Clazz.new_($I$(12,1));
this.htZipRenamed=Clazz.new_($I$(12,1));
this.bsRezipVendors=Clazz.new_($I$(16,1));
this.bsPropertyVendors=Clazz.new_($I$(16,1));
this.includeIgnoredFiles=true;
this.errorLog="";
this.testID=-1;
this.dataciteUp=true;
this.cleanCollectionDir=true;
},1);

C$.$fields$=[['Z',['stopOnAnyFailure','debugReadOnly','debugging','readOnly','createFindingAidsOnly','allowNoPubInfo','skipPubInfo','addPublicationMetadata','createZippedCollection','cachePatternHasVendors','noOutput','includeIgnoredFiles','haveExtracted','isAssociationByID','dataciteUp','cleanCollectionDir'],'I',['ifdObjectCount','warnings','errors','testID'],'J',['extractedByteCount'],'S',['extractScript','extractVersion','sourceDir','rootPath','localizedName','originPath','currentRezipPath','lastRezipPath','resource','resourceList','localizedTopLevelZipURL','ifdid','errorLog'],'O',['helper','org.iupac.fairdata.contrib.fairspec.FAIRSpecExtractorHelperI','objectParsers','java.util.List','IFDZipContents','java.util.Map','targetDir','java.io.File','cachePattern','java.util.regex.Pattern','products','java.util.List','currentRezipRepresentation','org.iupac.fairdata.core.IFDRepresentation','currentRezipVendor','com.integratedgraphics.ifd.api.VendorPluginI','rezipCache','java.util.List','lstManifest','com.integratedgraphics.ifd.Extractor.FileList','+lstIgnored','+lstRejected','htLocalizedNameToObject','java.util.Map','+htZipRenamed','+cache','deferredPropertyList','java.util.List','bsRezipVendors','java.util.BitSet','+bsPropertyVendors','rezipCachePattern','java.util.regex.Pattern','structurePropertyManager','org.iupac.fairdata.extract.PropertyManagerI','htStructureRepCache','java.util.Map','currentZipFile','java.io.File','currentZipStream','java.io.InputStream']]
,['S',['IFD_PROPERTY_DATAOBECT_NOTE'],'O',['objectDefPattern','java.util.regex.Pattern','+pStarDotStar']]]

Clazz.newMeth(C$, 'getWarningCount$',  function () {
return this.warnings;
});

Clazz.newMeth(C$, 'getErrorCount$',  function () {
return this.errors;
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.setDefaultRunParams$();
this.getStructurePropertyManager$();
this.noOutput=(this.createFindingAidsOnly || this.readOnly );
}, 1);

Clazz.newMeth(C$, 'run$S$java_io_File$java_io_File$S',  function (key, ifdExtractScriptFile, targetDir, localsourceArchive) {
this.log$S("!Extractor\n ifdExtractScriptFIle= " + ifdExtractScriptFile + "\n localsourceArchive = " + localsourceArchive + "\n targetDir = " + targetDir.getAbsolutePath$() );
var findingAidFileName=(key == null  ? "" : key);
if (this.extractAndCreateFindingAid$java_io_File$S$java_io_File$S(ifdExtractScriptFile, localsourceArchive, targetDir, findingAidFileName) == null  && !this.allowNoPubInfo ) {
throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["Extractor failed"]);
}this.log$S("!Extractor extracted " + this.lstManifest.size$() + " files (" + Long.$s(this.lstManifest.getByteCount$()) + " bytes)" + "; ignored " + this.lstIgnored.size$() + " files (" + Long.$s(this.lstIgnored.getByteCount$()) + " bytes)" + "; rejected " + this.lstRejected.size$() + " files (" + Long.$s(this.lstRejected.getByteCount$()) + " bytes)" );
});

Clazz.newMeth(C$, 'extractAndCreateFindingAid$java_io_File$S$java_io_File$S',  function (ifdExtractScriptFile, localArchive, targetDir, findingAidFileNameRoot) {
this.getObjectParsersForFile$java_io_File(ifdExtractScriptFile);
var puburi=null;
var pubCrossrefInfo=null;
puburi=this.helper.getFindingAid$().getPropertyValue$S($I$(10).IFD_PROPERTY_COLLECTIONSET_SOURCE_PUBLICATION_URI);
if (puburi != null  && !this.skipPubInfo ) {
pubCrossrefInfo=$I$(17).getPubInfo$S$Z(puburi, this.addPublicationMetadata);
if (pubCrossrefInfo == null  || pubCrossrefInfo.get$O("title") == null  ) {
if (this.skipPubInfo) {
this.logWarn$S$S("skipPubInfo == true; Finding aid does not contain PubInfo", "extractAndCreateFindingAid");
} else {
if (!this.allowNoPubInfo) {
this.logErr$S$S("Finding aid does not contain PubInfo! No internet? cannot continue", "extractAndCreateFindingAid");
return null;
}this.logWarn$S$S("Could not access " + $I$(17).getCrossrefMetadataUrl$S(puburi), "extractAndCreateFindingAid");
}} else {
var list=Clazz.new_($I$(6,1));
list.add$O(pubCrossrefInfo);
this.helper.getFindingAid$().setCitations$java_util_List(list);
}}this.setLocalSourceDir$S(localArchive);
this.setCachePattern$S(null);
this.setRezipCachePattern$S$S(null, null);
this.extractObjects$java_io_File(targetDir);
this.log$S("!Extractor.extractAndCreateFindingAid serializing...");
var ser=this.getSerializer$();
var times=Clazz.array(Long.TYPE, [3]);
var s=this.helper.createSerialization$java_io_File$S$java_util_List$org_iupac_fairdata_api_IFDSerializerI$JA((this.noOutput && !this.createFindingAidsOnly  ? null : targetDir), findingAidFileNameRoot, this.createZippedCollection ? this.products : null, ser, times);
this.log$S("!Extractor serialization done " + Long.$s(times[0]) + " " + Long.$s(times[1]) + " " + Long.$s(times[2]) + " ms " + s.length$() + " bytes" );
return s;
});

Clazz.newMeth(C$, 'getSerializer$',  function () {
return Clazz.new_($I$(18,1));
});

Clazz.newMeth(C$, 'setLocalSourceDir$S',  function (sourceDir) {
if (sourceDir != null  && sourceDir.indexOf$S("://") < 0 ) sourceDir="file:///" + sourceDir;
this.sourceDir=sourceDir;
});

Clazz.newMeth(C$, 'getFindingAid$',  function () {
return this.helper.getFindingAid$();
});

Clazz.newMeth(C$, 'setCachePattern$S',  function (sp) {
if (sp == null ) sp="(?<img>\\.pdf$|\\.png$)" + "|" + this.structurePropertyManager.getParamRegex$() ;
var s="";
for (var i=0; i < $I$(14).activeVendors.size$(); i++) {
var cp=$I$(14).activeVendors.get$I(i).vcache;
if (cp != null ) {
this.bsPropertyVendors.set$I(i);
s+="|" + cp;
}}
if (s.length$() > 0) {
s="(?<param>" + s.substring$I(1) + ")|" + sp ;
this.cachePatternHasVendors=true;
} else {
s=sp;
}this.cachePattern=$I$(8,"compile$S",["(?<ext>" + s + ")" ]);
this.cache=Clazz.new_($I$(12,1));
});

Clazz.newMeth(C$, 'getPropertyManager$java_util_regex_Matcher',  function (m) {
if (m.group$S("struc") != null ) return this.structurePropertyManager;
for (var i=this.bsPropertyVendors.nextSetBit$I(0); i >= 0; i=this.bsPropertyVendors.nextSetBit$I(i + 1)) {
var ret=m.group$S("param" + i);
if (ret != null  && ret.length$() > 0 ) {
return $I$(14).activeVendors.get$I(i).vendor;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'setRezipCachePattern$S$S',  function (procs, toExclude) {
var s="";
for (var i=0; i < $I$(14).activeVendors.size$(); i++) {
var cp=$I$(14).activeVendors.get$I(i).vrezip;
if (cp != null ) {
this.bsRezipVendors.set$I(i);
s=s + "|" + cp ;
}}
s+=(procs == null  ? "" : "|" + procs);
if (s.length$() > 0) s=s.substring$I(1);
this.rezipCachePattern=$I$(8).compile$S(s);
this.rezipCache=Clazz.new_($I$(6,1));
});

Clazz.newMeth(C$, 'getStructurePropertyManager$',  function () {
return (this.structurePropertyManager == null  ? (this.structurePropertyManager=Clazz.new_($I$(19,1).c$$org_iupac_fairdata_extract_ExtractorI,[this])) : this.structurePropertyManager);
});

Clazz.newMeth(C$, 'getObjectParsersForFile$java_io_File',  function (ifdExtractScript) {
this.log$S("!Extracting " + ifdExtractScript.getAbsolutePath$());
return this.getObjectsForStream$java_io_InputStream(ifdExtractScript.toURI$().toURL$().openStream$());
});

Clazz.newMeth(C$, 'getObjectsForStream$java_io_InputStream',  function (is) {
this.extractScript= String.instantialize($I$(11).getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z(is, -1, null, true, true));
this.objectParsers=this.parseScript$S(this.extractScript);
return this.objectParsers;
});

Clazz.newMeth(C$, 'parseScript$S',  function (script) {
if (this.helper != null ) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["Only one finding aid per instance of Extractor is allowed (for now)."]);
this.helper=p$1.newExtractionHelper.apply(this, []);
var jsonMap=Clazz.new_($I$(20,1)).parse$S$Z(script, false);
if (this.debugging) this.log$S(jsonMap.toString());
this.extractVersion=jsonMap.get$O($I$(21).FAIRSPEC_EXTRACT_VERSION);
if (C$.logging$()) this.log$S(this.extractVersion);
var objectParsers=this.getObjectParsers$java_util_List(jsonMap.get$O("keys"));
if (C$.logging$()) this.log$S(objectParsers.size$() + " extractor regex strings");
this.log$S("!license: " + this.helper.getFindingAid$().getPropertyValue$S($I$(10).IFD_PROPERTY_COLLECTIONSET_SOURCE_DATA_LICENSE_NAME) + " at " + this.helper.getFindingAid$().getPropertyValue$S($I$(10).IFD_PROPERTY_COLLECTIONSET_SOURCE_DATA_LICENSE_URI) );
return objectParsers;
});

Clazz.newMeth(C$, 'newExtractionHelper',  function () {
return Clazz.new_($I$(21,1).c$$org_iupac_fairdata_extract_ExtractorI$S,[this, "https://github.com/IUPAC/IUPAC-FAIRSpec/blob/main/src/main/java/com/integratedgraphics/ifd/Extractor.java 0.0.3-alpha+2022.11.21"]);
}, p$1);

Clazz.newMeth(C$, 'getObjectParsers$java_util_List',  function (pathway) {
var keys=Clazz.new_($I$(6,1));
var values=Clazz.new_($I$(6,1));
var parsers=Clazz.new_($I$(6,1));
var ignore="";
var reject="";
for (var i=0; i < pathway.size$(); i++) {
var def=pathway.get$I(i);
for (var e, $e = def.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var key=e.getKey$();
if (key.startsWith$S("#")) continue;
var val=e.getValue$();
if (val.indexOf$S("{") >= 0) {
var s=$I$(11).replaceStrings$S$java_util_List$java_util_List(val, keys, values);
if (!s.equals$O(val)) {
if (this.debugging) this.log$S(val + "\n" + s + "\n" );
e.setValue$O(s);
}val=s;
}var keyDef=null;
var pt=key.indexOf$S("=");
if (pt > 0) {
keyDef=key.substring$I$I(0, pt);
key=key.substring$I(pt + 1);
}if (key.equals$O($I$(21).IFD_EXTRACTOR_OBJECT)) {
parsers.add$O(this.newObjectParser$S(val));
continue;
}if (key.equals$O($I$(21).IFD_EXTRACTOR_ASSIGN)) {
parsers.get$I(parsers.size$() - 1).addAssignment$S(val);
continue;
}if (key.equals$O($I$(21).IFD_EXTRACTOR_REJECT)) {
reject+="(" + val + ")|" ;
continue;
}if (key.equals$O($I$(21).IFD_EXTRACTOR_IGNORE)) {
ignore+="|(" + val + ")" ;
continue;
}if (key.startsWith$S($I$(21).IFD_EXTRACTOR_FLAG) || key.equals$O($I$(21).IFD_EXTRACTOR_FLAGS) ) {
p$1.setExtractorFlag$S$S.apply(this, [key, val]);
continue;
}if (key.startsWith$S($I$(10).IFD_PROPERTY_FLAG)) {
if (key.equals$O($I$(10).IFD_PROPERTY_COLLECTIONSET_ID)) {
this.ifdid=val;
this.helper.getFindingAid$().setID$S(val);
}this.helper.getFindingAid$().setPropertyValue$S$O(key, val);
if (keyDef == null ) continue;
}keys.add$O("{" + (keyDef == null  ? key : keyDef) + "}" );
values.add$O(val);
}
}
this.lstRejected.setAcceptPattern$S(reject + $I$(21).junkFilePattern);
if (ignore.length$() > 0) this.lstIgnored.setAcceptPattern$S(ignore.substring$I(1));
return parsers;
});

Clazz.newMeth(C$, 'setExtractorFlag$S$S',  function (key, val) {
if (key.equals$O($I$(21).IFD_EXTRACTOR_FLAG_ASSOCIATION_BYID)) this.helper.setAssociationsById$Z(this.isAssociationByID=val.equalsIgnoreCase$S("true"));
 else p$1.checkFlags$S.apply(this, [val]);
}, p$1);

Clazz.newMeth(C$, 'extractObjects$java_io_File',  function (targetDir) {
if (this.haveExtracted) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["Only one extraction per instance of Extractor is allowed (for now)."]);
this.haveExtracted=true;
if (targetDir == null ) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["The target directory may not be null."]);
if (this.cache == null ) this.setCachePattern$S(null);
if (this.rezipCache == null ) this.setRezipCachePattern$S$S(null, null);
this.targetDir=targetDir;
targetDir.mkdir$();
this.log$S("=====");
if (C$.logging$()) {
if (this.sourceDir != null ) this.log$S("extractObjects from " + this.sourceDir);
this.log$S("extractObjects to " + targetDir.getAbsolutePath$());
}var lastRootPath=null;
var lastURL=null;
this.deferredPropertyList=Clazz.new_($I$(6,1));
for (var i=0; i < this.objectParsers.size$(); i++) {
var parser=this.objectParsers.get$I(i);
this.log$S("!parser is " + parser);
this.resource=parser.dataSource;
if (!this.resource.equals$O(lastURL)) {
this.helper.addOrSetSource$S(this.resource);
lastURL=this.resource;
if (this.resourceList == null ) this.resourceList=this.resource;
 else this.resourceList+="," + this.resource;
}this.localizedTopLevelZipURL=this.localizeURL$S(this.resource);
if (this.debugging) this.log$S("opening " + this.localizedTopLevelZipURL);
lastRootPath=p$1.initializeCollection$S.apply(this, [lastRootPath]);
this.log$S("!PHASE 2.1 \n" + this.localizedTopLevelZipURL + "\n" + parser.sData );
var haveData=p$1.parseZipFileNamesForObjects$com_integratedgraphics_ifd_Extractor_ObjectParser.apply(this, [parser]);
this.log$S("!PHASE 2.2 rezip haveData=" + haveData);
if (haveData && this.rezipCache != null   && this.rezipCache.size$() > 0 ) {
this.lastRezipPath=null;
this.getNextRezipName$();
this.readZipContentsIteratively$com_integratedgraphics_ifd_Extractor_ObjectParser$java_io_InputStream$S$Z$java_util_Map(parser, Clazz.new_($I$(22,1).c$$S,[this.localizedTopLevelZipURL]).openStream$(), "", true, null);
}if (C$.logging$()) this.log$S("found " + this.ifdObjectCount + " IFD objects" );
}
p$1.processDeferredObjectProperties.apply(this, []);
p$1.addCachedRepresentationsToObjects.apply(this, []);
p$1.removeUnmanifestedRepresentations.apply(this, []);
p$1.checkForDuplicateSpecData.apply(this, []);
this.helper.removeInvalidData$();
this.writeCollectionManifests$Z(false);
this.log$S(this.helper.finalizeExtraction$());
});

Clazz.newMeth(C$, 'initializeCollection$S',  function (lastRootPath) {
var zipPath=this.localizedTopLevelZipURL.substring$I(this.localizedTopLevelZipURL.lastIndexOf$S(":") + 1);
var rootPath=Clazz.new_($I$(23,1).c$$S,[zipPath]).getName$();
if (rootPath.endsWith$S(".zip") || rootPath.endsWith$S(".tgz") ) rootPath=rootPath.substring$I$I(0, rootPath.length$() - 4);
 else if (rootPath.endsWith$S(".tar.gz")) rootPath=rootPath.substring$I$I(0, rootPath.length$() - 7);
if (!rootPath.equals$O(lastRootPath)) {
if (lastRootPath != null ) {
this.writeCollectionManifests$Z(false);
}var rootDir=Clazz.new_($I$(23,1).c$$S,[this.targetDir + "/" + rootPath ]);
rootDir.mkdir$();
if (this.cleanCollectionDir) {
$I$(24).cleanDirectory$java_io_File(rootDir);
}this.rootPath=lastRootPath=rootPath;
this.products.add$O(this.targetDir + "/" + rootPath );
this.writeCollectionManifests$Z(true);
}return lastRootPath;
}, p$1);

Clazz.newMeth(C$, 'parseZipFileNamesForObjects$com_integratedgraphics_ifd_Extractor_ObjectParser',  function (parser) {
var haveData=false;
var key=this.localizedTopLevelZipURL;
var zipFiles=this.IFDZipContents.get$O(key);
if (zipFiles == null ) {
this.log$S("!retrieving " + this.localizedTopLevelZipURL);
var url=Clazz.new_($I$(22,1).c$$S,[this.localizedTopLevelZipURL]);
var retLength=Clazz.array(Long.TYPE, [1]);
var stream=p$1.openLocalFileInputStream$java_net_URL$JA.apply(this, [url, retLength]);
var len=retLength[0];
this.helper.setCurrentResourceByteLength$J(len);
zipFiles=this.readZipContentsIteratively$com_integratedgraphics_ifd_Extractor_ObjectParser$java_io_InputStream$S$Z$java_util_Map(parser, stream, "", false, Clazz.new_($I$(12,1)));
this.IFDZipContents.put$O$O(key, zipFiles);
}for (var e, $e = zipFiles.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var originPath=e.getKey$();
var localizedName=C$.localizePath$S(originPath);
if (this.htLocalizedNameToObject.get$O(localizedName) != null ) continue;
var obj=p$1.addIFDObjectsForName$com_integratedgraphics_ifd_Extractor_ObjectParser$S$S$J.apply(this, [parser, originPath, localizedName, e.getValue$().getSize$()]);
if (obj != null ) {
++this.ifdObjectCount;
if (Clazz.instanceOf(obj, "org.iupac.fairdata.dataobject.IFDDataObject") || Clazz.instanceOf(obj, "org.iupac.fairdata.core.IFDAssociation") ) haveData=true;
}}
return haveData;
}, p$1);

Clazz.newMeth(C$, 'openLocalFileInputStream$java_net_URL$JA',  function (url, retLength) {
var stream;
if ("file".equals$O(url.getProtocol$())) {
stream=url.openStream$();
this.currentZipFile=Clazz.new_([url.getPath$()],$I$(23,1).c$$S);
retLength[0]=this.currentZipFile.length$();
} else {
var tempFile=this.currentZipFile=$I$(23).createTempFile$S$S("extract", ".zip");
this.localizedTopLevelZipURL="file:///" + tempFile.getAbsolutePath$();
this.log$S("!saving " + url + " as " + tempFile );
$I$(11,"getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z",[url.openStream$(), -1, Clazz.new_($I$(25,1).c$$java_io_File,[tempFile]), true, true]);
this.log$S("!saved " + Long.$s(tempFile.length$()) + " bytes" );
retLength[0]=tempFile.length$();
stream=Clazz.new_($I$(26,1).c$$java_io_File,[tempFile]);
}return stream;
}, p$1);

Clazz.newMeth(C$, 'newObjectParser$S',  function (sObj) {
return Clazz.new_($I$(27,1).c$$com_integratedgraphics_ifd_Extractor$S,[this, sObj]);
});

Clazz.newMeth(C$, 'readZipContentsIteratively$com_integratedgraphics_ifd_Extractor_ObjectParser$java_io_InputStream$S$Z$java_util_Map',  function (parser, is, baseOriginPath, isPhase2, retOriginPathToEntryMap) {
if (this.debugging && baseOriginPath.length$() > 0 ) this.log$S("! opening " + baseOriginPath);
var isTopLevel=(baseOriginPath.length$() == 0);
var ais=Clazz.new_($I$(28,1).c$$java_io_InputStream,[is]);
var zipEntry=null;
var nextEntry=null;
var n=0;
var phase=(isPhase2 ? 2 : 1);
var first=true;
var pt;
while ((zipEntry=(nextEntry == null  ? ais.getNextEntry$() : nextEntry)) != null ){
++n;
nextEntry=null;
var name=zipEntry.getName$();
var isDir=zipEntry.isDirectory$();
if (first) {
first=false;
if (!isDir && (pt=name.lastIndexOf$I("/")) >= 0 ) {
nextEntry=Clazz.new_([name.substring$I$I(0, pt + 1)],$I$(4,1).c$$S);
continue;
}}var originPath=baseOriginPath + name;
if (isDir) {
if (C$.logging$()) this.log$S("Phase " + phase + " checking zip directory: " + n + " " + originPath );
} else if (Long.$eq(zipEntry.getSize$(),0 )) {
continue;
} else {
if (this.lstRejected.accept$S(originPath)) {
if (!isPhase2) p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [originPath, 0, zipEntry.getSize$(), null]);
continue;
}if (this.lstIgnored.accept$S(originPath)) {
if (!isPhase2) p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [originPath, 1, zipEntry.getSize$(), ais]);
continue;
}}if (this.debugging) this.log$S("reading zip entry: " + n + " " + originPath );
if (retOriginPathToEntryMap != null ) {
retOriginPathToEntryMap.put$O$O(originPath, zipEntry);
}if (originPath.endsWith$S(".zip") || originPath.endsWith$S(".tgz") || originPath.endsWith$S("tar.gz")  ) {
this.readZipContentsIteratively$com_integratedgraphics_ifd_Extractor_ObjectParser$java_io_InputStream$S$Z$java_util_Map(parser, ais, originPath + "|", isPhase2, retOriginPathToEntryMap);
} else if (isPhase2) {
if (originPath.equals$O(this.currentRezipPath)) {
nextEntry=p$1.processEntryPhase2$com_integratedgraphics_ifd_Extractor_ObjectParser$S$S$com_integratedgraphics_ifd_Extractor_ArchiveInputStream$com_integratedgraphics_ifd_Extractor_ArchiveEntry.apply(this, [parser, baseOriginPath, originPath, ais, zipEntry]);
} else {
var localizedName=C$.localizePath$S(originPath);
if (!isDir && !this.lstManifest.contains$S(localizedName) && !this.lstIgnored.contains$S(originPath) && !this.lstRejected.contains$S(originPath)  ) {
if (this.lstRejected.accept$S(originPath)) {
p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [originPath, 0, zipEntry.getSize$(), null]);
} else {
p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [originPath, 1, zipEntry.getSize$(), ais]);
}}nextEntry=null;
}} else if (!isDir) {
this.processEntryPhase1$com_integratedgraphics_ifd_Extractor_ObjectParser$S$java_io_InputStream$com_integratedgraphics_ifd_Extractor_ArchiveEntry(parser, originPath, ais, zipEntry);
}}
if (isTopLevel) ais.close$();
return retOriginPathToEntryMap;
});

Clazz.newMeth(C$, 'processEntryPhase1$com_integratedgraphics_ifd_Extractor_ObjectParser$S$java_io_InputStream$com_integratedgraphics_ifd_Extractor_ArchiveEntry',  function (parser, originPath, ais, zipEntry) {
var len=zipEntry.getSize$();
var m;
if (this.cachePattern != null  && (m=this.cachePattern.matcher$CharSequence(originPath)).find$() ) {
var v=p$1.getPropertyManager$java_util_regex_Matcher.apply(this, [m]);
var doCheck=(v != null );
var doExtract=(!doCheck || v.doExtract$S(originPath) );
if (doExtract) {
var ext=m.group$S("ext");
var f=this.getAbsoluteFileTarget$S(originPath);
var os=(doCheck || this.noOutput  ? Clazz.new_($I$(29,1)) : Clazz.new_($I$(25,1).c$$java_io_File,[f]));
if (os != null ) $I$(11).getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z(ais, len, os, false, true);
var localizedName=C$.localizePath$S(originPath);
var type=null;
if (!doCheck && !this.noOutput ) {
len=f.length$();
} else {
var bytes=(os).toByteArray$();
len=bytes.length;
if (doCheck) {
p$1.writeBytesToFile$BA$java_io_File.apply(this, [bytes, f]);
var oldOriginPath=this.originPath;
var oldLocal=this.localizedName;
this.originPath=originPath;
this.localizedName=localizedName;
type=v.accept$org_iupac_fairdata_extract_ExtractorI$S$BA(this, originPath, bytes);
this.deferredPropertyList.add$O(null);
this.localizedName=oldLocal;
this.originPath=oldOriginPath;
}}p$1.addFileAndCacheRepresentation$S$S$J$S$S.apply(this, [originPath, localizedName, len, type, ext]);
}}if (this.rezipCachePattern != null  && (m=this.rezipCachePattern.matcher$CharSequence(originPath)).find$() ) {
var v=p$1.getVendorForRezip$java_util_regex_Matcher.apply(this, [m]);
originPath=m.group$S("path" + v.getIndex$());
if (originPath.equals$O(this.lastRezipPath)) {
if (C$.logging$()) this.log$S("duplicate path " + originPath);
} else {
this.lastRezipPath=originPath;
var localPath=C$.localizePath$S(originPath);
var ref=Clazz.new_([Clazz.new_($I$(31,1).c$$O$S$S,[originPath, this.rootPath, localPath]), v, len, null, "application/zip"],$I$(30,1).c$$org_iupac_fairdata_core_IFDReference$O$J$S$S);
this.rezipCache.add$O(ref);
if (C$.logging$()) this.log$S("rezip pattern found " + originPath);
}}});

Clazz.newMeth(C$, 'addProperty$S$O',  function (key, val) {
this.addPropertyOrRepresentation$S$O$Z$S(key, val, false, null);
});

Clazz.newMeth(C$, 'addPropertyOrRepresentation$S$O$Z$S',  function (key, val, isInline, mediaType) {
if (key == null ) {
this.deferredPropertyList.add$O(null);
return;
}this.deferredPropertyList.add$O(Clazz.array(java.lang.Object, -1, [this.originPath, this.localizedName, key, val, Boolean.valueOf$Z(isInline), mediaType]));
if (key.startsWith$S("_struc.")) {
var bytes=(val)[0];
var name=(val)[1];
this.getStructurePropertyManager$().processRepresentation$S$BA(name, bytes);
}});

Clazz.newMeth(C$, 'processDeferredObjectProperties',  function () {
var lastLocal=null;
var localSpec=null;
var struc=null;
var sample=null;
for (var i=0, n=this.deferredPropertyList.size$(); i < n; i++) {
var a=this.deferredPropertyList.get$I(i);
if (a == null ) {
sample=null;
continue;
}var originPath=a[0];
var localizedName=a[1];
var key=a[2];
var isRep=$I$(10).isRepresentation$S(key);
var value=a[3];
var isInline=(a[4] === Boolean.TRUE );
var type=$I$(21).getObjectTypeForName$S$Z(key, true);
var isSample=(type == "org.iupac.fairdata.sample.IFDSample");
var isStructure=(type == "org.iupac.fairdata.structure.IFDStructure");
if (isSample) {
sample=this.helper.getSampleByName$S(value);
continue;
}var isNew=!localizedName.equals$O(lastLocal);
if (isNew) {
lastLocal=localizedName;
}var spec=this.htLocalizedNameToObject.get$O(localizedName);
if (spec == null ) {
p$1.logDigitalItem$S$S.apply(this, [localizedName, "processDeferredObjectProperties"]);
continue;
} else if (Clazz.instanceOf(spec, "org.iupac.fairdata.structure.IFDStructure")) {
struc=spec;
spec=null;
} else if (Clazz.instanceOf(spec, "org.iupac.fairdata.sample.IFDSample")) {
sample=spec;
spec=null;
} else if (isNew && Clazz.instanceOf(spec, "org.iupac.fairdata.dataobject.IFDDataObject") ) {
localSpec=spec;
}if (isRep) {
var mediaType=a[5];
var keyPath=(isInline ? null : value.toString());
var data=(isInline ? value : null);
var obj=($I$(10).isStructure$S(key) ? struc : spec);
p$1.linkLocalizedNameToObject$S$S$org_iupac_fairdata_core_IFDRepresentableObject.apply(this, [keyPath, null, obj]);
var r=obj.findOrAddRepresentation$S$S$O$S$S(originPath, keyPath, data, key, mediaType);
if (!isInline) p$1.setLocalFileLength$org_iupac_fairdata_core_IFDRepresentation.apply(this, [r]);
continue;
}if (key.equals$O("*NEW_FAIRSPEC*")) {
var idExtension=value;
var newSpec=this.helper.cloneData$org_iupac_fairdata_dataobject_IFDDataObject$S(localSpec, idExtension);
spec=newSpec;
struc=this.helper.getFirstStructureForSpec$org_iupac_fairdata_dataobject_IFDDataObject$Z(localSpec, true);
if (sample == null ) sample=this.helper.getFirstSampleForSpec$org_iupac_fairdata_dataobject_IFDDataObject$Z(localSpec, true);
if (struc != null ) {
this.helper.associateStructureSpec$org_iupac_fairdata_structure_IFDStructure$org_iupac_fairdata_dataobject_IFDDataObject(struc, newSpec);
this.log$S("!Structure " + struc + " found and associated with " + spec );
}if (sample != null ) {
this.helper.associateSampleSpec$org_iupac_fairdata_sample_IFDSample$org_iupac_fairdata_dataobject_IFDDataObject(sample, newSpec);
this.log$S("!Structure " + struc + " found and associated with " + spec );
}if (struc == null  && sample == null  ) {
this.log$S("!SpecData " + spec + " added " );
}var rep=this.cache.get$O(localizedName);
var ckey=localizedName + idExtension.replace$C$C("_", "#") + "\u0000" + idExtension ;
this.cache.put$O$O(ckey, rep);
this.htLocalizedNameToObject.put$O$O(localizedName, spec);
this.htLocalizedNameToObject.put$O$O(ckey, spec);
continue;
}if (key.startsWith$S("_struc.")) {
var oval=value;
var bytes=oval[0];
var oPath=oval[1];
var ifdRepType=$I$(19,"getType$S$BA",[key.substring$I(key.length$() - 3), bytes]);
if (this.htStructureRepCache == null ) this.htStructureRepCache=Clazz.new_($I$(32,1));
var w=Clazz.new_($I$(33,1).c$$BA,[bytes]);
struc=this.htStructureRepCache.get$O(w);
var name=C$.getStructureNameFromPath$S(oPath);
if (struc == null ) {
var f=this.getAbsoluteFileTarget$S(oPath);
p$1.writeBytesToFile$BA$java_io_File.apply(this, [bytes, f]);
var localName=C$.localizePath$S(oPath);
struc=this.helper.getFirstStructureForSpec$org_iupac_fairdata_dataobject_IFDDataObject$Z(spec, false);
if (struc == null ) {
struc=this.helper.addStructureForSpec$S$org_iupac_fairdata_dataobject_IFDDataObject$S$S$S$S(this.rootPath, spec, ifdRepType, oPath, localName, name);
}this.htStructureRepCache.put$O$O(w, struc);
if (sample != null ) this.helper.associateSampleStructure$org_iupac_fairdata_sample_IFDSample$org_iupac_fairdata_structure_IFDStructure(sample, struc);
p$1.addFileAndCacheRepresentation$S$S$J$S$S.apply(this, [oPath, null, bytes.length, ifdRepType, null]);
p$1.linkLocalizedNameToObject$S$S$org_iupac_fairdata_core_IFDRepresentableObject.apply(this, [localName, ifdRepType, struc]);
this.log$S("!Structure " + struc + " created and associated with " + spec );
} else if (this.helper.getStructureAssociation$org_iupac_fairdata_structure_IFDStructure$org_iupac_fairdata_dataobject_IFDDataObject(struc, spec) == null ) {
this.helper.associateStructureSpec$org_iupac_fairdata_structure_IFDStructure$org_iupac_fairdata_dataobject_IFDDataObject(struc, spec);
this.log$S("!Structure " + struc + " found and associated with " + spec );
}continue;
}if (isStructure) {
if (struc == null ) {
this.logErr$S$S("No structure found for " + lastLocal + " " + key , "updateObjectProperies");
continue;
} else {
struc.setPropertyValue$S$O(key, value);
}} else if (isSample) {
} else {
spec.setPropertyValue$S$O(key, value);
}}
this.deferredPropertyList.clear$();
this.htStructureRepCache=null;
}, p$1);

Clazz.newMeth(C$, 'getStructureNameFromPath$S',  function (ifdPath) {
var name=ifdPath.substring$I(ifdPath.lastIndexOf$S("/") + 1);
name=name.substring$I(name.indexOf$I("#") + 1);
var pt=name.indexOf$I(".");
if (pt >= 0) name=name.substring$I$I(0, pt);
return name;
}, 1);

Clazz.newMeth(C$, 'setLocalFileLength$org_iupac_fairdata_core_IFDRepresentation',  function (rep) {
var f=this.getAbsoluteFileTarget$S(rep.getRef$().getLocalName$());
var len=(f.exists$() ? f.length$() : 0);
rep.setLength$J(len);
return len;
}, p$1);

Clazz.newMeth(C$, 'addCachedRepresentationsToObjects',  function () {
for (var ckey, $ckey = this.cache.keySet$().iterator$(); $ckey.hasNext$()&&((ckey=($ckey.next$())),1);) {
var obj=this.htLocalizedNameToObject.get$O(ckey);
if (obj == null ) {
var o=this.cache.get$O(ckey);
var path=o.getRef$().getOrigin$().toString();
p$1.logDigitalItem$S$S.apply(this, [ckey, "addCachedRepresentationsToObjects"]);
try {
p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [path, 1, o.getLength$(), null]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
} else {
p$1.copyCachedRepresentation$S$org_iupac_fairdata_core_IFDRepresentableObject.apply(this, [ckey, obj]);
}}
}, p$1);

Clazz.newMeth(C$, 'logDigitalItem$S$S',  function (localPath, method) {
this.logErr$S$S("digital item ignored, as it does not fit any template pattern: " + localPath, method);
}, p$1);

Clazz.newMeth(C$, 'copyCachedRepresentation$S$org_iupac_fairdata_core_IFDRepresentableObject',  function (ckey, obj) {
var r=this.cache.get$O(ckey);
var ifdPath=r.getRef$().getOrigin$().toString();
var type=r.getType$();
var subtype=r.getMediaType$();
var pt=ckey.indexOf$I("\u0000");
if (pt > 0) ckey=ckey.substring$I$I(0, pt);
var r1=obj.findOrAddRepresentation$S$S$O$S$S(ifdPath, ckey, null, r.getType$(), null);
if (type != null ) r1.setType$S(type);
if (subtype != null ) r1.setMediaType$S(subtype);
r1.setLength$J(r.getLength$());
}, p$1);

Clazz.newMeth(C$, 'checkForDuplicateSpecData',  function () {
var bs=Clazz.new_($I$(16,1));
var ssc=this.helper.getStructureDataCollection$();
var isFound=false;
var doRemove=false;
var n=0;
var map=Clazz.new_($I$(32,1));
for (var assoc, $assoc = ssc.iterator$(); $assoc.hasNext$()&&((assoc=($assoc.next$())),1);) {
var c=(assoc).getDataObjectCollection$();
var found=Clazz.new_($I$(6,1));
for (var spec, $spec = c.iterator$(); $spec.hasNext$()&&((spec=($spec.next$())),1);) {
var i=spec.getIndex$();
if (bs.get$I(i)) {
found.add$O(spec);
this.log$S("! Extractor found duplicate DataObject reference " + spec + " for " + assoc.getFirstObj1$() + " in " + assoc + " and " + map.get$O(Integer.valueOf$I(i)) + " template order needs changing? " );
isFound=true;
} else {
bs.set$I(i);
map.put$O$O(Integer.valueOf$I(i), assoc);
}}
n+=found.size$();
if (found.size$() > 0) {
if (doRemove) c.removeAll$java_util_Collection(found);
}}
if (isFound && doRemove ) {
n+=this.helper.removeStructuresWithNoAssociations$();
if (n > 0) this.log$S("! " + n + " objects removed" );
}}, p$1);

Clazz.newMeth(C$, 'removeUnmanifestedRepresentations',  function () {
var isRemoved=false;
for (var spec, $spec = this.helper.getDataObjectCollection$().iterator$(); $spec.hasNext$()&&((spec=($spec.next$())),1);) {
var lstRepRemoved=Clazz.new_($I$(6,1));
for (var o, $o = spec.iterator$(); $o.hasNext$()&&((o=($o.next$())),1);) {
var rep=o;
if (Long.$eq(rep.getLength$(),0 ) && Long.$eq(p$1.setLocalFileLength$org_iupac_fairdata_core_IFDRepresentation.apply(this, [rep]),0 ) ) {
lstRepRemoved.add$O(rep);
}}
spec.removeAll$java_util_Collection(lstRepRemoved);
if (spec.size$() == 0) {
spec.invalidate$();
isRemoved=true;
}}
if (isRemoved) {
var n=this.helper.removeStructuresWithNoAssociations$();
if (n > 0) this.log$S("!" + n + " objects with no representations removed" );
}}, p$1);

Clazz.newMeth(C$, 'writeCollectionManifests$Z',  function (isOpen) {
if (!isOpen) {
if (this.createFindingAidsOnly || this.readOnly ) {
if (this.lstIgnored.size$() > 0) {
this.logWarn$S$S("ignored " + this.lstIgnored.size$() + " files" , "saveCollectionManifests");
}if (this.lstRejected.size$() > 0) {
this.logWarn$S$S("rejected " + this.lstRejected.size$() + " files" , "saveCollectionManifests");
}} else {
p$1.writeBytesToFile$BA$java_io_File.apply(this, [this.extractScript.getBytes$(), this.getAbsoluteFileTarget$S("_IFD_extract.json")]);
this.outputListJSON$com_integratedgraphics_ifd_Extractor_FileList$java_io_File(this.lstManifest, this.getAbsoluteFileTarget$S("_IFD_manifest.json"));
this.outputListJSON$com_integratedgraphics_ifd_Extractor_FileList$java_io_File(this.lstIgnored, this.getAbsoluteFileTarget$S("_IFD_ignored.json"));
this.outputListJSON$com_integratedgraphics_ifd_Extractor_FileList$java_io_File(this.lstRejected, Clazz.new_($I$(23,1).c$$S,[this.targetDir + "/_IFD_rejected.json"]));
}}this.lstManifest.clear$();
this.lstIgnored.clear$();
});

Clazz.newMeth(C$, 'outputListJSON$com_integratedgraphics_ifd_Extractor_FileList$java_io_File',  function (lst, fileTarget) {
this.log$S("!saved " + fileTarget + " (" + lst.size$() + " items)" );
var name=lst.getName$();
var sb=Clazz.new_($I$(7,1));
sb.append$S("{\"IFD.fairdata.version\":\"" + $I$(10).IFD_VERSION + "\",\n" );
sb.append$S("\"FAIRSpec.extractor.version\":\"0.0.3-alpha+2022.11.21\",\n").append$S("\"FAIRSpec.extractor.code\":\"https://github.com/IUPAC/IUPAC-FAIRSpec/blob/main/src/main/java/com/integratedgraphics/ifd/Extractor.java\",\n").append$S("\"FAIRSpec.extractor.list.type\":\"" + name + "\",\n" ).append$S("\"FAIRSpec.extractor.script\":\"_IFD_extract.json\",\n");
if (lst === this.lstRejected ) {
sb.append$S("\"FAIRSpec.extractor.sources\":\"" + this.resourceList + "\",\n" );
} else {
sb.append$S("\"FAIRSpec.extractor.source\":\"" + this.resource + "\",\n" );
}sb.append$S("\"FAIRSpec.extractor.creation.date\":\"" + this.helper.getFindingAid$().getDate$().toGMTString$() + "\",\n" ).append$S("\"FAIRSpec.extractor.listFileCount\":" + lst.size$() + ",\n" ).append$S("\"FAIRSpec.extractor.listByteCount\":" + Long.$s(lst.getByteCount$()) + ",\n" ).append$S("\"FAIRSpec.extractor.list\":\n");
lst.serialize$StringBuffer(sb);
sb.append$S("}\n");
p$1.writeBytesToFile$BA$java_io_File.apply(this, [sb.toString().getBytes$(), fileTarget]);
});

Clazz.newMeth(C$, 'addIFDObjectsForName$com_integratedgraphics_ifd_Extractor_ObjectParser$S$S$J',  function (parser, originPath, localizedName, len) {
var m=parser.p.matcher$CharSequence(originPath);
if (!m.find$()) return null;
this.helper.beginAddingObjects$S(originPath);
if (this.debugging) this.log$S("adding IFDObjects for " + originPath);
var keys=Clazz.new_($I$(6,1));
for (var key, $key = parser.keys.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) {
keys.add$O(key);
}
for (var i=keys.size$(); --i >= 0; ) {
var key=keys.get$I(i);
var param=parser.keys.get$O(key);
if (param.length$() > 0) {
var id=m.group$S(key);
this.log$S("!found " + param + " " + id );
var obj=this.helper.addObject$S$S$S$S$J(this.rootPath, param, id, localizedName, len);
if (obj != null ) p$1.linkLocalizedNameToObject$S$S$org_iupac_fairdata_core_IFDRepresentableObject.apply(this, [localizedName, param, obj]);
if (this.debugging) this.log$S("!found " + param + " " + id );
}}
return this.helper.endAddingObjects$();
}, p$1);

Clazz.newMeth(C$, 'linkLocalizedNameToObject$S$S$org_iupac_fairdata_core_IFDRepresentableObject',  function (localizedName, type, obj) {
if (localizedName != null  && (type == null  || $I$(10).isRepresentation$S(type) ) ) {
var renamed=this.htZipRenamed.get$O(localizedName);
this.htLocalizedNameToObject.put$O$O(renamed == null  ? localizedName : renamed, obj);
}}, p$1);

Clazz.newMeth(C$, 'logNote$S$S',  function (msg, method) {
msg="!NOTE: Extractor." + method + " " + this.ifdid + " " + this.rootPath + " " + msg ;
this.log$S(msg);
});

Clazz.newMeth(C$, 'logWarn$S$S',  function (msg, method) {
msg="! Extractor." + method + " " + this.ifdid + " " + this.rootPath + " WARNING: " + msg ;
this.log$S(msg);
});

Clazz.newMeth(C$, 'logErr$S$S',  function (msg, method) {
msg="!! Extractor." + method + " " + this.ifdid + " " + this.rootPath + " ERROR: " + msg ;
this.log$S(msg);
});

Clazz.newMeth(C$, 'log$S',  function (msg) {
if (msg.startsWith$S("!!")) {
++this.errors;
this.errorLog+=msg + "\n";
} else if (msg.startsWith$S("! ")) {
++this.warnings;
this.errorLog+=msg + "\n";
}this.logToSys$S(msg);
});

Clazz.newMeth(C$, 'logToSys$S',  function (msg) {
var toSysErr=msg.startsWith$S("!!") || msg.startsWith$S("! ") ;
var toSysOut=toSysErr || msg.startsWith$S("!") ;
if (this.testID >= 0) msg="test " + this.testID + ": " + msg ;
if (C$.logging$()) {
try {
$I$(11).logStream.write$BA((msg + "\n").getBytes$());
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
}System.out.flush$();
System.err.flush$();
if (toSysErr) {
System.err.println$S(msg);
} else if (toSysOut) {
System.out.println$S(msg);
}System.out.flush$();
System.err.flush$();
});

Clazz.newMeth(C$, 'logging$',  function () {
return $I$(11).logStream != null ;
}, 1);

Clazz.newMeth(C$, 'localizeURL$S',  function (sUrl) {
if (this.sourceDir != null ) {
var pt=sUrl.lastIndexOf$S("/");
if (pt < 0) return this.sourceDir;
sUrl=this.sourceDir + sUrl.substring$I(pt);
if (!sUrl.endsWith$S(".zip")) sUrl+=".zip";
}return sUrl;
});

Clazz.newMeth(C$, 'getIFDExtractValue$S$S$IA',  function (sObj, key, pt) {
key="{" + key + "::" ;
if (pt == null ) pt=Clazz.array(Integer.TYPE, [1]);
var p=sObj.indexOf$S$I(key, pt[0]);
if (p < 0) return null;
var q=-1;
var nBrace=1;
p+=key.length$();
var len=sObj.length$();
for (var i=p; i < len && nBrace > 0 ; i++) {
switch ((sObj.charCodeAt$I(i))) {
case 123:
q=i;
++nBrace;
break;
case 125:
if (--nBrace < 0) {
throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["unopened '}' in " + sObj + " at char " + i ]);
}q=i;
break;
}
}
if (nBrace > 0) {
throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["unclosed '{' in " + sObj + " at char " + q ]);
}pt[0]=q;
return sObj.substring$I$I(p, pt[0]++);
}, 1);

Clazz.newMeth(C$, 'addFileAndCacheRepresentation$S$S$J$S$S',  function (ifdPath, localizedName, len, ifdType, fileNameForMediaType) {
if (localizedName == null ) localizedName=C$.localizePath$S(ifdPath);
if (fileNameForMediaType == null ) fileNameForMediaType=localizedName;
try {
p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [localizedName, 2, len, null]);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
var subtype=$I$(11).mediaTypeFromFileName$S(fileNameForMediaType);
return p$1.cacheFileRepresentation$S$S$J$S$S.apply(this, [ifdPath, localizedName, len, ifdType, subtype]);
}, p$1);

Clazz.newMeth(C$, 'getVendorForRezip$java_util_regex_Matcher',  function (m) {
for (var i=this.bsRezipVendors.nextSetBit$I(0); i >= 0; i=this.bsRezipVendors.nextSetBit$I(i + 1)) {
var ret=m.group$S("rezip" + i);
if (ret != null  && ret.length$() > 0 ) {
return $I$(14).activeVendors.get$I(i).vendor;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'getParamName$java_util_regex_Matcher',  function (m) {
try {
if (this.cachePatternHasVendors) return m.group$S("param");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return null;
}, p$1);

Clazz.newMeth(C$, 'cacheFileRepresentation$S$S$J$S$S',  function (ifdPath, localizedName, len, type, subtype) {
if (subtype == null ) subtype=$I$(11).mediaTypeFromFileName$S(localizedName);
var rep=Clazz.new_([Clazz.new_($I$(31,1).c$$O$S$S,[ifdPath, this.rootPath, localizedName]), null, len, type, subtype],$I$(30,1).c$$org_iupac_fairdata_core_IFDReference$O$J$S$S);
this.cache.put$O$O(localizedName, rep);
return rep;
}, p$1);

Clazz.newMeth(C$, 'getNextRezipName$',  function () {
if (this.rezipCache.size$() == 0) {
this.currentRezipPath=null;
this.currentRezipRepresentation=null;
} else {
this.currentRezipPath=(this.currentRezipRepresentation=this.rezipCache.remove$I(0)).getRef$().getOrigin$();
this.currentRezipVendor=this.currentRezipRepresentation.getData$();
}});

Clazz.newMeth(C$, 'processEntryPhase2$com_integratedgraphics_ifd_Extractor_ObjectParser$S$S$com_integratedgraphics_ifd_Extractor_ArchiveInputStream$com_integratedgraphics_ifd_Extractor_ArchiveEntry',  function (parser, baseName, originPath, ais, entry) {
var vendor=this.currentRezipVendor;
var entryName=entry.getName$();
var dirName;
if (entry.isDirectory$()) {
dirName=entryName;
} else {
dirName=entryName.substring$I$I(0, entryName.lastIndexOf$I("/") + 1);
}var parent=Clazz.new_($I$(23,1).c$$S,[entryName]).getParent$();
var lenOffset=(parent == null  ? 0 : parent.length$() + 1);
var newDir=vendor.getRezipPrefix$S(dirName.substring$I$I(lenOffset, dirName.length$() - 1));
var m=null;
var localizedName=C$.localizePath$S(originPath);
var basePath=baseName.substring$I$I(0, baseName.length$() - 1);
if (newDir == null ) {
newDir="";
originPath=basePath;
localizedName=C$.localizePath$S(originPath);
} else {
newDir+="/";
lenOffset=dirName.length$();
if (lenOffset > 0) {
this.htZipRenamed.put$O$O(C$.localizePath$S(basePath), localizedName);
}if (this.localizedName == null ) this.localizedName=localizedName;
var msg="Extractor correcting Bruker directory name to " + localizedName + "|" + newDir ;
this.addProperty$S$O(C$.IFD_PROPERTY_DATAOBECT_NOTE, msg);
this.logWarn$S$S(msg, "processEntryPhase2");
}this.originPath=originPath;
this.localizedName=localizedName;
this.log$S("!Extractor rezipping " + originPath + " for " + entry );
var outFile=this.getAbsoluteFileTarget$S(originPath + (originPath.endsWith$S(".zip") ? "" : ".zip"));
var fos=(this.noOutput ? Clazz.new_($I$(29,1)) : Clazz.new_($I$(25,1).c$$java_io_File,[outFile]));
var zos=Clazz.new_($I$(34,1).c$$java_io_OutputStream,[fos]);
vendor.startRezip$org_iupac_fairdata_extract_ExtractorI(this);
var len=0;
while ((entry=ais.getNextEntry$()) != null ){
entryName=entry.getName$();
var entryPath=baseName + entryName;
var isDir=entry.isDirectory$();
if (this.lstRejected.accept$S(entryPath)) {
if (!this.lstRejected.contains$S(entryPath)) p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [entryPath, 0, entry.getSize$(), null]);
continue;
}if (!entryName.startsWith$S(dirName)) break;
if (isDir) continue;
var mgr=null;
this.originPath=entryPath;
var doInclude=(vendor == null  || vendor.doRezipInclude$org_iupac_fairdata_extract_ExtractorI$S$S(this, baseName, entryName) );
var doCache=(this.cachePattern != null  && (m=this.cachePattern.matcher$CharSequence(entryName)).find$()  && p$1.getParamName$java_util_regex_Matcher.apply(this, [m]) != null   && ((mgr=p$1.getPropertyManager$java_util_regex_Matcher.apply(this, [m])) == null  || mgr.doExtract$S(entryName) ) );
var doCheck=(doCache || mgr != null  );
len=entry.getSize$();
if (Long.$ne(len,0 )) {
var os;
if (doCheck) {
os=Clazz.new_($I$(29,1));
} else if (doInclude) {
os=zos;
} else {
continue;
}var outName=newDir + entryName.substring$I(lenOffset);
if (doInclude) zos.putNextEntry$java_util_zip_ZipEntry(Clazz.new_($I$(35,1).c$$S,[outName]));
$I$(11,"getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z",[ais.getStream$(), len, os, false, false]);
if (doCheck) {
var bytes=(os).toByteArray$();
if (doInclude) zos.write$BA(bytes);
this.originPath=originPath + outName;
this.localizedName=localizedName;
if (mgr == null  || mgr === vendor  ) {
vendor.accept$org_iupac_fairdata_extract_ExtractorI$S$BA(null, this.originPath, bytes);
} else {
mgr.accept$org_iupac_fairdata_extract_ExtractorI$S$BA(this, this.originPath, bytes);
}}if (doInclude) zos.closeEntry$();
}}
vendor.endRezip$();
zos.close$();
fos.close$();
var dataType=vendor.processRepresentation$S$BA(originPath + ".zip", null);
len=(this.noOutput ? (fos).size$() : outFile.length$());
var r=this.helper.getSpecDataRepresentation$S(originPath);
if (r == null ) {
} else {
r.setLength$J(len);
}p$1.cacheFileRepresentation$S$S$J$S$S.apply(this, [originPath, localizedName, len, dataType, "application/zip"]);
p$1.addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream.apply(this, [localizedName, 2, len, null]);
this.getNextRezipName$();
return entry;
}, p$1);

Clazz.newMeth(C$, 'getAbsoluteFileTarget$S',  function (originPath) {
return Clazz.new_([this.targetDir + "/" + this.rootPath + "/" + C$.localizePath$S(originPath) ],$I$(23,1).c$$S);
});

Clazz.newMeth(C$, 'localizePath$S',  function (path) {
var isDir=path.endsWith$S("/");
if (isDir) path=path.substring$I$I(0, path.length$() - 1);
var pt=-1;
while ((pt=path.indexOf$I$I("|", pt + 1)) >= 0)path=path.substring$I$I(0, pt) + ".." + path.substring$I(++pt) ;

return path.replace$C$C("/", "_").replace$C$C("#", "_").replace$C$C(" ", "_") + (isDir ? ".zip" : "");
}, 1);

Clazz.newMeth(C$, 'addFileToFileLists$S$I$J$com_integratedgraphics_ifd_Extractor_ArchiveInputStream',  function (fileName, mode, len, ais) {
switch (mode) {
case 1:
p$1.outputIgnoredFile$S$com_integratedgraphics_ifd_Extractor_ArchiveInputStream$J.apply(this, [fileName, ais, len]);
break;
case 0:
this.lstRejected.add$S$J(fileName, len);
break;
case 2:
this.lstManifest.add$S$J(fileName, len);
break;
}
}, p$1);

Clazz.newMeth(C$, 'outputIgnoredFile$S$com_integratedgraphics_ifd_Extractor_ArchiveInputStream$J',  function (originPath, ais, len) {
var localizedName=C$.localizePath$S(originPath);
this.lstIgnored.add$S$J(localizedName, len);
if (this.noOutput || !this.includeIgnoredFiles || ais == null   ) return;
var f=this.getAbsoluteFileTarget$S(localizedName);
$I$(11,"getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z",[ais, len, Clazz.new_($I$(25,1).c$$java_io_File,[f]), false, true]);
}, p$1);

Clazz.newMeth(C$, 'writeBytesToFile$BA$java_io_File',  function (bytes, f) {
if (!this.noOutput) $I$(11).writeBytesToFile$BA$java_io_File(bytes, f);
}, p$1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
if (args.length == 0) {
System.out.println$S(C$.getCommandLineHelp$());
return;
}C$.runExtraction$SA$SA$I$I(args, null, -1, -1);
}, 1);

Clazz.newMeth(C$, 'runExtraction$SA$SA$I$I',  function (args, testSet, first, last) {
System.out.println$S($I$(5).toString$OA(args));
var i0=Math.max(0, Math.min(first, last));
var i1=Math.max(0, Math.max(first, last));
var failed=0;
var sourceArchive=null;
var targetDir=null;
var ifdExtractJSONFilename;
switch (args.length) {
default:
case 3:
targetDir=args[2];
case 2:
sourceArchive=args[1];
case 1:
ifdExtractJSONFilename=args[0];
break;
case 0:
ifdExtractJSONFilename=null;
}
if (ifdExtractJSONFilename == null  && testSet == null  ) throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["No IFD-extract.json or test set?"]);
if (sourceArchive == null ) throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["No source zip file??"]);
if (targetDir == null ) throw Clazz.new_(Clazz.load('NullPointerException').c$$S,["No targetDir"]);
$I$(11).setLogging$S(targetDir + "/extractor.log");
var json=null;
var n=0;
var nWarnings=0;
var nErrors=0;
var createFindingAidJSONList=false;
var extractor=null;
var flags=null;
for (var itest=i0; itest <= i1; itest++) {
extractor=Clazz.new_(C$);
extractor.logToSys$S("Extractor.runExtraction output to " + Clazz.new_($I$(23,1).c$$S,[targetDir]).getAbsolutePath$());
var job=null;
var thisIFDExtractName=null;
if (ifdExtractJSONFilename == null ) {
job=thisIFDExtractName=testSet[itest];
extractor.logToSys$S("Extractor.runExtraction " + itest + " " + job );
var pt=thisIFDExtractName.indexOf$S("#");
if (pt >= 0) {
ifdExtractJSONFilename=thisIFDExtractName.substring$I(pt + 1);
} else ifdExtractJSONFilename=thisIFDExtractName;
}++n;
if (thisIFDExtractName != null ) {
if (json == null ) {
json="{\"findingaids\":[\n";
} else {
json+=",\n";
}json+="\"" + thisIFDExtractName + "\"" ;
}var t0=System.currentTimeMillis$();
extractor.testID=itest;
p$1.processFlags$SA.apply(extractor, [args]);
Clazz.new_($I$(23,1).c$$S,[targetDir]).mkdirs$();
flags="\n first = " + first + " last = " + last + "\n stopOnAnyFailure = " + extractor.stopOnAnyFailure + "\n debugging = " + extractor.debugging + " readOnly = " + extractor.readOnly + " debugReadOnly = " + extractor.debugReadOnly + "\n requireNoPubInfo = " + !extractor.allowNoPubInfo + " skipPubInfo = " + extractor.skipPubInfo + "\n sourceArchive = " + sourceArchive + " targetDir = " + targetDir + "\n createZippedCollection = " + extractor.createZippedCollection + " createFindingAidJSONList = " + createFindingAidJSONList + "\n IFD version " + $I$(10).IFD_VERSION + "\n" ;
createFindingAidJSONList=!extractor.debugReadOnly && (first != last || first < 0 ) ;
try {
var ifdExtractScriptFile=Clazz.new_($I$(23,1).c$$S,[ifdExtractJSONFilename]);
var targetPath=Clazz.new_($I$(23,1).c$$S,[targetDir]);
var sourcePath=Clazz.new_($I$(23,1).c$$S,[sourceArchive]).getAbsolutePath$();
extractor.run$S$java_io_File$java_io_File$S(thisIFDExtractName, ifdExtractScriptFile, targetPath, sourcePath);
extractor.logToSys$S("Extractor.runExtraction ok " + thisIFDExtractName);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
++failed;
extractor.logErr$S$S("Exception " + e + " " + itest , "runExtraction");
e.printStackTrace$();
if (extractor.stopOnAnyFailure) break;
} else {
throw e;
}
}
nWarnings+=extractor.warnings;
nErrors+=extractor.errors;
extractor.logToSys$S("!Extractor.runExtraction job " + job + " time/sec=" + new Double((Long.$sub(System.currentTimeMillis$(),t0)) / 1000.0).toString() );
}
json+="\n]}\n";
if (extractor != null ) {
if (failed == 0) {
try {
if (createFindingAidJSONList && !extractor.readOnly && json != null   ) {
var f=Clazz.new_($I$(23,1).c$$S,[targetDir + "/_IFD_findingaids.json"]);
$I$(11,"writeBytesToFile$BA$java_io_File",[json.getBytes$(), f]);
extractor.logToSys$S("Extractor.runExtraction File " + f.getAbsolutePath$() + " created \n" + json );
} else {
extractor.logToSys$S("Extractor.runExtraction _IFD_findingaids.json was not created for\n" + json);
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
}extractor.logToSys$S("");
System.err.flush$();
System.out.flush$();
System.err.println$S(extractor.errorLog);
System.err.flush$();
extractor.logToSys$S("!Extractor.runExtraction flags " + flags);
extractor.logToSys$S("!Extractor " + (failed == 0 ? "done" : "failed") + " total=" + n + " failed=" + failed + " errors=" + nErrors + " warnings=" + nWarnings );
}$I$(11).setLogging$S(null);
}, 1);

Clazz.newMeth(C$, 'setDefaultRunParams$',  function () {
System.out.flush$();
this.debugReadOnly=false;
this.addPublicationMetadata=false;
this.cleanCollectionDir=true;
this.stopOnAnyFailure=true;
this.debugging=false;
this.createFindingAidsOnly=false;
this.allowNoPubInfo=true;
p$1.setDerivedFlags.apply(this, []);
});

Clazz.newMeth(C$, 'setDerivedFlags',  function () {
this.createZippedCollection=this.createZippedCollection && !this.debugReadOnly ;
this.readOnly=!!(this.readOnly|(this.debugReadOnly));
this.skipPubInfo=!this.dataciteUp || this.debugReadOnly ;
}, p$1);

Clazz.newMeth(C$, 'processFlags$SA',  function (args) {
var flags="";
for (var i=3; i < args.length; i++) {
if (args[i] != null ) flags+="-" + args[i] + ";" ;
}
p$1.checkFlags$S.apply(this, [flags]);
p$1.setDerivedFlags.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'checkFlags$S',  function (flags) {
flags=flags.toLowerCase$();
if (flags.indexOf$S("-") < 0) flags="-" + flags.replaceAll$S$S("\\;", "-;") + ";" ;
if (flags.indexOf$S("-debugreadonly;") >= 0) {
this.debugReadOnly=true;
}if (flags.indexOf$S("-readonly;") >= 0) {
this.readOnly=true;
}if (flags.indexOf$S("-addpublicationmetadata;") >= 0) {
this.addPublicationMetadata=true;
}if (flags.indexOf$S("-nostoponfailure;") >= 0) {
this.stopOnAnyFailure=false;
}if (flags.indexOf$S("-datacitedown;") >= 0) {
this.dataciteUp=false;
}if (flags.indexOf$S("-debugging;") >= 0) {
this.debugging=true;
}if (flags.indexOf$S("-noclean;") >= 0) {
this.cleanCollectionDir=false;
}if (flags.indexOf$S("-noignored;") >= 0) {
this.includeIgnoredFiles=false;
}if (flags.indexOf$S("-nozip;") >= 0) {
this.createZippedCollection=false;
}if (flags.indexOf$S("-requirepubinfo;") >= 0) {
this.allowNoPubInfo=false;
}if (flags.indexOf$S("-nopubinfo;") >= 0) {
this.skipPubInfo=true;
}if (flags.indexOf$S("-nozip;") >= 0) {
this.createZippedCollection=false;
}if (flags.indexOf$S("-byid;") >= 0) {
p$1.setExtractorFlag$S$S.apply(this, [$I$(21).IFD_EXTRACTOR_FLAG_ASSOCIATION_BYID, "true"]);
}}, p$1);

Clazz.newMeth(C$, 'getCommandLineHelp$',  function () {
return "\nformat: java -jar IFDExtractor.jar [IFD-extract.json] [sourceArchive] [targetDir] [flags]\n\n\nwhere \n\n[IFD-extract.json] is the IFD extraction template for this collection\n[sourceArchive] is the source .zip, .tar.gz, or .tgz file\n[targetDir] is the target directory for the collection (which you are responsible to empty first)\n\n[flags] are one or more of:\n\n-addPublicationMetadata (only for post-publication-related collections)\n-datacitedown (only for post-publication-related collections)\n-debugging (lots of messages)\n-debugreadonly (readonly, no publicationmetadata)\n-noclean (don\'t empty the destination collection directory before extraction; allows additional files to be zipped)\n-noignored (don\'t include ignored files -- treat them as REJECTED)\n-nopubinfo (ignore all publication info)\n-nostoponfailure (continue if there is an error)\n-nozip (don\'t zip up the target directory)\n-readonly (just create a log file)\n-requirepubinfo (throw an error is datacite cannot be reached; post-publication-related collections only)";
}, 1);

C$.$static$=function(){C$.$static$=0;
{
$I$(13).loadProperties$();
$I$(14).init$();
};
C$.objectDefPattern=$I$(8,"compile$S",["\\{([^:]+)::([^}]+)\\}"]);
C$.pStarDotStar=$I$(8,"compile$S",["\\*([^|/])\\*"]);
C$.IFD_PROPERTY_DATAOBECT_NOTE=$I$(10,"concat$SA",[Clazz.array(String, -1, [$I$(10).IFD_PROPERTY_FLAG, $I$(10).IFD_DATAOBJECT_FLAG, $I$(10).IFD_NOTE_FLAG])]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "ArchiveEntry", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['J',['size'],'S',['name']]]

Clazz.newMeth(C$, 'c$$java_util_zip_ZipEntry',  function (ze) {
;C$.$init$.apply(this);
this.name=ze.getName$();
this.size=ze.getSize$();
}, 1);

Clazz.newMeth(C$, 'c$$org_apache_commons_compress_archivers_tar_TarArchiveEntry',  function (te) {
;C$.$init$.apply(this);
this.name=te.getName$();
this.size=te.getSize$();
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz.newMeth(C$, 'isDirectory$',  function () {
return this.name.endsWith$S("/");
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.size;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.name;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "ArchiveInputStream", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.io.InputStream');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['zis','java.util.zip.ZipInputStream','tis','org.apache.commons.compress.archivers.tar.TarArchiveInputStream','is','java.io.InputStream']]]

Clazz.newMeth(C$, 'c$$java_io_InputStream',  function (is) {
Clazz.super_(C$, this);
if (Clazz.instanceOf(is, "com.integratedgraphics.ifd.Extractor.ArchiveInputStream")) is=Clazz.new_([(is).getStream$()],$I$(1,1).c$$java_io_InputStream);
if ($I$(2).isGzipS$java_io_InputStream(is)) this.is=this.tis=$I$(2).newTarInputStream$java_io_InputStream(is);
 else this.is=this.zis=Clazz.new_($I$(3,1).c$$java_io_InputStream,[is]);
}, 1);

Clazz.newMeth(C$, 'getNextEntry$',  function () {
if (this.tis != null ) {
var te=this.tis.getNextTarEntry$();
return (te == null  ? null : Clazz.new_($I$(4,1).c$$org_apache_commons_compress_archivers_tar_TarArchiveEntry,[te]));
}var ze=this.zis.getNextEntry$();
return (ze == null  ? null : Clazz.new_($I$(4,1).c$$java_util_zip_ZipEntry,[ze]));
});

Clazz.newMeth(C$, 'close$',  function () {
this.is.close$();
});

Clazz.newMeth(C$, 'getStream$',  function () {
return this.is;
});

Clazz.newMeth(C$, 'read$',  function () {
return this.is.read$();
});

Clazz.newMeth(C$, 'read$BA$I$I',  function (b, off, len) {
return this.is.read$BA$I$I(b, off, len);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "CacheRepresentation", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.iupac.fairdata.core.IFDRepresentation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$org_iupac_fairdata_core_IFDReference$O$J$S$S',  function (ifdReference, o, len, type, subtype) {
;C$.superclazz.c$$org_iupac_fairdata_core_IFDReference$O$J$S$S.apply(this,[ifdReference, o, len, type, subtype]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "AWrap", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['a','byte[]']]]

Clazz.newMeth(C$, 'c$$BA',  function (b) {
;C$.$init$.apply(this);
this.a=b;
}, 1);

Clazz.newMeth(C$, 'equals$O',  function (o) {
var b=o;
return $I$(5).equals$BA$BA(this.a, b.a);
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return $I$(5).hashCode$BA(this.a);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "FileList", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.files=Clazz.new_($I$(6,1));
},1);

C$.$fields$=[['J',['byteCount'],'S',['name'],'O',['files','java.util.List','acceptPattern','java.util.regex.Pattern']]]

Clazz.newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz.newMeth(C$, 'size$',  function () {
return this.files.size$();
});

Clazz.newMeth(C$, 'clear$',  function () {
this.files.clear$();
this.byteCount=0;
});

Clazz.newMeth(C$, 'serialize$StringBuffer',  function (sb) {
var returnString=(sb == null );
if (returnString) sb=Clazz.new_($I$(7,1));
sb.append$S("[\n");
var sep="";
if (this.name.equals$O("manifest")) {
for (var fname, $fname = this.files.iterator$(); $fname.hasNext$()&&((fname=($fname.next$())),1);) {
if (fname.endsWith$S(".zip")) {
sb.append$S((sep + "\"" + fname + "\"\n" ));
sep=",";
}}
for (var fname, $fname = this.files.iterator$(); $fname.hasNext$()&&((fname=($fname.next$())),1);) {
if (!fname.endsWith$S(".zip")) {
sb.append$S((sep + "\"" + fname + "\"\n" ));
sep=",";
}}
} else {
for (var fname, $fname = this.files.iterator$(); $fname.hasNext$()&&((fname=($fname.next$())),1);) {
sb.append$S((sep + "\"" + fname + "\"\n" ));
sep=",";
}
}sb.append$S("]\n");
return (returnString ? sb.toString() : null);
});

Clazz.newMeth(C$, 'contains$S',  function (fileName) {
return this.files.contains$O(fileName);
});

Clazz.newMeth(C$, 'add$S$J',  function (fileName, len) {
this.files.add$O(fileName);
(this.byteCount=Long.$add(this.byteCount,(len)));
});

Clazz.newMeth(C$, 'getByteCount$',  function () {
return this.byteCount;
});

Clazz.newMeth(C$, 'accept$S',  function (fileName) {
return (this.acceptPattern != null  && this.acceptPattern.matcher$CharSequence(fileName).find$() );
});

Clazz.newMeth(C$, 'setAcceptPattern$S',  function (pattern) {
this.acceptPattern=$I$(8).compile$S(pattern);
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.serialize$StringBuffer(null);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.Extractor, "ObjectParser", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['sData','dataSource'],'O',['p','java.util.regex.Pattern','regexList','java.util.List','keys','java.util.Map','extractor','com.integratedgraphics.ifd.Extractor','assignments','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_integratedgraphics_ifd_Extractor$S',  function (extractor, sObj) {
;C$.$init$.apply(this);
this.extractor=extractor;
var pt=Clazz.array(Integer.TYPE, [1]);
this.dataSource=$I$(9,"getIFDExtractValue$S$S$IA",[sObj, $I$(10).IFD_PROPERTY_COLLECTIONSET_SOURCE_DATA_URI, pt]);
if (this.dataSource == null ) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["No {" + $I$(10).IFD_PROPERTY_COLLECTIONSET_SOURCE_DATA_URI + "::...} found in " + sObj ]);
this.sData=sObj.substring$I(pt[0] + 1);
this.init$();
}, 1);

Clazz.newMeth(C$, 'addAssignment$S',  function (val) {
if (this.assignments == null ) this.assignments=Clazz.new_($I$(6,1));
var pt=val.indexOf$S("::") - 1;
if (pt < 0) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,[val + " is not of the form xx.xx.xx::definition"]);
val=val.substring$I$I(1, val.length$() - 1);
var prop=val.substring$I$I(0, pt);
val=val.substring$I(pt + 2);
this.assignments.add$O(Clazz.array(String, -1, [prop, val]));
});

Clazz.newMeth(C$, 'init$',  function () {
var s=this.protectRegex$S(null);
s=$I$(11,"rep$S$S$S",[s, "**/", "\\E(?:[^/]+/)\u0002\\Q"]);
var m;
if (s.indexOf$S("*") != s.lastIndexOf$S("*")) {
while ((m=$I$(9).pStarDotStar.matcher$CharSequence(s)).find$()){
var schar=m.group$I(1);
s=$I$(11,"rep$S$S$S",[s, "*" + schar + "*" , "\\E([^\u0005]+(?:\u0006[^\u0005]+)\u0002)\\Q".replaceAll$S$S("\u0006", "\\\\Q" + schar.charAt$I(0) + "\\\\E" ).replace$C$C("\u0005", schar.charAt$I(0))]);
}
}s=$I$(11).rep$S$S$S(s, "*", "\\E[^|/]+\\Q");
s=this.compileIFDDefs$S$Z$Z(s, true, true);
s=s.replace$C$C("\u0002", "*");
s="^" + "\\Q" + this.protectRegex$S(s) + "\\E" + "$" ;
s=$I$(11).rep$S$S$S(s, "\\Q\\E", "");
this.extractor.log$S("!Extractor.ObjectParser pattern: " + s);
this.p=$I$(8).compile$S(s);
});

Clazz.newMeth(C$, 'compileIFDDefs$S$Z$Z',  function (s, isFull, replaceK) {
while (s.indexOf$S("::") >= 0){
var m=$I$(9).objectDefPattern.matcher$CharSequence(s);
if (!m.find$()) return s;
var param=m.group$I(1);
var val=m.group$I(2);
var pv="{" + param + "::" + val + "}" ;
if (val.indexOf$S("::") >= 0) val=this.compileIFDDefs$S$Z$Z(val, false, replaceK);
var pt=param.indexOf$S("=");
if (pt == 0) throw Clazz.new_(Clazz.load('org.iupac.fairdata.common.IFDException').c$$S,["bad {def=key::val} expression: " + param + "::" + val ]);
if (this.keys == null ) this.keys=Clazz.new_($I$(12,1));
var key;
if (pt > 0) {
key=param.substring$I$I(0, pt);
param=param.substring$I(pt + 1);
} else {
key=param.replace$C$C(".", "0");
}this.keys.put$O$O(key, param);
var bk="{" + key + "}" ;
if (s.indexOf$S(bk) >= 0) {
s=$I$(11).rep$S$S$S(s, bk, "<" + key + ">" );
}s=$I$(11,"rep$S$S$S",[s, pv, (replaceK ? "\\E(?\u0003" + key + "\u0004\\Q"  : "\\E(?<" + key + ">\\Q" ) + val + "\\E)\\Q" ]);
}
if (isFull && (s.indexOf$S("<") >= 0 || s.indexOf$I("\u0003") >= 0 ) ) {
s=$I$(11).rep$S$S$S(s, "<", "\\E\\k<");
s=$I$(11).rep$S$S$S(s, ">", ">\\Q").replace$C$C("\u0003", "<").replace$C$C("\u0004", ">");
}return s;
});

Clazz.newMeth(C$, 'protectRegex$S',  function (s) {
if (this.sData.indexOf$S("{regex::") < 0) return (s == null  ? this.sData : s);
if (s == null ) {
s=this.sData;
this.regexList=Clazz.new_($I$(6,1));
var pt=Clazz.array(Integer.TYPE, [1]);
var i=0;
while ((pt[0]=s.indexOf$S("{regex::")) >= 0){
var p0=pt[0];
var rx=$I$(9).getIFDExtractValue$S$S$IA(s, "regex", pt);
this.regexList.add$O("\\E" + rx + "\\Q" );
s=s.substring$I$I(0, p0) + "\u0000" + (i++) + "\u0001" + s.substring$I(pt[0]) ;
}
} else {
var p;
while ((p=s.indexOf$I("\u0000")) >= 0){
var p2=s.indexOf$I("\u0001");
var i=Integer.parseInt$S(s.substring$I$I(p + 1, p2));
s=s.substring$I$I(0, p) + this.regexList.get$I(i) + s.substring$I(p2 + 1) ;
}
}return s;
});

Clazz.newMeth(C$, 'toString',  function () {
return "[ObjectParser " + this.sData + "]" ;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-23 05:42:35 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
