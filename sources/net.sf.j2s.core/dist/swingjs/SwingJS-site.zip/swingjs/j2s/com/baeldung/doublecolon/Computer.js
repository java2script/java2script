(function(){var P$=Clazz.newPackage("com.baeldung.doublecolon"),I$=[];
var C$=Clazz.newClass(P$, "Computer");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.age=null;
this.color=null;
this.healty=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$S', function (age, color) {
C$.$init$.apply(this);
this.age=new Integer(age);
this.color=color;
}, 1);

Clazz.newMeth(C$, 'c$$Integer$S$Integer', function (age, color, healty) {
C$.$init$.apply(this);
this.age=age;
this.color=color;
this.healty=healty;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getAge$', function () {
return this.age;
});

Clazz.newMeth(C$, 'setAge$Integer', function (age) {
this.age=age;
});

Clazz.newMeth(C$, 'getColor$', function () {
return this.color;
});

Clazz.newMeth(C$, 'setColor$S', function (color) {
this.color=color;
});

Clazz.newMeth(C$, 'getHealty$', function () {
return this.healty;
});

Clazz.newMeth(C$, 'setHealty$Integer', function (healty) {
this.healty=healty;
});

Clazz.newMeth(C$, 'turnOnPc$', function () {
System.out.println$S("Computer turned on " + this);
});

Clazz.newMeth(C$, 'turnOffPcStatic$com_baeldung_doublecolon_Computer', function (c) {
c.turnOffPc$();
}, 1);

Clazz.newMeth(C$, 'turnOffPc$', function () {
System.out.println$S("Computer turned off " + this);
});

Clazz.newMeth(C$, 'calculateValue$Double', function (initialValue) {
return new Double((initialValue).doubleValue$() / 1.5);
});

Clazz.newMeth(C$, 'toString', function () {
return "Computer{age=" + this.age + ", color='" + this.color + '\'' + ", healty=" + this.healty + '}' ;
});

Clazz.newMeth(C$, 'equals$O', function (o) {
if (this === o ) {
return true;
}if (o == null  || this.getClass$() !== o.getClass$()  ) {
return false;
}var computer=o;
return (this.age != null  ? this.age.equals$O(computer.age) : computer.age == null ) && (this.color != null  ? this.color.equals$O(computer.color) : computer.color == null ) ;
});

Clazz.newMeth(C$, 'hashCode$', function () {
var result=this.age != null  ? this.age.hashCode$() : 0;
result=31 * result + (this.color != null  ? this.color.hashCode$() : 0);
return result;
});
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 11:42:54 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
