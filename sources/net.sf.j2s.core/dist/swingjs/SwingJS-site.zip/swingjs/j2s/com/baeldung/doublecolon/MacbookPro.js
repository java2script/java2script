(function(){var P$=Clazz.newPackage("com.baeldung.doublecolon"),I$=[[0,'com.baeldung.doublecolon.Computer']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "MacbookPro", null, 'com.baeldung.doublecolon.Computer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$S', function (age, color) {
C$.superclazz.c$$I$S.apply(this, [age, color]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$Integer$S$Integer', function (age, color, healty) {
C$.superclazz.c$$Integer$S$Integer.apply(this, [age, color, healty]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'turnOnPc$', function () {
});

Clazz.newMeth(C$, 'turnOffPc$', function () {
});

Clazz.newMeth(C$, 'calculateValue$Double', function (initialValue) {
var $function=(P$.MacbookPro$lambda1$||(P$.MacbookPro$lambda1$=((function($class$){((P$.MacbookPro$lambda1||
(function(){var C$=Clazz.newClass(P$, "MacbookPro$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
/*lambda_S*/
Clazz.newMeth(C$, ['apply$'], function (t) { return t.calculateValue$Double.apply(t,[t])});
})()
)); return Clazz.new_(P$.MacbookPro$lambda1.$init$, [this, null])})($I$(1)))));
var pcValue=$function.apply$(initialValue);
return new Double((pcValue).doubleValue$() + ((initialValue).doubleValue$() / 10));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 11:42:54 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
