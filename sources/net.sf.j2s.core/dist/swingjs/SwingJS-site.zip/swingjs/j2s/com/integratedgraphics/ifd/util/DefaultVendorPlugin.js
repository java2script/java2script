(function(){var P$=Clazz.newPackage("com.integratedgraphics.ifd.util"),I$=[[0,'java.util.regex.Pattern','com.integratedgraphics.ifd.api.VendorPluginI','org.iupac.fairdata.common.IFDConst','org.jmol.util.Elements','jspecview.source.JDXDataObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DefaultVendorPlugin", null, null, 'com.integratedgraphics.ifd.api.VendorPluginI');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['rezipping','enabled'],'I',['index'],'S',['paramRegex','rezipRegex'],'O',['extractor','org.iupac.fairdata.extract.ExtractorI']]
,['S',['IFD_REP_DATAOBJECT_FAIRSPEC_NMR_VENDOR_DATASET','IFD_PROPERTY_DATAOBJECT_FAIRSPEC_NMR_INSTR_MANUFACTURER_NAME'],'O',['nucPat','java.util.regex.Pattern']]]

Clazz.newMeth(C$, 'register$Class',  function (c) {
$I$(2).registerIFDVendorPlugin$Class(c);
}, 1);

Clazz.newMeth(C$, 'setIndex$I',  function (index) {
this.index=index;
});

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'isEnabled$',  function () {
return true;
});

Clazz.newMeth(C$, 'getParamRegex$',  function () {
return this.paramRegex;
});

Clazz.newMeth(C$, 'getRezipRegex$',  function () {
return (this.rezipRegex == null  ? null : "^(?<path#>.+(?:/|\\|)(?<dir#>[^/]+)(?:/|\\|))".replace$CharSequence$CharSequence("#", "" + this.index) + this.rezipRegex);
});

Clazz.newMeth(C$, 'getRezipPrefix$S',  function (dirName) {
return null;
});

Clazz.newMeth(C$, 'accept$org_iupac_fairdata_extract_ExtractorI$S$BA',  function (extractor, zipOrPathName, bytes) {
if (extractor != null ) {
this.extractor=extractor;
}return this.processRepresentation$S$BA(null, null);
});

Clazz.newMeth(C$, 'doExtract$S',  function (entryName) {
return true;
});

Clazz.newMeth(C$, 'startRezip$org_iupac_fairdata_extract_ExtractorI',  function (extractor) {
this.extractor=extractor;
this.reportVendor$();
this.rezipping=true;
});

Clazz.newMeth(C$, 'getProp$S',  function (name) {
return $I$(3).getProp$S(name);
}, 1);

Clazz.newMeth(C$, 'reportVendor$',  function () {
this.addProperty$S$O(C$.IFD_PROPERTY_DATAOBJECT_FAIRSPEC_NMR_INSTR_MANUFACTURER_NAME, this.getVendorName$());
});

Clazz.newMeth(C$, 'endRezip$',  function () {
this.rezipping=false;
this.extractor=null;
});

Clazz.newMeth(C$, 'doRezipInclude$org_iupac_fairdata_extract_ExtractorI$S$S',  function (extractor, zipfileName, entryName) {
return true;
});

Clazz.newMeth(C$, 'addProperty$S$O',  function (key, val) {
if (Clazz.instanceOf(val, "java.lang.Double")) {
if (Double.isNaN$D((val).valueOf())) return;
}if (val != null  && this.extractor != null  ) this.extractor.addProperty$S$O(key, val);
});

Clazz.newMeth(C$, 'isUnsignedInteger$S',  function (s) {
for (var i=s.length$(); --i >= 0; ) if (!Character.isDigit$C(s.charAt$I(i))) return false;

return true;
}, 1);

Clazz.newMeth(C$, 'getDelimitedString$java_util_Map$S$C$C',  function (map, key, c0, c1) {
var val=map.get$O(key);
var n;
return (val == null  || (n=val.length$()) < 3  || val.charAt$I(0) != c0  || val.charAt$I(n - 1) != c1  ? null : val.substring$I$I(1, val.length$() - 1).trim$());
}, 1);

Clazz.newMeth(C$, 'getDoubleValue$java_util_Map$S',  function (map, key) {
var f=map.get$O(key);
try {
return (f == null  ? NaN : Double.valueOf$S(f).doubleValue$());
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
return NaN;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'fixNucleus$S',  function (nuc) {
var m=C$.nucPat.matcher$CharSequence(nuc);
if (m.find$()) {
var sn=m.group$I(2);
var el=m.group$I(1);
el=(el.length$() == 0 ? m.group$I(3) : el);
if (el.length$() > 2) {
var an=$I$(4).elementNumberFromName$S(el);
el=$I$(4).elementSymbolFromNumber$I(an);
if (el != null ) nuc=el;
} else {
nuc=el;
}if (nuc.length$() == 2) {
nuc=nuc.substring$I$I(0, 1).toUpperCase$() + nuc.substring$I(1).toLowerCase$();
}nuc=sn + nuc;
}return nuc;
}, 1);

Clazz.newMeth(C$, 'fixSolvent$S',  function (solvent) {
return solvent;
}, 1);

Clazz.newMeth(C$, 'getNominalFrequency$D$S',  function (freq, nuc) {
return $I$(5).getNominalSpecFreq$S$D(nuc, freq);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.IFD_REP_DATAOBJECT_FAIRSPEC_NMR_VENDOR_DATASET=C$.getProp$S("IFD_REP_DATAOBJECT_FAIRSPEC_NMR_VENDOR_DATASET");
C$.IFD_PROPERTY_DATAOBJECT_FAIRSPEC_NMR_INSTR_MANUFACTURER_NAME=C$.getProp$S("IFD_PROPERTY_DATAOBJECT_FAIRSPEC_NMR_INSTR_MANUFACTURER_NAME");
C$.nucPat=$I$(1,"compile$S",["(^[^\\d]*)(\\d+)([^\\d]*)$"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-11-21 14:29:48 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
