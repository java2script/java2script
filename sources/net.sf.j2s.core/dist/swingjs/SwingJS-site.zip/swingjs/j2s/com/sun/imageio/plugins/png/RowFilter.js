(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.png"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "RowFilter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'abs$I', function (x) {
return (x < 0) ? -x : x;
}, 1);

Clazz.newMeth(C$, 'subFilter$BA$BA$I$I', function (currRow, subFilteredRow, bytesPerPixel, bytesPerRow) {
let badness=0;
for (let i=bytesPerPixel; i < bytesPerRow + bytesPerPixel; i++) {
let curr=currRow[i] & 255;
let left=currRow[i - bytesPerPixel] & 255;
let difference=curr - left;
subFilteredRow[i]=(difference|0);
badness+=C$.abs$I(difference);
}
return badness;
}, 1);

Clazz.newMeth(C$, 'upFilter$BA$BA$BA$I$I', function (currRow, prevRow, upFilteredRow, bytesPerPixel, bytesPerRow) {
let badness=0;
for (let i=bytesPerPixel; i < bytesPerRow + bytesPerPixel; i++) {
let curr=currRow[i] & 255;
let up=prevRow[i] & 255;
let difference=curr - up;
upFilteredRow[i]=(difference|0);
badness+=C$.abs$I(difference);
}
return badness;
}, 1);

Clazz.newMeth(C$, 'paethPredictor$I$I$I', function (a, b, c) {
let p=a + b - c;
let pa=C$.abs$I(p - a);
let pb=C$.abs$I(p - b);
let pc=C$.abs$I(p - c);
if ((pa <= pb) && (pa <= pc) ) {
return a;
} else if (pb <= pc) {
return b;
} else {
return c;
}});

Clazz.newMeth(C$, 'filterRow$I$BA$BA$BAA$I$I', function (colorType, currRow, prevRow, scratchRows, bytesPerRow, bytesPerPixel) {
if (colorType != 3) {
System.arraycopy$O$I$O$I$I(currRow, bytesPerPixel, scratchRows[0], bytesPerPixel, bytesPerRow);
return 0;
}let filterBadness=Clazz.array(Integer.TYPE, [5]);
for (let i=0; i < 5; i++) {
filterBadness[i]=2147483647;
}
{
let badness=0;
for (let i=bytesPerPixel; i < bytesPerRow + bytesPerPixel; i++) {
let curr=currRow[i] & 255;
badness+=curr;
}
filterBadness[0]=badness;
}{
let subFilteredRow=scratchRows[1];
let badness=C$.subFilter$BA$BA$I$I(currRow, subFilteredRow, bytesPerPixel, bytesPerRow);
filterBadness[1]=badness;
}{
let upFilteredRow=scratchRows[2];
let badness=C$.upFilter$BA$BA$BA$I$I(currRow, prevRow, upFilteredRow, bytesPerPixel, bytesPerRow);
filterBadness[2]=badness;
}{
let averageFilteredRow=scratchRows[3];
let badness=0;
for (let i=bytesPerPixel; i < bytesPerRow + bytesPerPixel; i++) {
let curr=currRow[i] & 255;
let left=currRow[i - bytesPerPixel] & 255;
let up=prevRow[i] & 255;
let difference=curr - ((left + up)/2|0);
;averageFilteredRow[i]=(difference|0);
badness+=C$.abs$I(difference);
}
filterBadness[3]=badness;
}{
let paethFilteredRow=scratchRows[4];
let badness=0;
for (let i=bytesPerPixel; i < bytesPerRow + bytesPerPixel; i++) {
let curr=currRow[i] & 255;
let left=currRow[i - bytesPerPixel] & 255;
let up=prevRow[i] & 255;
let upleft=prevRow[i - bytesPerPixel] & 255;
let predictor=this.paethPredictor$I$I$I(left, up, upleft);
let difference=curr - predictor;
paethFilteredRow[i]=(difference|0);
badness+=C$.abs$I(difference);
}
filterBadness[4]=badness;
}let minBadness=filterBadness[0];
let filterType=0;
for (let i=1; i < 5; i++) {
if (filterBadness[i] < minBadness) {
minBadness=filterBadness[i];
filterType=i;
}}
if (filterType == 0) {
System.arraycopy$O$I$O$I$I(currRow, bytesPerPixel, scratchRows[0], bytesPerPixel, bytesPerRow);
}return filterType;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.10-v1');//Created 2020-07-08 11:10:10 Java2ScriptVisitor version 3.2.10-v1 net.sf.j2s.core.jar version 3.2.10-v1
