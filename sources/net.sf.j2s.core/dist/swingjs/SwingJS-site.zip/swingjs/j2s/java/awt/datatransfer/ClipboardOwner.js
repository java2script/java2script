(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ClipboardOwner");
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-17 16:36:53 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
