(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Readable");
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-20 07:49:52 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
