(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MultipleMaster");
})();
;Clazz.setTVer('5.0.1-v5');//Created 2025-02-23 19:45:41 Java2ScriptVisitor version 5.0.1-v5 net.sf.j2s.core.jar version 5.0.1-v5
