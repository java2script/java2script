(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "AWTError", null, 'Error');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (msg) {
C$.superclazz.c$$S.apply(this, [msg]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-17 13:15:43 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
