(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ComponentListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.7-v1');//Created 2020-01-08 10:33:31 Java2ScriptVisitor version 3.2.7-v1 net.sf.j2s.core.jar version 3.2.7-v1
