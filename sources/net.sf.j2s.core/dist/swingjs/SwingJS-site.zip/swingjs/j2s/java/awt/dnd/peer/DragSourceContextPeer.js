(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DragSourceContextPeer");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-07-13 18:27:24 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
