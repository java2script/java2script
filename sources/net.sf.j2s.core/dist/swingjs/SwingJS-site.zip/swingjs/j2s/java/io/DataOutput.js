(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DataOutput");
})();
;Clazz.setTVer('3.2.5-v2');//Created 2019-12-07 15:27:16 Java2ScriptVisitor version 3.2.5-v2 net.sf.j2s.core.jar version 3.2.5-v2
