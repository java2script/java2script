(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PanelPeer", null, null, 'java.awt.peer.LightweightPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:50:32 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
