(function(){var P$=Clazz.newPackage("java.lang.annotation"),I$=[];
var C$=Clazz.newClass(P$, "IncompleteAnnotationException", null, 'RuntimeException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.annotationType=null;
this.elementName=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$Class$S', function (annotationType, elementName) {
C$.superclazz.c$$S.apply(this, [Clazz.load('org.apache.harmony.luni.util.Msg').getString$S$O$O("annotation.0", elementName, annotationType)]);
C$.$init$.apply(this);
this.annotationType=annotationType;
this.elementName=elementName;
}, 1);

Clazz.newMeth(C$, 'annotationType$', function () {
return this.annotationType;
});

Clazz.newMeth(C$, 'elementName$', function () {
return this.elementName;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-30 14:48:54 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
