(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "Canvas", null, 'swingjs.a2s.Canvas');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (config) {
C$.$load$&&Clazz.load(C$,2);C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this, [config]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-13 09:28:59 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
