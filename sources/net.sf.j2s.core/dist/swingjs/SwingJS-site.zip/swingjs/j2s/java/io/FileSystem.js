(function(){var P$=java.io,I$=[];
var C$=Clazz.newClass(P$, "FileSystem");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getFileSystem$', function () {
return Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'getSeparator$', function () {
return "/";
});

Clazz.newMeth(C$, 'getPathSeparator$', function () {
return "/";
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-14 23:51:00 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
