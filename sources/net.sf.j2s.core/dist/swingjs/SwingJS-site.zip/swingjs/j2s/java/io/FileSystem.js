(function(){var P$=java.io,I$=[];
var C$=Clazz.newClass(P$, "FileSystem");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getFileSystem$', function () {
return Clazz.new_(C$);
}, 1);

Clazz.newMeth(C$, 'getSeparator$', function () {
return "/";
});

Clazz.newMeth(C$, 'getPathSeparator$', function () {
return "/";
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.06');//Created 2019-01-14 11:27:23 Java2ScriptVisitor version 3.2.4.06 net.sf.j2s.core.jar version 3.2.4.06
