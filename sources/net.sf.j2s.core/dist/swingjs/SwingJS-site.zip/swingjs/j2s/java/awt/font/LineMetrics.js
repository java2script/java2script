(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "LineMetrics");

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.5-v4');//Created 2019-12-15 10:19:31 Java2ScriptVisitor version 3.2.5-v4 net.sf.j2s.core.jar version 3.2.5-v4
