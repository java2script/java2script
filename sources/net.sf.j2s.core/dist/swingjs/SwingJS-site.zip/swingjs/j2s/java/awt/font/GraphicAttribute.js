(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
var C$=Clazz.newClass(P$, "GraphicAttribute");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fAlignment=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (alignment) {
C$.$init$.apply(this);
if (alignment < -2 || alignment > 2 ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["bad alignment"]);
}this.fAlignment=alignment;
}, 1);

Clazz.newMeth(C$, 'getBounds$', function () {
var ascent=this.getAscent$();
return Clazz.new_(Clazz.load(['java.awt.geom.Rectangle2D','.Float']).c$$F$F$F$F,[0, -ascent, this.getAdvance$(), ascent + this.getDescent$()]);
});

Clazz.newMeth(C$, 'getOutline$java_awt_geom_AffineTransform', function (tx) {
var b=this.getBounds$();
if (tx != null ) {
b=tx.createTransformedShape$java_awt_Shape(b);
}return b;
});

Clazz.newMeth(C$, 'getAlignment$', function () {
return this.fAlignment;
});

Clazz.newMeth(C$, 'getJustificationInfo$', function () {
var advance=this.getAdvance$();
return Clazz.new_(Clazz.load('java.awt.font.GlyphJustificationInfo').c$$F$Z$I$F$F$Z$I$F$F,[advance, false, 2, advance / 3, advance / 3, false, 1, 0, 0]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-24 06:19:42 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
