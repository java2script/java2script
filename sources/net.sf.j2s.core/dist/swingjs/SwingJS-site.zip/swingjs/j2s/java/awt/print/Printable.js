(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Printable");

C$.$fields$=[[]
,['I',['PAGE_EXISTS','NO_SUCH_PAGE']]]

C$.$static$=function(){C$.$static$=0;
C$.PAGE_EXISTS=0;
C$.NO_SUCH_PAGE=1;
};
})();
;Clazz.setTVer('3.3.1-v6');//Created 2023-03-20 19:03:59 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
