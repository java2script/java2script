(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
var C$=Clazz.newInterface(P$, "Printable");
C$.PAGE_EXISTS=0;
C$.NO_SUCH_PAGE=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.PAGE_EXISTS=0;
C$.NO_SUCH_PAGE=1;
}
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 17:09:40 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
