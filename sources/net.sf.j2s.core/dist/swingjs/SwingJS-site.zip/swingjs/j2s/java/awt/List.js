(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "List", null, 'swingjs.a2s.List');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$I$Z.apply(this,[0, false]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (rows) {
;C$.superclazz.c$$I$Z.apply(this,[rows, false]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$Z',  function (rows, multipleMode) {
;C$.superclazz.c$$I$Z.apply(this,[rows, multipleMode]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.3.1-v6');//Created 2023-03-20 19:03:51 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
