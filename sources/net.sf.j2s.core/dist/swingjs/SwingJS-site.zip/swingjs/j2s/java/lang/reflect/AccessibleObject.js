(function(){var P$=java.lang.reflect,I$=[[0,'java.lang.annotation.Annotation']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "AccessibleObject", null, null, 'java.lang.reflect.AnnotatedElement');
C$.emptyArgs=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.emptyArgs=Clazz.array(java.lang.Object, [0]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'isAccessible$', function () {
return false;
});

Clazz.newMeth(C$, 'setAccessible$reflect_AccessibleObjectA$Z', function (objects, flag) {
return;
}, 1);

Clazz.newMeth(C$, 'setAccessible$Z', function (flag) {
return;
});

Clazz.newMeth(C$, 'isAnnotationPresent$Class', function (annotationType) {
return false;
});

Clazz.newMeth(C$, 'getDeclaredAnnotations$', function () {
return Clazz.array($I$(1), [0]);
});

Clazz.newMeth(C$, 'getAnnotations$', function () {
return Clazz.array($I$(1), [0]);
});

Clazz.newMeth(C$, 'getAnnotation$Class', function (annotationType) {
return null;
});

Clazz.newMeth(C$, 'marshallArguments$ClassA$OA', function (parameterTypes, args) {
return null;
}, 1);

Clazz.newMeth(C$, 'invokeV$O$OA', function (receiver, args) {
return;
});

Clazz.newMeth(C$, 'invokeL$O$OA', function (receiver, args) {
return null;
});

Clazz.newMeth(C$, 'invokeI$O$OA', function (receiver, args) {
return 0;
});

Clazz.newMeth(C$, 'invokeJ$O$OA', function (receiver, args) {
return 0;
});

Clazz.newMeth(C$, 'invokeF$O$OA', function (receiver, args) {
return 0.0;
});

Clazz.newMeth(C$, 'invokeD$O$OA', function (receiver, args) {
return 0.0;
});

Clazz.newMeth(C$, 'getParameterTypesImpl$', function () {
return null;
});

Clazz.newMeth(C$, 'getModifiers$', function () {
return 0;
});

Clazz.newMeth(C$, 'getExceptionTypesImpl$', function () {
return null;
});

Clazz.newMeth(C$, 'getSignature$', function () {
return "__FIELD__";
});

Clazz.newMeth(C$, 'checkAccessibility$Class$O', function (senderClass, receiver) {
return true;
});

Clazz.newMeth(C$, 'initializeClass$Class', function (clazz) {
}, 1);

Clazz.newMeth(C$, 'getStackClass$I', function (depth) {
return null;
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-07 09:13:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
