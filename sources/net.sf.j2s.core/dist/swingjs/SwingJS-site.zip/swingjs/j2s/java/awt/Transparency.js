(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Transparency");
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-31 16:16:21 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
