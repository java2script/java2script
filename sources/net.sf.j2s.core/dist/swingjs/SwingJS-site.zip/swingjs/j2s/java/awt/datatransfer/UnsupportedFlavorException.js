(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "UnsupportedFlavorException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_awt_datatransfer_DataFlavor', function (flavor) {
;C$.superclazz.c$$S.apply(this,[(flavor != null ) ? flavor.getHumanPresentableName$() : null]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.7-v5');//Created 2020-02-01 07:02:04 Java2ScriptVisitor version 3.2.7-v5 net.sf.j2s.core.jar version 3.2.7-v5
