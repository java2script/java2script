(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "UnsupportedFlavorException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$java_awt_datatransfer_DataFlavor',  function (flavor) {
;C$.superclazz.c$$S.apply(this,[(flavor != null ) ? flavor.getHumanPresentableName$() : null]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-02 18:46:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
