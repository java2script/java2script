(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ItemSelectable");
})();
;Clazz.setTVer('3.2.5-v4');//Created 2019-12-15 10:19:23 Java2ScriptVisitor version 3.2.5-v4 net.sf.j2s.core.jar version 3.2.5-v4
