(function(){var P$=java.io,I$=[[0,'java.io.SerializablePermission']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*i*/var C$=Clazz.newInterface(P$, "ObjectStreamConstants");

C$.$static$ = function() {C$.$static$=0;
C$.SUBSTITUTION_PERMISSION=Clazz.new_($I$(1,1).c$$S,["enableSubstitution"]);
C$.SUBCLASS_IMPLEMENTATION_PERMISSION=Clazz.new_($I$(1,1).c$$S,["enableSubclassImplementation"]);
}

C$.$fields$=[[]
,['B',['TC_BASE','TC_NULL','TC_REFERENCE','TC_CLASSDESC','TC_OBJECT','TC_STRING','TC_ARRAY','TC_CLASS','TC_BLOCKDATA','TC_ENDBLOCKDATA','TC_RESET','TC_BLOCKDATALONG','TC_EXCEPTION','TC_LONGSTRING','TC_PROXYCLASSDESC','TC_ENUM','TC_MAX','SC_WRITE_METHOD','SC_BLOCK_DATA','SC_SERIALIZABLE','SC_EXTERNALIZABLE','SC_ENUM'],'I',['baseWireHandle','PROTOCOL_VERSION_1','PROTOCOL_VERSION_2'],'H',['STREAM_MAGIC','STREAM_VERSION'],'O',['SUBSTITUTION_PERMISSION','java.io.SerializablePermission','+SUBCLASS_IMPLEMENTATION_PERMISSION']]]
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-22 23:13:54 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
