(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "GraphicsEnvironment");
C$.localEnv=null;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getLocalGraphicsEnvironment$', function () {
if (C$.localEnv == null ) {
C$.localEnv=Clazz.load('swingjs.JSUtil').getInstance$S("swingjs.JSGraphicsEnvironment");
}return C$.localEnv;
}, 1);

Clazz.newMeth(C$, 'isHeadless$', function () {
return false;
}, 1);

Clazz.newMeth(C$, 'getHeadlessProperty$', function () {
return false;
}, 1);

Clazz.newMeth(C$, 'checkHeadless$', function () {
}, 1);

Clazz.newMeth(C$, 'isHeadlessInstance$', function () {
return C$.getHeadlessProperty$();
});

Clazz.newMeth(C$, 'registerFont$java_awt_Font', function (font) {
return true;
});

Clazz.newMeth(C$, 'preferLocaleFonts$', function () {
});

Clazz.newMeth(C$, 'preferProportionalFonts$', function () {
});

Clazz.newMeth(C$, 'getCenterPoint$', function () {
return null;
});
})();
;Clazz.setTVer('3.2.4.02');//Created 2018-11-04 12:14:59 Java2ScriptVisitor version 3.2.4.02 net.sf.j2s.core.jar version 3.2.4.02
