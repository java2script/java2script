(function(){var P$=java.io,I$=[[0,'java.io.FileOutputStream']],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FileWriter", null, 'java.io.OutputStreamWriter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S', function (fileName) {
;C$.superclazz.c$$java_io_OutputStream.apply(this,[Clazz.new_($I$(1,1).c$$S,[fileName])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (fileName, append) {
;C$.superclazz.c$$java_io_OutputStream.apply(this,[Clazz.new_($I$(1,1).c$$S$Z,[fileName, append])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (file) {
;C$.superclazz.c$$java_io_OutputStream.apply(this,[Clazz.new_($I$(1,1).c$$java_io_File,[file])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$Z', function (file, append) {
;C$.superclazz.c$$java_io_OutputStream.apply(this,[Clazz.new_($I$(1,1).c$$java_io_File$Z,[file, append])]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-11 10:55:29 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
