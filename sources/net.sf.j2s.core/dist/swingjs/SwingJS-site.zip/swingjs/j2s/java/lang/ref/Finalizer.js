(function(){var P$=Clazz.newPackage("java.lang.ref"),p$1={},I$=[[0,'sun.misc.VM','sun.misc.SharedSecrets','java.lang.ref.Finalizer','java.lang.ref.ReferenceQueue','Thread',['java.lang.ref.Finalizer','.FinalizerThread'],'java.security.AccessController']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Finalizer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.lang.ref.FinalReference');
C$.$queue=null;
C$.unfinalized=null;
C$.$lock=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.$queue=Clazz.new_($I$(4));
C$.unfinalized=null;
C$.$lock= Clazz.new_();
{
var tg=$I$(5).currentThread$().getThreadGroup$();
for (var tgn=tg; tgn != null ; tg=tgn, tgn=tg.getParent$()) ;
var finalizer=Clazz.new_($I$(6).c$$ThreadGroup,[tg]);
finalizer.setPriority$I(8);
finalizer.setDaemon$Z(true);
finalizer.start$();
};
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$next=null;
this.prev=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$next=null;
this.prev=null;
}, 1);

Clazz.newMeth(C$, 'hasBeenFinalized', function () {
return (this.$next === this );
}, p$1);

Clazz.newMeth(C$, 'add', function () {
{
if (C$.unfinalized != null ) {
this.$next=C$.unfinalized;
C$.unfinalized.prev=this;
}C$.unfinalized=this;
}}, p$1);

Clazz.newMeth(C$, 'remove', function () {
{
if (C$.unfinalized === this ) {
if (this.$next != null ) {
C$.unfinalized=this.$next;
} else {
C$.unfinalized=this.prev;
}}if (this.$next != null ) {
this.$next.prev=this.prev;
}if (this.prev != null ) {
this.prev.$next=this.$next;
}this.$next=this;
this.prev=this;
}}, p$1);

Clazz.newMeth(C$, 'c$$O', function (finalizee) {
C$.superclazz.c$$TT$ref_ReferenceQueue.apply(this, [finalizee, C$.$queue]);
C$.$init$.apply(this);
p$1.add.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'register$O', function (finalizee) {
Clazz.new_(C$.c$$O,[finalizee]);
}, 1);

Clazz.newMeth(C$, 'runFinalizer$sun_misc_JavaLangAccess', function (jla) {
{
if (p$1.hasBeenFinalized.apply(this, [])) return;
p$1.remove.apply(this, []);
}try {
var finalizee=this.get$();
if (finalizee != null  && !(Clazz.instanceOf(finalizee, "java.lang.Enum")) ) {
jla.invokeFinalize$O(finalizee);
finalizee=null;
}} catch (x) {
}
C$.superclazz.prototype.clear$.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'forkSecondaryFinalizer$Runnable', function (proc) {
$I$(7).doPrivileged$java_security_PrivilegedAction(((P$.Finalizer$1||
(function(){var C$=Clazz.newClass(P$, "Finalizer$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedAction', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run$', function () {
var tg=$I$(5).currentThread$().getThreadGroup$();
for (var tgn=tg; tgn != null ; tg=tgn, tgn=tg.getParent$()) ;
var sft=Clazz.new_($I$(5).c$$ThreadGroup$Runnable$S,[tg, this.$finals$.proc, "Secondary finalizer"]);
sft.start$();
try {
sft.join$();
} catch (x) {
if (Clazz.exceptionOf(x,"InterruptedException")){
} else {
throw x;
}
}
return null;
});
})()
), Clazz.new_(P$.Finalizer$1.$init$, [this, {proc: proc}])));
}, 1);

Clazz.newMeth(C$, 'runFinalization$', function () {
if (!$I$(1).isBooted$()) {
return;
}C$.forkSecondaryFinalizer$Runnable(((P$.Finalizer$2||
(function(){var C$=Clazz.newClass(P$, "Finalizer$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.running=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run$', function () {
if (this.running) return;
var jla=$I$(2).getJavaLangAccess$();
this.running=true;
for (; ; ) {
var f=$I$(3).$queue.poll$();
if (f == null ) break;
p$1.runFinalizer$sun_misc_JavaLangAccess.apply(f, [jla]);
}
});
})()
), Clazz.new_(P$.Finalizer$2.$init$, [this, null])));
}, 1);

Clazz.newMeth(C$, 'runAllFinalizers$', function () {
if (!$I$(1).isBooted$()) {
return;
}C$.forkSecondaryFinalizer$Runnable(((P$.Finalizer$3||
(function(){var C$=Clazz.newClass(P$, "Finalizer$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.running=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run$', function () {
if (this.running) return;
var jla=$I$(2).getJavaLangAccess$();
this.running=true;
for (; ; ) {
var f;
{
f=$I$(3).unfinalized;
if (f == null ) break;
$I$(3).unfinalized=f.$next;
}p$1.runFinalizer$sun_misc_JavaLangAccess.apply(f, [jla]);
}
});
})()
), Clazz.new_(P$.Finalizer$3.$init$, [this, null])));
}, 1);
;
(function(){var C$=Clazz.newClass(P$.Finalizer, "FinalizerThread", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.running=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$ThreadGroup', function (g) {
C$.superclazz.c$$ThreadGroup$S.apply(this, [g, "Finalizer"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'run$', function () {
if (this.running) return;
while (!$I$(1).isBooted$()){
try {
$I$(1).awaitBooted$();
} catch (x) {
if (Clazz.exceptionOf(x,"InterruptedException")){
} else {
throw x;
}
}
}
var jla=$I$(2).getJavaLangAccess$();
this.running=true;
for (; ; ) {
try {
var f=$I$(3).$queue.remove$();
p$1.runFinalizer$sun_misc_JavaLangAccess.apply(f, [jla]);
} catch (x) {
if (Clazz.exceptionOf(x,"InterruptedException")){
} else {
throw x;
}
}
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-21 08:24:20 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
