(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethodContext", null, null, 'java.awt.im.InputMethodRequests');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-07-22 00:08:53 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
