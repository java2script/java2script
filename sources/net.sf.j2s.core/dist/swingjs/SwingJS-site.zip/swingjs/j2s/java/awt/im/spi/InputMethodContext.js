(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethodContext", null, null, 'java.awt.im.InputMethodRequests');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-03-27 14:07:17 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
