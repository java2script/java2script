(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "PaintContext");
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-12-03 11:01:19 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
