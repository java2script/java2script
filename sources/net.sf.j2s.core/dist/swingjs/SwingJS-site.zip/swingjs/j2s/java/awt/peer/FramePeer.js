(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FramePeer", null, null, 'java.awt.peer.WindowPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-07-06 17:56:47 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
