(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Menu", null, 'swingjs.a2s.Menu');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.isHelpMenu=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (label) {
;C$.superclazz.c$$S.apply(this, [label]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (label, tearOff) {
;C$.superclazz.c$$S.apply(this, [label]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v4');//Created 2019-12-15 10:19:24 Java2ScriptVisitor version 3.2.5-v4 net.sf.j2s.core.jar version 3.2.5-v4
