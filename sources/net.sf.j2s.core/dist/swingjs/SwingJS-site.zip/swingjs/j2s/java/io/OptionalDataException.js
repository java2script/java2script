(function(){var P$=java.io,I$=[];
var C$=Clazz.newClass(P$, "OptionalDataException", null, 'java.io.ObjectStreamException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.length=0;
this.eof=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (len) {
Clazz.super_(C$, this,1);
this.eof=false;
this.length=len;
}, 1);

Clazz.newMeth(C$, 'c$$Z', function (end) {
Clazz.super_(C$, this,1);
this.length=0;
this.eof=end;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.09');//Created 2019-10-27 12:18:44 Java2ScriptVisitor version 3.2.4.09 net.sf.j2s.core.jar version 3.2.4.09
