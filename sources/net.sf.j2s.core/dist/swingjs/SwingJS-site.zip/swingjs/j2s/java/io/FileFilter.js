(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FileFilter");
})();
;Clazz.setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
