(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Comparable");
})();
;Clazz.setTVer('3.2.4.06');//Created 2019-01-14 00:56:16 Java2ScriptVisitor version 3.2.4.06 net.sf.j2s.core.jar version 3.2.4.06
