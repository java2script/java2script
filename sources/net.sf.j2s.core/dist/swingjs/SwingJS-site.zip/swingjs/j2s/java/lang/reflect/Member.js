(function(){var P$=java.lang.reflect,I$=[];
var C$=Clazz.newInterface(P$, "Member");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-23 08:35:00 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
