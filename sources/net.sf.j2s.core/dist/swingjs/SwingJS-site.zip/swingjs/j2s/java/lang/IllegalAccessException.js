(function(){var P$=java.lang,I$=[];
/*c*/var C$=Clazz.newClass(P$, "IllegalAccessException", null, 'ReflectiveOperationException');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (s) {
;C$.superclazz.c$$S.apply(this, [s]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v2');//Created 2019-12-12 19:00:17 Java2ScriptVisitor version 3.2.5-v2 net.sf.j2s.core.jar version 3.2.5-v2
