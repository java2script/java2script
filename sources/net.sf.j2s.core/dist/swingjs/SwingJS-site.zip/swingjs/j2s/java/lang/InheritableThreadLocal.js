(function(){var P$=java.lang,I$=[[0,['ThreadLocal','.ThreadLocalMap']]],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "InheritableThreadLocal", null, 'ThreadLocal');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['childValue$TT'], function (parentValue) {
return parentValue;
});

Clazz.newMeth(C$, 'getMap$Thread', function (t) {
return t.inheritableThreadLocals;
});

Clazz.newMeth(C$, ['createMap$Thread$TT'], function (t, firstValue) {
t.inheritableThreadLocals=Clazz.new_($I$(1,1).c$$ThreadLocal$O,[this, firstValue]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-21 18:53:04 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
