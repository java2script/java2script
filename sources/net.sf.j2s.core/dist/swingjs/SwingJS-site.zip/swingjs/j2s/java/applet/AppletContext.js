(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletContext");
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-12-03 11:01:13 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
