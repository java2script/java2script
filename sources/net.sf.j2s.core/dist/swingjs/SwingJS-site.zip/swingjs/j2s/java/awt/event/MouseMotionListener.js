(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MouseMotionListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-28 08:36:36 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
