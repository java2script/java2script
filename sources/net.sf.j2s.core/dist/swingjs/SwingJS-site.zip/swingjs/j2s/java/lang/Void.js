(function(){var P$=java.lang,I$=[];
/*c*/var C$=Clazz.newClass(P$, "Void");
C$.TYPE=null;

C$.$clinit$=1;

C$.$static$ = function() {C$.$static$=0;
C$.TYPE=null;
{

java.lang.Void.TYPE = java.lang.Void;
};
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-20 22:35:34 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
