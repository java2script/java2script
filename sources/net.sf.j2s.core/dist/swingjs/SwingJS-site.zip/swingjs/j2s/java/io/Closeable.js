(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Closeable", null, null, 'AutoCloseable');

C$.$clinit$=1;
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-12-03 12:47:45 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
