(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Stroke");
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-12 22:22:14 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
