(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ComponentPeer");

C$.$fields$=[[]
,['I',['SET_LOCATION','SET_SIZE','SET_BOUNDS','SET_CLIENT_SIZE','RESET_OPERATION','NO_EMBEDDED_CHECK','DEFAULT_OPERATION']]]
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-21 18:52:59 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
