(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-14 23:50:58 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
