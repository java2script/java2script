(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-22 20:58:54 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
