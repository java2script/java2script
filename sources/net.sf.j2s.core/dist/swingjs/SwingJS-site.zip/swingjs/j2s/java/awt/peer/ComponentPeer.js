(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ComponentPeer");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-07-13 17:09:23 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
