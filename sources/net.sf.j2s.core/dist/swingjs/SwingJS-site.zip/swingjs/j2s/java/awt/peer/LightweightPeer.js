(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LightweightPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=1;
})();
;Clazz.setTVer('3.2.5-v4');//Created 2019-12-15 10:19:36 Java2ScriptVisitor version 3.2.5-v4 net.sf.j2s.core.jar version 3.2.5-v4
