(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LightweightPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.3.1-v4');//Created 2022-03-19 05:25:17 Java2ScriptVisitor version 3.3.1-v4 net.sf.j2s.core.jar version 3.3.1-v4
