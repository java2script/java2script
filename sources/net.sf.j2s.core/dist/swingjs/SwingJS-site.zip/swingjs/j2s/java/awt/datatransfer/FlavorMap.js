(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "FlavorMap");
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-11-01 19:40:04 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
