(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LayoutManager2", null, null, 'java.awt.LayoutManager');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.8-v2');//Created 2020-02-19 15:02:00 Java2ScriptVisitor version 3.2.8-v2 net.sf.j2s.core.jar version 3.2.8-v2
