(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Pageable");

C$.$fields$=[[]
,['I',['UNKNOWN_NUMBER_OF_PAGES']]]

C$.$static$=function(){C$.$static$=0;
C$.UNKNOWN_NUMBER_OF_PAGES=-1;
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:23:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
