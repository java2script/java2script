(function(){var P$=Clazz.newPackage("java.awt.print"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Pageable");

C$.$static$ = function() {C$.$static$=0;
C$.UNKNOWN_NUMBER_OF_PAGES=-1;
}

C$.$fields$=[[]
,['I',['UNKNOWN_NUMBER_OF_PAGES']]]
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-21 18:53:00 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
