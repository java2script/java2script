(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Flushable");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-05-13 18:24:39 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
