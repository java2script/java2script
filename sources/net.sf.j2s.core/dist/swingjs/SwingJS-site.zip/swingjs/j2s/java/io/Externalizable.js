(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Externalizable", null, null, 'java.io.Serializable');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.8-v2');//Created 2020-02-19 15:02:12 Java2ScriptVisitor version 3.2.8-v2 net.sf.j2s.core.jar version 3.2.8-v2
