(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Runnable");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-07 09:13:03 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
