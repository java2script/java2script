(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageConsumer");
C$.RANDOMPIXELORDER=0;
C$.TOPDOWNLEFTRIGHT=0;
C$.COMPLETESCANLINES=0;
C$.SINGLEPASS=0;
C$.SINGLEFRAME=0;
C$.IMAGEERROR=0;
C$.SINGLEFRAMEDONE=0;
C$.STATICIMAGEDONE=0;
C$.IMAGEABORTED=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.RANDOMPIXELORDER=1;
C$.TOPDOWNLEFTRIGHT=2;
C$.COMPLETESCANLINES=4;
C$.SINGLEPASS=8;
C$.SINGLEFRAME=16;
C$.IMAGEERROR=1;
C$.SINGLEFRAMEDONE=2;
C$.STATICIMAGEDONE=3;
C$.IMAGEABORTED=4;
}
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 13:18:41 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
