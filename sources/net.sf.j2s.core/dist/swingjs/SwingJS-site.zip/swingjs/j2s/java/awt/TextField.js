(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TextField", null, 'swingjs.a2s.TextField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
;C$.superclazz.c$$S.apply(this,[text]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (columns) {
;C$.superclazz.c$$I.apply(this,[columns]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (text, columns) {
;C$.superclazz.c$$S$I.apply(this,[text, columns]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-17 13:51:19 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
