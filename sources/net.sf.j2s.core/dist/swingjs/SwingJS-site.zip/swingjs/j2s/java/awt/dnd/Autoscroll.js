(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
var C$=Clazz.newInterface(P$, "Autoscroll");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-02-06 18:30:12 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
