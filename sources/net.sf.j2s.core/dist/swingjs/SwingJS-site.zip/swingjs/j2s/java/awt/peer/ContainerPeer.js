(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
var C$=Clazz.newInterface(P$, "ContainerPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.4.02');//Created 2018-11-06 18:55:57 Java2ScriptVisitor version 3.2.4.02 net.sf.j2s.core.jar version 3.2.4.02
