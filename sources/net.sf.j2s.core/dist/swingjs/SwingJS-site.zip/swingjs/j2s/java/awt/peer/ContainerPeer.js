(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ContainerPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-21 18:53:00 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
