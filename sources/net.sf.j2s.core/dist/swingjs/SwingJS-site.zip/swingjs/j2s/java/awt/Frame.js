(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newClass(P$, "Frame", null, 'swingjs.a2s.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this, [gc]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (title) {
C$.superclazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_GraphicsConfiguration', function (title, gc) {
C$.superclazz.c$$S$java_awt_GraphicsConfiguration.apply(this, [title, gc]);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-12-09 14:32:21 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
