(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Frame", null, 'swingjs.a2s.Frame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
;C$.superclazz.c$$java_awt_GraphicsConfiguration.apply(this,[gc]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (title) {
;C$.superclazz.c$$S.apply(this,[title]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_GraphicsConfiguration', function (title, gc) {
;C$.superclazz.c$$S$java_awt_GraphicsConfiguration.apply(this,[title, gc]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-25 07:21:15 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
