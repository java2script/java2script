(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AudioClip");
})();
;Clazz.setTVer('3.2.4.02');//Created 2018-11-08 07:22:28 Java2ScriptVisitor version 3.2.4.02 net.sf.j2s.core.jar version 3.2.4.02
