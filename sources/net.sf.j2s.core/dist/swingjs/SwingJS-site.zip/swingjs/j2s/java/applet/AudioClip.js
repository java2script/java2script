(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AudioClip");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-06-30 16:15:58 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
