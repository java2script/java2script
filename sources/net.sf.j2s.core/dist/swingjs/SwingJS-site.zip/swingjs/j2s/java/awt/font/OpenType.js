(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "OpenType");

C$.$fields$=[[]
,['I',['TAG_CMAP','TAG_HEAD','TAG_NAME','TAG_GLYF','TAG_MAXP','TAG_PREP','TAG_HMTX','TAG_KERN','TAG_HDMX','TAG_LOCA','TAG_POST','TAG_OS2','TAG_CVT','TAG_GASP','TAG_VDMX','TAG_VMTX','TAG_VHEA','TAG_HHEA','TAG_TYP1','TAG_BSLN','TAG_GSUB','TAG_DSIG','TAG_FPGM','TAG_FVAR','TAG_GVAR','TAG_CFF','TAG_MMSD','TAG_MMFX','TAG_BASE','TAG_GDEF','TAG_GPOS','TAG_JSTF','TAG_EBDT','TAG_EBLC','TAG_EBSC','TAG_LTSH','TAG_PCLT','TAG_ACNT','TAG_AVAR','TAG_BDAT','TAG_BLOC','TAG_CVAR','TAG_FEAT','TAG_FDSC','TAG_FMTX','TAG_JUST','TAG_LCAR','TAG_MORT','TAG_OPBD','TAG_PROP','TAG_TRAK']]]
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-22 23:13:47 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
