(function(){var P$=Clazz.newPackage("java.awt.font"),I$=[];
var C$=Clazz.newInterface(P$, "OpenType");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-03-22 09:27:02 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
