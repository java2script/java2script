(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
var C$=Clazz.newClass(P$, "GeneralPath", null, ['java.awt.geom.Path2D','.Float']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$$I$I.apply(this, [1, 20]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (rule) {
C$.superclazz.c$$I$I.apply(this, [rule, 20]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (rule, initialCapacity) {
C$.superclazz.c$$I$I.apply(this, [rule, initialCapacity]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Shape', function (s) {
C$.superclazz.c$$java_awt_Shape$java_awt_geom_AffineTransform.apply(this, [s, null]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$BA$I$FA$I', function (windingRule, pointTypes, numTypes, pointCoords, numCoords) {
Clazz.super_(C$, this,1);
this.windingRule=windingRule;
this.pointTypes=pointTypes;
this.numTypes=numTypes;
this.floatCoords=pointCoords;
this.numCoords=numCoords;
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-07-14 10:26:22 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
