(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ActionListener", null, null, 'java.util.EventListener');

C$.$clinit$=1;
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-11-27 14:06:25 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
