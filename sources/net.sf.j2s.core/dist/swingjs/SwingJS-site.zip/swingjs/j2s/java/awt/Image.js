(function(){var P$=Clazz.newPackage("java.awt"),I$=[[0,'java.awt.image.AreaAveragingScaleFilter','java.awt.image.ReplicateScaleFilter','java.awt.image.FilteredImageSource','java.awt.Toolkit']],$I$=function(i,n){return ((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
var C$=Clazz.newClass(P$, "Image");
C$.UndefinedProperty=null;

C$.$clinit$=1;

C$.$static$ = function() {C$.$static$=0;
C$.UndefinedProperty= Clazz.new_();
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.accelerationPriority=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.accelerationPriority=0.5;
}, 1);

Clazz.newMeth(C$, 'getScaledInstance$I$I$I', function (width, height, hints) {
var filter;
if ((hints & (20)) != 0) {
filter=Clazz.new_($I$(1,1).c$$I$I,[width, height]);
} else {
filter=Clazz.new_($I$(2,1).c$$I$I,[width, height]);
}var prod;
prod=Clazz.new_($I$(3,1).c$$java_awt_image_ImageProducer$java_awt_image_ImageFilter,[this.getSource$(), filter]);
return $I$(4).getDefaultToolkit$().createImage$java_awt_image_ImageProducer(prod);
});

Clazz.newMeth(C$, 'flush$', function () {
});

Clazz.newMeth(C$, 'setAccelerationPriority$F', function (priority) {
});

Clazz.newMeth(C$, 'getAccelerationPriority$', function () {
return this.accelerationPriority;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-13 09:29:07 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
