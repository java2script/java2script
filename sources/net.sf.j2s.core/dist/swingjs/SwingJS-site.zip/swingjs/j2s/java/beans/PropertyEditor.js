(function(){var P$=Clazz.newPackage("java.beans"),I$=[];
var C$=Clazz.newInterface(P$, "PropertyEditor");
})();
;Clazz.setTVer('3.2.4.08');//Created 2019-10-24 13:18:46 Java2ScriptVisitor version 3.2.4.08 net.sf.j2s.core.jar version 3.2.4.08
