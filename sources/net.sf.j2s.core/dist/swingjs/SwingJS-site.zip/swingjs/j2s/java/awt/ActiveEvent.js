(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ActiveEvent");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-14 19:06:57 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
