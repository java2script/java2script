(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ActiveEvent");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-04-10 06:36:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
