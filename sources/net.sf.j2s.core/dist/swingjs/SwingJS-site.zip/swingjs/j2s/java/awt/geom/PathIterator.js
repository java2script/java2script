(function(){var P$=Clazz.newPackage("java.awt.geom"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "PathIterator");
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-13 09:09:56 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
