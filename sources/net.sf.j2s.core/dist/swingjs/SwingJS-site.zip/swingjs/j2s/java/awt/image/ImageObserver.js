(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageObserver");
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-10 20:59:47 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
