(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageObserver");
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-23 12:28:31 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
