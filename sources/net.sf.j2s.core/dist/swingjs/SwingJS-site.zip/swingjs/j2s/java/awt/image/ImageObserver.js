(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ImageObserver");
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-07-22 00:08:54 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
