(function(){var P$=java.io,p$1={},I$=[[0,'java.io.File','java.io.FileDescriptor','swingjs.JSFileChannel']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "FileOutputStream", null, 'java.io.OutputStream');

C$.$clinit$ = function() {Clazz.load(C$, 1);
{
C$.initIDs$();
}
;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fd=null;
this.append=false;
this.channel=null;
this.path=null;
this.closeLock=null;
this.closed=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.closeLock= Clazz.new_();
this.closed=false;
}, 1);

Clazz.newMeth(C$, 'c$$S', function (name) {
C$.c$$java_io_File$Z.apply(this, [name != null  ? Clazz.new_(Clazz.load('java.io.File').c$$S,[name]) : null, false]);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z', function (name, append) {
C$.c$$java_io_File$Z.apply(this, [name != null  ? Clazz.new_($I$(1).c$$S,[name]) : null, append]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File', function (file) {
C$.c$$java_io_File$Z.apply(this, [file, false]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$Z', function (file, append) {
Clazz.super_(C$, this,1);
var name=(file != null  ? file.getPath$() : null);
var security=System.getSecurityManager$();
if (security != null ) {
security.checkWrite$S(name);
}if (name == null ) {
throw Clazz.new_(Clazz.load('NullPointerException'));
}this.fd=Clazz.new_(Clazz.load('java.io.FileDescriptor'));
this.fd.attach$java_io_Closeable(this);
this.append=append;
this.path=name;
p$1.open$S$Z.apply(this, [name, append]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_FileDescriptor', function (fdObj) {
Clazz.super_(C$, this,1);
var security=System.getSecurityManager$();
if (fdObj == null ) {
throw Clazz.new_(Clazz.load('NullPointerException'));
}if (security != null ) {
security.checkWrite$java_io_FileDescriptor(fdObj);
}this.fd=fdObj;
this.append=false;
this.path=null;
this.fd.attach$java_io_Closeable(this);
}, 1);

Clazz.newMeth(C$, 'open0$S$Z', function (name, append) {
alert('native method must be replaced! Ljava/io/FileOutputStream;.open0(Ljava/lang/String;Z)V|Ljava/io/FileNotFoundException;');
}
, p$1);

Clazz.newMeth(C$, 'open$S$Z', function (name, append) {
p$1.open0$S$Z.apply(this, [name, append]);
}, p$1);

Clazz.newMeth(C$, 'write$I$Z', function (b, append) {
alert('native method must be replaced! Ljava/io/FileOutputStream;.write(IZ)V|Ljava/io/IOException;');
}
, p$1);

Clazz.newMeth(C$, 'write$I', function (b) {
p$1.write$I$Z.apply(this, [b, this.append]);
});

Clazz.newMeth(C$, 'writeBytes$BA$I$I$Z', function (b, off, len, append) {
alert('native method must be replaced! Ljava/io/FileOutputStream;.writeBytes([BIIZ)V|Ljava/io/IOException;');
}
, p$1);

Clazz.newMeth(C$, 'write$BA', function (b) {
p$1.writeBytes$BA$I$I$Z.apply(this, [b, 0, b.length, this.append]);
});

Clazz.newMeth(C$, 'write$BA$I$I', function (b, off, len) {
p$1.writeBytes$BA$I$I$Z.apply(this, [b, off, len, this.append]);
});

Clazz.newMeth(C$, 'close$', function () {
{
if (this.closed) {
return;
}this.closed=true;
}if (this.channel != null ) {
this.channel.close$();
}this.fd.closeAll$java_io_Closeable(((P$.FileOutputStream$1||
(function(){var C$=Clazz.newClass(P$, "FileOutputStream$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.io.Closeable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'close$', function () {
p$1.close0.apply(this.b$['java.io.FileOutputStream'], []);
});
})()
), Clazz.new_(P$.FileOutputStream$1.$init$, [this, null])));
});

Clazz.newMeth(C$, 'getFD$', function () {
if (this.fd != null ) {
return this.fd;
}throw Clazz.new_(Clazz.load('java.io.IOException'));
});

Clazz.newMeth(C$, 'getChannel$', function () {
{
if (this.channel == null ) {
this.channel=Clazz.load('swingjs.JSFileChannel').open$java_io_FileDescriptor$S$Z$Z$Z$O(this.fd, this.path, false, true, this.append, this);
}return this.channel;
}});

Clazz.newMeth(C$, 'finalize$', function () {
if (this.fd != null ) {
if (this.fd === $I$(2).out  || this.fd === $I$(2).err  ) {
this.flush$();
} else {
this.close$();
}}});

Clazz.newMeth(C$, 'close0', function () {
alert('native method must be replaced! Ljava/io/FileOutputStream;.close0()V|Ljava/io/IOException;');
}
, p$1);

Clazz.newMeth(C$, 'initIDs$', function () {
alert('native method must be replaced! Ljava/io/FileOutputStream;.initIDs()V');
}
, 2);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-23 08:58:09 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
