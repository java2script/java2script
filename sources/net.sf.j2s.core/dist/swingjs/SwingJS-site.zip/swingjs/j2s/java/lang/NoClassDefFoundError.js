(function(){var P$=java.lang,I$=[];
/*c*/var C$=Clazz.newClass(P$, "NoClassDefFoundError", null, 'LinkageError');

C$.$clinit$=1;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
;C$.superclazz.c$.apply(this, []);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (detailMessage) {
;C$.superclazz.c$$S.apply(this, [detailMessage]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.5-v1');//Created 2019-12-03 12:47:49 Java2ScriptVisitor version 3.2.5-v1 net.sf.j2s.core.jar version 3.2.5-v1
