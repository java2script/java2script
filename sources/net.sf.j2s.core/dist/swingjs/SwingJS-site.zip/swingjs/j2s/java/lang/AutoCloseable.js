(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "AutoCloseable");
})();
;Clazz.setTVer('3.2.4.05');//Created 2018-12-24 14:25:08 Java2ScriptVisitor version 3.2.4.05 net.sf.j2s.core.jar version 3.2.4.05
