(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
var C$=Clazz.newInterface(P$, "DragGestureListener", null, null, 'java.util.EventListener');

C$.$clinit$=1;
})();
;Clazz.setTVer('3.2.5-v0');//Created 2019-11-13 09:29:17 Java2ScriptVisitor version 3.2.5-v0 net.sf.j2s.core.jar version 3.2.5-v0
