(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletStub");
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-25 21:39:17 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
