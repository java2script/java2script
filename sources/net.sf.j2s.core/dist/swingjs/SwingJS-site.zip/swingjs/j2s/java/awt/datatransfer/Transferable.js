(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Transferable");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-10-27 11:22:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
