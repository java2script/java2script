(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Transferable");
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-01-14 18:17:05 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
