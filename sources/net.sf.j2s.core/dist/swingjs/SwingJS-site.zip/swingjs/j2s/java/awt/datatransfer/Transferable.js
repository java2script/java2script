(function(){var P$=Clazz.newPackage("java.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "Transferable");
})();
;Clazz.setTVer('3.2.4.02');//Created 2018-11-07 11:34:21 Java2ScriptVisitor version 3.2.4.02 net.sf.j2s.core.jar version 3.2.4.02
