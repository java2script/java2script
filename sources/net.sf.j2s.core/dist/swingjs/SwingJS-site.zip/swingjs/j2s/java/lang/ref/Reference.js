(function(){var P$=Clazz.newPackage("java.lang.ref"),I$=[[0,'java.lang.ref.Reference','java.lang.ref.ReferenceQueue',['java.lang.ref.Reference','.Lock'],'Thread',['java.lang.ref.Reference','.ReferenceHandler']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Reference", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.lock=null;
C$.pending=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.lock=Clazz.new_(Clazz.load(['java.lang.ref.Reference','.Lock']));
C$.pending=null;
{
var tg=Clazz.load('Thread').currentThread$().getThreadGroup$();
for (var tgn=tg; tgn != null ; tg=tgn, tgn=tg.getParent$()) ;
var handler=Clazz.new_(Clazz.load(['java.lang.ref.Reference','.ReferenceHandler']).c$$ThreadGroup$S,[tg, "Reference Handler"]);
handler.setPriority$I(10);
handler.setDaemon$Z(true);
handler.start$();
}
;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.referent=null;
this.queue=null;
this.next=null;
this.discovered=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'get$', function () {
return this.referent;
});

Clazz.newMeth(C$, 'clear$', function () {
this.referent=null;
});

Clazz.newMeth(C$, 'isEnqueued$', function () {
return (this.queue === $I$(2).ENQUEUED );
});

Clazz.newMeth(C$, 'enqueue$', function () {
return this.queue.enqueue$ref_Reference(this);
});

Clazz.newMeth(C$, 'c$$TT', function (referent) {
C$.c$$TT$ref_ReferenceQueue.apply(this, [referent, null]);
}, 1);

Clazz.newMeth(C$, 'c$$TT$ref_ReferenceQueue', function (referent, queue) {
C$.$init$.apply(this);
this.referent=referent;
this.queue=(queue == null ) ? $I$(2).NULL : queue;
}, 1);
;
(function(){var C$=Clazz.newClass(P$.Reference, "Lock", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Reference, "ReferenceHandler", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$ThreadGroup$S', function (g, name) {
C$.superclazz.c$$ThreadGroup$S.apply(this, [g, name]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'run$', function () {
for (; ; ) {
var r;
{
if (Clazz.load('java.lang.ref.Reference').pending != null ) {
r=$I$(1).pending;
$I$(1).pending=r.discovered;
r.discovered=null;
} else {
try {
try {
$I$(1).lock.wait$();
} catch (x) {
if (Clazz.exceptionOf(x,"OutOfMemoryError")){
} else {
throw x;
}
}
} catch (x) {
if (Clazz.exceptionOf(x,"InterruptedException")){
} else {
throw x;
}
}
continue;
}}if (Clazz.instanceOf(r, "sun.misc.Cleaner")) {
(r).clean$();
continue;
}var q=r.queue;
if (q !== Clazz.load('java.lang.ref.ReferenceQueue').NULL ) q.enqueue$ref_Reference(r);
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-09-29 17:28:55 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
