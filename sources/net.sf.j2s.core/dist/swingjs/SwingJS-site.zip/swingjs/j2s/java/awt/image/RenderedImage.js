(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RenderedImage");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-02-06 18:30:17 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
