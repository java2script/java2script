(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethod");
})();
;Clazz.setTVer('3.3.1-v5');//Created 2022-07-06 17:56:44 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
