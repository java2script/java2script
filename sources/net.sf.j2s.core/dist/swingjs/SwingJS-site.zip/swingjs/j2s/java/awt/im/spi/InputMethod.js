(function(){var P$=Clazz.newPackage("java.awt.im.spi"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "InputMethod");
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-13 20:36:26 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
