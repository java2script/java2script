(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Paint", null, null, 'java.awt.Transparency');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-24 06:19:39 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
