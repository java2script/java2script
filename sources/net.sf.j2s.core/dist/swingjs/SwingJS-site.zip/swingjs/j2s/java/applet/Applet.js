(function(){var P$=Clazz.newPackage("java.applet"),I$=[];
var C$=Clazz.newClass(P$, "Applet", null, 'swingjs.a2s.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.4.06');//Created 2019-01-09 18:35:27 Java2ScriptVisitor version 3.2.4.06 net.sf.j2s.core.jar version 3.2.4.06
