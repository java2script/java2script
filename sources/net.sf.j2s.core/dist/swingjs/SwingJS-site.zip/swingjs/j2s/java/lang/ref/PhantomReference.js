(function(){var P$=Clazz.newPackage("java.lang.ref"),I$=[];
var C$=Clazz.newClass(P$, "PhantomReference", null, 'java.lang.ref.Reference');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'get$', function () {
return null;
});

Clazz.newMeth(C$, ['c$$TT$ref_ReferenceQueue'], function (referent, q) {
C$.superclazz.c$$TT$ref_ReferenceQueue.apply(this, [referent, q]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-09-29 17:28:55 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
