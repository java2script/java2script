(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newClass(P$, "ContainerAdapter", null, null, 'java.awt.event.ContainerListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'componentAdded$java_awt_event_ContainerEvent', function (e) {
});

Clazz.newMeth(C$, 'componentRemoved$java_awt_event_ContainerEvent', function (e) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-30 14:48:45 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
