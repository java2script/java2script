(function(){var P$=Clazz.newPackage("java.awt.dnd"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DropTargetListener", null, null, 'java.util.EventListener');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-12-19 07:45:47 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
