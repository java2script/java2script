(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Iterable");
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'forEach$java_util_function_Consumer', function (action) {
Clazz.load('java.util.Objects').requireNonNull$TT(action);
for (var t, $t = this.iterator$(); $t.hasNext$()&&((t=($t.next$())),1);) {
action.accept$(t);
}
});

Clazz.newMeth(C$, 'spliterator$', function () {
return Clazz.load('java.util.Spliterators').spliteratorUnknownSize$java_util_Iterator$I(this.iterator$(), 0);
});
};})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-10 13:31:41 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
