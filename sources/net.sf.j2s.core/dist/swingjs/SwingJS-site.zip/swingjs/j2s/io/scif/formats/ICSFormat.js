(function(){var P$=Clazz.newPackage("io.scif.formats"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ICSFormat", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Reader',9]];

Clazz.newMeth(C$, '$init$', function () {
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ICSFormat, "Reader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.6-v1');//Created 2020-01-03 22:12:35 Java2ScriptVisitor version 3.2.6-v1 net.sf.j2s.core.jar version 3.2.6-v1
