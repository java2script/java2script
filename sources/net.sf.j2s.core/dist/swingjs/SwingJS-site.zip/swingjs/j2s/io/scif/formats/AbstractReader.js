(function(){var P$=Clazz.newPackage("io.scif.formats"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AbstractReader", null, null, 'io.scif.formats.TypedReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['openPlane$TP$io_scif_formats_SCIFIOConfig'], function (plane, config) {
return this.openPlane$I$TP$I(0, plane, 0);
});

Clazz.newMeth(C$, ['openPlane2$TP$io_scif_formats_SCIFIOConfig'], function (plane, config) {
return this.openPlane$TP(plane);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.6-v1');//Created 2020-01-03 19:47:57 Java2ScriptVisitor version 3.2.6-v1 net.sf.j2s.core.jar version 3.2.6-v1
