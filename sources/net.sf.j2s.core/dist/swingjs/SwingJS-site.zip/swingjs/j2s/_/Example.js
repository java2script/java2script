(function(){var P$=Clazz.newPackage("_"),I$=[[0,'java.awt.Color','java.awt.BorderLayout',['test.kt.karlosp.NeueKarte','.Example','.mitte']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Example", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.applet.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.Feld=null;
this.Bildpxl=null;
this.BildName=null;
this.dasAGif=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.BildName="kartemfp.gif";
this.setBackground$java_awt_Color($I$(1).white);
this.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.BorderLayout')));
this.add$S$java_awt_Component("Center", this.Feld=Clazz.new_(Clazz.load(['test.kt.karlosp.NeueKarte','.Example','.mitte']).c$$test_kt_karlosp_NeueKarte_Example, [this, null, this]));
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.Feld.init$();
this.Feld.repaint$();
});
;
(function(){var C$=Clazz.newClass(P$.Example, "mitte", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.theapplet=null;
this.imggc=null;
this.$width=0;
this.$height=0;
this.dasGif=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$test_kt_karlosp_NeueKarte_Example', function (a) {
Clazz.super_(C$, this,1);
this.theapplet=a;
}, 1);

Clazz.newMeth(C$, 'init$', function () {
var d=this.size$();
this.$width=d.width;
this.$height=d.height;
this.dasGif=this.b$['java.applet.JSApplet'].getImage$java_net_URL$S.apply(this.b$['java.applet.JSApplet'], [this.b$['a2s.Applet'].getCodeBase$.apply(this.b$['a2s.Applet'], []), this.b$['test.kt.karlosp.NeueKarte.Example'].BildName]);
var g=this.getGraphics$();
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.dasGif, 0, 0, 100, 200, this.theapplet);
this.validate$();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (gc) {
gc.setColor$java_awt_Color(Clazz.load('java.awt.Color').red);
gc.drawRect$I$I$I$I(0, 2, 40, 29);
gc.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.dasGif, 0, 0, 100, 200, this.theapplet);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (gc) {
gc.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.dasGif, 0, 0, 200, 200, this.theapplet);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-06 07:26:01 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
