(function(){var P$=Clazz.newPackage("_"),I$=[[0,'_.Test0_Applet','Thread',['Thread','.State'],'java.io.BufferedReader']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Test0", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.j2sHeadless=false;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.j2sHeadless=true;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
var f="1";
System.out.println$S("hello from Test0");
String.valueOf$O("test");
Clazz.new_(Clazz.load('_.Test0_Applet')).init$();
System.out.println$S($I$(1).staticVar);
var o=Clazz.load('Thread').currentThread$();
var oo=Clazz.getClass($I$(2));
var ooo=Clazz.getClass(Clazz.load(['Thread','.State']));
var rdr=null;
try {var br=Clazz.new_(Clazz.load('java.io.BufferedReader').c$$java_io_Reader,[rdr])
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException") || Clazz.exceptionOf(e,"NullPointerException")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);
;
(function(){var C$=Clazz.newClass(P$, "Test0$1exc2", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, ['Test0','.Exc','.Exc1'], null, 2);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$finals=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$finals="finalsEx2";
}, 1);

Clazz.newMeth(C$, 'test$', function () {
System.out.println$S(this.$finals$.f);
});
;
(function(){var C$=Clazz.newClass(P$.Test0$1exc2, "Exc3", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
System.out.println$S(this.b$['_.Test0$1exc2'].$finals);
}, 1);
})()

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Test0, "Test0a", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, '_.Test0');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
System.out.println$S("Test0.Test0a");
}, 1);
})()
;
(function(){var C$=Clazz.newClass(P$.Test0, "Exc", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'NullPointerException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'test$S$Z', function (s, b) {
});
;
(function(){var C$=Clazz.newClass(P$, "Test0$Exc$1Exc2", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'NullPointerException', null, 2);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
System.out.println$S("Test0.Exc2");
}, 1);
;
(function(){var C$=Clazz.newClass(P$.Test0$Exc$1Exc2, "Exc3", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, '_.Test0$Exc$1Exc2');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
System.out.println$S("Test0.Exc2.Exc3");
}, 1);
})()
})()
;
(function(){var C$=Clazz.newClass(P$.Test0.Exc, "Exc1", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.finals=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.finals="finals1";
}, 1);

Clazz.newMeth(C$, 'test$Z', function (b) {
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.04');//Created 2018-11-20 06:45:15 Java2ScriptVisitor version 3.2.4.04 net.sf.j2s.core.jar version 3.2.4.04
