(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Canvas", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.notified=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_GraphicsConfiguration', function (config) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setBackground$java_awt_Color', function (c) {
C$.superclazz.prototype.setBackground$java_awt_Color.apply(this, [c]);
this.setOpaque$Z(c != null );
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.update$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
if (!this.notified) System.out.println$S("neither paint(g) nor update(g) is implemented for " + this);
this.notified=true;
if (this.paintComponent$java_awt_Graphics ||false) this.paintComponent$java_awt_Graphics(g);
});
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-23 12:28:17 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
