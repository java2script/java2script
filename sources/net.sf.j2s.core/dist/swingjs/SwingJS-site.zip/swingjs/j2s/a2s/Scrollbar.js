(function(){var P$=Clazz.newPackage("a2s"),I$=[[0,'a2s.A2SEvent','a2s.A2SListener']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Scrollbar", null, 'javax.swing.JScrollBar', 'a2s.A2SContainer');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.listener=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.listener=null;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (direction) {
C$.superclazz.c$$I.apply(this, [direction]);
C$.$init$.apply(this);
Clazz.load('a2s.A2SEvent').addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
$I$(1).addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I', function (orientation, value, extent, min, max) {
C$.superclazz.c$$I$I$I$I$I.apply(this, [orientation, value, extent, min, max]);
C$.$init$.apply(this);
$I$(1).addListener$javax_swing_JComponent$java_awt_Component(null, this);
}, 1);

Clazz.newMeth(C$, 'processAdjustmentEvent$java_awt_event_AdjustmentEvent', function (e) {
});

Clazz.newMeth(C$, 'setValue$I', function (n) {
C$.superclazz.prototype.setValue$I.apply(this, [n]);
});

Clazz.newMeth(C$, 'getMinimum$', function () {
return C$.superclazz.prototype.getMinimum$.apply(this, []);
});

Clazz.newMeth(C$, 'getMaximum$', function () {
return C$.superclazz.prototype.getMaximum$.apply(this, []);
});

Clazz.newMeth(C$, 'getValue$', function () {
return C$.superclazz.prototype.getValue$.apply(this, []);
});

Clazz.newMeth(C$, 'getA2SListener$', function () {
if (this.listener == null ) this.listener=Clazz.new_(Clazz.load('a2s.A2SListener'));
return this.listener;
});
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-17 23:18:59 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
