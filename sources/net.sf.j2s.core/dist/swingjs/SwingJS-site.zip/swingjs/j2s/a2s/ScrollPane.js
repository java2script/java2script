(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "ScrollPane", null, 'javax.swing.JScrollPane');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (scrollbars) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
switch (scrollbars) {
case 2:
this.setVerticalScrollBarPolicy$I(21);
this.setHorizontalScrollBarPolicy$I(31);
break;
case 1:
this.setVerticalScrollBarPolicy$I(22);
this.setHorizontalScrollBarPolicy$I(32);
break;
case 0:
break;
}
}, 1);

Clazz.newMeth(C$, 'add$java_awt_Component', function (c) {
this.getViewport$().add$java_awt_Component(c);
return c;
});
})();
;Clazz.setTVer('3.2.2.07');//Created 2018-09-25 21:26:40 Java2ScriptVisitor version 3.2.2.07 net.sf.j2s.core.jar version 3.2.2.07
