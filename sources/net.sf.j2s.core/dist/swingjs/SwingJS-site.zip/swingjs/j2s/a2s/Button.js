(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Button", null, 'javax.swing.JButton');
C$.awtInsets=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.awtInsets=Clazz.new_(Clazz.load('java.awt.Insets').c$$I$I$I$I,[0, 6, 0, 6]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.superclazz.c$$S.apply(this, [text]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getMargin$', function () {
return C$.awtInsets;
});

Clazz.newMeth(C$, 'fireActionPerformed$java_awt_event_ActionEvent', function (event) {
Clazz.load('a2s.A2SEvent').addListener$javax_swing_JComponent$java_awt_Component(null, this);
C$.superclazz.prototype.fireActionPerformed$java_awt_event_ActionEvent.apply(this, [event]);
});
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-08-27 17:09:26 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
