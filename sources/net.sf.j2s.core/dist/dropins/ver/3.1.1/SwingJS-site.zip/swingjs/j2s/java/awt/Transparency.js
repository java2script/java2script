(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Transparency");
})();
//Created 2018-07-06 06:35:17
