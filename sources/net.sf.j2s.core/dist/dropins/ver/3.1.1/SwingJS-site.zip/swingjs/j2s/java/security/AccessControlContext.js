(function(){var P$=Clazz.newPackage("java.security"),I$=[];
var C$=Clazz.newInterface(P$, "AccessControlContext");
})();
//Created 2018-07-06 06:35:26
