(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
//Created 2018-07-06 06:35:20
