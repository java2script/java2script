(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Closeable", null, null, 'AutoCloseable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.2.02');//Created 2018-08-04 12:14:47 Jav2ScriptVisitor version 3.2.2.02 net.sf.j2s.core.jar version 3.2.2.02
