(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
var C$=Clazz.newInterface(P$, "Composite");
})();
;Clazz.setTVer('3.2.2.02');//Created 2018-08-05 23:03:22 Jav2ScriptVisitor version 3.2.2.02 net.sf.j2s.core.jar version 3.2.2.02
