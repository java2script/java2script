(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "RasterOp");
})();
;Clazz.setTVer('3.2.2.02');//Created 2018-08-04 12:14:46 Jav2ScriptVisitor version 3.2.2.02 net.sf.j2s.core.jar version 3.2.2.02
