(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "FocusListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.2.03');//Created 2018-08-06 17:25:21 Jav2ScriptVisitor version 3.2.2.03 net.sf.j2s.core.jar version 3.2.2.03
