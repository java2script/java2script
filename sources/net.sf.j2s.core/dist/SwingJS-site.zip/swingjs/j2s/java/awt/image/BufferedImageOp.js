(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "BufferedImageOp");
})();
;Clazz.setTVer('3.2.2.03');//Created 2018-08-06 23:10:53 Java2ScriptVisitor version 3.2.2.03 net.sf.j2s.core.jar version 3.2.2.03
