(function(){var P$=Clazz.newPackage("java.awt.event"),I$=[];
var C$=Clazz.newInterface(P$, "ComponentListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
;Clazz.setTVer('3.2.2.02');//Created 2018-08-05 23:03:30 Jav2ScriptVisitor version 3.2.2.02 net.sf.j2s.core.jar version 3.2.2.02
