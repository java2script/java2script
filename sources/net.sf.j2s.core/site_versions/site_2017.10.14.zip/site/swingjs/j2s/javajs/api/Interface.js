(function(){var P$=Clazz.newPackage$("javajs.api");
var C$=Clazz.newClass$(P$, "Interface");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getInterface$S', function (name) {
try {
var x = Clazz._4Name(name);
return (x == null  ? null|0 : x.newInstance());
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S("Interface.getInterface Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'getInstanceWithParams$S$ClassA$OA', function (name, classes, params) {
try {
var cl = Clazz._4Name(name);
return cl.getConstructor$ClassA(classes).newInstance$OA(params);
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S("Interface.getInterfaceWithParams Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:24
