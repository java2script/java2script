(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "Matrix", function(){
Clazz.newInstance$(this, arguments);
}, null, 'Cloneable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.a = null;
this.m = 0;
this.n = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$DAA$I$I', function (a, m, n) {
C$.$init$.apply(this);
this.a = (a == null  ?  Clazz.newArray$(Double.TYPE, [m, n]) : a);
this.m = m;
this.n = n;
}, 1);

Clazz.newMethod$(C$, 'getRowDimension', function () {
return this.m;
});

Clazz.newMethod$(C$, 'getColumnDimension', function () {
return this.n;
});

Clazz.newMethod$(C$, 'getArray', function () {
return this.a;
});

Clazz.newMethod$(C$, 'getArrayCopy', function () {
var x =  Clazz.newArray$(Double.TYPE, [this.m, this.n]);
for (var i = this.m; --i >= 0; ) for (var j = this.n; --j >= 0; ) x[i][j] = this.a[i][j];


return x;
});

Clazz.newMethod$(C$, 'copy', function () {
var x = Clazz.new(C$.c$$DAA$I$I,[null, this.m, this.n]);
var c = x.a;
for (var i = this.m; --i >= 0; ) for (var j = this.n; --j >= 0; ) c[i][j] = this.a[i][j];


return x;
});

Clazz.newMethod$(C$, 'clone', function () {
return this.copy();
});

Clazz.newMethod$(C$, 'getSubmatrix$I$I$I$I', function (i0, j0, nrows, ncols) {
var x = Clazz.new(C$.c$$DAA$I$I,[null, nrows, ncols]);
var xa = x.a;
for (var i = nrows; --i >= 0; ) for (var j = ncols; --j >= 0; ) xa[i][j] = this.a[i0 + i][j0 + j];


return x;
});

Clazz.newMethod$(C$, 'getMatrixSelected$IA$I', function (r, n) {
var x = Clazz.new(C$.c$$DAA$I$I,[null, r.length, n]);
var xa = x.a;
for (var i = r.length; --i >= 0; ) {
var b = this.a[r[i]];
for (var j = n; --j >= 0; ) xa[i][j] = b[j];

}
return x;
});

Clazz.newMethod$(C$, 'transpose', function () {
var x = Clazz.new(C$.c$$DAA$I$I,[null, this.n, this.m]);
var c = x.a;
for (var i = this.m; --i >= 0; ) for (var j = this.n; --j >= 0; ) c[j][i] = this.a[i][j];


return x;
});

Clazz.newMethod$(C$, 'add$javajs_util_Matrix', function (b) {
return this.scaleAdd$javajs_util_Matrix$D(b, 1);
});

Clazz.newMethod$(C$, 'sub$javajs_util_Matrix', function (b) {
return this.scaleAdd$javajs_util_Matrix$D(b, -1);
});

Clazz.newMethod$(C$, 'scaleAdd$javajs_util_Matrix$D', function (b, scale) {
var x = Clazz.new(C$.c$$DAA$I$I,[null, this.m, this.n]);
var xa = x.a;
var ba = b.a;
for (var i = this.m; --i >= 0; ) for (var j = this.n; --j >= 0; ) xa[i][j] = ba[i][j] * scale + this.a[i][j];


return x;
});

Clazz.newMethod$(C$, 'mul$javajs_util_Matrix', function (b) {
if (b.m != this.n) return null;
var x = Clazz.new(C$.c$$DAA$I$I,[null, this.m, b.n]);
var xa = x.a;
var ba = b.a;
for (var j = b.n; --j >= 0; ) for (var i = this.m; --i >= 0; ) {
var arowi = this.a[i];
var s = 0;
for (var k = this.n; --k >= 0; ) s += arowi[k] * ba[k][j];

xa[i][j] = s;
}

return x;
});

Clazz.newMethod$(C$, 'inverse', function () {
return Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javajs.util.Matrix').LUDecomp))).c$$I$I, [this, null, this.m, this.n]).solve$javajs_util_Matrix$I(C$.identity$I$I(this.m, this.m), this.n);
});

Clazz.newMethod$(C$, 'trace', function () {
var t = 0;
for (var i = Math.min(this.m, this.n); --i >= 0; ) t += this.a[i][i];

return t;
});

Clazz.newMethod$(C$, 'identity$I$I', function (m, n) {
var x = Clazz.new(C$.c$$DAA$I$I,[null, m, n]);
var xa = x.a;
for (var i = Math.min(m, n); --i >= 0; ) xa[i][i] = 1;

return x;
}, 1);

Clazz.newMethod$(C$, 'getRotation', function () {
return this.getSubmatrix$I$I$I$I(0, 0, this.m - 1, this.n - 1);
});

Clazz.newMethod$(C$, 'getTranslation', function () {
return this.getSubmatrix$I$I$I$I(0, this.n - 1, this.m - 1, 1);
});

Clazz.newMethod$(C$, 'newT$javajs_util_T3$Z', function (r, asColumn) {
return (asColumn ? Clazz.new(C$.c$$DAA$I$I,[ Clazz.newArray$(Double.TYPE, -2, [ Clazz.newArray$(Double.TYPE, -1, [r.x]),  Clazz.newArray$(Double.TYPE, -1, [r.y]),  Clazz.newArray$(Double.TYPE, -1, [r.z])]), 3, 1]) : Clazz.new(C$.c$$DAA$I$I,[ Clazz.newArray$(Double.TYPE, -2, [ Clazz.newArray$(Double.TYPE, -1, [r.x, r.y, r.z])]), 1, 3]));
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
var s = "[\u000a";
for (var i = 0; i < this.m; i++) {
s += "  [";
for (var j = 0; j < this.n; j++) s += " " + new Double(this.a[i][j]).toString();

s += "]\n";
}
s += "]";
return s;
});
;
(function(){var C$=Clazz.newClass$(P$.Matrix, "LUDecomp", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.LU = null;
this.piv = null;
this.pivsign = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (m, n) {
C$.$init$.apply(this);
this.LU = this.b$['javajs.util.Matrix'].getArrayCopy();
this.piv =  Clazz.newArray$(Integer.TYPE, [m]);
for (var i = m; --i >= 0; ) this.piv[i] = i;

this.pivsign = 1;
var LUrowi;
var LUcolj =  Clazz.newArray$(Double.TYPE, [m]);
for (var j = 0; j < n; j++) {
for (var i = m; --i >= 0; ) LUcolj[i] = this.LU[i][j];

for (var i = m; --i >= 0; ) {
LUrowi = this.LU[i];
var kmax = Math.min(i, j);
var s = 0.0;
for (var k = kmax; --k >= 0; ) s += LUrowi[k] * LUcolj[k];

LUrowi[j] = LUcolj[i] -= s;
}
var p = j;
for (var i = m; --i > j; ) if (Math.abs(LUcolj[i]) > Math.abs(LUcolj[p]) ) p = i;

if (p != j) {
for (var k = n; --k >= 0; ) {
var t = this.LU[p][k];
this.LU[p][k] = this.LU[j][k];
this.LU[j][k] = t;
}
var k = this.piv[p];
this.piv[p] = this.piv[j];
this.piv[j] = k;
this.pivsign = -this.pivsign;
}if (!!(j < m & this.LU[j][j] != 0.0 )) for (var i = m; --i > j; ) this.LU[i][j] /= this.LU[j][j];

}
}, 1);

Clazz.newMethod$(C$, 'solve$javajs_util_Matrix$I', function (b, n) {
for (var j = 0; j < n; j++) if (this.LU[j][j] == 0 ) return null;

var nx = b.n;
var x = b.getMatrixSelected$IA$I(this.piv, nx);
var a = x.a;
for (var k = 0; k < n; k++) for (var i = k + 1; i < n; i++) for (var j = 0; j < nx; j++) a[i][j] -= a[k][j] * this.LU[i][k];



for (var k = n; --k >= 0; ) {
for (var j = nx; --j >= 0; ) a[k][j] /= this.LU[k][k];

for (var i = k; --i >= 0; ) for (var j = nx; --j >= 0; ) a[i][j] -= a[k][j] * this.LU[i][k];


}
return x;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:27
