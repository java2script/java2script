(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "T3d");


Clazz.newMethod$(C$, '$init$', function () {
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'set$D$D$D', function (x, y, z) {
this.x = x;
this.y = y;
this.z = z;
});

Clazz.newMethod$(C$, 'setA$DA', function (t) {
this.x = t[0];
this.y = t[1];
this.z = t[2];
});

Clazz.newMethod$(C$, 'setT$javajs_util_T3d', function (t1) {
this.x = t1.x;
this.y = t1.y;
this.z = t1.z;
});

Clazz.newMethod$(C$, 'add2$javajs_util_T3d$javajs_util_T3d', function (t1, t2) {
this.x = t1.x + t2.x;
this.y = t1.y + t2.y;
this.z = t1.z + t2.z;
});

Clazz.newMethod$(C$, 'add$javajs_util_T3d', function (t1) {
this.x += t1.x;
this.y += t1.y;
this.z += t1.z;
});

Clazz.newMethod$(C$, 'sub2$javajs_util_T3d$javajs_util_T3d', function (t1, t2) {
this.x = t1.x - t2.x;
this.y = t1.y - t2.y;
this.z = t1.z - t2.z;
});

Clazz.newMethod$(C$, 'sub$javajs_util_T3d', function (t1) {
this.x -= t1.x;
this.y -= t1.y;
this.z -= t1.z;
});

Clazz.newMethod$(C$, 'scale$D', function (s) {
this.x *= s;
this.y *= s;
this.z *= s;
});

Clazz.newMethod$(C$, 'scaleAdd$D$javajs_util_T3d$javajs_util_T3d', function (s, t1, t2) {
this.x = s * t1.x + t2.x;
this.y = s * t1.y + t2.y;
this.z = s * t1.z + t2.z;
});

Clazz.newMethod$(C$, 'hashCode', function () {
var xbits = C$.doubleToLongBits0$D(this.x);
var ybits = C$.doubleToLongBits0$D(this.y);
var zbits = C$.doubleToLongBits0$D(this.z);
return ($i$[0] = (xbits ^ (xbits >> 32) ^ ybits ^ (ybits >> 32) ^ zbits ^ (zbits >> 32) ), $i$[0]);
});

Clazz.newMethod$(C$, 'doubleToLongBits0$D', function (d) {
return (d == 0  ? 0 : Double.doubleToLongBits(d));
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (t1) {
if (!(Clazz.instanceOf(t1, "javajs.util.T3d"))) return false;
var t2 = t1;
return (this.x == t2.x  && this.y == t2.y   && this.z == t2.z  );
});

Clazz.newMethod$(C$, 'toString', function () {
return "{" + new Double(this.x).toString() + ", " + new Double(this.y).toString() + ", " + new Double(this.z).toString() + "}" ;
});
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:28
