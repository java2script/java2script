(function(){var P$=Clazz.newPackage$("javajs.api.js");
var C$=Clazz.newInterface$(P$, "JSInterface");

})();
//Created 2017-10-14 13:31:24
