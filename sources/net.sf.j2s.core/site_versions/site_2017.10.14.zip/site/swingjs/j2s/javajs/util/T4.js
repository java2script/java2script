(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "T4", null, 'javajs.util.T3');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.w = 0;
}, 1);

Clazz.newMethod$(C$, 'set4$F$F$F$F', function (x, y, z, w) {
this.x = x;
this.y = y;
this.z = z;
this.w = w;
});

Clazz.newMethod$(C$, 'scale4$F', function (s) {
this.scale$F(s);
this.w *= s;
});

Clazz.newMethod$(C$, 'hashCode', function () {
return (I$[0] || (I$[0]=Clazz.load('javajs.util.T3'))).floatToIntBits$F(this.x) ^ (I$[0] || (I$[0]=Clazz.load('javajs.util.T3'))).floatToIntBits$F(this.y) ^ (I$[0] || (I$[0]=Clazz.load('javajs.util.T3'))).floatToIntBits$F(this.z) ^ (I$[0] || (I$[0]=Clazz.load('javajs.util.T3'))).floatToIntBits$F(this.w) ;
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (!(Clazz.instanceOf(o, "javajs.util.T4"))) return false;
var t = o;
return (this.x == t.x  && this.y == t.y   && this.z == t.z   && this.w == t.w  );
});

Clazz.newMethod$(C$, 'toString', function () {
return "(" + new Float(this.x).toString() + ", " + new Float(this.y).toString() + ", " + new Float(this.z).toString() + ", " + new Float(this.w).toString() + ")" ;
});

Clazz.newMethod$(C$, 'toJSON', function () {
return "[" + new Float(this.x).toString() + ", " + new Float(this.y).toString() + ", " + new Float(this.z).toString() + ", " + new Float(this.w).toString() + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
