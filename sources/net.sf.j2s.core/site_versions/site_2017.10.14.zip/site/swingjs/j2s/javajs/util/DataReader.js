(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "DataReader", null, 'java.io.BufferedReader');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.ptMark = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$java_io_Reader.apply(this, [Clazz.new((I$[0] || (I$[0]=Clazz.load('java.io.StringReader'))).c$$S,[""])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_Reader', function ($in) {
C$.superClazz.c$$java_io_Reader.apply(this, [$in]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getBufferedReader', function () {
return this;
});

Clazz.newMethod$(C$, 'readBuf$CA$I$I', function (buf, off, len) {
var nRead = 0;
var line = this.readLine();
if (line == null ) return 0;
var linept = 0;
var linelen = line.length$();
for (var i = off; i < len && linelen >= 0 ; i++) {
if (linept >= linelen) {
linept = 0;
buf[i] = '\u000a';
line = this.readLine();
linelen = (line == null  ? -1 : line.length$());
} else {
buf[i] = line.charAt(linept++);
}nRead++;
}
return nRead;
});
})();
//Created 2017-10-14 13:31:26
