(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "Jpg64Encoder", null, 'javajs.img.JpgEncoder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.outTemp = null;
}, 1);

Clazz.newMethod$(C$, 'setParams$java_util_Map', function (params) {
this.defaultQuality = 75;
this.outTemp = params.remove$O("outputChannelTemp");
C$.superClazz.prototype.setParams$java_util_Map.apply(this, [params]);
});

Clazz.newMethod$(C$, 'generate', function () {
var out0 = this.out;
this.out = this.outTemp;
C$.superClazz.prototype.generate.apply(this, []);
var bytes = (I$[0] || (I$[0]=Clazz.load('javajs.util.Base64'))).getBytes64$BA(this.out.toByteArray());
this.outTemp = null;
this.out = out0;
this.out.write$BA$I$I(bytes, 0, bytes.length);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:25
