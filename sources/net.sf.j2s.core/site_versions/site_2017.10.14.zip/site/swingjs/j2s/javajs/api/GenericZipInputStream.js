(function(){var P$=Clazz.newPackage$("javajs.api");
var C$=Clazz.newClass$(P$, "GenericZipInputStream", null, 'java.util.zip.ZipInputStream', 'javajs.api.ZInputStream');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_InputStream', function ($in) {
C$.superClazz.c$$java_io_InputStream.apply(this, [$in]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:24
