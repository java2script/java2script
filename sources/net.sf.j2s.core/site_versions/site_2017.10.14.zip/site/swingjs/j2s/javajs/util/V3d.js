(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "V3d", null, 'javajs.util.T3d');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'cross$javajs_util_V3d$javajs_util_V3d', function (v1, v2) {
this.set$D$D$D(v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x);
});

Clazz.newMethod$(C$, 'normalize', function () {
var d = this.length$();
this.x /= d;
this.y /= d;
this.z /= d;
});

Clazz.newMethod$(C$, 'dot$javajs_util_V3d', function (v) {
return this.x * v.x + this.y * v.y + this.z * v.z;
});

Clazz.newMethod$(C$, 'lengthSquared', function () {
return this.x * this.x + this.y * this.y + this.z * this.z;
});

Clazz.newMethod$(C$, 'length$', function () {
return Math.sqrt(this.lengthSquared());
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
