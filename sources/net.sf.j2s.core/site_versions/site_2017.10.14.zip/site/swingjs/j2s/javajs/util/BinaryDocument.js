(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "BinaryDocument", null, 'javajs.util.BC', 'javajs.api.GenericBinaryDocument');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.stream = null;
this.isRandom = false;
this.isBigEndian = true;
this.bis = null;
this.nBytes = 0;
this.out = null;
this.t8 =  Clazz.newArray$(Byte.TYPE, [8]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'close', function () {
if (this.stream != null ) try {
this.stream.close();
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
} else {
throw e;
}
}
if (this.out != null ) this.out.closeChannel();
});

Clazz.newMethod$(C$, 'setStream$java_io_BufferedInputStream$Z', function (bis, isBigEndian) {
this.bis = bis;
if (bis != null ) {
this.stream = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.io.DataInputStream'))).c$$java_io_InputStream,[bis]);
}this.isBigEndian = isBigEndian;
return this;
});

Clazz.newMethod$(C$, 'getInputStream', function () {
return this.bis;
});

Clazz.newMethod$(C$, 'setStreamData$java_io_DataInputStream$Z', function (stream, isBigEndian) {
if (stream != null ) this.stream = stream;
this.isBigEndian = isBigEndian;
});

Clazz.newMethod$(C$, 'setOutputChannel$javajs_api_GenericOutputChannel', function (out) {
this.out = out;
});

Clazz.newMethod$(C$, 'setRandom$Z', function (TF) {
this.isRandom = TF;
});

Clazz.newMethod$(C$, 'readByte', function () {
this.nBytes++;
return $b$[0] = p$.ioReadByte.apply(this, []), $b$[0];
});

Clazz.newMethod$(C$, 'readUInt8', function () {
this.nBytes++;
var b = this.stream.readUnsignedByte();
if (this.out != null ) this.out.writeByteAsInt$I(b);
return b;
});

Clazz.newMethod$(C$, 'ioReadByte', function () {
var b = ($b$[0] = this.stream.readByte(), $b$[0]);
if (this.out != null ) this.out.writeByteAsInt$I(b);
return $b$[0] = b, $b$[0];
});

Clazz.newMethod$(C$, 'readBytes$I', function (n) {
var b =  Clazz.newArray$(Byte.TYPE, [n]);
this.readByteArray$BA$I$I(b, 0, n);
return b;
});

Clazz.newMethod$(C$, 'readByteArray$BA$I$I', function (b, off, len) {
var n = p$.ioRead$BA$I$I.apply(this, [b, off, len]);
this.nBytes = this.nBytes+(n);
return n;
});

Clazz.newMethod$(C$, 'ioRead$BA$I$I', function (b, off, len) {
var m = 0;
while (len > 0){
var n = this.stream.read$BA$I$I(b, off, len);
m = m+(n);
if (n > 0 && this.out != null  ) this.out.write$BA$I$I(b, off, n);
if (n >= len) break;
off = off+(n);
len = len-(n);
}
return m;
});

Clazz.newMethod$(C$, 'readString$I', function (nChar) {
var temp =  Clazz.newArray$(Byte.TYPE, [nChar]);
var n = this.readByteArray$BA$I$I(temp, 0, nChar);
return  String.instantialize(temp, 0, n, "UTF-8");
});

Clazz.newMethod$(C$, 'readShort', function () {
this.nBytes = this.nBytes+(2);
var n = ($s$[0] = (this.isBigEndian ? p$.ioReadShort.apply(this, []) : ((p$.ioReadByte.apply(this, []) & 255) | (p$.ioReadByte.apply(this, []) & 255) << 8)), $s$[0]);
{
return (n > 0x7FFF ? n - 0x10000 : n);
}});

Clazz.newMethod$(C$, 'ioReadShort', function () {
var b = ($s$[0] = this.stream.readShort(), $s$[0]);
if (this.out != null ) this.out.writeShort$H(($s$[0] = b, $s$[0]));
return $s$[0] = b, $s$[0];
});

Clazz.newMethod$(C$, 'readIntLE', function () {
this.nBytes = this.nBytes+(4);
return p$.readLEInt.apply(this, []);
});

Clazz.newMethod$(C$, 'readInt', function () {
this.nBytes = this.nBytes+(4);
return (this.isBigEndian ? p$.ioReadInt.apply(this, []) : p$.readLEInt.apply(this, []));
});

Clazz.newMethod$(C$, 'ioReadInt', function () {
var i = this.stream.readInt();
if (this.out != null ) this.out.writeInt$I(i);
return i;
});

Clazz.newMethod$(C$, 'swapBytesI$I', function (n) {
return (((n >> 24) & 255) | ((n >> 16) & 255) << 8 | ((n >> 8) & 255) << 16 | (n & 255) << 24);
});

Clazz.newMethod$(C$, 'swapBytesS$H', function (n) {
return $s$[0] = ((((n >> 8) & 255) | (n & 255) << 8)), $s$[0];
});

Clazz.newMethod$(C$, 'readUnsignedShort', function () {
this.nBytes = this.nBytes+(2);
var a = (p$.ioReadByte.apply(this, []) & 255);
var b = (p$.ioReadByte.apply(this, []) & 255);
return (this.isBigEndian ? (a << 8) + b : (b << 8) + a);
});

Clazz.newMethod$(C$, 'readLong', function () {
this.nBytes = this.nBytes+(8);
return (this.isBigEndian ? p$.ioReadLong.apply(this, []) : (((p$.ioReadByte.apply(this, [])) & 255) | ((p$.ioReadByte.apply(this, [])) & 255) << 8 | ((p$.ioReadByte.apply(this, [])) & 255) << 16 | ((p$.ioReadByte.apply(this, [])) & 255) << 24 | ((p$.ioReadByte.apply(this, [])) & 255) << 32 | ((p$.ioReadByte.apply(this, [])) & 255) << 40 | ((p$.ioReadByte.apply(this, [])) & 255) << 48 | ((p$.ioReadByte.apply(this, [])) & 255) << 54));
});

Clazz.newMethod$(C$, 'ioReadLong', function () {
var b = this.stream.readLong();
if (this.out != null ) this.out.writeLong$J(b);
return b;
});

Clazz.newMethod$(C$, 'readLEInt', function () {
p$.ioRead$BA$I$I.apply(this, [this.t8, 0, 4]);
return P$.BC.bytesToInt$BA$I$Z(this.t8, 0, false);
});

Clazz.newMethod$(C$, 'readFloat', function () {
return P$.BC.intToFloat$I(this.readInt());
});

Clazz.newMethod$(C$, 'readDouble', function () {
{
this.readByteArray(this.t8, 0, 8);
return this.bytesToDoubleToFloat(this.t8, 0, this.isBigEndian);
}});

Clazz.newMethod$(C$, 'ioReadDouble', function () {
var d = this.stream.readDouble();
if (this.out != null ) this.out.writeLong$J(Double.doubleToRawLongBits(d));
return d;
});

Clazz.newMethod$(C$, 'readLELong', function () {
return (((p$.ioReadByte.apply(this, [])) & 255) | ((p$.ioReadByte.apply(this, [])) & 255) << 8 | ((p$.ioReadByte.apply(this, [])) & 255) << 16 | ((p$.ioReadByte.apply(this, [])) & 255) << 24 | ((p$.ioReadByte.apply(this, [])) & 255) << 32 | ((p$.ioReadByte.apply(this, [])) & 255) << 40 | ((p$.ioReadByte.apply(this, [])) & 255) << 48 | ((p$.ioReadByte.apply(this, [])) & 255) << 56);
});

Clazz.newMethod$(C$, 'seek$J', function (offset) {
try {
if (offset == this.nBytes) return;
if (offset < this.nBytes) {
this.stream.reset();
if (this.out != null  && this.nBytes != 0 ) this.out.reset();
this.nBytes = 0;
} else {
offset = offset-(this.nBytes);
}if (this.out == null ) {
this.stream.skipBytes$I(($i$[0] = offset, $i$[0]));
} else {
this.readByteArray$BA$I$I( Clazz.newArray$(Byte.TYPE, [($i$[0] = offset, $i$[0])]), 0, ($i$[0] = offset, $i$[0]));
}this.nBytes = this.nBytes+(offset);
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getPosition', function () {
return this.nBytes;
});

Clazz.newMethod$(C$, 'getAllDataFiles$S$S', function (binaryFileList, firstFile) {
return null;
});

Clazz.newMethod$(C$, 'getAllDataMapped$S$S$java_util_Map', function (replace, string, fileData) {
});
var $b$ = new Int8Array(1);
var $s$ = new Int16Array(1);
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:26
