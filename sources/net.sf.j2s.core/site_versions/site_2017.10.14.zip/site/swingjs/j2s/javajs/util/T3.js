(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "T3", null, null, 'javajs.api.JSONEncodable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMethod$(C$, 'set$F$F$F', function (x, y, z) {
this.x = x;
this.y = y;
this.z = z;
});

Clazz.newMethod$(C$, 'setA$FA', function (t) {
this.x = t[0];
this.y = t[1];
this.z = t[2];
});

Clazz.newMethod$(C$, 'setT$javajs_util_T3', function (t1) {
this.x = t1.x;
this.y = t1.y;
this.z = t1.z;
});

Clazz.newMethod$(C$, 'add2$javajs_util_T3$javajs_util_T3', function (t1, t2) {
this.x = t1.x + t2.x;
this.y = t1.y + t2.y;
this.z = t1.z + t2.z;
});

Clazz.newMethod$(C$, 'add$javajs_util_T3', function (t1) {
this.x += t1.x;
this.y += t1.y;
this.z += t1.z;
});

Clazz.newMethod$(C$, 'distanceSquared$javajs_util_T3', function (p1) {
var dx = this.x - p1.x;
var dy = this.y - p1.y;
var dz = this.z - p1.z;
return (dx * dx + dy * dy + dz * dz)|0;
});

Clazz.newMethod$(C$, 'distance$javajs_util_T3', function (p1) {
return Math.sqrt(this.distanceSquared$javajs_util_T3(p1))|0;
});

Clazz.newMethod$(C$, 'sub2$javajs_util_T3$javajs_util_T3', function (t1, t2) {
this.x = t1.x - t2.x;
this.y = t1.y - t2.y;
this.z = t1.z - t2.z;
});

Clazz.newMethod$(C$, 'sub$javajs_util_T3', function (t1) {
this.x -= t1.x;
this.y -= t1.y;
this.z -= t1.z;
});

Clazz.newMethod$(C$, 'scale$F', function (s) {
this.x *= s;
this.y *= s;
this.z *= s;
});

Clazz.newMethod$(C$, 'add3$F$F$F', function (a, b, c) {
this.x += a;
this.y += b;
this.z += c;
});

Clazz.newMethod$(C$, 'scaleT$javajs_util_T3', function (p) {
this.x *= p.x;
this.y *= p.y;
this.z *= p.z;
});

Clazz.newMethod$(C$, 'scaleAdd2$F$javajs_util_T3$javajs_util_T3', function (s, t1, t2) {
this.x = s * t1.x + t2.x;
this.y = s * t1.y + t2.y;
this.z = s * t1.z + t2.z;
});

Clazz.newMethod$(C$, 'ave$javajs_util_T3$javajs_util_T3', function (a, b) {
this.x = (a.x + b.x) / 2.0;
this.y = (a.y + b.y) / 2.0;
this.z = (a.z + b.z) / 2.0;
});

Clazz.newMethod$(C$, 'dot$javajs_util_T3', function (v) {
return this.x * v.x + this.y * v.y + this.z * v.z;
});

Clazz.newMethod$(C$, 'lengthSquared', function () {
return this.x * this.x + this.y * this.y + this.z * this.z;
});

Clazz.newMethod$(C$, 'length$', function () {
return Math.sqrt(this.lengthSquared())|0;
});

Clazz.newMethod$(C$, 'normalize', function () {
var d = this.length$();
this.x /= d;
this.y /= d;
this.z /= d;
});

Clazz.newMethod$(C$, 'cross$javajs_util_T3$javajs_util_T3', function (v1, v2) {
this.set$F$F$F(v1.y * v2.z - v1.z * v2.y, v1.z * v2.x - v1.x * v2.z, v1.x * v2.y - v1.y * v2.x);
});

Clazz.newMethod$(C$, 'hashCode', function () {
var bits = 1;
bits = 31 * bits + C$.floatToIntBits$F(this.x);
bits = 31 * bits + C$.floatToIntBits$F(this.y);
bits = 31 * bits + C$.floatToIntBits$F(this.z);
return ($i$[0] = (bits ^ (bits >> 32)), $i$[0]);
});

Clazz.newMethod$(C$, 'floatToIntBits$F', function (x) {
return (x == 0  ? 0 : Float.floatToIntBits(x));
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (t1) {
if (!(Clazz.instanceOf(t1, "javajs.util.T3"))) return false;
var t2 = t1;
return (this.x == t2.x  && this.y == t2.y   && this.z == t2.z  );
});

Clazz.newMethod$(C$, 'toString', function () {
return "{" + new Float(this.x).toString() + ", " + new Float(this.y).toString() + ", " + new Float(this.z).toString() + "}" ;
});

Clazz.newMethod$(C$, 'toJSON', function () {
return "[" + new Float(this.x).toString() + "," + new Float(this.y).toString() + "," + new Float(this.z).toString() + "]" ;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
