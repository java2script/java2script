(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "Encoding", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "NONE", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "UTF8", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "UTF_16BE", 2, []);
Clazz.newEnumConst$(vals, C$.c$, "UTF_16LE", 3, []);
Clazz.newEnumConst$(vals, C$.c$, "UTF_32BE", 4, []);
Clazz.newEnumConst$(vals, C$.c$, "UTF_32LE", 5, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})();
//Created 2017-10-14 13:31:27
