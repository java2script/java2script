(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "PdfEncoder", null, 'javajs.img.ImageEncoder');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.isLandscape = false;
this.pdf = null;
this.comment = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'setParams$java_util_Map', function (params) {
this.isLandscape = (this.quality > 1);
this.comment = "Jmol " + params.get$O("comment");
});

Clazz.newMethod$(C$, 'generate', function () {
this.pdf = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.export.PDFCreator'))));
var pageWidth = 576;
var pageHeight = 792;
this.pdf.setOutputStream$java_io_OutputStream(this.out);
this.pdf.newDocument$I$I$Z(pageWidth, pageHeight, this.isLandscape);
p$.addMyImage$I$I.apply(this, [pageWidth, pageHeight]);
var ht = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Hashtable'))));
if (this.comment != null ) ht.put$TK$TV("Producer", this.comment);
ht.put$TK$TV("Author", "JMol");
ht.put$TK$TV("CreationDate", this.date);
this.pdf.addInfo$java_util_Map(ht);
this.pdf.closeDocument();
});

Clazz.newMethod$(C$, 'addMyImage$I$I', function (pageWidth, pageHeight) {
this.pdf.addImageResource$O$I$I$IA$Z("img1", this.width, this.height, this.pixels, true);
var w = (this.isLandscape ? pageHeight : pageWidth);
var h = (this.isLandscape ? pageWidth : pageHeight);
var iw = this.width;
var ih = this.height;
if (iw > 0.9 * w ) {
ih = ($i$[0] = (ih * 0.9 * w  / iw), $i$[0]);
iw = ($i$[0] = (w * 0.9), $i$[0]);
}if (ih > 0.9 * h ) {
iw = ($i$[0] = (iw * 0.9 * h  / ih), $i$[0]);
ih = ($i$[0] = (h * 0.9), $i$[0]);
}var x = 0;
var y = 0;
var x1 = iw;
var y1 = ih;
if (w > iw) {
x = ($i$[0] = (w - iw)/2, $i$[0]);
x1 = iw + x;
}if (h > ih) {
y = ($i$[0] = (h - ih)/2, $i$[0]);
y1 = ih + y;
}this.pdf.drawImage$O$I$I$I$I$I$I$I$I("img1", x, y, x1, y1, 0, 0, this.width, this.height);
});
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:25
