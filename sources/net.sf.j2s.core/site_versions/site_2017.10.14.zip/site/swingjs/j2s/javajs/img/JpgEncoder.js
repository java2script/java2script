(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "JpgEncoder", null, 'javajs.img.ImageEncoder');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.eoi =  Clazz.newArray$(Byte.TYPE, -1, [-1, -39]);
C$.jfif =  Clazz.newArray$(Byte.TYPE, -1, [-1, -32, 0, 16, 74, 70, 73, 70, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0]);
C$.soi =  Clazz.newArray$(Byte.TYPE, -1, [-1, -40]);
};

C$.eoi = null;
C$.jfif = null;
C$.soi = null;

Clazz.newMethod$(C$, '$init$', function () {
this.jpegObj = null;
this.huf = null;
this.dct = null;
this.defaultQuality = 100;
this.applicationTag = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'setParams$java_util_Map', function (params) {
if (this.quality <= 0) this.quality = (params.containsKey$O("qualityJPG") ? (params.get$O("qualityJPG")).intValue() : this.defaultQuality);
this.jpegObj = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.img.JpegObj'))));
this.jpegObj.comment = params.get$O("comment");
this.applicationTag = params.get$O("jpgAppTag");
});

Clazz.newMethod$(C$, 'generate', function () {
this.jpegObj.imageWidth = this.width;
this.jpegObj.imageHeight = this.height;
this.dct = Clazz.new((I$[1] || (I$[1]=Clazz.load('javajs.img.DCT'))).c$$I,[this.quality]);
this.huf = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).c$$I$I,[this.width, this.height]);
if (this.jpegObj == null ) return;
this.jpegObj.getYCCArray$IA(this.pixels);
var longState = p$.writeHeaders$javajs_img_JpegObj$javajs_img_DCT.apply(this, [this.jpegObj, this.dct]);
p$.writeCompressedData$javajs_img_JpegObj$javajs_img_DCT$javajs_img_Huffman.apply(this, [this.jpegObj, this.dct, this.huf]);
this.writeMarker$BA(C$.eoi);
if (longState != null ) {
var b = longState.getBytes();
this.out.write$BA$I$I(b, 0, b.length);
}});

Clazz.newMethod$(C$, 'writeCompressedData$javajs_img_JpegObj$javajs_img_DCT$javajs_img_Huffman', function (jpegObj, dct, huf) {
var i;
var j;
var r;
var c;
var a;
var b;
var comp;
var xpos;
var ypos;
var xblockoffset;
var yblockoffset;
var inputArray;
var dctArray1 =  Clazz.newArray$(Float.TYPE, [8, 8]);
var dctArray2 =  Clazz.newArray$(Double.TYPE, [8, 8]);
var dctArray3 =  Clazz.newArray$(Integer.TYPE, [64]);
var lastDCvalue =  Clazz.newArray$(Integer.TYPE, [jpegObj.numberOfComponents]);
var minBlockWidth;
var minBlockHeight;
minBlockWidth = ((huf.imageWidth % 8 != 0) ? ($i$[0] = (Math.floor(huf.imageWidth / 8.0) + 1), $i$[0]) * 8 : huf.imageWidth);
minBlockHeight = ((huf.imageHeight % 8 != 0) ? ($i$[0] = (Math.floor(huf.imageHeight / 8.0) + 1), $i$[0]) * 8 : huf.imageHeight);
for (comp = 0; comp < jpegObj.numberOfComponents; comp++) {
minBlockWidth = Math.min(minBlockWidth, jpegObj.blockWidth[comp]);
minBlockHeight = Math.min(minBlockHeight, jpegObj.blockHeight[comp]);
}
xpos = 0;
for (r = 0; r < minBlockHeight; r++) {
for (c = 0; c < minBlockWidth; c++) {
xpos = c * 8;
ypos = r * 8;
for (comp = 0; comp < jpegObj.numberOfComponents; comp++) {
inputArray = jpegObj.components[comp];
var vsampF = jpegObj.vsampFactor[comp];
var hsampF = jpegObj.hsampFactor[comp];
var qNumber = jpegObj.qtableNumber[comp];
var dcNumber = jpegObj.dctableNumber[comp];
var acNumber = jpegObj.actableNumber[comp];
for (i = 0; i < vsampF; i++) {
for (j = 0; j < hsampF; j++) {
xblockoffset = j * 8;
yblockoffset = i * 8;
for (a = 0; a < 8; a++) {
for (b = 0; b < 8; b++) {
dctArray1[a][b] = inputArray[ypos + yblockoffset + a ][xpos + xblockoffset + b ];
}
}
dctArray2 = (I$[1] || (I$[1]=Clazz.load('javajs.img.DCT'))).forwardDCT$FAA(dctArray1);
dctArray3 = (I$[1] || (I$[1]=Clazz.load('javajs.img.DCT'))).quantizeBlock$DAA$DA(dctArray2, dct.divisors[qNumber]);
huf.HuffmanBlockEncoder$javajs_util_OC$IA$I$I$I(this.out, dctArray3, lastDCvalue[comp], dcNumber, acNumber);
lastDCvalue[comp] = dctArray3[0];
}
}
}
}
}
huf.flushBuffer$javajs_util_OC(this.out);
});

Clazz.newMethod$(C$, 'writeHeaders$javajs_img_JpegObj$javajs_img_DCT', function (jpegObj, dct) {
var i;
var j;
var index;
var offset;
var tempArray;
this.writeMarker$BA(C$.soi);
this.writeArray$BA(C$.jfif);
var comment = null;
if (jpegObj.comment != null  && jpegObj.comment.length$() > 0 ) p$.writeString$S$B.apply(this, [jpegObj.comment, ($b$[0] = -31, $b$[0])]);
p$.writeString$S$B.apply(this, ["JPEG Encoder Copyright 1998, James R. Weeks and BioElectroMech.\u000a\u000a", ($b$[0] = -2, $b$[0])]);
var dqt =  Clazz.newArray$(Byte.TYPE, [134]);
dqt[0] = -1;
dqt[1] = -37;
dqt[2] = 0;
dqt[3] = -124;
offset = 4;
for (i = 0; i < 2; i++) {
dqt[offset++] = (0 + i);
tempArray = dct.quantum[i];
for (j = 0; j < 64; j++) {
dqt[offset++] = tempArray[(I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).jpegNaturalOrder[j]];
}
}
this.writeArray$BA(dqt);
var sof =  Clazz.newArray$(Byte.TYPE, [19]);
sof[0] = -1;
sof[1] = -64;
sof[2] = 0;
sof[3] = 17;
sof[4] = jpegObj.precision;
sof[5] = ((jpegObj.imageHeight >> 8) & 255);
sof[6] = ((jpegObj.imageHeight) & 255);
sof[7] = ((jpegObj.imageWidth >> 8) & 255);
sof[8] = ((jpegObj.imageWidth) & 255);
sof[9] = jpegObj.numberOfComponents;
index = 10;
for (i = 0; i < sof[9]; i++) {
sof[index++] = jpegObj.compID[i];
sof[index++] = ((jpegObj.hsampFactor[i] << 4) + jpegObj.vsampFactor[i]);
sof[index++] = jpegObj.qtableNumber[i];
}
this.writeArray$BA(sof);
this.WriteDHTHeader$IA$IA((I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).bitsDCluminance, (I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).valDCluminance);
this.WriteDHTHeader$IA$IA((I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).bitsACluminance, (I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).valACluminance);
this.WriteDHTHeader$IA$IA((I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).bitsDCchrominance, (I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).valDCchrominance);
this.WriteDHTHeader$IA$IA((I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).bitsACchrominance, (I$[2] || (I$[2]=Clazz.load('javajs.img.Huffman'))).valACchrominance);
var sos =  Clazz.newArray$(Byte.TYPE, [14]);
sos[0] = -1;
sos[1] = -38;
sos[2] = 0;
sos[3] = 12;
sos[4] = jpegObj.numberOfComponents;
index = 5;
for (i = 0; i < sos[4]; i++) {
sos[index++] = jpegObj.compID[i];
sos[index++] = ((jpegObj.dctableNumber[i] << 4) + jpegObj.actableNumber[i]);
}
sos[index++] = jpegObj.ss;
sos[index++] = jpegObj.se;
sos[index++] = ((jpegObj.ah << 4) + jpegObj.al);
this.writeArray$BA(sos);
return comment;
});

Clazz.newMethod$(C$, 'writeString$S$B', function (s, id) {
var len = s.length$();
var i0 = 0;
var suffix = this.applicationTag;
while (i0 < len){
var nBytes = len - i0;
if (nBytes > 65510) {
nBytes = 65500;
var pt = s.lastIndexOf('\u000a'.$c(), i0 + nBytes);
if (pt > i0 + 1) nBytes = pt - i0;
}if (i0 + nBytes == len) suffix = "";
p$.writeTag$I$B.apply(this, [nBytes + suffix.length$(), ($b$[0] = id, $b$[0])]);
this.writeArray$BA(s.substring(i0, i0 + nBytes).getBytes());
if (suffix.length$() > 0) this.writeArray$BA(suffix.getBytes());
i0 = i0+(nBytes);
}
});

Clazz.newMethod$(C$, 'writeTag$I$B', function (length, id) {
length = length+(2);
var com =  Clazz.newArray$(Byte.TYPE, [4]);
com[0] = -1;
com[1] = id;
com[2] = ((length >> 8) & 255);
com[3] = (length & 255);
this.writeArray$BA(com);
});

Clazz.newMethod$(C$, 'WriteDHTHeader$IA$IA', function (bits, val) {
var dht;
var bytes = 0;
for (var j = 1; j < 17; j++) bytes = bytes+(bits[j]);

dht =  Clazz.newArray$(Byte.TYPE, [21 + bytes]);
dht[0] = -1;
dht[1] = -60;
var index = 4;
for (var j = 0; j < 17; j++) dht[index++] = bits[j];

for (var j = 0; j < bytes; j++) dht[index++] = val[j];

dht[2] = (((index - 2) >> 8) & 255);
dht[3] = ((index - 2) & 255);
this.writeArray$BA(dht);
});

Clazz.newMethod$(C$, 'writeMarker$BA', function (data) {
this.out.write$BA$I$I(data, 0, 2);
});

Clazz.newMethod$(C$, 'writeArray$BA', function (data) {
this.out.write$BA$I$I(data, 0, data.length);
});
var $i$ = new Int32Array(1);
var $b$ = new Int8Array(1);
})();
//Created 2017-10-14 13:31:25
