(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "Lst", null, 'java.util.ArrayList');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'addLast$TV', function (v) {
return C$.superClazz.prototype.add$TE.apply(this, [v]);
});

Clazz.newMethod$(C$, 'removeItemAt$I', function (location) {
return C$.superClazz.prototype.remove$I.apply(this, [location]);
});

Clazz.newMethod$(C$, 'removeObj$O', function (v) {
return C$.superClazz.prototype.remove$O.apply(this, [v]);
});
})();
//Created 2017-10-14 13:31:27
