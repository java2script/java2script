(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "AjaxURLStreamHandler", null, 'java.net.URLStreamHandler');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.protocol = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (protocol) {
Clazz.super(C$, this,1);
this.protocol = protocol;
}, 1);

Clazz.newMethod$(C$, 'openConnection$java_net_URL', function (url) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.util.AjaxURLConnection'))).c$$java_net_URL,[url]);
});

Clazz.newMethod$(C$, 'toExternalForm$java_net_URL', function (u) {
var result = Clazz.new((I$[1] || (I$[1]=Clazz.load('javajs.util.SB'))));
result.append$S(u.getProtocol());
result.append$S(":");
if (u.getAuthority() != null  && u.getAuthority().length$() > 0 ) {
result.append$S("//");
result.append$S(u.getAuthority());
}if (u.getPath() != null ) {
result.append$S(u.getPath());
}if (u.getQuery() != null ) {
result.append$S("?");
result.append$S(u.getQuery());
}if (u.getRef() != null ) {
result.append$S("#");
result.append$S(u.getRef());
}return result.toString();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:25
