(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "AjaxURLConnection", null, 'java.net.URLConnection');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.bytesOut = null;
this.postOut = "";
}, 1);

Clazz.newMethod$(C$, 'c$$java_net_URL', function (url) {
C$.superClazz.c$$java_net_URL.apply(this, [url]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'doAjax$Z', function (isBinary) {
var jmol = null;
{
jmol = J2S || Jmol;
}return jmol._doAjax(this.url, this.postOut, this.bytesOut, isBinary);
});

Clazz.newMethod$(C$, 'connect', function () {
});

Clazz.newMethod$(C$, 'outputBytes$BA', function (bytes) {
this.bytesOut = bytes;
});

Clazz.newMethod$(C$, 'outputString$S', function (post) {
this.postOut = post;
});

Clazz.newMethod$(C$, 'getInputStream', function () {
var bis = C$.getAttachedStreamData$java_net_URL(this.url);
if (bis != null ) return bis;
var o = p$.doAjax$Z.apply(this, [true]);
return ((I$[0] || (I$[0]=Clazz.load('javajs.util.AU'))).isAB$O(o) ? (I$[1] || (I$[1]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(o) : Clazz.instanceOf(o, "javajs.util.SB") ? (I$[1] || (I$[1]=Clazz.load('javajs.util.Rdr'))).getBIS$BA((I$[1] || (I$[1]=Clazz.load('javajs.util.Rdr'))).getBytesFromSB$javajs_util_SB(o)) : Clazz.instanceOf(o, "java.lang.String") ? (I$[1] || (I$[1]=Clazz.load('javajs.util.Rdr'))).getBIS$BA((o).getBytes()) : bis);
});

Clazz.newMethod$(C$, 'getAttachedStreamData$java_net_URL', function (url) {
var bis = null;
{
bis = url._streamData;
}if (bis != null ) (bis).resetStream();
return bis;
}, 1);

Clazz.newMethod$(C$, 'getContents', function () {
return p$.doAjax$Z.apply(this, [false]);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:25
