(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "JSJSONParser");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.str = null;
this.index = 0;
this.len = 0;
this.asHashTable = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'parseMap$S$Z', function (str, asHashTable) {
this.index = 0;
this.asHashTable = asHashTable;
this.str = str;
this.len = str.length$();
if (p$.getChar.apply(this, []) != '{') return null;
p$.returnChar.apply(this, []);
return p$.getValue$Z.apply(this, [false]);
});

Clazz.newMethod$(C$, 'parse$S', function (str) {
this.index = 0;
this.str = str;
this.len = str.length$();
return p$.getValue$Z.apply(this, [false]);
});

Clazz.newMethod$(C$, 'next', function () {
return (this.index < this.len ? this.str.charAt(this.index++) : '\u0000');
});

Clazz.newMethod$(C$, 'returnChar', function () {
this.index--;
});

Clazz.newMethod$(C$, 'getChar', function () {
for (; ; ) {
var c = p$.next.apply(this, []);
if (c.$c() == 0  || c > ' ' ) {
return c;
}}
});

Clazz.newMethod$(C$, 'getValue$Z', function (isKey) {
var i = this.index;
var c = p$.getChar.apply(this, []);
switch (c.$c()) {
case 0:
return null;
case 34:
case 39:
return p$.getString$C.apply(this, [c]);
case 123:
if (!isKey) return p$.getObject.apply(this, []);
c = String.fromCharCode(0);
break;
case 91:
if (!isKey) return p$.getArray.apply(this, []);
c = String.fromCharCode(0);
break;
default:
p$.returnChar.apply(this, []);
while (c >= ' ' && "[,]{:}'\"".indexOf(c.$c()) < 0 )c = p$.next.apply(this, []);

p$.returnChar.apply(this, []);
if (isKey && c != ':' ) c = String.fromCharCode(0);
break;
}
if (isKey && c.$c() == 0  ) throw Clazz.new(Clazz.load('javajs.util.JSONException').c$$S,["invalid key"]);
var string = this.str.substring(i, this.index);
if (!isKey) {
if (string.equals$O("true")) {
return Boolean.TRUE;
}if (string.equals$O("false")) {
return Boolean.FALSE;
}if (string.equals$O("null")) {
return (this.asHashTable ? string : null);
}}c = string.charAt(0);
if (c >= '0' && c <= '9'  || c == '-' ) try {
if (string.indexOf('.'.$c()) < 0 && string.indexOf('e'.$c()) < 0  && string.indexOf('E'.$c()) < 0 ) return  new Integer(string);
var d = Float.$valueOf(string);
if (!d.isInfinite() && !d.isNaN() ) return d;
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
} else {
throw e;
}
}
System.out.println$S("JSON parser cannot parse " + string);
throw Clazz.new(Clazz.load('javajs.util.JSONException').c$$S,["invalid value"]);
});

Clazz.newMethod$(C$, 'getString$C', function (quote) {
var c;
var sb = null;
var i0 = this.index;
for (; ; ) {
var i1 = this.index;
switch ((c = p$.next.apply(this, [])).$c()) {
case 0:
case 10:
case 13:
throw this.syntaxError$S("Unterminated string");
case 92:
switch ((c = p$.next.apply(this, [])).$c()) {
case 34:
case 39:
case 92:
case 47:
break;
case 98:
c = '\u0008';
break;
case 116:
c = '\u0009';
break;
case 110:
c = '\u000a';
break;
case 102:
c = '\u000c';
break;
case 114:
c = '\u000d';
break;
case 117:
var i = this.index;
this.index = this.index+(4);
try {
c = String.fromCharCode(Integer.parseInt(this.str.substring(i, this.index), 16));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
throw this.syntaxError$S("Substring bounds error");
} else {
throw e;
}
}
break;
default:
throw this.syntaxError$S("Illegal escape.");
}
break;
default:
if (c == quote) return (sb == null  ? this.str.substring(i0, i1) : sb.toString());
break;
}
if (this.index > i1 + 1) {
if (sb == null ) {
sb = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.util.SB'))));
sb.append$S(this.str.substring(i0, i1));
}}if (sb != null ) sb.appendC$C(c);
}
});

Clazz.newMethod$(C$, 'getObject', function () {
var map = (this.asHashTable ? Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Hashtable')))) : Clazz.new((I$[2] || (I$[2]=Clazz.load('java.util.HashMap')))));
var key = null;
switch ((p$.getChar.apply(this, [])).$c()) {
case 125:
return map;
case 0:
throw Clazz.new(Clazz.load('javajs.util.JSONException').c$$S,["invalid object"]);
}
p$.returnChar.apply(this, []);
var isKey = false;
for (; ; ) {
if ((isKey = !isKey) == true ) key = p$.getValue$Z.apply(this, [true]).toString();
 else map.put$TK$TV(key, p$.getValue$Z.apply(this, [false]));
switch ((p$.getChar.apply(this, [])).$c()) {
case 125:
return map;
case 58:
if (isKey) continue;
isKey = true;
case 44:
if (!isKey) continue;
default:
throw this.syntaxError$S("Expected \',\' or \':\' or \'}\'");
}
}
});

Clazz.newMethod$(C$, 'getArray', function () {
var l = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.Lst'))));
switch ((p$.getChar.apply(this, [])).$c()) {
case 93:
return l;
case 0:
throw Clazz.new(Clazz.load('javajs.util.JSONException').c$$S,["invalid array"]);
}
p$.returnChar.apply(this, []);
var isNull = false;
for (; ; ) {
if (isNull) {
l.addLast$TV(null);
isNull = false;
} else {
l.addLast$TV(p$.getValue$Z.apply(this, [false]));
}switch ((p$.getChar.apply(this, [])).$c()) {
case 44:
switch ((p$.getChar.apply(this, [])).$c()) {
case 93:
return l;
case 44:
isNull = true;
default:
p$.returnChar.apply(this, []);
}
continue;
case 93:
return l;
default:
throw this.syntaxError$S("Expected \',\' or \']\'");
}
}
});

Clazz.newMethod$(C$, 'syntaxError$S', function (message) {
return Clazz.new(Clazz.load('javajs.util.JSONException').c$$S,[message + " for " + this.str.substring(0, Math.min(this.index, this.len)) ]);
});
})();
//Created 2017-10-14 13:31:27
