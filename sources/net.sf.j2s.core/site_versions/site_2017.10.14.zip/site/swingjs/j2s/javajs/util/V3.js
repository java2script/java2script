(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "V3", null, 'javajs.util.T3');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'newV$javajs_util_T3', function (t) {
return C$.new3$F$F$F(t.x, t.y, t.z);
}, 1);

Clazz.newMethod$(C$, 'newVsub$javajs_util_T3$javajs_util_T3', function (t1, t2) {
return C$.new3$F$F$F(t1.x - t2.x, t1.y - t2.y, t1.z - t2.z);
}, 1);

Clazz.newMethod$(C$, 'new3$F$F$F', function (x, y, z) {
var v = Clazz.new(C$);
v.x = x;
v.y = y;
v.z = z;
return v;
}, 1);

Clazz.newMethod$(C$, 'angle$javajs_util_V3', function (v1) {
var xx = this.y * v1.z - this.z * v1.y;
var yy = this.z * v1.x - this.x * v1.z;
var zz = this.x * v1.y - this.y * v1.x;
var cross = Math.sqrt(xx * xx + yy * yy + zz * zz);
return Math.abs(Math.atan2(cross, this.dot$javajs_util_T3(v1)))|0;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
