(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "BArray");


Clazz.newMethod$(C$, '$init$', function () {
this.data = null;
}, 1);

Clazz.newMethod$(C$, 'c$$BA', function (data) {
C$.$init$.apply(this);
this.data = data;
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (Clazz.instanceOf(o, "javajs.util.BArray")) {
var d = (o).data;
if (d.length == this.data.length) {
for (var i = 0; i < d.length; i++) if (d[i] != this.data[i]) return false;

return true;
}}return false;
});

Clazz.newMethod$(C$, 'hashCode', function () {
return this.data.hashCode();
});

Clazz.newMethod$(C$, 'toString', function () {
return  String.instantialize(this.data);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:26
