(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "ListDataReader", null, 'javajs.util.DataReader');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.data = null;
this.pt = 0;
this.len = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setData$O', function (data) {
this.data = data;
this.len = this.data.size();
return this;
});

Clazz.newMethod$(C$, 'read$CA$I$I', function (buf, off, len) {
return this.readBuf$CA$I$I(buf, off, len);
});

Clazz.newMethod$(C$, 'readLine', function () {
return (this.pt < this.len ? this.data.get$I(this.pt++) : null);
});

Clazz.newMethod$(C$, 'mark$J', function (ptr) {
this.ptMark = this.pt;
});

Clazz.newMethod$(C$, 'reset', function () {
this.pt = this.ptMark;
});
})();
//Created 2017-10-14 13:31:27
