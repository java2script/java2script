(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "StringDataReader", null, 'javajs.util.DataReader');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (data) {
C$.superClazz.c$$java_io_Reader.apply(this, [Clazz.new((I$[0] || (I$[0]=Clazz.load('java.io.StringReader'))).c$$S,[data])]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setData$O', function (data) {
return Clazz.new(C$.c$$S,[data]);
});
})();
//Created 2017-10-14 13:31:28
