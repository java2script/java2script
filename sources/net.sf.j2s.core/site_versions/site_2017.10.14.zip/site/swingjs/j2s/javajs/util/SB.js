(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "SB");


Clazz.newMethod$(C$, '$init$', function () {
this.sb = null;
this.s = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
{
this.s = "";
}}, 1);

Clazz.newMethod$(C$, 'newN$I', function (n) {
{
return new javajs.util.SB();
}}, 1);

Clazz.newMethod$(C$, 'newS$S', function (s) {
{
var sb = new javajs.util.SB();
sb.s = s;
return sb;
}}, 1);

Clazz.newMethod$(C$, 'append$S', function (s) {
{
this.s += s }return this;
});

Clazz.newMethod$(C$, 'appendC$C', function (c) {
{
this.s += c;
}return this;
});

Clazz.newMethod$(C$, 'appendI$I', function (i) {
{
this.s += i }return this;
});

Clazz.newMethod$(C$, 'appendB$Z', function (b) {
{
this.s += b }return this;
});

Clazz.newMethod$(C$, 'appendF$F', function (f) {
{
var sf = "" + f;
if (sf.indexOf(".") < 0 && sf.indexOf("e") < 0) sf += ".0" ;
this.s += sf;
}return this;
});

Clazz.newMethod$(C$, 'appendD$D', function (d) {
{
var sf = "" + d;
if (sf.indexOf(".") < 0 && sf.indexOf("e") < 0) sf += ".0" ;
this.s += sf;
}return this;
});

Clazz.newMethod$(C$, 'appendSB$javajs_util_SB', function (buf) {
{
this.s += buf.s;
}return this;
});

Clazz.newMethod$(C$, 'appendO$O', function (data) {
if (data != null ) {
{
this.s += data.toString();
}}return this;
});

Clazz.newMethod$(C$, 'appendCB$CA$I$I', function (cb, off, len) {
{
this.s += cb.slice(off,off+len).join("");
}});

Clazz.newMethod$(C$, 'toString', function () {
{
return this.s;
}});

Clazz.newMethod$(C$, 'length$', function () {
{
return this.s.length;
}});

Clazz.newMethod$(C$, 'indexOf$S', function (s) {
{
return this.s.indexOf(s);
}});

Clazz.newMethod$(C$, 'charAt$I', function (i) {
{
return this.s.charAt(i);
}});

Clazz.newMethod$(C$, 'charCodeAt$I', function (i) {
{
return this.s.charCodeAt(i);
}});

Clazz.newMethod$(C$, 'setLength$I', function (n) {
{
this.s = this.s.substring(0, n);
}});

Clazz.newMethod$(C$, 'lastIndexOf$S', function (s) {
{
return this.s.lastIndexOf(s);
}});

Clazz.newMethod$(C$, 'indexOf2$S$I', function (s, i) {
{
return this.s.indexOf(s, i);
}});

Clazz.newMethod$(C$, 'substring$I', function (i) {
{
return this.s.substring(i);
}});

Clazz.newMethod$(C$, 'substring2$I$I', function (i, j) {
{
return this.s.substring(i, j);
}});

Clazz.newMethod$(C$, 'toBytes$I$I', function (off, len) {
if (len == 0) return  Clazz.newArray$(Byte.TYPE, [0]);
var cs;
{
cs = "UTF-8";
}return (len > 0 ? this.substring2$I$I(off, off + len) : off == 0 ? this.toString() : this.substring2$I$I(off, this.length$() - off)).getBytes(cs);
});

Clazz.newMethod$(C$, 'replace$I$I$S', function (start, end, str) {
{
this.s = this.s.substring(0, start) + str + this.s.substring(end);
}});

Clazz.newMethod$(C$, 'insert$I$S', function (offset, str) {
this.replace$I$I$S(offset, offset, str);
});
})();
//Created 2017-10-14 13:31:28
