(function(){var P$=Clazz.declarePackage("javajs");
})();

//Created 2017-10-10 07:27:58
