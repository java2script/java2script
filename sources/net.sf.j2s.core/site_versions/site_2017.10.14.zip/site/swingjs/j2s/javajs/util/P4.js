(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "P4", null, 'javajs.util.T4');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'new4$F$F$F$F', function (x, y, z, w) {
var pt = Clazz.new(C$);
pt.set4$F$F$F$F(x, y, z, w);
return pt;
}, 1);

Clazz.newMethod$(C$, 'newPt$javajs_util_P4', function (value) {
var pt = Clazz.new(C$);
pt.set4$F$F$F$F(value.x, value.y, value.z, value.w);
return pt;
}, 1);

Clazz.newMethod$(C$, 'distance4$javajs_util_P4', function (p1) {
var dx = this.x - p1.x;
var dy = this.y - p1.y;
var dz = this.z - p1.z;
var dw = this.w - p1.w;
return Math.sqrt(dx * dx + dy * dy + dz * dz + dw * dw)|0;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:27
