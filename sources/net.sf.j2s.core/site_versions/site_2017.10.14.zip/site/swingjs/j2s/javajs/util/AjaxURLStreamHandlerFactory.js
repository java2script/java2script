(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "AjaxURLStreamHandlerFactory", null, null, 'java.net.URLStreamHandlerFactory');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.htFactories = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Hashtable'))));
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'createURLStreamHandler$S', function (protocol) {
var fac = this.htFactories.get$O(protocol);
if (fac == null ) this.htFactories.put$TK$TV(protocol, fac = Clazz.new((I$[1] || (I$[1]=Clazz.load('javajs.util.AjaxURLStreamHandler'))).c$$S,[protocol]));
return (fac.protocol == null  ? null : fac);
});
})();
//Created 2017-10-14 13:31:25
