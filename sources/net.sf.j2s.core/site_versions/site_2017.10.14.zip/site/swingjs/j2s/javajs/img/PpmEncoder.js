(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "PpmEncoder", null, 'javajs.img.ImageEncoder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setParams$java_util_Map', function (params) {
});

Clazz.newMethod$(C$, 'generate', function () {
this.putString$S("P6\u000a");
this.putString$S(this.width + " " + this.height + "\n" );
this.putString$S("255\u000a");
var ppmPixels =  Clazz.newArray$(Byte.TYPE, [this.width * 3]);
for (var pt = 0, row = 0; row < this.height; ++row) {
for (var col = 0, j = 0; col < this.width; ++col, pt++) {
var p = this.pixels[pt];
ppmPixels[j++] = ((p >> 16) & 255);
ppmPixels[j++] = ((p >> 8) & 255);
ppmPixels[j++] = (p & 255);
}
this.out.write$BA$I$I(ppmPixels, 0, ppmPixels.length);
}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:25
