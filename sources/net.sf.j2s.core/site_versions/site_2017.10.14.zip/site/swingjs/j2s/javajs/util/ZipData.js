(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "ZipData");


Clazz.newMethod$(C$, '$init$', function () {
this.isEnabled = true;
this.buf = null;
this.pt = 0;
this.nBytes = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (nBytes) {
C$.$init$.apply(this);
this.nBytes = nBytes;
}, 1);

Clazz.newMethod$(C$, 'addBytes$BA$I$I', function (byteBuf, nSectorBytes, nBytesRemaining) {
if (this.pt == 0) {
if (!(I$[0] || (I$[0]=Clazz.load('javajs.util.Rdr'))).isGzipB$BA(byteBuf)) {
this.isEnabled = false;
return -1;
}this.buf =  Clazz.newArray$(Byte.TYPE, [nBytesRemaining]);
}var nToAdd = Math.min(nSectorBytes, nBytesRemaining);
System.arraycopy(byteBuf, 0, this.buf, this.pt, nToAdd);
this.pt = this.pt+(nToAdd);
return nBytesRemaining - nToAdd;
});

Clazz.newMethod$(C$, 'addTo$javajs_api_GenericZipTools$javajs_util_SB', function (jzt, data) {
data.append$S(C$.getGzippedBytesAsString$javajs_api_GenericZipTools$BA(jzt, this.buf));
});

Clazz.newMethod$(C$, 'getGzippedBytesAsString$javajs_api_GenericZipTools$BA', function (jzt, bytes) {
try {
var bis = jzt.getUnGzippedInputStream$BA(bytes);
var s = (I$[1] || (I$[1]=Clazz.load('javajs.util.ZipTools'))).getStreamAsString$java_io_InputStream(bis);
bis.close();
return s;
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return "";
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
