(function(){var P$=Clazz.newPackage$("javajs.api");
var C$=Clazz.newInterface$(P$, "GenericLineReader");

})();
//Created 2017-10-14 13:31:24
