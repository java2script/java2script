(function(){var P$=Clazz.newPackage$("javajs.util");
var C$=Clazz.newClass$(P$, "DebugJS");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '_$S', function (msg) {
{
if (Clazz._debugging) { debugger;
} }}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:26
