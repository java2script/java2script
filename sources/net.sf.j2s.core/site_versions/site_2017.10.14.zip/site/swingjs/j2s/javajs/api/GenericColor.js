(function(){var P$=Clazz.newPackage$("javajs.api");
var C$=Clazz.newInterface$(P$, "GenericColor");

})();
//Created 2017-10-14 13:31:24
