(function(){var P$=Clazz.newPackage$("javajs.export"),I$=[];
var C$=Clazz.newClass$(P$, "PDFCreator");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.os = null;
this.indirectObjects = null;
this.root = null;
this.graphics = null;
this.pt = 0;
this.xrefPt = 0;
this.count = 0;
this.height = 0;
this.width = 0;
this.fonts = null;
this.images = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setOutputStream$java_io_OutputStream', function (os) {
this.os = os;
});

Clazz.newMethod$(C$, 'newDocument$I$I$Z', function (paperWidth, paperHeight, isLandscape) {
this.width = (isLandscape ? paperHeight : paperWidth);
this.height = (isLandscape ? paperWidth : paperHeight);
System.out.println$S("Creating PDF with width=" + this.width + " and height=" + this.height );
this.fonts = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Hashtable'))));
this.indirectObjects = Clazz.new((I$[1] || (I$[1]=Clazz.load('javajs.util.Lst'))));
this.root = p$.newObject$S.apply(this, ["Catalog"]);
var pages = p$.newObject$S.apply(this, ["Pages"]);
var page = p$.newObject$S.apply(this, ["Page"]);
var pageContents = p$.newObject$S.apply(this, [null]);
this.graphics = p$.newObject$S.apply(this, ["XObject"]);
this.root.addDef$S$O("Pages", pages.getRef());
pages.addDef$S$O("Count", "1");
pages.addDef$S$O("Kids", "[ " + page.getRef() + " ]" );
page.addDef$S$O("Parent", pages.getRef());
page.addDef$S$O("MediaBox", "[ 0 0 " + paperWidth + " " + paperHeight + " ]" );
if (isLandscape) page.addDef$S$O("Rotate", "90");
pageContents.addDef$S$O("Length", "?");
pageContents.append$S((isLandscape ? "q 0 1 1 0 0 0 " : "q 1 0 0 -1 0 " + (paperHeight)) + " cm /" + this.graphics.getID() + " Do Q" );
page.addDef$S$O("Contents", pageContents.getRef());
p$.addProcSet$javajs_export_PDFObject.apply(this, [page]);
p$.addProcSet$javajs_export_PDFObject.apply(this, [this.graphics]);
this.graphics.addDef$S$O("Subtype", "/Form");
this.graphics.addDef$S$O("FormType", "1");
this.graphics.addDef$S$O("BBox", "[0 0 " + this.width + " " + this.height + "]" );
this.graphics.addDef$S$O("Matrix", "[1 0 0 1 0 0]");
this.graphics.addDef$S$O("Length", "?");
page.addResource$S$S$S("XObject", this.graphics.getID(), this.graphics.getRef());
this.g$S("q 1 w 1 J 1 j 10 M []0 d q ");
p$.clip$I$I$I$I.apply(this, [0, 0, this.width, this.height]);
});

Clazz.newMethod$(C$, 'addProcSet$javajs_export_PDFObject', function (o) {
o.addResource$S$S$S(null, "ProcSet", "[/PDF /Text /ImageB /ImageC /ImageI]");
});

Clazz.newMethod$(C$, 'clip$I$I$I$I', function (x1, y1, x2, y2) {
this.moveto$I$I(x1, y1);
this.lineto$I$I(x2, y1);
this.lineto$I$I(x2, y2);
this.lineto$I$I(x1, y2);
this.g$S("h W n");
});

Clazz.newMethod$(C$, 'moveto$I$I', function (x, y) {
this.g$S(x + " " + y + " m" );
});

Clazz.newMethod$(C$, 'lineto$I$I', function (x, y) {
this.g$S(x + " " + y + " l" );
});

Clazz.newMethod$(C$, 'newObject$S', function (type) {
var o = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.export.PDFObject'))).c$$I,[++this.count]);
if (type != null ) o.addDef$S$O("Type", "/" + type);
this.indirectObjects.addLast$TV(o);
return o;
});

Clazz.newMethod$(C$, 'addInfo$java_util_Map', function (data) {
var info = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Hashtable'))));
for (var e, $e = data.entrySet().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var value = "(" + e.getValue().$replace(')', '_').$replace('(', '_') + ")" ;
info.put$TK$TV(e.getKey(), value);
}
this.root.addDef$S$O("Info", info);
});

Clazz.newMethod$(C$, 'addFontResource$S', function (fname) {
var f = p$.newObject$S.apply(this, ["Font"]);
this.fonts.put$TK$TV(fname, f);
f.addDef$S$O("BaseFont", fname);
f.addDef$S$O("Encoding", "/WinAnsiEncoding");
f.addDef$S$O("Subtype", "/Type1");
this.graphics.addResource$S$S$S("Font", f.getID(), f.getRef());
return f;
});

Clazz.newMethod$(C$, 'addImageResource$O$I$I$IA$Z', function (newImage, width, height, buffer, isRGB) {
var imageObj = p$.newObject$S.apply(this, ["XObject"]);
if (this.images == null ) this.images = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Hashtable'))));
this.images.put$TK$TV(newImage, imageObj);
imageObj.addDef$S$O("Subtype", "/Image");
imageObj.addDef$S$O("Length", "?");
imageObj.addDef$S$O("ColorSpace", isRGB ? "/DeviceRGB" : "/DeviceGray");
imageObj.addDef$S$O("BitsPerComponent", "8");
imageObj.addDef$S$O("Width", "" + width);
imageObj.addDef$S$O("Height", "" + height);
this.graphics.addResource$S$S$S("XObject", imageObj.getID(), imageObj.getRef());
var n = buffer.length;
var stream =  Clazz.newArray$(Byte.TYPE, [n * (isRGB ? 3 : 1)]);
if (isRGB) {
for (var i = 0, pt = 0; i < n; i++) {
stream[pt++] = ((buffer[i] >> 16) & 255);
stream[pt++] = ((buffer[i] >> 8) & 255);
stream[pt++] = (buffer[i] & 255);
}
} else {
for (var i = 0; i < n; i++) stream[i] = buffer[i];

}imageObj.setStream$BA(stream);
this.graphics.addResource$S$S$S("XObject", imageObj.getID(), imageObj.getRef());
});

Clazz.newMethod$(C$, 'g$S', function (cmd) {
this.graphics.append$S(cmd).appendC$C('\u000a');
});

Clazz.newMethod$(C$, 'output$S', function (s) {
var b = s.getBytes();
this.os.write$BA$I$I(b, 0, b.length);
this.pt = this.pt+(b.length);
});

Clazz.newMethod$(C$, 'closeDocument', function () {
this.g$S("Q Q");
p$.outputHeader.apply(this, []);
p$.writeObjects.apply(this, []);
p$.writeXRefTable.apply(this, []);
p$.writeTrailer.apply(this, []);
this.os.flush();
this.os.close();
});

Clazz.newMethod$(C$, 'outputHeader', function () {
p$.output$S.apply(this, ["%PDF-1.3\u000a%"]);
var b =  Clazz.newArray$(Byte.TYPE, -1, [-1, -1, -1, -1]);
this.os.write$BA$I$I(b, 0, b.length);
this.pt = this.pt+(4);
p$.output$S.apply(this, ["\u000a"]);
});

Clazz.newMethod$(C$, 'writeTrailer', function () {
var trailer = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.export.PDFObject'))).c$$I,[-2]);
p$.output$S.apply(this, ["trailer"]);
trailer.addDef$S$O("Size", "" + this.indirectObjects.size());
trailer.addDef$S$O("Root", this.root.getRef());
trailer.output$java_io_OutputStream(this.os);
p$.output$S.apply(this, ["startxref\u000a"]);
p$.output$S.apply(this, ["" + this.xrefPt + "\n" ]);
p$.output$S.apply(this, ["%%EOF\u000a"]);
});

Clazz.newMethod$(C$, 'writeObjects', function () {
var nObj = this.indirectObjects.size();
for (var i = 0; i < nObj; i++) {
var o = this.indirectObjects.get$I(i);
if (!o.isFont()) continue;
o.pt = this.pt;
this.pt = this.pt+(o.output$java_io_OutputStream(this.os));
}
for (var i = 0; i < nObj; i++) {
var o = this.indirectObjects.get$I(i);
if (o.isFont()) continue;
o.pt = this.pt;
this.pt = this.pt+(o.output$java_io_OutputStream(this.os));
}
});

Clazz.newMethod$(C$, 'writeXRefTable', function () {
this.xrefPt = this.pt;
var nObj = this.indirectObjects.size();
var sb = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
sb.append$S("xref\n0 " + (nObj + 1) + "\n0000000000 65535 f\r\n" );
for (var i = 0; i < nObj; i++) {
var o = this.indirectObjects.get$I(i);
var s = "0000000000" + o.pt;
sb.append$S(s.substring(s.length$() - 10));
sb.append$S(" 00000 n\u000d\u000a");
}
p$.output$S.apply(this, [sb.toString()]);
});

Clazz.newMethod$(C$, 'canDoLineTo', function () {
return true;
});

Clazz.newMethod$(C$, 'fill', function () {
this.g$S("f");
});

Clazz.newMethod$(C$, 'stroke', function () {
this.g$S("S");
});

Clazz.newMethod$(C$, 'doCircle$I$I$I$Z', function (x, y, r, doFill) {
var d = r * 4 * (Math.sqrt(2) - 1)  / 3;
var dx = x;
var dy = y;
this.g$S(new Double((dx + r)).toString() + " " + new Double(dy).toString() + " m" );
this.g$S(new Double((dx + r)).toString() + " " + new Double((dy + d)).toString() + " " + new Double((dx + d)).toString() + " " + new Double((dy + r)).toString() + " " + new Double((dx)).toString() + " " + new Double((dy + r)).toString() + " " + " c" );
this.g$S(new Double((dx - d)).toString() + " " + new Double((dy + r)).toString() + " " + new Double((dx - r)).toString() + " " + new Double((dy + d)).toString() + " " + new Double((dx - r)).toString() + " " + new Double((dy)).toString() + " c" );
this.g$S(new Double((dx - r)).toString() + " " + new Double((dy - d)).toString() + " " + new Double((dx - d)).toString() + " " + new Double((dy - r)).toString() + " " + new Double((dx)).toString() + " " + new Double((dy - r)).toString() + " c" );
this.g$S(new Double((dx + d)).toString() + " " + new Double((dy - r)).toString() + " " + new Double((dx + r)).toString() + " " + new Double((dy - d)).toString() + " " + new Double((dx + r)).toString() + " " + new Double((dy)).toString() + " c" );
this.g$S(doFill ? "f" : "s");
});

Clazz.newMethod$(C$, 'doPolygon$IA$IA$I$Z', function (axPoints, ayPoints, nPoints, doFill) {
this.moveto$I$I(axPoints[0], ayPoints[0]);
for (var i = 1; i < nPoints; i++) this.lineto$I$I(axPoints[i], ayPoints[i]);

this.g$S(doFill ? "f" : "s");
});

Clazz.newMethod$(C$, 'doRect$I$I$I$I$Z', function (x, y, width, height, doFill) {
this.g$S(x + " " + y + " " + width + " " + height + " re " + (doFill ? "f" : "s") );
});

Clazz.newMethod$(C$, 'drawImage$O$I$I$I$I$I$I$I$I', function (image, destX0, destY0, destX1, destY1, srcX0, srcY0, srcX1, srcY1) {
var imageObj = this.images.get$O(image);
if (imageObj == null ) return;
this.g$S("q");
p$.clip$I$I$I$I.apply(this, [destX0, destY0, destX1, destY1]);
var iw = Double.parseDouble(imageObj.getDef$S("Width"));
var ih = Double.parseDouble(imageObj.getDef$S("Height"));
var dw = (destX1 - destX0 + 1);
var dh = (destY1 - destY0 + 1);
var sw = (srcX1 - srcX0 + 1);
var sh = (srcY1 - srcY0 + 1);
var scaleX = dw / sw;
var scaleY = dh / sh;
var transX = destX0 - srcX0 * scaleX;
var transY = destY0 + (ih - srcY0) * scaleY;
this.g$S(new Double(scaleX * iw).toString() + " 0 0 " + new Double(-scaleY * ih).toString() + " " + new Double(transX).toString() + " " + new Double(transY).toString() + " cm");
this.g$S("/" + imageObj.getID() + " Do" );
this.g$S("Q");
});

Clazz.newMethod$(C$, 'drawStringRotated$S$I$I$I', function (s, x, y, angle) {
this.g$S("q " + this.getRotation$I(angle) + " " + x + " " + y + " cm BT(" + s + ")Tj ET Q" );
});

Clazz.newMethod$(C$, 'getRotation$I', function (angle) {
var cos = 0;
var sin = 0;
switch (angle) {
case 0:
cos = 1;
break;
case 90:
sin = 1;
break;
case -90:
sin = -1;
break;
case 180:
cos = -1;
break;
default:
var a = (angle * 0.017453292519943295)|0;
cos = Math.cos(a)|0;
sin = Math.sin(a)|0;
if (Math.abs(cos) < 1.0E-4 ) cos = 0;
if (Math.abs(sin) < 1.0E-4 ) sin = 0;
}
return new Float(cos).toString() + " " + new Float(sin).toString() + " " + new Float(sin).toString() + " " + new Float(-cos).toString() ;
});

Clazz.newMethod$(C$, 'setColor$FA$Z', function (rgb, isFill) {
this.g$S(new Float(rgb[0]).toString() + " " + new Float(rgb[1]).toString() + " " + new Float(rgb[2]).toString() + (isFill ? " rg" : " RG") );
});

Clazz.newMethod$(C$, 'setFont$S$F', function (fname, size) {
var f = this.fonts.get$O(fname);
if (f == null ) f = p$.addFontResource$S.apply(this, [fname]);
this.g$S("/" + f.getID() + " " + new Float(size).toString() + " Tf" );
});

Clazz.newMethod$(C$, 'setLineWidth$F', function (width) {
this.g$S(new Float(width).toString() + " w");
});

Clazz.newMethod$(C$, 'translateScale$F$F$F', function (x, y, scale) {
this.g$S(new Float(scale).toString() + " 0 0 " + new Float(scale).toString() + " " + new Float(x).toString() + " " + new Float(y).toString() + " cm" );
});
})();
//Created 2017-10-14 13:31:24
