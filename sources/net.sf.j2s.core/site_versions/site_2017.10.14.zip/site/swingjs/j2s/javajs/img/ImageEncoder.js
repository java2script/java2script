(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "ImageEncoder", null, null, 'javajs.api.GenericImageEncoder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.out = null;
this.width = -1;
this.height = -1;
this.quality = -1;
this.date = null;
this.logging = false;
this.doClose = true;
this.pixels = null;
}, 1);

Clazz.newMethod$(C$, 'createImage$S$javajs_util_OC$java_util_Map', function (type, out, params) {
this.out = out;
this.logging = (Boolean.TRUE === params.get$O("logging") );
this.width = (params.get$O("imageWidth")).intValue();
this.height = (params.get$O("imageHeight")).intValue();
this.pixels = params.get$O("imagePixels");
this.date = params.get$O("date");
var q = params.get$O("quality");
this.quality = (q == null  ? -1 : q.intValue());
this.setParams$java_util_Map(params);
this.generate();
this.close();
return this.doClose;
});

Clazz.newMethod$(C$, 'putString$S', function (s) {
var b = s.getBytes();
this.out.write$BA$I$I(b, 0, b.length);
});

Clazz.newMethod$(C$, 'putByte$I', function (b) {
this.out.writeByteAsInt$I(b);
});

Clazz.newMethod$(C$, 'close', function () {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:25
