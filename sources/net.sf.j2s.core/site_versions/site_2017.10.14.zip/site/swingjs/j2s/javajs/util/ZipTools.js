(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "ZipTools", null, null, 'javajs.api.GenericZipTools');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'newZipInputStream$java_io_InputStream', function (is) {
return C$.newZIS$java_io_InputStream(is);
});

Clazz.newMethod$(C$, 'newZIS$java_io_InputStream', function (is) {
return (Clazz.instanceOf(is, "javajs.api.ZInputStream") ? is : Clazz.instanceOf(is, "java.io.BufferedInputStream") ? Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.api.GenericZipInputStream'))).c$$java_io_InputStream,[is]) : Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.api.GenericZipInputStream'))).c$$java_io_InputStream,[Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.BufferedInputStream'))).c$$java_io_InputStream,[is])]));
}, 1);

Clazz.newMethod$(C$, 'getAllZipData$java_io_InputStream$SA$S$S$S$java_util_Map', function (is, subfileList, name0, binaryFileList, exclude, fileData) {
var zis = C$.newZIS$java_io_InputStream(is);
var ze;
var listing = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
binaryFileList = "|" + binaryFileList + "|" ;
var prefix = (I$[3] || (I$[3]=Clazz.load('javajs.util.PT'))).join$SA$C$I(subfileList, '/', 1);
var prefixd = null;
if (prefix != null ) {
prefixd = prefix.substring(0, prefix.indexOf("/") + 1);
if (prefixd.length$() == 0) prefixd = null;
}try {
while ((ze = zis.getNextEntry()) != null ){
var name = ze.getName();
if (prefix != null  && prefixd != null   && !(name.equals$O(prefix) || name.startsWith$S(prefixd) )  || exclude != null  && name.contains$CharSequence(exclude)  ) continue;
listing.append$S(name).appendC$C('\u000a');
var sname = "|" + name.substring(name.lastIndexOf("/") + 1) + "|" ;
var asBinaryString = (binaryFileList.indexOf(sname) >= 0);
var bytes = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(zis, ze.getSize());
var str;
if (asBinaryString) {
str = p$.getBinaryStringForBytes$BA.apply(this, [bytes]);
name += ":asBinaryString";
} else {
str = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).fixUTF$BA(bytes);
}str = "BEGIN Directory Entry " + name + "\n" + str + "\nEND Directory Entry " + name + "\n" ;
var key = name0 + "|" + name ;
fileData.put$TK$TV(key, str);
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
} else {
throw e;
}
}
fileData.put$TK$TV("#Directory_Listing", listing.toString());
});

Clazz.newMethod$(C$, 'getBinaryStringForBytes$BA', function (bytes) {
var ret = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
for (var i = 0; i < bytes.length; i++) ret.append$S(Integer.toHexString(bytes[i] & 255)).appendC$C(' ');

return ret.toString();
});

Clazz.newMethod$(C$, 'getZipFileDirectory$java_io_BufferedInputStream$SA$I$Z', function (bis, list, listPtr, asBufferedInputStream) {
var ret;
if (list == null  || listPtr >= list.length ) return this.getZipDirectoryAsStringAndClose$java_io_BufferedInputStream(bis);
bis = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getPngZipStream$java_io_BufferedInputStream$Z(bis, true);
var fileName = list[listPtr];
var zis = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.util.zip.ZipInputStream'))).c$$java_io_InputStream,[bis]);
var ze;
try {
var isAll = (fileName.equals$O("."));
if (isAll || fileName.lastIndexOf("/") == fileName.length$() - 1 ) {
ret = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
while ((ze = zis.getNextEntry()) != null ){
var name = ze.getName();
if (isAll || name.startsWith$S(fileName) ) ret.append$S(name).appendC$C('\u000a');
}
var str = ret.toString();
return (asBufferedInputStream ? (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(str.getBytes()) : str);
}var pt = fileName.indexOf(":asBinaryString");
var asBinaryString = (pt > 0);
if (asBinaryString) fileName = fileName.substring(0, pt);
fileName = fileName.$replace('\\', '/');
while ((ze = zis.getNextEntry()) != null  && !fileName.equals$O(ze.getName()) ){
}
var bytes = (ze == null  ? null : (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(zis, ze.getSize()));
ze = null;
zis.close();
if (bytes == null ) return "";
if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isZipB$BA(bytes) || (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isPngZipB$BA(bytes) ) return this.getZipFileDirectory$java_io_BufferedInputStream$SA$I$Z((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(bytes), list, ++listPtr, asBufferedInputStream);
if (asBufferedInputStream) return (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(bytes);
if (asBinaryString) {
ret = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
for (var i = 0; i < bytes.length; i++) ret.append$S(Integer.toHexString(bytes[i] & 255)).appendC$C(' ');

return ret.toString();
}if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isGzipB$BA(bytes)) bytes = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(this.getUnGzippedInputStream$BA(bytes), -1);
return (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).fixUTF$BA(bytes);
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return "";
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getZipFileContentsAsBytes$java_io_BufferedInputStream$SA$I', function (bis, list, listPtr) {
var ret =  Clazz.newArray$(Byte.TYPE, [0]);
var fileName = list[listPtr];
if (fileName.lastIndexOf("/") == fileName.length$() - 1) return ret;
try {
bis = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getPngZipStream$java_io_BufferedInputStream$Z(bis, true);
var zis = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.util.zip.ZipInputStream'))).c$$java_io_InputStream,[bis]);
var ze;
while ((ze = zis.getNextEntry()) != null ){
if (!fileName.equals$O(ze.getName())) continue;
var bytes = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(zis, ze.getSize());
return (((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isZipB$BA(bytes) || (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isPngZipB$BA(bytes) ) && ++listPtr < list.length  ? this.getZipFileContentsAsBytes$java_io_BufferedInputStream$SA$I((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(bytes), list, listPtr) : bytes);
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
} else {
throw e;
}
}
return ret;
});

Clazz.newMethod$(C$, 'getZipDirectoryAsStringAndClose$java_io_BufferedInputStream', function (bis) {
var sb = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
var s =  Clazz.newArray$(java.lang.String, [0]);
try {
s = p$.getZipDirectoryOrErrorAndClose$java_io_BufferedInputStream$S.apply(this, [bis, null]);
bis.close();
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
for (var i = 0; i < s.length; i++) sb.append$S(s[i]).appendC$C('\u000a');

return sb.toString();
});

Clazz.newMethod$(C$, 'getZipDirectoryAndClose$java_io_BufferedInputStream$S', function (bis, manifestID) {
var s =  Clazz.newArray$(java.lang.String, [0]);
try {
s = p$.getZipDirectoryOrErrorAndClose$java_io_BufferedInputStream$S.apply(this, [bis, manifestID]);
bis.close();
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
return s;
});

Clazz.newMethod$(C$, 'getZipDirectoryOrErrorAndClose$java_io_BufferedInputStream$S', function (bis, manifestID) {
bis = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getPngZipStream$java_io_BufferedInputStream$Z(bis, true);
var v = Clazz.new((I$[6] || (I$[6]=Clazz.load('javajs.util.Lst'))));
var zis = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.util.zip.ZipInputStream'))).c$$java_io_InputStream,[bis]);
var ze;
var manifest = null;
while ((ze = zis.getNextEntry()) != null ){
var fileName = ze.getName();
if (manifestID != null  && fileName.startsWith$S(manifestID) ) manifest = C$.getStreamAsString$java_io_InputStream(zis);
 else if (!fileName.startsWith$S("__MACOS")) v.addLast$TV(fileName);
}
zis.close();
if (manifestID != null ) v.add$I$TE(0, manifest == null  ? "" : manifest + "\n############\n");
return v.toArray$TTA( Clazz.newArray$(java.lang.String, [v.size()]));
});

Clazz.newMethod$(C$, 'getStreamAsString$java_io_InputStream', function (is) {
return (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).fixUTF$BA((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(is, -1));
}, 1);

Clazz.newMethod$(C$, 'newGZIPInputStream$java_io_InputStream', function (is) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.BufferedInputStream'))).c$$java_io_InputStream,[Clazz.new((I$[7] || (I$[7]=Clazz.load('java.util.zip.GZIPInputStream'))).c$$java_io_InputStream$I,[is, 512])]);
});

Clazz.newMethod$(C$, 'getUnGzippedInputStream$BA', function (bytes) {
try {
return (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getUnzippedInputStream$javajs_api_GenericZipTools$java_io_BufferedInputStream(this, (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(bytes));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return null;
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'addZipEntry$O$S', function (zos, fileName) {
(zos).putNextEntry$java_util_zip_ZipEntry(Clazz.new((I$[8] || (I$[8]=Clazz.load('java.util.zip.ZipEntry'))).c$$S,[fileName]));
});

Clazz.newMethod$(C$, 'closeZipEntry$O', function (zos) {
(zos).closeEntry();
});

Clazz.newMethod$(C$, 'getZipOutputStream$O', function (bos) {
{
return javajs.api.Interface.getInterface( "java.util.zip.ZipOutputStream").setZOS(bos);
}});

Clazz.newMethod$(C$, 'getCrcValue$BA', function (bytes) {
var crc = Clazz.new((I$[9] || (I$[9]=Clazz.load('java.util.zip.CRC32'))));
crc.update$BA$I$I(bytes, 0, bytes.length);
return ($i$[0] = crc.getValue(), $i$[0]);
});

Clazz.newMethod$(C$, 'readFileAsMap$java_io_BufferedInputStream$java_util_Map$S', function (bis, bdata, name) {
C$.readFileAsMapStatic$java_io_BufferedInputStream$java_util_Map$S(bis, bdata, name);
});

Clazz.newMethod$(C$, 'readFileAsMapStatic$java_io_BufferedInputStream$java_util_Map$S', function (bis, bdata, name) {
var pt = (name == null  ? -1 : name.indexOf("|"));
name = (pt >= 0 ? name.substring(pt + 1) : null);
try {
if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isPngZipStream$java_io_InputStream(bis)) {
var isImage = "_IMAGE_".equals$O(name);
if (name == null  || isImage ) bdata.put$TK$TV((isImage ? "_DATA_" : "_IMAGE_"), Clazz.new((I$[10] || (I$[10]=Clazz.load('javajs.util.BArray'))).c$$BA,[C$.getPngImageBytes$java_io_BufferedInputStream(bis)]));
if (!isImage) C$.cacheZipContentsStatic$java_io_BufferedInputStream$S$java_util_Map$Z(bis, name, bdata, true);
} else if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isZipS$java_io_InputStream(bis)) {
C$.cacheZipContentsStatic$java_io_BufferedInputStream$S$java_util_Map$Z(bis, name, bdata, true);
} else if (name == null ) {
bdata.put$TK$TV("_DATA_", Clazz.new((I$[10] || (I$[10]=Clazz.load('javajs.util.BArray'))).c$$BA,[(I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(bis, -1)]));
} else {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["ZIP file " + name + " not found" ]);
}bdata.put$TK$TV("$_BINARY_$", Boolean.TRUE);
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
bdata.clear();
bdata.put$TK$TV("_ERROR_", e.getMessage());
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'cacheZipContents$java_io_BufferedInputStream$S$java_util_Map$Z', function (bis, fileName, cache, asByteArray) {
return C$.cacheZipContentsStatic$java_io_BufferedInputStream$S$java_util_Map$Z(bis, fileName, cache, asByteArray);
});

Clazz.newMethod$(C$, 'cacheZipContentsStatic$java_io_BufferedInputStream$S$java_util_Map$Z', function (bis, fileName, cache, asByteArray) {
var zis = C$.newZIS$java_io_InputStream(bis);
var ze;
var listing = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.SB'))));
var n = 0;
var isPath = (fileName != null  && fileName.endsWith$S("/") );
var oneFile = (asByteArray && !isPath && fileName != null   );
var pt = (oneFile ? fileName.indexOf("|") : -1);
var file0 = (pt >= 0 ? fileName : null);
if (pt >= 0) fileName = fileName.substring(0, pt);
var prefix = (fileName == null  ? "" : isPath ? fileName : fileName + "|");
try {
while ((ze = zis.getNextEntry()) != null ){
var name = ze.getName();
if (fileName != null ) {
if (oneFile) {
if (!name.equalsIgnoreCase$S(fileName)) continue;
} else {
listing.append$S(name).appendC$C('\u000a');
}}var nBytes = ze.getSize();
var bytes = (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(zis, nBytes);
if (file0 != null ) {
C$.readFileAsMapStatic$java_io_BufferedInputStream$java_util_Map$S((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getBIS$BA(bytes), cache, file0);
return null;
}n = n+(bytes.length);
var o = (asByteArray ? Clazz.new((I$[10] || (I$[10]=Clazz.load('javajs.util.BArray'))).c$$BA,[bytes]) : bytes);
cache.put$TK$TV((oneFile ? "_DATA_" : prefix + name), o);
if (oneFile) break;
}
zis.close();
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
try {
zis.close();
} catch (e1) {
if (Clazz.exceptionOf(e1, java.io.IOException)){
} else {
throw e1;
}
}
return null;
} else {
throw e;
}
}
if (n == 0 || fileName == null  ) return null;
System.out.println$S("ZipTools cached " + n + " bytes from " + fileName );
return listing.toString();
}, 1);

Clazz.newMethod$(C$, 'getPngImageBytes$java_io_BufferedInputStream', function (bis) {
try {
if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isPngZipStream$java_io_InputStream(bis)) {
var pt_count =  Clazz.newArray$(Integer.TYPE, [2]);
(I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getPngZipPointAndCount$java_io_BufferedInputStream$IA(bis, pt_count);
if (pt_count[1] != 0) return C$.deActivatePngZipB$BA((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(bis, pt_count[0]));
}return (I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(bis, -1);
} catch (e) {
if (Clazz.exceptionOf(e, java.io.IOException)){
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'deActivatePngZipB$BA', function (bytes) {
if ((I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).isPngZipB$BA(bytes)) bytes[51] = 32;
return bytes;
}, 1);
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:28
