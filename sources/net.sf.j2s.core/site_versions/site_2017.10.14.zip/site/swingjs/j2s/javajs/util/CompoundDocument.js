(function(){var P$=Clazz.newPackage$("javajs.util"),I$=[];
var C$=Clazz.newClass$(P$, "CompoundDocument", null, 'javajs.util.BinaryDocument');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.header = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.util.CompoundDocHeader'))).c$$javajs_util_CompoundDocument,[this]);
this.directory = Clazz.new((I$[1] || (I$[1]=Clazz.load('javajs.util.Lst'))));
this.rootEntry = null;
this.jzt = null;
this.SAT = null;
this.SSAT = null;
this.sectorSize = 0;
this.shortSectorSize = 0;
this.nShortSectorsPerStandardSector = 0;
this.nIntPerSector = 0;
this.nDirEntriesperSector = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.isBigEndian = true;
}, 1);

Clazz.newMethod$(C$, 'setDocStream$javajs_api_GenericZipTools$java_io_BufferedInputStream', function (jzt, bis) {
this.jzt = jzt;
if (!this.isRandom) {
this.stream = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.io.DataInputStream'))).c$$java_io_InputStream,[bis]);
}this.stream.mark$I(2147483647);
if (!p$.readHeader.apply(this, [])) return;
p$.getSectorAllocationTable.apply(this, []);
p$.getShortSectorAllocationTable.apply(this, []);
p$.getDirectoryTable.apply(this, []);
});

Clazz.newMethod$(C$, 'getDirectory', function () {
return this.directory;
});

Clazz.newMethod$(C$, 'getDirectoryListing$S', function (separator) {
var sb = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
for (var i = 0; i < this.directory.size(); i++) {
var thisEntry = this.directory.get$I(i);
if (!thisEntry.isEmpty) sb.append$S(separator).append$S(thisEntry.entryName).append$S("\u0009len=").appendI$I(thisEntry.lenStream).append$S("\u0009SID=").appendI$I(thisEntry.SIDfirstSector).append$S(thisEntry.isStandard ? "\tfileOffset=" + p$.getOffset$I.apply(this, [thisEntry.SIDfirstSector]) : "");
}
return sb.toString();
});

Clazz.newMethod$(C$, 'getAllData', function () {
return this.getAllDataFiles$S$S(null, null);
});

Clazz.newMethod$(C$, 'getAllDataMapped$S$S$java_util_Map', function (prefix, binaryFileList, fileData) {
fileData.put$TK$TV("#Directory_Listing", this.getDirectoryListing$S("|"));
binaryFileList = "|" + binaryFileList + "|" ;
for (var i = 0; i < this.directory.size(); i++) {
var thisEntry = this.directory.get$I(i);
if (!thisEntry.isEmpty && thisEntry.entryType != 5 ) {
var name = thisEntry.entryName;
System.out.println$S("CompoundDocument file " + name);
var isBinary = (binaryFileList.indexOf("|" + name + "|" ) >= 0);
if (isBinary) name += ":asBinaryString";
fileData.put$TK$TV(prefix + "/" + name , p$.appendData$javajs_util_SB$S$javajs_util_CompoundDocDirEntry$Z.apply(this, [Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB')))), name, thisEntry, isBinary]).toString());
}}
this.close();
});

Clazz.newMethod$(C$, 'getAllDataFiles$S$S', function (binaryFileList, firstFile) {
var data = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
data.append$S("Compound Document File Directory: ");
data.append$S(this.getDirectoryListing$S("|"));
data.append$S("\u000a");
var thisEntry;
binaryFileList = "|" + binaryFileList + "|" ;
for (var i = 0, n = this.directory.size(); i < n; i++) {
thisEntry = this.directory.get$I(i);
var name = thisEntry.entryName;
switch (thisEntry.entryType) {
case 5:
break;
case 1:
data.append$S("NEW Directory ").append$S(name).append$S("\u000a");
break;
case 2:
if (name.endsWith$S(".gz")) name = name.substring(0, name.length$() - 3);
p$.appendData$javajs_util_SB$S$javajs_util_CompoundDocDirEntry$Z.apply(this, [data, name, thisEntry, binaryFileList.indexOf("|" + thisEntry.entryName + "|" ) >= 0]);
break;
}
}
this.close();
return data;
});

Clazz.newMethod$(C$, 'appendData$javajs_util_SB$S$javajs_util_CompoundDocDirEntry$Z', function (data, name, thisEntry, isBinary) {
data.append$S("BEGIN Directory Entry ").append$S(name).append$S("\u000a");
data.appendSB$javajs_util_SB(p$.getEntryAsString$javajs_util_CompoundDocDirEntry$Z.apply(this, [thisEntry, isBinary]));
data.append$S("\u000aEND Directory Entry ").append$S(name).append$S("\u000a");
return data;
});

Clazz.newMethod$(C$, 'getFileAsString$S', function (entryName) {
for (var i = 0; i < this.directory.size(); i++) {
var thisEntry = this.directory.get$I(i);
if (thisEntry.entryName.equals$O(entryName)) return p$.getEntryAsString$javajs_util_CompoundDocDirEntry$Z.apply(this, [thisEntry, false]);
}
return Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
});

Clazz.newMethod$(C$, 'getOffset$I', function (SID) {
return (SID + 1) * this.sectorSize;
});

Clazz.newMethod$(C$, 'gotoSector$I', function (SID) {
this.seek$J(p$.getOffset$I.apply(this, [SID]));
});

Clazz.newMethod$(C$, 'readHeader', function () {
if (!this.header.readData()) return false;
this.sectorSize = 1 << this.header.sectorPower;
this.shortSectorSize = 1 << this.header.shortSectorPower;
this.nShortSectorsPerStandardSector = ($i$[0] = this.sectorSize/this.shortSectorSize, $i$[0]);
this.nIntPerSector = ($i$[0] = this.sectorSize/4, $i$[0]);
this.nDirEntriesperSector = ($i$[0] = this.sectorSize/128, $i$[0]);
return true;
});

Clazz.newMethod$(C$, 'getSectorAllocationTable', function () {
var nSID = 0;
var thisSID;
this.SAT =  Clazz.newArray$(Integer.TYPE, [this.header.nSATsectors * this.nIntPerSector + 109]);
try {
for (var i = 0; i < 109; i++) {
thisSID = this.header.MSAT0[i];
if (thisSID < 0) break;
p$.gotoSector$I.apply(this, [thisSID]);
for (var j = 0; j < this.nIntPerSector; j++) {
this.SAT[nSID++] = this.readInt();
}
}
var nMaster = this.header.nAdditionalMATsectors;
thisSID = this.header.SID_MSAT_next;
var MSAT =  Clazz.newArray$(Integer.TYPE, [this.nIntPerSector]);
out : while (nMaster-- > 0 && thisSID >= 0 ){
p$.gotoSector$I.apply(this, [thisSID]);
for (var i = 0; i < this.nIntPerSector; i++) MSAT[i] = this.readInt();

for (var i = 0; i < this.nIntPerSector - 1; i++) {
thisSID = MSAT[i];
if (thisSID < 0) break out;
p$.gotoSector$I.apply(this, [thisSID]);
for (var j = this.nIntPerSector; --j >= 0; ) this.SAT[nSID++] = this.readInt();

}
thisSID = MSAT[this.nIntPerSector - 1];
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getShortSectorAllocationTable', function () {
var nSSID = 0;
var thisSID = this.header.SID_SSAT_start;
var nMax = this.header.nSSATsectors * this.nIntPerSector;
this.SSAT =  Clazz.newArray$(Integer.TYPE, [nMax]);
try {
while (thisSID > 0 && nSSID < nMax ){
p$.gotoSector$I.apply(this, [thisSID]);
for (var j = 0; j < this.nIntPerSector; j++) {
this.SSAT[nSSID++] = this.readInt();
}
thisSID = this.SAT[thisSID];
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getDirectoryTable', function () {
var thisSID = this.header.SID_DIR_start;
var thisEntry;
this.rootEntry = null;
try {
while (thisSID > 0){
p$.gotoSector$I.apply(this, [thisSID]);
for (var j = this.nDirEntriesperSector; --j >= 0; ) {
thisEntry = Clazz.new((I$[4] || (I$[4]=Clazz.load('javajs.util.CompoundDocDirEntry'))).c$$javajs_util_CompoundDocument,[this]);
thisEntry.readData();
this.directory.addLast$TV(thisEntry);
if (thisEntry.entryType == 5) this.rootEntry = thisEntry;
}
thisSID = this.SAT[thisSID];
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getEntryAsString$javajs_util_CompoundDocDirEntry$Z', function (thisEntry, asBinaryString) {
if (thisEntry.isEmpty) return Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
return (thisEntry.isStandard ? p$.getStandardStringData$I$I$Z.apply(this, [thisEntry.SIDfirstSector, thisEntry.lenStream, asBinaryString]) : p$.getShortStringData$I$I$Z.apply(this, [thisEntry.SIDfirstSector, thisEntry.lenStream, asBinaryString]));
});

Clazz.newMethod$(C$, 'getStandardStringData$I$I$Z', function (thisSID, nBytes, asBinaryString) {
var data = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
var byteBuf =  Clazz.newArray$(Byte.TYPE, [this.sectorSize]);
var gzipData = Clazz.new((I$[5] || (I$[5]=Clazz.load('javajs.util.ZipData'))).c$$I,[nBytes]);
try {
while (thisSID > 0 && nBytes > 0 ){
p$.gotoSector$I.apply(this, [thisSID]);
nBytes = p$.getSectorData$javajs_util_SB$BA$I$I$Z$javajs_util_ZipData.apply(this, [data, byteBuf, this.sectorSize, nBytes, asBinaryString, gzipData]);
thisSID = this.SAT[thisSID];
}
if (nBytes == -9999) return Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(e.toString());
} else {
throw e;
}
}
if (gzipData.isEnabled) gzipData.addTo$javajs_api_GenericZipTools$javajs_util_SB(this.jzt, data);
return data;
});

Clazz.newMethod$(C$, 'getSectorData$javajs_util_SB$BA$I$I$Z$javajs_util_ZipData', function (data, byteBuf, nSectorBytes, nBytes, asBinaryString, gzipData) {
this.readByteArray$BA$I$I(byteBuf, 0, byteBuf.length);
var n = gzipData.addBytes$BA$I$I(byteBuf, nSectorBytes, nBytes);
if (n >= 0) return n;
if (asBinaryString) {
for (var i = 0; i < nSectorBytes; i++) {
data.append$S(Integer.toHexString(byteBuf[i] & 255)).appendC$C(' ');
if (--nBytes < 1) break;
}
} else {
for (var i = 0; i < nSectorBytes; i++) {
if (byteBuf[i] == 0) return -9999;
data.appendC$C(String.fromCharCode(byteBuf[i]));
if (--nBytes < 1) break;
}
}return nBytes;
});

Clazz.newMethod$(C$, 'getShortStringData$I$I$Z', function (shortSID, nBytes, asBinaryString) {
var data = Clazz.new((I$[3] || (I$[3]=Clazz.load('javajs.util.SB'))));
if (this.rootEntry == null ) return data;
var thisSID = this.rootEntry.SIDfirstSector;
var ptShort = 0;
var byteBuf =  Clazz.newArray$(Byte.TYPE, [this.shortSectorSize]);
var gzipData = Clazz.new((I$[5] || (I$[5]=Clazz.load('javajs.util.ZipData'))).c$$I,[nBytes]);
try {
while (thisSID >= 0 && shortSID >= 0  && nBytes > 0 ){
while (shortSID - ptShort >= this.nShortSectorsPerStandardSector){
ptShort = ptShort+(this.nShortSectorsPerStandardSector);
thisSID = this.SAT[thisSID];
}
this.seek$J(p$.getOffset$I.apply(this, [thisSID]) + (shortSID - ptShort) * this.shortSectorSize);
nBytes = p$.getSectorData$javajs_util_SB$BA$I$I$Z$javajs_util_ZipData.apply(this, [data, byteBuf, this.shortSectorSize, nBytes, asBinaryString, gzipData]);
shortSID = this.SSAT[shortSID];
}
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
System.out.println$S(data.toString());
System.out.println$S("reader error in CompoundDocument " + e.toString());
} else {
throw e;
}
}
if (gzipData.isEnabled) gzipData.addTo$javajs_api_GenericZipTools$javajs_util_SB(this.jzt, data);
return data;
});
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:26
