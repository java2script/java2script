(function(){var P$=Clazz.newPackage$("javajs.img"),I$=[];
var C$=Clazz.newClass$(P$, "CRCEncoder", null, 'javajs.img.ImageEncoder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.startPos = 0;
this.bytePos = 0;
this.crc = null;
this.pngBytes = null;
this.dataLen = 0;
this.int2 =  Clazz.newArray$(Byte.TYPE, [2]);
this.int4 =  Clazz.newArray$(Byte.TYPE, [4]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.pngBytes =  Clazz.newArray$(Byte.TYPE, [250]);
this.crc = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.zip.CRC32'))));
}, 1);

Clazz.newMethod$(C$, 'setData$BA$I', function (b, pt) {
this.pngBytes = b;
this.dataLen = b.length;
this.startPos = this.bytePos = pt;
});

Clazz.newMethod$(C$, 'getBytes', function () {
return (this.dataLen == this.pngBytes.length ? this.pngBytes : (I$[1] || (I$[1]=Clazz.load('javajs.util.AU'))).arrayCopyByte$BA$I(this.pngBytes, this.dataLen));
});

Clazz.newMethod$(C$, 'writeCRC', function () {
this.crc.reset();
this.crc.update$BA$I$I(this.pngBytes, this.startPos, this.bytePos - this.startPos);
this.writeInt4$I(($i$[0] = this.crc.getValue(), $i$[0]));
});

Clazz.newMethod$(C$, 'writeInt2$I', function (n) {
this.int2[0] = ((n >> 8) & 255);
this.int2[1] = (n & 255);
this.writeBytes$BA(this.int2);
});

Clazz.newMethod$(C$, 'writeInt4$I', function (n) {
C$.getInt4$I$BA(n, this.int4);
this.writeBytes$BA(this.int4);
});

Clazz.newMethod$(C$, 'getInt4$I$BA', function (n, int4) {
int4[0] = ((n >> 24) & 255);
int4[1] = ((n >> 16) & 255);
int4[2] = ((n >> 8) & 255);
int4[3] = (n & 255);
}, 1);

Clazz.newMethod$(C$, 'writeByte$I', function (b) {
var temp =  Clazz.newArray$(Byte.TYPE, -1, [($b$[0] = b, $b$[0])]);
this.writeBytes$BA(temp);
});

Clazz.newMethod$(C$, 'writeString$S', function (s) {
this.writeBytes$BA(s.getBytes());
});

Clazz.newMethod$(C$, 'writeBytes$BA', function (data) {
var newPos = this.bytePos + data.length;
this.dataLen = Math.max(this.dataLen, newPos);
if (newPos > this.pngBytes.length) this.pngBytes = (I$[1] || (I$[1]=Clazz.load('javajs.util.AU'))).arrayCopyByte$BA$I(this.pngBytes, newPos + 16);
System.arraycopy(data, 0, this.pngBytes, this.bytePos, data.length);
this.bytePos = newPos;
});
var $i$ = new Int32Array(1);
var $b$ = new Int8Array(1);
})();
//Created 2017-10-14 13:31:25
