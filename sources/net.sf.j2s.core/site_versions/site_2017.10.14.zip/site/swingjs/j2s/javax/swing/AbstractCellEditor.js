(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractCellEditor", null, null, 'javax.swing.CellEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
this.changeEvent = null;
}, 1);

Clazz.newMethod$(C$, 'isCellEditable$java_util_EventObject', function (e) {
return true;
});

Clazz.newMethod$(C$, 'shouldSelectCell$java_util_EventObject', function (anEvent) {
return true;
});

Clazz.newMethod$(C$, 'stopCellEditing', function () {
this.fireEditingStopped();
return true;
});

Clazz.newMethod$(C$, 'cancelCellEditing', function () {
this.fireEditingCanceled();
});

Clazz.newMethod$(C$, 'addCellEditorListener$javax_swing_event_CellEditorListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.CellEditorListener), l);
});

Clazz.newMethod$(C$, 'removeCellEditorListener$javax_swing_event_CellEditorListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.CellEditorListener), l);
});

Clazz.newMethod$(C$, 'getCellEditorListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.CellEditorListener));
});

Clazz.newMethod$(C$, 'fireEditingStopped', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.CellEditorListener) ) {
if (this.changeEvent == null ) this.changeEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
(listeners[i + 1]).editingStopped$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'fireEditingCanceled', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.CellEditorListener) ) {
if (this.changeEvent == null ) this.changeEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
(listeners[i + 1]).editingCanceled$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:30
