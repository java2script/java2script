(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "InputVerifier");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'shouldYieldFocus$javax_swing_JComponent', function (input) {
return this.verify$javax_swing_JComponent(input);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:34
