(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SwingPaintEventDispatcher", null, 'sun.awt.PaintEventDispatcher');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
{
C$.ERASE_BACKGROUND = true;
}
};

C$.ERASE_BACKGROUND = false;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'createPaintEvent$java_awt_Component$I$I$I$I', function (component, x, y, w, h) {
return C$.superClazz.prototype.createPaintEvent$java_awt_Component$I$I$I$I.apply(this, [component, x, y, w, h]);
});

Clazz.newMethod$(C$, 'shouldDoNativeBackgroundErase$java_awt_Component', function (c) {
return C$.ERASE_BACKGROUND || !(Clazz.instanceOf(c, "javax.swing.RootPaneContainer")) ;
});

Clazz.newMethod$(C$, 'queueSurfaceDataReplacing$java_awt_Component$Runnable', function (c, r) {
if (Clazz.instanceOf(c, "javax.swing.RootPaneContainer")) {
return true;
}return C$.superClazz.prototype.queueSurfaceDataReplacing$java_awt_Component$Runnable.apply(this, [c, r]);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:50
