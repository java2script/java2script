(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "JToolTip", null, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.tipText = null;
this.component = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.setOpaque$Z(true);
this.uiClassID = "ToolTipUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'setTipText$S', function (tipText) {
var oldValue = this.tipText;
this.tipText = tipText;
this.firePropertyChange$S$O$O("tiptext", oldValue, tipText);
});

Clazz.newMethod$(C$, 'getTipText', function () {
return this.tipText;
});

Clazz.newMethod$(C$, 'setComponent$javax_swing_JComponent', function (c) {
var oldValue = this.component;
this.component = c;
this.firePropertyChange$S$O$O("component", oldValue, c);
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this.component;
});

Clazz.newMethod$(C$, 'alwaysOnTop', function () {
return true;
});

Clazz.newMethod$(C$, 'paramString', function () {
var tipTextString = (this.tipText != null  ? this.tipText : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",tipText=" + tipTextString ;
});
})();
//Created 2017-10-14 13:31:46
