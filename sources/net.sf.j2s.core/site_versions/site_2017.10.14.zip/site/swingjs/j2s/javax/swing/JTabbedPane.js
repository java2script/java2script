(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JTabbedPane", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.SwingConstants');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.tabPlacement = 1;
this.tabLayoutPolicy = 0;
this.model = null;
this.haveRegistered = false;
this.changeListener = null;
this.pages = null;
this.visComp = null;
this.changeEvent = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I$I.apply(this, [1, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (tabPlacement) {
C$.c$$I$I.apply(this, [tabPlacement, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (tabPlacement, tabLayoutPolicy) {
Clazz.super(C$, this,1);
this.setTabPlacement$I(tabPlacement);
this.setTabLayoutPolicy$I(tabLayoutPolicy);
this.pages = Clazz.new((I$[2] || (I$[2]=Clazz.load('javajs.util.Lst'))));
this.setModel$javax_swing_SingleSelectionModel(Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.DefaultSingleSelectionModel')))));
this.uiClassID = "TabbedPaneUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'setUI$javax_swing_plaf_TabbedPaneUI', function (ui) {
C$.superClazz.prototype.setUI$javax_swing_plaf_ComponentUI.apply(this, [ui]);
for (var i = 0; i < this.getTabCount(); i++) {
var icon = this.pages.get$I(i).disabledIcon;
if (Clazz.instanceOf(icon, "javax.swing.plaf.UIResource")) {
this.setDisabledIconAt$I$javax_swing_Icon(i, null);
}}
});

Clazz.newMethod$(C$, 'createChangeListener', function () {
return Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.JTabbedPane').ModelListener))), [this, null]);
});

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'getChangeListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ChangeListener));
});

Clazz.newMethod$(C$, 'fireStateChanged', function () {
var selIndex = this.getSelectedIndex();
if (selIndex < 0) {
if (this.visComp != null  && this.visComp.isVisible() ) {
this.visComp.setVisible$Z(false);
}this.visComp = null;
} else {
var newComp = this.getComponentAt$I(selIndex);
if (newComp != null  && newComp !== this.visComp  ) {
if (this.visComp != null ) {
if (this.visComp.isVisible()) {
this.visComp.setVisible$Z(false);
}}if (!newComp.isVisible()) {
newComp.setVisible$Z(true);
}this.visComp = newComp;
}}var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ChangeListener) ) {
if (this.changeEvent == null ) this.changeEvent = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
(listeners[i + 1]).stateChanged$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'getModel', function () {
return this.model;
});

Clazz.newMethod$(C$, 'setModel$javax_swing_SingleSelectionModel', function (model) {
var oldModel = this.getModel();
if (oldModel != null ) {
oldModel.removeChangeListener$javax_swing_event_ChangeListener(this.changeListener);
this.changeListener = null;
}this.model = model;
if (model != null ) {
this.changeListener = this.createChangeListener();
model.addChangeListener$javax_swing_event_ChangeListener(this.changeListener);
}this.firePropertyChange$S$O$O("model", oldModel, model);
this.repaint();
});

Clazz.newMethod$(C$, 'getTabPlacement', function () {
return this.tabPlacement;
});

Clazz.newMethod$(C$, 'setTabPlacement$I', function (tabPlacement) {
if (tabPlacement != 1 && tabPlacement != 2  && tabPlacement != 3  && tabPlacement != 4 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["illegal tab placement: must be TOP, BOTTOM, LEFT, or RIGHT"]);
}if (this.tabPlacement != tabPlacement) {
var oldValue = this.tabPlacement;
this.tabPlacement = tabPlacement;
this.firePropertyChange$S$I$I("tabPlacement", oldValue, tabPlacement);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'getTabLayoutPolicy', function () {
return this.tabLayoutPolicy;
});

Clazz.newMethod$(C$, 'setTabLayoutPolicy$I', function (tabLayoutPolicy) {
if (tabLayoutPolicy != 0 && tabLayoutPolicy != 1 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["illegal tab layout policy: must be WRAP_TAB_LAYOUT or SCROLL_TAB_LAYOUT"]);
}if (this.tabLayoutPolicy != tabLayoutPolicy) {
var oldValue = this.tabLayoutPolicy;
this.tabLayoutPolicy = tabLayoutPolicy;
this.firePropertyChange$S$I$I("tabLayoutPolicy", oldValue, tabLayoutPolicy);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'getSelectedIndex', function () {
return this.model.getSelectedIndex();
});

Clazz.newMethod$(C$, 'setSelectedIndex$I', function (index) {
if (index != -1) {
p$.checkIndex$I.apply(this, [index]);
}p$.setSelectedIndexImpl$I$Z.apply(this, [index, true]);
});

Clazz.newMethod$(C$, 'setSelectedIndexImpl$I$Z', function (index, doAccessibleChanges) {
this.model.setSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'getSelectedComponent', function () {
var index = this.getSelectedIndex();
if (index == -1) {
return null;
}return this.getComponentAt$I(index);
});

Clazz.newMethod$(C$, 'setSelectedComponent$java_awt_Component', function (c) {
var index = this.indexOfComponent$java_awt_Component(c);
if (index != -1) {
this.setSelectedIndex$I(index);
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["component not found in tabbed pane"]);
}});

Clazz.newMethod$(C$, 'insertTab$S$javax_swing_Icon$java_awt_Component$S$I', function (title, icon, component, tip, index) {
var newIndex = index;
var removeIndex = this.indexOfComponent$java_awt_Component(component);
if (component != null  && removeIndex != -1 ) {
this.removeTabAt$I(removeIndex);
if (newIndex > removeIndex) {
newIndex--;
}}var selectedIndex = this.getSelectedIndex();
this.pages.add$I$TE(newIndex, Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.JTabbedPane').Page))).c$$javax_swing_JTabbedPane$S$javax_swing_Icon$javax_swing_Icon$java_awt_Component$S, [this, null, this, title != null  ? title : "", icon, null, component, tip]));
if (component != null ) {
this.addImplCont$java_awt_Component$O$I(component, null, -1);
component.setVisible$Z(false);
} else {
this.firePropertyChange$S$I$I("indexForNullComponent", -1, index);
}if (this.pages.size() == 1) {
this.setSelectedIndex$I(0);
}if (selectedIndex >= newIndex) {
p$.setSelectedIndexImpl$I$Z.apply(this, [selectedIndex + 1, false]);
}this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'addTab$S$javax_swing_Icon$java_awt_Component$S', function (title, icon, component, tip) {
this.insertTab$S$javax_swing_Icon$java_awt_Component$S$I(title, icon, component, tip, this.pages.size());
});

Clazz.newMethod$(C$, 'addTab$S$javax_swing_Icon$java_awt_Component', function (title, icon, component) {
this.insertTab$S$javax_swing_Icon$java_awt_Component$S$I(title, icon, component, null, this.pages.size());
});

Clazz.newMethod$(C$, 'addTab$S$java_awt_Component', function (title, component) {
this.insertTab$S$javax_swing_Icon$java_awt_Component$S$I(title, null, component, null, this.pages.size());
});

Clazz.newMethod$(C$, 'add$java_awt_Component', function (component) {
if (!(Clazz.instanceOf(component, "javax.swing.plaf.UIResource"))) {
this.addTab$S$java_awt_Component(component.getName(), component);
} else {
C$.superClazz.prototype.add$java_awt_Component.apply(this, [component]);
}return component;
});

Clazz.newMethod$(C$, 'add$S$java_awt_Component', function (title, component) {
if (!(Clazz.instanceOf(component, "javax.swing.plaf.UIResource"))) {
this.addTab$S$java_awt_Component(title, component);
} else {
C$.superClazz.prototype.add$S$java_awt_Component.apply(this, [title, component]);
}return component;
});

Clazz.newMethod$(C$, 'add$java_awt_Component$I', function (component, index) {
if (!(Clazz.instanceOf(component, "javax.swing.plaf.UIResource"))) {
this.insertTab$S$javax_swing_Icon$java_awt_Component$S$I(component.getName(), null, component, null, index == -1 ? this.getTabCount() : index);
} else {
C$.superClazz.prototype.add$java_awt_Component$I.apply(this, [component, index]);
}return component;
});

Clazz.newMethod$(C$, 'add$java_awt_Component$O', function (component, constraints) {
if (!(Clazz.instanceOf(component, "javax.swing.plaf.UIResource"))) {
if (Clazz.instanceOf(constraints, "java.lang.String")) {
this.addTab$S$java_awt_Component(constraints, component);
} else if (Clazz.instanceOf(constraints, "javax.swing.Icon")) {
this.addTab$S$javax_swing_Icon$java_awt_Component(null, constraints, component);
} else {
this.add$java_awt_Component(component);
}} else {
C$.superClazz.prototype.add$java_awt_Component$O.apply(this, [component, constraints]);
}});

Clazz.newMethod$(C$, 'add$java_awt_Component$O$I', function (component, constraints, index) {
if (!(Clazz.instanceOf(component, "javax.swing.plaf.UIResource"))) {
var icon = Clazz.instanceOf(constraints, "javax.swing.Icon") ? constraints : null;
var title = Clazz.instanceOf(constraints, "java.lang.String") ? constraints : null;
this.insertTab$S$javax_swing_Icon$java_awt_Component$S$I(title, icon, component, null, index == -1 ? this.getTabCount() : index);
} else {
this.addImpl$java_awt_Component$O$I(component, constraints, index);
}return component;
});

Clazz.newMethod$(C$, 'removeTabAt$I', function (index) {
p$.checkIndex$I.apply(this, [index]);
var component = this.getComponentAt$I(index);
var selected = this.getSelectedIndex();
if (component === this.visComp ) {
this.visComp = null;
}this.setTabComponentAt$I$java_awt_Component(index, null);
this.pages.removeItemAt$I(index);
this.putClientProperty$O$O("__index_to_remove__",  new Integer(index));
if (selected > index) {
p$.setSelectedIndexImpl$I$Z.apply(this, [selected - 1, false]);
} else if (selected >= this.getTabCount()) {
p$.setSelectedIndexImpl$I$Z.apply(this, [selected - 1, false]);
} else if (index == selected) {
this.fireStateChanged();
}if (component != null ) {
var components = this.getComponents();
for (var i = components.length; --i >= 0; ) {
if (components[i] === component ) {
C$.superClazz.prototype.remove$I.apply(this, [i]);
component.setVisible$Z(true);
break;
}}
}this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (component) {
var index = this.indexOfComponent$java_awt_Component(component);
if (index != -1) {
this.removeTabAt$I(index);
} else {
var children = this.getComponents();
for (var i = 0; i < children.length; i++) {
if (component === children[i] ) {
C$.superClazz.prototype.remove$I.apply(this, [i]);
break;
}}
}});

Clazz.newMethod$(C$, 'remove$I', function (index) {
this.removeTabAt$I(index);
});

Clazz.newMethod$(C$, 'removeAll', function () {
p$.setSelectedIndexImpl$I$Z.apply(this, [-1, true]);
var tabCount = this.getTabCount();
while (tabCount-- > 0){
this.removeTabAt$I(tabCount);
}
});

Clazz.newMethod$(C$, 'getTabCount', function () {
return this.pages.size();
});

Clazz.newMethod$(C$, 'getTabRunCount', function () {
if (this.ui != null ) {
return (this.ui).getTabRunCount$javax_swing_JTabbedPane(this);
}return 0;
});

Clazz.newMethod$(C$, 'getTitleAt$I', function (index) {
return this.pages.get$I(index).title;
});

Clazz.newMethod$(C$, 'getIconAt$I', function (index) {
return this.pages.get$I(index).icon;
});

Clazz.newMethod$(C$, 'getDisabledIconAt$I', function (index) {
var page = this.pages.get$I(index);
if (page.disabledIcon == null ) {
page.disabledIcon = (I$[7] || (I$[7]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getDisabledIcon$javax_swing_JComponent$javax_swing_Icon(this, page.icon);
}return page.disabledIcon;
});

Clazz.newMethod$(C$, 'getToolTipTextAt$I', function (index) {
return this.pages.get$I(index).tip;
});

Clazz.newMethod$(C$, 'getBackgroundAt$I', function (index) {
return this.pages.get$I(index).getBackground();
});

Clazz.newMethod$(C$, 'getForegroundAt$I', function (index) {
return this.pages.get$I(index).getForeground();
});

Clazz.newMethod$(C$, 'isEnabledAt$I', function (index) {
return this.pages.get$I(index).isEnabled();
});

Clazz.newMethod$(C$, 'getComponentAt$I', function (index) {
return this.pages.get$I(index).component;
});

Clazz.newMethod$(C$, 'getMnemonicAt$I', function (tabIndex) {
p$.checkIndex$I.apply(this, [tabIndex]);
var page = this.pages.get$I(tabIndex);
return page.getMnemonic();
});

Clazz.newMethod$(C$, 'getDisplayedMnemonicIndexAt$I', function (tabIndex) {
p$.checkIndex$I.apply(this, [tabIndex]);
var page = this.pages.get$I(tabIndex);
return page.getDisplayedMnemonicIndex();
});

Clazz.newMethod$(C$, 'getBoundsAt$I', function (index) {
p$.checkIndex$I.apply(this, [index]);
if (this.ui != null ) {
return (this.ui).getTabBounds$javax_swing_JTabbedPane$I(this, index);
}return null;
});

Clazz.newMethod$(C$, 'setTitleAt$I$S', function (index, title) {
var page = this.pages.get$I(index);
var oldTitle = page.title;
page.title = title;
if (oldTitle != title) {
this.firePropertyChange$S$I$I("indexForTitle", -1, index);
}page.updateDisplayedMnemonicIndex();
if (title == null  || oldTitle == null   || !title.equals$O(oldTitle) ) {
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'setIconAt$I$javax_swing_Icon', function (index, icon) {
var page = this.pages.get$I(index);
var oldIcon = page.icon;
if (icon !== oldIcon ) {
page.icon = icon;
if (Clazz.instanceOf(page.disabledIcon, "javax.swing.plaf.UIResource")) {
page.disabledIcon = null;
}this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'setDisabledIconAt$I$javax_swing_Icon', function (index, disabledIcon) {
var oldIcon = this.pages.get$I(index).disabledIcon;
this.pages.get$I(index).disabledIcon = disabledIcon;
if (disabledIcon !== oldIcon  && !this.isEnabledAt$I(index) ) {
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'setToolTipTextAt$I$S', function (index, toolTipText) {
this.pages.get$I(index).tip = toolTipText;
});

Clazz.newMethod$(C$, 'setBackgroundAt$I$java_awt_Color', function (index, background) {
var oldBg = this.pages.get$I(index).background;
this.pages.get$I(index).setBackground$java_awt_Color(background);
if (background == null  || oldBg == null   || !background.equals$O(oldBg) ) {
var tabBounds = this.getBoundsAt$I(index);
if (tabBounds != null ) {
this.repaint$java_awt_Rectangle(tabBounds);
}}});

Clazz.newMethod$(C$, 'setForegroundAt$I$java_awt_Color', function (index, foreground) {
var oldFg = this.pages.get$I(index).foreground;
this.pages.get$I(index).setForeground$java_awt_Color(foreground);
if (foreground == null  || oldFg == null   || !foreground.equals$O(oldFg) ) {
var tabBounds = this.getBoundsAt$I(index);
if (tabBounds != null ) {
this.repaint$java_awt_Rectangle(tabBounds);
}}});

Clazz.newMethod$(C$, 'setEnabledAt$I$Z', function (index, enabled) {
var oldEnabled = this.pages.get$I(index).isEnabled();
this.pages.get$I(index).setEnabled$Z(enabled);
if (enabled != oldEnabled ) {
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'setComponentAt$I$java_awt_Component', function (index, component) {
var page = this.pages.get$I(index);
if (component !== page.component ) {
if (page.component != null ) {
{
var count = this.getComponentCount();
var children = this.getComponents();
for (var i = 0; i < count; i++) {
if (children[i] === page.component ) {
C$.superClazz.prototype.remove$I.apply(this, [i]);
}}
}}page.component = component;
var selectedPage = (this.getSelectedIndex() == index);
if (selectedPage) {
this.visComp = component;
}if (component != null ) {
component.setVisible$Z(selectedPage);
this.addImplCont$java_awt_Component$O$I(component, null, -1);
} else {
this.repaint();
}this.revalidate();
}});

Clazz.newMethod$(C$, 'setDisplayedMnemonicIndexAt$I$I', function (tabIndex, mnemonicIndex) {
p$.checkIndex$I.apply(this, [tabIndex]);
var page = this.pages.get$I(tabIndex);
page.setDisplayedMnemonicIndex$I(mnemonicIndex);
});

Clazz.newMethod$(C$, 'setMnemonicAt$I$I', function (tabIndex, mnemonic) {
p$.checkIndex$I.apply(this, [tabIndex]);
var page = this.pages.get$I(tabIndex);
page.setMnemonic$I(mnemonic);
this.firePropertyChange$S$O$O("mnemonicAt", null, null);
});

Clazz.newMethod$(C$, 'indexOfTab$S', function (title) {
for (var i = 0; i < this.getTabCount(); i++) {
if (this.getTitleAt$I(i).equals$O(title == null  ? "" : title)) {
return i;
}}
return -1;
});

Clazz.newMethod$(C$, 'indexOfTab$javax_swing_Icon', function (icon) {
for (var i = 0; i < this.getTabCount(); i++) {
var tabIcon = this.getIconAt$I(i);
if ((tabIcon != null  && tabIcon.equals$O(icon) ) || (tabIcon == null  && tabIcon === icon  ) ) {
return i;
}}
return -1;
});

Clazz.newMethod$(C$, 'indexOfComponent$java_awt_Component', function (component) {
for (var i = 0; i < this.getTabCount(); i++) {
var c = this.getComponentAt$I(i);
if ((c != null  && c.equals$O(component) ) || (c == null  && c === component  ) ) {
return i;
}}
return -1;
});

Clazz.newMethod$(C$, 'indexAtLocation$I$I', function (x, y) {
if (this.ui != null ) {
return (this.ui).tabForCoordinate$javax_swing_JTabbedPane$I$I(this, x, y);
}return -1;
});

Clazz.newMethod$(C$, 'getToolTipText$java_awt_event_MouseEvent', function (event) {
if (this.ui != null ) {
var index = (this.ui).tabForCoordinate$javax_swing_JTabbedPane$I$I(this, event.getX(), event.getY());
if (index != -1) {
return this.pages.get$I(index).tip;
}}return C$.superClazz.prototype.getToolTipText$java_awt_event_MouseEvent.apply(this, [event]);
});

Clazz.newMethod$(C$, 'checkIndex$I', function (index) {
if (index < 0 || index >= this.pages.size() ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Index: " + index + ", Tab count: " + this.pages.size() ]);
}});

Clazz.newMethod$(C$, 'paramString', function () {
var tabPlacementString;
if (this.tabPlacement == 1) {
tabPlacementString = "TOP";
} else if (this.tabPlacement == 3) {
tabPlacementString = "BOTTOM";
} else if (this.tabPlacement == 2) {
tabPlacementString = "LEFT";
} else if (this.tabPlacement == 4) {
tabPlacementString = "RIGHT";
} else tabPlacementString = "";
var haveRegisteredString = (this.haveRegistered ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",haveRegistered=" + haveRegisteredString + ",tabPlacement=" + tabPlacementString ;
});

Clazz.newMethod$(C$, 'setTabComponentAt$I$java_awt_Component', function (index, component) {
if (component != null  && this.indexOfComponent$java_awt_Component(component) != -1 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Component is already added to this JTabbedPane"]);
}var oldValue = this.getTabComponentAt$I(index);
if (component !== oldValue ) {
var tabComponentIndex = this.indexOfTabComponent$java_awt_Component(component);
if (tabComponentIndex != -1) {
this.setTabComponentAt$I$java_awt_Component(tabComponentIndex, null);
}this.pages.get$I(index).tabComponent = component;
this.firePropertyChange$S$I$I("indexForTabComponent", -1, index);
}});

Clazz.newMethod$(C$, 'getTabComponentAt$I', function (index) {
return this.pages.get$I(index).tabComponent;
});

Clazz.newMethod$(C$, 'indexOfTabComponent$java_awt_Component', function (tabComponent) {
for (var i = 0; i < this.getTabCount(); i++) {
var c = this.getTabComponentAt$I(i);
if (c === tabComponent ) {
return i;
}}
return -1;
});
;
(function(){var C$=Clazz.newClass$(P$.JTabbedPane, "ModelListener", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
this.b$['javax.swing.JTabbedPane'].fireStateChanged();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTabbedPane, "Page", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.title = null;
this.background = null;
this.foreground = null;
this.icon = null;
this.disabledIcon = null;
this.parent = null;
this.component = null;
this.tip = null;
this.enabled = true;
this.mnemonic = -1;
this.mnemonicIndex = -1;
this.tabComponent = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JTabbedPane$S$javax_swing_Icon$javax_swing_Icon$java_awt_Component$S', function (parent, title, icon, disabledIcon, component, tip) {
C$.$init$.apply(this);
this.title = title;
this.icon = icon;
this.disabledIcon = disabledIcon;
this.parent = parent;
this.component = component;
this.tip = tip;
}, 1);

Clazz.newMethod$(C$, 'setMnemonic$I', function (mnemonic) {
this.mnemonic = mnemonic;
this.updateDisplayedMnemonicIndex();
});

Clazz.newMethod$(C$, 'getMnemonic', function () {
return this.mnemonic;
});

Clazz.newMethod$(C$, 'setDisplayedMnemonicIndex$I', function (mnemonicIndex) {
if (this.mnemonicIndex != mnemonicIndex) {
if (mnemonicIndex != -1 && (this.title == null  || mnemonicIndex < 0  || mnemonicIndex >= this.title.length$() ) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid mnemonic index: " + mnemonicIndex]);
}this.mnemonicIndex = mnemonicIndex;
this.b$['javax.swing.JTabbedPane'].firePropertyChange$S$O$O("displayedMnemonicIndexAt", null, null);
}});

Clazz.newMethod$(C$, 'getDisplayedMnemonicIndex', function () {
return this.mnemonicIndex;
});

Clazz.newMethod$(C$, 'updateDisplayedMnemonicIndex', function () {
this.setDisplayedMnemonicIndex$I((I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).findDisplayedMnemonicIndex$S$I(this.title, this.mnemonic));
});

Clazz.newMethod$(C$, 'getBackground', function () {
return this.background != null  ? this.background : this.parent.getBackground();
});

Clazz.newMethod$(C$, 'setBackground$java_awt_Color', function (c) {
this.background = c;
});

Clazz.newMethod$(C$, 'getForeground', function () {
return this.foreground != null  ? this.foreground : this.parent.getForeground();
});

Clazz.newMethod$(C$, 'setForeground$java_awt_Color', function (c) {
this.foreground = c;
});

Clazz.newMethod$(C$, 'isEnabled', function () {
return this.enabled;
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (b) {
this.enabled = b;
});

Clazz.newMethod$(C$, 'isVisible', function () {
return this.parent.isVisible();
});

Clazz.newMethod$(C$, 'setVisible$Z', function (b) {
this.parent.setVisible$Z(b);
});

Clazz.newMethod$(C$, 'isShowing', function () {
return this.parent.isShowing();
});

Clazz.newMethod$(C$, 'contains$java_awt_Point', function (p) {
var r = this.getBounds();
return r.contains$java_awt_Point(p);
});

Clazz.newMethod$(C$, 'getLocationOnScreen', function () {
var parentLocation = this.parent.getLocationOnScreen();
var componentLocation = this.getLocation();
componentLocation.translate$I$I(parentLocation.x, parentLocation.y);
return componentLocation;
});

Clazz.newMethod$(C$, 'getLocation', function () {
var r = this.getBounds();
return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[r.x, r.y]);
});

Clazz.newMethod$(C$, 'getBounds', function () {
return (this.parent.getUI()).getTabBounds$javax_swing_JTabbedPane$I(this.parent, this.parent.indexOfTab$S(this.title));
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:44
