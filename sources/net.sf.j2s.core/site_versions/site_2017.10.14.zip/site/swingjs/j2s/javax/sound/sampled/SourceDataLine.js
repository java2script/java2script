(function(){var P$=Clazz.newPackage$("javax.sound.sampled");
var C$=Clazz.newInterface$(P$, "SourceDataLine", null, null, 'javax.sound.sampled.DataLine');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:29
