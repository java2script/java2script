(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newClass$(P$, "LayeredHighlighter", function(){
Clazz.newInstance$(this, arguments);
}, null, 'javax.swing.text.Highlighter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);
;
(function(){var C$=Clazz.newClass$(P$.LayeredHighlighter, "LayerPainter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'javax.swing.text.Highlighter.HighlightPainter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:03
