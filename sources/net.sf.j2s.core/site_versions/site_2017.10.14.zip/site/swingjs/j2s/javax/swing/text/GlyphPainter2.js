(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "GlyphPainter2", null, 'javax.swing.text.GlyphView.GlyphPainter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F', function (v, p0, p1, e, x) {
return 0;
});

Clazz.newMethod$(C$, 'getHeight$javax_swing_text_GlyphView', function (v) {
return 0;
});

Clazz.newMethod$(C$, 'getAscent$javax_swing_text_GlyphView', function (v) {
return 0;
});

Clazz.newMethod$(C$, 'getDescent$javax_swing_text_GlyphView', function (v) {
return 0;
});

Clazz.newMethod$(C$, 'paint$javax_swing_text_GlyphView$java_awt_Graphics$java_awt_Shape$I$I', function (v, g, a, p0, p1) {
});

Clazz.newMethod$(C$, 'modelToView$javax_swing_text_GlyphView$I$javax_swing_text_Position_Bias$java_awt_Shape', function (v, pos, bias, a) {
return null;
});

Clazz.newMethod$(C$, 'viewToModel$javax_swing_text_GlyphView$F$F$java_awt_Shape$javax_swing_text_Position_BiasA', function (v, x, y, a, biasReturn) {
return 0;
});

Clazz.newMethod$(C$, 'getBoundedPosition$javax_swing_text_GlyphView$I$F$F', function (v, p0, x, len) {
return 0;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
