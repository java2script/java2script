(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newClass$(P$, "CaretEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$O', function (source) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:53
