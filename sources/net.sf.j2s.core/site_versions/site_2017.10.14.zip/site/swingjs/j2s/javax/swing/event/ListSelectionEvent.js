(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "ListSelectionEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.firstIndex = 0;
this.lastIndex = 0;
this.isAdjusting = false;
}, 1);

Clazz.newMethod$(C$, 'c$$O$I$I$Z', function (source, firstIndex, lastIndex, isAdjusting) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.firstIndex = firstIndex;
this.lastIndex = lastIndex;
this.isAdjusting = isAdjusting;
}, 1);

Clazz.newMethod$(C$, 'getFirstIndex', function () {
return this.firstIndex;
});

Clazz.newMethod$(C$, 'getLastIndex', function () {
return this.lastIndex;
});

Clazz.newMethod$(C$, 'getValueIsAdjusting', function () {
return this.isAdjusting;
});

Clazz.newMethod$(C$, 'toString', function () {
var properties = " source=" + this.getSource() + " firstIndex= " + this.firstIndex + " lastIndex= " + this.lastIndex + " isAdjusting= " + this.isAdjusting + " " ;
return this.getClass().getName() + "[" + properties + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
