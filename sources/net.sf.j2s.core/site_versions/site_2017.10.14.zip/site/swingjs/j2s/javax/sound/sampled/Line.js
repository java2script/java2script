(function(){var P$=Clazz.newPackage$("javax.sound.sampled");
var C$=Clazz.newInterface$(P$, "Line", function(){
});

;
(function(){var C$=Clazz.newClass$(P$.Line, "Info", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.lineClass = null;
}, 1);

Clazz.newMethod$(C$, 'c$$Class', function (lineClass) {
C$.$init$.apply(this);
if (lineClass == null ) {
this.lineClass = Clazz.getClass(javax.sound.sampled.Line);
} else {
this.lineClass = lineClass;
}}, 1);

Clazz.newMethod$(C$, 'getLineClass', function () {
return this.lineClass;
});

Clazz.newMethod$(C$, 'matches$javax_sound_sampled_Line_Info', function (info) {
if (!(this.getClass().isInstance$O(info))) {
return false;
}if (!(this.getLineClass().isAssignableFrom$Class(info.getLineClass()))) {
return false;
}return true;
});

Clazz.newMethod$(C$, 'toString', function () {
var fullPackagePath = "javax.sound.sampled.";
var initialString =  String.instantialize(this.getLineClass().toString());
var finalString;
var index = initialString.indexOf(fullPackagePath);
if (index != -1) {
finalString = initialString.substring(0, index) + initialString.substring((index + fullPackagePath.length$()), initialString.length$());
} else {
finalString = initialString;
}return finalString;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:29
