(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JPasswordField", null, 'javax.swing.JTextField');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.echoChar = '\0';
this.echoCharSet = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, null, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, text, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (columns) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, null, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (text, columns) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, text, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document$S$I', function (doc, txt, columns) {
C$.superClazz.c$$javax_swing_text_Document$S$I.apply(this, [doc, txt, columns]);
C$.$init$.apply(this);
this.uiClassID = "PasswordFieldUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'updateUI', function () {
if (!this.echoCharSet) {
this.echoChar = '*';
}C$.superClazz.prototype.updateUI.apply(this, []);
});

Clazz.newMethod$(C$, 'getEchoChar', function () {
return this.echoChar;
});

Clazz.newMethod$(C$, 'setEchoChar$C', function (c) {
this.echoChar = c;
this.echoCharSet = true;
this.repaint();
this.revalidate();
});

Clazz.newMethod$(C$, 'echoCharIsSet', function () {
return this.echoChar.$c() != 0 ;
});

Clazz.newMethod$(C$, 'cut', function () {
});

Clazz.newMethod$(C$, 'copy', function () {
});

Clazz.newMethod$(C$, 'getText', function () {
return C$.superClazz.prototype.getText.apply(this, []);
});

Clazz.newMethod$(C$, 'getText$I$I', function (offs, len) {
return C$.superClazz.prototype.getText$I$I.apply(this, [offs, len]);
});

Clazz.newMethod$(C$, 'getPassword', function () {
var doc = this.getDocument();
var txt = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.text.Segment'))));
try {
doc.getText$I$I$javax_swing_text_Segment(0, doc.getLength(), txt);
} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
return null;
} else {
throw e;
}
}
var retValue =  Clazz.newArray$(Character.TYPE, [txt.count]);
System.arraycopy(txt.array, txt.offset, retValue, 0, txt.count);
return retValue;
});

Clazz.newMethod$(C$, 'paramString', function () {
return C$.superClazz.prototype.paramString.apply(this, []) + ",echoChar=" + this.echoChar ;
});

Clazz.newMethod$(C$, 'customSetUIProperty$S$O', function (propertyName, value) {
if (propertyName == "echoChar") {
if (!this.echoCharSet) {
this.setEchoChar$C((value).charValue());
this.echoCharSet = false;
}return true;
}return false;
});
})();
//Created 2017-10-14 13:31:41
