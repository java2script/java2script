(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JEditorPane", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.JTextComponent');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.kitRegistryKey =  new Clazz._O();
C$.kitTypeRegistryKey =  new Clazz._O();
C$.kitLoaderRegistryKey =  new Clazz._O();
C$.defaultEditorKitMap = Clazz.new((I$[11] || (I$[11]=Clazz.load('java.util.HashMap'))).c$$I,[0]);
};

C$.kitRegistryKey = null;
C$.kitTypeRegistryKey = null;
C$.kitLoaderRegistryKey = null;
C$.defaultEditorKitMap = null;

Clazz.newMethod$(C$, '$init$', function () {
this.loading = null;
this.kit = null;
this.isUserSetEditorKit = false;
this.pageProperties = null;
this.typeHandlers = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$S$S.apply(this, [null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_net_URL', function (initialPage) {
C$.c$$S$S.apply(this, [null, null]);
this.setPage$java_net_URL(initialPage);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (url) {
C$.c$$S$S.apply(this, [null, null]);
this.setPage$S(url);
}, 1);

Clazz.newMethod$(C$, 'c$$S$S', function (type, text) {
C$.c$$S$S$S.apply(this, [type, text, "EditorPaneUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$S$S', function (type, text, uid) {
C$.superClazz.c$$S.apply(this, [uid]);
C$.$init$.apply(this);
if (type != null ) this.setContentType$S(type);
if (text != null ) this.setText$S(text);
}, 1);

Clazz.newMethod$(C$, 'addHyperlinkListener$javax_swing_event_HyperlinkListener', function (listener) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.HyperlinkListener), listener);
});

Clazz.newMethod$(C$, 'removeHyperlinkListener$javax_swing_event_HyperlinkListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.HyperlinkListener), listener);
});

Clazz.newMethod$(C$, 'getHyperlinkListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.HyperlinkListener));
});

Clazz.newMethod$(C$, 'fireHyperlinkUpdate$javax_swing_event_HyperlinkEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.HyperlinkListener) ) {
(listeners[i + 1]).hyperlinkUpdate$javax_swing_event_HyperlinkEvent(e);
}}
});

Clazz.newMethod$(C$, 'setPage$java_net_URL', function (page) {
if (page == null ) {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["invalid url"]);
}var loaded = this.getPage();
if (!page.equals$O(loaded) && page.getRef() == null  ) {
this.scrollRectToVisible$java_awt_Rectangle(Clazz.new((I$[12] || (I$[12]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[0, 0, 1, 1]));
}var reloaded = false;
var postData = p$.getPostData.apply(this, []);
if ((loaded == null ) || !loaded.sameFile$java_net_URL(page) || (postData != null )  ) {
var p = p$.getAsynchronousLoadPriority$javax_swing_text_Document.apply(this, [this.getDocument()]);
if ((postData == null ) || (p < 0) ) {
var $in = this.getStream$java_net_URL(page);
if (this.kit != null ) {
var doc = this.initializeModel$javax_swing_text_EditorKit$java_net_URL(this.kit, page);
{
if (this.loading != null ) {
this.loading.cancel();
this.loading = null;
}}p = p$.getAsynchronousLoadPriority$javax_swing_text_Document.apply(this, [doc]);
if (p >= 0) {
this.setDocument$javax_swing_text_Document(doc);
{
this.loading = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JEditorPane').PageStream))).c$$java_io_InputStream,[$in]);
var pl = Clazz.new((I$[13] || (I$[13]=Clazz.load(Clazz.load('javax.swing.JEditorPane').PageLoader))).c$$javax_swing_text_Document$java_io_InputStream$I$java_net_URL$java_net_URL, [this, null, doc, this.loading, p, loaded, page]);
pl.start();
}return;
}this.read$java_io_InputStream$javax_swing_text_Document($in, doc);
this.setDocument$javax_swing_text_Document(doc);
reloaded = true;
}} else {
var pl = Clazz.new((I$[13] || (I$[13]=Clazz.load(Clazz.load('javax.swing.JEditorPane').PageLoader))).c$$javax_swing_text_Document$java_io_InputStream$I$java_net_URL$java_net_URL, [this, null, null, null, p, loaded, page]);
pl.start();
return;
}}var reference = page.getRef();
if (reference != null ) {
if (!reloaded) {
this.scrollToReference$S(reference);
} else {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "JEditorPane$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.b$['javax.swing.JEditorPane'].scrollToReference$S(this.$finals.reference);
});
})()
), Clazz.new((I$[14] || (I$[14]=Clazz.load(P$.JEditorPane$1))).$init$, [this, {reference: reference}])));
}this.getDocument().putProperty$O$O("stream", page);
}this.firePropertyChange$S$O$O("page", loaded, page);
});

Clazz.newMethod$(C$, 'initializeModel$javax_swing_text_EditorKit$java_net_URL', function (kit, page) {
var doc = kit.createDefaultDocument();
if (this.pageProperties != null ) {
for (var e = this.pageProperties.keys(); e.hasMoreElements(); ) {
var key = e.nextElement();
doc.putProperty$O$O(key, this.pageProperties.get$O(key));
}
this.pageProperties.clear();
}if (doc.getProperty$O("stream") == null ) {
doc.putProperty$O$O("stream", page);
}return doc;
});

Clazz.newMethod$(C$, 'getAsynchronousLoadPriority$javax_swing_text_Document', function (doc) {
return (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument") ? (doc).getAsynchronousLoadPriority() : -1);
});

Clazz.newMethod$(C$, 'read$java_io_InputStream$O', function ($in, desc) {
var charset = this.getClientProperty$O("charset");
var r = (charset != null ) ? Clazz.new((I$[15] || (I$[15]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream$S,[$in, charset]) : Clazz.new((I$[15] || (I$[15]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream,[$in]);
C$.superClazz.prototype.read$java_io_Reader$O.apply(this, [r, desc]);
});

Clazz.newMethod$(C$, 'read$java_io_InputStream$javax_swing_text_Document', function ($in, doc) {
if (!Boolean.TRUE.equals(doc.getProperty$O("IgnoreCharsetDirective"))) {
var READ_LIMIT = 10240;
$in = Clazz.new((I$[16] || (I$[16]=Clazz.load('java.io.BufferedInputStream'))).c$$java_io_InputStream$I,[$in, 10240]);
$in.mark$I(10240);
}try {
var charset = this.getClientProperty$O("charset");
var r = (charset != null ) ? Clazz.new((I$[15] || (I$[15]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream$S,[$in, charset]) : Clazz.new((I$[15] || (I$[15]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream,[$in]);
this.kit.read$java_io_Reader$javax_swing_text_Document$I(r, doc, 0);
} catch (e$$) {
if (Clazz.exceptionOf(e$$, P$.text.BadLocationException)){
var e = e$$;
{
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,[e.getMessage()]);
}
} else if (Clazz.exceptionOf(e$$, P$.text.ChangedCharSetException)){
var changedCharSetException = e$$;
{
var charSetSpec = changedCharSetException.getCharSetSpec();
if (changedCharSetException.keyEqualsCharSet()) {
this.putClientProperty$O$O("charset", charSetSpec);
} else {
p$.setCharsetFromContentTypeParameters$S.apply(this, [charSetSpec]);
}try {
$in.reset();
} catch (exception) {
if (Clazz.exceptionOf(exception, java.io.IOException)){
$in.close();
var url = doc.getProperty$O("stream");
if (url != null ) {
var conn = url.openConnection();
$in = conn.getInputStream();
} else {
throw changedCharSetException;
}} else {
throw exception;
}
}
try {
doc.remove$I$I(0, doc.getLength());
} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
} else {
throw e;
}
}
doc.putProperty$O$O("IgnoreCharsetDirective", (I$[17] || (I$[17]=Clazz.load('Boolean'))).$valueOf(true));
this.read$java_io_InputStream$javax_swing_text_Document($in, doc);
}
} else {
throw e$$;
}
}
});

Clazz.newMethod$(C$, 'getStream$java_net_URL', function (page) {
var conn = page.openConnection();
if ((I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread()) {
this.handleConnectionProperties$java_net_URLConnection(conn);
} else {
try {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeAndWait$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "JEditorPane$2", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.b$['javax.swing.JEditorPane'].handleConnectionProperties$java_net_URLConnection(this.$finals.conn);
});
})()
), Clazz.new((I$[18] || (I$[18]=Clazz.load(P$.JEditorPane$2))).$init$, [this, {conn: conn}])));
} catch (e$$) {
if (Clazz.exceptionOf(e$$, InterruptedException)){
var e = e$$;
{
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
}
} else if (Clazz.exceptionOf(e$$, java.lang.reflect.InvocationTargetException)){
var e = e$$;
{
throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$Throwable,[e]);
}
} else {
throw e$$;
}
}
}return conn.getInputStream();
});

Clazz.newMethod$(C$, 'handleConnectionProperties$java_net_URLConnection', function (conn) {
if (this.pageProperties == null ) {
this.pageProperties = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))));
}});

Clazz.newMethod$(C$, 'getPostData', function () {
return this.getDocument().getProperty$O("javax.swing.JEditorPane.postdata");
});

Clazz.newMethod$(C$, 'scrollToReference$S', function (reference) {
});

Clazz.newMethod$(C$, 'getPage', function () {
return this.getDocument().getProperty$O("stream");
});

Clazz.newMethod$(C$, 'setPage$S', function (url) {
if (url == null ) {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["invalid url"]);
}var page = Clazz.new((I$[20] || (I$[20]=Clazz.load('java.net.URL'))).c$$S,[url]);
this.setPage$java_net_URL(page);
});

Clazz.newMethod$(C$, 'createDefaultEditorKit', function () {
return Clazz.new((I$[21] || (I$[21]=Clazz.load(Clazz.load('javax.swing.JEditorPane').PlainEditorKit))));
});

Clazz.newMethod$(C$, 'getEditorKit', function () {
if (this.kit == null ) {
this.kit = this.createDefaultEditorKit();
this.isUserSetEditorKit = false;
}return this.kit;
});

Clazz.newMethod$(C$, 'getContentType', function () {
return (this.kit != null ) ? this.kit.getContentType() : null;
});

Clazz.newMethod$(C$, 'setContentType$S', function (type) {
var parm = type.indexOf(";");
if (parm > -1) {
var paramList = type.substring(parm);
type = type.substring(0, parm).trim();
if (type.toLowerCase().startsWith$S("text/")) {
p$.setCharsetFromContentTypeParameters$S.apply(this, [paramList]);
}}if ((this.kit == null ) || (!type.equals$O(this.kit.getContentType())) || !this.isUserSetEditorKit  ) {
var k = this.getEditorKitForContentType$S(type);
if (k != null  && k !== this.kit  ) {
this.setEditorKit$javax_swing_text_EditorKit(k);
this.isUserSetEditorKit = false;
}}});

Clazz.newMethod$(C$, 'setCharsetFromContentTypeParameters$S', function (paramlist) {
var charset = null;
try {
var semi = paramlist.indexOf(';'.$c());
if (semi > -1 && semi < paramlist.length$() - 1 ) {
paramlist = paramlist.substring(semi + 1);
}if (paramlist.length$() > 0) {
var hdrParser = Clazz.new((I$[22] || (I$[22]=Clazz.load(Clazz.load('javax.swing.JEditorPane').HeaderParser))).c$$S,[paramlist]);
charset = hdrParser.findValue$S("charset");
if (charset != null ) {
this.putClientProperty$O$O("charset", charset);
}}} catch (e$$) {
if (Clazz.exceptionOf(e$$, IndexOutOfBoundsException)){
var e = e$$;
{
}
} else if (Clazz.exceptionOf(e$$, NullPointerException)){
var e = e$$;
{
}
} else if (Clazz.exceptionOf(e$$, Exception)){
var e = e$$;
{
System.err.println$S("JEditorPane.getCharsetFromContentTypeParameters failed on: " + paramlist);
e.printStackTrace();
}
} else {
throw e$$;
}
}
});

Clazz.newMethod$(C$, 'setEditorKit$javax_swing_text_EditorKit', function (kit) {
var old = this.kit;
this.isUserSetEditorKit = true;
if (old != null ) {
old.deinstall$javax_swing_JEditorPane(this);
}this.kit = kit;
if (this.kit != null ) {
this.kit.install$javax_swing_JEditorPane(this);
this.setDocument$javax_swing_text_Document(this.kit.createDefaultDocument());
}this.firePropertyChange$S$O$O("editorKit", old, kit);
});

Clazz.newMethod$(C$, 'getEditorKitForContentType$S', function (type) {
if (this.typeHandlers == null ) {
this.typeHandlers = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))).c$$I,[3]);
}var k = this.typeHandlers.get$O(type);
if (k == null ) {
k = C$.createEditorKitForContentType$S(type);
if (k != null ) {
this.setEditorKitForContentType$S$javax_swing_text_EditorKit(type, k);
}}if (k == null ) {
k = this.createDefaultEditorKit();
}return k;
});

Clazz.newMethod$(C$, 'setEditorKitForContentType$S$javax_swing_text_EditorKit', function (type, k) {
if (this.typeHandlers == null ) {
this.typeHandlers = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))).c$$I,[3]);
}this.typeHandlers.put$TK$TV(type, k);
});

Clazz.newMethod$(C$, 'replaceSelection$S', function (content) {
if (!this.isEditable()) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
return;
}var kit = this.getEditorKit();
if (Clazz.instanceOf(kit, "javax.swing.text.StyledEditorKit")) {
try {
var doc = this.getDocument();
var caret = this.getCaret();
var p0 = Math.min(caret.getDot(), caret.getMark());
var p1 = Math.max(caret.getDot(), caret.getMark());
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).replace$I$I$S$javax_swing_text_AttributeSet(p0, p1 - p0, content, (kit).getInputAttributes());
} else {
if (p0 != p1) {
doc.remove$I$I(p0, p1 - p0);
}if (content != null  && content.length$() > 0 ) {
doc.insertString$I$S$javax_swing_text_AttributeSet(p0, content, (kit).getInputAttributes());
}}} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
} else {
throw e;
}
}
} else {
C$.superClazz.prototype.replaceSelection$S.apply(this, [content]);
}});

Clazz.newMethod$(C$, 'createEditorKitForContentType$S', function (type) {
var k = null;
var kitRegistry = C$.getKitRegisty();
k = kitRegistry.get$O(type);
if (k == null ) {
var classname = C$.getKitTypeRegistry().get$O(type);
try {
k = (I$[23] || (I$[23]=Clazz.load('swingjs.api.Interface'))).getInstance$S$Z(classname, false);
kitRegistry.put$TK$TV(type, k);
} catch (e) {
k = null;
}
}if (k != null ) {
return k.clone();
}return null;
}, 1);

Clazz.newMethod$(C$, 'registerEditorKitForContentType$S$S', function (type, classname) {
C$.registerEditorKitForContentType$S$S$ClassLoader(type, classname, null);
}, 1);

Clazz.newMethod$(C$, 'registerEditorKitForContentType$S$S$ClassLoader', function (type, classname, loader) {
C$.getKitTypeRegistry().put$TK$TV(type, classname);
C$.getKitRegisty().remove$O(type);
}, 1);

Clazz.newMethod$(C$, 'getEditorKitClassNameForContentType$S', function (type) {
return C$.getKitTypeRegistry().get$O(type);
}, 1);

Clazz.newMethod$(C$, 'getKitTypeRegistry', function () {
C$.loadDefaultKitsIfNecessary();
return (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.kitTypeRegistryKey);
}, 1);

Clazz.newMethod$(C$, 'getKitRegisty', function () {
var ht = (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.kitRegistryKey);
if (ht == null ) {
ht = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))).c$$I,[3]);
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.kitRegistryKey, ht);
}return ht;
}, 1);

Clazz.newMethod$(C$, 'loadDefaultKitsIfNecessary', function () {
if ((I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.kitTypeRegistryKey) == null ) {
{
if (C$.defaultEditorKitMap.size() == 0) {
C$.defaultEditorKitMap.put$TK$TV("text/plain", "javax.swing.JEditorPane$PlainEditorKit");
C$.defaultEditorKitMap.put$TK$TV("text/html", "javax.swing.JEditorPane$PlainEditorKit");
}}var ht = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))));
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.kitTypeRegistryKey, ht);
ht = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.util.Hashtable'))));
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.kitLoaderRegistryKey, ht);
for (var key, $key = C$.defaultEditorKitMap.keySet().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
C$.registerEditorKitForContentType$S$S(key, C$.defaultEditorKitMap.get$O(key));
}
}}, 1);

Clazz.newMethod$(C$, 'getPreferredSize', function () {
var d = this.getPrefSizeJComp();
if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
var port = this.getParent();
var ui = this.getUI();
var prefWidth = d.width;
var prefHeight = d.height;
if (!this.getScrollableTracksViewportWidth()) {
var w = port.getWidth();
var min = ui.getMinimumSize();
if (w != 0 && w < min.width ) {
prefWidth = min.width;
}}if (!this.getScrollableTracksViewportHeight()) {
var h = port.getHeight();
var min = ui.getMinimumSize();
if (h != 0 && h < min.height ) {
prefHeight = min.height;
}}if (prefWidth != d.width || prefHeight != d.height ) {
d = Clazz.new((I$[24] || (I$[24]=Clazz.load('java.awt.Dimension'))).c$$I$I,[prefWidth, prefHeight]);
}}return d;
});

Clazz.newMethod$(C$, 'setText$S', function (t) {
try {
var doc = this.getDocument();
doc.remove$I$I(0, doc.getLength());
if (t == null  || t.equals$O("") ) {
return;
}var r = Clazz.new((I$[25] || (I$[25]=Clazz.load('java.io.StringReader'))).c$$S,[t]);
var kit = this.getEditorKit();
kit.read$java_io_Reader$javax_swing_text_Document$I(r, doc, 0);
} catch (e$$) {
if (Clazz.exceptionOf(e$$, java.io.IOException)){
var ioe = e$$;
{
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
}
} else if (Clazz.exceptionOf(e$$, P$.text.BadLocationException)){
var ble = e$$;
{
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
}
} else {
throw e$$;
}
}
});

Clazz.newMethod$(C$, 'getText', function () {
var doc = this.getDocument();
try {
return doc.getText$I$I(0, doc.getLength());
} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
return null;
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportWidth', function () {
if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
var port = this.getParent();
var ui = this.getUI();
var w = port.getWidth();
var min = ui.getMinimumSize();
var max = ui.getMaximumSize();
if ((w >= min.width) && (w <= max.width) ) {
return true;
}}return false;
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportHeight', function () {
if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
var port = this.getParent();
var ui = this.getUI();
var h = port.getHeight();
var min = ui.getMinimumSize();
if (h >= min.height) {
var max = ui.getMaximumSize();
if (h <= max.height) {
return true;
}}}return false;
});

Clazz.newMethod$(C$, 'paramString', function () {
var kitString = (this.kit != null  ? this.kit.toString() : "");
var typeHandlersString = (this.typeHandlers != null  ? this.typeHandlers.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",kit=" + kitString + ",typeHandlers=" + typeHandlersString ;
});
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane, "PageLoader", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'Thread');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.pageLoaded = false;
this.$in = null;
this.old = null;
this.page = null;
this.doc = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document$java_io_InputStream$I$java_net_URL$java_net_URL', function (doc, $in, priority, old, page) {
Clazz.super(C$, this,1);
this.setPriority$I(priority);
this.$in = $in;
this.old = old;
this.page = page;
this.doc = doc;
}, 1);

Clazz.newMethod$(C$, 'run', function () {
try {
if (this.$in == null ) {
this.$in = this.b$['javax.swing.JEditorPane'].getStream$java_net_URL(this.page);
if (this.b$['javax.swing.JEditorPane'].kit == null ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this.b$['javax.swing.JEditorPane']);
return;
}{
this.$in = this.b$['javax.swing.JEditorPane'].loading = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JEditorPane').PageStream))).c$$java_io_InputStream,[this.$in]);
}}if (this.doc == null ) {
try {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeAndWait$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "JEditorPane$PageLoader$2", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.b$['javax.swing.JEditorPane.PageLoader'].doc = this.b$['javax.swing.JEditorPane'].initializeModel$javax_swing_text_EditorKit$java_net_URL(this.b$['javax.swing.JEditorPane'].kit, this.b$['javax.swing.JEditorPane.PageLoader'].page);
this.b$['javax.swing.JEditorPane'].setDocument$javax_swing_text_Document(this.b$['javax.swing.JEditorPane.PageLoader'].doc);
});
})()
), Clazz.new((I$[3] || (I$[3]=Clazz.load(P$.JEditorPane$PageLoader$2))).$init$, [this, null])));
} catch (e$$) {
if (Clazz.exceptionOf(e$$, java.lang.reflect.InvocationTargetException)){
var ex = e$$;
{
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this.b$['javax.swing.JEditorPane']);
return;
}
} else if (Clazz.exceptionOf(e$$, InterruptedException)){
var ex = e$$;
{
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this.b$['javax.swing.JEditorPane']);
return;
}
} else {
throw e$$;
}
}
}this.b$['javax.swing.JEditorPane'].read$java_io_InputStream$javax_swing_text_Document(this.$in, this.doc);
var page = this.doc.getProperty$O("stream");
var reference = page.getRef();
if (reference != null ) {
var callScrollToReference = ((
(function(){var C$=Clazz.newClass$(P$, "JEditorPane$PageLoader$3", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
var u = this.b$['javax.swing.JEditorPane'].getDocument().getProperty$O("stream");
var ref = u.getRef();
this.b$['javax.swing.JEditorPane'].scrollToReference$S(ref);
});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load(P$.JEditorPane$PageLoader$3))).$init$, [this, null]));
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(callScrollToReference);
}this.pageLoaded = true;
} catch (ioe) {
if (Clazz.exceptionOf(ioe, java.io.IOException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this.b$['javax.swing.JEditorPane']);
} else {
throw ioe;
}
} finally {
{
this.b$['javax.swing.JEditorPane'].loading = null;
}(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "JEditorPane$PageLoader$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
if (this.b$['javax.swing.JEditorPane.PageLoader'].pageLoaded) {
this.b$['javax.swing.JEditorPane'].firePropertyChange$S$O$O("page", this.b$['javax.swing.JEditorPane.PageLoader'].old, this.b$['javax.swing.JEditorPane.PageLoader'].page);
}});
})()
), Clazz.new((I$[5] || (I$[5]=Clazz.load(P$.JEditorPane$PageLoader$1))).$init$, [this, null])));
}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane, "PageStream", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'java.io.FilterInputStream');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.canceled = false;
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_InputStream', function (i) {
C$.superClazz.c$$java_io_InputStream.apply(this, [i]);
C$.$init$.apply(this);
this.canceled = false;
}, 1);

Clazz.newMethod$(C$, 'cancel', function () {
this.canceled = true;
});

Clazz.newMethod$(C$, 'checkCanceled', function () {
if (this.canceled) {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["page canceled"]);
}});

Clazz.newMethod$(C$, 'read', function () {
this.checkCanceled();
return C$.superClazz.prototype.read.apply(this, []);
});

Clazz.newMethod$(C$, 'skip$J', function (n) {
this.checkCanceled();
return C$.superClazz.prototype.skip$J.apply(this, [n]);
});

Clazz.newMethod$(C$, 'available', function () {
this.checkCanceled();
return C$.superClazz.prototype.available.apply(this, []);
});

Clazz.newMethod$(C$, 'reset', function () {
this.checkCanceled();
C$.superClazz.prototype.reset.apply(this, []);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane, "PlainEditorKit", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.DefaultEditorKit', 'javax.swing.text.ViewFactory');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getViewFactory', function () {
return this;
});

Clazz.newMethod$(C$, 'create$javax_swing_text_Element', function (elem) {
return Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.text.WrappedPlainView'))).c$$javax_swing_text_Element,[elem]);
});

Clazz.newMethod$(C$, 'createI18N$javax_swing_text_Element', function (elem) {
var kind = elem.getName();
if (kind != null ) {
if (kind.equals$O("content")) {
return Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load(Clazz.load('javax.swing.JEditorPane').PlainEditorKit).PlainParagraph))).c$$javax_swing_text_Element,[elem]);
} else if (kind.equals$O("paragraph")) {
return Clazz.new((I$[10] || (I$[10]=Clazz.load('javax.swing.text.BoxView'))).c$$javax_swing_text_Element$I,[elem, 1]);
}}return null;
});
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane.PlainEditorKit, "PlainParagraph", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.ParagraphView');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.superClazz.c$$javax_swing_text_Element.apply(this, [elem]);
C$.$init$.apply(this);
this.layoutPool = Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load(Clazz.load(Clazz.load('javax.swing.JEditorPane').PlainEditorKit).PlainParagraph).LogicalView))).c$$javax_swing_text_Element,[elem]);
this.layoutPool.setParent$javax_swing_text_View(this);
}, 1);

Clazz.newMethod$(C$, 'setPropertiesFromAttributes', function () {
var c = this.getContainer();
if ((c != null ) && (!c.getComponentOrientation().isLeftToRight()) ) {
this.setJustification$I(2);
} else {
this.setJustification$I(0);
}});

Clazz.newMethod$(C$, 'getFlowSpan$I', function (index) {
var c = this.getContainer();
if (Clazz.instanceOf(c, "javax.swing.JTextArea")) {
var area = c;
if (!area.getLineWrap()) {
return 2147483647;
}}return C$.superClazz.prototype.getFlowSpan$I.apply(this, [index]);
});

Clazz.newMethod$(C$, 'calculateMinorAxisRequirements$I$javax_swing_SizeRequirements', function (axis, r) {
var req = C$.superClazz.prototype.calculateMinorAxisRequirements$I$javax_swing_SizeRequirements.apply(this, [axis, r]);
var c = this.getContainer();
if (Clazz.instanceOf(c, "javax.swing.JTextArea")) {
var area = c;
if (!area.getLineWrap()) {
req.minimum = req.preferred;
}}return req;
});
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane.PlainEditorKit.PlainParagraph, "LogicalView", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.CompositeView');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.superClazz.c$$javax_swing_text_Element.apply(this, [elem]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getViewIndexAtPosition$I', function (pos) {
var elem = this.getElement();
if (elem.getElementCount() > 0) {
return elem.getElementIndex$I(pos);
}return 0;
});

Clazz.newMethod$(C$, 'updateChildren$javax_swing_event_DocumentEvent_ElementChange$javax_swing_event_DocumentEvent$javax_swing_text_ViewFactory', function (ec, e, f) {
return false;
});

Clazz.newMethod$(C$, 'loadChildren$javax_swing_text_ViewFactory', function (f) {
});

Clazz.newMethod$(C$, 'getPreferredSpan$I', function (axis) {
if (this.getViewCount() != 1) throw Clazz.new((I$[6] || (I$[6]=Clazz.load('java.lang.Error'))).c$$S,["One child view is assumed."]);
var v = this.getView$I(0);
return v.getPreferredSpan$I(axis);
});

Clazz.newMethod$(C$, 'forwardUpdateToView$javax_swing_text_View$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (v, e, a, f) {
v.setParent$javax_swing_text_View(this);
C$.superClazz.prototype.forwardUpdateToView$javax_swing_text_View$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory.apply(this, [v, e, a, f]);
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics$java_awt_Shape', function (g, allocation) {
});

Clazz.newMethod$(C$, 'isBefore$I$I$java_awt_Rectangle', function (x, y, alloc) {
return false;
});

Clazz.newMethod$(C$, 'isAfter$I$I$java_awt_Rectangle', function (x, y, alloc) {
return false;
});

Clazz.newMethod$(C$, 'getViewAtPoint$I$I$java_awt_Rectangle', function (x, y, alloc) {
return null;
});

Clazz.newMethod$(C$, 'childAllocation$I$java_awt_Rectangle', function (index, a) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JEditorPane, "HeaderParser", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.raw = null;
this.tab = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (raw) {
C$.$init$.apply(this);
this.raw = raw;
this.tab =  Clazz.newArray$(java.lang.String, [10, 2]);
p$.parse.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'parse', function () {
if (this.raw != null ) {
this.raw = this.raw.trim();
var ca = this.raw.toCharArray();
var beg = 0;
var end = 0;
var i = 0;
var inKey = true;
var inQuote = false;
var len = ca.length;
while (end < len){
var c = ca[end];
if (c == '=') {
this.tab[i][0] =  String.instantialize(ca, beg, end - beg).toLowerCase();
inKey = false;
end++;
beg = end;
} else if (c == '\"') {
if (inQuote) {
this.tab[i++][1] =  String.instantialize(ca, beg, end - beg);
inQuote = false;
do {
end++;
} while (end < len && (ca[end] == ' ' || ca[end] == ',' ) );
inKey = true;
beg = end;
} else {
inQuote = true;
end++;
beg = end;
}} else if (c == ' ' || c == ',' ) {
if (inQuote) {
end++;
continue;
} else if (inKey) {
this.tab[i++][0] = ( String.instantialize(ca, beg, end - beg)).toLowerCase();
} else {
this.tab[i++][1] = ( String.instantialize(ca, beg, end - beg));
}while (end < len && (ca[end] == ' ' || ca[end] == ',' ) ){
end++;
}
inKey = true;
beg = end;
} else {
end++;
}}
if (--end > beg) {
if (!inKey) {
if (ca[end] == '\"') {
this.tab[i++][1] = ( String.instantialize(ca, beg, end - beg));
} else {
this.tab[i++][1] = ( String.instantialize(ca, beg, end - beg + 1));
}} else {
this.tab[i][0] = ( String.instantialize(ca, beg, end - beg + 1)).toLowerCase();
}} else if (end == beg) {
if (!inKey) {
if (ca[end] == '\"') {
this.tab[i++][1] = String.valueOf(ca[end - 1]);
} else {
this.tab[i++][1] = String.valueOf(ca[end]);
}} else {
this.tab[i][0] = String.valueOf(ca[end]).toLowerCase();
}}}});

Clazz.newMethod$(C$, 'findKey$I', function (i) {
if (i < 0 || i > 10 ) return null;
return this.tab[i][0];
});

Clazz.newMethod$(C$, 'findValue$I', function (i) {
if (i < 0 || i > 10 ) return null;
return this.tab[i][1];
});

Clazz.newMethod$(C$, 'findValue$S', function (key) {
return this.findValue$S$S(key, null);
});

Clazz.newMethod$(C$, 'findValue$S$S', function (k, Default) {
if (k == null ) return Default;
k = k.toLowerCase();
for (var i = 0; i < 10; ++i) {
if (this.tab[i][0] == null ) {
return Default;
} else if (k.equals$O(this.tab[i][0])) {
return this.tab[i][1];
}}
return Default;
});

Clazz.newMethod$(C$, 'findInt$S$I', function (k, Default) {
try {
return Integer.parseInt(this.findValue$S$S(k, String.valueOf(Default)));
} catch (t) {
return Default;
}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:37
