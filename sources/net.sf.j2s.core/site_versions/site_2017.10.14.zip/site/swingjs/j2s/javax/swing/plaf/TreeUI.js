(function(){var P$=Clazz.newPackage$("javax.swing.plaf");
var C$=Clazz.newClass$(P$, "TreeUI", null, 'javax.swing.plaf.ComponentUI');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:58
