(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JMenuItem", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.AbstractButton', 'javax.swing.MenuElement');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.isMouseDragged = false;
this.accelerator = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [null, null, -2147483648, "MenuItemUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Icon', function (icon) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [null, icon, -2147483648, "MenuItemUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [text, null, -2147483648, "MenuItemUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Action', function (a) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [null, null, -2147483648, "MenuItemUI"]);
this.setAction$javax_swing_Action(a);
}, 1);

Clazz.newMethod$(C$, 'c$$S$javax_swing_Icon', function (text, icon) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [text, icon, -2147483648, "MenuItemUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (text, mnemonic) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [text, null, mnemonic, "MenuItemUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$javax_swing_Icon$S', function (text, icon, uid) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [text, icon, 0, uid]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$javax_swing_Icon$I$S', function (text, icon, mnemonic, uid) {
Clazz.super(C$, this,1);
p$.init0$S$javax_swing_Icon$I$S.apply(this, [text, icon, mnemonic, uid]);
}, 1);

Clazz.newMethod$(C$, 'init0$S$javax_swing_Icon$I$S', function (text, icon, mnemonic, uid) {
this.setModel$javax_swing_ButtonModel(Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.DefaultButtonModel')))));
this.init$S$javax_swing_Icon$S(text, icon, uid);
if (mnemonic >= 0) this.setMnemonic$I(mnemonic);
this.initFocusability();
});

Clazz.newMethod$(C$, 'init$S$javax_swing_Icon$S', function (text, icon, uid) {
this.uiClassID = uid;
this.updateUI();
if (text != null ) this.setText$S(text);
if (icon != null ) this.setIcon$javax_swing_Icon(icon);
this.addFocusListener$java_awt_event_FocusListener(Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JMenuItem').MenuItemFocusListener)))));
this.setUIProperty$S$O("borderPainted", Boolean.FALSE);
this.setOpaque$Z(true);
this.setFocusPainted$Z(false);
this.setHorizontalTextPosition$I(11);
this.setHorizontalAlignment$I(10);
});

Clazz.newMethod$(C$, 'setModel$javax_swing_ButtonModel', function (newModel) {
C$.superClazz.prototype.setModel$javax_swing_ButtonModel.apply(this, [newModel]);
if (Clazz.instanceOf(newModel, "javax.swing.DefaultButtonModel")) {
(newModel).setMenuItem$Z(true);
}});

Clazz.newMethod$(C$, 'initFocusability', function () {
this.setFocusable$Z(false);
});

Clazz.newMethod$(C$, 'setArmed$Z', function (b) {
var model = this.getModel();
if (model.isArmed() != b ) {
model.setArmed$Z(b);
}});

Clazz.newMethod$(C$, 'isArmed', function () {
var model = this.getModel();
return model.isArmed();
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (b) {
if (!b && !(I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getBoolean$O("MenuItem.disabledAreNavigable") ) {
this.setArmed$Z(false);
}C$.superClazz.prototype.setEnabled$Z.apply(this, [b]);
});

Clazz.newMethod$(C$, 'alwaysOnTop', function () {
return true;
});

Clazz.newMethod$(C$, 'setAccelerator$javax_swing_KeyStroke', function (keyStroke) {
var oldAccelerator = this.accelerator;
this.accelerator = keyStroke;
this.repaint();
this.revalidate();
this.firePropertyChange$S$O$O("accelerator", oldAccelerator, this.accelerator);
});

Clazz.newMethod$(C$, 'getAccelerator', function () {
return this.accelerator;
});

Clazz.newMethod$(C$, 'configurePropertiesFromAction$javax_swing_Action', function (a) {
C$.superClazz.prototype.configurePropertiesFromAction$javax_swing_Action.apply(this, [a]);
this.configureAcceleratorFromAction$javax_swing_Action(a);
});

Clazz.newMethod$(C$, 'setIconFromAction$javax_swing_Action', function (a) {
var icon = null;
if (a != null ) {
icon = a.getValue$S("SmallIcon");
}this.setIcon$javax_swing_Icon(icon);
});

Clazz.newMethod$(C$, 'largeIconChanged$javax_swing_Action', function (a) {
});

Clazz.newMethod$(C$, 'smallIconChanged$javax_swing_Action', function (a) {
this.setIconFromAction$javax_swing_Action(a);
});

Clazz.newMethod$(C$, 'configureAcceleratorFromAction$javax_swing_Action', function (a) {
var ks = (a == null ) ? null : a.getValue$S("AcceleratorKey");
this.setAccelerator$javax_swing_KeyStroke(ks);
});

Clazz.newMethod$(C$, 'actionPropertyChanged$javax_swing_Action$S', function (action, propertyName) {
if (propertyName == "AcceleratorKey") {
this.configureAcceleratorFromAction$javax_swing_Action(action);
} else {
C$.superClazz.prototype.actionPropertyChanged$javax_swing_Action$S.apply(this, [action, propertyName]);
}});

Clazz.newMethod$(C$, 'processMouseEvent$java_awt_event_MouseEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (e, path, manager) {
this.processMenuDragMouseEvent$javax_swing_event_MenuDragMouseEvent(Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.event.MenuDragMouseEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$javax_swing_MenuElementA$javax_swing_MenuSelectionManager,[e.getComponent(), e.getID(), e.getWhen(), e.getModifiers(), e.getX(), e.getY(), e.getXOnScreen(), e.getYOnScreen(), e.getClickCount(), e.isPopupTrigger(), path, manager]));
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (e, path, manager) {
var mke = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.event.MenuKeyEvent'))).c$$java_awt_Component$I$J$I$I$C$javax_swing_MenuElementA$javax_swing_MenuSelectionManager,[e.getComponent(), e.getID(), e.getWhen(), e.getModifiers(), e.getKeyCode(), e.getKeyChar(), path, manager]);
this.processMenuKeyEvent$javax_swing_event_MenuKeyEvent(mke);
if (mke.isConsumed()) {
e.consume();
}});

Clazz.newMethod$(C$, 'processMenuDragMouseEvent$javax_swing_event_MenuDragMouseEvent', function (e) {
switch (e.getID()) {
case 504:
this.isMouseDragged = false;
this.fireMenuDragMouseEntered$javax_swing_event_MenuDragMouseEvent(e);
break;
case 505:
this.isMouseDragged = false;
this.fireMenuDragMouseExited$javax_swing_event_MenuDragMouseEvent(e);
break;
case 506:
this.isMouseDragged = true;
this.fireMenuDragMouseDragged$javax_swing_event_MenuDragMouseEvent(e);
break;
case 502:
if (this.isMouseDragged) this.fireMenuDragMouseReleased$javax_swing_event_MenuDragMouseEvent(e);
break;
default:
break;
}
});

Clazz.newMethod$(C$, 'processMenuKeyEvent$javax_swing_event_MenuKeyEvent', function (e) {
switch (e.getID()) {
case 401:
this.fireMenuKeyPressed$javax_swing_event_MenuKeyEvent(e);
break;
case 402:
this.fireMenuKeyReleased$javax_swing_event_MenuKeyEvent(e);
break;
case 400:
this.fireMenuKeyTyped$javax_swing_event_MenuKeyEvent(e);
break;
default:
break;
}
});

Clazz.newMethod$(C$, 'fireMenuDragMouseEntered$javax_swing_event_MenuDragMouseEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuDragMouseListener) ) {
(listeners[i + 1]).menuDragMouseEntered$javax_swing_event_MenuDragMouseEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuDragMouseExited$javax_swing_event_MenuDragMouseEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuDragMouseListener) ) {
(listeners[i + 1]).menuDragMouseExited$javax_swing_event_MenuDragMouseEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuDragMouseDragged$javax_swing_event_MenuDragMouseEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuDragMouseListener) ) {
(listeners[i + 1]).menuDragMouseDragged$javax_swing_event_MenuDragMouseEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuDragMouseReleased$javax_swing_event_MenuDragMouseEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuDragMouseListener) ) {
(listeners[i + 1]).menuDragMouseReleased$javax_swing_event_MenuDragMouseEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuKeyPressed$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyPressed$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuKeyReleased$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyReleased$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuKeyTyped$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyTyped$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'menuSelectionChanged$Z', function (isIncluded) {
this.setArmed$Z(isIncluded);
});

Clazz.newMethod$(C$, 'getSubElements', function () {
return  Clazz.newArray$(javax.swing.MenuElement, [0]);
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this;
});

Clazz.newMethod$(C$, 'addMenuDragMouseListener$javax_swing_event_MenuDragMouseListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.MenuDragMouseListener), l);
});

Clazz.newMethod$(C$, 'removeMenuDragMouseListener$javax_swing_event_MenuDragMouseListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.MenuDragMouseListener), l);
});

Clazz.newMethod$(C$, 'getMenuDragMouseListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.MenuDragMouseListener));
});

Clazz.newMethod$(C$, 'addMenuKeyListener$javax_swing_event_MenuKeyListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.MenuKeyListener), l);
});

Clazz.newMethod$(C$, 'removeMenuKeyListener$javax_swing_event_MenuKeyListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.MenuKeyListener), l);
});

Clazz.newMethod$(C$, 'getMenuKeyListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.MenuKeyListener));
});

Clazz.newMethod$(C$, 'paramString', function () {
return C$.superClazz.prototype.paramString.apply(this, []);
});
;
(function(){var C$=Clazz.newClass$(P$.JMenuItem, "MenuItemFocusListener", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'java.awt.event.FocusListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'focusGained$java_awt_event_FocusEvent', function (event) {
});

Clazz.newMethod$(C$, 'focusLost$java_awt_event_FocusEvent', function (event) {
var mi = event.getSource();
if (mi.isFocusPainted()) {
mi.repaint();
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:40
