(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JList", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.Scrollable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.fixedCellWidth = -1;
this.fixedCellHeight = -1;
this.horizontalScrollIncrement = -1;
this.prototypeCellValue = null;
this.visibleRowCount = 8;
this.selectionForeground = null;
this.selectionBackground = null;
this.dragEnabled = false;
this.selectionModel = null;
this.dataModel = null;
this.cellRenderer = null;
this.selectionListener = null;
this.layoutOrientation = 0;
this.dropMode = (I$[1] || (I$[1]=Clazz.load('javax.swing.DropMode'))).USE_SELECTION;
this.dropLocation = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_ListModel', function (dataModel) {
Clazz.super(C$, this,1);
if (dataModel == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["dataModel must be non null"]);
}this.layoutOrientation = 0;
this.dataModel = dataModel;
this.selectionModel = this.createSelectionModel();
this.setAutoscrolls$Z(true);
this.setOpaque$Z(true);
this.uiClassID = "ListUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'c$$OA', function (listData) {
C$.c$$javax_swing_ListModel.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "JList$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractListModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return this.$finals.listData.length;
});

Clazz.newMethod$(C$, 'getElementAt$I', function (i) {
return this.$finals.listData[i];
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.AbstractListModel'))), [this, {listData: listData}],P$.JList$1))]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Vector', function (listData) {
C$.c$$javax_swing_ListModel.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "JList$2", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractListModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return this.$finals.listData.size();
});

Clazz.newMethod$(C$, 'getElementAt$I', function (i) {
return this.$finals.listData.elementAt$I(i);
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.AbstractListModel'))), [this, {listData: listData}],P$.JList$2))]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_ListModel.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "JList$3", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractListModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return 0;
});

Clazz.newMethod$(C$, 'getElementAt$I', function (i) {
return "No Data Model";
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.AbstractListModel'))), [this, null],P$.JList$3))]);
}, 1);

Clazz.newMethod$(C$, 'updateUI', function () {
C$.superClazz.prototype.updateUI.apply(this, []);
var renderer = this.getCellRenderer();
if (Clazz.instanceOf(renderer, "java.awt.Component")) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).updateComponentTreeUI$java_awt_Component(renderer);
}});

Clazz.newMethod$(C$, 'updateFixedCellSize', function () {
var cr = this.getCellRenderer();
var value = this.getPrototypeCellValue();
if ((cr != null ) && (value != null ) ) {
var c = cr.getListCellRendererComponent$javax_swing_JList$O$I$Z$Z(this, value, 0, false, false);
var f = c.getFont();
c.setFont$java_awt_Font(this.getFont());
var d = c.getPreferredSize();
this.fixedCellWidth = d.width;
this.fixedCellHeight = d.height;
c.setFont$java_awt_Font(f);
}});

Clazz.newMethod$(C$, 'getPrototypeCellValue', function () {
return this.prototypeCellValue;
});

Clazz.newMethod$(C$, 'setPrototypeCellValue$O', function (prototypeCellValue) {
var oldValue = this.prototypeCellValue;
this.prototypeCellValue = prototypeCellValue;
if ((prototypeCellValue != null ) && !prototypeCellValue.equals$O(oldValue) ) {
p$.updateFixedCellSize.apply(this, []);
}this.firePropertyChange$S$O$O("prototypeCellValue", oldValue, prototypeCellValue);
});

Clazz.newMethod$(C$, 'getFixedCellWidth', function () {
return this.fixedCellWidth;
});

Clazz.newMethod$(C$, 'setFixedCellWidth$I', function (width) {
var oldValue = this.fixedCellWidth;
this.fixedCellWidth = width;
this.firePropertyChange$S$I$I("fixedCellWidth", oldValue, this.fixedCellWidth);
});

Clazz.newMethod$(C$, 'getFixedCellHeight', function () {
return this.fixedCellHeight;
});

Clazz.newMethod$(C$, 'setFixedCellHeight$I', function (height) {
var oldValue = this.fixedCellHeight;
this.fixedCellHeight = height;
this.firePropertyChange$S$I$I("fixedCellHeight", oldValue, this.fixedCellHeight);
});

Clazz.newMethod$(C$, 'getCellRenderer', function () {
return this.cellRenderer;
});

Clazz.newMethod$(C$, 'setCellRenderer$javax_swing_ListCellRenderer', function (cellRenderer) {
var oldValue = this.cellRenderer;
this.cellRenderer = cellRenderer;
if ((cellRenderer != null ) && !cellRenderer.equals$O(oldValue) ) {
p$.updateFixedCellSize.apply(this, []);
}this.firePropertyChange$S$O$O("cellRenderer", oldValue, cellRenderer);
});

Clazz.newMethod$(C$, 'getSelectionForeground', function () {
return this.selectionForeground;
});

Clazz.newMethod$(C$, 'setSelectionForeground$java_awt_Color', function (selectionForeground) {
var oldValue = this.selectionForeground;
this.selectionForeground = selectionForeground;
this.firePropertyChange$S$O$O("selectionForeground", oldValue, selectionForeground);
});

Clazz.newMethod$(C$, 'getSelectionBackground', function () {
return this.selectionBackground;
});

Clazz.newMethod$(C$, 'setSelectionBackground$java_awt_Color', function (selectionBackground) {
var oldValue = this.selectionBackground;
this.selectionBackground = selectionBackground;
this.firePropertyChange$S$O$O("selectionBackground", oldValue, selectionBackground);
});

Clazz.newMethod$(C$, 'getVisibleRowCount', function () {
return this.visibleRowCount;
});

Clazz.newMethod$(C$, 'setVisibleRowCount$I', function (visibleRowCount) {
var oldValue = this.visibleRowCount;
this.visibleRowCount = Math.max(0, visibleRowCount);
this.firePropertyChange$S$I$I("visibleRowCount", oldValue, visibleRowCount);
});

Clazz.newMethod$(C$, 'getLayoutOrientation', function () {
return this.layoutOrientation;
});

Clazz.newMethod$(C$, 'setLayoutOrientation$I', function (layoutOrientation) {
var oldValue = this.layoutOrientation;
switch (layoutOrientation) {
case 0:
case 1:
case 2:
this.layoutOrientation = layoutOrientation;
this.firePropertyChange$S$I$I("layoutOrientation", oldValue, layoutOrientation);
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["layoutOrientation must be one of: VERTICAL, HORIZONTAL_WRAP or VERTICAL_WRAP"]);
}
});

Clazz.newMethod$(C$, 'getFirstVisibleIndex', function () {
var r = this.getVisibleRect();
var first;
if (this.getComponentOrientation().isLeftToRight()) {
first = this.locationToIndex$java_awt_Point(r.getLocation());
} else {
first = this.locationToIndex$java_awt_Point(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[(r.x + r.width) - 1, r.y]));
}if (first != -1) {
var bounds = this.getCellBounds$I$I(first, first);
if (bounds != null ) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).computeIntersection$I$I$I$I$java_awt_Rectangle(r.x, r.y, r.width, r.height, bounds);
if (bounds.width == 0 || bounds.height == 0 ) {
first = -1;
}}}return first;
});

Clazz.newMethod$(C$, 'getLastVisibleIndex', function () {
var leftToRight = this.getComponentOrientation().isLeftToRight();
var r = this.getVisibleRect();
var lastPoint;
if (leftToRight) {
lastPoint = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[(r.x + r.width) - 1, (r.y + r.height) - 1]);
} else {
lastPoint = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[r.x, (r.y + r.height) - 1]);
}var location = this.locationToIndex$java_awt_Point(lastPoint);
if (location != -1) {
var bounds = this.getCellBounds$I$I(location, location);
if (bounds != null ) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).computeIntersection$I$I$I$I$java_awt_Rectangle(r.x, r.y, r.width, r.height, bounds);
if (bounds.width == 0 || bounds.height == 0 ) {
var isHorizontalWrap = (this.getLayoutOrientation() == 2);
var visibleLocation = isHorizontalWrap ? Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[lastPoint.x, r.y]) : Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[r.x, lastPoint.y]);
var last;
var visIndex = -1;
var lIndex = location;
location = -1;
do {
last = visIndex;
visIndex = this.locationToIndex$java_awt_Point(visibleLocation);
if (visIndex != -1) {
bounds = this.getCellBounds$I$I(visIndex, visIndex);
if (visIndex != lIndex && bounds != null   && bounds.contains$java_awt_Point(visibleLocation) ) {
location = visIndex;
if (isHorizontalWrap) {
visibleLocation.y = bounds.y + bounds.height;
if (visibleLocation.y >= lastPoint.y) {
last = visIndex;
}} else {
visibleLocation.x = bounds.x + bounds.width;
if (visibleLocation.x >= lastPoint.x) {
last = visIndex;
}}} else {
last = visIndex;
}}} while (visIndex != -1 && last != visIndex );
}}}return location;
});

Clazz.newMethod$(C$, 'ensureIndexIsVisible$I', function (index) {
var cellBounds = this.getCellBounds$I$I(index, index);
if (cellBounds != null ) {
this.scrollRectToVisible$java_awt_Rectangle(cellBounds);
}});

Clazz.newMethod$(C$, 'setDragEnabled$Z', function (b) {
this.dragEnabled = b;
});

Clazz.newMethod$(C$, 'getDragEnabled', function () {
return this.dragEnabled;
});

Clazz.newMethod$(C$, 'setDropMode$javax_swing_DropMode', function (dropMode) {
if (dropMode != null ) {
switch (dropMode) {
case P$.DropMode.USE_SELECTION:
case P$.DropMode.ON:
case P$.DropMode.INSERT:
case P$.DropMode.ON_OR_INSERT:
this.dropMode = dropMode;
return;
}
}throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[dropMode + ": Unsupported drop mode for list"]);
});

Clazz.newMethod$(C$, 'getNextMatch$S$I$javax_swing_text_Position_Bias', function (prefix, startIndex, bias) {
var model = this.getModel();
var max = model.getSize();
if (prefix == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException'));
}if (startIndex < 0 || startIndex >= max ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException'));
}prefix = prefix.toUpperCase();
var increment = (bias === (I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward ) ? 1 : -1;
var index = startIndex;
do {
var o = model.getElementAt$I(index);
if (o != null ) {
var string;
if (Clazz.instanceOf(o, "java.lang.String")) {
string = (o).toUpperCase();
} else {
string = o.toString();
if (string != null ) {
string = string.toUpperCase();
}}if (string != null  && string.startsWith$S(prefix) ) {
return index;
}}index = (index + increment + max ) % max;
} while (index != startIndex);
return -1;
});

Clazz.newMethod$(C$, 'getToolTipText$java_awt_event_MouseEvent', function (event) {
if (event != null ) {
var p = event.getPoint();
var index = this.locationToIndex$java_awt_Point(p);
var r = this.getCellRenderer();
var cellBounds;
if (index != -1 && r != null   && (cellBounds = this.getCellBounds$I$I(index, index)) != null   && cellBounds.contains$I$I(p.x, p.y) ) {
var lsm = this.getSelectionModel();
var rComponent = r.getListCellRendererComponent$javax_swing_JList$O$I$Z$Z(this, this.getModel().getElementAt$I(index), index, lsm.isSelectedIndex$I(index), (this.hasFocus() && (lsm.getLeadSelectionIndex() == index) ));
var newEvent;
p.translate$I$I(-cellBounds.x, -cellBounds.y);
newEvent = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.event.MouseEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$I,[rComponent, event.getID(), event.getWhen(), event.getModifiers(), p.x, p.y, event.getXOnScreen(), event.getYOnScreen(), event.getClickCount(), event.isPopupTrigger(), 0]);
var tip = (rComponent).getToolTipText$java_awt_event_MouseEvent(newEvent);
if (tip != null ) {
return tip;
}}}return C$.superClazz.prototype.getToolTipText.apply(this, []);
});

Clazz.newMethod$(C$, 'locationToIndex$java_awt_Point', function (location) {
var ui = this.getUI();
return (ui != null ) ? ui.locationToIndex$javax_swing_JList$java_awt_Point(this, location) : -1;
});

Clazz.newMethod$(C$, 'indexToLocation$I', function (index) {
var ui = this.getUI();
return (ui != null ) ? ui.indexToLocation$javax_swing_JList$I(this, index) : null;
});

Clazz.newMethod$(C$, 'getCellBounds$I$I', function (index0, index1) {
var ui = this.getUI();
return (ui != null ) ? ui.getCellBounds$javax_swing_JList$I$I(this, index0, index1) : null;
});

Clazz.newMethod$(C$, 'getModel', function () {
return this.dataModel;
});

Clazz.newMethod$(C$, 'setModel$javax_swing_ListModel', function (model) {
if (model == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["model must be non null"]);
}var oldValue = this.dataModel;
this.dataModel = model;
this.firePropertyChange$S$O$O("model", oldValue, this.dataModel);
this.clearSelection();
});

Clazz.newMethod$(C$, 'setListData$OA', function (listData) {
this.setModel$javax_swing_ListModel(((
(function(){var C$=Clazz.newClass$(P$, "JList$4", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractListModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return this.$finals.listData.length;
});

Clazz.newMethod$(C$, 'getElementAt$I', function (i) {
return this.$finals.listData[i];
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.AbstractListModel'))), [this, {listData: listData}],P$.JList$4)));
});

Clazz.newMethod$(C$, 'setListData$java_util_Vector', function (listData) {
this.setModel$javax_swing_ListModel(((
(function(){var C$=Clazz.newClass$(P$, "JList$5", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractListModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return this.$finals.listData.size();
});

Clazz.newMethod$(C$, 'getElementAt$I', function (i) {
return this.$finals.listData.elementAt$I(i);
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.AbstractListModel'))), [this, {listData: listData}],P$.JList$5)));
});

Clazz.newMethod$(C$, 'createSelectionModel', function () {
return Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.DefaultListSelectionModel'))));
});

Clazz.newMethod$(C$, 'getSelectionModel', function () {
return this.selectionModel;
});

Clazz.newMethod$(C$, 'fireSelectionValueChanged$I$I$Z', function (firstIndex, lastIndex, isAdjusting) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ListSelectionListener) ) {
if (e == null ) {
e = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.event.ListSelectionEvent'))).c$$O$I$I$Z,[this, firstIndex, lastIndex, isAdjusting]);
}(listeners[i + 1]).valueChanged$javax_swing_event_ListSelectionEvent(e);
}}
});

Clazz.newMethod$(C$, 'addListSelectionListener$javax_swing_event_ListSelectionListener', function (listener) {
if (this.selectionListener == null ) {
this.selectionListener = Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.JList').ListSelectionHandler))), [this, null]);
this.getSelectionModel().addListSelectionListener$javax_swing_event_ListSelectionListener(this.selectionListener);
}this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ListSelectionListener), listener);
});

Clazz.newMethod$(C$, 'removeListSelectionListener$javax_swing_event_ListSelectionListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ListSelectionListener), listener);
});

Clazz.newMethod$(C$, 'getListSelectionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ListSelectionListener));
});

Clazz.newMethod$(C$, 'setSelectionModel$javax_swing_ListSelectionModel', function (selectionModel) {
if (selectionModel == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["selectionModel must be non null"]);
}if (this.selectionListener != null ) {
this.selectionModel.removeListSelectionListener$javax_swing_event_ListSelectionListener(this.selectionListener);
selectionModel.addListSelectionListener$javax_swing_event_ListSelectionListener(this.selectionListener);
}var oldValue = this.selectionModel;
this.selectionModel = selectionModel;
this.firePropertyChange$S$O$O("selectionModel", oldValue, selectionModel);
});

Clazz.newMethod$(C$, 'setSelectionMode$I', function (selectionMode) {
this.getSelectionModel().setSelectionMode$I(selectionMode);
});

Clazz.newMethod$(C$, 'getSelectionMode', function () {
return this.getSelectionModel().getSelectionMode();
});

Clazz.newMethod$(C$, 'getAnchorSelectionIndex', function () {
return this.getSelectionModel().getAnchorSelectionIndex();
});

Clazz.newMethod$(C$, 'getLeadSelectionIndex', function () {
return this.getSelectionModel().getLeadSelectionIndex();
});

Clazz.newMethod$(C$, 'getMinSelectionIndex', function () {
return this.getSelectionModel().getMinSelectionIndex();
});

Clazz.newMethod$(C$, 'getMaxSelectionIndex', function () {
return this.getSelectionModel().getMaxSelectionIndex();
});

Clazz.newMethod$(C$, 'isSelectedIndex$I', function (index) {
return this.getSelectionModel().isSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'isSelectionEmpty', function () {
return this.getSelectionModel().isSelectionEmpty();
});

Clazz.newMethod$(C$, 'clearSelection', function () {
this.getSelectionModel().clearSelection();
});

Clazz.newMethod$(C$, 'setSelectionInterval$I$I', function (anchor, lead) {
this.getSelectionModel().setSelectionInterval$I$I(anchor, lead);
});

Clazz.newMethod$(C$, 'addSelectionInterval$I$I', function (anchor, lead) {
this.getSelectionModel().addSelectionInterval$I$I(anchor, lead);
});

Clazz.newMethod$(C$, 'removeSelectionInterval$I$I', function (index0, index1) {
this.getSelectionModel().removeSelectionInterval$I$I(index0, index1);
});

Clazz.newMethod$(C$, 'setValueIsAdjusting$Z', function (b) {
this.getSelectionModel().setValueIsAdjusting$Z(b);
});

Clazz.newMethod$(C$, 'getValueIsAdjusting', function () {
return this.getSelectionModel().getValueIsAdjusting();
});

Clazz.newMethod$(C$, 'getSelectedIndices', function () {
var sm = this.getSelectionModel();
var iMin = sm.getMinSelectionIndex();
var iMax = sm.getMaxSelectionIndex();
if ((iMin < 0) || (iMax < 0) ) {
return  Clazz.newArray$(Integer.TYPE, [0]);
}var rvTmp =  Clazz.newArray$(Integer.TYPE, [1 + (iMax - iMin)]);
var n = 0;
for (var i = iMin; i <= iMax; i++) {
if (sm.isSelectedIndex$I(i)) {
rvTmp[n++] = i;
}}
var rv =  Clazz.newArray$(Integer.TYPE, [n]);
System.arraycopy(rvTmp, 0, rv, 0, n);
return rv;
});

Clazz.newMethod$(C$, 'setSelectedIndex$I', function (index) {
if (index >= this.getModel().getSize()) {
return;
}this.getSelectionModel().setSelectionInterval$I$I(index, index);
});

Clazz.newMethod$(C$, 'setSelectedIndices$IA', function (indices) {
var sm = this.getSelectionModel();
sm.clearSelection();
var size = this.getModel().getSize();
for (var i = 0; i < indices.length; i++) {
if (indices[i] < size) {
sm.addSelectionInterval$I$I(indices[i], indices[i]);
}}
});

Clazz.newMethod$(C$, 'getSelectedValues', function () {
var sm = this.getSelectionModel();
var dm = this.getModel();
var iMin = sm.getMinSelectionIndex();
var iMax = sm.getMaxSelectionIndex();
if ((iMin < 0) || (iMax < 0) ) {
return  Clazz.newArray$(java.lang.Object, [0]);
}var rvTmp =  Clazz.newArray$(java.lang.Object, [1 + (iMax - iMin)]);
var n = 0;
for (var i = iMin; i <= iMax; i++) {
if (sm.isSelectedIndex$I(i)) {
rvTmp[n++] = dm.getElementAt$I(i);
}}
var rv =  Clazz.newArray$(java.lang.Object, [n]);
System.arraycopy(rvTmp, 0, rv, 0, n);
return rv;
});

Clazz.newMethod$(C$, 'getSelectedIndex', function () {
return this.getMinSelectionIndex();
});

Clazz.newMethod$(C$, 'getSelectedValue', function () {
var i = this.getMinSelectionIndex();
return (i == -1) ? null : this.getModel().getElementAt$I(i);
});

Clazz.newMethod$(C$, 'setSelectedValue$O$Z', function (anObject, shouldScroll) {
if (anObject == null ) this.setSelectedIndex$I(-1);
 else if (!anObject.equals$O(this.getSelectedValue())) {
var i;
var c;
var dm = this.getModel();
for (i = 0, c = dm.getSize(); i < c; i++) if (anObject.equals$O(dm.getElementAt$I(i))) {
this.setSelectedIndex$I(i);
if (shouldScroll) this.ensureIndexIsVisible$I(i);
this.repaint();
return;
}
this.setSelectedIndex$I(-1);
}this.repaint();
});

Clazz.newMethod$(C$, 'checkScrollableParameters$java_awt_Rectangle$I', function (visibleRect, orientation) {
if (visibleRect == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["visibleRect must be non-null"]);
}switch (orientation) {
case 1:
case 0:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["orientation must be one of: VERTICAL, HORIZONTAL"]);
}
});

Clazz.newMethod$(C$, 'getPreferredScrollableViewportSize', function () {
if (this.getLayoutOrientation() != 0) {
return this.getPreferredSize();
}var insets = this.getInsets();
var dx = insets.left + insets.right;
var dy = insets.top + insets.bottom;
var visibleRowCount = this.getVisibleRowCount();
var fixedCellWidth = this.getFixedCellWidth();
var fixedCellHeight = this.getFixedCellHeight();
if ((fixedCellWidth > 0) && (fixedCellHeight > 0) ) {
var width = fixedCellWidth + dx;
var height = (visibleRowCount * fixedCellHeight) + dy;
return Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, height]);
} else if (this.getModel().getSize() > 0) {
var width = this.getPreferredSize().width;
var height;
var r = this.getCellBounds$I$I(0, 0);
if (r != null ) {
height = (visibleRowCount * r.height) + dy;
} else {
height = 1;
}return Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, height]);
} else {
fixedCellWidth = (fixedCellWidth > 0) ? fixedCellWidth : 256;
fixedCellHeight = (fixedCellHeight > 0) ? fixedCellHeight : 16;
return Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.Dimension'))).c$$I$I,[fixedCellWidth, fixedCellHeight * visibleRowCount]);
}});

Clazz.newMethod$(C$, 'getScrollableUnitIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
p$.checkScrollableParameters$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
if (orientation == 1) {
var row = this.locationToIndex$java_awt_Point(visibleRect.getLocation());
if (row == -1) {
return 0;
} else {
if (direction > 0) {
var r = this.getCellBounds$I$I(row, row);
return (r == null ) ? 0 : r.height - (visibleRect.y - r.y);
} else {
var r = this.getCellBounds$I$I(row, row);
if ((r.y == visibleRect.y) && (row == 0) ) {
return 0;
} else if (r.y == visibleRect.y) {
var loc = r.getLocation();
loc.y--;
var prevIndex = this.locationToIndex$java_awt_Point(loc);
var prevR = this.getCellBounds$I$I(prevIndex, prevIndex);
if (prevR == null  || prevR.y >= r.y ) {
return 0;
}return prevR.height;
} else {
return visibleRect.y - r.y;
}}}} else if (orientation == 0 && this.getLayoutOrientation() != 0 ) {
var leftToRight = this.getComponentOrientation().isLeftToRight();
var index;
var leadingPoint;
if (leftToRight) {
leadingPoint = visibleRect.getLocation();
} else {
leadingPoint = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x + visibleRect.width - 1, visibleRect.y]);
}index = this.locationToIndex$java_awt_Point(leadingPoint);
if (index != -1) {
var cellBounds = this.getCellBounds$I$I(index, index);
if (cellBounds != null  && cellBounds.contains$java_awt_Point(leadingPoint) ) {
var leadingVisibleEdge;
var leadingCellEdge;
if (leftToRight) {
leadingVisibleEdge = visibleRect.x;
leadingCellEdge = cellBounds.x;
} else {
leadingVisibleEdge = visibleRect.x + visibleRect.width;
leadingCellEdge = cellBounds.x + cellBounds.width;
}if (leadingCellEdge != leadingVisibleEdge) {
if (direction < 0) {
return Math.abs(leadingVisibleEdge - leadingCellEdge);
} else if (leftToRight) {
return leadingCellEdge + cellBounds.width - leadingVisibleEdge;
} else {
return leadingVisibleEdge - cellBounds.x;
}}return cellBounds.width;
}}}var f = this.getFont();
return (f != null ) ? f.getSize() : 1;
});

Clazz.newMethod$(C$, 'getScrollableBlockIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
p$.checkScrollableParameters$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
if (orientation == 1) {
var inc = visibleRect.height;
if (direction > 0) {
var last = this.locationToIndex$java_awt_Point(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y + visibleRect.height - 1]));
if (last != -1) {
var lastRect = this.getCellBounds$I$I(last, last);
if (lastRect != null ) {
inc = lastRect.y - visibleRect.y;
if ((inc == 0) && (last < this.getModel().getSize() - 1) ) {
inc = lastRect.height;
}}}} else {
var newFirst = this.locationToIndex$java_awt_Point(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y - visibleRect.height]));
var first = this.getFirstVisibleIndex();
if (newFirst != -1) {
if (first == -1) {
first = this.locationToIndex$java_awt_Point(visibleRect.getLocation());
}var newFirstRect = this.getCellBounds$I$I(newFirst, newFirst);
var firstRect = this.getCellBounds$I$I(first, first);
if ((newFirstRect != null ) && (firstRect != null ) ) {
while ((newFirstRect.y + visibleRect.height < firstRect.y + firstRect.height) && (newFirstRect.y < firstRect.y) ){
newFirst++;
newFirstRect = this.getCellBounds$I$I(newFirst, newFirst);
}
inc = visibleRect.y - newFirstRect.y;
if ((inc <= 0) && (newFirstRect.y > 0) ) {
newFirst--;
newFirstRect = this.getCellBounds$I$I(newFirst, newFirst);
if (newFirstRect != null ) {
inc = visibleRect.y - newFirstRect.y;
}}}}}return inc;
} else if (orientation == 0 && this.getLayoutOrientation() != 0 ) {
var leftToRight = this.getComponentOrientation().isLeftToRight();
var inc = visibleRect.width;
if (direction > 0) {
var x = visibleRect.x + (leftToRight ? (visibleRect.width - 1) : 0);
var last = this.locationToIndex$java_awt_Point(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[x, visibleRect.y]));
if (last != -1) {
var lastRect = this.getCellBounds$I$I(last, last);
if (lastRect != null ) {
if (leftToRight) {
inc = lastRect.x - visibleRect.x;
} else {
inc = visibleRect.x + visibleRect.width - (lastRect.x + lastRect.width);
}if (inc < 0) {
inc = inc+(lastRect.width);
} else if ((inc == 0) && (last < this.getModel().getSize() - 1) ) {
inc = lastRect.width;
}}}} else {
var x = visibleRect.x + (leftToRight ? -visibleRect.width : visibleRect.width - 1 + visibleRect.width);
var first = this.locationToIndex$java_awt_Point(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[x, visibleRect.y]));
if (first != -1) {
var firstRect = this.getCellBounds$I$I(first, first);
if (firstRect != null ) {
var firstRight = firstRect.x + firstRect.width;
if (leftToRight) {
if ((firstRect.x < visibleRect.x - visibleRect.width) && (firstRight < visibleRect.x) ) {
inc = visibleRect.x - firstRight;
} else {
inc = visibleRect.x - firstRect.x;
}} else {
var visibleRight = visibleRect.x + visibleRect.width;
if ((firstRight > visibleRight + visibleRect.width) && (firstRect.x > visibleRight) ) {
inc = firstRect.x - visibleRight;
} else {
inc = firstRight - visibleRight;
}}}}}return inc;
}return visibleRect.width;
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportWidth', function () {
if (this.getLayoutOrientation() == 2 && this.getVisibleRowCount() <= 0 ) {
return true;
}if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
return ((this.getParent()).getWidth() > this.getPreferredSize().width);
}return false;
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportHeight', function () {
if (this.getLayoutOrientation() == 1 && this.getVisibleRowCount() <= 0 ) {
return true;
}if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
return ((this.getParent()).getHeight() > this.getPreferredSize().height);
}return false;
});

Clazz.newMethod$(C$, 'paramString', function () {
var selectionForegroundString = (this.selectionForeground != null  ? this.selectionForeground.toString() : "");
var selectionBackgroundString = (this.selectionBackground != null  ? this.selectionBackground.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",fixedCellHeight=" + this.fixedCellHeight + ",fixedCellWidth=" + this.fixedCellWidth + ",horizontalScrollIncrement=" + this.horizontalScrollIncrement + ",selectionBackground=" + selectionBackgroundString + ",selectionForeground=" + selectionForegroundString + ",visibleRowCount=" + this.visibleRowCount + ",layoutOrientation=" + this.layoutOrientation ;
});
;
(function(){var C$=Clazz.newClass$(P$.JList, "DropLocation", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.index = 0;
this.$isInsert = false;
this.dropPoint = null;
}, 1);

Clazz.newMethod$(C$, 'getDropPoint', function () {
return this.dropPoint;
});

Clazz.newMethod$(C$, 'c$$java_awt_Point$I$Z', function (p, index, isInsert) {
C$.$init$.apply(this);
this.dropPoint = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$java_awt_Point,[p]);
this.index = index;
this.$isInsert = isInsert;
}, 1);

Clazz.newMethod$(C$, 'getIndex', function () {
return this.index;
});

Clazz.newMethod$(C$, 'isInsert', function () {
return this.$isInsert;
});

Clazz.newMethod$(C$, 'toString', function () {
return this.getClass().getName() + "[" + "index=" + this.index + "," + "insert=" + this.$isInsert + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JList, "ListSelectionHandler", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ListSelectionListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'valueChanged$javax_swing_event_ListSelectionEvent', function (e) {
this.b$['javax.swing.JList'].fireSelectionValueChanged$I$I$Z(e.getFirstIndex(), e.getLastIndex(), e.getValueIsAdjusting());
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:39
