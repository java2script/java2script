(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JApplet", null, 'java.applet.Applet', 'javax.swing.RootPaneContainer');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.rootPane = null;
this.rootPaneCheckingEnabled = false;
this.transferHandler = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.setFrameViewer$swingjs_JSFrameViewer(this.appletViewer);
p$.setJApplet.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'setJApplet', function () {
this.setForeground$java_awt_Color((I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).black);
this.setBackground$java_awt_Color((I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).white);
this.setLocale$java_util_Locale((I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getDefaultLocale());
this.setLayout$java_awt_LayoutManager(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.BorderLayout')))));
this.setRootPane$javax_swing_JRootPane(this.createRootPane());
this.rootPane.setFrameViewer$swingjs_JSFrameViewer(this.appletViewer);
this.setRootPaneCheckingEnabled$Z(true);
this.setFocusTraversalPolicyProvider$Z(true);
this.enableEvents$J(8);
});

Clazz.newMethod$(C$, 'createRootPane', function () {
var rp = Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.JRootPane'))).c$$S$Z,["", true]);
rp.setOpaque$Z(true);
return rp;
});

Clazz.newMethod$(C$, 'setTransferHandler$javax_swing_TransferHandler', function (newHandler) {
var oldHandler = this.transferHandler;
this.transferHandler = newHandler;
(I$[4] || (I$[4]=Clazz.load('javax.swing.SwingUtilities'))).installSwingDropTargetAsNecessary$java_awt_Component$javax_swing_TransferHandler(this, this.transferHandler);
this.firePropertyChange$S$O$O("transferHandler", oldHandler, newHandler);
});

Clazz.newMethod$(C$, 'getTransferHandler', function () {
return this.transferHandler;
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
(g).setBackground$java_awt_Color(this.getBackground());
(g).setColor$java_awt_Color(this.getForeground());
this.rootPane.paint$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'setJMenuBar$javax_swing_JMenuBar', function (menuBar) {
this.getRootPane().setMenuBar$javax_swing_JMenuBar(menuBar);
});

Clazz.newMethod$(C$, 'getJMenuBar', function () {
return this.getRootPane().getMenuBar();
});

Clazz.newMethod$(C$, 'isRootPaneCheckingEnabled', function () {
return this.rootPaneCheckingEnabled;
});

Clazz.newMethod$(C$, 'setRootPaneCheckingEnabled$Z', function (enabled) {
this.rootPaneCheckingEnabled = enabled;
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
if (this.isRootPaneCheckingEnabled()) {
return this.getContentPane().add$java_awt_Component$O$I(comp, constraints, index);
}return this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (comp) {
if (comp === this.rootPane ) {
C$.superClazz.prototype.remove$java_awt_Component.apply(this, [comp]);
} else {
this.getContentPane().remove$java_awt_Component(comp);
}});

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (manager) {
if (this.isRootPaneCheckingEnabled()) {
this.getContentPane().setLayout$java_awt_LayoutManager(manager);
} else {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [manager]);
}});

Clazz.newMethod$(C$, 'getRootPane', function () {
return this.rootPane;
});

Clazz.newMethod$(C$, 'setRootPane$javax_swing_JRootPane', function (root) {
if (this.rootPane != null ) {
this.remove$java_awt_Component(this.rootPane);
}this.rootPane = root;
if (this.rootPane != null ) {
var checkingEnabled = this.isRootPaneCheckingEnabled();
try {
this.setRootPaneCheckingEnabled$Z(false);
this.add$java_awt_Component$O(this.rootPane, "Center");
} finally {
this.setRootPaneCheckingEnabled$Z(checkingEnabled);
}
}});

Clazz.newMethod$(C$, 'getContentPane', function () {
return this.getRootPane().getContentPane();
});

Clazz.newMethod$(C$, 'setContentPane$java_awt_Container', function (contentPane) {
this.getRootPane().setContentPane$java_awt_Container(contentPane);
});

Clazz.newMethod$(C$, 'getLayeredPane', function () {
return this.getRootPane().getLayeredPane();
});

Clazz.newMethod$(C$, 'setLayeredPane$javax_swing_JLayeredPane', function (layeredPane) {
this.getRootPane().setLayeredPane$javax_swing_JLayeredPane(layeredPane);
});

Clazz.newMethod$(C$, 'getGlassPane', function () {
return this.getRootPane().getGlassPane();
});

Clazz.newMethod$(C$, 'setGlassPane$java_awt_Component', function (glassPane) {
this.getRootPane().setGlassPane$java_awt_Component(glassPane);
});

Clazz.newMethod$(C$, 'getGraphics', function () {
(I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getGraphicsInvoked$java_awt_Component(this);
return C$.superClazz.prototype.getGraphics.apply(this, []);
});

Clazz.newMethod$(C$, 'repaint$J$I$I$I$I', function (time, x, y, width, height) {
if ((I$[5] || (I$[5]=Clazz.load('javax.swing.RepaintManager'))).HANDLE_TOP_LEVEL_PAINT) {
(I$[5] || (I$[5]=Clazz.load('javax.swing.RepaintManager'))).currentManager$java_awt_Component(this).addDirtyRegion$java_applet_Applet$I$I$I$I(this, x, y, width, height);
} else {
C$.superClazz.prototype.repaint$J$I$I$I$I.apply(this, [time, x, y, width, height]);
}});

Clazz.newMethod$(C$, 'repaintNow', function () {
this.repaint$J$I$I$I$I(100, 0, 0, this.getWidth(), this.getHeight());
});

Clazz.newMethod$(C$, 'paramString', function () {
var rootPaneString = (this.rootPane != null  ? this.rootPane.toString() : "");
var rootPaneCheckingEnabledString = (this.rootPaneCheckingEnabled ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",rootPane=" + rootPaneString + ",rootPaneCheckingEnabled=" + rootPaneCheckingEnabledString ;
});
})();
//Created 2017-10-14 13:31:34
