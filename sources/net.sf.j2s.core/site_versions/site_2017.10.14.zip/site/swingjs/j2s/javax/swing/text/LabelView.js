(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "LabelView", null, 'javax.swing.text.GlyphView', 'javax.swing.text.TabableView');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.font = null;
this.fg = null;
this.bg = null;
this.underline = false;
this.strike = false;
this.superscript = false;
this.subscript = false;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.superClazz.c$$javax_swing_text_Element.apply(this, [elem]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'sync', function () {
if (this.font == null ) {
this.setPropertiesFromAttributes();
}});

Clazz.newMethod$(C$, 'setUnderline$Z', function (u) {
this.underline = u;
});

Clazz.newMethod$(C$, 'setStrikeThrough$Z', function (s) {
this.strike = s;
});

Clazz.newMethod$(C$, 'setSuperscript$Z', function (s) {
this.superscript = s;
});

Clazz.newMethod$(C$, 'setSubscript$Z', function (s) {
this.subscript = s;
});

Clazz.newMethod$(C$, 'setBackground$java_awt_Color', function (bg) {
this.bg = bg;
});

Clazz.newMethod$(C$, 'setPropertiesFromAttributes', function () {
var attr = this.getAttributes();
if (attr != null ) {
var d = this.getDocument();
if (Clazz.instanceOf(d, "javax.swing.text.StyledDocument")) {
var doc = d;
this.font = doc.getFont$javax_swing_text_AttributeSet(attr);
this.fg = doc.getForeground$javax_swing_text_AttributeSet(attr);
if (attr.isDefined$O((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).Background)) {
this.bg = doc.getBackground$javax_swing_text_AttributeSet(attr);
} else {
this.bg = null;
}this.setUnderline$Z((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).isUnderline$javax_swing_text_AttributeSet(attr));
this.setStrikeThrough$Z((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).isStrikeThrough$javax_swing_text_AttributeSet(attr));
this.setSuperscript$Z((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).isSuperscript$javax_swing_text_AttributeSet(attr));
this.setSubscript$Z((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).isSubscript$javax_swing_text_AttributeSet(attr));
} else {
throw Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.text.StateInvariantError'))).c$$S,["LabelView needs StyledDocument"]);
}}});

Clazz.newMethod$(C$, 'getFontMetrics', function () {
this.sync();
var c = this.getContainer();
return (c != null ) ? c.getFontMetrics$java_awt_Font(this.font) : (I$[2] || (I$[2]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit().getFontMetrics$java_awt_Font(this.font);
});

Clazz.newMethod$(C$, 'getBackground', function () {
this.sync();
return this.bg;
});

Clazz.newMethod$(C$, 'getForeground', function () {
this.sync();
return this.fg;
});

Clazz.newMethod$(C$, 'getFont', function () {
this.sync();
return this.font;
});

Clazz.newMethod$(C$, 'isUnderline', function () {
this.sync();
return this.underline;
});

Clazz.newMethod$(C$, 'isStrikeThrough', function () {
this.sync();
return this.strike;
});

Clazz.newMethod$(C$, 'isSubscript', function () {
this.sync();
return this.subscript;
});

Clazz.newMethod$(C$, 'isSuperscript', function () {
this.sync();
return this.superscript;
});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (e, a, f) {
this.font = null;
C$.superClazz.prototype.changedUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory.apply(this, [e, a, f]);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:03
