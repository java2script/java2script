(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newClass$(P$, "HyperlinkEvent", function(){
Clazz.newInstance$(this, arguments);
}, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.type = null;
this.u = null;
this.desc = null;
this.sourceElement = null;
}, 1);

Clazz.newMethod$(C$, 'c$$O$javax_swing_event_HyperlinkEvent_EventType$java_net_URL', function (source, type, u) {
C$.c$$O$javax_swing_event_HyperlinkEvent_EventType$java_net_URL$S.apply(this, [source, type, u, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$javax_swing_event_HyperlinkEvent_EventType$java_net_URL$S', function (source, type, u, desc) {
C$.c$$O$javax_swing_event_HyperlinkEvent_EventType$java_net_URL$S$javax_swing_text_Element.apply(this, [source, type, u, desc, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$javax_swing_event_HyperlinkEvent_EventType$java_net_URL$S$javax_swing_text_Element', function (source, type, u, desc, sourceElement) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.type = type;
this.u = u;
this.desc = desc;
this.sourceElement = sourceElement;
}, 1);

Clazz.newMethod$(C$, 'getEventType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'getDescription', function () {
return this.desc;
});

Clazz.newMethod$(C$, 'getURL', function () {
return this.u;
});

Clazz.newMethod$(C$, 'getSourceElement', function () {
return this.sourceElement;
});
;
(function(){var C$=Clazz.newClass$(P$.HyperlinkEvent, "EventType", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.ENTERED = Clazz.new(C$.c$$S,["ENTERED"]);
C$.EXITED = Clazz.new(C$.c$$S,["EXITED"]);
C$.ACTIVATED = Clazz.new(C$.c$$S,["ACTIVATED"]);
};

C$.ENTERED = null;
C$.EXITED = null;
C$.ACTIVATED = null;

Clazz.newMethod$(C$, '$init$', function () {
this.typeString = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (s) {
C$.$init$.apply(this);
this.typeString = s;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return this.typeString;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
