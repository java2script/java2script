(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractDocument", function(){
Clazz.newInstance$(this, arguments);
}, null, 'swingjs.api.JSMinimalAbstractDocument');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.documentProperties = null;
this.listenerList = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.event.EventListenerList'))));
this.data = null;
this.context = null;
this.bidiRoot = null;
this.documentFilter = null;
this.filterBypass = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_AbstractDocument_Content', function (data) {
C$.c$$javax_swing_text_AbstractDocument_Content$javax_swing_text_AbstractDocument_AttributeContext.apply(this, [data, (I$[8] || (I$[8]=Clazz.load('javax.swing.text.StyleContext'))).getDefaultStyleContext()]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_AbstractDocument_Content$javax_swing_text_AbstractDocument_AttributeContext', function (data, context) {
C$.$init$.apply(this);
this.data = data;
this.context = context;
}, 1);

Clazz.newMethod$(C$, 'getDocumentProperties', function () {
if (this.documentProperties == null ) {
this.documentProperties = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.util.Hashtable'))).c$$I,[2]);
}return this.documentProperties;
});

Clazz.newMethod$(C$, 'setDocumentProperties$java_util_Dictionary', function (x) {
this.documentProperties = x;
});

Clazz.newMethod$(C$, 'fireInsertUpdate$javax_swing_event_DocumentEvent', function (e) {
try {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.DocumentListener) ) {
(listeners[i + 1]).insertUpdate$javax_swing_event_DocumentEvent(e);
}}
} finally {
}
});

Clazz.newMethod$(C$, 'fireChangedUpdate$javax_swing_event_DocumentEvent', function (e) {
try {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.DocumentListener) ) {
(listeners[i + 1]).changedUpdate$javax_swing_event_DocumentEvent(e);
}}
} finally {
}
});

Clazz.newMethod$(C$, 'fireRemoveUpdate$javax_swing_event_DocumentEvent', function (e) {
try {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.DocumentListener) ) {
(listeners[i + 1]).removeUpdate$javax_swing_event_DocumentEvent(e);
}}
} finally {
}
});

Clazz.newMethod$(C$, 'fireUndoableEditUpdate$javax_swing_event_UndoableEditEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.UndoableEditListener) ) {
(listeners[i + 1]).undoableEditHappened$javax_swing_event_UndoableEditEvent(e);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'getAsynchronousLoadPriority', function () {
var loadPriority = this.getProperty$O("load priority");
if (loadPriority != null ) {
return loadPriority.intValue();
}return -1;
});

Clazz.newMethod$(C$, 'setAsynchronousLoadPriority$I', function (p) {
var loadPriority = (p >= 0) ?  new Integer(p) : null;
this.putProperty$O$O("load priority", loadPriority);
});

Clazz.newMethod$(C$, 'setDocumentFilter$javax_swing_text_DocumentFilter', function (filter) {
this.documentFilter = filter;
});

Clazz.newMethod$(C$, 'getDocumentFilter', function () {
return this.documentFilter;
});

Clazz.newMethod$(C$, 'getLength', function () {
return this.data.length$() - 1;
});

Clazz.newMethod$(C$, 'addDocumentListener$javax_swing_event_DocumentListener', function (listener) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.DocumentListener), listener);
});

Clazz.newMethod$(C$, 'removeDocumentListener$javax_swing_event_DocumentListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.DocumentListener), listener);
});

Clazz.newMethod$(C$, 'getDocumentListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.DocumentListener));
});

Clazz.newMethod$(C$, 'addUndoableEditListener$javax_swing_event_UndoableEditListener', function (listener) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.UndoableEditListener), listener);
});

Clazz.newMethod$(C$, 'removeUndoableEditListener$javax_swing_event_UndoableEditListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.UndoableEditListener), listener);
});

Clazz.newMethod$(C$, 'getUndoableEditListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.UndoableEditListener));
});

Clazz.newMethod$(C$, 'getProperty$O', function (key) {
return this.getDocumentProperties().get$O(key);
});

Clazz.newMethod$(C$, 'putProperty$O$O', function (key, value) {
if (value != null ) {
this.getDocumentProperties().put$TK$TV(key, value);
} else {
this.getDocumentProperties().remove$O(key);
}});

Clazz.newMethod$(C$, 'remove$I$I', function (offs, len) {
var filter = this.getDocumentFilter();
this.writeLock();
try {
if (filter != null ) {
filter.remove$javax_swing_text_DocumentFilter_FilterBypass$I$I(p$.getFilterBypass.apply(this, []), offs, len);
} else {
this.handleRemove$I$I(offs, len);
}} finally {
this.writeUnlock();
}
});

Clazz.newMethod$(C$, 'handleRemove$I$I', function (offs, len) {
if (len > 0) {
if (offs < 0 || (offs + len) > this.getLength() ) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Invalid remove", this.getLength() + 1]);
}var chng = Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').DefaultDocumentEvent))).c$$I$I$javax_swing_event_DocumentEvent_EventType, [this, null, offs, len, (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE]);
var isComposedTextElement = false;
isComposedTextElement = (I$[10] || (I$[10]=Clazz.load('javax.swing.text.Utilities'))).isComposedTextElement$javax_swing_text_Document$I(this, offs);
this.removeUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent(chng);
var u = this.data.remove$I$I(offs, len);
if (u != null ) {
chng.addEdit$javax_swing_undo_UndoableEdit(u);
}this.postRemoveUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent(chng);
chng.end();
this.fireRemoveUpdate$javax_swing_event_DocumentEvent(chng);
if ((u != null ) && !isComposedTextElement ) {
this.fireUndoableEditUpdate$javax_swing_event_UndoableEditEvent(Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.event.UndoableEditEvent'))).c$$O$javax_swing_undo_UndoableEdit,[this, chng]));
}}});

Clazz.newMethod$(C$, 'replace$I$I$S$javax_swing_text_AttributeSet', function (offset, length, text, attrs) {
if (length == 0 && (text == null  || text.length$() == 0 ) ) {
return;
}var filter = this.getDocumentFilter();
this.writeLock();
try {
if (filter != null ) {
filter.replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(p$.getFilterBypass.apply(this, []), offset, length, text, attrs);
} else {
if (length > 0) {
this.remove$I$I(offset, length);
}if (text != null  && text.length$() > 0 ) {
this.insertString$I$S$javax_swing_text_AttributeSet(offset, text, attrs);
}}} finally {
this.writeUnlock();
}
});

Clazz.newMethod$(C$, 'insertString$I$S$javax_swing_text_AttributeSet', function (offs, str, a) {
if ((str == null ) || (str.length$() == 0) ) {
return;
}var filter = this.getDocumentFilter();
this.writeLock();
try {
if (filter != null ) {
filter.insertString$javax_swing_text_DocumentFilter_FilterBypass$I$S$javax_swing_text_AttributeSet(p$.getFilterBypass.apply(this, []), offs, str, a);
} else {
this.handleInsertString$I$S$javax_swing_text_AttributeSet(offs, str, a);
}} finally {
this.writeUnlock();
}
});

Clazz.newMethod$(C$, 'handleInsertString$I$S$javax_swing_text_AttributeSet', function (offs, str, a) {
if ((str == null ) || (str.length$() == 0) ) {
return;
}var u = this.data.insertString$I$S(offs, str);
var e = Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').DefaultDocumentEvent))).c$$I$I$javax_swing_event_DocumentEvent_EventType, [this, null, offs, str.length$(), (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT]);
if (u != null ) {
e.addEdit$javax_swing_undo_UndoableEdit(u);
}if (this.getProperty$O("i18n").equals$O(Boolean.FALSE)) {
}this.insertUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent$javax_swing_text_AttributeSet(e, a);
e.end();
this.fireInsertUpdate$javax_swing_event_DocumentEvent(e);
if (u != null  && (a == null  || !a.isDefined$O((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).ComposedTextAttribute) ) ) {
this.fireUndoableEditUpdate$javax_swing_event_UndoableEditEvent(Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.event.UndoableEditEvent'))).c$$O$javax_swing_undo_UndoableEdit,[this, e]));
}});

Clazz.newMethod$(C$, 'getText$I$I', function (offset, length) {
if (length < 0) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Length must be positive", length]);
}var str = this.data.getString$I$I(offset, length);
return str;
});

Clazz.newMethod$(C$, 'getText$I$I$javax_swing_text_Segment', function (offset, length, txt) {
if (length < 0) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Length must be positive", length]);
}this.data.getChars$I$I$javax_swing_text_Segment(offset, length, txt);
});

Clazz.newMethod$(C$, 'createPosition$I', function (offs) {
return this.data.createPosition$I(offs);
});

Clazz.newMethod$(C$, 'getStartPosition', function () {
var p;
try {
p = this.createPosition$I(0);
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
p = null;
} else {
throw bl;
}
}
return p;
});

Clazz.newMethod$(C$, 'getEndPosition', function () {
var p;
try {
p = this.createPosition$I(this.data.length$());
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
p = null;
} else {
throw bl;
}
}
return p;
});

Clazz.newMethod$(C$, 'getRootElements', function () {
var elems =  Clazz.newArray$(javax.swing.text.Element, [2]);
elems[0] = this.getDefaultRootElement();
elems[1] = this.getBidiRootElement();
return elems;
});

Clazz.newMethod$(C$, 'getFilterBypass', function () {
if (this.filterBypass == null ) {
this.filterBypass = Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').DefaultFilterBypass))), [this, null]);
}return this.filterBypass;
});

Clazz.newMethod$(C$, 'getBidiRootElement', function () {
return this.bidiRoot;
});

Clazz.newMethod$(C$, 'isLeftToRight$I$I', function (p0, p1) {
if (!this.getProperty$O("i18n").equals$O(Boolean.TRUE)) {
return true;
}var bidiRoot = this.getBidiRootElement();
var index = bidiRoot.getElementIndex$I(p0);
var bidiElem = bidiRoot.getElement$I(index);
if (bidiElem.getEndOffset() >= p1) {
var bidiAttrs = bidiElem.getAttributes();
return (((I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).getBidiLevel$javax_swing_text_AttributeSet(bidiAttrs) % 2) == 0);
}return true;
});

Clazz.newMethod$(C$, 'getAttributeContext', function () {
return this.context;
});

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent$javax_swing_text_AttributeSet', function (chng, attr) {
if (chng.type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT  && chng.getLength() > 0  && !Boolean.TRUE.equals(this.getProperty$O(C$.MultiByteProperty)) ) {
var segment = (I$[13] || (I$[13]=Clazz.load('javax.swing.text.SegmentCache'))).getSharedSegment();
try {
this.getText$I$I$javax_swing_text_Segment(chng.getOffset(), chng.getLength(), segment);
segment.first();
do {
if (segment.current().$c() > 255) {
this.putProperty$O$O(C$.MultiByteProperty, Boolean.TRUE);
break;
}} while (segment.next() != '\uffff');
} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
(I$[13] || (I$[13]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(segment);
}});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent', function (chng) {
});

Clazz.newMethod$(C$, 'postRemoveUpdate$javax_swing_text_AbstractDocument_DefaultDocumentEvent', function (chng) {
});

Clazz.newMethod$(C$, 'getContent', function () {
return this.data;
});

Clazz.newMethod$(C$, 'createLeafElement$javax_swing_text_Element$javax_swing_text_AttributeSet$I$I', function (parent, a, p0, p1) {
return Clazz.new((I$[14] || (I$[14]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').LeafElement))).c$$javax_swing_text_Element$javax_swing_text_AttributeSet$I$I, [this, null, parent, a, p0, p1]);
});

Clazz.newMethod$(C$, 'createBranchElement$javax_swing_text_Element$javax_swing_text_AttributeSet', function (parent, a) {
return Clazz.new((I$[15] || (I$[15]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').BranchElement))).c$$javax_swing_text_Element$javax_swing_text_AttributeSet, [this, null, parent, a]);
});

Clazz.newMethod$(C$, 'writeLock', function () {
});

Clazz.newMethod$(C$, 'writeUnlock', function () {
});

Clazz.newMethod$(C$, 'readLock', function () {
});

Clazz.newMethod$(C$, 'readUnlock', function () {
});
var C$=Clazz.newInterface$(P$.AbstractDocument, "Content", function(){
});

var C$=Clazz.newInterface$(P$.AbstractDocument, "AttributeContext", function(){
});

;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "AbstractElement", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, ['javax.swing.text.Element', 'javax.swing.text.MutableAttributeSet', 'javax.swing.tree.TreeNode']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.parent = null;
this.attributes = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element$javax_swing_text_AttributeSet', function (parent, a) {
C$.$init$.apply(this);
this.parent = parent;
this.attributes = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext().getEmptySet();
if (a != null ) {
this.addAttributes$javax_swing_text_AttributeSet(a);
}}, 1);

Clazz.newMethod$(C$, 'getAttributeCount', function () {
return this.attributes.getAttributeCount();
});

Clazz.newMethod$(C$, 'isDefined$O', function (attrName) {
return this.attributes.isDefined$O(attrName);
});

Clazz.newMethod$(C$, 'isEqual$javax_swing_text_AttributeSet', function (attr) {
return this.attributes.isEqual$javax_swing_text_AttributeSet(attr);
});

Clazz.newMethod$(C$, 'copyAttributes', function () {
return this.attributes.copyAttributes();
});

Clazz.newMethod$(C$, 'getAttribute$O', function (attrName) {
var value = this.attributes.getAttribute$O(attrName);
if (value == null ) {
var a = (this.parent != null ) ? this.parent.getAttributes() : null;
if (a != null ) {
value = a.getAttribute$O(attrName);
}}return value;
});

Clazz.newMethod$(C$, 'getAttributeNames', function () {
return this.attributes.getAttributeNames();
});

Clazz.newMethod$(C$, 'containsAttribute$O$O', function (name, value) {
return this.attributes.containsAttribute$O$O(name, value);
});

Clazz.newMethod$(C$, 'containsAttributes$javax_swing_text_AttributeSet', function (attrs) {
return this.attributes.containsAttributes$javax_swing_text_AttributeSet(attrs);
});

Clazz.newMethod$(C$, 'getResolveParent', function () {
var a = this.attributes.getResolveParent();
if ((a == null ) && (this.parent != null ) ) {
a = this.parent.getAttributes();
}return a;
});

Clazz.newMethod$(C$, 'addAttribute$O$O', function (name, value) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
this.attributes = context.addAttribute$javax_swing_text_AttributeSet$O$O(this.attributes, name, value);
});

Clazz.newMethod$(C$, 'addAttributes$javax_swing_text_AttributeSet', function (attr) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
this.attributes = context.addAttributes$javax_swing_text_AttributeSet$javax_swing_text_AttributeSet(this.attributes, attr);
});

Clazz.newMethod$(C$, 'removeAttribute$O', function (name) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
this.attributes = context.removeAttribute$javax_swing_text_AttributeSet$O(this.attributes, name);
});

Clazz.newMethod$(C$, 'removeAttributes$java_util_Enumeration', function (names) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
this.attributes = context.removeAttributes$javax_swing_text_AttributeSet$java_util_Enumeration(this.attributes, names);
});

Clazz.newMethod$(C$, 'removeAttributes$javax_swing_text_AttributeSet', function (attrs) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
if (attrs === this ) {
this.attributes = context.getEmptySet();
} else {
this.attributes = context.removeAttributes$javax_swing_text_AttributeSet$javax_swing_text_AttributeSet(this.attributes, attrs);
}});

Clazz.newMethod$(C$, 'setResolveParent$javax_swing_text_AttributeSet', function (parent) {
p$.checkForIllegalCast.apply(this, []);
var context = this.b$['javax.swing.text.AbstractDocument'].getAttributeContext();
if (parent != null ) {
this.attributes = context.addAttribute$javax_swing_text_AttributeSet$O$O(this.attributes, (I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).ResolveAttribute, parent);
} else {
this.attributes = context.removeAttribute$javax_swing_text_AttributeSet$O(this.attributes, (I$[0] || (I$[0]=Clazz.load('javax.swing.text.StyleConstants'))).ResolveAttribute);
}});

Clazz.newMethod$(C$, 'checkForIllegalCast', function () {
});

Clazz.newMethod$(C$, 'getDocument', function () {
return this.b$['javax.swing.text.AbstractDocument'];
});

Clazz.newMethod$(C$, 'getParentElement', function () {
return this.parent;
});

Clazz.newMethod$(C$, 'getAttributes', function () {
return this;
});

Clazz.newMethod$(C$, 'getName', function () {
if (this.attributes.isDefined$O("$ename")) {
return this.attributes.getAttribute$O("$ename");
}return null;
});

Clazz.newMethod$(C$, 'getChildAt$I', function (childIndex) {
return this.getElement$I(childIndex);
});

Clazz.newMethod$(C$, 'getChildCount', function () {
return this.getElementCount();
});

Clazz.newMethod$(C$, 'getParent', function () {
return this.getParentElement();
});

Clazz.newMethod$(C$, 'getIndex$javax_swing_tree_TreeNode', function (node) {
for (var counter = this.getChildCount() - 1; counter >= 0; counter--) if (this.getChildAt$I(counter) === node ) return counter;

return -1;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "BranchElement", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.AbstractDocument.AbstractElement');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.$children = null;
this.nchildren = 0;
this.lastIndex = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element$javax_swing_text_AttributeSet', function (parent, a) {
C$.superClazz.c$$javax_swing_text_Element$javax_swing_text_AttributeSet.apply(this, [parent, a]);
C$.$init$.apply(this);
this.$children =  Clazz.newArray$(javax.swing.text.AbstractDocument.AbstractElement, [1]);
this.nchildren = 0;
this.lastIndex = -1;
}, 1);

Clazz.newMethod$(C$, 'positionToElement$I', function (pos) {
var index = this.getElementIndex$I(pos);
var child = this.$children[index];
var p0 = child.getStartOffset();
var p1 = child.getEndOffset();
if ((pos >= p0) && (pos < p1) ) {
return child;
}return null;
});

Clazz.newMethod$(C$, 'replace$I$I$javax_swing_text_ElementA', function (offset, length, elems) {
var delta = elems.length - length;
var src = offset + length;
var nmove = this.nchildren - src;
var dest = src + delta;
if ((this.nchildren + delta) >= this.$children.length) {
var newLength = Math.max(2 * this.$children.length, this.nchildren + delta);
var newChildren =  Clazz.newArray$(javax.swing.text.AbstractDocument.AbstractElement, [newLength]);
System.arraycopy(this.$children, 0, newChildren, 0, offset);
System.arraycopy(elems, 0, newChildren, offset, elems.length);
System.arraycopy(this.$children, src, newChildren, dest, nmove);
this.$children = newChildren;
} else {
System.arraycopy(this.$children, src, this.$children, dest, nmove);
System.arraycopy(elems, 0, this.$children, offset, elems.length);
}this.nchildren = this.nchildren + delta;
});

Clazz.newMethod$(C$, 'toString', function () {
return "BranchElement(" + this.getName() + ") " + this.getStartOffset() + "," + this.getEndOffset() + "\n" ;
});

Clazz.newMethod$(C$, 'getName', function () {
var nm = C$.superClazz.prototype.getName.apply(this, []);
if (nm == null ) {
nm = "paragraph";
}return nm;
});

Clazz.newMethod$(C$, 'getStartOffset', function () {
return this.$children[0].getStartOffset();
});

Clazz.newMethod$(C$, 'getEndOffset', function () {
var child = (this.nchildren > 0) ? this.$children[this.nchildren - 1] : this.$children[0];
return child.getEndOffset();
});

Clazz.newMethod$(C$, 'getElement$I', function (index) {
if (index < this.nchildren) {
return this.$children[index];
}return null;
});

Clazz.newMethod$(C$, 'getElementCount', function () {
return this.nchildren;
});

Clazz.newMethod$(C$, 'getElementIndex$I', function (offset) {
var index;
var lower = 0;
var upper = this.nchildren - 1;
var mid = 0;
var p0 = this.getStartOffset();
var p1;
if (this.nchildren == 0) {
return 0;
}if (offset >= this.getEndOffset()) {
return this.nchildren - 1;
}if ((this.lastIndex >= lower) && (this.lastIndex <= upper) ) {
var lastHit = this.$children[this.lastIndex];
p0 = lastHit.getStartOffset();
p1 = lastHit.getEndOffset();
if ((offset >= p0) && (offset < p1) ) {
return this.lastIndex;
}if (offset < p0) {
upper = this.lastIndex;
} else {
lower = this.lastIndex;
}}while (lower <= upper){
mid = lower + (($i$[0] = (upper - lower)/2, $i$[0]));
var elem = this.$children[mid];
p0 = elem.getStartOffset();
p1 = elem.getEndOffset();
if ((offset >= p0) && (offset < p1) ) {
index = mid;
this.lastIndex = index;
return index;
} else if (offset < p0) {
upper = mid - 1;
} else {
lower = mid + 1;
}}
if (offset < p0) {
index = mid;
} else {
index = mid + 1;
}this.lastIndex = index;
return index;
});

Clazz.newMethod$(C$, 'isLeaf', function () {
return false;
});

Clazz.newMethod$(C$, 'getAllowsChildren', function () {
return true;
});

Clazz.newMethod$(C$, 'children', function () {
if (this.nchildren == 0) return null;
var tempVector = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Vector'))).c$$I,[this.nchildren]);
for (var counter = 0; counter < this.nchildren; counter++) tempVector.addElement$TE(this.$children[counter]);

return tempVector.elements();
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "LeafElement", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.AbstractDocument.AbstractElement');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.p0 = null;
this.p1 = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element$javax_swing_text_AttributeSet$I$I', function (parent, a, offs0, offs1) {
C$.superClazz.c$$javax_swing_text_Element$javax_swing_text_AttributeSet.apply(this, [parent, a]);
C$.$init$.apply(this);
try {
this.p0 = this.b$['javax.swing.text.AbstractDocument'].createPosition$I(offs0);
this.p1 = this.b$['javax.swing.text.AbstractDocument'].createPosition$I(offs1);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
this.p0 = null;
this.p1 = null;
throw Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.StateInvariantError'))).c$$S,["Can\'t create Position references"]);
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "LeafElement(" + this.getName() + ") " + this.p0 + "," + this.p1 + "\n" ;
});

Clazz.newMethod$(C$, 'getStartOffset', function () {
return this.p0.getOffset();
});

Clazz.newMethod$(C$, 'getEndOffset', function () {
return this.p1.getOffset();
});

Clazz.newMethod$(C$, 'getName', function () {
var nm = C$.superClazz.prototype.getName.apply(this, []);
if (nm == null ) {
nm = "content";
}return nm;
});

Clazz.newMethod$(C$, 'getElementIndex$I', function (pos) {
return -1;
});

Clazz.newMethod$(C$, 'getElement$I', function (index) {
return null;
});

Clazz.newMethod$(C$, 'getElementCount', function () {
return 0;
});

Clazz.newMethod$(C$, 'isLeaf', function () {
return true;
});

Clazz.newMethod$(C$, 'getAllowsChildren', function () {
return false;
});

Clazz.newMethod$(C$, 'children', function () {
return null;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "DefaultDocumentEvent", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.undo.CompoundEdit', 'javax.swing.event.DocumentEvent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.offset = 0;
this.length = 0;
this.changeLookup = null;
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$javax_swing_event_DocumentEvent_EventType', function (offs, len, type) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.offset = offs;
this.length = len;
this.type = type;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return this.edits.toString();
});

Clazz.newMethod$(C$, 'addEdit$javax_swing_undo_UndoableEdit', function (anEdit) {
if ((this.changeLookup == null ) && (this.edits.size() > 10) ) {
this.changeLookup = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.util.Hashtable'))));
var n = this.edits.size();
for (var i = 0; i < n; i++) {
var o = this.edits.elementAt$I(i);
if (Clazz.instanceOf(o, "javax.swing.event.DocumentEvent.ElementChange")) {
var ec = o;
this.changeLookup.put$TK$TV(ec.getElement(), ec);
}}
}if ((this.changeLookup != null ) && (Clazz.instanceOf(anEdit, "javax.swing.event.DocumentEvent.ElementChange")) ) {
var ec = anEdit;
this.changeLookup.put$TK$TV(ec.getElement(), ec);
}return C$.superClazz.prototype.addEdit$javax_swing_undo_UndoableEdit.apply(this, [anEdit]);
});

Clazz.newMethod$(C$, 'redo', function () {
this.b$['javax.swing.text.AbstractDocument'].writeLock();
try {
C$.superClazz.prototype.redo.apply(this, []);
var ev = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').UndoRedoDocumentEvent))).c$$javax_swing_text_AbstractDocument_DefaultDocumentEvent$Z, [this, null, this, false]);
if (this.type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT ) {
this.b$['javax.swing.text.AbstractDocument'].fireInsertUpdate$javax_swing_event_DocumentEvent(ev);
} else if (this.type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE ) {
this.b$['javax.swing.text.AbstractDocument'].fireRemoveUpdate$javax_swing_event_DocumentEvent(ev);
} else {
this.b$['javax.swing.text.AbstractDocument'].fireChangedUpdate$javax_swing_event_DocumentEvent(ev);
}} finally {
this.b$['javax.swing.text.AbstractDocument'].writeUnlock();
}
});

Clazz.newMethod$(C$, 'undo', function () {
this.b$['javax.swing.text.AbstractDocument'].writeLock();
try {
C$.superClazz.prototype.undo.apply(this, []);
var ev = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.AbstractDocument').UndoRedoDocumentEvent))).c$$javax_swing_text_AbstractDocument_DefaultDocumentEvent$Z, [this, null, this, true]);
if (this.type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE ) {
this.b$['javax.swing.text.AbstractDocument'].fireInsertUpdate$javax_swing_event_DocumentEvent(ev);
} else if (this.type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT ) {
this.b$['javax.swing.text.AbstractDocument'].fireRemoveUpdate$javax_swing_event_DocumentEvent(ev);
} else {
this.b$['javax.swing.text.AbstractDocument'].fireChangedUpdate$javax_swing_event_DocumentEvent(ev);
}} finally {
this.b$['javax.swing.text.AbstractDocument'].writeUnlock();
}
});

Clazz.newMethod$(C$, 'isSignificant', function () {
return true;
});

Clazz.newMethod$(C$, 'getPresentationName', function () {
var type = this.getType();
if (type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT ) return (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("AbstractDocument.additionText");
if (type === (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE ) return (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("AbstractDocument.deletionText");
return (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("AbstractDocument.styleChangeText");
});

Clazz.newMethod$(C$, 'getUndoPresentationName', function () {
return (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("AbstractDocument.undoText") + " " + this.getPresentationName() ;
});

Clazz.newMethod$(C$, 'getRedoPresentationName', function () {
return (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("AbstractDocument.redoText") + " " + this.getPresentationName() ;
});

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'getOffset', function () {
return this.offset;
});

Clazz.newMethod$(C$, 'getLength', function () {
return this.length;
});

Clazz.newMethod$(C$, 'getDocument', function () {
return this.b$['javax.swing.text.AbstractDocument'];
});

Clazz.newMethod$(C$, 'getChange$javax_swing_text_Element', function (elem) {
if (this.changeLookup != null ) {
return this.changeLookup.get$O(elem);
}var n = this.edits.size();
for (var i = 0; i < n; i++) {
var o = this.edits.elementAt$I(i);
if (Clazz.instanceOf(o, "javax.swing.event.DocumentEvent.ElementChange")) {
var c = o;
if (elem.equals$O(c.getElement())) {
return c;
}}}
return null;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "UndoRedoDocumentEvent", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.DocumentEvent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.src = null;
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_AbstractDocument_DefaultDocumentEvent$Z', function (src, isUndo) {
C$.$init$.apply(this);
this.src = src;
if (isUndo) {
if (src.getType().equals$O((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT)) {
this.type = (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE;
} else if (src.getType().equals$O((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).REMOVE)) {
this.type = (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.event.DocumentEvent').EventType))).INSERT;
} else {
this.type = src.getType();
}} else {
this.type = src.getType();
}}, 1);

Clazz.newMethod$(C$, 'getSource', function () {
return this.src;
});

Clazz.newMethod$(C$, 'getOffset', function () {
return this.src.getOffset();
});

Clazz.newMethod$(C$, 'getLength', function () {
return this.src.getLength();
});

Clazz.newMethod$(C$, 'getDocument', function () {
return this.src.getDocument();
});

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'getChange$javax_swing_text_Element', function (elem) {
return this.src.getChange$javax_swing_text_Element(elem);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "ElementEdit", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.undo.AbstractUndoableEdit', 'javax.swing.event.DocumentEvent.ElementChange');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.e = null;
this.index = 0;
this.removed = null;
this.added = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element$I$javax_swing_text_ElementA$javax_swing_text_ElementA', function (e, index, removed, added) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.e = e;
this.index = index;
this.removed = removed;
this.added = added;
}, 1);

Clazz.newMethod$(C$, 'getElement', function () {
return this.e;
});

Clazz.newMethod$(C$, 'getIndex', function () {
return this.index;
});

Clazz.newMethod$(C$, 'getChildrenRemoved', function () {
return this.removed;
});

Clazz.newMethod$(C$, 'getChildrenAdded', function () {
return this.added;
});

Clazz.newMethod$(C$, 'redo', function () {
C$.superClazz.prototype.redo.apply(this, []);
var tmp = this.removed;
this.removed = this.added;
this.added = tmp;
(this.e).replace$I$I$javax_swing_text_ElementA(this.index, this.removed.length, this.added);
});

Clazz.newMethod$(C$, 'undo', function () {
C$.superClazz.prototype.undo.apply(this, []);
(this.e).replace$I$I$javax_swing_text_ElementA(this.index, this.added.length, this.removed);
var tmp = this.removed;
this.removed = this.added;
this.added = tmp;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.AbstractDocument, "DefaultFilterBypass", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.DocumentFilter.FilterBypass');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getDocument', function () {
return this.b$['javax.swing.text.AbstractDocument'];
});

Clazz.newMethod$(C$, 'remove$I$I', function (offset, length) {
this.b$['javax.swing.text.AbstractDocument'].handleRemove$I$I(offset, length);
});

Clazz.newMethod$(C$, 'insertString$I$S$javax_swing_text_AttributeSet', function (offset, string, attr) {
this.b$['javax.swing.text.AbstractDocument'].handleInsertString$I$S$javax_swing_text_AttributeSet(offset, string, attr);
});

Clazz.newMethod$(C$, 'replace$I$I$S$javax_swing_text_AttributeSet', function (offset, length, text, attrs) {
this.b$['javax.swing.text.AbstractDocument'].handleRemove$I$I(offset, length);
this.b$['javax.swing.text.AbstractDocument'].handleInsertString$I$S$javax_swing_text_AttributeSet(offset, text, attrs);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:00
