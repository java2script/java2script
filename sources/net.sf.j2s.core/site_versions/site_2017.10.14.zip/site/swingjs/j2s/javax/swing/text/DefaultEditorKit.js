(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultEditorKit", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.EditorKit');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.defaultActions =  Clazz.newArray$(javax.swing.Action, -1, [Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').InsertContentAction)))), Clazz.new((I$[13] || (I$[13]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').DeletePrevCharAction)))), Clazz.new((I$[14] || (I$[14]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').DeleteNextCharAction)))), Clazz.new((I$[15] || (I$[15]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').ReadOnlyAction)))), Clazz.new((I$[16] || (I$[16]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').WritableAction)))), Clazz.new((I$[17] || (I$[17]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').CutAction)))), Clazz.new((I$[18] || (I$[18]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').CopyAction)))), Clazz.new((I$[19] || (I$[19]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').PasteAction)))), Clazz.new((I$[20] || (I$[20]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').VerticalPageAction))).c$$S$I$Z,["page-up", -1, false]), Clazz.new((I$[20] || (I$[20]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').VerticalPageAction))).c$$S$I$Z,["page-down", 1, false]), Clazz.new((I$[20] || (I$[20]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').VerticalPageAction))).c$$S$I$Z,["selection-page-up", -1, true]), Clazz.new((I$[20] || (I$[20]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').VerticalPageAction))).c$$S$I$Z,["selection-page-down", 1, true]), Clazz.new((I$[21] || (I$[21]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').PageAction))).c$$S$Z$Z,["selection-page-left", true, true]), Clazz.new((I$[21] || (I$[21]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').PageAction))).c$$S$Z$Z,["selection-page-right", false, true]), Clazz.new((I$[22] || (I$[22]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').InsertBreakAction)))), Clazz.new((I$[23] || (I$[23]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeepAction)))), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["caret-forward", false, 3]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["caret-backward", false, 7]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["selection-forward", true, 3]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["selection-backward", true, 7]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["caret-up", false, 1]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["caret-down", false, 5]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["selection-up", true, 1]), Clazz.new((I$[24] || (I$[24]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextVisualPositionAction))).c$$S$Z$I,["selection-down", true, 5]), Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginWordAction))).c$$S$Z,["caret-begin-word", false]), Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndWordAction))).c$$S$Z,["caret-end-word", false]), Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginWordAction))).c$$S$Z,["selection-begin-word", true]), Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndWordAction))).c$$S$Z,["selection-end-word", true]), Clazz.new((I$[25] || (I$[25]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').PreviousWordAction))).c$$S$Z,["caret-previous-word", false]), Clazz.new((I$[26] || (I$[26]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextWordAction))).c$$S$Z,["caret-next-word", false]), Clazz.new((I$[25] || (I$[25]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').PreviousWordAction))).c$$S$Z,["selection-previous-word", true]), Clazz.new((I$[26] || (I$[26]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').NextWordAction))).c$$S$Z,["selection-next-word", true]), Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginLineAction))).c$$S$Z,["caret-begin-line", false]), Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndLineAction))).c$$S$Z,["caret-end-line", false]), Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginLineAction))).c$$S$Z,["selection-begin-line", true]), Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndLineAction))).c$$S$Z,["selection-end-line", true]), Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginParagraphAction))).c$$S$Z,["caret-begin-paragraph", false]), Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndParagraphAction))).c$$S$Z,["caret-end-paragraph", false]), Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginParagraphAction))).c$$S$Z,["selection-begin-paragraph", true]), Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndParagraphAction))).c$$S$Z,["selection-end-paragraph", true]), Clazz.new((I$[27] || (I$[27]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginAction))).c$$S$Z,["caret-begin", false]), Clazz.new((I$[28] || (I$[28]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndAction))).c$$S$Z,["caret-end", false]), Clazz.new((I$[27] || (I$[27]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginAction))).c$$S$Z,["selection-begin", true]), Clazz.new((I$[28] || (I$[28]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndAction))).c$$S$Z,["selection-end", true]), Clazz.new((I$[29] || (I$[29]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').DefaultKeyTypedAction)))), Clazz.new((I$[30] || (I$[30]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').InsertTabAction)))), Clazz.new((I$[31] || (I$[31]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').SelectWordAction)))), Clazz.new((I$[32] || (I$[32]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').SelectLineAction)))), Clazz.new((I$[33] || (I$[33]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').SelectParagraphAction)))), Clazz.new((I$[34] || (I$[34]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').SelectAllAction)))), Clazz.new((I$[35] || (I$[35]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').UnselectAction)))), Clazz.new((I$[36] || (I$[36]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').ToggleComponentOrientationAction))))]);
};

C$.defaultActions = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'getContentType', function () {
return "text/plain";
});

Clazz.newMethod$(C$, 'getViewFactory', function () {
return null;
});

Clazz.newMethod$(C$, 'getActions', function () {
return C$.defaultActions;
});

Clazz.newMethod$(C$, 'createCaret', function () {
return null;
});

Clazz.newMethod$(C$, 'createDefaultDocument', function () {
return Clazz.new((I$[37] || (I$[37]=Clazz.load('swingjs.JSPlainDocument'))));
});

Clazz.newMethod$(C$, 'read$java_io_InputStream$javax_swing_text_Document$I', function ($in, doc, pos) {
this.read$java_io_Reader$javax_swing_text_Document$I(Clazz.new((I$[38] || (I$[38]=Clazz.load('java.io.InputStreamReader'))).c$$java_io_InputStream,[$in]), doc, pos);
});

Clazz.newMethod$(C$, 'write$java_io_OutputStream$javax_swing_text_Document$I$I', function (out, doc, pos, len) {
var osw = (I$[39] || (I$[39]=Clazz.load('swingjs.api.Interface'))).getInstanceWithParams$S$ClassA$OA("java.io.OutputStreamWriter",  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass(java.io.OutputStream)]),  Clazz.newArray$(java.lang.Object, -1, [out]));
this.write$java_io_Writer$javax_swing_text_Document$I$I(osw, doc, pos, len);
osw.flush();
});

Clazz.newMethod$(C$, 'getInputAttributes', function () {
return null;
});

Clazz.newMethod$(C$, 'read$java_io_Reader$javax_swing_text_Document$I', function ($in, doc, pos) {
var buff =  Clazz.newArray$(Character.TYPE, [4096]);
var nch;
var lastWasCR = false;
var isCRLF = false;
var isCR = false;
var last;
var wasEmpty = (doc.getLength() == 0);
var attr = this.getInputAttributes();
while ((nch = $in.read$CA$I$I(buff, 0, buff.length)) != -1){
last = 0;
for (var counter = 0; counter < nch; counter++) {
switch ((buff[counter]).$c()) {
case 13:
if (lastWasCR) {
isCR = true;
if (counter == 0) {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos, "\u000a", attr);
pos++;
} else {
buff[counter - 1] = '\u000a';
}} else {
lastWasCR = true;
}break;
case 10:
if (lastWasCR) {
if (counter > (last + 1)) {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos,  String.instantialize(buff, last, counter - last - 1 ), attr);
pos = pos+((counter - last - 1 ));
}lastWasCR = false;
last = counter;
isCRLF = true;
}break;
default:
if (lastWasCR) {
isCR = true;
if (counter == 0) {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos, "\u000a", attr);
pos++;
} else {
buff[counter - 1] = '\u000a';
}lastWasCR = false;
}break;
}
}
if (last < nch) {
if (lastWasCR) {
if (last < (nch - 1)) {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos,  String.instantialize(buff, last, nch - last - 1 ), attr);
pos = pos+((nch - last - 1 ));
}} else {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos,  String.instantialize(buff, last, nch - last), attr);
pos = pos+((nch - last));
}}}
if (lastWasCR) {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos, "\u000a", attr);
isCR = true;
}if (wasEmpty) {
if (isCRLF) {
doc.putProperty$O$O("__EndOfLine__", "\u000d\u000a");
} else if (isCR) {
doc.putProperty$O$O("__EndOfLine__", "\u000d");
} else {
doc.putProperty$O$O("__EndOfLine__", "\u000a");
}}});

Clazz.newMethod$(C$, 'write$java_io_Writer$javax_swing_text_Document$I$I', function (out, doc, pos, len) {
if ((pos < 0) || ((pos + len) > doc.getLength()) ) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["DefaultEditorKit.write", pos]);
}var data = Clazz.new((I$[40] || (I$[40]=Clazz.load('javax.swing.text.Segment'))));
var nleft = len;
var offs = pos;
var endOfLineProperty = doc.getProperty$O("__EndOfLine__");
if (endOfLineProperty == null ) {
try {
endOfLineProperty = System.getProperty("line.separator");
} catch (se) {
if (Clazz.exceptionOf(se, SecurityException)){
} else {
throw se;
}
}
}var endOfLine;
if (Clazz.instanceOf(endOfLineProperty, "java.lang.String")) {
endOfLine = endOfLineProperty;
} else {
endOfLine = null;
}if (endOfLineProperty != null  && !endOfLine.equals$O("\u000a") ) {
while (nleft > 0){
var n = Math.min(nleft, 4096);
doc.getText$I$I$javax_swing_text_Segment(offs, n, data);
var last = data.offset;
var array = data.array;
var maxCounter = last + data.count;
for (var counter = last; counter < maxCounter; counter++) {
if (array[counter] == '\u000a') {
if (counter > last) {
out.write$CA$I$I(array, last, counter - last);
}out.write$S(endOfLine);
last = counter + 1;
}}
if (maxCounter > last) {
out.write$CA$I$I(array, last, maxCounter - last);
}offs = offs+(n);
nleft = nleft-(n);
}
} else {
while (nleft > 0){
var n = Math.min(nleft, 4096);
doc.getText$I$I$javax_swing_text_Segment(offs, n, data);
out.write$CA$I$I(data.array, data.offset, data.count);
offs = offs+(n);
nleft = nleft-(n);
}
}out.flush();
});
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "DefaultKeyTypedAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["default-typed"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if ((target != null ) && (e != null ) ) {
if ((!target.isEditable()) || (!target.isEnabled()) ) {
return;
}var content = e.getActionCommand();
var mod = e.getModifiers();
if ((content != null ) && (content.length$() > 0) && ((mod & 8) == (mod & 2))  ) {
var c = content.charAt(0);
if ((c.$c() >= 32 ) && (c.$c() != 127 ) ) {
target.replaceSelection$S(content);
}}}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "InsertContentAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["insert-content"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if ((target != null ) && (e != null ) ) {
if ((!target.isEditable()) || (!target.isEnabled()) ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
return;
}var content = e.getActionCommand();
if (content != null ) {
target.replaceSelection$S(content);
} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
}}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "InsertBreakAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["insert-break"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
if ((!target.isEditable()) || (!target.isEnabled()) ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
return;
}target.replaceSelection$S("\u000a");
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "InsertTabAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["insert-tab"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
if ((!target.isEditable()) || (!target.isEnabled()) ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
return;
}target.replaceSelection$S("\u0009");
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "DeletePrevCharAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["delete-previous"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
var beep = true;
if ((target != null ) && (target.isEditable()) ) {
try {
var doc = target.getDocument();
var caret = target.getCaret();
var dot = caret.getDot();
var mark = caret.getMark();
if (dot != mark) {
doc.remove$I$I(Math.min(dot, mark), Math.abs(dot - mark));
beep = false;
} else if (dot > 0) {
var delChars = 1;
if (dot > 1) {
var dotChars = doc.getText$I$I(dot - 2, 2);
var c0 = dotChars.charAt(0);
var c1 = dotChars.charAt(1);
if (c0 >= '\ud800' && c0 <= '\udbff'  && c1 >= '\udc00'  && c1 <= '\udfff' ) {
delChars = 2;
}}doc.remove$I$I(dot - delChars, delChars);
beep = false;
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
} else {
throw bl;
}
}
}if (beep) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "DeleteNextCharAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["delete-next"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
var beep = true;
if ((target != null ) && (target.isEditable()) ) {
try {
var doc = target.getDocument();
var caret = target.getCaret();
var dot = caret.getDot();
var mark = caret.getMark();
if (dot != mark) {
doc.remove$I$I(Math.min(dot, mark), Math.abs(dot - mark));
beep = false;
} else if (dot < doc.getLength()) {
var delChars = 1;
if (dot < doc.getLength() - 1) {
var dotChars = doc.getText$I$I(dot, 2);
var c0 = dotChars.charAt(0);
var c1 = dotChars.charAt(1);
if (c0 >= '\ud800' && c0 <= '\udbff'  && c1 >= '\udc00'  && c1 <= '\udfff' ) {
delChars = 2;
}}doc.remove$I$I(dot, delChars);
beep = false;
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
} else {
throw bl;
}
}
}if (beep) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "ReadOnlyAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["set-read-only"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.setEditable$Z(false);
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "WritableAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["set-writable"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.setEditable$Z(true);
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "CutAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["cut-to-clipboard"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.cut();
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "CopyAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["copy-to-clipboard"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.copy();
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "PasteAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["paste-from-clipboard"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.paste();
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "BeepAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["beep"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "VerticalPageAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
this.direction = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$S$I$Z', function (nm, direction, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
this.direction = direction;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var visible = target.getVisibleRect();
var newVis = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[visible]);
var selectedIndex = target.getCaretPosition();
var scrollAmount = this.direction * target.getScrollableBlockIncrement$java_awt_Rectangle$I$I(visible, 1, this.direction);
var initialY = visible.y;
var caret = target.getCaret();
var magicPosition = caret.getMagicCaretPosition();
if (selectedIndex != -1) {
try {
var dotBounds = target.modelToView$I(selectedIndex);
var x = (magicPosition != null ) ? magicPosition.x : dotBounds.x;
var h = dotBounds.height;
if (h > 0) {
scrollAmount = ($i$[0] = scrollAmount/h, $i$[0]) * h;
}newVis.y = p$.constrainY$javax_swing_text_JTextComponent$I$I.apply(this, [target, initialY + scrollAmount, visible.height]);
var newIndex;
if (visible.contains$I$I(dotBounds.x, dotBounds.y)) {
newIndex = target.viewToModel$java_awt_Point(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[x, p$.constrainY$javax_swing_text_JTextComponent$I$I.apply(this, [target, dotBounds.y + scrollAmount, 0])]));
} else {
if (this.direction == -1) {
newIndex = target.viewToModel$java_awt_Point(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[x, newVis.y]));
} else {
newIndex = target.viewToModel$java_awt_Point(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[x, newVis.y + visible.height]));
}}newIndex = p$.constrainOffset$javax_swing_text_JTextComponent$I.apply(this, [target, newIndex]);
if (newIndex != selectedIndex) {
p$.adjustScrollIfNecessary$javax_swing_text_JTextComponent$java_awt_Rectangle$I$I.apply(this, [target, newVis, initialY, newIndex]);
if (this.select) {
target.moveCaretPosition$I(newIndex);
} else {
target.setCaretPosition$I(newIndex);
}}} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
} else {
newVis.y = p$.constrainY$javax_swing_text_JTextComponent$I$I.apply(this, [target, initialY + scrollAmount, visible.height]);
}if (magicPosition != null ) {
caret.setMagicCaretPosition$java_awt_Point(magicPosition);
}target.scrollRectToVisible$java_awt_Rectangle(newVis);
}});

Clazz.newMethod$(C$, 'constrainY$javax_swing_text_JTextComponent$I$I', function (target, y, vis) {
if (y < 0) {
y = 0;
} else if (y + vis > target.getHeight()) {
y = Math.max(0, target.getHeight() - vis);
}return y;
});

Clazz.newMethod$(C$, 'constrainOffset$javax_swing_text_JTextComponent$I', function (text, offset) {
var doc = text.getDocument();
if ((offset != 0) && (offset > doc.getLength()) ) {
offset = doc.getLength();
}if (offset < 0) {
offset = 0;
}return offset;
});

Clazz.newMethod$(C$, 'adjustScrollIfNecessary$javax_swing_text_JTextComponent$java_awt_Rectangle$I$I', function (text, visible, initialY, index) {
try {
var dotBounds = text.modelToView$I(index);
if (dotBounds.y < visible.y || (dotBounds.y > (visible.y + visible.height))  || (dotBounds.y + dotBounds.height) > (visible.y + visible.height) ) {
var y;
if (dotBounds.y < visible.y) {
y = dotBounds.y;
} else {
y = dotBounds.y + dotBounds.height - visible.height;
}if ((this.direction == -1 && y < initialY ) || (this.direction == 1 && y > initialY ) ) {
visible.y = y;
}}} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "PageAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
this.left = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z$Z', function (nm, left, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
this.left = left;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var selectedIndex;
var visible = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Rectangle'))));
target.computeVisibleRect$java_awt_Rectangle(visible);
if (this.left) {
visible.x = Math.max(0, visible.x - visible.width);
} else {
visible.x = visible.x+(visible.width);
}selectedIndex = target.getCaretPosition();
if (selectedIndex != -1) {
if (this.left) {
selectedIndex = target.viewToModel$java_awt_Point(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[visible.x, visible.y]));
} else {
selectedIndex = target.viewToModel$java_awt_Point(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[visible.x + visible.width - 1, visible.y + visible.height - 1]));
}var doc = target.getDocument();
if ((selectedIndex != 0) && (selectedIndex > (doc.getLength() - 1)) ) {
selectedIndex = doc.getLength() - 1;
} else if (selectedIndex < 0) {
selectedIndex = 0;
}if (this.select) target.moveCaretPosition$I(selectedIndex);
 else target.setCaretPosition$I(selectedIndex);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "NextVisualPositionAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
this.direction = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z$I', function (nm, select, direction) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
this.direction = direction;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var caret = target.getCaret();
var bidiCaret = (Clazz.instanceOf(caret, "javax.swing.text.DefaultCaret")) ? caret : null;
var dot = caret.getDot();
var bias =  Clazz.newArray$(javax.swing.text.Position.Bias, [1]);
var magicPosition = caret.getMagicCaretPosition();
try {
if (magicPosition == null  && (this.direction == 1 || this.direction == 5 ) ) {
var r = (bidiCaret != null ) ? (target.getUI()).modelToView$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias(target, dot, bidiCaret.getDotBias()) : target.modelToView$I(dot);
magicPosition = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Point'))).c$$I$I,[r.x, r.y]);
}var filter = target.getNavigationFilter();
if (filter != null ) {
dot = filter.getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(target, dot, (bidiCaret != null ) ? bidiCaret.getDotBias() : (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward, this.direction, bias);
} else {
dot = (target.getUI()).getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(target, dot, (bidiCaret != null ) ? bidiCaret.getDotBias() : (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward, this.direction, bias);
}if (bias[0] == null ) {
bias[0] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
}if (bidiCaret != null ) {
if (this.select) {
bidiCaret.moveDot$I$javax_swing_text_Position_Bias(dot, bias[0]);
} else {
bidiCaret.setDot$I$javax_swing_text_Position_Bias(dot, bias[0]);
}} else {
if (this.select) {
caret.moveDot$I(dot);
} else {
caret.setDot$I(dot);
}}if (magicPosition != null  && (this.direction == 1 || this.direction == 5 ) ) {
target.getCaret().setMagicCaretPosition$java_awt_Point(magicPosition);
}} catch (ex) {
if (Clazz.exceptionOf(ex, P$.BadLocationException)){
} else {
throw ex;
}
}
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "BeginWordAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
try {
var offs = target.getCaretPosition();
var begOffs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getWordStart$javax_swing_text_JTextComponent$I(target, offs);
if (this.select) {
target.moveCaretPosition$I(begOffs);
} else {
target.setCaretPosition$I(begOffs);
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
} else {
throw bl;
}
}
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "EndWordAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
try {
var offs = target.getCaretPosition();
var endOffs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getWordEnd$javax_swing_text_JTextComponent$I(target, offs);
if (this.select) {
target.moveCaretPosition$I(endOffs);
} else {
target.setCaretPosition$I(endOffs);
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
} else {
throw bl;
}
}
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "PreviousWordAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var offs = target.getCaretPosition();
var failed = false;
try {
var curPara = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getParagraphElement$javax_swing_text_JTextComponent$I(target, offs);
offs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getPreviousWord$javax_swing_text_JTextComponent$I(target, offs);
if (offs < curPara.getStartOffset()) {
offs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getParagraphElement$javax_swing_text_JTextComponent$I(target, offs).getEndOffset() - 1;
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
if (offs != 0) {
offs = 0;
} else {
failed = true;
}} else {
throw bl;
}
}
if (!failed) {
if (this.select) {
target.moveCaretPosition$I(offs);
} else {
target.setCaretPosition$I(offs);
}} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "NextWordAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var offs = target.getCaretPosition();
var failed = false;
var oldOffs = offs;
var curPara = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getParagraphElement$javax_swing_text_JTextComponent$I(target, offs);
try {
offs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getNextWord$javax_swing_text_JTextComponent$I(target, offs);
if (offs >= curPara.getEndOffset() && oldOffs != curPara.getEndOffset() - 1 ) {
offs = curPara.getEndOffset() - 1;
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
var end = target.getDocument().getLength();
if (offs != end) {
if (oldOffs != curPara.getEndOffset() - 1) {
offs = curPara.getEndOffset() - 1;
} else {
offs = end;
}} else {
failed = true;
}} else {
throw bl;
}
}
if (!failed) {
if (this.select) {
target.moveCaretPosition$I(offs);
} else {
target.setCaretPosition$I(offs);
}} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "BeginLineAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
try {
var offs = target.getCaretPosition();
var begOffs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getRowStart$javax_swing_text_JTextComponent$I(target, offs);
if (this.select) {
target.moveCaretPosition$I(begOffs);
} else {
target.setCaretPosition$I(begOffs);
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
} else {
throw bl;
}
}
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "EndLineAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
try {
var offs = target.getCaretPosition();
var endOffs = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getRowEnd$javax_swing_text_JTextComponent$I(target, offs);
if (this.select) {
target.moveCaretPosition$I(endOffs);
} else {
target.setCaretPosition$I(endOffs);
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(target);
} else {
throw bl;
}
}
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "BeginParagraphAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var offs = target.getCaretPosition();
var elem = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getParagraphElement$javax_swing_text_JTextComponent$I(target, offs);
offs = elem.getStartOffset();
if (this.select) {
target.moveCaretPosition$I(offs);
} else {
target.setCaretPosition$I(offs);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "EndParagraphAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var offs = target.getCaretPosition();
var elem = (I$[4] || (I$[4]=Clazz.load('javax.swing.text.Utilities'))).getParagraphElement$javax_swing_text_JTextComponent$I(target, offs);
offs = Math.min(target.getDocument().getLength(), elem.getEndOffset());
if (this.select) {
target.moveCaretPosition$I(offs);
} else {
target.setCaretPosition$I(offs);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "BeginAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
if (this.select) {
target.moveCaretPosition$I(0);
} else {
target.setCaretPosition$I(0);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "EndAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.select = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (nm, select) {
C$.superClazz.c$$S.apply(this, [nm]);
C$.$init$.apply(this);
this.select = select;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var doc = target.getDocument();
var dot = doc.getLength();
if (this.select) {
target.moveCaretPosition$I(dot);
} else {
target.setCaretPosition$I(dot);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "SelectWordAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.start = null;
this.end = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["select-word"]);
C$.$init$.apply(this);
this.start = Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginWordAction))).c$$S$Z,["pigdog", false]);
this.end = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndWordAction))).c$$S$Z,["pigdog", true]);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.start.actionPerformed$java_awt_event_ActionEvent(e);
this.end.actionPerformed$java_awt_event_ActionEvent(e);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "SelectLineAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.start = null;
this.end = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["select-line"]);
C$.$init$.apply(this);
this.start = Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginLineAction))).c$$S$Z,["pigdog", false]);
this.end = Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndLineAction))).c$$S$Z,["pigdog", true]);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.start.actionPerformed$java_awt_event_ActionEvent(e);
this.end.actionPerformed$java_awt_event_ActionEvent(e);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "SelectParagraphAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.start = null;
this.end = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["select-paragraph"]);
C$.$init$.apply(this);
this.start = Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').BeginParagraphAction))).c$$S$Z,["pigdog", false]);
this.end = Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').EndParagraphAction))).c$$S$Z,["pigdog", true]);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.start.actionPerformed$java_awt_event_ActionEvent(e);
this.end.actionPerformed$java_awt_event_ActionEvent(e);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "SelectAllAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["select-all"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var doc = target.getDocument();
target.setCaretPosition$I(0);
target.moveCaretPosition$I(doc.getLength());
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "UnselectAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["unselect"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
target.setCaretPosition$I(target.getCaretPosition());
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultEditorKit, "ToggleComponentOrientationAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["toggle-componentOrientation"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getTextComponent$java_awt_event_ActionEvent(e);
if (target != null ) {
var last = target.getComponentOrientation();
var next;
if (last === (I$[11] || (I$[11]=Clazz.load('java.awt.ComponentOrientation'))).RIGHT_TO_LEFT ) next = (I$[11] || (I$[11]=Clazz.load('java.awt.ComponentOrientation'))).LEFT_TO_RIGHT;
 else next = (I$[11] || (I$[11]=Clazz.load('java.awt.ComponentOrientation'))).RIGHT_TO_LEFT;
target.setComponentOrientation$java_awt_ComponentOrientation(next);
target.repaint();
}});
})()
})();
//Created 2017-10-14 13:32:01
