(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ProgressMonitor", function(){
Clazz.newInstance$(this, arguments);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.root = null;
this.dialog = null;
this.pane = null;
this.myBar = null;
this.noteLabel = null;
this.parentComponent = null;
this.note = null;
this.cancelOption = null;
this.message = null;
this.T0 = 0;
this.millisToDecideToPopup = 500;
this.millisToPopup = 2000;
this.min = 0;
this.max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$O$S$I$I', function (parentComponent, message, note, min, max) {
C$.c$$java_awt_Component$O$S$I$I$javax_swing_ProgressMonitor.apply(this, [parentComponent, message, note, min, max, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$O$S$I$I$javax_swing_ProgressMonitor', function (parentComponent, message, note, min, max, group) {
C$.$init$.apply(this);
this.min = min;
this.max = max;
this.parentComponent = parentComponent;
this.cancelOption =  Clazz.newArray$(java.lang.Object, [1]);
this.cancelOption[0] = (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("OptionPane.cancelButtonText");
this.message = message;
this.note = note;
if (group != null ) {
this.root = (group.root != null ) ? group.root : group;
this.T0 = this.root.T0;
this.dialog = this.root.dialog;
} else {
this.T0 = System.currentTimeMillis();
}}, 1);

Clazz.newMethod$(C$, 'setProgress$I', function (nv) {
if (nv >= this.max) {
this.close();
} else {
if (this.myBar != null ) {
this.myBar.setValue$I(nv);
} else {
var T = System.currentTimeMillis();
var dT = ($i$[0] = (T - this.T0), $i$[0]);
if (dT >= this.millisToDecideToPopup) {
var predictedCompletionTime;
if (nv > this.min) {
predictedCompletionTime = ($i$[0] = (dT * (this.max - this.min)/(nv - this.min)|0), $i$[0]);
} else {
predictedCompletionTime = this.millisToPopup;
}if (predictedCompletionTime >= this.millisToPopup) {
this.myBar = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.JProgressBar'))));
this.myBar.setMinimum$I(this.min);
this.myBar.setMaximum$I(this.max);
this.myBar.setValue$I(nv);
if (this.note != null ) this.noteLabel = Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.JLabel'))).c$$S,[this.note]);
this.pane = Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.ProgressMonitor').ProgressOptionPane))).c$$O, [this, null,  Clazz.newArray$(java.lang.Object, -1, [this.message, this.noteLabel, this.myBar])]);
this.dialog = this.pane.createDialog$java_awt_Component$S(this.parentComponent, (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getString$O("ProgressMonitor.progressText"));
this.dialog.show();
}}}}});

Clazz.newMethod$(C$, 'close', function () {
if (this.dialog != null ) {
this.dialog.setVisible$Z(false);
this.dialog.dispose();
this.dialog = null;
this.pane = null;
this.myBar = null;
}});

Clazz.newMethod$(C$, 'getMinimum', function () {
return this.min;
});

Clazz.newMethod$(C$, 'setMinimum$I', function (m) {
if (this.myBar != null ) {
this.myBar.setMinimum$I(m);
}this.min = m;
});

Clazz.newMethod$(C$, 'getMaximum', function () {
return this.max;
});

Clazz.newMethod$(C$, 'setMaximum$I', function (m) {
if (this.myBar != null ) {
this.myBar.setMaximum$I(m);
}this.max = m;
});

Clazz.newMethod$(C$, 'isCanceled', function () {
if (this.pane == null ) return false;
var v = this.pane.getValue();
return ((v != null ) && (this.cancelOption.length == 1) && (v.equals$O(this.cancelOption[0]))  );
});

Clazz.newMethod$(C$, 'setMillisToDecideToPopup$I', function (millisToDecideToPopup) {
this.millisToDecideToPopup = millisToDecideToPopup;
});

Clazz.newMethod$(C$, 'getMillisToDecideToPopup', function () {
return this.millisToDecideToPopup;
});

Clazz.newMethod$(C$, 'setMillisToPopup$I', function (millisToPopup) {
this.millisToPopup = millisToPopup;
});

Clazz.newMethod$(C$, 'getMillisToPopup', function () {
return this.millisToPopup;
});

Clazz.newMethod$(C$, 'setNote$S', function (note) {
this.note = note;
if (this.noteLabel != null ) {
this.noteLabel.setText$S(note);
}});

Clazz.newMethod$(C$, 'getNote', function () {
return this.note;
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.ProgressMonitor, "ProgressOptionPane", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.JOptionPane');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$O', function (messageList) {
C$.superClazz.c$$O$I$I$javax_swing_Icon$OA$O.apply(this, [messageList, 1, -1, null, this.b$['javax.swing.ProgressMonitor'].cancelOption, null]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getMaxCharactersPerLineCount', function () {
return 60;
});

Clazz.newMethod$(C$, 'createDialog$java_awt_Component$S', function (parentComponent, title) {
var dialog;
var window = (I$[0] || (I$[0]=Clazz.load('javax.swing.JOptionPane'))).getWindowForComponent$java_awt_Component(parentComponent);
if (Clazz.instanceOf(window, "java.awt.Frame")) {
dialog = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Frame$S$Z,[window, title, false]);
} else {
dialog = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Dialog$S$Z,[window, title, false]);
}if (Clazz.instanceOf(window, "javax.swing.SwingUtilities.SharedOwnerFrame")) {
var ownerShutdownListener = (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
dialog.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}var contentPane = dialog.getContentPane();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.BorderLayout')))));
contentPane.add$java_awt_Component$O(this, "Center");
dialog.pack();
dialog.setLocationRelativeTo$java_awt_Component(parentComponent);
dialog.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass$(P$, "ProgressMonitor$ProgressOptionPane$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('java.awt.event.WindowAdapter'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
this.gotFocus = false;
}, 1);

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (we) {
this.b$['javax.swing.ProgressMonitor.ProgressOptionPane'].setValue$O(this.b$['javax.swing.ProgressMonitor'].cancelOption[0]);
});

Clazz.newMethod$(C$, 'windowActivated$java_awt_event_WindowEvent', function (we) {
if (!this.gotFocus) {
this.b$['javax.swing.ProgressMonitor.ProgressOptionPane'].selectInitialValue();
this.gotFocus = true;
}});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.event.WindowAdapter'))), [this, null],P$.ProgressMonitor$ProgressOptionPane$1)));
this.addPropertyChangeListener$java_beans_PropertyChangeListener(((
(function(){var C$=Clazz.newClass$(P$, "ProgressMonitor$ProgressOptionPane$2", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'java.beans.PropertyChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (event) {
if (this.$finals.dialog.isVisible() && event.getSource() === this.b$['javax.swing.ProgressMonitor.ProgressOptionPane']   && (event.getPropertyName().equals$O("value") || event.getPropertyName().equals$O("inputValue") ) ) {
this.$finals.dialog.setVisible$Z(false);
this.$finals.dialog.dispose();
}});
})()
), Clazz.new((I$[5] || (I$[5]=Clazz.load(P$.ProgressMonitor$ProgressOptionPane$2))).$init$, [this, {dialog: dialog}])));
return dialog;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:48
