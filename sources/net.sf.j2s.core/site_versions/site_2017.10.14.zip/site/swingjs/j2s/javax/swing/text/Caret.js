(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newInterface$(P$, "Caret");

})();
//Created 2017-10-14 13:32:00
