(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JMenuBar", null, 'javax.swing.JComponent', 'javax.swing.MenuElement');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.selectionModel = null;
this.$paintBorder = false;
this.margin = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setSelectionModel$javax_swing_SingleSelectionModel(Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.DefaultSingleSelectionModel')))));
this.uiClassID = "MenuBarUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'getSelectionModel', function () {
return this.selectionModel;
});

Clazz.newMethod$(C$, 'setSelectionModel$javax_swing_SingleSelectionModel', function (model) {
var oldValue = this.selectionModel;
this.selectionModel = model;
this.firePropertyChange$S$O$O("selectionModel", oldValue, this.selectionModel);
});

Clazz.newMethod$(C$, 'add$javax_swing_JMenu', function (c) {
C$.superClazz.prototype.add$java_awt_Component.apply(this, [c]);
return c;
});

Clazz.newMethod$(C$, 'getMenu$I', function (index) {
var c = this.getComponentAtIndex$I(index);
if (Clazz.instanceOf(c, "javax.swing.JMenu")) return c;
return null;
});

Clazz.newMethod$(C$, 'getMenuCount', function () {
return this.getComponentCount();
});

Clazz.newMethod$(C$, 'setHelpMenu$javax_swing_JMenu', function (menu) {
throw Clazz.new((I$[1] || (I$[1]=Clazz.load('java.lang.Error'))).c$$S,["setHelpMenu() not yet implemented."]);
});

Clazz.newMethod$(C$, 'getHelpMenu', function () {
throw Clazz.new((I$[1] || (I$[1]=Clazz.load('java.lang.Error'))).c$$S,["getHelpMenu() not yet implemented."]);
});

Clazz.newMethod$(C$, 'getComponentAtIndex$I', function (i) {
if (i < 0 || i >= this.getComponentCount() ) {
return null;
}return this.getComponent$I(i);
});

Clazz.newMethod$(C$, 'getComponentIndex$java_awt_Component', function (c) {
var ncomponents = this.getComponentCount();
var component = this.getComponents();
for (var i = 0; i < ncomponents; i++) {
var comp = component[i];
if (comp === c ) return i;
}
return -1;
});

Clazz.newMethod$(C$, 'setSelected$java_awt_Component', function (sel) {
var model = this.getSelectionModel();
var index = this.getComponentIndex$java_awt_Component(sel);
model.setSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'isSelected', function () {
return this.selectionModel.isSelected();
});

Clazz.newMethod$(C$, 'isBorderPainted', function () {
return this.$paintBorder;
});

Clazz.newMethod$(C$, 'setBorderPainted$Z', function (b) {
{
}});

Clazz.newMethod$(C$, 'paintBorder$java_awt_Graphics', function (g) {
if (this.isBorderPainted()) {
C$.superClazz.prototype.paintBorder$java_awt_Graphics.apply(this, [g]);
}});

Clazz.newMethod$(C$, 'setMargin$java_awt_Insets', function (m) {
var old = this.margin;
this.margin = m;
this.firePropertyChange$S$O$O("margin", old, m);
if (old == null  || !old.equals$O(m) ) {
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'getMargin', function () {
if (this.margin == null ) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
} else {
return this.margin;
}});

Clazz.newMethod$(C$, 'processMouseEvent$java_awt_event_MouseEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (event, path, manager) {
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (e, path, manager) {
});

Clazz.newMethod$(C$, 'menuSelectionChanged$Z', function (isIncluded) {
});

Clazz.newMethod$(C$, 'getSubElements', function () {
var result;
var tmp = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.util.Vector'))));
var c = this.getComponentCount();
var i;
var m;
for (i = 0; i < c; i++) {
m = this.getComponent$I(i);
if (Clazz.instanceOf(m, "javax.swing.MenuElement")) tmp.addElement$TE(m);
}
result =  Clazz.newArray$(javax.swing.MenuElement, [tmp.size()]);
for (i = 0, c = tmp.size(); i < c; i++) result[i] = tmp.elementAt$I(i);

return result;
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this;
});

Clazz.newMethod$(C$, 'paramString', function () {
var paintBorderString = (this.$paintBorder ? "true" : "false");
var marginString = (this.margin != null  ? this.margin.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",margin=" + marginString + ",paintBorder=" + paintBorderString ;
});

Clazz.newMethod$(C$, 'processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z', function (ks, e, condition, pressed) {
var retValue = C$.superClazz.prototype.processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z.apply(this, [ks, e, condition, pressed]);
if (!retValue) {
var subElements = this.getSubElements();
for (var i = 0; i < subElements.length; i++) {
if (C$.processBindingForKeyStrokeRecursive$javax_swing_MenuElement$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z(subElements[i], ks, e, condition, pressed)) {
return true;
}}
}return retValue;
});

Clazz.newMethod$(C$, 'processBindingForKeyStrokeRecursive$javax_swing_MenuElement$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z', function (elem, ks, e, condition, pressed) {
if (elem == null ) {
return false;
}var c = elem.getComponent();
if (!(c.isVisible() || (Clazz.instanceOf(c, "javax.swing.JPopupMenu")) ) || !c.isEnabled() ) {
return false;
}if (c != null  && Clazz.instanceOf(c, "javax.swing.JComponent")  && (c).processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z(ks, e, condition, pressed) ) {
return true;
}var subElements = elem.getSubElements();
for (var i = 0; i < subElements.length; i++) {
if (C$.processBindingForKeyStrokeRecursive$javax_swing_MenuElement$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z(subElements[i], ks, e, condition, pressed)) {
return true;
}}
return false;
}, 1);

Clazz.newMethod$(C$, 'addNotify', function () {
C$.superClazz.prototype.addNotify.apply(this, []);
(I$[4] || (I$[4]=Clazz.load('javax.swing.KeyboardManager'))).getCurrentManager().registerMenuBar$javax_swing_JMenuBar(this);
});

Clazz.newMethod$(C$, 'removeNotify', function () {
C$.superClazz.prototype.removeNotify.apply(this, []);
(I$[4] || (I$[4]=Clazz.load('javax.swing.KeyboardManager'))).getCurrentManager().unregisterMenuBar$javax_swing_JMenuBar(this);
});
})();
//Created 2017-10-14 13:31:40
