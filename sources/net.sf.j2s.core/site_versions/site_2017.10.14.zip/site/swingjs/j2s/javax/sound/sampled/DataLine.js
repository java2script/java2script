(function(){var P$=Clazz.newPackage$("javax.sound.sampled"),I$=[];
var C$=Clazz.newInterface$(P$, "DataLine", function(){
}, null, 'javax.sound.sampled.Line');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

;
(function(){var C$=Clazz.newClass$(P$.DataLine, "Info", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.sound.sampled.Line.Info');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.formats = null;
this.minBufferSize = 0;
this.maxBufferSize = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$Class$javax_sound_sampled_AudioFormatA$I$I', function (lineClass, formats, minBufferSize, maxBufferSize) {
C$.superClazz.c$$Class.apply(this, [lineClass]);
C$.$init$.apply(this);
if (formats == null ) {
this.formats =  Clazz.newArray$(javax.sound.sampled.AudioFormat, [0]);
} else {
this.formats = formats;
}this.minBufferSize = minBufferSize;
this.maxBufferSize = maxBufferSize;
}, 1);

Clazz.newMethod$(C$, 'c$$Class$javax_sound_sampled_AudioFormat$I', function (lineClass, format, bufferSize) {
C$.superClazz.c$$Class.apply(this, [lineClass]);
C$.$init$.apply(this);
if (format == null ) {
this.formats =  Clazz.newArray$(javax.sound.sampled.AudioFormat, [0]);
} else {
var formats =  Clazz.newArray$(javax.sound.sampled.AudioFormat, -1, [format]);
this.formats = formats;
}this.minBufferSize = bufferSize;
this.maxBufferSize = bufferSize;
}, 1);

Clazz.newMethod$(C$, 'c$$Class$javax_sound_sampled_AudioFormat', function (lineClass, format) {
C$.c$$Class$javax_sound_sampled_AudioFormat$I.apply(this, [lineClass, format, -1]);
}, 1);

Clazz.newMethod$(C$, 'getFormats', function () {
var returnedArray =  Clazz.newArray$(javax.sound.sampled.AudioFormat, [this.formats.length]);
System.arraycopy(this.formats, 0, returnedArray, 0, this.formats.length);
return returnedArray;
});

Clazz.newMethod$(C$, 'isFormatSupported$javax_sound_sampled_AudioFormat', function (format) {
for (var i = 0; i < this.formats.length; i++) {
if (format.matches$javax_sound_sampled_AudioFormat(this.formats[i])) {
return true;
}}
return false;
});

Clazz.newMethod$(C$, 'getMinBufferSize', function () {
return this.minBufferSize;
});

Clazz.newMethod$(C$, 'getMaxBufferSize', function () {
return this.maxBufferSize;
});

Clazz.newMethod$(C$, 'matches$javax_sound_sampled_Line_Info', function (info) {
if (!(C$.superClazz.prototype.matches$javax_sound_sampled_Line_Info.apply(this, [info]))) {
return false;
}var dataLineInfo = info;
if ((this.getMaxBufferSize() >= 0) && (dataLineInfo.getMaxBufferSize() >= 0) ) {
if (this.getMaxBufferSize() > dataLineInfo.getMaxBufferSize()) {
return false;
}}if ((this.getMinBufferSize() >= 0) && (dataLineInfo.getMinBufferSize() >= 0) ) {
if (this.getMinBufferSize() < dataLineInfo.getMinBufferSize()) {
return false;
}}var localFormats = this.getFormats();
if (localFormats != null ) {
for (var i = 0; i < localFormats.length; i++) {
if (!(localFormats[i] == null )) {
if (!(dataLineInfo.isFormatSupported$javax_sound_sampled_AudioFormat(localFormats[i]))) {
return false;
}}}
}return true;
});

Clazz.newMethod$(C$, 'toString', function () {
var buf = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.lang.StringBuffer'))));
if ((this.formats.length == 1) && (this.formats[0] != null ) ) {
buf.append$S(" supporting format " + this.formats[0]);
} else if (this.getFormats().length > 1) {
buf.append$S(" supporting " + this.getFormats().length + " audio formats" );
}if ((this.minBufferSize != -1) && (this.maxBufferSize != -1) ) {
buf.append$S(", and buffers of " + this.minBufferSize + " to " + this.maxBufferSize + " bytes" );
} else if ((this.minBufferSize != -1) && (this.minBufferSize > 0) ) {
buf.append$S(", and buffers of at least " + this.minBufferSize + " bytes" );
} else if (this.maxBufferSize != -1) {
buf.append$S(", and buffers of up to " + this.minBufferSize + " bytes" );
}return  String.instantialize(C$.superClazz.prototype.toString.apply(this, []) + buf);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:29
