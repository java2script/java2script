(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JFileChooser", null, 'javax.swing.JComponent');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.dialogTitle = null;
this.approveButtonText = null;
this.approveButtonToolTipText = null;
this.approveButtonMnemonic = 0;
this.filters = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.ArrayList'))).c$$I,[5]);
this.dialog = null;
this.dialogType = 0;
this.returnValue = -1;
this.accessory = null;
this.fileView = null;
this.uiFileView = null;
this.controlsShown = true;
this.useFileHiding = true;
this.showFilesListener = null;
this.fileSelectionMode = 0;
this.multiSelectionEnabled = false;
this.useAcceptAllFileFilter = true;
this.dragEnabled = false;
this.fileFilter = null;
this.currentDirectory = null;
this.selectedFile = null;
this.selectedFiles = null;
this.lastFileName = "";
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_io_File.apply(this, [Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.File'))).c$$S,["."])]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (currentDirectoryPath) {
C$.c$$java_io_File.apply(this, [Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.File'))).c$$S,[currentDirectoryPath])]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_File', function (currentDirectory) {
Clazz.super(C$, this,1);
this.currentDirectory = currentDirectory;
}, 1);

Clazz.newMethod$(C$, 'setDragEnabled$Z', function (b) {
this.dragEnabled = b;
});

Clazz.newMethod$(C$, 'getDragEnabled', function () {
return this.dragEnabled;
});

Clazz.newMethod$(C$, 'getSelectedFile', function () {
return this.selectedFile;
});

Clazz.newMethod$(C$, 'setSelectedFile$java_io_File', function (file) {
var oldValue = this.selectedFile;
this.selectedFile = file;
if (this.selectedFile != null ) {
if (file.isAbsolute() && !p$.isParent$java_io_File$java_io_File.apply(this, [this.getCurrentDirectory(), this.selectedFile]) ) {
this.setCurrentDirectory$java_io_File(this.selectedFile.getParentFile());
}if (!this.isMultiSelectionEnabled() || this.selectedFiles == null   || this.selectedFiles.length == 1 ) {
this.ensureFileIsVisible$java_io_File(this.selectedFile);
}}this.firePropertyChange$S$O$O("SelectedFileChangedProperty", oldValue, this.selectedFile);
});

Clazz.newMethod$(C$, 'isParent$java_io_File$java_io_File', function (dir, file) {
return file.getPath().indexOf(dir.getPath() + "/") == 0;
});

Clazz.newMethod$(C$, 'getSelectedFiles', function () {
if (this.selectedFiles == null ) {
return  Clazz.newArray$(java.io.File, [0]);
} else {
return this.selectedFiles.clone();
}});

Clazz.newMethod$(C$, 'setSelectedFiles$java_io_FileA', function (selectedFiles) {
var oldValue = this.selectedFiles;
if (selectedFiles == null  || selectedFiles.length == 0 ) {
selectedFiles = null;
this.selectedFiles = null;
this.setSelectedFile$java_io_File(null);
} else {
this.selectedFiles = selectedFiles.clone();
this.setSelectedFile$java_io_File(this.selectedFiles[0]);
}this.firePropertyChange$S$O$O("SelectedFilesChangedProperty", oldValue, selectedFiles);
});

Clazz.newMethod$(C$, 'getCurrentDirectory', function () {
return this.currentDirectory;
});

Clazz.newMethod$(C$, 'setCurrentDirectory$java_io_File', function (dir) {
var oldValue = this.currentDirectory;
if (dir != null  && !dir.exists() ) {
dir = this.currentDirectory;
}this.firePropertyChange$S$O$O("directoryChanged", oldValue, this.currentDirectory);
});

Clazz.newMethod$(C$, 'changeToParentDirectory', function () {
this.selectedFile = null;
var oldValue = this.getCurrentDirectory();
this.setCurrentDirectory$java_io_File(p$.getParentDirectory$java_io_File.apply(this, [oldValue]));
});

Clazz.newMethod$(C$, 'getParentDirectory$java_io_File', function (f) {
var path = f.getPath();
if (path.endsWith$S("/")) path = path.substring(path.length$() - 1);
return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.File'))).c$$S,[path.substring(0, path.lastIndexOf("/"))]);
});

Clazz.newMethod$(C$, 'rescanCurrentDirectory', function () {
});

Clazz.newMethod$(C$, 'ensureFileIsVisible$java_io_File', function (f) {
});

Clazz.newMethod$(C$, 'showOpenDialog$java_awt_Component', function (parent) {
this.setDialogType$I(0);
return this.showDialog$java_awt_Component$S(parent, null);
});

Clazz.newMethod$(C$, 'showSaveDialog$java_awt_Component', function (parent) {
this.setDialogType$I(1);
return this.showDialog$java_awt_Component$S(parent, null);
});

Clazz.newMethod$(C$, 'showDialog$java_awt_Component$S', function (parent, approveButtonText) {
switch (this.dialogType) {
case 0:
return 1;
case 1:
var name = (I$[2] || (I$[2]=Clazz.load('swingjs.JSUtil'))).prompt$S$S(this.dialogTitle, this.lastFileName);
if (name == null ) return 1;
this.selectedFile = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.io.File'))).c$$S,[name]);
return 0;
case 2:
(I$[2] || (I$[2]=Clazz.load('swingjs.JSUtil'))).notImplemented$S("JFileChooser.CUSTOM_DIALOG");
return 1;
}
return 1;
});

Clazz.newMethod$(C$, 'createDialog$java_awt_Component', function (parent) {
var title = this.dialogTitle;
if (title == null ) title = "SwingJS";
var dialog;
var window = (I$[3] || (I$[3]=Clazz.load('javax.swing.JOptionPane'))).getWindowForComponent$java_awt_Component(parent);
if (Clazz.instanceOf(window, "java.awt.Frame")) {
dialog = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Frame$S$Z,[window, title, true]);
} else {
dialog = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Dialog$S$Z,[window, title, true]);
}dialog.setComponentOrientation$java_awt_ComponentOrientation(this.getComponentOrientation());
var contentPane = dialog.getContentPane();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.BorderLayout')))));
contentPane.add$java_awt_Component$O(this, "Center");
if ((I$[4] || (I$[4]=Clazz.load('javax.swing.JDialog'))).isDefaultLookAndFeelDecorated()) {
var supportsWindowDecorations = (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getSupportsWindowDecorations();
if (supportsWindowDecorations) {
dialog.getRootPane().setWindowDecorationStyle$I(6);
}}dialog.pack();
dialog.setLocationRelativeTo$java_awt_Component(parent);
return dialog;
});

Clazz.newMethod$(C$, 'getControlButtonsAreShown', function () {
return this.controlsShown;
});

Clazz.newMethod$(C$, 'setControlButtonsAreShown$Z', function (b) {
if (this.controlsShown == b ) {
return;
}var oldValue = this.controlsShown;
this.controlsShown = b;
this.firePropertyChange$S$Z$Z("ControlButtonsAreShownChangedProperty", oldValue, this.controlsShown);
});

Clazz.newMethod$(C$, 'getDialogType', function () {
return this.dialogType;
});

Clazz.newMethod$(C$, 'setDialogType$I', function (dialogType) {
if (this.dialogType == dialogType) {
return;
}if (!(dialogType == 0 || dialogType == 1  || dialogType == 2 )) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Incorrect Dialog Type: " + dialogType]);
}var oldValue = this.dialogType;
this.dialogType = dialogType;
if (dialogType == 0 || dialogType == 1 ) {
this.setApproveButtonText$S(null);
}this.firePropertyChange$S$I$I("DialogTypeChangedProperty", oldValue, dialogType);
});

Clazz.newMethod$(C$, 'setDialogTitle$S', function (dialogTitle) {
var oldValue = this.dialogTitle;
this.dialogTitle = dialogTitle;
if (this.dialog != null ) {
this.dialog.setTitle$S(dialogTitle);
}this.firePropertyChange$S$O$O("DialogTitleChangedProperty", oldValue, dialogTitle);
});

Clazz.newMethod$(C$, 'getDialogTitle', function () {
return this.dialogTitle;
});

Clazz.newMethod$(C$, 'setApproveButtonToolTipText$S', function (toolTipText) {
if (this.approveButtonToolTipText == toolTipText) {
return;
}var oldValue = this.approveButtonToolTipText;
this.approveButtonToolTipText = toolTipText;
this.firePropertyChange$S$O$O("ApproveButtonToolTipTextChangedProperty", oldValue, this.approveButtonToolTipText);
});

Clazz.newMethod$(C$, 'getApproveButtonToolTipText', function () {
return this.approveButtonToolTipText;
});

Clazz.newMethod$(C$, 'getApproveButtonMnemonic', function () {
return this.approveButtonMnemonic;
});

Clazz.newMethod$(C$, 'setApproveButtonMnemonic$I', function (mnemonic) {
if (this.approveButtonMnemonic == mnemonic) {
return;
}var oldValue = this.approveButtonMnemonic;
this.approveButtonMnemonic = mnemonic;
this.firePropertyChange$S$I$I("ApproveButtonMnemonicChangedProperty", oldValue, this.approveButtonMnemonic);
});

Clazz.newMethod$(C$, 'setApproveButtonMnemonic$C', function (mnemonic) {
var vk = mnemonic.$c();
if (vk >= 97  && vk <= 122  ) {
vk = vk-(32);
}this.setApproveButtonMnemonic$I(vk);
});

Clazz.newMethod$(C$, 'setApproveButtonText$S', function (approveButtonText) {
if (this.approveButtonText == approveButtonText) {
return;
}var oldValue = this.approveButtonText;
this.approveButtonText = approveButtonText;
this.firePropertyChange$S$O$O("ApproveButtonTextChangedProperty", oldValue, approveButtonText);
});

Clazz.newMethod$(C$, 'getApproveButtonText', function () {
return this.approveButtonText;
});

Clazz.newMethod$(C$, 'getChoosableFileFilters', function () {
var filterArray =  Clazz.newArray$(javax.swing.filechooser.FileFilter, [this.filters.size()]);
this.filters.toArray$TTA(filterArray);
return filterArray;
});

Clazz.newMethod$(C$, 'addChoosableFileFilter$javax_swing_filechooser_FileFilter', function (filter) {
if (filter != null  && !this.filters.contains$O(filter) ) {
var oldValue = this.getChoosableFileFilters();
this.filters.add$TE(filter);
this.firePropertyChange$S$O$O("ChoosableFileFilterChangedProperty", oldValue, this.getChoosableFileFilters());
if (this.fileFilter == null  && this.filters.size() == 1 ) {
this.setFileFilter$javax_swing_filechooser_FileFilter(filter);
}}});

Clazz.newMethod$(C$, 'removeChoosableFileFilter$javax_swing_filechooser_FileFilter', function (f) {
if (this.filters.contains$O(f)) {
if (this.getFileFilter() === f ) {
this.setFileFilter$javax_swing_filechooser_FileFilter(null);
}var oldValue = this.getChoosableFileFilters();
this.filters.remove$O(f);
this.firePropertyChange$S$O$O("ChoosableFileFilterChangedProperty", oldValue, this.getChoosableFileFilters());
return true;
} else {
return false;
}});

Clazz.newMethod$(C$, 'resetChoosableFileFilters', function () {
var oldValue = this.getChoosableFileFilters();
this.setFileFilter$javax_swing_filechooser_FileFilter(null);
this.filters.clear();
if (this.isAcceptAllFileFilterUsed()) {
this.addChoosableFileFilter$javax_swing_filechooser_FileFilter(this.getAcceptAllFileFilter());
}this.firePropertyChange$S$O$O("ChoosableFileFilterChangedProperty", oldValue, this.getChoosableFileFilters());
});

Clazz.newMethod$(C$, 'getAcceptAllFileFilter', function () {
return Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.filechooser.FileFilter'))).c$$SA,[ Clazz.newArray$(java.lang.String, -1, ["*.*", "All Files"])]);
});

Clazz.newMethod$(C$, 'isAcceptAllFileFilterUsed', function () {
return this.useAcceptAllFileFilter;
});

Clazz.newMethod$(C$, 'setAcceptAllFileFilterUsed$Z', function (b) {
var oldValue = this.useAcceptAllFileFilter;
this.useAcceptAllFileFilter = b;
if (!b) {
this.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(this.getAcceptAllFileFilter());
} else {
this.removeChoosableFileFilter$javax_swing_filechooser_FileFilter(this.getAcceptAllFileFilter());
this.addChoosableFileFilter$javax_swing_filechooser_FileFilter(this.getAcceptAllFileFilter());
}this.firePropertyChange$S$Z$Z("acceptAllFileFilterUsedChanged", oldValue, this.useAcceptAllFileFilter);
});

Clazz.newMethod$(C$, 'getAccessory', function () {
return this.accessory;
});

Clazz.newMethod$(C$, 'setAccessory$javax_swing_JComponent', function (newAccessory) {
var oldValue = this.accessory;
this.accessory = newAccessory;
this.firePropertyChange$S$O$O("AccessoryChangedProperty", oldValue, this.accessory);
});

Clazz.newMethod$(C$, 'setFileSelectionMode$I', function (mode) {
if (this.fileSelectionMode == mode) {
return;
}if ((mode == 0) || (mode == 1) || (mode == 2)  ) {
var oldValue = this.fileSelectionMode;
this.fileSelectionMode = mode;
this.firePropertyChange$S$I$I("fileSelectionChanged", oldValue, this.fileSelectionMode);
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Incorrect Mode for file selection: " + mode]);
}});

Clazz.newMethod$(C$, 'getFileSelectionMode', function () {
return this.fileSelectionMode;
});

Clazz.newMethod$(C$, 'isFileSelectionEnabled', function () {
return ((this.fileSelectionMode == 0) || (this.fileSelectionMode == 2) );
});

Clazz.newMethod$(C$, 'isDirectorySelectionEnabled', function () {
return ((this.fileSelectionMode == 1) || (this.fileSelectionMode == 2) );
});

Clazz.newMethod$(C$, 'setMultiSelectionEnabled$Z', function (b) {
if (this.multiSelectionEnabled == b ) {
return;
}var oldValue = this.multiSelectionEnabled;
this.multiSelectionEnabled = b;
this.firePropertyChange$S$Z$Z("MultiSelectionEnabledChangedProperty", oldValue, this.multiSelectionEnabled);
});

Clazz.newMethod$(C$, 'isMultiSelectionEnabled', function () {
return this.multiSelectionEnabled;
});

Clazz.newMethod$(C$, 'isFileHidingEnabled', function () {
return this.useFileHiding;
});

Clazz.newMethod$(C$, 'setFileHidingEnabled$Z', function (b) {
if (this.showFilesListener != null ) {
(I$[8] || (I$[8]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit().removePropertyChangeListener$S$java_beans_PropertyChangeListener("awt.file.showHiddenFiles", this.showFilesListener);
this.showFilesListener = null;
}var oldValue = this.useFileHiding;
this.useFileHiding = b;
this.firePropertyChange$S$Z$Z("FileHidingChanged", oldValue, this.useFileHiding);
});

Clazz.newMethod$(C$, 'setFileFilter$javax_swing_filechooser_FileFilter', function (filter) {
var oldValue = this.fileFilter;
this.fileFilter = filter;
if (filter != null ) {
if (this.isMultiSelectionEnabled() && this.selectedFiles != null   && this.selectedFiles.length > 0 ) {
var fList = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.ArrayList'))));
var failed = false;
for (var i = 0; i < this.selectedFiles.length; i++) {
if (filter.accept$java_io_File(this.selectedFiles[i])) {
fList.add$TE(this.selectedFiles[i]);
} else {
failed = true;
}}
if (failed) {
this.setSelectedFiles$java_io_FileA((fList.size() == 0) ? null : fList.toArray$TTA( Clazz.newArray$(java.io.File, [fList.size()])));
}} else if (this.selectedFile != null  && !filter.accept$java_io_File(this.selectedFile) ) {
this.setSelectedFile$java_io_File(null);
}}this.firePropertyChange$S$O$O("fileFilterChanged", oldValue, this.fileFilter);
});

Clazz.newMethod$(C$, 'getFileFilter', function () {
return this.fileFilter;
});

Clazz.newMethod$(C$, 'setFileView$javax_swing_filechooser_FileView', function (fileView) {
var oldValue = this.fileView;
this.fileView = fileView;
this.firePropertyChange$S$O$O("fileViewChanged", oldValue, fileView);
});

Clazz.newMethod$(C$, 'getFileView', function () {
return this.fileView;
});

Clazz.newMethod$(C$, 'getName$java_io_File', function (f) {
var filename = null;
if (f != null ) {
if (this.getFileView() != null ) {
filename = this.getFileView().getName$java_io_File(f);
}if (filename == null  && this.uiFileView != null  ) {
filename = this.uiFileView.getName$java_io_File(f);
}}return filename;
});

Clazz.newMethod$(C$, 'getDescription$java_io_File', function (f) {
var description = null;
if (f != null ) {
if (this.getFileView() != null ) {
description = this.getFileView().getDescription$java_io_File(f);
}if (description == null  && this.uiFileView != null  ) {
description = this.uiFileView.getDescription$java_io_File(f);
}}return description;
});

Clazz.newMethod$(C$, 'getTypeDescription$java_io_File', function (f) {
var typeDescription = null;
if (f != null ) {
if (this.getFileView() != null ) {
typeDescription = this.getFileView().getTypeDescription$java_io_File(f);
}if (typeDescription == null  && this.uiFileView != null  ) {
typeDescription = this.uiFileView.getTypeDescription$java_io_File(f);
}}return typeDescription;
});

Clazz.newMethod$(C$, 'getIcon$java_io_File', function (f) {
var icon = null;
if (f != null ) {
if (this.getFileView() != null ) {
icon = this.getFileView().getIcon$java_io_File(f);
}if (icon == null  && this.uiFileView != null  ) {
icon = this.uiFileView.getIcon$java_io_File(f);
}}return icon;
});

Clazz.newMethod$(C$, 'accept$java_io_File', function (f) {
var shown = true;
if (f != null  && this.fileFilter != null  ) {
shown = this.fileFilter.accept$java_io_File(f);
}return shown;
});

Clazz.newMethod$(C$, 'approveSelection', function () {
this.returnValue = 0;
if (this.dialog != null ) {
this.dialog.setVisible$Z(false);
}this.fireActionPerformed$S("ApproveSelection");
});

Clazz.newMethod$(C$, 'cancelSelection', function () {
this.returnValue = 1;
if (this.dialog != null ) {
this.dialog.setVisible$Z(false);
}this.fireActionPerformed$S("CancelSelection");
});

Clazz.newMethod$(C$, 'addActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'getActionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ActionListener));
});

Clazz.newMethod$(C$, 'fireActionPerformed$S', function (command) {
var listeners = this.listenerList.getListenerList();
var mostRecentEventTime = (I$[9] || (I$[9]=Clazz.load('java.awt.EventQueue'))).getMostRecentEventTime();
var modifiers = 0;
var currentEvent = (I$[9] || (I$[9]=Clazz.load('java.awt.EventQueue'))).getCurrentEvent();
if (Clazz.instanceOf(currentEvent, "java.awt.event.InputEvent")) {
modifiers = (currentEvent).getModifiers();
} else if (Clazz.instanceOf(currentEvent, "java.awt.event.ActionEvent")) {
modifiers = (currentEvent).getModifiers();
}var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ActionListener) ) {
if (e == null ) {
e = Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S$J$I,[this, 1001, command, mostRecentEventTime, modifiers]);
}(listeners[i + 1]).actionPerformed$java_awt_event_ActionEvent(e);
}}
});

Clazz.newMethod$(C$, 'paramString', function () {
var approveButtonTextString = (this.approveButtonText != null  ? this.approveButtonText : "");
var dialogTitleString = (this.dialogTitle != null  ? this.dialogTitle : "");
var dialogTypeString;
if (this.dialogType == 0) {
dialogTypeString = "OPEN_DIALOG";
} else if (this.dialogType == 1) {
dialogTypeString = "SAVE_DIALOG";
} else if (this.dialogType == 2) {
dialogTypeString = "CUSTOM_DIALOG";
} else dialogTypeString = "";
var returnValueString;
if (this.returnValue == 1) {
returnValueString = "CANCEL_OPTION";
} else if (this.returnValue == 0) {
returnValueString = "APPROVE_OPTION";
} else if (this.returnValue == -1) {
returnValueString = "ERROR_OPTION";
} else returnValueString = "";
var useFileHidingString = (this.useFileHiding ? "true" : "false");
var fileSelectionModeString;
if (this.fileSelectionMode == 0) {
fileSelectionModeString = "FILES_ONLY";
} else if (this.fileSelectionMode == 1) {
fileSelectionModeString = "DIRECTORIES_ONLY";
} else if (this.fileSelectionMode == 2) {
fileSelectionModeString = "FILES_AND_DIRECTORIES";
} else fileSelectionModeString = "";
var currentDirectoryString = (this.currentDirectory != null  ? this.currentDirectory.toString() : "");
var selectedFileString = (this.selectedFile != null  ? this.selectedFile.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",approveButtonText=" + approveButtonTextString + ",currentDirectory=" + currentDirectoryString + ",dialogTitle=" + dialogTitleString + ",dialogType=" + dialogTypeString + ",fileSelectionMode=" + fileSelectionModeString + ",returnValue=" + returnValueString + ",selectedFile=" + selectedFileString + ",useFileHiding=" + useFileHidingString ;
});
})();
//Created 2017-10-14 13:31:38
