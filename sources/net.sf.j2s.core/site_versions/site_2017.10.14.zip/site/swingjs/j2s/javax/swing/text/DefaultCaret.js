(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultCaret", function(){
Clazz.newInstance$(this, arguments);
}, 'java.awt.Rectangle', ['javax.swing.text.Caret', 'java.awt.event.FocusListener', 'java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.selectWord = null;
C$.selectLine = null;
};

C$.selectWord = null;
C$.selectLine = null;

Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.event.EventListenerList'))));
this.changeEvent = null;
this.component = null;
this.updatePolicy = 0;
this.visible = false;
this.active = false;
this.dot = 0;
this.mark = 0;
this.selectionTag = null;
this.selectionVisible = false;
this.magicCaretPosition = null;
this.dotBias = null;
this.markBias = null;
this.dotLTR = false;
this.markLTR = false;
this.handler = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.DefaultCaret').Handler))), [this, null]);
this.flagXPoints =  Clazz.newArray$(Integer.TYPE, [3]);
this.flagYPoints =  Clazz.newArray$(Integer.TYPE, [3]);
this.filterBypass = null;
this.ownsSelection = false;
this.forceCaretPositionChange = false;
this.shouldHandleRelease = false;
this.selectedWordEvent = null;
this.caretWidth = -1;
this.aspectRatio = -1;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'setUpdatePolicy$I', function (policy) {
this.updatePolicy = policy;
});

Clazz.newMethod$(C$, 'getUpdatePolicy', function () {
return this.updatePolicy;
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this.component;
});

Clazz.newMethod$(C$, 'repaint', function () {
if (this.component != null ) {
this.component.repaint$I$I$I$I(this.x, this.y, this.width, this.height);
}});

Clazz.newMethod$(C$, 'damage$java_awt_Rectangle', function (r) {
if (r != null ) {
var damageWidth = this.getCaretWidth$I(r.height);
this.x = r.x - 4 - (damageWidth >> 1) ;
this.y = r.y;
this.width = 9 + damageWidth;
this.height = r.height;
this.repaint();
}});

Clazz.newMethod$(C$, 'adjustVisibility$java_awt_Rectangle', function (nloc) {
if (this.component == null ) {
return;
}if ((I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread()) {
this.component.scrollRectToVisible$java_awt_Rectangle(nloc);
} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.DefaultCaret').SafeScroller))).c$$java_awt_Rectangle, [this, null, nloc]));
}});

Clazz.newMethod$(C$, 'getSelectionPainter', function () {
return (I$[6] || (I$[6]=Clazz.load('javax.swing.text.DefaultHighlighter'))).DefaultPainter;
});

Clazz.newMethod$(C$, 'positionCaret$java_awt_event_MouseEvent', function (e) {
var pt = Clazz.new((I$[7] || (I$[7]=Clazz.load('java.awt.Point'))).c$$I$I,[e.getX(), e.getY()]);
var biasRet =  Clazz.newArray$(javax.swing.text.Position.Bias, [1]);
var pos = (this.component.getUI()).viewToModel$javax_swing_text_JTextComponent$java_awt_Point$javax_swing_text_Position_BiasA(this.component, pt, biasRet);
if (biasRet[0] == null ) biasRet[0] = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
if (pos >= 0) {
this.setDot$I$javax_swing_text_Position_Bias(pos, biasRet[0]);
}});

Clazz.newMethod$(C$, 'moveCaret$java_awt_event_MouseEvent', function (e) {
var pt = Clazz.new((I$[7] || (I$[7]=Clazz.load('java.awt.Point'))).c$$I$I,[e.getX(), e.getY()]);
var biasRet =  Clazz.newArray$(javax.swing.text.Position.Bias, [1]);
var pos = (this.component.getUI()).viewToModel$javax_swing_text_JTextComponent$java_awt_Point$javax_swing_text_Position_BiasA(this.component, pt, biasRet);
if (biasRet[0] == null ) biasRet[0] = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
if (pos >= 0) {
this.moveDot$I$javax_swing_text_Position_Bias(pos, biasRet[0]);
}});

Clazz.newMethod$(C$, 'focusGained$java_awt_event_FocusEvent', function (e) {
if (this.component.isEnabled()) {
if (this.component.isEditable()) {
this.setVisible$Z(true);
}this.setSelectionVisible$Z(true);
}});

Clazz.newMethod$(C$, 'focusLost$java_awt_event_FocusEvent', function (e) {
this.setVisible$Z(false);
this.setSelectionVisible$Z(this.ownsSelection || e.isTemporary() );
});

Clazz.newMethod$(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
var nclicks = e.getClickCount();
if (!e.isConsumed()) {
if ((I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isLeftMouseButton$java_awt_event_MouseEvent(e)) {
if (nclicks == 1) {
this.selectedWordEvent = null;
}} else if ((I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isMiddleMouseButton$java_awt_event_MouseEvent(e)) {
}}});

Clazz.newMethod$(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
if ((I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isLeftMouseButton$java_awt_event_MouseEvent(e)) {
if (e.isConsumed()) {
this.shouldHandleRelease = true;
} else {
this.shouldHandleRelease = false;
this.adjustCaretAndFocus$java_awt_event_MouseEvent(e);
}}});

Clazz.newMethod$(C$, 'adjustCaretAndFocus$java_awt_event_MouseEvent', function (e) {
p$.adjustCaret$java_awt_event_MouseEvent.apply(this, [e]);
p$.adjustFocus$Z.apply(this, [false]);
});

Clazz.newMethod$(C$, 'adjustCaret$java_awt_event_MouseEvent', function (e) {
if ((e.getModifiers() & 1) != 0 && this.getDot() != -1 ) {
this.moveCaret$java_awt_event_MouseEvent(e);
} else {
this.positionCaret$java_awt_event_MouseEvent(e);
}});

Clazz.newMethod$(C$, 'adjustFocus$Z', function (inWindow) {
if ((this.component != null ) && this.component.isEnabled() && this.component.isRequestFocusEnabled()  ) {
if (inWindow) {
this.component.requestFocusInWindow();
} else {
this.component.requestFocus();
}}});

Clazz.newMethod$(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
if (!e.isConsumed() && this.shouldHandleRelease && (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isLeftMouseButton$java_awt_event_MouseEvent(e)  ) {
this.adjustCaretAndFocus$java_awt_event_MouseEvent(e);
}});

Clazz.newMethod$(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
if ((!e.isConsumed()) && (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isLeftMouseButton$java_awt_event_MouseEvent(e) ) {
this.moveCaret$java_awt_event_MouseEvent(e);
}});

Clazz.newMethod$(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
if (this.isVisible()) {
try {
var mapper = this.component.getUI();
var r = mapper.modelToView$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias(this.component, this.dot, this.dotBias);
if ((r == null ) || ((r.width == 0) && (r.height == 0) ) ) {
return;
}if (this.width > 0 && this.height > 0  && !this._contains$I$I$I$I(r.x, r.y, r.width, r.height) ) {
var clip = g.getClipBounds();
if (clip != null  && !clip.contains$java_awt_Rectangle(this) ) {
this.repaint();
}this.damage$java_awt_Rectangle(r);
}g.setColor$java_awt_Color(this.component.getCaretColor());
var paintWidth = this.getCaretWidth$I(r.height);
r.x = r.x-(paintWidth >> 1);
g.fillRect$I$I$I$I(r.x, r.y, paintWidth, r.height);
var doc = this.component.getDocument();
if (Clazz.instanceOf(doc, "javax.swing.text.AbstractDocument")) {
var bidi = (doc).getBidiRootElement();
if ((bidi != null ) && (bidi.getElementCount() > 1) ) {
this.flagXPoints[0] = r.x + ((this.dotLTR) ? paintWidth : 0);
this.flagYPoints[0] = r.y;
this.flagXPoints[1] = this.flagXPoints[0];
this.flagYPoints[1] = this.flagYPoints[0] + 4;
this.flagXPoints[2] = this.flagXPoints[0] + ((this.dotLTR) ? 4 : -4);
this.flagYPoints[2] = this.flagYPoints[0];
g.fillPolygon$IA$IA$I(this.flagXPoints, this.flagYPoints, 3);
}}} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'install$javax_swing_text_JTextComponent', function (c) {
this.component = c;
var doc = c.getDocument();
this.dot = this.mark = 0;
this.dotLTR = this.markLTR = true;
this.dotBias = this.markBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
if (doc != null ) {
doc.addDocumentListener$javax_swing_event_DocumentListener(this.handler);
}c.addPropertyChangeListener$java_beans_PropertyChangeListener(this.handler);
c.addFocusListener$java_awt_event_FocusListener(this);
c.addMouseListener$java_awt_event_MouseListener(this);
c.addMouseMotionListener$java_awt_event_MouseMotionListener(this);
if (this.component.hasFocus()) {
this.focusGained$java_awt_event_FocusEvent(null);
}var ratio = c.getClientProperty$O("caretAspectRatio");
if (ratio != null ) {
this.aspectRatio = ratio.floatValue();
} else {
this.aspectRatio = -1;
}var width = c.getClientProperty$O("caretWidth");
if (width != null ) {
this.caretWidth = width.intValue();
} else {
this.caretWidth = -1;
}});

Clazz.newMethod$(C$, 'deinstall$javax_swing_text_JTextComponent', function (c) {
c.removeMouseListener$java_awt_event_MouseListener(this);
c.removeMouseMotionListener$java_awt_event_MouseMotionListener(this);
c.removeFocusListener$java_awt_event_FocusListener(this);
c.removePropertyChangeListener$java_beans_PropertyChangeListener(this.handler);
var doc = c.getDocument();
if (doc != null ) {
doc.removeDocumentListener$javax_swing_event_DocumentListener(this.handler);
}{
this.component = null;
}});

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'getChangeListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ChangeListener));
});

Clazz.newMethod$(C$, 'fireStateChanged', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ChangeListener) ) {
if (this.changeEvent == null ) this.changeEvent = Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
(listeners[i + 1]).stateChanged$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'setSelectionVisible$Z', function (vis) {
if (vis != this.selectionVisible ) {
this.selectionVisible = vis;
if (this.selectionVisible) {
var h = this.component.getHighlighter();
if ((this.dot != this.mark) && (h != null ) && (this.selectionTag == null )  ) {
var p0 = Math.min(this.dot, this.mark);
var p1 = Math.max(this.dot, this.mark);
var p = this.getSelectionPainter();
try {
this.selectionTag = h.addHighlight$I$I$javax_swing_text_Highlighter_HighlightPainter(p0, p1, p);
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
this.selectionTag = null;
} else {
throw bl;
}
}
}} else {
if (this.selectionTag != null ) {
var h = this.component.getHighlighter();
h.removeHighlight$O(this.selectionTag);
this.selectionTag = null;
}}}});

Clazz.newMethod$(C$, 'isSelectionVisible', function () {
return this.selectionVisible;
});

Clazz.newMethod$(C$, 'isActive', function () {
return this.active;
});

Clazz.newMethod$(C$, 'isVisible', function () {
return this.visible;
});

Clazz.newMethod$(C$, 'setVisible$Z', function (e) {
if (this.component != null ) {
this.active = e;
var mapper = this.component.getUI();
if (this.visible != e ) {
this.visible = e;
try {
var loc = mapper.modelToView$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias(this.component, this.dot, this.dotBias);
this.damage$java_awt_Rectangle(loc);
} catch (badloc) {
if (Clazz.exceptionOf(badloc, P$.BadLocationException)){
} else {
throw badloc;
}
}
}}});

Clazz.newMethod$(C$, 'setBlinkRate$I', function (rate) {
});

Clazz.newMethod$(C$, 'getBlinkRate', function () {
return 0;
});

Clazz.newMethod$(C$, 'getDot', function () {
return this.dot;
});

Clazz.newMethod$(C$, 'getMark', function () {
return this.mark;
});

Clazz.newMethod$(C$, 'setDot$I', function (dot) {
this.setDot$I$javax_swing_text_Position_Bias(dot, (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward);
});

Clazz.newMethod$(C$, 'moveDot$I', function (dot) {
this.moveDot$I$javax_swing_text_Position_Bias(dot, (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward);
});

Clazz.newMethod$(C$, 'moveDot$I$javax_swing_text_Position_Bias', function (dot, dotBias) {
if (dotBias == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null bias"]);
}if (!this.component.isEnabled()) {
this.setDot$I$javax_swing_text_Position_Bias(dot, dotBias);
return;
}if (dot != this.dot) {
var filter = this.component.getNavigationFilter();
if (filter != null ) {
filter.moveDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias(p$.getFilterBypass.apply(this, []), dot, dotBias);
} else {
this.handleMoveDot$I$javax_swing_text_Position_Bias(dot, dotBias);
}}});

Clazz.newMethod$(C$, 'handleMoveDot$I$javax_swing_text_Position_Bias', function (dot, dotBias) {
this.changeCaretPosition$I$javax_swing_text_Position_Bias(dot, dotBias);
if (this.selectionVisible) {
var h = this.component.getHighlighter();
if (h != null ) {
var p0 = Math.min(dot, this.mark);
var p1 = Math.max(dot, this.mark);
if (p0 == p1) {
if (this.selectionTag != null ) {
h.removeHighlight$O(this.selectionTag);
this.selectionTag = null;
}} else {
try {
if (this.selectionTag != null ) {
h.changeHighlight$O$I$I(this.selectionTag, p0, p1);
} else {
var p = this.getSelectionPainter();
this.selectionTag = h.addHighlight$I$I$javax_swing_text_Highlighter_HighlightPainter(p0, p1, p);
}} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
throw Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.text.StateInvariantError'))).c$$S,["Bad caret position"]);
} else {
throw e;
}
}
}}}});

Clazz.newMethod$(C$, 'setDot$I$javax_swing_text_Position_Bias', function (dot, dotBias) {
if (dotBias == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null bias"]);
}var filter = this.component.getNavigationFilter();
if (filter != null ) {
filter.setDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias(p$.getFilterBypass.apply(this, []), dot, dotBias);
} else {
this.handleSetDot$I$javax_swing_text_Position_Bias(dot, dotBias);
}});

Clazz.newMethod$(C$, 'handleSetDot$I$javax_swing_text_Position_Bias', function (dot, dotBias) {
var doc = this.component.getDocument();
if (doc != null ) {
dot = Math.min(dot, doc.getLength());
}dot = Math.max(dot, 0);
if (dot == 0) dotBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
this.mark = dot;
if (this.dot != dot || this.dotBias !== dotBias   || this.selectionTag != null   || this.forceCaretPositionChange ) {
this.changeCaretPosition$I$javax_swing_text_Position_Bias(dot, dotBias);
}this.markBias = this.dotBias;
this.markLTR = this.dotLTR;
var h = this.component.getHighlighter();
if ((h != null ) && (this.selectionTag != null ) ) {
h.removeHighlight$O(this.selectionTag);
this.selectionTag = null;
}});

Clazz.newMethod$(C$, 'getDotBias', function () {
return this.dotBias;
});

Clazz.newMethod$(C$, 'getMarkBias', function () {
return this.markBias;
});

Clazz.newMethod$(C$, 'isDotLeftToRight', function () {
return this.dotLTR;
});

Clazz.newMethod$(C$, 'isMarkLeftToRight', function () {
return this.markLTR;
});

Clazz.newMethod$(C$, 'isPositionLTR$I$javax_swing_text_Position_Bias', function (position, bias) {
var doc = this.component.getDocument();
if (Clazz.instanceOf(doc, "javax.swing.text.AbstractDocument")) {
if (bias === (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward  && --position < 0 ) position = 0;
return (doc).isLeftToRight$I$I(position, position);
}return true;
});

Clazz.newMethod$(C$, 'guessBiasForOffset$I$javax_swing_text_Position_Bias$Z', function (offset, lastBias, lastLTR) {
if (lastLTR != this.isPositionLTR$I$javax_swing_text_Position_Bias(offset, lastBias) ) {
lastBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward;
} else if (lastBias !== (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward  && lastLTR != this.isPositionLTR$I$javax_swing_text_Position_Bias(offset, (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward)  ) {
lastBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward;
}if (lastBias === (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward  && offset > 0 ) {
try {
var s = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.text.Segment'))));
this.component.getDocument().getText$I$I$javax_swing_text_Segment(offset - 1, 1, s);
if (s.count > 0 && s.array[s.offset] == '\u000a' ) {
lastBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
}} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
}return lastBias;
});

Clazz.newMethod$(C$, 'changeCaretPosition$I$javax_swing_text_Position_Bias', function (dot, dotBias) {
this.repaint();
this.dot = dot;
this.dotBias = dotBias;
this.dotLTR = this.isPositionLTR$I$javax_swing_text_Position_Bias(dot, dotBias);
this.fireStateChanged();
p$.updateSystemSelection.apply(this, []);
this.setMagicCaretPosition$java_awt_Point(null);
var callRepaintNewCaret = ((
(function(){var C$=Clazz.newClass$(P$, "DefaultCaret$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.b$['javax.swing.text.DefaultCaret'].repaintNewCaret();
});
})()
), Clazz.new((I$[10] || (I$[10]=Clazz.load(P$.DefaultCaret$1))).$init$, [this, null]));
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(callRepaintNewCaret);
});

Clazz.newMethod$(C$, 'repaintNewCaret', function () {
if (this.component != null ) {
var mapper = this.component.getUI();
var doc = this.component.getDocument();
if ((mapper != null ) && (doc != null ) ) {
var newLoc;
try {
newLoc = mapper.modelToView$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias(this.component, this.dot, this.dotBias);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
newLoc = null;
} else {
throw e;
}
}
if (newLoc != null ) {
this.adjustVisibility$java_awt_Rectangle(newLoc);
if (this.getMagicCaretPosition() == null ) {
this.setMagicCaretPosition$java_awt_Point(Clazz.new((I$[7] || (I$[7]=Clazz.load('java.awt.Point'))).c$$I$I,[newLoc.x, newLoc.y]));
}}this.damage$java_awt_Rectangle(newLoc);
}}});

Clazz.newMethod$(C$, 'updateSystemSelection', function () {
});

Clazz.newMethod$(C$, 'ensureValidPosition', function () {
var length = this.component.getDocument().getLength();
if (this.dot > length || this.mark > length ) {
this.handleSetDot$I$javax_swing_text_Position_Bias(length, (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward);
}});

Clazz.newMethod$(C$, 'setMagicCaretPosition$java_awt_Point', function (p) {
this.magicCaretPosition = p;
});

Clazz.newMethod$(C$, 'getMagicCaretPosition', function () {
return this.magicCaretPosition;
});

Clazz.newMethod$(C$, 'equals$O', function (obj) {
return (this === obj );
});

Clazz.newMethod$(C$, 'toString', function () {
var s = "Dot=(" + this.dot + ", " + this.dotBias + ")" ;
s += " Mark=(" + this.mark + ", " + this.markBias + ")" ;
return s;
});

Clazz.newMethod$(C$, 'getFilterBypass', function () {
if (this.filterBypass == null ) {
this.filterBypass = Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.text.DefaultCaret').DefaultFilterBypass))), [this, null]);
}return this.filterBypass;
});

Clazz.newMethod$(C$, '_contains$I$I$I$I', function (X, Y, W, H) {
var w = this.width;
var h = this.height;
if ((w | h | W | H ) < 0) {
return false;
}var x = this.x;
var y = this.y;
if (X < x || Y < y ) {
return false;
}if (W > 0) {
w = w+(x);
W = W+(X);
if (W <= X) {
if (w >= x || W > w ) return false;
} else {
if (w >= x && W > w ) return false;
}} else if ((x + w) < X) {
return false;
}if (H > 0) {
h = h+(y);
H = H+(Y);
if (H <= Y) {
if (h >= y || H > h ) return false;
} else {
if (h >= y && H > h ) return false;
}} else if ((y + h) < Y) {
return false;
}return true;
});

Clazz.newMethod$(C$, 'getCaretWidth$I', function (height) {
if (this.aspectRatio > -1 ) {
return ($i$[0] = (this.aspectRatio * height), $i$[0]) + 1;
}if (this.caretWidth > -1) {
return this.caretWidth;
}return 1;
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.DefaultCaret, "SafeScroller", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.r = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Rectangle', function (r) {
C$.$init$.apply(this);
this.r = r;
}, 1);

Clazz.newMethod$(C$, 'run', function () {
if (this.b$['javax.swing.text.DefaultCaret'].component != null ) {
this.b$['javax.swing.text.DefaultCaret'].component.scrollRectToVisible$java_awt_Rectangle(this.r);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultCaret, "Handler", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, ['java.beans.PropertyChangeListener', 'javax.swing.event.DocumentListener', 'java.awt.event.ActionListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.b$['javax.swing.text.DefaultCaret'].width == 0 || this.b$['javax.swing.text.DefaultCaret'].height == 0 ) {
if (this.b$['javax.swing.text.DefaultCaret'].component != null ) {
var mapper = this.b$['javax.swing.text.DefaultCaret'].component.getUI();
try {
var r = mapper.modelToView$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias(this.b$['javax.swing.text.DefaultCaret'].component, this.b$['javax.swing.text.DefaultCaret'].dot, this.b$['javax.swing.text.DefaultCaret'].dotBias);
if (r != null  && r.width != 0  && r.height != 0 ) {
this.b$['javax.swing.text.DefaultCaret'].damage$java_awt_Rectangle(r);
}} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
}}this.b$['javax.swing.text.DefaultCaret'].visible = !this.b$['javax.swing.text.DefaultCaret'].visible;
this.b$['javax.swing.text.DefaultCaret'].repaint();
});

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_event_DocumentEvent', function (e) {
if (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 1 || (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 0 && !(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread() ) ) {
if ((e.getOffset() <= this.b$['javax.swing.text.DefaultCaret'].dot || e.getOffset() <= this.b$['javax.swing.text.DefaultCaret'].mark ) && this.b$['javax.swing.text.DefaultCaret'].selectionTag != null  ) {
try {
this.b$['javax.swing.text.DefaultCaret'].component.getHighlighter().changeHighlight$O$I$I(this.b$['javax.swing.text.DefaultCaret'].selectionTag, Math.min(this.b$['javax.swing.text.DefaultCaret'].dot, this.b$['javax.swing.text.DefaultCaret'].mark), Math.max(this.b$['javax.swing.text.DefaultCaret'].dot, this.b$['javax.swing.text.DefaultCaret'].mark));
} catch (e1) {
if (Clazz.exceptionOf(e1, P$.BadLocationException)){
e1.printStackTrace();
} else {
throw e1;
}
}
}return;
}var adjust = 0;
var offset = e.getOffset();
var length = e.getLength();
var newDot = this.b$['javax.swing.text.DefaultCaret'].dot;
var changed = ($s$[0] = 0, $s$[0]);
if (Clazz.instanceOf(e, "javax.swing.text.AbstractDocument.UndoRedoDocumentEvent")) {
this.b$['javax.swing.text.DefaultCaret'].setDot$I(offset + length);
return;
}if (newDot >= offset) {
newDot = newDot+(length);
changed = ($s$[0] = changed|(1), $s$[0]);
}var newMark = this.b$['javax.swing.text.DefaultCaret'].mark;
if (newMark >= offset) {
newMark = newMark+(length);
changed = ($s$[0] = changed|(2), $s$[0]);
}if (changed != 0) {
var dotBias = this.b$['javax.swing.text.DefaultCaret'].dotBias;
if (this.b$['javax.swing.text.DefaultCaret'].dot == offset) {
var doc = this.b$['javax.swing.text.DefaultCaret'].component.getDocument();
var isNewline;
try {
var s = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.text.Segment'))));
doc.getText$I$I$javax_swing_text_Segment(newDot - 1, 1, s);
isNewline = (s.count > 0 && s.array[s.offset] == '\u000a' );
} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
isNewline = false;
} else {
throw ble;
}
}
if (isNewline) {
dotBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
} else {
dotBias = (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward;
}}if (newMark == newDot) {
this.b$['javax.swing.text.DefaultCaret'].setDot$I$javax_swing_text_Position_Bias(newDot, dotBias);
this.b$['javax.swing.text.DefaultCaret'].ensureValidPosition();
} else {
this.b$['javax.swing.text.DefaultCaret'].setDot$I$javax_swing_text_Position_Bias(newMark, this.b$['javax.swing.text.DefaultCaret'].markBias);
if (this.b$['javax.swing.text.DefaultCaret'].getDot() == newMark) {
this.b$['javax.swing.text.DefaultCaret'].moveDot$I$javax_swing_text_Position_Bias(newDot, dotBias);
}this.b$['javax.swing.text.DefaultCaret'].ensureValidPosition();
}}});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_event_DocumentEvent', function (e) {
if (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 1 || (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 0 && !(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread() ) ) {
var length = this.b$['javax.swing.text.DefaultCaret'].component.getDocument().getLength();
this.b$['javax.swing.text.DefaultCaret'].dot = Math.min(this.b$['javax.swing.text.DefaultCaret'].dot, length);
this.b$['javax.swing.text.DefaultCaret'].mark = Math.min(this.b$['javax.swing.text.DefaultCaret'].mark, length);
if ((e.getOffset() < this.b$['javax.swing.text.DefaultCaret'].dot || e.getOffset() < this.b$['javax.swing.text.DefaultCaret'].mark ) && this.b$['javax.swing.text.DefaultCaret'].selectionTag != null  ) {
try {
this.b$['javax.swing.text.DefaultCaret'].component.getHighlighter().changeHighlight$O$I$I(this.b$['javax.swing.text.DefaultCaret'].selectionTag, Math.min(this.b$['javax.swing.text.DefaultCaret'].dot, this.b$['javax.swing.text.DefaultCaret'].mark), Math.max(this.b$['javax.swing.text.DefaultCaret'].dot, this.b$['javax.swing.text.DefaultCaret'].mark));
} catch (e1) {
if (Clazz.exceptionOf(e1, P$.BadLocationException)){
e1.printStackTrace();
} else {
throw e1;
}
}
}return;
}var offs0 = e.getOffset();
var offs1 = offs0 + e.getLength();
var adjust = 0;
var newDot = this.b$['javax.swing.text.DefaultCaret'].dot;
var adjustDotBias = false;
var newMark = this.b$['javax.swing.text.DefaultCaret'].mark;
var adjustMarkBias = false;
if (Clazz.instanceOf(e, "javax.swing.text.AbstractDocument.UndoRedoDocumentEvent")) {
this.b$['javax.swing.text.DefaultCaret'].setDot$I(offs0);
return;
}if (newDot >= offs1) {
newDot = newDot-((offs1 - offs0));
if (newDot == offs1) {
adjustDotBias = true;
}} else if (newDot >= offs0) {
newDot = offs0;
adjustDotBias = true;
}if (newMark >= offs1) {
newMark = newMark-((offs1 - offs0));
if (newMark == offs1) {
adjustMarkBias = true;
}} else if (newMark >= offs0) {
newMark = offs0;
adjustMarkBias = true;
}if (newMark == newDot) {
this.b$['javax.swing.text.DefaultCaret'].forceCaretPositionChange = true;
try {
this.b$['javax.swing.text.DefaultCaret'].setDot$I$javax_swing_text_Position_Bias(newDot, this.b$['javax.swing.text.DefaultCaret'].guessBiasForOffset$I$javax_swing_text_Position_Bias$Z(newDot, this.b$['javax.swing.text.DefaultCaret'].dotBias, this.b$['javax.swing.text.DefaultCaret'].dotLTR));
} finally {
this.b$['javax.swing.text.DefaultCaret'].forceCaretPositionChange = false;
}
this.b$['javax.swing.text.DefaultCaret'].ensureValidPosition();
} else {
var dotBias = this.b$['javax.swing.text.DefaultCaret'].dotBias;
var markBias = this.b$['javax.swing.text.DefaultCaret'].markBias;
if (adjustDotBias) {
dotBias = this.b$['javax.swing.text.DefaultCaret'].guessBiasForOffset$I$javax_swing_text_Position_Bias$Z(newDot, dotBias, this.b$['javax.swing.text.DefaultCaret'].dotLTR);
}if (adjustMarkBias) {
markBias = this.b$['javax.swing.text.DefaultCaret'].guessBiasForOffset$I$javax_swing_text_Position_Bias$Z(this.b$['javax.swing.text.DefaultCaret'].mark, markBias, this.b$['javax.swing.text.DefaultCaret'].markLTR);
}this.b$['javax.swing.text.DefaultCaret'].setDot$I$javax_swing_text_Position_Bias(newMark, markBias);
if (this.b$['javax.swing.text.DefaultCaret'].getDot() == newMark) {
this.b$['javax.swing.text.DefaultCaret'].moveDot$I$javax_swing_text_Position_Bias(newDot, dotBias);
}this.b$['javax.swing.text.DefaultCaret'].ensureValidPosition();
}});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent', function (e) {
if (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 1 || (this.b$['javax.swing.text.DefaultCaret'].getUpdatePolicy() == 0 && !(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread() ) ) {
return;
}if (Clazz.instanceOf(e, "javax.swing.text.AbstractDocument.UndoRedoDocumentEvent")) {
this.b$['javax.swing.text.DefaultCaret'].setDot$I(e.getOffset() + e.getLength());
}});

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (evt) {
var oldValue = evt.getOldValue();
var newValue = evt.getNewValue();
if ((Clazz.instanceOf(oldValue, "javax.swing.text.Document")) || (Clazz.instanceOf(newValue, "javax.swing.text.Document")) ) {
this.b$['javax.swing.text.DefaultCaret'].setDot$I(0);
if (oldValue != null ) {
(oldValue).removeDocumentListener$javax_swing_event_DocumentListener(this);
}if (newValue != null ) {
(newValue).addDocumentListener$javax_swing_event_DocumentListener(this);
}} else if ("enabled".equals$O(evt.getPropertyName())) {
var enabled = evt.getNewValue();
if (this.b$['javax.swing.text.DefaultCaret'].component.isFocusOwner()) {
if (enabled === Boolean.TRUE ) {
if (this.b$['javax.swing.text.DefaultCaret'].component.isEditable()) {
this.b$['javax.swing.text.DefaultCaret'].setVisible$Z(true);
}this.b$['javax.swing.text.DefaultCaret'].setSelectionVisible$Z(true);
} else {
this.b$['javax.swing.text.DefaultCaret'].setVisible$Z(false);
this.b$['javax.swing.text.DefaultCaret'].setSelectionVisible$Z(false);
}}} else if ("caretWidth".equals$O(evt.getPropertyName())) {
var newWidth = evt.getNewValue();
if (newWidth != null ) {
this.b$['javax.swing.text.DefaultCaret'].caretWidth = newWidth.intValue();
} else {
this.b$['javax.swing.text.DefaultCaret'].caretWidth = -1;
}this.b$['javax.swing.text.DefaultCaret'].repaint();
} else if ("caretAspectRatio".equals$O(evt.getPropertyName())) {
var newRatio = evt.getNewValue();
if (newRatio != null ) {
this.b$['javax.swing.text.DefaultCaret'].aspectRatio = newRatio.floatValue();
} else {
this.b$['javax.swing.text.DefaultCaret'].aspectRatio = -1;
}this.b$['javax.swing.text.DefaultCaret'].repaint();
}});
var $s$ = new Int16Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultCaret, "DefaultFilterBypass", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.NavigationFilter.FilterBypass');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getCaret', function () {
return this.b$['javax.swing.text.DefaultCaret'];
});

Clazz.newMethod$(C$, 'setDot$I$javax_swing_text_Position_Bias', function (dot, bias) {
this.b$['javax.swing.text.DefaultCaret'].handleSetDot$I$javax_swing_text_Position_Bias(dot, bias);
});

Clazz.newMethod$(C$, 'moveDot$I$javax_swing_text_Position_Bias', function (dot, bias) {
this.b$['javax.swing.text.DefaultCaret'].handleMoveDot$I$javax_swing_text_Position_Bias(dot, bias);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:01
