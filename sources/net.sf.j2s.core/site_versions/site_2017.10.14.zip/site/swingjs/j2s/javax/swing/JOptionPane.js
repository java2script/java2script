(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JOptionPane", null, 'javax.swing.JComponent');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.sharedFrameKey = Clazz.getClass(javax.swing.JOptionPane);
};

C$.sharedFrameKey = null;

Clazz.newMethod$(C$, '$init$', function () {
this.icon = null;
this.message = null;
this.options = null;
this.initialValue = null;
this.messageType = 0;
this.optionType = 0;
this.value = null;
this.selectionValues = null;
this.inputValue = null;
this.initialSelectionValue = null;
this.wantsInput = false;
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$O', function (message) {
return C$.showInputDialog$java_awt_Component$O(null, message);
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$O$O', function (message, initialSelectionValue) {
return C$.showInputDialog$java_awt_Component$O$O(null, message, initialSelectionValue);
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$java_awt_Component$O', function (parentComponent, message) {
return C$.showInputDialog$java_awt_Component$O$S$I(parentComponent, message, (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O$java_awt_Component("OptionPane.inputDialogTitle", parentComponent), 3);
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$java_awt_Component$O$O', function (parentComponent, message, initialSelectionValue) {
return C$.showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(parentComponent, message, (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O$java_awt_Component("OptionPane.inputDialogTitle", parentComponent), 3, null, null, initialSelectionValue);
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$java_awt_Component$O$S$I', function (parentComponent, message, title, messageType) {
return C$.showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O(parentComponent, message, title, messageType, null, null, null);
}, 1);

Clazz.newMethod$(C$, 'showInputDialog$java_awt_Component$O$S$I$javax_swing_Icon$OA$O', function (parentComponent, message, title, messageType, icon, selectionValues, initialSelectionValue) {
var value;
message = C$.joinMessage$O(message);
{
value = prompt(message, initialSelectionValue == null ? "" : initialSelectionValue);
}return value;
}, 1);

Clazz.newMethod$(C$, 'getRunnable$O', function (message) {
var r = null;
if (Clazz.instanceOf(message, Clazz.arrayClass$(java.lang.Object, 1))) {
var m = message;
if (m.length > 0 && Clazz.instanceOf(m[m.length - 1], "java.lang.Runnable") ) r = m[m.length - 1];
}return r;
}, 1);

Clazz.newMethod$(C$, 'showMessageDialog$java_awt_Component$O', function (parentComponent, message) {
C$.showMessageDialog$java_awt_Component$O$S$I(parentComponent, message, (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O$java_awt_Component("OptionPane.messageDialogTitle", parentComponent), 1);
}, 1);

Clazz.newMethod$(C$, 'showMessageDialog$java_awt_Component$O$S$I', function (parentComponent, message, title, messageType) {
C$.showMessageDialog$java_awt_Component$O$S$I$javax_swing_Icon(parentComponent, message, title, messageType, null);
}, 1);

Clazz.newMethod$(C$, 'showMessageDialog$java_awt_Component$O$S$I$javax_swing_Icon', function (parentComponent, message, title, messageType, icon) {
message = C$.joinMessage$O(message);
{
alert(message);
}}, 1);

Clazz.newMethod$(C$, 'showConfirmDialog$java_awt_Component$O', function (parentComponent, message) {
return C$.showConfirmDialog$java_awt_Component$O$S$I(parentComponent, message, (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("OptionPane.titleText"), 1);
}, 1);

Clazz.newMethod$(C$, 'showConfirmDialog$java_awt_Component$O$S$I', function (parentComponent, message, title, optionType) {
return C$.showConfirmDialog$java_awt_Component$O$S$I$I(parentComponent, message, title, optionType, 3);
}, 1);

Clazz.newMethod$(C$, 'showConfirmDialog$java_awt_Component$O$S$I$I', function (parentComponent, message, title, optionType, messageType) {
return C$.showConfirmDialog$java_awt_Component$O$S$I$I$javax_swing_Icon(parentComponent, message, title, optionType, messageType, null);
}, 1);

Clazz.newMethod$(C$, 'showConfirmDialog$java_awt_Component$O$S$I$I$javax_swing_Icon', function (parentComponent, message, title, optionType, messageType, icon) {
var ok = 0;
var canc = 2;
var yes = 0;
var no = 1;
message = C$.joinMessage$O(message);
var options =  Clazz.newArray$(java.lang.String, -1, ["ok"]);
switch (optionType) {
case 2:
{
return (confirm(message) ? ok : canc);
}break;
case 1:
options =  Clazz.newArray$(java.lang.String, -1, ["yes", "no", "cancel"]);
break;
case 0:
options =  Clazz.newArray$(java.lang.String, -1, ["yes", "no"]);
break;
}
var ret = null;
{
var ret = prompt(message, options[0]);
return (!ret ? canc : ret.toLowerCase() == "yes" ? yes : no);
}{
}}, 1);

Clazz.newMethod$(C$, 'joinMessage$O', function (message) {
{
return (message.join ? message.join("\n\n") : message);
}}, 1);

Clazz.newMethod$(C$, 'showOptionDialog$java_awt_Component$O$S$I$I$javax_swing_Icon$OA$O', function (parentComponent, message, title, optionType, messageType, icon, options, initialValue) {
var pane = Clazz.new(C$.c$$O$I$I$javax_swing_Icon$OA$O,[message, messageType, optionType, icon, options, initialValue]);
pane.setInitialValue$O(initialValue);
pane.setComponentOrientation$java_awt_ComponentOrientation(((parentComponent == null ) ? C$.getRootFrame() : parentComponent).getComponentOrientation());
var style = C$.styleFromMessageType$I(messageType);
var dialog = pane.createDialog$java_awt_Component$S$I(parentComponent, title, style);
pane.selectInitialValue();
dialog.show();
dialog.dispose();
var selectedValue = pane.getValue();
if (selectedValue == null ) return -1;
if (options == null ) {
if (Clazz.instanceOf(selectedValue, "java.lang.Integer")) return (selectedValue).intValue();
return -1;
}for (var counter = 0, maxCounter = options.length; counter < maxCounter; counter++) {
if (options[counter].equals$O(selectedValue)) return counter;
}
return -1;
}, 1);

Clazz.newMethod$(C$, 'createDialog$java_awt_Component$S', function (parentComponent, title) {
var style = C$.styleFromMessageType$I(this.getMessageType());
return p$.createDialog$java_awt_Component$S$I.apply(this, [parentComponent, title, style]);
});

Clazz.newMethod$(C$, 'createDialog$S', function (title) {
var style = C$.styleFromMessageType$I(this.getMessageType());
var dialog = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Dialog$S$Z,[null, title, true]);
p$.initDialog$javax_swing_JDialog$I$java_awt_Component.apply(this, [dialog, style, null]);
return dialog;
});

Clazz.newMethod$(C$, 'createDialog$java_awt_Component$S$I', function (parentComponent, title, style) {
var dialog;
var window = C$.getWindowForComponent$java_awt_Component(parentComponent);
if (Clazz.instanceOf(window, "java.awt.Frame")) {
dialog = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Frame$S$Z,[window, title, true]);
} else {
dialog = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).c$$java_awt_Dialog$S$Z,[window, title, true]);
}if (Clazz.instanceOf(window, "javax.swing.SwingUtilities.SharedOwnerFrame")) {
var ownerShutdownListener = (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
dialog.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}p$.initDialog$javax_swing_JDialog$I$java_awt_Component.apply(this, [dialog, style, parentComponent]);
return dialog;
});

Clazz.newMethod$(C$, 'initDialog$javax_swing_JDialog$I$java_awt_Component', function (dialog, style, parentComponent) {
dialog.setComponentOrientation$java_awt_ComponentOrientation(this.getComponentOrientation());
var contentPane = dialog.getContentPane();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.BorderLayout')))));
contentPane.add$java_awt_Component$O(this, "Center");
dialog.setResizable$Z(false);
if ((I$[1] || (I$[1]=Clazz.load('javax.swing.JDialog'))).isDefaultLookAndFeelDecorated()) {
var supportsWindowDecorations = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getSupportsWindowDecorations();
if (supportsWindowDecorations) {
dialog.setUndecorated$Z(true);
this.getRootPane().setWindowDecorationStyle$I(style);
}}dialog.pack();
dialog.setLocationRelativeTo$java_awt_Component(parentComponent);
var adapter = ((
(function(){var C$=Clazz.newClass$(P$, "JOptionPane$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('java.awt.event.WindowAdapter'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
this.gotFocus = false;
}, 1);

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (we) {
this.b$['javax.swing.JOptionPane'].setValue$O(null);
});

Clazz.newMethod$(C$, 'windowGainedFocus$java_awt_event_WindowEvent', function (we) {
if (!this.gotFocus) {
this.b$['javax.swing.JOptionPane'].selectInitialValue();
this.gotFocus = true;
}});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.event.WindowAdapter'))), [this, null],P$.JOptionPane$1));
dialog.addWindowListener$java_awt_event_WindowListener(adapter);
dialog.addWindowFocusListener$java_awt_event_WindowFocusListener(adapter);
dialog.addComponentListener$java_awt_event_ComponentListener(((
(function(){var C$=Clazz.newClass$(P$, "JOptionPane$2", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('java.awt.event.ComponentAdapter'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'componentShown$java_awt_event_ComponentEvent', function (ce) {
this.b$['javax.swing.JOptionPane'].setValue$O(P$.JOptionPane.UNINITIALIZED_VALUE);
});
})()
), Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.event.ComponentAdapter'))), [this, null],P$.JOptionPane$2)));
this.addPropertyChangeListener$java_beans_PropertyChangeListener(((
(function(){var C$=Clazz.newClass$(P$, "JOptionPane$3", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'java.beans.PropertyChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (event) {
if (this.$finals.dialog.isVisible() && event.getSource() === this   && (event.getPropertyName().equals$O("value") || event.getPropertyName().equals$O("inputValue") )  && event.getNewValue() != null   && event.getNewValue() !== P$.JOptionPane.UNINITIALIZED_VALUE  ) {
this.$finals.dialog.setVisible$Z(false);
}});
})()
), Clazz.new((I$[6] || (I$[6]=Clazz.load(P$.JOptionPane$3))).$init$, [this, {dialog: dialog}])));
});

Clazz.newMethod$(C$, 'getFrameForComponent$java_awt_Component', function (parentComponent) {
if (parentComponent == null ) return C$.getRootFrame();
if (Clazz.instanceOf(parentComponent, "java.awt.Frame")) return parentComponent;
return C$.getFrameForComponent$java_awt_Component(parentComponent.getParent());
}, 1);

Clazz.newMethod$(C$, 'getWindowForComponent$java_awt_Component', function (parentComponent) {
if (parentComponent == null ) return C$.getRootFrame();
if (Clazz.instanceOf(parentComponent, "java.awt.Frame") || Clazz.instanceOf(parentComponent, "java.awt.Dialog") ) return parentComponent;
return C$.getWindowForComponent$java_awt_Component(parentComponent.getParent());
}, 1);

Clazz.newMethod$(C$, 'setRootFrame$java_awt_Frame', function (newRootFrame) {
if (newRootFrame != null ) {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.sharedFrameKey, newRootFrame);
} else {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextRemove$O(C$.sharedFrameKey);
}}, 1);

Clazz.newMethod$(C$, 'getRootFrame', function () {
var sharedFrame = (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.sharedFrameKey);
if (sharedFrame == null ) {
sharedFrame = (I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame();
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.sharedFrameKey, sharedFrame);
}return sharedFrame;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$O.apply(this, ["JOptionPane message"]);
}, 1);

Clazz.newMethod$(C$, 'c$$O', function (message) {
C$.c$$O$I.apply(this, [message, -1]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$I', function (message, messageType) {
C$.c$$O$I$I.apply(this, [message, messageType, -1]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$I$I', function (message, messageType, optionType) {
C$.c$$O$I$I$javax_swing_Icon.apply(this, [message, messageType, optionType, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$I$I$javax_swing_Icon', function (message, messageType, optionType, icon) {
C$.c$$O$I$I$javax_swing_Icon$OA.apply(this, [message, messageType, optionType, icon, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$I$I$javax_swing_Icon$OA', function (message, messageType, optionType, icon, options) {
C$.c$$O$I$I$javax_swing_Icon$OA$O.apply(this, [message, messageType, optionType, icon, options, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$I$I$javax_swing_Icon$OA$O', function (message, messageType, optionType, icon, options, initialValue) {
Clazz.super(C$, this,1);
this.message = message;
this.options = options;
this.initialValue = initialValue;
this.icon = icon;
this.setMessageType$I(messageType);
this.setOptionType$I(optionType);
this.value = C$.UNINITIALIZED_VALUE;
this.inputValue = C$.UNINITIALIZED_VALUE;
this.uiClassID = "OptionPaneUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'setUI$javax_swing_plaf_OptionPaneUI', function (ui) {
if (this.ui !== ui ) {
C$.superClazz.prototype.setUI$javax_swing_plaf_ComponentUI.apply(this, [ui]);
this.invalidate();
}});

Clazz.newMethod$(C$, 'setMessage$O', function (newMessage) {
var oldMessage = this.message;
this.message = newMessage;
this.firePropertyChange$S$O$O("message", oldMessage, this.message);
});

Clazz.newMethod$(C$, 'getMessage', function () {
return this.message;
});

Clazz.newMethod$(C$, 'setIcon$javax_swing_Icon', function (newIcon) {
var oldIcon = this.icon;
this.icon = newIcon;
this.firePropertyChange$S$O$O("icon", oldIcon, this.icon);
});

Clazz.newMethod$(C$, 'getIcon', function () {
return this.icon;
});

Clazz.newMethod$(C$, 'setValue$O', function (newValue) {
var oldValue = this.value;
this.value = newValue;
this.firePropertyChange$S$O$O("value", oldValue, this.value);
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.value;
});

Clazz.newMethod$(C$, 'setOptions$OA', function (newOptions) {
var oldOptions = this.options;
this.options = newOptions;
this.firePropertyChange$S$O$O("options", oldOptions, this.options);
});

Clazz.newMethod$(C$, 'getOptions', function () {
if (this.options != null ) {
var optionCount = this.options.length;
var retOptions =  Clazz.newArray$(java.lang.Object, [optionCount]);
System.arraycopy(this.options, 0, retOptions, 0, optionCount);
return retOptions;
}return this.options;
});

Clazz.newMethod$(C$, 'setInitialValue$O', function (newInitialValue) {
var oldIV = this.initialValue;
this.initialValue = newInitialValue;
this.firePropertyChange$S$O$O("initialValue", oldIV, this.initialValue);
});

Clazz.newMethod$(C$, 'getInitialValue', function () {
return this.initialValue;
});

Clazz.newMethod$(C$, 'setMessageType$I', function (newType) {
if (newType != 0 && newType != 1  && newType != 2  && newType != 3  && newType != -1 ) throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["JOptionPane: type must be one of JOptionPane.ERROR_MESSAGE, JOptionPane.INFORMATION_MESSAGE, JOptionPane.WARNING_MESSAGE, JOptionPane.QUESTION_MESSAGE or JOptionPane.PLAIN_MESSAGE"]);
var oldType = this.messageType;
this.messageType = newType;
this.firePropertyChange$S$I$I("messageType", oldType, this.messageType);
});

Clazz.newMethod$(C$, 'getMessageType', function () {
return this.messageType;
});

Clazz.newMethod$(C$, 'setOptionType$I', function (newType) {
if (newType != -1 && newType != 0  && newType != 1  && newType != 2 ) throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["JOptionPane: option type must be one of JOptionPane.DEFAULT_OPTION, JOptionPane.YES_NO_OPTION, JOptionPane.YES_NO_CANCEL_OPTION or JOptionPane.OK_CANCEL_OPTION"]);
var oldType = this.optionType;
this.optionType = newType;
this.firePropertyChange$S$I$I("optionType", oldType, this.optionType);
});

Clazz.newMethod$(C$, 'getOptionType', function () {
return this.optionType;
});

Clazz.newMethod$(C$, 'setSelectionValues$OA', function (newValues) {
var oldValues = this.selectionValues;
this.selectionValues = newValues;
this.firePropertyChange$S$O$O("selectionValues", oldValues, newValues);
if (this.selectionValues != null ) this.setWantsInput$Z(true);
});

Clazz.newMethod$(C$, 'getSelectionValues', function () {
return this.selectionValues;
});

Clazz.newMethod$(C$, 'setInitialSelectionValue$O', function (newValue) {
var oldValue = this.initialSelectionValue;
this.initialSelectionValue = newValue;
this.firePropertyChange$S$O$O("initialSelectionValue", oldValue, newValue);
});

Clazz.newMethod$(C$, 'getInitialSelectionValue', function () {
return this.initialSelectionValue;
});

Clazz.newMethod$(C$, 'setInputValue$O', function (newValue) {
var oldValue = this.inputValue;
this.inputValue = newValue;
this.firePropertyChange$S$O$O("inputValue", oldValue, newValue);
});

Clazz.newMethod$(C$, 'getInputValue', function () {
return this.inputValue;
});

Clazz.newMethod$(C$, 'getMaxCharactersPerLineCount', function () {
return 2147483647;
});

Clazz.newMethod$(C$, 'setWantsInput$Z', function (newValue) {
var oldValue = this.wantsInput;
this.wantsInput = newValue;
this.firePropertyChange$S$Z$Z("wantsInput", oldValue, newValue);
});

Clazz.newMethod$(C$, 'getWantsInput', function () {
return this.wantsInput;
});

Clazz.newMethod$(C$, 'selectInitialValue', function () {
var ui = this.getUI();
if (ui != null ) {
ui.selectInitialValue$javax_swing_JOptionPane(this);
}});

Clazz.newMethod$(C$, 'styleFromMessageType$I', function (messageType) {
switch (messageType) {
case 0:
return 4;
case 3:
return 7;
case 2:
return 8;
case 1:
return 3;
case -1:
default:
return 2;
}
}, 1);

Clazz.newMethod$(C$, 'paramString', function () {
var iconString = (this.icon != null  ? this.icon.toString() : "");
var initialValueString = (this.initialValue != null  ? this.initialValue.toString() : "");
var messageString = (this.message != null  ? this.message.toString() : "");
var messageTypeString;
if (this.messageType == 0) {
messageTypeString = "ERROR_MESSAGE";
} else if (this.messageType == 1) {
messageTypeString = "INFORMATION_MESSAGE";
} else if (this.messageType == 2) {
messageTypeString = "WARNING_MESSAGE";
} else if (this.messageType == 3) {
messageTypeString = "QUESTION_MESSAGE";
} else if (this.messageType == -1) {
messageTypeString = "PLAIN_MESSAGE";
} else messageTypeString = "";
var optionTypeString;
if (this.optionType == -1) {
optionTypeString = "DEFAULT_OPTION";
} else if (this.optionType == 0) {
optionTypeString = "YES_NO_OPTION";
} else if (this.optionType == 1) {
optionTypeString = "YES_NO_CANCEL_OPTION";
} else if (this.optionType == 2) {
optionTypeString = "OK_CANCEL_OPTION";
} else optionTypeString = "";
var wantsInputString = (this.wantsInput ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",icon=" + iconString + ",initialValue=" + initialValueString + ",message=" + messageString + ",messageType=" + messageTypeString + ",optionType=" + optionTypeString + ",wantsInput=" + wantsInputString ;
});
})();
//Created 2017-10-14 13:31:40
