(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "PopupFactory", function(){
Clazz.newInstance$(this, arguments);
});
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.SharedInstanceKey =  new Clazz._O();
};

C$.popupCount = 0;
C$.SharedInstanceKey = null;

Clazz.newMethod$(C$, '$init$', function () {
this.popupType = 0;
}, 1);

Clazz.newMethod$(C$, 'setSharedInstance$javax_swing_PopupFactory', function (factory) {
if (factory == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["PopupFactory can not be null"]);
}(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.SharedInstanceKey, factory);
}, 1);

Clazz.newMethod$(C$, 'getSharedInstance', function () {
var factory = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.SharedInstanceKey);
if (factory == null ) {
factory = Clazz.new(C$);
C$.setSharedInstance$javax_swing_PopupFactory(factory);
}return factory;
}, 1);

Clazz.newMethod$(C$, 'setPopupType$I', function (type) {
this.popupType = type;
});

Clazz.newMethod$(C$, 'getPopupType', function () {
return this.popupType;
});

Clazz.newMethod$(C$, 'getPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, x, y) {
if (contents == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Popup.getPopup must be passed non-null contents"]);
}var popupType = p$.getPopupType$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, x, y]);
var popup = p$.getPopup$java_awt_Component$java_awt_Component$I$I$I.apply(this, [owner, contents, x, y, popupType]);
if (popup == null ) {
popup = p$.getPopup$java_awt_Component$java_awt_Component$I$I$I.apply(this, [owner, contents, x, y, 2]);
}return popup;
});

Clazz.newMethod$(C$, 'getPopupType$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
var popupType = this.getPopupType();
if (owner == null  || p$.invokerInHeavyWeightPopup$java_awt_Component.apply(this, [owner]) ) {
popupType = 2;
} else if (popupType == 0 && !(Clazz.instanceOf(contents, "javax.swing.JToolTip"))  && !(Clazz.instanceOf(contents, "javax.swing.JPopupMenu")) ) {
popupType = 1;
}var c = owner;
while (c != null ){
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
if ((c).getClientProperty$O(P$.ClientPropertyKey.PopupFactory_FORCE_HEAVYWEIGHT_POPUP) === Boolean.TRUE ) {
popupType = 2;
break;
}}c = c.getParent();
}
return popupType;
});

Clazz.newMethod$(C$, 'getPopup$java_awt_Component$java_awt_Component$I$I$I', function (owner, contents, ownerX, ownerY, popupType) {
switch (popupType) {
case 0:
return p$.getLightWeightPopup$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
case 1:
return p$.getMediumWeightPopup$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
case 2:
return p$.getHeavyWeightPopup$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
}
return null;
});

Clazz.newMethod$(C$, 'getLightWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
return (I$[14] || (I$[14]=Clazz.load(Clazz.load('javax.swing.PopupFactory').LightWeightPopup))).getLightWeightPopup$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
});

Clazz.newMethod$(C$, 'getMediumWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
return (I$[15] || (I$[15]=Clazz.load(Clazz.load('javax.swing.PopupFactory').MediumWeightPopup))).getMediumWeightPopup$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
});

Clazz.newMethod$(C$, 'getHeavyWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
return (I$[16] || (I$[16]=Clazz.load(Clazz.load('javax.swing.PopupFactory').HeavyWeightPopup))).getHeavyWeightPopup$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
});

Clazz.newMethod$(C$, 'invokerInHeavyWeightPopup$java_awt_Component', function (i) {
if (i != null ) {
var parent;
for (parent = i.getParent(); parent != null ; parent = parent.getParent()) {
if ((I$[2] || (I$[2]=Clazz.load('javax.swing.Popup'))).isHeavyWeight$java_awt_Container(parent)) {
return true;
}}
}return false;
});
;
(function(){var C$=Clazz.newClass$(P$.PopupFactory, "HeavyWeightPopup", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Popup');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.heavyWeightPopupCacheKey =  new Clazz._O();
};

C$.heavyWeightPopupCacheKey = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getHeavyWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
var window = (owner != null ) ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getWindowAncestor$java_awt_Component(owner) : null;
var popup = null;
if (window != null ) {
popup = C$.getRecycledHeavyWeightPopup$java_awt_Window(window);
}var focusPopup = false;
if (contents != null  && contents.isFocusable() ) {
if (Clazz.instanceOf(contents, "javax.swing.JPopupMenu")) {
var jpm = contents;
var popComps = jpm.getComponents();
for (var i = 0; i < popComps.length; i++) {
if (!(Clazz.instanceOf(popComps[i], "javax.swing.MenuElement")) && !(Clazz.instanceOf(popComps[i], "javax.swing.JSeparator")) ) {
focusPopup = true;
break;
}}
}}if (popup == null  || (popup.getComponent()).getFocusableWindowState() != focusPopup  ) {
if (popup != null ) {
popup._dispose();
}popup = Clazz.new(C$);
}popup.reset$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
if (focusPopup) {
var wnd = popup.getComponent();
wnd.setFocusableWindowState$Z(true);
wnd.setName$S("###focusableSwingPopup###");
}return popup;
}, 1);

Clazz.newMethod$(C$, 'getRecycledHeavyWeightPopup$java_awt_Window', function (w) {
{
var cache;
var heavyPopupCache = C$.getHeavyWeightPopupCache();
if (heavyPopupCache.containsKey$O(w)) {
cache = heavyPopupCache.get$O(w);
} else {
return null;
}if ((cache.size()) > 0) {
var r = cache.get$I(0);
cache.removeItemAt$I(0);
return r;
}return null;
}}, 1);

Clazz.newMethod$(C$, 'getHeavyWeightPopupCache', function () {
{
var cache = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.heavyWeightPopupCacheKey);
if (cache == null ) {
cache = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.HashMap'))).c$$I,[2]);
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.heavyWeightPopupCacheKey, cache);
}return cache;
}}, 1);

Clazz.newMethod$(C$, 'recycleHeavyWeightPopup$javax_swing_PopupFactory_HeavyWeightPopup', function (popup) {
{
var cache;
var window = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getWindowAncestor$java_awt_Component(popup.getComponent());
var heavyPopupCache = C$.getHeavyWeightPopupCache();
if ((I$[2] || (I$[2]=Clazz.load('javax.swing.Popup'))).isDefaultFrame$O(window) || !(window).isVisible() ) {
popup._dispose();
return;
} else if (heavyPopupCache.containsKey$O(window)) {
cache = heavyPopupCache.get$O(window);
} else {
cache = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.util.ArrayList'))));
heavyPopupCache.put$TK$TV(window, cache);
var w = window;
w.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass$(P$, "PopupFactory$HeavyWeightPopup$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('java.awt.event.WindowAdapter'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
var popups;
{
var heavyPopupCache2 = P$.PopupFactory.HeavyWeightPopup.getHeavyWeightPopupCache();
popups = heavyPopupCache2.remove$O(this.$finals.w);
}if (popups != null ) {
for (var counter = popups.size() - 1; counter >= 0; counter--) {
(popups.get$I(counter))._dispose();
}
}});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.event.WindowAdapter'))), [this, {w: w}],P$.PopupFactory$HeavyWeightPopup$1)));
}if (cache.size() < 5) {
cache.add$TE(popup);
} else {
popup._dispose();
}}}, 1);

Clazz.newMethod$(C$, 'hide', function () {
C$.superClazz.prototype.hide.apply(this, []);
C$.recycleHeavyWeightPopup$javax_swing_PopupFactory_HeavyWeightPopup(this);
});

Clazz.newMethod$(C$, 'dispose', function () {
});

Clazz.newMethod$(C$, '_dispose', function () {
C$.superClazz.prototype.dispose.apply(this, []);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.PopupFactory, "ContainerPopup", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Popup');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.owner = null;
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMethod$(C$, 'hide', function () {
var component = this.getComponent();
if (component != null ) {
var parent = component.getParent();
if (parent != null ) {
var bounds = component.getBounds();
parent.remove$java_awt_Component(component);
parent.repaint$I$I$I$I(bounds.x, bounds.y, bounds.width, bounds.height);
}}this.owner = null;
});

Clazz.newMethod$(C$, 'pack', function () {
var component = this.getComponent();
if (component != null ) {
component.setSize$java_awt_Dimension(component.getPreferredSize());
}});

Clazz.newMethod$(C$, 'reset$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
if ((Clazz.instanceOf(owner, "javax.swing.JFrame")) || (Clazz.instanceOf(owner, "javax.swing.JDialog")) || (Clazz.instanceOf(owner, "javax.swing.JWindow"))  ) {
owner = (owner).getLayeredPane();
}C$.superClazz.prototype.reset$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
this.x = ownerX;
this.y = ownerY;
this.owner = owner;
});

Clazz.newMethod$(C$, 'overlappedByOwnedWindow', function () {
var component = this.getComponent();
if (this.owner != null  && component != null  ) {
var w = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getWindowAncestor$java_awt_Component(this.owner);
if (w == null ) {
return false;
}var ownedWindows = w.getOwnedWindows();
if (ownedWindows != null ) {
var bnd = component.getBounds();
for (var i = 0; i < ownedWindows.length; i++) {
var owned = ownedWindows[i];
if (owned.isVisible() && bnd.intersects$java_awt_Rectangle(owned.getBounds()) ) {
return true;
}}
}}return false;
});

Clazz.newMethod$(C$, 'fitsOnScreen', function () {
var component = this.getComponent();
if (this.owner != null  && component != null  ) {
var parent;
var width = component.getWidth();
var height = component.getHeight();
for (parent = this.owner.getParent(); parent != null ; parent = parent.getParent()) {
if (Clazz.instanceOf(parent, "javax.swing.JFrame") || Clazz.instanceOf(parent, "javax.swing.JDialog") || Clazz.instanceOf(parent, "javax.swing.JWindow")  ) {
var r = parent.getBounds();
var i = parent.getInsets();
r.x = r.x+(i.left);
r.y = r.y+(i.top);
r.width = r.width-((i.left + i.right));
r.height = r.height-((i.top + i.bottom));
var gc = parent.getGraphicsConfiguration();
var popupArea = this.getContainerPopupArea$java_awt_GraphicsConfiguration(gc);
return r.intersection$java_awt_Rectangle(popupArea).contains$I$I$I$I(this.x, this.y, width, height);
} else if (Clazz.instanceOf(parent, "javax.swing.JApplet")) {
var r = parent.getBounds();
var p = parent.getLocationOnScreen();
r.x = p.x;
r.y = p.y;
return r.contains$I$I$I$I(this.x, this.y, width, height);
} else if (Clazz.instanceOf(parent, "java.awt.Window") || Clazz.instanceOf(parent, "java.applet.Applet") ) {
break;
}}
}return false;
});

Clazz.newMethod$(C$, 'getContainerPopupArea$java_awt_GraphicsConfiguration', function (gc) {
var screenBounds;
var toolkit = (I$[5] || (I$[5]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit();
var insets;
if (gc != null ) {
screenBounds = gc.getBounds();
insets = toolkit.getScreenInsets$java_awt_GraphicsConfiguration(gc);
} else {
screenBounds = Clazz.new((I$[6] || (I$[6]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Dimension,[toolkit.getScreenSize()]);
insets = Clazz.new((I$[7] || (I$[7]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
}screenBounds.x = screenBounds.x+(insets.left);
screenBounds.y = screenBounds.y+(insets.top);
screenBounds.width = screenBounds.width-((insets.left + insets.right));
screenBounds.height = screenBounds.height-((insets.top + insets.bottom));
return screenBounds;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.PopupFactory, "LightWeightPopup", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.PopupFactory.ContainerPopup');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getLightWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
var popup = null;
if (popup == null ) {
popup = Clazz.new(C$);
}popup.reset$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
if (!popup.fitsOnScreen() || popup.overlappedByOwnedWindow() ) {
popup.hide();
return null;
}return popup;
}, 1);

Clazz.newMethod$(C$, 'hide', function () {
C$.superClazz.prototype.hide.apply(this, []);
var component = this.getComponent();
component.removeAll();
});

Clazz.newMethod$(C$, 'show', function () {
var parent = null;
if (this.owner != null ) {
parent = (Clazz.instanceOf(this.owner, "java.awt.Container") ? this.owner : this.owner.getParent());
}for (var p = parent; p != null ; p = p.getParent()) {
if (Clazz.instanceOf(p, "javax.swing.JRootPane")) {
parent = (p).getLayeredPane();
} else if (Clazz.instanceOf(p, "java.awt.Window")) {
if (parent == null ) {
parent = p;
}break;
} else if (Clazz.instanceOf(p, "javax.swing.JApplet")) {
break;
}}
var p = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).convertScreenLocationToParent$java_awt_Container$I$I(parent, this.x, this.y);
var component = this.getComponent();
component.setLocation$I$I(p.x, p.y);
if (Clazz.instanceOf(parent, "javax.swing.JLayeredPane")) {
(parent).add$java_awt_Component$O$I(component, (I$[8] || (I$[8]=Clazz.load('javax.swing.JLayeredPane'))).POPUP_LAYER, 0);
} else {
parent.add$java_awt_Component(component);
}});

Clazz.newMethod$(C$, 'createComponent$java_awt_Component', function (owner) {
var component = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.JPanel'))).c$$java_awt_LayoutManager$Z,[Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.BorderLayout')))), true]);
component.setOpaque$Z(true);
return component;
});

Clazz.newMethod$(C$, 'reset$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
C$.superClazz.prototype.reset$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
var component = this.getComponent();
component.setOpaque$Z(contents.isOpaque());
component.setLocation$I$I(ownerX, ownerY);
component.add$java_awt_Component$O(contents, "Center");
contents.invalidate();
this.pack();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.PopupFactory, "MediumWeightPopup", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.PopupFactory.ContainerPopup');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.mediumWeightPopupCacheKey =  new Clazz._O();
};

C$.mediumWeightPopupCacheKey = null;

Clazz.newMethod$(C$, '$init$', function () {
this.rootPane = null;
}, 1);

Clazz.newMethod$(C$, 'getMediumWeightPopup$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
var popup = C$.getRecycledMediumWeightPopup();
if (popup == null ) {
popup = Clazz.new(C$);
}popup.reset$java_awt_Component$java_awt_Component$I$I(owner, contents, ownerX, ownerY);
if (!popup.fitsOnScreen() || popup.overlappedByOwnedWindow() ) {
popup.hide();
return null;
}return popup;
}, 1);

Clazz.newMethod$(C$, 'getMediumWeightPopupCache', function () {
var cache = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.mediumWeightPopupCacheKey);
if (cache == null ) {
cache = Clazz.new((I$[11] || (I$[11]=Clazz.load('javajs.util.Lst'))));
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.mediumWeightPopupCacheKey, cache);
}return cache;
}, 1);

Clazz.newMethod$(C$, 'recycleMediumWeightPopup$javax_swing_PopupFactory_MediumWeightPopup', function (popup) {
{
var mediumPopupCache = C$.getMediumWeightPopupCache();
if (mediumPopupCache.size() < 5) {
mediumPopupCache.add$TE(popup);
}}}, 1);

Clazz.newMethod$(C$, 'getRecycledMediumWeightPopup', function () {
{
var mediumPopupCache = C$.getMediumWeightPopupCache();
if ((mediumPopupCache.size()) > 0) {
var r = mediumPopupCache.get$I(0);
mediumPopupCache.removeItemAt$I(0);
return r;
}return null;
}}, 1);

Clazz.newMethod$(C$, 'hide', function () {
C$.superClazz.prototype.hide.apply(this, []);
this.rootPane.getContentPane().removeAll();
C$.recycleMediumWeightPopup$javax_swing_PopupFactory_MediumWeightPopup(this);
});

Clazz.newMethod$(C$, 'show', function () {
var component = this.getComponent();
var parent = null;
if (this.owner != null ) {
parent = this.owner.getParent();
}while (!(Clazz.instanceOf(parent, "java.awt.Window") || Clazz.instanceOf(parent, "java.applet.Applet") ) && (parent != null ) ){
parent = parent.getParent();
}
if (Clazz.instanceOf(parent, "javax.swing.RootPaneContainer")) {
parent = (parent).getLayeredPane();
var p = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).convertScreenLocationToParent$java_awt_Container$I$I(parent, this.x, this.y);
component.setVisible$Z(false);
component.setLocation$I$I(p.x, p.y);
(parent).add$java_awt_Component$O$I(component, (I$[8] || (I$[8]=Clazz.load('javax.swing.JLayeredPane'))).POPUP_LAYER, 0);
} else {
var p = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).convertScreenLocationToParent$java_awt_Container$I$I(parent, this.x, this.y);
component.setLocation$I$I(p.x, p.y);
component.setVisible$Z(false);
parent.add$java_awt_Component(component);
}component.setVisible$Z(true);
});

Clazz.newMethod$(C$, 'createComponent$java_awt_Component', function (owner) {
var component = Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load(Clazz.load('javax.swing.PopupFactory').MediumWeightPopup).MediumWeightComponent))));
this.rootPane = Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.JRootPane'))).c$$S$Z,["_Popup" + (++P$.PopupFactory.popupCount), false]);
this.rootPane.setFrameViewer$swingjs_JSFrameViewer((owner).getFrameViewer());
this.rootPane.setOpaque$Z(true);
component.add$java_awt_Component$O(this.rootPane, "Center");
return component;
});

Clazz.newMethod$(C$, 'reset$java_awt_Component$java_awt_Component$I$I', function (owner, contents, ownerX, ownerY) {
C$.superClazz.prototype.reset$java_awt_Component$java_awt_Component$I$I.apply(this, [owner, contents, ownerX, ownerY]);
var component = this.getComponent();
component.setLocation$I$I(ownerX, ownerY);
this.rootPane.getContentPane().add$java_awt_Component$O(contents, "Center");
contents.invalidate();
component.validate();
this.pack();
});
;
(function(){var C$=Clazz.newClass$(P$.PopupFactory.MediumWeightPopup, "MediumWeightComponent", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'java.awt.Panel', 'javax.swing.SwingHeavyWeight');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$java_awt_LayoutManager.apply(this, [Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.BorderLayout'))))]);
C$.$init$.apply(this);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:48
