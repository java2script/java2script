(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JFrame", null, 'java.awt.Frame', ['javax.swing.WindowConstants', 'javax.swing.RootPaneContainer']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.defaultLookAndFeelDecoratedKey =  new Clazz._O();
};

C$.defaultLookAndFeelDecoratedKey = null;
C$.frameCount = 0;

Clazz.newMethod$(C$, '$init$', function () {
this.defaultCloseOperation = 1;
this.transferHandler = null;
this.rootPane = null;
this.rootPaneCheckingEnabled = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$S$java_awt_GraphicsConfiguration.apply(this, [null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
C$.c$$S$java_awt_GraphicsConfiguration.apply(this, [null, gc]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (title) {
C$.c$$S$java_awt_GraphicsConfiguration.apply(this, [title, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$java_awt_GraphicsConfiguration', function (title, gc) {
Clazz.super(C$, this,1);
this.initTitleGC$S$java_awt_GraphicsConfiguration(title, gc);
this.enableEvents$J(72);
this.setLocale$java_util_Locale((I$[0] || (I$[0]=Clazz.load('javax.swing.JComponent'))).getDefaultLocale());
this.uiClassID = "FrameUI";
this.setRootPane$javax_swing_JRootPane(this.createRootPane());
this.rootPane.setFrameViewer$swingjs_JSFrameViewer(this.setFrameViewer$swingjs_JSFrameViewer(null));
this.setBackground$java_awt_Color((I$[1] || (I$[1]=Clazz.load('javax.swing.UIManager'))).getColor$O("control"));
this.setRootPaneCheckingEnabled$Z(true);
if (C$.isDefaultLookAndFeelDecorated()) {
var supportsWindowDecorations = (I$[1] || (I$[1]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getSupportsWindowDecorations();
if (supportsWindowDecorations) {
this.setUndecorated$Z(true);
this.getRootPane().setWindowDecorationStyle$I(1);
}}this.updateUI();
this.addNotify();
this.rootPane.addNotify();
}, 1);

Clazz.newMethod$(C$, 'createRootPane', function () {
var rp = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JRootPane'))).c$$S$Z,["_Frame" + (++C$.frameCount), false]);
rp.setOpaque$Z(true);
return rp;
});

Clazz.newMethod$(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superClazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
switch (this.defaultCloseOperation) {
case 1:
this.setVisible$Z(false);
break;
case 2:
this.dispose();
break;
case 0:
default:
break;
case 3:
System.exit(0);
break;
}
}});

Clazz.newMethod$(C$, 'setDefaultCloseOperation$I', function (operation) {
if (operation != 0 && operation != 1  && operation != 2  && operation != 3 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["defaultCloseOperation must be one of: DO_NOTHING_ON_CLOSE, HIDE_ON_CLOSE, DISPOSE_ON_CLOSE, or EXIT_ON_CLOSE"]);
}if (this.defaultCloseOperation != operation) {
if (operation == 3) {
var security = System.getSecurityManager();
if (security != null ) {
security.checkExit$I(0);
}}var oldValue = this.defaultCloseOperation;
this.defaultCloseOperation = operation;
this.firePropertyChange$S$I$I("defaultCloseOperation", oldValue, operation);
}});

Clazz.newMethod$(C$, 'getDefaultCloseOperation', function () {
return this.defaultCloseOperation;
});

Clazz.newMethod$(C$, 'setTransferHandler$javax_swing_TransferHandler', function (newHandler) {
var oldHandler = this.transferHandler;
this.transferHandler = newHandler;
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).installSwingDropTargetAsNecessary$java_awt_Component$javax_swing_TransferHandler(this, this.transferHandler);
this.firePropertyChange$S$O$O("transferHandler", oldHandler, newHandler);
});

Clazz.newMethod$(C$, 'getTransferHandler', function () {
return this.transferHandler;
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
(g).setBackground$java_awt_Color(this.getBackground());
(g).setColor$java_awt_Color(this.getForeground());
C$.superClazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMethod$(C$, 'setJMenuBar$javax_swing_JMenuBar', function (menubar) {
this.getRootPane().setMenuBar$javax_swing_JMenuBar(menubar);
});

Clazz.newMethod$(C$, 'getJMenuBar', function () {
return this.getRootPane().getMenuBar();
});

Clazz.newMethod$(C$, 'isRootPaneCheckingEnabled', function () {
return this.rootPaneCheckingEnabled;
});

Clazz.newMethod$(C$, 'setRootPaneCheckingEnabled$Z', function (enabled) {
this.rootPaneCheckingEnabled = enabled;
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
if (this.isRootPaneCheckingEnabled()) {
return this.getContentPane().add$java_awt_Component$O$I(comp, constraints, index);
}return this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (comp) {
if (comp === this.rootPane ) {
C$.superClazz.prototype.remove$java_awt_Component.apply(this, [comp]);
} else {
this.getContentPane().remove$java_awt_Component(comp);
}});

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (manager) {
if (this.isRootPaneCheckingEnabled()) {
this.getContentPane().setLayout$java_awt_LayoutManager(manager);
} else {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [manager]);
}});

Clazz.newMethod$(C$, 'getRootPane', function () {
return this.rootPane;
});

Clazz.newMethod$(C$, 'setRootPane$javax_swing_JRootPane', function (root) {
if (this.rootPane != null ) {
this.remove$java_awt_Component(this.rootPane);
}this.rootPane = root;
if (this.rootPane != null ) {
var checkingEnabled = this.isRootPaneCheckingEnabled();
try {
this.setRootPaneCheckingEnabled$Z(false);
this.add$java_awt_Component$O(this.rootPane, "Center");
} finally {
this.setRootPaneCheckingEnabled$Z(checkingEnabled);
}
}});

Clazz.newMethod$(C$, 'setIconImage$java_awt_Image', function (image) {
C$.superClazz.prototype.setIconImage$java_awt_Image.apply(this, [image]);
});

Clazz.newMethod$(C$, 'getContentPane', function () {
return this.getRootPane().getContentPane();
});

Clazz.newMethod$(C$, 'setContentPane$java_awt_Container', function (contentPane) {
this.getRootPane().setContentPane$java_awt_Container(contentPane);
});

Clazz.newMethod$(C$, 'getLayeredPane', function () {
return this.getRootPane().getLayeredPane();
});

Clazz.newMethod$(C$, 'setLayeredPane$javax_swing_JLayeredPane', function (layeredPane) {
this.getRootPane().setLayeredPane$javax_swing_JLayeredPane(layeredPane);
});

Clazz.newMethod$(C$, 'getGlassPane', function () {
return this.getRootPane().getGlassPane();
});

Clazz.newMethod$(C$, 'setGlassPane$java_awt_Component', function (glassPane) {
this.getRootPane().setGlassPane$java_awt_Component(glassPane);
});

Clazz.newMethod$(C$, 'getGraphics', function () {
(I$[0] || (I$[0]=Clazz.load('javax.swing.JComponent'))).getGraphicsInvoked$java_awt_Component(this);
return C$.superClazz.prototype.getGraphics.apply(this, []);
});

Clazz.newMethod$(C$, 'repaint$J$I$I$I$I', function (time, x, y, width, height) {
if ((I$[4] || (I$[4]=Clazz.load('javax.swing.RepaintManager'))).HANDLE_TOP_LEVEL_PAINT) {
(I$[4] || (I$[4]=Clazz.load('javax.swing.RepaintManager'))).currentManager$java_awt_Component(this).addDirtyRegion$java_awt_Window$I$I$I$I(this, x, y, width, height);
} else {
C$.superClazz.prototype.repaint$J$I$I$I$I.apply(this, [time, x, y, width, height]);
}});

Clazz.newMethod$(C$, 'setDefaultLookAndFeelDecorated$Z', function (defaultLookAndFeelDecorated) {
if (defaultLookAndFeelDecorated) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLookAndFeelDecoratedKey, Boolean.TRUE);
} else {
(I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLookAndFeelDecoratedKey, Boolean.FALSE);
}}, 1);

Clazz.newMethod$(C$, 'isDefaultLookAndFeelDecorated', function () {
var defaultLookAndFeelDecorated = (I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.defaultLookAndFeelDecoratedKey);
if (defaultLookAndFeelDecorated == null ) {
defaultLookAndFeelDecorated = Boolean.FALSE;
}return defaultLookAndFeelDecorated.booleanValue();
}, 1);

Clazz.newMethod$(C$, 'paramString', function () {
var defaultCloseOperationString;
if (this.defaultCloseOperation == 1) {
defaultCloseOperationString = "HIDE_ON_CLOSE";
} else if (this.defaultCloseOperation == 2) {
defaultCloseOperationString = "DISPOSE_ON_CLOSE";
} else if (this.defaultCloseOperation == 0) {
defaultCloseOperationString = "DO_NOTHING_ON_CLOSE";
} else if (this.defaultCloseOperation == 3) {
defaultCloseOperationString = "EXIT_ON_CLOSE";
} else defaultCloseOperationString = "";
var rootPaneString = (this.rootPane != null  ? this.rootPane.toString() : "");
var rootPaneCheckingEnabledString = (this.rootPaneCheckingEnabled ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",defaultCloseOperation=" + defaultCloseOperationString + ",rootPane=" + rootPaneString + ",rootPaneCheckingEnabled=" + rootPaneCheckingEnabledString ;
});
})();
//Created 2017-10-14 13:31:38
