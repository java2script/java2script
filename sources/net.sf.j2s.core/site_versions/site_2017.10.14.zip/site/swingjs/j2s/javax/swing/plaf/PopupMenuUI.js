(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "PopupMenuUI", null, 'javax.swing.plaf.ComponentUI');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'isPopupTrigger$java_awt_event_MouseEvent', function (e) {
return e.isPopupTrigger();
});

Clazz.newMethod$(C$, 'getPopup$javax_swing_JPopupMenu$I$I', function (popup, x, y) {
var popupFactory = (I$[0] || (I$[0]=Clazz.load('javax.swing.PopupFactory'))).getSharedInstance();
return popupFactory.getPopup$java_awt_Component$java_awt_Component$I$I(popup.getInvoker(), popup, x, y);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:57
