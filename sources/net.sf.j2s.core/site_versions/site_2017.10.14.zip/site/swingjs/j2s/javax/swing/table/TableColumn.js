(function(){var P$=Clazz.newPackage$("javax.swing.table"),I$=[];
var C$=Clazz.newClass$(P$, "TableColumn");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.modelIndex = 0;
this.identifier = null;
this.width = 0;
this.minWidth = 0;
this.preferredWidth = 0;
this.maxWidth = 0;
this.headerRenderer = null;
this.headerValue = null;
this.cellRenderer = null;
this.cellEditor = null;
this.isResizable = false;
this.resizedPostingDisableCount = 0;
this.changeSupport = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (modelIndex) {
C$.c$$I$I$javax_swing_table_TableCellRenderer$javax_swing_table_TableCellEditor.apply(this, [modelIndex, 75, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (modelIndex, width) {
C$.c$$I$I$javax_swing_table_TableCellRenderer$javax_swing_table_TableCellEditor.apply(this, [modelIndex, width, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$javax_swing_table_TableCellRenderer$javax_swing_table_TableCellEditor', function (modelIndex, width, cellRenderer, cellEditor) {
C$.$init$.apply(this);
this.modelIndex = modelIndex;
this.preferredWidth = this.width = Math.max(width, 0);
this.cellRenderer = cellRenderer;
this.cellEditor = cellEditor;
this.minWidth = Math.min(15, this.width);
this.maxWidth = 2147483647;
this.isResizable = true;
this.resizedPostingDisableCount = 0;
this.headerValue = null;
}, 1);

Clazz.newMethod$(C$, 'firePropertyChange$S$O$O', function (propertyName, oldValue, newValue) {
if (this.changeSupport != null ) {
this.changeSupport.firePropertyChange$S$O$O(propertyName, oldValue, newValue);
}});

Clazz.newMethod$(C$, 'firePropertyChange$S$I$I', function (propertyName, oldValue, newValue) {
if (oldValue != newValue) {
p$.firePropertyChange$S$O$O.apply(this, [propertyName,  new Integer(oldValue),  new Integer(newValue)]);
}});

Clazz.newMethod$(C$, 'firePropertyChange$S$Z$Z', function (propertyName, oldValue, newValue) {
if (oldValue != newValue ) {
p$.firePropertyChange$S$O$O.apply(this, [propertyName, (I$[0] || (I$[0]=Clazz.load('Boolean'))).$valueOf(oldValue), (I$[0] || (I$[0]=Clazz.load('Boolean'))).$valueOf(newValue)]);
}});

Clazz.newMethod$(C$, 'setModelIndex$I', function (modelIndex) {
var old = this.modelIndex;
this.modelIndex = modelIndex;
p$.firePropertyChange$S$I$I.apply(this, ["modelIndex", old, modelIndex]);
});

Clazz.newMethod$(C$, 'getModelIndex', function () {
return this.modelIndex;
});

Clazz.newMethod$(C$, 'setIdentifier$O', function (identifier) {
var old = this.identifier;
this.identifier = identifier;
p$.firePropertyChange$S$O$O.apply(this, ["identifier", old, identifier]);
});

Clazz.newMethod$(C$, 'getIdentifier', function () {
return (this.identifier != null ) ? this.identifier : this.getHeaderValue();
});

Clazz.newMethod$(C$, 'setHeaderValue$O', function (headerValue) {
var old = this.headerValue;
this.headerValue = headerValue;
p$.firePropertyChange$S$O$O.apply(this, ["headerValue", old, headerValue]);
});

Clazz.newMethod$(C$, 'getHeaderValue', function () {
return this.headerValue;
});

Clazz.newMethod$(C$, 'setHeaderRenderer$javax_swing_table_TableCellRenderer', function (headerRenderer) {
var old = this.headerRenderer;
this.headerRenderer = headerRenderer;
p$.firePropertyChange$S$O$O.apply(this, ["headerRenderer", old, headerRenderer]);
});

Clazz.newMethod$(C$, 'getHeaderRenderer', function () {
return this.headerRenderer;
});

Clazz.newMethod$(C$, 'setCellRenderer$javax_swing_table_TableCellRenderer', function (cellRenderer) {
var old = this.cellRenderer;
this.cellRenderer = cellRenderer;
p$.firePropertyChange$S$O$O.apply(this, ["cellRenderer", old, cellRenderer]);
});

Clazz.newMethod$(C$, 'getCellRenderer', function () {
return this.cellRenderer;
});

Clazz.newMethod$(C$, 'setCellEditor$javax_swing_table_TableCellEditor', function (cellEditor) {
var old = this.cellEditor;
this.cellEditor = cellEditor;
p$.firePropertyChange$S$O$O.apply(this, ["cellEditor", old, cellEditor]);
});

Clazz.newMethod$(C$, 'getCellEditor', function () {
return this.cellEditor;
});

Clazz.newMethod$(C$, 'setWidth$I', function (width) {
var old = this.width;
this.width = Math.min(Math.max(width, this.minWidth), this.maxWidth);
p$.firePropertyChange$S$I$I.apply(this, ["width", old, this.width]);
});

Clazz.newMethod$(C$, 'getWidth', function () {
return this.width;
});

Clazz.newMethod$(C$, 'setPreferredWidth$I', function (preferredWidth) {
var old = this.preferredWidth;
this.preferredWidth = Math.min(Math.max(preferredWidth, this.minWidth), this.maxWidth);
p$.firePropertyChange$S$I$I.apply(this, ["preferredWidth", old, this.preferredWidth]);
});

Clazz.newMethod$(C$, 'getPreferredWidth', function () {
return this.preferredWidth;
});

Clazz.newMethod$(C$, 'setMinWidth$I', function (minWidth) {
var old = this.minWidth;
this.minWidth = Math.max(Math.min(minWidth, this.maxWidth), 0);
if (this.width < this.minWidth) {
this.setWidth$I(this.minWidth);
}if (this.preferredWidth < this.minWidth) {
this.setPreferredWidth$I(this.minWidth);
}p$.firePropertyChange$S$I$I.apply(this, ["minWidth", old, this.minWidth]);
});

Clazz.newMethod$(C$, 'getMinWidth', function () {
return this.minWidth;
});

Clazz.newMethod$(C$, 'setMaxWidth$I', function (maxWidth) {
var old = this.maxWidth;
this.maxWidth = Math.max(this.minWidth, maxWidth);
if (this.width > this.maxWidth) {
this.setWidth$I(this.maxWidth);
}if (this.preferredWidth > this.maxWidth) {
this.setPreferredWidth$I(this.maxWidth);
}p$.firePropertyChange$S$I$I.apply(this, ["maxWidth", old, this.maxWidth]);
});

Clazz.newMethod$(C$, 'getMaxWidth', function () {
return this.maxWidth;
});

Clazz.newMethod$(C$, 'setResizable$Z', function (isResizable) {
var old = this.isResizable;
this.isResizable = isResizable;
p$.firePropertyChange$S$Z$Z.apply(this, ["isResizable", old, this.isResizable]);
});

Clazz.newMethod$(C$, 'getResizable', function () {
return this.isResizable;
});

Clazz.newMethod$(C$, 'sizeWidthToFit', function () {
if (this.headerRenderer == null ) {
return;
}var c = this.headerRenderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(null, this.getHeaderValue(), false, false, 0, 0);
this.setMinWidth$I(c.getMinimumSize().width);
this.setMaxWidth$I(c.getMaximumSize().width);
this.setPreferredWidth$I(c.getPreferredSize().width);
this.setWidth$I(this.getPreferredWidth());
});

Clazz.newMethod$(C$, 'disableResizedPosting', function () {
this.resizedPostingDisableCount++;
});

Clazz.newMethod$(C$, 'enableResizedPosting', function () {
this.resizedPostingDisableCount--;
});

Clazz.newMethod$(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
if (this.changeSupport == null ) {
this.changeSupport = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.SwingPropertyChangeSupport'))).c$$O,[this]);
}this.changeSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(listener);
});

Clazz.newMethod$(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (listener) {
if (this.changeSupport != null ) {
this.changeSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(listener);
}});

Clazz.newMethod$(C$, 'getPropertyChangeListeners', function () {
if (this.changeSupport == null ) {
return  Clazz.newArray$(java.beans.PropertyChangeListener, [0]);
}return this.changeSupport.getPropertyChangeListeners();
});

Clazz.newMethod$(C$, 'createDefaultHeaderRenderer', function () {
var label = ((
(function(){var C$=Clazz.newClass$(P$, "TableColumn$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.table.DefaultTableCellRenderer'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, value, isSelected, hasFocus, row, column) {
if (table != null ) {
var header = table.getTableHeader();
if (header != null ) {
this.setForeground$java_awt_Color(header.getForeground());
this.setBackground$java_awt_Color(header.getBackground());
this.setFont$java_awt_Font(header.getFont());
}}this.setText$S((value == null ) ? "" : value.toString());
this.setBorder$javax_swing_border_Border((I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getBorder$O("TableHeader.cellBorder"));
return this;
});
})()
), Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.table.DefaultTableCellRenderer'))), [this, null],P$.TableColumn$1));
label.setHorizontalAlignment$I(0);
return label;
});
})();
//Created 2017-10-14 13:32:00
