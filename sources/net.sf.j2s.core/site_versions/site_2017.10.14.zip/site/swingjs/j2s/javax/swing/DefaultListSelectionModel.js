(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultListSelectionModel", null, null, ['javax.swing.ListSelectionModel', 'Cloneable']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.selectionMode = 2;
this.minIndex = 2147483647;
this.maxIndex = -1;
this.anchorIndex = -1;
this.leadIndex = -1;
this.firstAdjustedIndex = 2147483647;
this.lastAdjustedIndex = -1;
this.isAdjusting = false;
this.firstChangedIndex = 2147483647;
this.lastChangedIndex = -1;
this.value = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.BitSet'))).c$$I,[32]);
this.listenerList = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.EventListenerList'))));
this.leadAnchorNotificationEnabled = true;
}, 1);

Clazz.newMethod$(C$, 'getMinSelectionIndex', function () {
return this.isSelectionEmpty() ? -1 : this.minIndex;
});

Clazz.newMethod$(C$, 'getMaxSelectionIndex', function () {
return this.maxIndex;
});

Clazz.newMethod$(C$, 'getValueIsAdjusting', function () {
return this.isAdjusting;
});

Clazz.newMethod$(C$, 'getSelectionMode', function () {
return this.selectionMode;
});

Clazz.newMethod$(C$, 'setSelectionMode$I', function (selectionMode) {
switch (selectionMode) {
case 0:
case 1:
case 2:
this.selectionMode = selectionMode;
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid selectionMode"]);
}
});

Clazz.newMethod$(C$, 'isSelectedIndex$I', function (index) {
return ((index < this.minIndex) || (index > this.maxIndex) ) ? false : this.value.get$I(index);
});

Clazz.newMethod$(C$, 'isSelectionEmpty', function () {
return (this.minIndex > this.maxIndex);
});

Clazz.newMethod$(C$, 'addListSelectionListener$javax_swing_event_ListSelectionListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ListSelectionListener), l);
});

Clazz.newMethod$(C$, 'removeListSelectionListener$javax_swing_event_ListSelectionListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ListSelectionListener), l);
});

Clazz.newMethod$(C$, 'getListSelectionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ListSelectionListener));
});

Clazz.newMethod$(C$, 'fireValueChanged$Z', function (isAdjusting) {
if (this.lastChangedIndex == -1) {
return;
}var oldFirstChangedIndex = this.firstChangedIndex;
var oldLastChangedIndex = this.lastChangedIndex;
this.firstChangedIndex = 2147483647;
this.lastChangedIndex = -1;
this.fireValueChanged$I$I$Z(oldFirstChangedIndex, oldLastChangedIndex, isAdjusting);
});

Clazz.newMethod$(C$, 'fireValueChanged$I$I', function (firstIndex, lastIndex) {
this.fireValueChanged$I$I$Z(firstIndex, lastIndex, this.getValueIsAdjusting());
});

Clazz.newMethod$(C$, 'fireValueChanged$I$I$Z', function (firstIndex, lastIndex, isAdjusting) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ListSelectionListener) ) {
if (e == null ) {
e = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.event.ListSelectionEvent'))).c$$O$I$I$Z,[this, firstIndex, lastIndex, isAdjusting]);
}(listeners[i + 1]).valueChanged$javax_swing_event_ListSelectionEvent(e);
}}
});

Clazz.newMethod$(C$, 'fireValueChanged', function () {
if (this.lastAdjustedIndex == -1) {
return;
}if (this.getValueIsAdjusting()) {
this.firstChangedIndex = Math.min(this.firstChangedIndex, this.firstAdjustedIndex);
this.lastChangedIndex = Math.max(this.lastChangedIndex, this.lastAdjustedIndex);
}var oldFirstAdjustedIndex = this.firstAdjustedIndex;
var oldLastAdjustedIndex = this.lastAdjustedIndex;
this.firstAdjustedIndex = 2147483647;
this.lastAdjustedIndex = -1;
this.fireValueChanged$I$I(oldFirstAdjustedIndex, oldLastAdjustedIndex);
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'markAsDirty$I', function (r) {
this.firstAdjustedIndex = Math.min(this.firstAdjustedIndex, r);
this.lastAdjustedIndex = Math.max(this.lastAdjustedIndex, r);
});

Clazz.newMethod$(C$, 'set$I', function (r) {
if (this.value.get$I(r)) {
return;
}this.value.set$I(r);
p$.markAsDirty$I.apply(this, [r]);
this.minIndex = Math.min(this.minIndex, r);
this.maxIndex = Math.max(this.maxIndex, r);
});

Clazz.newMethod$(C$, 'clear$I', function (r) {
if (!this.value.get$I(r)) {
return;
}this.value.clear$I(r);
p$.markAsDirty$I.apply(this, [r]);
if (r == this.minIndex) {
for (this.minIndex = this.minIndex + 1; this.minIndex <= this.maxIndex; this.minIndex++) {
if (this.value.get$I(this.minIndex)) {
break;
}}
}if (r == this.maxIndex) {
for (this.maxIndex = this.maxIndex - 1; this.minIndex <= this.maxIndex; this.maxIndex--) {
if (this.value.get$I(this.maxIndex)) {
break;
}}
}if (this.isSelectionEmpty()) {
this.minIndex = 2147483647;
this.maxIndex = -1;
}});

Clazz.newMethod$(C$, 'setLeadAnchorNotificationEnabled$Z', function (flag) {
this.leadAnchorNotificationEnabled = flag;
});

Clazz.newMethod$(C$, 'isLeadAnchorNotificationEnabled', function () {
return this.leadAnchorNotificationEnabled;
});

Clazz.newMethod$(C$, 'updateLeadAnchorIndices$I$I', function (anchorIndex, leadIndex) {
if (this.leadAnchorNotificationEnabled) {
if (this.anchorIndex != anchorIndex) {
if (this.anchorIndex != -1) {
p$.markAsDirty$I.apply(this, [this.anchorIndex]);
}p$.markAsDirty$I.apply(this, [anchorIndex]);
}if (this.leadIndex != leadIndex) {
if (this.leadIndex != -1) {
p$.markAsDirty$I.apply(this, [this.leadIndex]);
}p$.markAsDirty$I.apply(this, [leadIndex]);
}}this.anchorIndex = anchorIndex;
this.leadIndex = leadIndex;
});

Clazz.newMethod$(C$, 'contains$I$I$I', function (a, b, i) {
return (i >= a) && (i <= b) ;
});

Clazz.newMethod$(C$, 'changeSelection$I$I$I$I$Z', function (clearMin, clearMax, setMin, setMax, clearFirst) {
for (var i = Math.min(setMin, clearMin); i <= Math.max(setMax, clearMax); i++) {
var shouldClear = p$.contains$I$I$I.apply(this, [clearMin, clearMax, i]);
var shouldSet = p$.contains$I$I$I.apply(this, [setMin, setMax, i]);
if (shouldSet && shouldClear ) {
if (clearFirst) {
shouldClear = false;
} else {
shouldSet = false;
}}if (shouldSet) {
p$.set$I.apply(this, [i]);
}if (shouldClear) {
p$.clear$I.apply(this, [i]);
}}
p$.fireValueChanged.apply(this, []);
});

Clazz.newMethod$(C$, 'changeSelection$I$I$I$I', function (clearMin, clearMax, setMin, setMax) {
p$.changeSelection$I$I$I$I$Z.apply(this, [clearMin, clearMax, setMin, setMax, true]);
});

Clazz.newMethod$(C$, 'clearSelection', function () {
p$.removeSelectionIntervalImpl$I$I$Z.apply(this, [this.minIndex, this.maxIndex, false]);
});

Clazz.newMethod$(C$, 'setSelectionInterval$I$I', function (index0, index1) {
if (index0 == -1 || index1 == -1 ) {
return;
}if (this.getSelectionMode() == 0) {
index0 = index1;
}p$.updateLeadAnchorIndices$I$I.apply(this, [index0, index1]);
var clearMin = this.minIndex;
var clearMax = this.maxIndex;
var setMin = Math.min(index0, index1);
var setMax = Math.max(index0, index1);
p$.changeSelection$I$I$I$I.apply(this, [clearMin, clearMax, setMin, setMax]);
});

Clazz.newMethod$(C$, 'addSelectionInterval$I$I', function (index0, index1) {
if (index0 == -1 || index1 == -1 ) {
return;
}if (this.getSelectionMode() == 0) {
this.setSelectionInterval$I$I(index0, index1);
return;
}p$.updateLeadAnchorIndices$I$I.apply(this, [index0, index1]);
var clearMin = 2147483647;
var clearMax = -1;
var setMin = Math.min(index0, index1);
var setMax = Math.max(index0, index1);
if (this.getSelectionMode() == 1 && (setMax < this.minIndex - 1 || setMin > this.maxIndex + 1 ) ) {
this.setSelectionInterval$I$I(index0, index1);
return;
}p$.changeSelection$I$I$I$I.apply(this, [clearMin, clearMax, setMin, setMax]);
});

Clazz.newMethod$(C$, 'removeSelectionInterval$I$I', function (index0, index1) {
p$.removeSelectionIntervalImpl$I$I$Z.apply(this, [index0, index1, true]);
});

Clazz.newMethod$(C$, 'removeSelectionIntervalImpl$I$I$Z', function (index0, index1, changeLeadAnchor) {
if (index0 == -1 || index1 == -1 ) {
return;
}if (changeLeadAnchor) {
p$.updateLeadAnchorIndices$I$I.apply(this, [index0, index1]);
}var clearMin = Math.min(index0, index1);
var clearMax = Math.max(index0, index1);
var setMin = 2147483647;
var setMax = -1;
if (this.getSelectionMode() != 2 && clearMin > this.minIndex  && clearMax < this.maxIndex ) {
clearMax = this.maxIndex;
}p$.changeSelection$I$I$I$I.apply(this, [clearMin, clearMax, setMin, setMax]);
});

Clazz.newMethod$(C$, 'setState$I$Z', function (index, state) {
if (state) {
p$.set$I.apply(this, [index]);
} else {
p$.clear$I.apply(this, [index]);
}});

Clazz.newMethod$(C$, 'insertIndexInterval$I$I$Z', function (index, length, before) {
var insMinIndex = (before) ? index : index + 1;
var insMaxIndex = (insMinIndex + length) - 1;
for (var i = this.maxIndex; i >= insMinIndex; i--) {
p$.setState$I$Z.apply(this, [i + length, this.value.get$I(i)]);
}
var setInsertedValues = ((this.getSelectionMode() == 0) ? false : this.value.get$I(index));
for (var i = insMinIndex; i <= insMaxIndex; i++) {
p$.setState$I$Z.apply(this, [i, setInsertedValues]);
}
var leadIndex = this.leadIndex;
if (leadIndex > index || (before && leadIndex == index ) ) {
leadIndex = this.leadIndex + length;
}var anchorIndex = this.anchorIndex;
if (anchorIndex > index || (before && anchorIndex == index ) ) {
anchorIndex = this.anchorIndex + length;
}if (leadIndex != this.leadIndex || anchorIndex != this.anchorIndex ) {
p$.updateLeadAnchorIndices$I$I.apply(this, [anchorIndex, leadIndex]);
}p$.fireValueChanged.apply(this, []);
});

Clazz.newMethod$(C$, 'removeIndexInterval$I$I', function (index0, index1) {
var rmMinIndex = Math.min(index0, index1);
var rmMaxIndex = Math.max(index0, index1);
var gapLength = (rmMaxIndex - rmMinIndex) + 1;
for (var i = rmMinIndex; i <= this.maxIndex; i++) {
p$.setState$I$Z.apply(this, [i, this.value.get$I(i + gapLength)]);
}
var leadIndex = this.leadIndex;
if (leadIndex == 0 && rmMinIndex == 0 ) {
} else if (leadIndex > rmMaxIndex) {
leadIndex = this.leadIndex - gapLength;
} else if (leadIndex >= rmMinIndex) {
leadIndex = rmMinIndex - 1;
}var anchorIndex = this.anchorIndex;
if (anchorIndex == 0 && rmMinIndex == 0 ) {
} else if (anchorIndex > rmMaxIndex) {
anchorIndex = this.anchorIndex - gapLength;
} else if (anchorIndex >= rmMinIndex) {
anchorIndex = rmMinIndex - 1;
}if (leadIndex != this.leadIndex || anchorIndex != this.anchorIndex ) {
p$.updateLeadAnchorIndices$I$I.apply(this, [anchorIndex, leadIndex]);
}p$.fireValueChanged.apply(this, []);
});

Clazz.newMethod$(C$, 'setValueIsAdjusting$Z', function (isAdjusting) {
if (isAdjusting != this.isAdjusting ) {
this.isAdjusting = isAdjusting;
this.fireValueChanged$Z(isAdjusting);
}});

Clazz.newMethod$(C$, 'toString', function () {
var s = ((this.getValueIsAdjusting()) ? "~" : "=") + this.value.toString();
return this.getClass().getName() + " " + Integer.toString(this.hashCode()) + " " + s ;
});

Clazz.newMethod$(C$, 'clone', function () {
var clone = Clazz.clone(this);
clone.value = this.value.clone();
clone.listenerList = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.EventListenerList'))));
return clone;
});

Clazz.newMethod$(C$, 'getAnchorSelectionIndex', function () {
return this.anchorIndex;
});

Clazz.newMethod$(C$, 'getLeadSelectionIndex', function () {
return this.leadIndex;
});

Clazz.newMethod$(C$, 'setAnchorSelectionIndex$I', function (anchorIndex) {
p$.updateLeadAnchorIndices$I$I.apply(this, [anchorIndex, this.leadIndex]);
p$.fireValueChanged.apply(this, []);
});

Clazz.newMethod$(C$, 'moveLeadSelectionIndex$I', function (leadIndex) {
if (leadIndex == -1) {
if (this.anchorIndex != -1) {
return;
}}p$.updateLeadAnchorIndices$I$I.apply(this, [this.anchorIndex, leadIndex]);
p$.fireValueChanged.apply(this, []);
});

Clazz.newMethod$(C$, 'setLeadSelectionIndex$I', function (leadIndex) {
var anchorIndex = this.anchorIndex;
if (leadIndex == -1) {
if (anchorIndex == -1) {
p$.updateLeadAnchorIndices$I$I.apply(this, [anchorIndex, leadIndex]);
p$.fireValueChanged.apply(this, []);
}return;
} else if (anchorIndex == -1) {
return;
}if (this.leadIndex == -1) {
this.leadIndex = leadIndex;
}var shouldSelect = this.value.get$I(this.anchorIndex);
if (this.getSelectionMode() == 0) {
anchorIndex = leadIndex;
shouldSelect = true;
}var oldMin = Math.min(this.anchorIndex, this.leadIndex);
var oldMax = Math.max(this.anchorIndex, this.leadIndex);
var newMin = Math.min(anchorIndex, leadIndex);
var newMax = Math.max(anchorIndex, leadIndex);
p$.updateLeadAnchorIndices$I$I.apply(this, [anchorIndex, leadIndex]);
if (shouldSelect) {
p$.changeSelection$I$I$I$I.apply(this, [oldMin, oldMax, newMin, newMax]);
} else {
p$.changeSelection$I$I$I$I$Z.apply(this, [newMin, newMax, oldMin, oldMax, false]);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:32
