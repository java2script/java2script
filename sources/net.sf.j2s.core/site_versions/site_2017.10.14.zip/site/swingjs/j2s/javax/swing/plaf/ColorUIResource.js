(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "ColorUIResource", null, 'java.awt.Color', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I', function (r, g, b) {
C$.superClazz.c$$I$I$I.apply(this, [r, g, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (rgb) {
C$.superClazz.c$$I.apply(this, [rgb]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$F$F$F', function (r, g, b) {
C$.superClazz.c$$F$F$F.apply(this, [r, g, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color', function (c) {
C$.superClazz.c$$I$Z.apply(this, [c.getRGB(), (c.getRGB() & -16777216) != -16777216]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-10-14 13:31:55
