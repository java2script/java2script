(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractSpinnerModel", null, null, 'javax.swing.SpinnerModel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.changeEvent = null;
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
}, 1);

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'getChangeListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ChangeListener));
});

Clazz.newMethod$(C$, 'fireStateChanged', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ChangeListener) ) {
if (this.changeEvent == null ) {
this.changeEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
}(listeners[i + 1]).stateChanged$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:30
