(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "MenuKeyEvent", null, 'java.awt.event.KeyEvent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.path = null;
this.manager = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$I$J$I$I$C$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (source, id, when, modifiers, keyCode, keyChar, p, m) {
C$.superClazz.c$$java_awt_Component$I$J$I$I$C.apply(this, [source, id, when, modifiers, keyCode, keyChar]);
C$.$init$.apply(this);
this.path = p;
this.manager = m;
}, 1);

Clazz.newMethod$(C$, 'getPath', function () {
return this.path;
});

Clazz.newMethod$(C$, 'getMenuSelectionManager', function () {
return this.manager;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
