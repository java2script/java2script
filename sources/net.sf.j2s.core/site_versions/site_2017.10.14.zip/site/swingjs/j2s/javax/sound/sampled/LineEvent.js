(function(){var P$=Clazz.newPackage$("javax.sound.sampled");
var C$=Clazz.newClass$(P$, "LineEvent", function(){
Clazz.newInstance$(this, arguments);
}, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.type = null;
this.position = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_sound_sampled_Line$javax_sound_sampled_LineEvent_Type$J', function (line, type, position) {
C$.superClazz.c$.apply(this, [line]);
C$.$init$.apply(this);
this.type = type;
this.position = position;
}, 1);

Clazz.newMethod$(C$, 'getLine', function () {
return this.getSource();
});

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'getFramePosition', function () {
return this.position;
});

Clazz.newMethod$(C$, 'toString', function () {
var sType = "";
if (this.type != null ) sType = this.type.toString() + " ";
var sLine;
if (this.getLine() == null ) {
sLine = "null";
} else {
sLine = this.getLine().toString();
}return  String.instantialize(sType + "event from line " + sLine );
});
;
(function(){var C$=Clazz.newClass$(P$.LineEvent, "Type", function(){
Clazz.newInstance$(this, arguments[0], false);
});

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.OPEN = Clazz.new(C$.c$$S,["Open"]);
C$.CLOSE = Clazz.new(C$.c$$S,["Close"]);
C$.START = Clazz.new(C$.c$$S,["Start"]);
C$.STOP = Clazz.new(C$.c$$S,["Stop"]);
};

C$.OPEN = null;
C$.CLOSE = null;
C$.START = null;
C$.STOP = null;

Clazz.newMethod$(C$, '$init$', function () {
this.name = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name = name;
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (obj) {
return C$.superClazz.prototype.equals$O.apply(this, [obj]);
});

Clazz.newMethod$(C$, 'hashCode', function () {
return C$.superClazz.prototype.hashCode.apply(this, []);
});

Clazz.newMethod$(C$, 'toString', function () {
return this.name;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:29
