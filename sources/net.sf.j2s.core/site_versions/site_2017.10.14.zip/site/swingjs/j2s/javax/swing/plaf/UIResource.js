(function(){var P$=Clazz.newPackage$("javax.swing.plaf");
var C$=Clazz.newInterface$(P$, "UIResource");

})();
//Created 2017-10-14 13:31:58
