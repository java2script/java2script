(function(){var P$=Clazz.newPackage$("javax.swing.colorchooser"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultRGBChooserPanel", null, 'javax.swing.colorchooser.AbstractColorChooserPanel', 'javax.swing.event.ChangeListener');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.redSlider = null;
this.greenSlider = null;
this.blueSlider = null;
this.redField = null;
this.blueField = null;
this.greenField = null;
this.minValue = 0;
this.maxValue = 255;
this.isAdjusting = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setInheritsPopupMenu$Z(true);
}, 1);

Clazz.newMethod$(C$, 'setColor$java_awt_Color', function (newColor) {
var red = newColor.getRed();
var blue = newColor.getBlue();
var green = newColor.getGreen();
if (this.redSlider.getValue() != red) {
this.redSlider.setValue$I(red);
}if (this.greenSlider.getValue() != green) {
this.greenSlider.setValue$I(green);
}if (this.blueSlider.getValue() != blue) {
this.blueSlider.setValue$I(blue);
}if ((this.redField.getValue()).intValue() != red) this.redField.setValue$O( new Integer(red));
if ((this.greenField.getValue()).intValue() != green) this.greenField.setValue$O( new Integer(green));
if ((this.blueField.getValue()).intValue() != blue) this.blueField.setValue$O( new Integer(blue));
});

Clazz.newMethod$(C$, 'getDisplayName', function () {
return (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.rgbNameText");
});

Clazz.newMethod$(C$, 'getMnemonic', function () {
return P$.AbstractColorChooserPanel.getInt$O$I("ColorChooser.rgbMnemonic", -1);
});

Clazz.newMethod$(C$, 'getDisplayedMnemonicIndex', function () {
return P$.AbstractColorChooserPanel.getInt$O$I("ColorChooser.rgbDisplayedMnemonicIndex", -1);
});

Clazz.newMethod$(C$, 'getSmallDisplayIcon', function () {
return null;
});

Clazz.newMethod$(C$, 'getLargeDisplayIcon', function () {
return null;
});

Clazz.newMethod$(C$, 'installChooserPanel$javax_swing_JColorChooser', function (enclosingChooser) {
C$.superClazz.prototype.installChooserPanel$javax_swing_JColorChooser.apply(this, [enclosingChooser]);
});

Clazz.newMethod$(C$, 'buildChooser', function () {
var redString = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.rgbRedText");
var greenString = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.rgbGreenText");
var blueString = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.rgbBlueText");
this.setLayout$java_awt_LayoutManager(Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.BorderLayout')))));
var color = this.getColorFromModel();
var enclosure = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JPanel'))));
enclosure.setLayout$java_awt_LayoutManager(Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.colorchooser.SmartGridLayout'))).c$$I$I,[3, 3]));
enclosure.setInheritsPopupMenu$Z(true);
this.add$java_awt_Component$O(enclosure, "Center");
var l = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JLabel'))).c$$S,[redString]);
l.setDisplayedMnemonic$I((I$[5] || (I$[5]=Clazz.load('javax.swing.colorchooser.AbstractColorChooserPanel'))).getInt$O$I("ColorChooser.rgbRedMnemonic", -1));
enclosure.add$java_awt_Component(l);
this.redSlider = Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JSlider'))).c$$I$I$I$I,[0, 0, 255, color.getRed()]);
this.redSlider.setMajorTickSpacing$I(85);
this.redSlider.setMinorTickSpacing$I(17);
this.redSlider.setPaintTicks$Z(true);
this.redSlider.setPaintLabels$Z(true);
this.redSlider.setInheritsPopupMenu$Z(true);
enclosure.add$java_awt_Component(this.redSlider);
this.redField = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.JSpinner'))).c$$javax_swing_SpinnerModel,[Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.SpinnerNumberModel'))).c$$I$I$I$I,[color.getRed(), 0, 255, 1])]);
l.setLabelFor$java_awt_Component(this.redSlider);
this.redField.setInheritsPopupMenu$Z(true);
var redFieldHolder = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JPanel'))).c$$java_awt_LayoutManager,[Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.colorchooser.CenterLayout'))))]);
redFieldHolder.setInheritsPopupMenu$Z(true);
this.redField.addChangeListener$javax_swing_event_ChangeListener(this);
redFieldHolder.add$java_awt_Component(this.redField);
enclosure.add$java_awt_Component(redFieldHolder);
l = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JLabel'))).c$$S,[greenString]);
l.setDisplayedMnemonic$I((I$[5] || (I$[5]=Clazz.load('javax.swing.colorchooser.AbstractColorChooserPanel'))).getInt$O$I("ColorChooser.rgbGreenMnemonic", -1));
enclosure.add$java_awt_Component(l);
this.greenSlider = Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JSlider'))).c$$I$I$I$I,[0, 0, 255, color.getGreen()]);
this.greenSlider.setMajorTickSpacing$I(85);
this.greenSlider.setMinorTickSpacing$I(17);
this.greenSlider.setPaintTicks$Z(true);
this.greenSlider.setPaintLabels$Z(true);
this.greenSlider.setInheritsPopupMenu$Z(true);
enclosure.add$java_awt_Component(this.greenSlider);
this.greenField = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.JSpinner'))).c$$javax_swing_SpinnerModel,[Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.SpinnerNumberModel'))).c$$I$I$I$I,[color.getGreen(), 0, 255, 1])]);
l.setLabelFor$java_awt_Component(this.greenSlider);
this.greenField.setInheritsPopupMenu$Z(true);
var greenFieldHolder = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JPanel'))).c$$java_awt_LayoutManager,[Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.colorchooser.CenterLayout'))))]);
greenFieldHolder.add$java_awt_Component(this.greenField);
greenFieldHolder.setInheritsPopupMenu$Z(true);
this.greenField.addChangeListener$javax_swing_event_ChangeListener(this);
enclosure.add$java_awt_Component(greenFieldHolder);
l = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JLabel'))).c$$S,[blueString]);
l.setDisplayedMnemonic$I((I$[5] || (I$[5]=Clazz.load('javax.swing.colorchooser.AbstractColorChooserPanel'))).getInt$O$I("ColorChooser.rgbBlueMnemonic", -1));
enclosure.add$java_awt_Component(l);
this.blueSlider = Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JSlider'))).c$$I$I$I$I,[0, 0, 255, color.getBlue()]);
this.blueSlider.setMajorTickSpacing$I(85);
this.blueSlider.setMinorTickSpacing$I(17);
this.blueSlider.setPaintTicks$Z(true);
this.blueSlider.setPaintLabels$Z(true);
this.blueSlider.setInheritsPopupMenu$Z(true);
enclosure.add$java_awt_Component(this.blueSlider);
this.blueField = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.JSpinner'))).c$$javax_swing_SpinnerModel,[Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.SpinnerNumberModel'))).c$$I$I$I$I,[color.getBlue(), 0, 255, 1])]);
l.setLabelFor$java_awt_Component(this.blueSlider);
this.blueField.setInheritsPopupMenu$Z(true);
var blueFieldHolder = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JPanel'))).c$$java_awt_LayoutManager,[Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.colorchooser.CenterLayout'))))]);
blueFieldHolder.add$java_awt_Component(this.blueField);
this.blueField.addChangeListener$javax_swing_event_ChangeListener(this);
blueFieldHolder.setInheritsPopupMenu$Z(true);
enclosure.add$java_awt_Component(blueFieldHolder);
this.redSlider.addChangeListener$javax_swing_event_ChangeListener(this);
this.greenSlider.addChangeListener$javax_swing_event_ChangeListener(this);
this.blueSlider.addChangeListener$javax_swing_event_ChangeListener(this);
this.redSlider.putClientProperty$O$O("JSlider.isFilled", Boolean.TRUE);
this.greenSlider.putClientProperty$O$O("JSlider.isFilled", Boolean.TRUE);
this.blueSlider.putClientProperty$O$O("JSlider.isFilled", Boolean.TRUE);
});

Clazz.newMethod$(C$, 'uninstallChooserPanel$javax_swing_JColorChooser', function (enclosingChooser) {
C$.superClazz.prototype.uninstallChooserPanel$javax_swing_JColorChooser.apply(this, [enclosingChooser]);
this.removeAll();
});

Clazz.newMethod$(C$, 'updateChooser', function () {
if (!this.isAdjusting) {
this.isAdjusting = true;
p$.setColor$java_awt_Color.apply(this, [this.getColorFromModel()]);
this.isAdjusting = false;
}});

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
if (Clazz.instanceOf(e.getSource(), "javax.swing.JSlider") && !this.isAdjusting ) {
var red = this.redSlider.getValue();
var green = this.greenSlider.getValue();
var blue = this.blueSlider.getValue();
var color = Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.Color'))).c$$I$I$I,[red, green, blue]);
this.getColorSelectionModel().setSelectedColor$java_awt_Color(color);
} else if (Clazz.instanceOf(e.getSource(), "javax.swing.JSpinner") && !this.isAdjusting ) {
var red = (this.redField.getValue()).intValue();
var green = (this.greenField.getValue()).intValue();
var blue = (this.blueField.getValue()).intValue();
var color = Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.Color'))).c$$I$I$I,[red, green, blue]);
this.getColorSelectionModel().setSelectedColor$java_awt_Color(color);
}});
})();
//Created 2017-10-14 13:31:53
