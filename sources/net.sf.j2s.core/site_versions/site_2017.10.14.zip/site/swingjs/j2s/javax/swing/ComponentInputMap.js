(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "ComponentInputMap", null, 'javax.swing.InputMap');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.component = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComponent', function (component) {
Clazz.super(C$, this,1);
this.component = component;
if (component == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ComponentInputMaps must be associated with a non-null JComponent"]);
}}, 1);

Clazz.newMethod$(C$, 'setParent$javax_swing_InputMap', function (map) {
if (this.getParent() === map ) {
return;
}if (map != null  && (!(Clazz.instanceOf(map, "javax.swing.ComponentInputMap")) || (map).getComponent() !== this.getComponent()  ) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ComponentInputMaps must have a parent ComponentInputMap associated with the same component"]);
}C$.superClazz.prototype.setParent$javax_swing_InputMap.apply(this, [map]);
this.getComponent().componentInputMapChanged$javax_swing_ComponentInputMap(this);
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this.component;
});

Clazz.newMethod$(C$, 'put$javax_swing_KeyStroke$O', function (keyStroke, actionMapKey) {
C$.superClazz.prototype.put$javax_swing_KeyStroke$O.apply(this, [keyStroke, actionMapKey]);
if (this.getComponent() != null ) {
this.getComponent().componentInputMapChanged$javax_swing_ComponentInputMap(this);
}});

Clazz.newMethod$(C$, 'remove$javax_swing_KeyStroke', function (key) {
C$.superClazz.prototype.remove$javax_swing_KeyStroke.apply(this, [key]);
if (this.getComponent() != null ) {
this.getComponent().componentInputMapChanged$javax_swing_ComponentInputMap(this);
}});

Clazz.newMethod$(C$, 'clear', function () {
var oldSize = this.size();
C$.superClazz.prototype.clear.apply(this, []);
if (oldSize > 0 && this.getComponent() != null  ) {
this.getComponent().componentInputMapChanged$javax_swing_ComponentInputMap(this);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:32
