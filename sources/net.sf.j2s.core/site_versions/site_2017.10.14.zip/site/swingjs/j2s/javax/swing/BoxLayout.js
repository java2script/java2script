(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "BoxLayout", null, null, 'java.awt.LayoutManager2');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.axis = 0;
this.target = null;
this.xChildren = null;
this.yChildren = null;
this.xTotal = null;
this.yTotal = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Container$I', function (target, axis) {
C$.$init$.apply(this);
if (axis != 0 && axis != 1  && axis != 2  && axis != 3 ) {
throw Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.AWTError'))).c$$S,["Invalid axis"]);
}this.axis = axis;
this.target = target;
}, 1);

Clazz.newMethod$(C$, 'getTarget', function () {
return this.target;
});

Clazz.newMethod$(C$, 'getAxis', function () {
return this.axis;
});

Clazz.newMethod$(C$, 'invalidateLayout$java_awt_Container', function (target) {
this.checkContainer$java_awt_Container(target);
this.xChildren = null;
this.yChildren = null;
this.xTotal = null;
this.yTotal = null;
});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
this.invalidateLayout$java_awt_Container(comp.getParent());
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
this.invalidateLayout$java_awt_Container(comp.getParent());
});

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
this.invalidateLayout$java_awt_Container(comp.getParent());
});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
var size;
{
this.checkContainer$java_awt_Container(target);
this.checkRequests();
size = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[this.xTotal.preferred, this.yTotal.preferred]);
}var insets = target.getInsets();
size.width = ($i$[0] = Math.min(size.width + insets.left + insets.right , 2147483647), $i$[0]);
size.height = ($i$[0] = Math.min(size.height + insets.top + insets.bottom , 2147483647), $i$[0]);
return size;
});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
var size;
{
this.checkContainer$java_awt_Container(target);
this.checkRequests();
size = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[this.xTotal.minimum, this.yTotal.minimum]);
}var insets = target.getInsets();
size.width = ($i$[0] = Math.min(size.width + insets.left + insets.right , 2147483647), $i$[0]);
size.height = ($i$[0] = Math.min(size.height + insets.top + insets.bottom , 2147483647), $i$[0]);
return size;
});

Clazz.newMethod$(C$, 'maximumLayoutSize$java_awt_Container', function (target) {
var size;
{
this.checkContainer$java_awt_Container(target);
this.checkRequests();
size = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[this.xTotal.maximum, this.yTotal.maximum]);
}var insets = target.getInsets();
size.width = ($i$[0] = Math.min(size.width + insets.left + insets.right , 2147483647), $i$[0]);
size.height = ($i$[0] = Math.min(size.height + insets.top + insets.bottom , 2147483647), $i$[0]);
return size;
});

Clazz.newMethod$(C$, 'getLayoutAlignmentX$java_awt_Container', function (target) {
this.checkContainer$java_awt_Container(target);
this.checkRequests();
return this.xTotal.alignment;
});

Clazz.newMethod$(C$, 'getLayoutAlignmentY$java_awt_Container', function (target) {
this.checkContainer$java_awt_Container(target);
this.checkRequests();
return this.yTotal.alignment;
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (target) {
this.checkContainer$java_awt_Container(target);
var nChildren = target.getComponentCount();
var xOffsets =  Clazz.newArray$(Integer.TYPE, [nChildren]);
var xSpans =  Clazz.newArray$(Integer.TYPE, [nChildren]);
var yOffsets =  Clazz.newArray$(Integer.TYPE, [nChildren]);
var ySpans =  Clazz.newArray$(Integer.TYPE, [nChildren]);
var alloc = target.getSize();
var $in = target.getInsets();
alloc.width = alloc.width-($in.left + $in.right);
alloc.height = alloc.height-($in.top + $in.bottom);
var o = target.getComponentOrientation();
var absoluteAxis = p$.resolveAxis$I$java_awt_ComponentOrientation.apply(this, [this.axis, o]);
var ltr = (absoluteAxis != this.axis) ? o.isLeftToRight() : true;
{
this.checkRequests();
if (absoluteAxis == 0) {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).calcTiled$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(alloc.width, this.xTotal, this.xChildren, xOffsets, xSpans, ltr);
(I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).calcAligned$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(alloc.height, this.yTotal, this.yChildren, yOffsets, ySpans, true);
} else {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).calcAligned$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(alloc.width, this.xTotal, this.xChildren, xOffsets, xSpans, ltr);
(I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).calcTiled$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(alloc.height, this.yTotal, this.yChildren, yOffsets, ySpans, true);
}}for (var i = 0; i < nChildren; i++) {
var c = target.getComponent$I(i);
c.setBounds$I$I$I$I(($i$[0] = Math.min($in.left + xOffsets[i], 2147483647), $i$[0]), ($i$[0] = Math.min($in.top + yOffsets[i], 2147483647), $i$[0]), xSpans[i], ySpans[i]);
}
});

Clazz.newMethod$(C$, 'checkContainer$java_awt_Container', function (target) {
if (this.target !== target ) {
throw Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.AWTError'))).c$$S,["BoxLayout can\'t be shared"]);
}});

Clazz.newMethod$(C$, 'checkRequests', function () {
if (this.xChildren == null  || this.yChildren == null  ) {
var n = this.target.getComponentCount();
this.xChildren =  Clazz.newArray$(javax.swing.SizeRequirements, [n]);
this.yChildren =  Clazz.newArray$(javax.swing.SizeRequirements, [n]);
for (var i = 0; i < n; i++) {
var c = this.target.getComponent$I(i);
if (!c.isVisible()) {
this.xChildren[i] = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).c$$I$I$I$F,[0, 0, 0, c.getAlignmentX()]);
this.yChildren[i] = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).c$$I$I$I$F,[0, 0, 0, c.getAlignmentY()]);
continue;
}var min = c.getMinimumSize();
var typ = c.getPreferredSize();
var max = c.getMaximumSize();
this.xChildren[i] = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).c$$I$I$I$F,[min.width, typ.width, max.width, c.getAlignmentX()]);
this.yChildren[i] = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).c$$I$I$I$F,[min.height, typ.height, max.height, c.getAlignmentY()]);
}
var absoluteAxis = p$.resolveAxis$I$java_awt_ComponentOrientation.apply(this, [this.axis, this.target.getComponentOrientation()]);
if (absoluteAxis == 0) {
this.xTotal = (I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).getTiledSizeRequirements$javax_swing_SizeRequirementsA(this.xChildren);
this.yTotal = (I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).getAlignedSizeRequirements$javax_swing_SizeRequirementsA(this.yChildren);
} else {
this.xTotal = (I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).getAlignedSizeRequirements$javax_swing_SizeRequirementsA(this.xChildren);
this.yTotal = (I$[2] || (I$[2]=Clazz.load('javax.swing.SizeRequirements'))).getTiledSizeRequirements$javax_swing_SizeRequirementsA(this.yChildren);
}}});

Clazz.newMethod$(C$, 'resolveAxis$I$java_awt_ComponentOrientation', function (axis, o) {
var absoluteAxis;
if (axis == 2) {
absoluteAxis = o.isHorizontal() ? 0 : 1;
} else if (axis == 3) {
absoluteAxis = o.isHorizontal() ? 1 : 0;
} else {
absoluteAxis = axis;
}return absoluteAxis;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:31
