(function(){var P$=Clazz.newPackage$("javax.swing.table"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultTableModel", null, 'javax.swing.table.AbstractTableModel');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.dataVector = null;
this.columnIdentifiers = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I$I.apply(this, [0, 0]);
}, 1);

Clazz.newMethod$(C$, 'newVector$I', function (size) {
var v = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))).c$$I,[size]);
v.setSize$I(size);
return v;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (rowCount, columnCount) {
C$.c$$java_util_Vector$I.apply(this, [C$.newVector$I(columnCount), rowCount]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Vector$I', function (columnNames, rowCount) {
Clazz.super(C$, this,1);
this.setDataVector$java_util_Vector$java_util_Vector(C$.newVector$I(rowCount), columnNames);
}, 1);

Clazz.newMethod$(C$, 'c$$OA$I', function (columnNames, rowCount) {
C$.c$$java_util_Vector$I.apply(this, [C$.convertToVector$OA(columnNames), rowCount]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Vector$java_util_Vector', function (data, columnNames) {
Clazz.super(C$, this,1);
this.setDataVector$java_util_Vector$java_util_Vector(data, columnNames);
}, 1);

Clazz.newMethod$(C$, 'c$$OAA$OA', function (data, columnNames) {
Clazz.super(C$, this,1);
this.setDataVector$OAA$OA(data, columnNames);
}, 1);

Clazz.newMethod$(C$, 'getDataVector', function () {
return this.dataVector;
});

Clazz.newMethod$(C$, 'nonNullVector$java_util_Vector', function (v) {
return (v != null ) ? v : Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))));
}, 1);

Clazz.newMethod$(C$, 'setDataVector$java_util_Vector$java_util_Vector', function (dataVector, columnIdentifiers) {
this.dataVector = C$.nonNullVector$java_util_Vector(dataVector);
this.columnIdentifiers = C$.nonNullVector$java_util_Vector(columnIdentifiers);
p$.justifyRows$I$I.apply(this, [0, this.getRowCount()]);
this.fireTableStructureChanged();
});

Clazz.newMethod$(C$, 'setDataVector$OAA$OA', function (dataVector, columnIdentifiers) {
this.setDataVector$java_util_Vector$java_util_Vector(C$.convertToVector$OAA(dataVector), C$.convertToVector$OA(columnIdentifiers));
});

Clazz.newMethod$(C$, 'newDataAvailable$javax_swing_event_TableModelEvent', function (event) {
this.fireTableChanged$javax_swing_event_TableModelEvent(event);
});

Clazz.newMethod$(C$, 'justifyRows$I$I', function (from, to) {
this.dataVector.setSize$I(this.getRowCount());
for (var i = from; i < to; i++) {
if (this.dataVector.elementAt$I(i) == null ) {
this.dataVector.setElementAt$TE$I(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector')))), i);
}(this.dataVector.elementAt$I(i)).setSize$I(this.getColumnCount());
}
});

Clazz.newMethod$(C$, 'newRowsAdded$javax_swing_event_TableModelEvent', function (e) {
p$.justifyRows$I$I.apply(this, [e.getFirstRow(), e.getLastRow() + 1]);
this.fireTableChanged$javax_swing_event_TableModelEvent(e);
});

Clazz.newMethod$(C$, 'rowsRemoved$javax_swing_event_TableModelEvent', function (event) {
this.fireTableChanged$javax_swing_event_TableModelEvent(event);
});

Clazz.newMethod$(C$, 'setNumRows$I', function (rowCount) {
var old = this.getRowCount();
if (old == rowCount) {
return;
}this.dataVector.setSize$I(rowCount);
if (rowCount <= old) {
this.fireTableRowsDeleted$I$I(rowCount, old - 1);
} else {
p$.justifyRows$I$I.apply(this, [old, rowCount]);
this.fireTableRowsInserted$I$I(old, rowCount - 1);
}});

Clazz.newMethod$(C$, 'setRowCount$I', function (rowCount) {
this.setNumRows$I(rowCount);
});

Clazz.newMethod$(C$, 'addRow$java_util_Vector', function (rowData) {
this.insertRow$I$java_util_Vector(this.getRowCount(), rowData);
});

Clazz.newMethod$(C$, 'addRow$OA', function (rowData) {
this.addRow$java_util_Vector(C$.convertToVector$OA(rowData));
});

Clazz.newMethod$(C$, 'insertRow$I$java_util_Vector', function (row, rowData) {
this.dataVector.insertElementAt$TE$I(rowData, row);
p$.justifyRows$I$I.apply(this, [row, row + 1]);
this.fireTableRowsInserted$I$I(row, row);
});

Clazz.newMethod$(C$, 'insertRow$I$OA', function (row, rowData) {
this.insertRow$I$java_util_Vector(row, C$.convertToVector$OA(rowData));
});

Clazz.newMethod$(C$, 'gcd$I$I', function (i, j) {
return (j == 0) ? i : C$.gcd$I$I(j, i % j);
}, 1);

Clazz.newMethod$(C$, 'rotate$java_util_Vector$I$I$I', function (v, a, b, shift) {
var size = b - a;
var r = size - shift;
var g = C$.gcd$I$I(size, r);
for (var i = 0; i < g; i++) {
var to = i;
var tmp = v.elementAt$I(a + to);
for (var from = (to + r) % size; from != i; from = (to + r) % size) {
v.setElementAt$TE$I(v.elementAt$I(a + from), a + to);
to = from;
}
v.setElementAt$TE$I(tmp, a + to);
}
}, 1);

Clazz.newMethod$(C$, 'moveRow$I$I$I', function (start, end, to) {
var shift = to - start;
var first;
var last;
if (shift < 0) {
first = to;
last = end;
} else {
first = start;
last = to + end - start;
}C$.rotate$java_util_Vector$I$I$I(this.dataVector, first, last + 1, shift);
this.fireTableRowsUpdated$I$I(first, last);
});

Clazz.newMethod$(C$, 'removeRow$I', function (row) {
this.dataVector.removeElementAt$I(row);
this.fireTableRowsDeleted$I$I(row, row);
});

Clazz.newMethod$(C$, 'setColumnIdentifiers$java_util_Vector', function (columnIdentifiers) {
this.setDataVector$java_util_Vector$java_util_Vector(this.dataVector, columnIdentifiers);
});

Clazz.newMethod$(C$, 'setColumnIdentifiers$OA', function (newIdentifiers) {
this.setColumnIdentifiers$java_util_Vector(C$.convertToVector$OA(newIdentifiers));
});

Clazz.newMethod$(C$, 'setColumnCount$I', function (columnCount) {
this.columnIdentifiers.setSize$I(columnCount);
p$.justifyRows$I$I.apply(this, [0, this.getRowCount()]);
this.fireTableStructureChanged();
});

Clazz.newMethod$(C$, 'addColumn$O', function (columnName) {
this.addColumn$O$java_util_Vector(columnName, null);
});

Clazz.newMethod$(C$, 'addColumn$O$java_util_Vector', function (columnName, columnData) {
this.columnIdentifiers.addElement$TE(columnName);
if (columnData != null ) {
var columnSize = columnData.size();
if (columnSize > this.getRowCount()) {
this.dataVector.setSize$I(columnSize);
}p$.justifyRows$I$I.apply(this, [0, this.getRowCount()]);
var newColumn = this.getColumnCount() - 1;
for (var i = 0; i < columnSize; i++) {
var row = this.dataVector.elementAt$I(i);
row.setElementAt$TE$I(columnData.elementAt$I(i), newColumn);
}
} else {
p$.justifyRows$I$I.apply(this, [0, this.getRowCount()]);
}this.fireTableStructureChanged();
});

Clazz.newMethod$(C$, 'addColumn$O$OA', function (columnName, columnData) {
this.addColumn$O$java_util_Vector(columnName, C$.convertToVector$OA(columnData));
});

Clazz.newMethod$(C$, 'getRowCount', function () {
return this.dataVector.size();
});

Clazz.newMethod$(C$, 'getColumnCount', function () {
return this.columnIdentifiers.size();
});

Clazz.newMethod$(C$, 'getColumnName$I', function (column) {
var id = null;
if (column < this.columnIdentifiers.size() && (column >= 0) ) {
id = this.columnIdentifiers.elementAt$I(column);
}return (id == null ) ? C$.superClazz.prototype.getColumnName$I.apply(this, [column]) : id.toString();
});

Clazz.newMethod$(C$, 'isCellEditable$I$I', function (row, column) {
return true;
});

Clazz.newMethod$(C$, 'getValueAt$I$I', function (row, column) {
var rowVector = this.dataVector.elementAt$I(row);
return rowVector.elementAt$I(column);
});

Clazz.newMethod$(C$, 'setValueAt$O$I$I', function (aValue, row, column) {
var rowVector = this.dataVector.elementAt$I(row);
rowVector.setElementAt$TE$I(aValue, column);
this.fireTableCellUpdated$I$I(row, column);
});

Clazz.newMethod$(C$, 'convertToVector$OA', function (anArray) {
if (anArray == null ) {
return null;
}var v = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))).c$$I,[anArray.length]);
for (var i = 0; i < anArray.length; i++) {
v.addElement$TE(anArray[i]);
}
return v;
}, 1);

Clazz.newMethod$(C$, 'convertToVector$OAA', function (anArray) {
if (anArray == null ) {
return null;
}var v = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))).c$$I,[anArray.length]);
for (var i = 0; i < anArray.length; i++) {
v.addElement$TE(C$.convertToVector$OA(anArray[i]));
}
return v;
}, 1);
})();
//Created 2017-10-14 13:31:59
