(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "MultiUIDefaults", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.UIDefaults');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.tables = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_UIDefaultsA', function (defaults) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.tables = defaults;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.tables =  Clazz.newArray$(javax.swing.UIDefaults, [0]);
}, 1);

Clazz.newMethod$(C$, 'get$O', function (key) {
var value = C$.superClazz.prototype.get$O.apply(this, [key]);
if (value != null ) {
return value;
}for (var i = 0; i < this.tables.length; i++) {
var table = this.tables[i];
value = (table != null ) ? table.get$O(key) : null;
if (value != null ) {
return value;
}}
return null;
});

Clazz.newMethod$(C$, 'get$O$java_util_Locale', function (key, l) {
var value = C$.superClazz.prototype.get$O$java_util_Locale.apply(this, [key, l]);
if (value != null ) {
return value;
}for (var i = 0; i < this.tables.length; i++) {
var table = this.tables[i];
value = (table != null ) ? table.get$O$java_util_Locale(key, l) : null;
if (value != null ) {
return value;
}}
return null;
});

Clazz.newMethod$(C$, 'size', function () {
return this.entrySet().size();
});

Clazz.newMethod$(C$, 'isEmpty', function () {
return this.size() == 0;
});

Clazz.newMethod$(C$, 'keys', function () {
return Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.MultiUIDefaults').MultiUIDefaultsEnumerator))).c$$javax_swing_MultiUIDefaults_MultiUIDefaultsEnumerator_Type$java_util_Set,[(I$[1] || (I$[1]=Clazz.load(Clazz.load(Clazz.load('javax.swing.MultiUIDefaults').MultiUIDefaultsEnumerator).Type))).KEYS, this.entrySet()]);
});

Clazz.newMethod$(C$, 'elements', function () {
return Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.MultiUIDefaults').MultiUIDefaultsEnumerator))).c$$javax_swing_MultiUIDefaults_MultiUIDefaultsEnumerator_Type$java_util_Set,[(I$[1] || (I$[1]=Clazz.load(Clazz.load(Clazz.load('javax.swing.MultiUIDefaults').MultiUIDefaultsEnumerator).Type))).ELEMENTS, this.entrySet()]);
});

Clazz.newMethod$(C$, 'entrySet', function () {
var set = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.util.HashSet'))));
for (var i = this.tables.length - 1; i >= 0; i--) {
if (this.tables[i] != null ) {
set.addAll$java_util_Collection(this.tables[i].entrySet());
}}
set.addAll$java_util_Collection(C$.superClazz.prototype.entrySet.apply(this, []));
return set;
});

Clazz.newMethod$(C$, 'getUIError$S', function (msg) {
if (this.tables.length > 0) {
this.tables[0].getUIError$S(msg);
} else {
C$.superClazz.prototype.getUIError$S.apply(this, [msg]);
}});

Clazz.newMethod$(C$, 'remove$O', function (key) {
var value = null;
for (var i = this.tables.length - 1; i >= 0; i--) {
if (this.tables[i] != null ) {
var v = this.tables[i].remove$O(key);
if (v != null ) {
value = v;
}}}
var v = C$.superClazz.prototype.remove$O.apply(this, [key]);
if (v != null ) {
value = v;
}return value;
});

Clazz.newMethod$(C$, 'clear', function () {
C$.superClazz.prototype.clear.apply(this, []);
for (var i = 0; i < this.tables.length; i++) {
var table = this.tables[i];
if (table != null ) {
table.clear();
}}
});

Clazz.newMethod$(C$, 'toString', function () {
var buf = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.lang.StringBuffer'))));
buf.append$S("{");
var keys = this.keys();
while (keys.hasMoreElements()){
var key = keys.nextElement();
buf.append$S(key + "=" + this.get$O(key) + ", " );
}
var length = buf.length$();
if (length > 1) {
buf.$delete$I$I(length - 2, length);
}buf.append$S("}");
return buf.toString();
});
;
(function(){var C$=Clazz.newClass$(P$.MultiUIDefaults, "MultiUIDefaultsEnumerator", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'java.util.Enumeration');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.iterator = null;
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_MultiUIDefaults_MultiUIDefaultsEnumerator_Type$java_util_Set', function (type, entries) {
C$.$init$.apply(this);
this.type = type;
this.iterator = entries.iterator();
}, 1);

Clazz.newMethod$(C$, 'hasMoreElements', function () {
return this.iterator.hasNext();
});

Clazz.newMethod$(C$, 'nextElement', function () {
switch (this.type) {
case C$.Type.KEYS:
return this.iterator.next().getKey();
case C$.Type.ELEMENTS:
return this.iterator.next().getValue();
default:
return null;
}
});
;
(function(){var C$=Clazz.newClass$(P$.MultiUIDefaults.MultiUIDefaultsEnumerator, "Type", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "KEYS", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "ELEMENTS", 1, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:48
