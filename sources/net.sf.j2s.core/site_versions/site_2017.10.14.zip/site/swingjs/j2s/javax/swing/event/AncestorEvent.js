(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "AncestorEvent", null, 'java.awt.AWTEvent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.ancestor = null;
this.ancestorParent = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComponent$I$java_awt_Container$java_awt_Container', function (source, id, ancestor, ancestorParent) {
C$.superClazz.c$$O$I.apply(this, [source, id]);
C$.$init$.apply(this);
this.ancestor = ancestor;
this.ancestorParent = ancestorParent;
}, 1);

Clazz.newMethod$(C$, 'getAncestor', function () {
return this.ancestor;
});

Clazz.newMethod$(C$, 'getAncestorParent', function () {
return this.ancestorParent;
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this.getSource();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:53
