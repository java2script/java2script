(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newClass$(P$, "DefaultFormatterFactory", null, 'javax.swing.JFormattedTextField.AbstractFormatterFactory');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.defaultFormat = null;
this.displayFormat = null;
this.editFormat = null;
this.nullFormat = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatter', function (defaultFormat) {
Clazz.super(C$, this,1);
p$.set$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter.apply(this, [defaultFormat, null, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (defaultFormat, displayFormat) {
Clazz.super(C$, this,1);
p$.set$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter.apply(this, [defaultFormat, displayFormat, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (defaultFormat, displayFormat, editFormat) {
Clazz.super(C$, this,1);
p$.set$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter.apply(this, [defaultFormat, displayFormat, editFormat, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (defaultFormat, displayFormat, editFormat, nullFormat) {
Clazz.super(C$, this,1);
{
defaultFormat || (defaultFormat = null);
displayFormat || (displayFormat = null);
editFormat || (editFormat = null);
nullFormat || (nullFormat = null);
}p$.set$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter.apply(this, [defaultFormat, displayFormat, editFormat, nullFormat]);
}, 1);

Clazz.newMethod$(C$, 'set$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (defaultFormat, displayFormat, editFormat, nullFormat) {
this.defaultFormat = defaultFormat;
this.displayFormat = displayFormat;
this.editFormat = editFormat;
this.nullFormat = nullFormat;
return this;
});

Clazz.newMethod$(C$, 'setDefaultFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (atf) {
this.defaultFormat = atf;
});

Clazz.newMethod$(C$, 'getDefaultFormatter', function () {
return this.defaultFormat;
});

Clazz.newMethod$(C$, 'setDisplayFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (atf) {
this.displayFormat = atf;
});

Clazz.newMethod$(C$, 'getDisplayFormatter', function () {
return this.displayFormat;
});

Clazz.newMethod$(C$, 'setEditFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (atf) {
this.editFormat = atf;
});

Clazz.newMethod$(C$, 'getEditFormatter', function () {
return this.editFormat;
});

Clazz.newMethod$(C$, 'setNullFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (atf) {
this.nullFormat = atf;
});

Clazz.newMethod$(C$, 'getNullFormatter', function () {
return this.nullFormat;
});

Clazz.newMethod$(C$, 'getFormatter$javax_swing_JFormattedTextField', function (source) {
var format = null;
if (source == null ) {
return null;
}var value = source.getValue();
if (value == null ) {
format = this.getNullFormatter();
}if (format == null ) {
if (source.hasFocus()) {
format = this.getEditFormatter();
} else {
format = this.getDisplayFormatter();
}if (format == null ) {
format = this.getDefaultFormatter();
}}return format;
});
})();
//Created 2017-10-14 13:32:02
