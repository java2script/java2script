(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newInterface$(P$, "TreeExpansionListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:54
