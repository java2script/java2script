(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "DocumentFilter", function(){
Clazz.newInstance$(this, arguments);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'remove$javax_swing_text_DocumentFilter_FilterBypass$I$I', function (fb, offset, length) {
fb.remove$I$I(offset, length);
});

Clazz.newMethod$(C$, 'insertString$javax_swing_text_DocumentFilter_FilterBypass$I$S$javax_swing_text_AttributeSet', function (fb, offset, string, attr) {
fb.insertString$I$S$javax_swing_text_AttributeSet(offset, string, attr);
});

Clazz.newMethod$(C$, 'replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, text, attrs) {
fb.replace$I$I$S$javax_swing_text_AttributeSet(offset, length, text, attrs);
});
;
(function(){var C$=Clazz.newClass$(P$.DocumentFilter, "FilterBypass", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
