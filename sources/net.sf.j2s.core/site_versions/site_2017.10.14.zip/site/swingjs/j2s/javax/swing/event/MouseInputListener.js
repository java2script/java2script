(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newInterface$(P$, "MouseInputListener", null, null, ['java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:54
