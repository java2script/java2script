(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newClass$(P$, "EventListenerList");
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.NULL_ARRAY =  Clazz.newArray$(java.lang.Object, [0]);
};

C$.NULL_ARRAY = null;

Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = C$.NULL_ARRAY;
}, 1);

Clazz.newMethod$(C$, 'getListenerList', function () {
return this.listenerList;
});

Clazz.newMethod$(C$, 'getListeners$Class', function (t) {
var lList = this.listenerList;
var n = p$.getListenerCount$OA$Class.apply(this, [lList, t]);
var result = Clazz.newArray$(t, n);
var j = 0;
for (var i = lList.length - 2; i >= 0; i = i-(2)) {
if (lList[i] === t ) {
result[j++] = lList[i + 1];
}}
return result;
});

Clazz.newMethod$(C$, 'getListenerCount', function () {
return ($i$[0] = this.listenerList.length/2, $i$[0]);
});

Clazz.newMethod$(C$, 'getListenerCount$Class', function (t) {
var lList = this.listenerList;
return p$.getListenerCount$OA$Class.apply(this, [lList, t]);
});

Clazz.newMethod$(C$, 'getListenerCount$OA$Class', function (list, t) {
var count = 0;
for (var i = 0; i < list.length; i = i+(2)) {
if (t === list[i] ) count++;
}
return count;
});

Clazz.newMethod$(C$, 'add$Class$TT', function (t, l) {
if (l == null ) {
return;
}if (this.listenerList === C$.NULL_ARRAY ) {
this.listenerList =  Clazz.newArray$(java.lang.Object, -1, [t, l]);
} else {
var i = this.listenerList.length;
var tmp =  Clazz.newArray$(java.lang.Object, [i + 2]);
System.arraycopy(this.listenerList, 0, tmp, 0, i);
tmp[i] = t;
tmp[i + 1] = l;
this.listenerList = tmp;
}});

Clazz.newMethod$(C$, 'remove$Class$TT', function (t, l) {
if (l == null ) {
return;
}var index = -1;
for (var i = this.listenerList.length - 2; i >= 0; i = i-(2)) {
if ((this.listenerList[i] === t ) && (this.listenerList[i + 1].equals$O(l) == true ) ) {
index = i;
break;
}}
if (index != -1) {
var tmp =  Clazz.newArray$(java.lang.Object, [this.listenerList.length - 2]);
System.arraycopy(this.listenerList, 0, tmp, 0, index);
if (index < tmp.length) System.arraycopy(this.listenerList, index + 2, tmp, index, tmp.length - index);
this.listenerList = (tmp.length == 0) ? C$.NULL_ARRAY : tmp;
}});

Clazz.newMethod$(C$, 'toString', function () {
var lList = this.listenerList;
var s = "EventListenerList: ";
s += ($i$[0] = lList.length/2, $i$[0]) + " listeners: ";
for (var i = 0; i <= lList.length - 2; i = i+(2)) {
s += " type " + (lList[i]).getName();
s += " listener " + lList[i + 1];
}
return s;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
