(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JTextField", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.JTextComponent', 'javax.swing.SwingConstants');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.defaultActions =  Clazz.newArray$(javax.swing.Action, -1, [Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JTextField').NotifyAction))))]);
};

C$.defaultActions = null;

Clazz.newMethod$(C$, '$init$', function () {
this.$action = null;
this.actionPropertyChangeListener = null;
this.horizontalAlignment = 10;
this.columns = 0;
this.columnWidth = 0;
this.command = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, null, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, text, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (columns) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, null, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (text, columns) {
C$.c$$javax_swing_text_Document$S$I.apply(this, [null, text, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document$S$I', function (doc, text, columns) {
C$.superClazz.c$$S.apply(this, ["TextFieldUI"]);
C$.$init$.apply(this);
if (columns < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["columns less than zero."]);
}this.columns = columns;
if (doc == null ) {
doc = this.createDefaultModel();
}this.setDocument$javax_swing_text_Document(doc);
if (text != null ) {
this.setText$S(text);
}}, 1);

Clazz.newMethod$(C$, 'setDocument$javax_swing_text_Document', function (doc) {
if (doc != null ) {
doc.putProperty$O$O("filterNewlines", Boolean.TRUE);
}C$.superClazz.prototype.setDocument$javax_swing_text_Document.apply(this, [doc]);
});

Clazz.newMethod$(C$, 'isValidateRoot', function () {
var parent = this.getParent();
if (Clazz.instanceOf(parent, "javax.swing.JViewport")) {
return false;
}return true;
});

Clazz.newMethod$(C$, 'getHorizontalAlignment', function () {
return this.horizontalAlignment;
});

Clazz.newMethod$(C$, 'setHorizontalAlignment$I', function (alignment) {
if (alignment == this.horizontalAlignment) return;
var oldValue = this.horizontalAlignment;
if ((alignment == 2) || (alignment == 0) || (alignment == 4) || (alignment == 10) || (alignment == 11)  ) {
this.horizontalAlignment = alignment;
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["horizontalAlignment"]);
}this.firePropertyChange$S$I$I("horizontalAlignment", oldValue, this.horizontalAlignment);
this.invalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'createDefaultModel', function () {
return (I$[2] || (I$[2]=Clazz.load('swingjs.JSToolkit'))).getPlainDocument$javax_swing_JComponent(this);
});

Clazz.newMethod$(C$, 'getColumns', function () {
return this.columns;
});

Clazz.newMethod$(C$, 'setColumns$I', function (columns) {
var oldVal = this.columns;
if (columns < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["columns less than zero."]);
}if (columns != oldVal) {
this.columns = columns;
this.invalidate();
}});

Clazz.newMethod$(C$, 'getColumnWidth', function () {
if (this.columnWidth == 0) {
var metrics = this.getFontMetrics$java_awt_Font(this.getFont());
this.columnWidth = metrics.charWidth$C('m');
}return this.columnWidth;
});

Clazz.newMethod$(C$, 'getPreferredSize', function () {
return this.getPrefSizeJTF();
});

Clazz.newMethod$(C$, 'getPrefSizeJTF', function () {
var size = this.getPrefSizeJComp();
if (this.columns != 0) {
var insets = this.getInsets();
size.width = this.columns * this.getColumnWidth() + insets.left + insets.right;
}return size;
});

Clazz.newMethod$(C$, 'setFont$java_awt_Font', function (f) {
C$.superClazz.prototype.setFont$java_awt_Font.apply(this, [f]);
this.columnWidth = 0;
});

Clazz.newMethod$(C$, 'addActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
if ((l != null ) && (this.getAction() === l ) ) {
this.setAction$javax_swing_Action(null);
} else {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
}});

Clazz.newMethod$(C$, 'getActionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ActionListener));
});

Clazz.newMethod$(C$, 'fireActionPerformed', function () {
var listeners = this.listenerList.getListenerList();
var modifiers = 0;
var currentEvent = (I$[3] || (I$[3]=Clazz.load('java.awt.EventQueue'))).getCurrentEvent();
if (Clazz.instanceOf(currentEvent, "java.awt.event.InputEvent")) {
modifiers = (currentEvent).getModifiers();
} else if (Clazz.instanceOf(currentEvent, "java.awt.event.ActionEvent")) {
modifiers = (currentEvent).getModifiers();
}var e = Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S$J$I,[this, 1001, (this.command != null ) ? this.command : this.getText(), (I$[3] || (I$[3]=Clazz.load('java.awt.EventQueue'))).getMostRecentEventTime(), modifiers]);
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ActionListener) ) {
(listeners[i + 1]).actionPerformed$java_awt_event_ActionEvent(e);
}}
});

Clazz.newMethod$(C$, 'setActionCommand$S', function (command) {
this.command = command;
});

Clazz.newMethod$(C$, 'setAction$javax_swing_Action', function (a) {
var oldValue = this.getAction();
if (this.$action == null  || !this.$action.equals$O(a) ) {
this.$action = a;
if (oldValue != null ) {
this.removeActionListener$java_awt_event_ActionListener(oldValue);
oldValue.removePropertyChangeListener$java_beans_PropertyChangeListener(this.actionPropertyChangeListener);
this.actionPropertyChangeListener = null;
}this.configurePropertiesFromAction$javax_swing_Action(this.$action);
if (this.$action != null ) {
if (!p$.isListener$Class$java_awt_event_ActionListener.apply(this, [Clazz.getClass(java.awt.event.ActionListener), this.$action])) {
this.addActionListener$java_awt_event_ActionListener(this.$action);
}this.actionPropertyChangeListener = this.createActionPropertyChangeListener$javax_swing_Action(this.$action);
this.$action.addPropertyChangeListener$java_beans_PropertyChangeListener(this.actionPropertyChangeListener);
}this.firePropertyChange$S$O$O("action", oldValue, this.$action);
}});

Clazz.newMethod$(C$, 'isListener$Class$java_awt_event_ActionListener', function (c, a) {
var isListener = false;
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === c  && listeners[i + 1] === a  ) {
isListener = true;
}}
return isListener;
});

Clazz.newMethod$(C$, 'getAction', function () {
return this.$action;
});

Clazz.newMethod$(C$, 'configurePropertiesFromAction$javax_swing_Action', function (a) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setEnabledFromAction$javax_swing_JComponent$javax_swing_Action(this, a);
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setToolTipTextFromAction$javax_swing_JComponent$javax_swing_Action(this, a);
p$.setActionCommandFromAction$javax_swing_Action.apply(this, [a]);
});

Clazz.newMethod$(C$, 'actionPropertyChanged$javax_swing_Action$S', function (action, propertyName) {
if (propertyName == "ActionCommandKey") {
p$.setActionCommandFromAction$javax_swing_Action.apply(this, [action]);
} else if (propertyName == "enabled") {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setEnabledFromAction$javax_swing_JComponent$javax_swing_Action(this, action);
} else if (propertyName == "ShortDescription") {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setToolTipTextFromAction$javax_swing_JComponent$javax_swing_Action(this, action);
}});

Clazz.newMethod$(C$, 'setActionCommandFromAction$javax_swing_Action', function (action) {
this.setActionCommand$S((action == null ) ? null : action.getValue$S("ActionCommandKey"));
});

Clazz.newMethod$(C$, 'createActionPropertyChangeListener$javax_swing_Action', function (a) {
return Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.JTextField').TextFieldActionPropertyChangeListener))).c$$javax_swing_JTextField$javax_swing_Action,[this, a]);
});

Clazz.newMethod$(C$, 'getActions', function () {
return (I$[6] || (I$[6]=Clazz.load('javax.swing.text.TextAction'))).augmentList$javax_swing_ActionA$javax_swing_ActionA(C$.superClazz.prototype.getActions.apply(this, []), C$.defaultActions);
});

Clazz.newMethod$(C$, 'postActionEvent', function () {
this.fireActionPerformed();
});

Clazz.newMethod$(C$, 'hasActionListener', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ActionListener) ) {
return true;
}}
return false;
});

Clazz.newMethod$(C$, 'paramString', function () {
var horizontalAlignmentString;
if (this.horizontalAlignment == 2) {
horizontalAlignmentString = "LEFT";
} else if (this.horizontalAlignment == 0) {
horizontalAlignmentString = "CENTER";
} else if (this.horizontalAlignment == 4) {
horizontalAlignmentString = "RIGHT";
} else if (this.horizontalAlignment == 10) {
horizontalAlignmentString = "LEADING";
} else if (this.horizontalAlignment == 11) {
horizontalAlignmentString = "TRAILING";
} else horizontalAlignmentString = "";
var commandString = (this.command != null  ? this.command : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",columns=" + this.columns + ",columnWidth=" + this.columnWidth + ",command=" + commandString + ",horizontalAlignment=" + horizontalAlignmentString ;
});
;
(function(){var C$=Clazz.newClass$(P$.JTextField, "TextFieldActionPropertyChangeListener", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.ActionPropertyChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JTextField$javax_swing_Action', function (tf, a) {
C$.superClazz.c$$TT$javax_swing_Action.apply(this, [tf, a]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPropertyChanged$javax_swing_JTextField$javax_swing_Action$java_beans_PropertyChangeEvent', function (textField, action, e) {
if ((I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).shouldReconfigure$java_beans_PropertyChangeEvent(e)) {
textField.configurePropertiesFromAction$javax_swing_Action(action);
} else {
textField.actionPropertyChanged$javax_swing_Action$S(action, e.getPropertyName());
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextField, "NotifyAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["notify-field-accept"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JTextField")) {
var field = target;
field.postActionEvent();
}});

Clazz.newMethod$(C$, 'isEnabled', function () {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JTextField")) {
return (target).hasActionListener();
}return false;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextField, "ScrollRepainter", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
this.b$['javax.swing.JTextField'].repaint();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:45
