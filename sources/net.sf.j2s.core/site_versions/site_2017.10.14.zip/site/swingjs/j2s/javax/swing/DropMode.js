(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "DropMode", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "USE_SELECTION", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "ON", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "INSERT", 2, []);
Clazz.newEnumConst$(vals, C$.c$, "INSERT_ROWS", 3, []);
Clazz.newEnumConst$(vals, C$.c$, "INSERT_COLS", 4, []);
Clazz.newEnumConst$(vals, C$.c$, "ON_OR_INSERT", 5, []);
Clazz.newEnumConst$(vals, C$.c$, "ON_OR_INSERT_ROWS", 6, []);
Clazz.newEnumConst$(vals, C$.c$, "ON_OR_INSERT_COLS", 7, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})();
//Created 2017-10-14 13:31:33
