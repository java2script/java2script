(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "JTextComponent", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.Scrollable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.KEYMAP_TABLE =  new Clazz._O();
C$.FOCUSED_COMPONENT =  new Clazz._O();
};

C$.defaultTransferHandler = null;
C$.overrideMap = null;
C$.KEYMAP_TABLE = null;
C$.FOCUSED_COMPONENT = null;

Clazz.newMethod$(C$, '$init$', function () {
this.model = null;
this.caret = null;
this.navigationFilter = null;
this.highlighter = null;
this.keymap = null;
this.caretEvent = null;
this.caretColor = null;
this.selectionColor = null;
this.selectedTextColor = null;
this.disabledTextColor = null;
this.editable = false;
this.margin = null;
this.focusAccelerator = '\0';
this.dragEnabled = false;
this.dropMode = (I$[5] || (I$[5]=Clazz.load('javax.swing.DropMode'))).USE_SELECTION;
this.dropLocation = null;
this.composedTextAttribute = null;
this.composedTextContent = null;
this.composedTextStart = null;
this.composedTextEnd = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$S.apply(this, ["ComponentUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (uid) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.enableEvents$J(2056);
this.caretEvent = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').MutableCaretEvent))).c$$javax_swing_text_JTextComponent,[this]);
this.addMouseListener$java_awt_event_MouseListener(this.caretEvent);
this.addFocusListener$java_awt_event_FocusListener(this.caretEvent);
this.setEditable$Z(true);
this.setDragEnabled$Z(false);
this.setLayout$java_awt_LayoutManager(null);
this.uiClassID = uid;
this.updateUI();
this.setOpaque$Z(true);
}, 1);

Clazz.newMethod$(C$, 'updateUI', function () {
C$.superClazz.prototype.updateUI.apply(this, []);
this.invalidate();
});

Clazz.newMethod$(C$, 'addCaretListener$javax_swing_event_CaretListener', function (listener) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.CaretListener), listener);
});

Clazz.newMethod$(C$, 'removeCaretListener$javax_swing_event_CaretListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.CaretListener), listener);
});

Clazz.newMethod$(C$, 'getCaretListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.CaretListener));
});

Clazz.newMethod$(C$, 'fireCaretUpdate$javax_swing_event_CaretEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.CaretListener) ) {
(listeners[i + 1]).caretUpdate$javax_swing_event_CaretEvent(e);
}}
});

Clazz.newMethod$(C$, 'setDocument$javax_swing_text_Document', function (doc) {
var old = this.model;
try {
this.model = doc;
this.firePropertyChange$S$O$O("document", old, doc);
} finally {
}
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'getDocument', function () {
return this.model;
});

Clazz.newMethod$(C$, 'setComponentOrientation$java_awt_ComponentOrientation', function (o) {
C$.superClazz.prototype.setComponentOrientation$java_awt_ComponentOrientation.apply(this, [o]);
});

Clazz.newMethod$(C$, 'getActions', function () {
if (this.getUI() == null ) return null;
return (this.getUI()).getEditorKit$javax_swing_text_JTextComponent(this).getActions();
});

Clazz.newMethod$(C$, 'setMargin$java_awt_Insets', function (m) {
var old = this.margin;
this.margin = m;
this.firePropertyChange$S$O$O("margin", old, m);
this.invalidate();
});

Clazz.newMethod$(C$, 'getMargin', function () {
return this.margin;
});

Clazz.newMethod$(C$, 'setNavigationFilter$javax_swing_text_NavigationFilter', function (filter) {
this.navigationFilter = filter;
});

Clazz.newMethod$(C$, 'getNavigationFilter', function () {
return this.navigationFilter;
});

Clazz.newMethod$(C$, 'getCaret', function () {
return this.caret;
});

Clazz.newMethod$(C$, 'setCaret$javax_swing_text_Caret', function (c) {
if (this.caret != null ) {
this.caret.removeChangeListener$javax_swing_event_ChangeListener(this.caretEvent);
this.caret.deinstall$javax_swing_text_JTextComponent(this);
}var old = this.caret;
this.caret = c;
if (this.caret != null ) {
this.caret.install$javax_swing_text_JTextComponent(this);
this.caret.addChangeListener$javax_swing_event_ChangeListener(this.caretEvent);
}this.firePropertyChange$S$O$O("caret", old, this.caret);
});

Clazz.newMethod$(C$, 'getHighlighter', function () {
return this.highlighter;
});

Clazz.newMethod$(C$, 'setHighlighter$javax_swing_text_Highlighter', function (h) {
if (this.highlighter != null ) {
this.highlighter.deinstall$javax_swing_text_JTextComponent(this);
}var old = this.highlighter;
this.highlighter = h;
if (this.highlighter != null ) {
this.highlighter.install$javax_swing_text_JTextComponent(this);
}this.firePropertyChange$S$O$O("highlighter", old, h);
});

Clazz.newMethod$(C$, 'setKeymap$javax_swing_text_Keymap', function (map) {
var old = this.keymap;
this.keymap = map;
this.firePropertyChange$S$O$O("keymap", old, this.keymap);
this.updateInputMap$javax_swing_text_Keymap$javax_swing_text_Keymap(old, map);
});

Clazz.newMethod$(C$, 'setDragEnabled$Z', function (b) {
this.dragEnabled = b;
});

Clazz.newMethod$(C$, 'getDragEnabled', function () {
return this.dragEnabled;
});

Clazz.newMethod$(C$, 'setDropMode$javax_swing_DropMode', function (dropMode) {
if (dropMode != null ) {
switch (dropMode) {
case javax.swing.DropMode.USE_SELECTION:
case javax.swing.DropMode.INSERT:
this.dropMode = dropMode;
return;
}
}throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[dropMode + ": Unsupported drop mode for text"]);
});

Clazz.newMethod$(C$, 'getDropMode', function () {
return this.dropMode;
});

Clazz.newMethod$(C$, 'dropLocationForPoint$java_awt_Point', function (p) {
var bias =  Clazz.newArray$(javax.swing.text.Position.Bias, [1]);
var index = (this.getUI()).viewToModel$javax_swing_text_JTextComponent$java_awt_Point$javax_swing_text_Position_BiasA(this, p, bias);
if (bias[0] == null ) {
bias[0] = (I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
}return Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').DropLocation))).c$$java_awt_Point$I$javax_swing_text_Position_Bias,[p, index, bias[0]]);
});

Clazz.newMethod$(C$, 'setDropLocation$javax_swing_text_JTextComponent_DropLocation$O$Z', function (location, state, forDrop) {
var retVal = null;
var textLocation = location;
if (this.dropMode === (I$[5] || (I$[5]=Clazz.load('javax.swing.DropMode'))).USE_SELECTION ) {
if (textLocation == null ) {
if (state != null ) {
var vals = state;
if (!forDrop) {
if (Clazz.instanceOf(this.caret, "javax.swing.text.DefaultCaret")) {
(this.caret).setDot$I$javax_swing_text_Position_Bias((vals[0]).intValue(), vals[3]);
(this.caret).moveDot$I$javax_swing_text_Position_Bias((vals[1]).intValue(), vals[4]);
} else {
this.caret.setDot$I((vals[0]).intValue());
this.caret.moveDot$I((vals[1]).intValue());
}}this.caret.setVisible$Z((vals[2]).booleanValue());
}} else {
if (this.dropLocation == null ) {
var visible;
if (Clazz.instanceOf(this.caret, "javax.swing.text.DefaultCaret")) {
var dc = this.caret;
visible = dc.isActive();
retVal =  Clazz.newArray$(java.lang.Object, -1, [Integer.$valueOf(dc.getMark()), Integer.$valueOf(dc.getDot()), (I$[9] || (I$[9]=Clazz.load('Boolean'))).$valueOf(visible), dc.getMarkBias(), dc.getDotBias()]);
} else {
visible = this.caret.isVisible();
retVal =  Clazz.newArray$(java.lang.Object, -1, [Integer.$valueOf(this.caret.getMark()), Integer.$valueOf(this.caret.getDot()), (I$[9] || (I$[9]=Clazz.load('Boolean'))).$valueOf(visible)]);
}this.caret.setVisible$Z(true);
} else {
retVal = state;
}if (Clazz.instanceOf(this.caret, "javax.swing.text.DefaultCaret")) {
(this.caret).setDot$I$javax_swing_text_Position_Bias(textLocation.getIndex(), textLocation.getBias());
} else {
this.caret.setDot$I(textLocation.getIndex());
}}} else {
if (textLocation == null ) {
if (state != null ) {
this.caret.setVisible$Z((state).booleanValue());
}} else {
if (this.dropLocation == null ) {
var visible = Clazz.instanceOf(this.caret, "javax.swing.text.DefaultCaret") ? (this.caret).isActive() : this.caret.isVisible();
retVal = (I$[9] || (I$[9]=Clazz.load('Boolean'))).$valueOf(visible);
this.caret.setVisible$Z(false);
} else {
retVal = state;
}}}var old = this.dropLocation;
this.dropLocation = textLocation;
this.firePropertyChange$S$O$O("dropLocation", old, this.dropLocation);
return retVal;
});

Clazz.newMethod$(C$, 'getDropLocation', function () {
return this.dropLocation;
});

Clazz.newMethod$(C$, 'updateInputMap$javax_swing_text_Keymap$javax_swing_text_Keymap', function (oldKm, newKm) {
var km = this.getInputMap$I(0);
var last = km;
while (km != null  && !(Clazz.instanceOf(km, "javax.swing.text.JTextComponent.KeymapWrapper")) ){
last = km;
km = km.getParent();
}
if (km != null ) {
if (newKm == null ) {
if (last !== km ) {
last.setParent$javax_swing_InputMap(km.getParent());
} else {
last.setParent$javax_swing_InputMap(null);
}} else {
var newKM = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapWrapper))).c$$javax_swing_text_Keymap,[newKm]);
last.setParent$javax_swing_InputMap(newKM);
if (last !== km ) {
newKM.setParent$javax_swing_InputMap(km.getParent());
}}} else if (newKm != null ) {
km = this.getInputMap$I(0);
if (km != null ) {
var newKM = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapWrapper))).c$$javax_swing_text_Keymap,[newKm]);
newKM.setParent$javax_swing_InputMap(km.getParent());
km.setParent$javax_swing_InputMap(newKM);
}}var am = this.getActionMap();
var lastAM = am;
while (am != null  && !(Clazz.instanceOf(am, "javax.swing.text.JTextComponent.KeymapActionMap")) ){
lastAM = am;
am = am.getParent();
}
if (am != null ) {
if (newKm == null ) {
if (lastAM !== am ) {
lastAM.setParent$javax_swing_ActionMap(am.getParent());
} else {
lastAM.setParent$javax_swing_ActionMap(null);
}} else {
var newAM = Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapActionMap))).c$$javax_swing_text_Keymap,[newKm]);
lastAM.setParent$javax_swing_ActionMap(newAM);
if (lastAM !== am ) {
newAM.setParent$javax_swing_ActionMap(am.getParent());
}}} else if (newKm != null ) {
am = this.getActionMap();
if (am != null ) {
var newAM = Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapActionMap))).c$$javax_swing_text_Keymap,[newKm]);
newAM.setParent$javax_swing_ActionMap(am.getParent());
am.setParent$javax_swing_ActionMap(newAM);
}}});

Clazz.newMethod$(C$, 'getKeymap', function () {
return this.keymap;
});

Clazz.newMethod$(C$, 'addKeymap$S$javax_swing_text_Keymap', function (nm, parent) {
var map = Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').DefaultKeymap))).c$$S$javax_swing_text_Keymap,[nm, parent]);
if (nm != null ) {
C$.getKeymapTable().put$TK$TV(nm, map);
}return map;
}, 1);

Clazz.newMethod$(C$, 'removeKeymap$S', function (nm) {
return C$.getKeymapTable().remove$O(nm);
}, 1);

Clazz.newMethod$(C$, 'getKeymap$S', function (nm) {
return C$.getKeymapTable().get$O(nm);
}, 1);

Clazz.newMethod$(C$, 'getKeymapTable', function () {
{
var appContext = (I$[4] || (I$[4]=Clazz.load('sun.awt.AppContext'))).getAppContext();
var keymapTable = appContext.get$O(C$.KEYMAP_TABLE);
if (keymapTable == null ) {
keymapTable = Clazz.new((I$[12] || (I$[12]=Clazz.load('java.util.HashMap'))).c$$I,[17]);
appContext.put$O$O(C$.KEYMAP_TABLE, keymapTable);
var binding = C$.addKeymap$S$javax_swing_text_Keymap("default", null);
binding.setDefaultAction$javax_swing_Action(Clazz.new((I$[13] || (I$[13]=Clazz.load(Clazz.load('javax.swing.text.DefaultEditorKit').DefaultKeyTypedAction)))));
}return keymapTable;
}}, 1);

Clazz.newMethod$(C$, 'loadKeymap$javax_swing_text_Keymap$javax_swing_text_JTextComponent_KeyBindingA$javax_swing_ActionA', function (map, bindings, actions) {
var h = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Hashtable'))));
for (var i = 0; i < actions.length; i++) {
var a = actions[i];
var value = a.getValue$S("Name");
h.put$TK$TV((value != null  ? value : ""), a);
}
for (var i = 0; i < bindings.length; i++) {
var a = h.get$O(bindings[i].actionName);
if (a != null ) {
map.addActionForKeyStroke$javax_swing_KeyStroke$javax_swing_Action(bindings[i].key, a);
}}
}, 1);

Clazz.newMethod$(C$, 'getCaretColor', function () {
return this.caretColor;
});

Clazz.newMethod$(C$, 'setCaretColor$java_awt_Color', function (c) {
var old = this.caretColor;
this.caretColor = c;
this.firePropertyChange$S$O$O("caretColor", old, this.caretColor);
});

Clazz.newMethod$(C$, 'getSelectionColor', function () {
return this.selectionColor;
});

Clazz.newMethod$(C$, 'setSelectionColor$java_awt_Color', function (c) {
var old = this.selectionColor;
this.selectionColor = c;
this.firePropertyChange$S$O$O("selectionColor", old, this.selectionColor);
});

Clazz.newMethod$(C$, 'getSelectedTextColor', function () {
return this.selectedTextColor;
});

Clazz.newMethod$(C$, 'setSelectedTextColor$java_awt_Color', function (c) {
var old = this.selectedTextColor;
this.selectedTextColor = c;
this.firePropertyChange$S$O$O("selectedTextColor", old, this.selectedTextColor);
});

Clazz.newMethod$(C$, 'getDisabledTextColor', function () {
return this.disabledTextColor;
});

Clazz.newMethod$(C$, 'setDisabledTextColor$java_awt_Color', function (c) {
var old = this.disabledTextColor;
this.disabledTextColor = c;
this.firePropertyChange$S$O$O("disabledTextColor", old, this.disabledTextColor);
});

Clazz.newMethod$(C$, 'replaceSelection$S', function (content) {
var doc = this.getDocument();
if (doc != null ) {
try {
var composedTextSaved = p$.saveComposedText$I.apply(this, [this.caret.getDot()]);
var p0 = Math.min(this.caret.getDot(), this.caret.getMark());
var p1 = Math.max(this.caret.getDot(), this.caret.getMark());
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).replace$I$I$S$javax_swing_text_AttributeSet(p0, p1 - p0, content, null);
} else {
if (p0 != p1) {
doc.remove$I$I(p0, p1 - p0);
}if (content != null  && content.length$() > 0 ) {
doc.insertString$I$S$javax_swing_text_AttributeSet(p0, content, null);
}}if (composedTextSaved) {
p$.restoreComposedText.apply(this, []);
}} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
(I$[14] || (I$[14]=Clazz.load('swingjs.JSUtil'))).alert$O("SWINGJS BAD LOCATION EXCEPTION (replace):" + e.getMessage() + (I$[14] || (I$[14]=Clazz.load('swingjs.JSUtil'))).getStackTrace$I(-10) );
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'getText$I$I', function (offs, len) {
return this.getDocument().getText$I$I(offs, len);
});

Clazz.newMethod$(C$, 'modelToView$I', function (pos) {
return (this.getUI()).modelToView$javax_swing_text_JTextComponent$I(this, pos);
});

Clazz.newMethod$(C$, 'viewToModel$java_awt_Point', function (pt) {
return (this.getUI()).viewToModel$javax_swing_text_JTextComponent$java_awt_Point(this, pt);
});

Clazz.newMethod$(C$, 'cut', function () {
});

Clazz.newMethod$(C$, 'copy', function () {
});

Clazz.newMethod$(C$, 'paste', function () {
});

Clazz.newMethod$(C$, 'moveCaretPosition$I', function (pos) {
var doc = this.getDocument();
if (doc != null ) {
if (pos > doc.getLength() || pos < 0 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["bad position: " + pos]);
}this.caret.moveDot$I(pos);
}});

Clazz.newMethod$(C$, 'setFocusAccelerator$C', function (aKey) {
aKey = Character.toUpperCase(aKey);
var old = this.focusAccelerator;
this.focusAccelerator = aKey;
this.firePropertyChange$S$C$C("focusAcceleratorKey", old, this.focusAccelerator);
this.firePropertyChange$S$C$C("focusAccelerator", old, this.focusAccelerator);
});

Clazz.newMethod$(C$, 'getFocusAccelerator', function () {
return this.focusAccelerator;
});

Clazz.newMethod$(C$, 'read$java_io_Reader$O', function ($in, desc) {
var kit = (this.getUI()).getEditorKit$javax_swing_text_JTextComponent(this);
var doc = kit.createDefaultDocument();
if (desc != null ) {
doc.putProperty$O$O("stream", desc);
}try {
kit.read$java_io_Reader$javax_swing_text_Document$I($in, doc, 0);
this.setDocument$javax_swing_text_Document(doc);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'write$java_io_Writer', function (out) {
var doc = this.getDocument();
try {
(this.getUI()).getEditorKit$javax_swing_text_JTextComponent(this).write$java_io_Writer$javax_swing_text_Document$I$I(out, doc, 0, doc.getLength());
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'removeNotify', function () {
C$.superClazz.prototype.removeNotify.apply(this, []);
if (C$.getFocusedComponent() === this ) {
(I$[4] || (I$[4]=Clazz.load('sun.awt.AppContext'))).getAppContext().remove$O(C$.FOCUSED_COMPONENT);
}});

Clazz.newMethod$(C$, 'setCaretPosition$I', function (position) {
var doc = this.getDocument();
if (doc != null ) {
if (position > doc.getLength() || position < 0 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["bad position: " + position]);
}this.caret.setDot$I(position);
}});

Clazz.newMethod$(C$, 'getCaretPosition', function () {
return this.caret.getDot();
});

Clazz.newMethod$(C$, 'setText$S', function (t) {
try {
var doc = this.getDocument();
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).replace$I$I$S$javax_swing_text_AttributeSet(0, doc.getLength(), t, null);
} else {
doc.remove$I$I(0, doc.getLength());
doc.insertString$I$S$javax_swing_text_AttributeSet(0, t, null);
}} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
(I$[14] || (I$[14]=Clazz.load('swingjs.JSUtil'))).alert$O("SWINGJS BAD LOCATION EXCEPTION (setText):" + e.getMessage() + (I$[14] || (I$[14]=Clazz.load('swingjs.JSUtil'))).getStackTrace$I(-10) );
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'getText', function () {
var doc = this.getDocument();
var txt;
try {
txt = doc.getText$I$I(0, doc.getLength());
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
txt = null;
} else {
throw e;
}
}
return txt;
});

Clazz.newMethod$(C$, 'getSelectedText', function () {
var txt = null;
var p0 = Math.min(this.caret.getDot(), this.caret.getMark());
var p1 = Math.max(this.caret.getDot(), this.caret.getMark());
if (p0 != p1) {
try {
var doc = this.getDocument();
txt = doc.getText$I$I(p0, p1 - p0);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
}return txt;
});

Clazz.newMethod$(C$, 'isEditable', function () {
return this.editable;
});

Clazz.newMethod$(C$, 'setEditable$Z', function (b) {
if (b != this.editable ) {
var oldVal = this.editable;
this.editable = b;
this.firePropertyChange$S$O$O("editable", (I$[9] || (I$[9]=Clazz.load('Boolean'))).$valueOf(oldVal), (I$[9] || (I$[9]=Clazz.load('Boolean'))).$valueOf(this.editable));
this.repaint();
}});

Clazz.newMethod$(C$, 'getSelectionStart', function () {
var start = Math.min(this.caret.getDot(), this.caret.getMark());
return start;
});

Clazz.newMethod$(C$, 'setSelectionStart$I', function (selectionStart) {
this.select$I$I(selectionStart, this.getSelectionEnd());
});

Clazz.newMethod$(C$, 'getSelectionEnd', function () {
var end = Math.max(this.caret.getDot(), this.caret.getMark());
return end;
});

Clazz.newMethod$(C$, 'setSelectionEnd$I', function (selectionEnd) {
this.select$I$I(this.getSelectionStart(), selectionEnd);
});

Clazz.newMethod$(C$, 'select$I$I', function (selectionStart, selectionEnd) {
var docLength = this.getDocument().getLength();
if (selectionStart < 0) {
selectionStart = 0;
}if (selectionStart > docLength) {
selectionStart = docLength;
}if (selectionEnd > docLength) {
selectionEnd = docLength;
}if (selectionEnd < selectionStart) {
selectionEnd = selectionStart;
}this.setCaretPosition$I(selectionStart);
this.moveCaretPosition$I(selectionEnd);
});

Clazz.newMethod$(C$, 'selectAll', function () {
var doc = this.getDocument();
if (doc != null ) {
this.setCaretPosition$I(0);
this.moveCaretPosition$I(doc.getLength());
}});

Clazz.newMethod$(C$, 'getToolTipText$java_awt_event_MouseEvent', function (event) {
var retValue = C$.superClazz.prototype.getToolTipText$java_awt_event_MouseEvent.apply(this, [event]);
if (retValue == null ) {
var ui = (this.getUI());
if (ui != null ) {
retValue = ui.getToolTipText$javax_swing_text_JTextComponent$java_awt_Point(this, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$I$I,[event.getX(), event.getY()]));
}}return retValue;
});

Clazz.newMethod$(C$, 'getPreferredScrollableViewportSize', function () {
return this.getPreferredSize();
});

Clazz.newMethod$(C$, 'getScrollableUnitIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
switch (orientation) {
case 1:
return ($i$[0] = visibleRect.height/10, $i$[0]);
case 0:
return ($i$[0] = visibleRect.width/10, $i$[0]);
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid orientation: " + orientation]);
}
});

Clazz.newMethod$(C$, 'getScrollableBlockIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
switch (orientation) {
case 1:
return visibleRect.height;
case 0:
return visibleRect.width;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid orientation: " + orientation]);
}
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportWidth', function () {
if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
return ((this.getParent()).getWidth() > this.getPreferredSize().width);
}return false;
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportHeight', function () {
if (Clazz.instanceOf(this.getParent(), "javax.swing.JViewport")) {
return ((this.getParent()).getHeight() > this.getPreferredSize().height);
}return false;
});

Clazz.newMethod$(C$, 'paramString', function () {
var editableString = (this.editable ? "true" : "false");
var caretColorString = (this.caretColor != null  ? this.caretColor.toString() : "");
var selectionColorString = (this.selectionColor != null  ? this.selectionColor.toString() : "");
var selectedTextColorString = (this.selectedTextColor != null  ? this.selectedTextColor.toString() : "");
var disabledTextColorString = (this.disabledTextColor != null  ? this.disabledTextColor.toString() : "");
var marginString = (this.margin != null  ? this.margin.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",caretColor=" + caretColorString + ",disabledTextColor=" + disabledTextColorString + ",editable=" + editableString + ",margin=" + marginString + ",selectedTextColor=" + selectedTextColorString + ",selectionColor=" + selectionColorString ;
});

Clazz.newMethod$(C$, 'getFocusedComponent', function () {
return (I$[4] || (I$[4]=Clazz.load('sun.awt.AppContext'))).getAppContext().get$O(C$.FOCUSED_COMPONENT);
}, 1);

Clazz.newMethod$(C$, 'addInputMethodListener$java_awt_event_InputMethodListener', function (l) {
C$.superClazz.prototype.addInputMethodListener$java_awt_event_InputMethodListener.apply(this, [l]);
if (l != null ) {
}});

Clazz.newMethod$(C$, 'saveComposedText$I', function (pos) {
if (this.composedTextExists()) {
var start = this.composedTextStart.getOffset();
var len = this.composedTextEnd.getOffset() - this.composedTextStart.getOffset();
if (pos >= start && pos <= start + len ) {
try {
this.getDocument().remove$I$I(start, len);
return true;
} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
}}return false;
});

Clazz.newMethod$(C$, 'restoreComposedText', function () {
var doc = this.getDocument();
try {
doc.insertString$I$S$javax_swing_text_AttributeSet(this.caret.getDot(), this.composedTextContent, this.composedTextAttribute);
this.composedTextStart = doc.createPosition$I(this.caret.getDot() - this.composedTextContent.length$());
this.composedTextEnd = doc.createPosition$I(this.caret.getDot());
} catch (ble) {
if (Clazz.exceptionOf(ble, P$.BadLocationException)){
} else {
throw ble;
}
}
});

Clazz.newMethod$(C$, 'composedTextExists', function () {
return (this.composedTextStart != null );
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "KeyBinding", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.key = null;
this.actionName = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_KeyStroke$S', function (key, actionName) {
C$.$init$.apply(this);
this.key = key;
this.actionName = actionName;
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "DropLocation", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.index = 0;
this.bias = null;
this.dropPoint = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Point$I$javax_swing_text_Position_Bias', function (p, index, bias) {
C$.$init$.apply(this);
this.dropPoint = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))).c$$java_awt_Point,[p]);
this.index = index;
this.bias = bias;
}, 1);

Clazz.newMethod$(C$, 'getIndex', function () {
return this.index;
});

Clazz.newMethod$(C$, 'getBias', function () {
return this.bias;
});

Clazz.newMethod$(C$, 'toString', function () {
return this.getClass().getName() + "[dropPoint=" + this.getDropPoint() + "," + "index=" + this.index + "," + "bias=" + this.bias + "]" ;
});

Clazz.newMethod$(C$, 'getDropPoint', function () {
return this.dropPoint;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "DefaultTransferHandler", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "DefaultKeymap", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'javax.swing.text.Keymap');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.nm = null;
this.parent = null;
this.bindings = null;
this.defaultAction = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S$javax_swing_text_Keymap', function (nm, parent) {
C$.$init$.apply(this);
this.nm = nm;
this.parent = parent;
this.bindings = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Hashtable'))));
}, 1);

Clazz.newMethod$(C$, 'getDefaultAction', function () {
if (this.defaultAction != null ) {
return this.defaultAction;
}return (this.parent != null ) ? this.parent.getDefaultAction() : null;
});

Clazz.newMethod$(C$, 'setDefaultAction$javax_swing_Action', function (a) {
this.defaultAction = a;
});

Clazz.newMethod$(C$, 'getName', function () {
return this.nm;
});

Clazz.newMethod$(C$, 'getAction$javax_swing_KeyStroke', function (key) {
var a = this.bindings.get$O(key);
if ((a == null ) && (this.parent != null ) ) {
a = this.parent.getAction$javax_swing_KeyStroke(key);
}return a;
});

Clazz.newMethod$(C$, 'getBoundKeyStrokes', function () {
var keys =  Clazz.newArray$(javax.swing.KeyStroke, [this.bindings.size()]);
var i = 0;
for (var e = this.bindings.keys(); e.hasMoreElements(); ) {
keys[i++] = e.nextElement();
}
return keys;
});

Clazz.newMethod$(C$, 'getBoundActions', function () {
var actions =  Clazz.newArray$(javax.swing.Action, [this.bindings.size()]);
var i = 0;
for (var e = this.bindings.elements(); e.hasMoreElements(); ) {
actions[i++] = e.nextElement();
}
return actions;
});

Clazz.newMethod$(C$, 'getKeyStrokesForAction$javax_swing_Action', function (a) {
if (a == null ) {
return null;
}var retValue = null;
var keyStrokes = null;
for (var enum_ = this.bindings.keys(); enum_.hasMoreElements(); ) {
var key = enum_.nextElement();
if (this.bindings.get$O(key) === a ) {
if (keyStrokes == null ) {
keyStrokes = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.util.Vector'))));
}keyStrokes.addElement$TE(key);
}}
if (this.parent != null ) {
var pStrokes = this.parent.getKeyStrokesForAction$javax_swing_Action(a);
if (pStrokes != null ) {
var rCount = 0;
for (var counter = pStrokes.length - 1; counter >= 0; counter--) {
if (this.isLocallyDefined$javax_swing_KeyStroke(pStrokes[counter])) {
pStrokes[counter] = null;
rCount++;
}}
if (rCount > 0 && rCount < pStrokes.length ) {
if (keyStrokes == null ) {
keyStrokes = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.util.Vector'))));
}for (var counter = pStrokes.length - 1; counter >= 0; counter--) {
if (pStrokes[counter] != null ) {
keyStrokes.addElement$TE(pStrokes[counter]);
}}
} else if (rCount == 0) {
if (keyStrokes == null ) {
retValue = pStrokes;
} else {
retValue =  Clazz.newArray$(javax.swing.KeyStroke, [keyStrokes.size() + pStrokes.length]);
keyStrokes.copyInto$OA(retValue);
System.arraycopy(pStrokes, 0, retValue, keyStrokes.size(), pStrokes.length);
keyStrokes = null;
}}}}if (keyStrokes != null ) {
retValue =  Clazz.newArray$(javax.swing.KeyStroke, [keyStrokes.size()]);
keyStrokes.copyInto$OA(retValue);
}return retValue;
});

Clazz.newMethod$(C$, 'isLocallyDefined$javax_swing_KeyStroke', function (key) {
return this.bindings.containsKey$O(key);
});

Clazz.newMethod$(C$, 'addActionForKeyStroke$javax_swing_KeyStroke$javax_swing_Action', function (key, a) {
this.bindings.put$TK$TV(key, a);
});

Clazz.newMethod$(C$, 'removeKeyStrokeBinding$javax_swing_KeyStroke', function (key) {
this.bindings.remove$O(key);
});

Clazz.newMethod$(C$, 'removeBindings', function () {
this.bindings.clear();
});

Clazz.newMethod$(C$, 'getResolveParent', function () {
return this.parent;
});

Clazz.newMethod$(C$, 'setResolveParent$javax_swing_text_Keymap', function (parent) {
this.parent = parent;
});

Clazz.newMethod$(C$, 'toString', function () {
return "Keymap[" + this.nm + "]" + this.bindings ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "KeymapWrapper", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.InputMap');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.DefaultActionKey =  new Clazz._O();
};

C$.DefaultActionKey = null;

Clazz.newMethod$(C$, '$init$', function () {
this.keymap = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Keymap', function (keymap) {
Clazz.super(C$, this,1);
this.keymap = keymap;
}, 1);

Clazz.newMethod$(C$, 'keys', function () {
var sKeys = C$.superClazz.prototype.keys.apply(this, []);
var keymapKeys = this.keymap.getBoundKeyStrokes();
var sCount = (sKeys == null ) ? 0 : sKeys.length;
var keymapCount = (keymapKeys == null ) ? 0 : keymapKeys.length;
if (sCount == 0) {
return keymapKeys;
}if (keymapCount == 0) {
return sKeys;
}var retValue =  Clazz.newArray$(javax.swing.KeyStroke, [sCount + keymapCount]);
System.arraycopy(sKeys, 0, retValue, 0, sCount);
System.arraycopy(keymapKeys, 0, retValue, sCount, keymapCount);
return retValue;
});

Clazz.newMethod$(C$, 'size', function () {
var keymapStrokes = this.keymap.getBoundKeyStrokes();
var keymapCount = (keymapStrokes == null ) ? 0 : keymapStrokes.length;
return C$.superClazz.prototype.size.apply(this, []) + keymapCount;
});

Clazz.newMethod$(C$, 'get$javax_swing_KeyStroke', function (keyStroke) {
var retValue = this.keymap.getAction$javax_swing_KeyStroke(keyStroke);
if (retValue == null ) {
retValue = C$.superClazz.prototype.get$javax_swing_KeyStroke.apply(this, [keyStroke]);
if (retValue == null  && keyStroke.getKeyChar() != '\uffff'  && this.keymap.getDefaultAction() != null  ) {
retValue = C$.DefaultActionKey;
}}return retValue;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "KeymapActionMap", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.ActionMap');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.keymap = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Keymap', function (keymap) {
Clazz.super(C$, this,1);
this.keymap = keymap;
}, 1);

Clazz.newMethod$(C$, 'keys', function () {
var sKeys = C$.superClazz.prototype.keys.apply(this, []);
var keymapKeys = this.keymap.getBoundActions();
var sCount = (sKeys == null ) ? 0 : sKeys.length;
var keymapCount = (keymapKeys == null ) ? 0 : keymapKeys.length;
var hasDefault = (this.keymap.getDefaultAction() != null );
if (hasDefault) {
keymapCount++;
}if (sCount == 0) {
if (hasDefault) {
var retValue =  Clazz.newArray$(java.lang.Object, [keymapCount]);
if (keymapCount > 1) {
System.arraycopy(keymapKeys, 0, retValue, 0, keymapCount - 1);
}retValue[keymapCount - 1] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapWrapper))).DefaultActionKey;
return retValue;
}return keymapKeys;
}if (keymapCount == 0) {
return sKeys;
}var retValue =  Clazz.newArray$(java.lang.Object, [sCount + keymapCount]);
System.arraycopy(sKeys, 0, retValue, 0, sCount);
if (hasDefault) {
if (keymapCount > 1) {
System.arraycopy(keymapKeys, 0, retValue, sCount, keymapCount - 1);
}retValue[sCount + keymapCount - 1] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapWrapper))).DefaultActionKey;
} else {
System.arraycopy(keymapKeys, 0, retValue, sCount, keymapCount);
}return retValue;
});

Clazz.newMethod$(C$, 'size', function () {
var actions = this.keymap.getBoundActions();
var keymapCount = (actions == null ) ? 0 : actions.length;
if (this.keymap.getDefaultAction() != null ) {
keymapCount++;
}return C$.superClazz.prototype.size.apply(this, []) + keymapCount;
});

Clazz.newMethod$(C$, 'get$O', function (key) {
var retValue = C$.superClazz.prototype.get$O.apply(this, [key]);
if (retValue == null ) {
if (key === (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.JTextComponent').KeymapWrapper))).DefaultActionKey ) {
retValue = this.keymap.getDefaultAction();
} else if (Clazz.instanceOf(key, "javax.swing.Action")) {
retValue = key;
}}return retValue;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTextComponent, "MutableCaretEvent", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.event.CaretEvent', ['javax.swing.event.ChangeListener', 'java.awt.event.FocusListener', 'java.awt.event.MouseListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.dragActive = false;
this.dot = 0;
this.mark = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_JTextComponent', function (c) {
C$.superClazz.c$$O.apply(this, [c]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'fire', function () {
var c = this.getSource();
if (c != null ) {
var caret = c.getCaret();
if (caret != null ) {
this.dot = caret.getDot();
this.mark = caret.getMark();
c.fireCaretUpdate$javax_swing_event_CaretEvent(this);
}}});

Clazz.newMethod$(C$, 'toString', function () {
return "dot=" + this.dot + "," + "mark=" + this.mark ;
});

Clazz.newMethod$(C$, 'getDot', function () {
return this.dot;
});

Clazz.newMethod$(C$, 'getMark', function () {
return this.mark;
});

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
if (!this.dragActive) {
this.fire();
}});

Clazz.newMethod$(C$, 'focusGained$java_awt_event_FocusEvent', function (fe) {
(I$[4] || (I$[4]=Clazz.load('sun.awt.AppContext'))).getAppContext().put$O$O(P$.JTextComponent.FOCUSED_COMPONENT, fe.getSource());
});

Clazz.newMethod$(C$, 'focusLost$java_awt_event_FocusEvent', function (fe) {
});

Clazz.newMethod$(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.dragActive = true;
});

Clazz.newMethod$(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.dragActive = false;
this.fire();
});

Clazz.newMethod$(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:03
