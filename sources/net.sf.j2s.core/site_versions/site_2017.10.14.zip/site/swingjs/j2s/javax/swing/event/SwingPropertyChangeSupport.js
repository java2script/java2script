(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "SwingPropertyChangeSupport", null, 'java.beans.PropertyChangeSupport');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.notifyOnEDT = false;
}, 1);

Clazz.newMethod$(C$, 'c$$O', function (sourceBean) {
C$.c$$O$Z.apply(this, [sourceBean, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$O$Z', function (sourceBean, notifyOnEDT) {
C$.superClazz.c$$O.apply(this, [sourceBean]);
C$.$init$.apply(this);
this.notifyOnEDT = notifyOnEDT;
}, 1);

Clazz.newMethod$(C$, 'firePropertyChange$java_beans_PropertyChangeEvent', function (evt) {
if (evt == null ) {
throw Clazz.new(Clazz.load('java.lang.NullPointerException'));
}if (!this.isNotifyOnEDT() || (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).isEventDispatchThread() ) {
C$.superClazz.prototype.firePropertyChange$java_beans_PropertyChangeEvent.apply(this, [evt]);
} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(((
(function(){var C$=Clazz.newClass$(P$, "SwingPropertyChangeSupport$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
this.b$['javax.swing.event.SwingPropertyChangeSupport'].firePropertyChange$java_beans_PropertyChangeEvent(this.$finals.evt);
});
})()
), Clazz.new((I$[1] || (I$[1]=Clazz.load(P$.SwingPropertyChangeSupport$1))).$init$, [this, {evt: evt}])));
}});

Clazz.newMethod$(C$, 'isNotifyOnEDT', function () {
return this.notifyOnEDT;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
