(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newInterface$(P$, "Keymap");

})();
//Created 2017-10-14 13:32:03
