(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JComboBox", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', ['java.awt.ItemSelectable', 'javax.swing.event.ListDataListener', 'java.awt.event.ActionListener']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.dataModel = null;
this.renderer = null;
this.editor = null;
this.maximumRowCount = 8;
this.$isEditable = false;
this.keySelectionManager = null;
this.actionCommand = "comboBoxChanged";
this.lightWeightPopupEnabled = (I$[1] || (I$[1]=Clazz.load('javax.swing.JPopupMenu'))).getDefaultLightWeightPopupEnabled();
this.selectedItemReminder = null;
this.prototypeDisplayValue = null;
this.firingActionEvent = false;
this.selectingItem = false;
this.$action = null;
this.actionPropertyChangeListener = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_ComboBoxModel', function (aModel) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setModel$javax_swing_ComboBoxModel(aModel);
p$.initComboBox.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$OA', function (items) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setModel$javax_swing_ComboBoxModel(Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.DefaultComboBoxModel'))).c$$OA,[items]));
p$.initComboBox.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Vector', function (items) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setModel$javax_swing_ComboBoxModel(Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.DefaultComboBoxModel'))).c$$java_util_Vector,[items]));
p$.initComboBox.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setModel$javax_swing_ComboBoxModel(Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.DefaultComboBoxModel')))));
p$.initComboBox.apply(this, []);
}, 1);

Clazz.newMethod$(C$, 'initComboBox', function () {
this.installAncestorListener();
this.uiClassID = "ComboBoxUI";
this.setUIProperty$S$O("opaque", new Boolean(true));
this.updateUI();
});

Clazz.newMethod$(C$, 'installAncestorListener', function () {
this.addAncestorListener$javax_swing_event_AncestorListener(((
(function(){var C$=Clazz.newClass$(P$, "JComboBox$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'javax.swing.event.AncestorListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'ancestorAdded$javax_swing_event_AncestorEvent', function (event) {
this.b$['javax.swing.JComboBox'].hidePopup();
});

Clazz.newMethod$(C$, 'ancestorRemoved$javax_swing_event_AncestorEvent', function (event) {
this.b$['javax.swing.JComboBox'].hidePopup();
});

Clazz.newMethod$(C$, 'ancestorMoved$javax_swing_event_AncestorEvent', function (event) {
if (event.getSource() !== this.b$['javax.swing.JComboBox'] ) this.b$['javax.swing.JComboBox'].hidePopup();
});
})()
), Clazz.new((I$[3] || (I$[3]=Clazz.load(P$.JComboBox$1))).$init$, [this, null])));
});

Clazz.newMethod$(C$, 'updateUI', function () {
C$.superClazz.prototype.updateUI.apply(this, []);
var renderer = this.getRenderer();
if (Clazz.instanceOf(renderer, "java.awt.Component")) {
(I$[4] || (I$[4]=Clazz.load('javax.swing.SwingUtilities'))).updateComponentTreeUI$java_awt_Component(renderer);
}});

Clazz.newMethod$(C$, 'setModel$javax_swing_ComboBoxModel', function (aModel) {
var oldModel = this.dataModel;
if (oldModel != null ) {
oldModel.removeListDataListener$javax_swing_event_ListDataListener(this);
}this.dataModel = aModel;
this.dataModel.addListDataListener$javax_swing_event_ListDataListener(this);
this.selectedItemReminder = this.dataModel.getSelectedItem();
this.firePropertyChange$S$O$O("model", oldModel, this.dataModel);
});

Clazz.newMethod$(C$, 'getModel', function () {
return this.dataModel;
});

Clazz.newMethod$(C$, 'setLightWeightPopupEnabled$Z', function (aFlag) {
var oldFlag = this.lightWeightPopupEnabled;
this.lightWeightPopupEnabled = aFlag;
this.firePropertyChange$S$Z$Z("lightWeightPopupEnabled", oldFlag, this.lightWeightPopupEnabled);
});

Clazz.newMethod$(C$, 'isLightWeightPopupEnabled', function () {
return this.lightWeightPopupEnabled;
});

Clazz.newMethod$(C$, 'setEditable$Z', function (aFlag) {
var oldFlag = this.$isEditable;
this.$isEditable = aFlag;
this.firePropertyChange$S$Z$Z("editable", oldFlag, this.$isEditable);
});

Clazz.newMethod$(C$, 'isEditable', function () {
return this.$isEditable;
});

Clazz.newMethod$(C$, 'setMaximumRowCount$I', function (count) {
var oldCount = this.maximumRowCount;
this.maximumRowCount = count;
this.firePropertyChange$S$I$I("maximumRowCount", oldCount, this.maximumRowCount);
});

Clazz.newMethod$(C$, 'getMaximumRowCount', function () {
return this.maximumRowCount;
});

Clazz.newMethod$(C$, 'setRenderer$javax_swing_ListCellRenderer', function (aRenderer) {
var oldRenderer = this.renderer;
this.renderer = aRenderer;
this.firePropertyChange$S$O$O("renderer", oldRenderer, this.renderer);
this.invalidate();
});

Clazz.newMethod$(C$, 'getRenderer', function () {
return this.renderer;
});

Clazz.newMethod$(C$, 'setEditor$javax_swing_ComboBoxEditor', function (anEditor) {
var oldEditor = this.editor;
if (this.editor != null ) {
this.editor.removeActionListener$java_awt_event_ActionListener(this);
}this.editor = anEditor;
if (this.editor != null ) {
this.editor.addActionListener$java_awt_event_ActionListener(this);
}this.firePropertyChange$S$O$O("editor", oldEditor, this.editor);
});

Clazz.newMethod$(C$, 'getEditor', function () {
return this.editor;
});

Clazz.newMethod$(C$, 'setSelectedItem$O', function (anObject) {
var oldSelection = this.selectedItemReminder;
var objectToSelect = anObject;
if (oldSelection == null  || !oldSelection.equals$O(anObject) ) {
if (anObject != null  && !this.isEditable() ) {
var found = false;
for (var i = 0; i < this.dataModel.getSize(); i++) {
var element = this.dataModel.getElementAt$I(i);
if (anObject.equals$O(element)) {
found = true;
objectToSelect = element;
break;
}}
if (!found) {
return;
}}this.selectingItem = true;
this.dataModel.setSelectedItem$O(objectToSelect);
this.selectingItem = false;
if (this.selectedItemReminder !== this.dataModel.getSelectedItem() ) {
this.selectedItemChanged();
}}this.fireActionEvent();
});

Clazz.newMethod$(C$, 'getSelectedItem', function () {
return this.dataModel.getSelectedItem();
});

Clazz.newMethod$(C$, 'setSelectedIndex$I', function (anIndex) {
var size = this.dataModel.getSize();
if (anIndex == -1) {
this.setSelectedItem$O(null);
} else if (anIndex < -1 || anIndex >= size ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["setSelectedIndex: " + anIndex + " out of bounds" ]);
} else {
this.setSelectedItem$O(this.dataModel.getElementAt$I(anIndex));
}});

Clazz.newMethod$(C$, 'getSelectedIndex', function () {
var sObject = this.dataModel.getSelectedItem();
var i;
var c;
var obj;
for (i = 0, c = this.dataModel.getSize(); i < c; i++) {
obj = this.dataModel.getElementAt$I(i);
if (obj != null  && obj.equals$O(sObject) ) return i;
}
return -1;
});

Clazz.newMethod$(C$, 'getPrototypeDisplayValue', function () {
return this.prototypeDisplayValue;
});

Clazz.newMethod$(C$, 'setPrototypeDisplayValue$O', function (prototypeDisplayValue) {
var oldValue = this.prototypeDisplayValue;
this.prototypeDisplayValue = prototypeDisplayValue;
this.firePropertyChange$S$O$O("prototypeDisplayValue", oldValue, prototypeDisplayValue);
});

Clazz.newMethod$(C$, 'addItem$O', function (anObject) {
this.checkMutableComboBoxModel();
(this.dataModel).addElement$O(anObject);
});

Clazz.newMethod$(C$, 'insertItemAt$O$I', function (anObject, index) {
this.checkMutableComboBoxModel();
(this.dataModel).insertElementAt$O$I(anObject, index);
});

Clazz.newMethod$(C$, 'removeItem$O', function (anObject) {
this.checkMutableComboBoxModel();
(this.dataModel).removeElement$O(anObject);
});

Clazz.newMethod$(C$, 'removeItemAt$I', function (anIndex) {
this.checkMutableComboBoxModel();
(this.dataModel).removeElementAt$I(anIndex);
});

Clazz.newMethod$(C$, 'removeAllItems', function () {
this.checkMutableComboBoxModel();
var model = this.dataModel;
var size = model.getSize();
if (Clazz.instanceOf(model, "javax.swing.DefaultComboBoxModel")) {
(model).removeAllElements();
} else {
for (var i = 0; i < size; ++i) {
var element = model.getElementAt$I(0);
model.removeElement$O(element);
}
}this.selectedItemReminder = null;
if (this.isEditable()) {
this.editor.setItem$O(null);
}});

Clazz.newMethod$(C$, 'checkMutableComboBoxModel', function () {
if (!(Clazz.instanceOf(this.dataModel, "javax.swing.MutableComboBoxModel"))) throw Clazz.new(Clazz.load('java.lang.RuntimeException').c$$S,["Cannot use this method with a non-Mutable data model."]);
});

Clazz.newMethod$(C$, 'showPopup', function () {
this.setPopupVisible$Z(true);
});

Clazz.newMethod$(C$, 'hidePopup', function () {
this.setPopupVisible$Z(false);
});

Clazz.newMethod$(C$, 'setPopupVisible$Z', function (v) {
(this.getUI()).setPopupVisible$javax_swing_JComboBox$Z(this, v);
});

Clazz.newMethod$(C$, 'isPopupVisible', function () {
return (this.getUI()).isPopupVisible$javax_swing_JComboBox(this);
});

Clazz.newMethod$(C$, 'addItemListener$java_awt_event_ItemListener', function (aListener) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ItemListener), aListener);
});

Clazz.newMethod$(C$, 'removeItemListener$java_awt_event_ItemListener', function (aListener) {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ItemListener), aListener);
});

Clazz.newMethod$(C$, 'getItemListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ItemListener));
});

Clazz.newMethod$(C$, 'addActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
if ((l != null ) && (this.getAction() === l ) ) {
this.setAction$javax_swing_Action(null);
} else {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
}});

Clazz.newMethod$(C$, 'getActionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ActionListener));
});

Clazz.newMethod$(C$, 'addPopupMenuListener$javax_swing_event_PopupMenuListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.PopupMenuListener), l);
});

Clazz.newMethod$(C$, 'removePopupMenuListener$javax_swing_event_PopupMenuListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.PopupMenuListener), l);
});

Clazz.newMethod$(C$, 'getPopupMenuListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.PopupMenuListener));
});

Clazz.newMethod$(C$, 'firePopupMenuWillBecomeVisible', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuWillBecomeVisible$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'firePopupMenuWillBecomeInvisible', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuWillBecomeInvisible$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'firePopupMenuCanceled', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuCanceled$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'setActionCommand$S', function (aCommand) {
this.actionCommand = aCommand;
});

Clazz.newMethod$(C$, 'getActionCommand', function () {
return this.actionCommand;
});

Clazz.newMethod$(C$, 'setAction$javax_swing_Action', function (a) {
var oldValue = this.getAction();
if (this.$action == null  || !this.$action.equals$O(a) ) {
this.$action = a;
if (oldValue != null ) {
this.removeActionListener$java_awt_event_ActionListener(oldValue);
oldValue.removePropertyChangeListener$java_beans_PropertyChangeListener(this.actionPropertyChangeListener);
this.actionPropertyChangeListener = null;
}this.configurePropertiesFromAction$javax_swing_Action(this.$action);
if (this.$action != null ) {
if (!p$.isListener$Class$java_awt_event_ActionListener.apply(this, [Clazz.getClass(java.awt.event.ActionListener), this.$action])) {
this.addActionListener$java_awt_event_ActionListener(this.$action);
}this.actionPropertyChangeListener = this.createActionPropertyChangeListener$javax_swing_Action(this.$action);
this.$action.addPropertyChangeListener$java_beans_PropertyChangeListener(this.actionPropertyChangeListener);
}this.firePropertyChange$S$O$O("action", oldValue, this.$action);
}});

Clazz.newMethod$(C$, 'isListener$Class$java_awt_event_ActionListener', function (c, a) {
var isListener = false;
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === c  && listeners[i + 1] === a  ) {
isListener = true;
}}
return isListener;
});

Clazz.newMethod$(C$, 'getAction', function () {
return this.$action;
});

Clazz.newMethod$(C$, 'configurePropertiesFromAction$javax_swing_Action', function (a) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setEnabledFromAction$javax_swing_JComponent$javax_swing_Action(this, a);
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setToolTipTextFromAction$javax_swing_JComponent$javax_swing_Action(this, a);
p$.setActionCommandFromAction$javax_swing_Action.apply(this, [a]);
});

Clazz.newMethod$(C$, 'createActionPropertyChangeListener$javax_swing_Action', function (a) {
return Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.JComboBox').ComboBoxActionPropertyChangeListener))).c$$javax_swing_JComboBox$javax_swing_Action,[this, a]);
});

Clazz.newMethod$(C$, 'actionPropertyChanged$javax_swing_Action$S', function (action, propertyName) {
if (propertyName == "ActionCommandKey") {
p$.setActionCommandFromAction$javax_swing_Action.apply(this, [action]);
} else if (propertyName == "enabled") {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setEnabledFromAction$javax_swing_JComponent$javax_swing_Action(this, action);
} else if ("ShortDescription" == propertyName) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).setToolTipTextFromAction$javax_swing_JComponent$javax_swing_Action(this, action);
}});

Clazz.newMethod$(C$, 'setActionCommandFromAction$javax_swing_Action', function (a) {
this.setActionCommand$S((a != null ) ? a.getValue$S("ActionCommandKey") : null);
});

Clazz.newMethod$(C$, 'fireItemStateChanged$java_awt_event_ItemEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ItemListener) ) {
(listeners[i + 1]).itemStateChanged$java_awt_event_ItemEvent(e);
}}
});

Clazz.newMethod$(C$, 'fireActionEvent', function () {
if (!this.firingActionEvent) {
this.firingActionEvent = true;
var e = null;
var listeners = this.listenerList.getListenerList();
var mostRecentEventTime = (I$[7] || (I$[7]=Clazz.load('java.awt.EventQueue'))).getMostRecentEventTime();
var modifiers = 0;
var currentEvent = (I$[7] || (I$[7]=Clazz.load('java.awt.EventQueue'))).getCurrentEvent();
if (Clazz.instanceOf(currentEvent, "java.awt.event.InputEvent")) {
modifiers = (currentEvent).getModifiers();
} else if (Clazz.instanceOf(currentEvent, "java.awt.event.ActionEvent")) {
modifiers = (currentEvent).getModifiers();
}for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ActionListener) ) {
if (e == null ) e = Clazz.new((I$[8] || (I$[8]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S$J$I,[this, 1001, this.getActionCommand(), mostRecentEventTime, modifiers]);
(listeners[i + 1]).actionPerformed$java_awt_event_ActionEvent(e);
}}
this.firingActionEvent = false;
}});

Clazz.newMethod$(C$, 'selectedItemChanged', function () {
if (this.selectedItemReminder != null ) {
this.fireItemStateChanged$java_awt_event_ItemEvent(Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.event.ItemEvent'))).c$$java_awt_ItemSelectable$I$O$I,[this, 701, this.selectedItemReminder, 2]));
}this.selectedItemReminder = this.dataModel.getSelectedItem();
if (this.selectedItemReminder != null ) {
this.fireItemStateChanged$java_awt_event_ItemEvent(Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.event.ItemEvent'))).c$$java_awt_ItemSelectable$I$O$I,[this, 701, this.selectedItemReminder, 1]));
}});

Clazz.newMethod$(C$, 'getSelectedObjects', function () {
var selectedObject = this.getSelectedItem();
if (selectedObject == null ) return  Clazz.newArray$(java.lang.Object, [0]);
 else {
var result =  Clazz.newArray$(java.lang.Object, [1]);
result[0] = selectedObject;
return result;
}});

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var newItem = this.getEditor().getItem();
this.setPopupVisible$Z(false);
this.getModel().setSelectedItem$O(newItem);
var oldCommand = this.getActionCommand();
this.setActionCommand$S("comboBoxEdited");
this.fireActionEvent();
this.setActionCommand$S(oldCommand);
});

Clazz.newMethod$(C$, 'contentsChanged$javax_swing_event_ListDataEvent', function (e) {
var oldSelection = this.selectedItemReminder;
var newSelection = this.dataModel.getSelectedItem();
if (oldSelection == null  || !oldSelection.equals$O(newSelection) ) {
this.selectedItemChanged();
if (!this.selectingItem) {
this.fireActionEvent();
}}});

Clazz.newMethod$(C$, 'intervalAdded$javax_swing_event_ListDataEvent', function (e) {
if (this.selectedItemReminder !== this.dataModel.getSelectedItem() ) {
this.selectedItemChanged();
}});

Clazz.newMethod$(C$, 'intervalRemoved$javax_swing_event_ListDataEvent', function (e) {
this.contentsChanged$javax_swing_event_ListDataEvent(e);
});

Clazz.newMethod$(C$, 'selectWithKeyChar$C', function (keyChar) {
var index;
if (this.keySelectionManager == null ) this.keySelectionManager = this.createDefaultKeySelectionManager();
index = this.keySelectionManager.selectionForKey$C$javax_swing_ComboBoxModel(keyChar, this.getModel());
if (index != -1) {
this.setSelectedIndex$I(index);
return true;
} else return false;
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (b) {
C$.superClazz.prototype.setEnabled$Z.apply(this, [b]);
this.firePropertyChange$S$Z$Z("enabled", !this.isEnabled(), this.isEnabled());
});

Clazz.newMethod$(C$, 'configureEditor$javax_swing_ComboBoxEditor$O', function (anEditor, anItem) {
anEditor.setItem$O(anItem);
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent', function (e) {
if (e.getKeyCode() == 9) {
this.hidePopup();
}C$.superClazz.prototype.processKeyEvent$java_awt_event_KeyEvent.apply(this, [e]);
});

Clazz.newMethod$(C$, 'setKeySelectionManager$javax_swing_JComboBox_KeySelectionManager', function (aManager) {
this.keySelectionManager = aManager;
});

Clazz.newMethod$(C$, 'getKeySelectionManager', function () {
return this.keySelectionManager;
});

Clazz.newMethod$(C$, 'getItemCount', function () {
return this.dataModel.getSize();
});

Clazz.newMethod$(C$, 'getItemAt$I', function (index) {
return this.dataModel.getElementAt$I(index);
});

Clazz.newMethod$(C$, 'createDefaultKeySelectionManager', function () {
return Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.JComboBox').DefaultKeySelectionManager))), [this, null]);
});

Clazz.newMethod$(C$, 'paramString', function () {
var selectedItemReminderString = (this.selectedItemReminder != null  ? this.selectedItemReminder.toString() : "");
var isEditableString = (this.$isEditable ? "true" : "false");
var lightWeightPopupEnabledString = (this.lightWeightPopupEnabled ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",isEditable=" + isEditableString + ",lightWeightPopupEnabled=" + lightWeightPopupEnabledString + ",maximumRowCount=" + this.maximumRowCount + ",selectedItemReminder=" + selectedItemReminderString ;
});
;
(function(){var C$=Clazz.newClass$(P$.JComboBox, "ComboBoxActionPropertyChangeListener", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.ActionPropertyChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComboBox$javax_swing_Action', function (b, a) {
C$.superClazz.c$$TT$javax_swing_Action.apply(this, [b, a]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPropertyChanged$javax_swing_JComboBox$javax_swing_Action$java_beans_PropertyChangeEvent', function (cb, action, e) {
if ((I$[0] || (I$[0]=Clazz.load('javax.swing.AbstractAction'))).shouldReconfigure$java_beans_PropertyChangeEvent(e)) {
cb.configurePropertiesFromAction$javax_swing_Action(action);
} else {
cb.actionPropertyChanged$javax_swing_Action$S(action, e.getPropertyName());
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
var C$=Clazz.newInterface$(P$.JComboBox, "KeySelectionManager", function(){
});

;
(function(){var C$=Clazz.newClass$(P$.JComboBox, "DefaultKeySelectionManager", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.JComboBox.KeySelectionManager');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'selectionForKey$C$javax_swing_ComboBoxModel', function (aKey, aModel) {
var i;
var c;
var currentSelection = -1;
var selectedItem = aModel.getSelectedItem();
var v;
var pattern;
if (selectedItem != null ) {
for (i = 0, c = aModel.getSize(); i < c; i++) {
if (selectedItem === aModel.getElementAt$I(i) ) {
currentSelection = i;
break;
}}
}pattern = ("" + aKey).toLowerCase();
aKey = pattern.charAt(0);
for (i = ++currentSelection, c = aModel.getSize(); i < c; i++) {
var elem = aModel.getElementAt$I(i);
if (elem != null  && elem.toString() != null  ) {
v = elem.toString().toLowerCase();
if (v.length$() > 0 && v.charAt(0) == aKey ) return i;
}}
for (i = 0; i < currentSelection; i++) {
var elem = aModel.getElementAt$I(i);
if (elem != null  && elem.toString() != null  ) {
v = elem.toString().toLowerCase();
if (v.length$() > 0 && v.charAt(0) == aKey ) return i;
}}
return -1;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:36
