(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JTextPane", null, 'javax.swing.JEditorPane');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S$S$S.apply(this, [null, null, "TextPaneUI"]);
C$.$init$.apply(this);
var editorKit = this.createDefaultEditorKit();
var contentType = editorKit.getContentType();
if (contentType != null  && P$.JEditorPane.getEditorKitClassNameForContentType$S(contentType) == P$.JEditorPane.defaultEditorKitMap.get$O(contentType) ) {
this.setEditorKitForContentType$S$javax_swing_text_EditorKit(contentType, editorKit);
}this.setEditorKit$javax_swing_text_EditorKit(editorKit);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_StyledDocument', function (doc) {
C$.c$.apply(this, []);
this.setStyledDocument$javax_swing_text_StyledDocument(doc);
}, 1);

Clazz.newMethod$(C$, 'setDocument$javax_swing_text_Document', function (doc) {
if (Clazz.instanceOf(doc, "javax.swing.text.StyledDocument")) {
C$.superClazz.prototype.setDocument$javax_swing_text_Document.apply(this, [doc]);
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Model must be StyledDocument"]);
}});

Clazz.newMethod$(C$, 'setStyledDocument$javax_swing_text_StyledDocument', function (doc) {
C$.superClazz.prototype.setDocument$javax_swing_text_Document.apply(this, [doc]);
});

Clazz.newMethod$(C$, 'getStyledDocument', function () {
return this.getDocument();
});

Clazz.newMethod$(C$, 'replaceSelection$S', function (content) {
p$.replaceSelection$S$Z.apply(this, [content, true]);
});

Clazz.newMethod$(C$, 'replaceSelection$S$Z', function (content, checkEditable) {
if (checkEditable && !this.isEditable() ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
return;
}var doc = this.getStyledDocument();
if (doc != null ) {
try {
var caret = this.getCaret();
var p0 = Math.min(caret.getDot(), caret.getMark());
var p1 = Math.max(caret.getDot(), caret.getMark());
var attr = this.getInputAttributes().copyAttributes();
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).replace$I$I$S$javax_swing_text_AttributeSet(p0, p1 - p0, content, attr);
} else {
if (p0 != p1) {
doc.remove$I$I(p0, p1 - p0);
}if (content != null  && content.length$() > 0 ) {
doc.insertString$I$S$javax_swing_text_AttributeSet(p0, content, attr);
}}} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
(I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().provideErrorFeedback$java_awt_Component(this);
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'insertComponent$java_awt_Component', function (c) {
var inputAttributes = this.getInputAttributes();
inputAttributes.removeAttributes$javax_swing_text_AttributeSet(inputAttributes);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.StyleConstants'))).setComponent$javax_swing_text_MutableAttributeSet$java_awt_Component(inputAttributes, c);
p$.replaceSelection$S$Z.apply(this, [" ", false]);
inputAttributes.removeAttributes$javax_swing_text_AttributeSet(inputAttributes);
});

Clazz.newMethod$(C$, 'insertIcon$javax_swing_Icon', function (g) {
var inputAttributes = this.getInputAttributes();
inputAttributes.removeAttributes$javax_swing_text_AttributeSet(inputAttributes);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.StyleConstants'))).setIcon$javax_swing_text_MutableAttributeSet$javax_swing_Icon(inputAttributes, g);
p$.replaceSelection$S$Z.apply(this, [" ", false]);
inputAttributes.removeAttributes$javax_swing_text_AttributeSet(inputAttributes);
});

Clazz.newMethod$(C$, 'addStyle$S$javax_swing_text_Style', function (nm, parent) {
var doc = this.getStyledDocument();
return doc.addStyle$S$javax_swing_text_Style(nm, parent);
});

Clazz.newMethod$(C$, 'removeStyle$S', function (nm) {
var doc = this.getStyledDocument();
doc.removeStyle$S(nm);
});

Clazz.newMethod$(C$, 'getStyle$S', function (nm) {
var doc = this.getStyledDocument();
return doc.getStyle$S(nm);
});

Clazz.newMethod$(C$, 'setLogicalStyle$javax_swing_text_Style', function (s) {
var doc = this.getStyledDocument();
doc.setLogicalStyle$I$javax_swing_text_Style(this.getCaretPosition(), s);
});

Clazz.newMethod$(C$, 'getLogicalStyle', function () {
var doc = this.getStyledDocument();
return doc.getLogicalStyle$I(this.getCaretPosition());
});

Clazz.newMethod$(C$, 'getCharacterAttributes', function () {
var doc = this.getStyledDocument();
var run = doc.getCharacterElement$I(this.getCaretPosition());
if (run != null ) {
return run.getAttributes();
}return null;
});

Clazz.newMethod$(C$, 'setCharacterAttributes$javax_swing_text_AttributeSet$Z', function (attr, replace) {
var p0 = this.getSelectionStart();
var p1 = this.getSelectionEnd();
if (p0 != p1) {
var doc = this.getStyledDocument();
doc.setCharacterAttributes$I$I$javax_swing_text_AttributeSet$Z(p0, p1 - p0, attr, replace);
} else {
var inputAttributes = this.getInputAttributes();
if (replace) {
inputAttributes.removeAttributes$javax_swing_text_AttributeSet(inputAttributes);
}inputAttributes.addAttributes$javax_swing_text_AttributeSet(attr);
}});

Clazz.newMethod$(C$, 'getParagraphAttributes', function () {
var doc = this.getStyledDocument();
var paragraph = doc.getParagraphElement$I(this.getCaretPosition());
if (paragraph != null ) {
return paragraph.getAttributes();
}return null;
});

Clazz.newMethod$(C$, 'setParagraphAttributes$javax_swing_text_AttributeSet$Z', function (attr, replace) {
var p0 = this.getSelectionStart();
var p1 = this.getSelectionEnd();
var doc = this.getStyledDocument();
doc.setParagraphAttributes$I$I$javax_swing_text_AttributeSet$Z(p0, p1 - p0, attr, replace);
});

Clazz.newMethod$(C$, 'getInputAttributes', function () {
return this.getStyledEditorKit().getInputAttributes();
});

Clazz.newMethod$(C$, 'getStyledEditorKit', function () {
return this.getEditorKit();
});

Clazz.newMethod$(C$, 'createDefaultEditorKit', function () {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.StyledEditorKit'))));
});

Clazz.newMethod$(C$, 'setEditorKit$javax_swing_text_EditorKit', function (kit) {
if (Clazz.instanceOf(kit, "javax.swing.text.StyledEditorKit")) {
C$.superClazz.prototype.setEditorKit$javax_swing_text_EditorKit.apply(this, [kit]);
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Must be StyledEditorKit"]);
}});

Clazz.newMethod$(C$, 'paramString', function () {
return C$.superClazz.prototype.paramString.apply(this, []);
});
})();
//Created 2017-10-14 13:31:45
