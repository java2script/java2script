(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newClass$(P$, "BadLocationException", null, 'Exception');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.offs = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (s, offs) {
C$.superClazz.c$$S.apply(this, [s]);
C$.$init$.apply(this);
this.offs = offs;
}, 1);

Clazz.newMethod$(C$, 'offsetRequested', function () {
return this.offs;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:00
