(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "RowSorter", function(){
Clazz.newInstance$(this, arguments);
});


Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'addRowSorterListener$javax_swing_event_RowSorterListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.RowSorterListener), l);
});

Clazz.newMethod$(C$, 'removeRowSorterListener$javax_swing_event_RowSorterListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.RowSorterListener), l);
});

Clazz.newMethod$(C$, 'fireSortOrderChanged', function () {
this.fireRowSorterChanged$javax_swing_event_RowSorterEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.RowSorterEvent'))).c$$javax_swing_RowSorter,[this]));
});

Clazz.newMethod$(C$, 'fireRowSorterChanged$IA', function (lastRowIndexToModel) {
this.fireRowSorterChanged$javax_swing_event_RowSorterEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.RowSorterEvent'))).c$$javax_swing_RowSorter$javax_swing_event_RowSorterEvent_Type$IA,[this, (I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.event.RowSorterEvent').Type))).SORTED, lastRowIndexToModel]));
});

Clazz.newMethod$(C$, 'fireRowSorterChanged$javax_swing_event_RowSorterEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.RowSorterListener) ) {
(listeners[i + 1]).sorterChanged$javax_swing_event_RowSorterEvent(event);
}}
});
;
(function(){var C$=Clazz.newClass$(P$.RowSorter, "SortKey", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.column = 0;
this.sortOrder = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$javax_swing_SortOrder', function (column, sortOrder) {
C$.$init$.apply(this);
if (sortOrder == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["sort order must be non-null"]);
}this.column = column;
this.sortOrder = sortOrder;
}, 1);

Clazz.newMethod$(C$, 'getColumn', function () {
return this.column;
});

Clazz.newMethod$(C$, 'getSortOrder', function () {
return this.sortOrder;
});

Clazz.newMethod$(C$, 'hashCode', function () {
var result = 17;
result = 37 * result + this.column;
result = 37 * result + this.sortOrder.hashCode();
return result;
});

Clazz.newMethod$(C$, 'equals$O', function (o) {
if (o === this ) {
return true;
}if (Clazz.instanceOf(o, "javax.swing.RowSorter.SortKey")) {
return ((o).column == this.column && (o).sortOrder === this.sortOrder  );
}return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:49
