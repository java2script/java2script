(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JToolBar", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.SwingConstants');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.$paintBorder = true;
this.margin = null;
this.floatable = true;
this.orientation = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (orientation) {
C$.c$$S$I.apply(this, [null, orientation]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (name) {
C$.c$$S$I.apply(this, [name, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I', function (name, orientation) {
Clazz.super(C$, this,1);
this.setName$S(name);
p$.checkOrientation$I.apply(this, [orientation]);
this.orientation = orientation;
var layout = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JToolBar').DefaultToolBarLayout))).c$$I, [this, null, orientation]);
this.setLayout$java_awt_LayoutManager(layout);
this.addPropertyChangeListener$java_beans_PropertyChangeListener(layout);
this.uiClassID = "ToolBarUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'updateUI', function () {
C$.superClazz.prototype.updateUI.apply(this, []);
if (this.getLayout() == null ) {
this.setLayout$java_awt_LayoutManager(Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JToolBar').DefaultToolBarLayout))).c$$I, [this, null, this.getOrientation()]));
}this.invalidate();
});

Clazz.newMethod$(C$, 'getComponentIndex$java_awt_Component', function (c) {
var ncomponents = this.getComponentCount();
var component = this.getComponents();
for (var i = 0; i < ncomponents; i++) {
var comp = component[i];
if (comp === c ) return i;
}
return -1;
});

Clazz.newMethod$(C$, 'getComponentAtIndex$I', function (i) {
var ncomponents = this.getComponentCount();
if (i >= 0 && i < ncomponents ) {
var component = this.getComponents();
return component[i];
}return null;
});

Clazz.newMethod$(C$, 'setMargin$java_awt_Insets', function (m) {
var old = this.margin;
this.margin = m;
this.firePropertyChange$S$O$O("margin", old, m);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'getMargin', function () {
if (this.margin == null ) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
} else {
return this.margin;
}});

Clazz.newMethod$(C$, 'isBorderPainted', function () {
return this.$paintBorder;
});

Clazz.newMethod$(C$, 'setBorderPainted$Z', function (b) {
if (this.$paintBorder != b ) {
var old = this.$paintBorder;
this.$paintBorder = b;
this.firePropertyChange$S$Z$Z("borderPainted", old, b);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'paintBorder$java_awt_Graphics', function (g) {
if (this.isBorderPainted()) {
C$.superClazz.prototype.paintBorder$java_awt_Graphics.apply(this, [g]);
}});

Clazz.newMethod$(C$, 'isFloatable', function () {
return this.floatable;
});

Clazz.newMethod$(C$, 'setFloatable$Z', function (b) {
if (this.floatable != b ) {
var old = this.floatable;
this.floatable = b;
this.firePropertyChange$S$Z$Z("floatable", old, b);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'getOrientation', function () {
return this.orientation;
});

Clazz.newMethod$(C$, 'setOrientation$I', function (o) {
p$.checkOrientation$I.apply(this, [o]);
if (this.orientation != o) {
var old = this.orientation;
this.orientation = o;
this.firePropertyChange$S$I$I("orientation", old, o);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'setRollover$Z', function (rollover) {
this.putClientProperty$O$O("JToolBar.isRollover", rollover ? Boolean.TRUE : Boolean.FALSE);
});

Clazz.newMethod$(C$, 'isRollover', function () {
var rollover = this.getClientProperty$O("JToolBar.isRollover");
if (rollover != null ) {
return rollover.booleanValue();
}return false;
});

Clazz.newMethod$(C$, 'checkOrientation$I', function (orientation) {
switch (orientation) {
case 1:
case 0:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["orientation must be one of: VERTICAL, HORIZONTAL"]);
}
});

Clazz.newMethod$(C$, 'addSeparator', function () {
this.addSeparator$java_awt_Dimension(null);
});

Clazz.newMethod$(C$, 'addSeparator$java_awt_Dimension', function (size) {
var s = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.JToolBar').Separator))).c$$java_awt_Dimension,[size]);
this.add$java_awt_Component(s);
});

Clazz.newMethod$(C$, 'add$javax_swing_Action', function (a) {
var b = this.createActionComponent$javax_swing_Action(a);
b.setAction$javax_swing_Action(a);
this.add$java_awt_Component(b);
return b;
});

Clazz.newMethod$(C$, 'createActionComponent$javax_swing_Action', function (a) {
var b = ((
(function(){var C$=Clazz.newClass$(P$, "JToolBar$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.JButton'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'createActionPropertyChangeListener$javax_swing_Action', function (a) {
var pcl = this.b$['javax.swing.JToolBar'].createActionChangeListener$javax_swing_JButton(this);
if (pcl == null ) {
pcl = C$.superClazz.prototype.createActionPropertyChangeListener$javax_swing_Action.apply(this, [a]);
}return pcl;
});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JButton'))), [this, null],P$.JToolBar$1));
if (a != null  && (a.getValue$S("SmallIcon") != null  || a.getValue$S("SwingLargeIconKey") != null  ) ) {
b.setHideActionText$Z(true);
}b.setHorizontalTextPosition$I(0);
b.setVerticalTextPosition$I(3);
return b;
});

Clazz.newMethod$(C$, 'createActionChangeListener$javax_swing_JButton', function (b) {
return null;
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
if (Clazz.instanceOf(comp, "javax.swing.JToolBar.Separator")) {
if (this.getOrientation() == 1) {
(comp).setOrientation$I(0);
} else {
(comp).setOrientation$I(1);
}}this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
if (Clazz.instanceOf(comp, "javax.swing.JButton")) {
(comp).setDefaultCapable$Z(false);
}return comp;
});

Clazz.newMethod$(C$, 'paramString', function () {
var paintBorderString = (this.$paintBorder ? "true" : "false");
var marginString = (this.margin != null  ? this.margin.toString() : "");
var floatableString = (this.floatable ? "true" : "false");
var orientationString = (this.orientation == 0 ? "HORIZONTAL" : "VERTICAL");
return C$.superClazz.prototype.paramString.apply(this, []) + ",floatable=" + floatableString + ",margin=" + marginString + ",orientation=" + orientationString + ",paintBorder=" + paintBorderString ;
});

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (mgr) {
var oldMgr = this.getLayout();
if (Clazz.instanceOf(oldMgr, "java.beans.PropertyChangeListener")) {
this.removePropertyChangeListener$java_beans_PropertyChangeListener(oldMgr);
}C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [mgr]);
});
;
(function(){var C$=Clazz.newClass$(P$.JToolBar, "Separator", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JSeparator');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.separatorSize = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_awt_Dimension.apply(this, [null]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dimension', function (size) {
C$.superClazz.c$$I$S.apply(this, [0, "ToolBarSeparatorUI"]);
C$.$init$.apply(this);
this.setSeparatorSize$java_awt_Dimension(size);
}, 1);

Clazz.newMethod$(C$, 'setSeparatorSize$java_awt_Dimension', function (size) {
if (size != null ) {
this.separatorSize = size;
} else {
C$.superClazz.prototype.updateUI.apply(this, []);
}this.invalidate();
});

Clazz.newMethod$(C$, 'getSeparatorSize', function () {
return this.separatorSize;
});

Clazz.newMethod$(C$, 'getMinimumSize', function () {
if (this.separatorSize != null ) {
return this.separatorSize.getSize();
} else {
return C$.superClazz.prototype.getMinimumSize.apply(this, []);
}});

Clazz.newMethod$(C$, 'getMaximumSize', function () {
if (this.separatorSize != null ) {
return this.separatorSize.getSize();
} else {
return C$.superClazz.prototype.getMaximumSize.apply(this, []);
}});

Clazz.newMethod$(C$, 'getPreferredSize', function () {
if (this.separatorSize != null ) {
return this.separatorSize.getSize();
} else {
return this.getPrefSizeJComp();
}});
})()
;
(function(){var C$=Clazz.newClass$(P$.JToolBar, "DefaultToolBarLayout", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, ['java.awt.LayoutManager2', 'java.beans.PropertyChangeListener', 'javax.swing.plaf.UIResource']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.lm = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (orientation) {
C$.$init$.apply(this);
if (orientation == 1) {
this.lm = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.BoxLayout'))).c$$java_awt_Container$I,[this.b$['javax.swing.JToolBar'], 3]);
} else {
this.lm = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.BoxLayout'))).c$$java_awt_Container$I,[this.b$['javax.swing.JToolBar'], 2]);
}}, 1);

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
this.lm.addLayoutComponent$S$java_awt_Component(name, comp);
});

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
this.lm.addLayoutComponent$java_awt_Component$O(comp, constraints);
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
this.lm.removeLayoutComponent$java_awt_Component(comp);
});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
return this.lm.preferredLayoutSize$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
return this.lm.minimumLayoutSize$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'maximumLayoutSize$java_awt_Container', function (target) {
return this.lm.maximumLayoutSize$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (target) {
this.lm.layoutContainer$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'getLayoutAlignmentX$java_awt_Container', function (target) {
return this.lm.getLayoutAlignmentX$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'getLayoutAlignmentY$java_awt_Container', function (target) {
return this.lm.getLayoutAlignmentY$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'invalidateLayout$java_awt_Container', function (target) {
this.lm.invalidateLayout$java_awt_Container(target);
});

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var name = e.getPropertyName();
if (name.equals$O("orientation")) {
var o = (e.getNewValue()).intValue();
if (o == 1) this.lm = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.BoxLayout'))).c$$java_awt_Container$I,[this.b$['javax.swing.JToolBar'], 3]);
 else {
this.lm = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.BoxLayout'))).c$$java_awt_Container$I,[this.b$['javax.swing.JToolBar'], 2]);
}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:46
