(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "ActionPropertyChangeListener", null, null, 'java.beans.PropertyChangeListener');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.action = null;
}, 1);

Clazz.newMethod$(C$, 'c$$TT$javax_swing_Action', function (c, a) {
C$.$init$.apply(this);
p$.setTarget$TT.apply(this, [c]);
this.action = a;
}, 1);

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var target = this.getTarget();
if (target == null ) {
this.getAction().removePropertyChangeListener$java_beans_PropertyChangeListener(this);
} else {
this.actionPropertyChanged$TT$javax_swing_Action$java_beans_PropertyChangeEvent(target, this.getAction(), e);
}});

Clazz.newMethod$(C$, 'setTarget$TT', function (c) {
});

Clazz.newMethod$(C$, 'getTarget', function () {
return null;
});

Clazz.newMethod$(C$, 'getAction', function () {
return this.action;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:30
