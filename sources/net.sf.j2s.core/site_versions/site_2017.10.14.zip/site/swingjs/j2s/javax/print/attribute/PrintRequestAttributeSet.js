(function(){var P$=Clazz.newPackage$("javax.print.attribute");
var C$=Clazz.newInterface$(P$, "PrintRequestAttributeSet", null, null, 'javax.print.attribute.AttributeSet');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:29
