(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SizeRequirements");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.minimum = 0;
this.preferred = 0;
this.maximum = 0;
this.alignment = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
this.minimum = 0;
this.preferred = 0;
this.maximum = 0;
this.alignment = 0.5;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$F', function (min, pref, max, a) {
C$.$init$.apply(this);
this.minimum = min;
this.preferred = pref;
this.maximum = max;
this.alignment = a > 1.0  ? 1.0 : a < 0.0  ? 0.0 : a;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "[" + this.minimum + "," + this.preferred + "," + this.maximum + "]@" + new Float(this.alignment).toString() ;
});

Clazz.newMethod$(C$, 'getTiledSizeRequirements$javax_swing_SizeRequirementsA', function (children) {
var total = Clazz.new(C$);
for (var i = 0; i < children.length; i++) {
var req = children[i];
total.minimum = ($i$[0] = Math.min(total.minimum + req.minimum, 2147483647), $i$[0]);
total.preferred = ($i$[0] = Math.min(total.preferred + req.preferred, 2147483647), $i$[0]);
total.maximum = ($i$[0] = Math.min(total.maximum + req.maximum, 2147483647), $i$[0]);
}
return total;
}, 1);

Clazz.newMethod$(C$, 'getAlignedSizeRequirements$javax_swing_SizeRequirementsA', function (children) {
var totalAscent = Clazz.new(C$);
var totalDescent = Clazz.new(C$);
for (var i = 0; i < children.length; i++) {
var req = children[i];
var ascent = ($i$[0] = (req.alignment * req.minimum), $i$[0]);
var descent = req.minimum - ascent;
totalAscent.minimum = Math.max(ascent, totalAscent.minimum);
totalDescent.minimum = Math.max(descent, totalDescent.minimum);
ascent = ($i$[0] = (req.alignment * req.preferred), $i$[0]);
descent = req.preferred - ascent;
totalAscent.preferred = Math.max(ascent, totalAscent.preferred);
totalDescent.preferred = Math.max(descent, totalDescent.preferred);
ascent = ($i$[0] = (req.alignment * req.maximum), $i$[0]);
descent = req.maximum - ascent;
totalAscent.maximum = Math.max(ascent, totalAscent.maximum);
totalDescent.maximum = Math.max(descent, totalDescent.maximum);
}
var min = ($i$[0] = Math.min(totalAscent.minimum + totalDescent.minimum, 2147483647), $i$[0]);
var pref = ($i$[0] = Math.min(totalAscent.preferred + totalDescent.preferred, 2147483647), $i$[0]);
var max = ($i$[0] = Math.min(totalAscent.maximum + totalDescent.maximum, 2147483647), $i$[0]);
var alignment = 0.0;
if (min > 0) {
alignment = totalAscent.minimum / min;
alignment = alignment > 1.0  ? 1.0 : alignment < 0.0  ? 0.0 : alignment;
}return Clazz.new(C$.c$$I$I$I$F,[min, pref, max, alignment]);
}, 1);

Clazz.newMethod$(C$, 'calculateTiledPositions$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA', function (allocated, total, children, offsets, spans) {
C$.calcTiled$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, total, children, offsets, spans, true);
}, 1);

Clazz.newMethod$(C$, 'calculateTiledPositions$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, total, children, offsets, spans, forward) {
C$.calcTiled$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, total, children, offsets, spans, forward);
}, 1);

Clazz.newMethod$(C$, 'calcTiled$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, total, children, offsets, spans, forward) {
var min = 0;
var pref = 0;
var max = 0;
for (var i = 0; i < children.length; i++) {
min = min+(children[i].minimum);
pref = pref+(children[i].preferred);
max = max+(children[i].maximum);
}
if (allocated >= pref) {
C$.expandedTile$I$J$J$J$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, min, pref, max, children, offsets, spans, forward);
} else {
C$.compressedTile$I$J$J$J$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, min, pref, max, children, offsets, spans, forward);
}}, 1);

Clazz.newMethod$(C$, 'compressedTile$I$J$J$J$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, min, pref, max, request, offsets, spans, forward) {
var totalPlay = Math.min(pref - allocated, pref - min);
var factor = (pref - min == 0) ? 0.0 : totalPlay / (pref - min);
var totalOffset;
if (forward) {
totalOffset = 0;
for (var i = 0; i < spans.length; i++) {
offsets[i] = totalOffset;
var req = request[i];
var play = factor * (req.preferred - req.minimum);
spans[i] = (req.preferred - play);
totalOffset = ($i$[0] = Math.min(totalOffset + spans[i], 2147483647), $i$[0]);
}
} else {
totalOffset = allocated;
for (var i = 0; i < spans.length; i++) {
var req = request[i];
var play = factor * (req.preferred - req.minimum);
spans[i] = (req.preferred - play);
offsets[i] = totalOffset - spans[i];
totalOffset = ($i$[0] = Math.max(totalOffset - spans[i], 0), $i$[0]);
}
}}, 1);

Clazz.newMethod$(C$, 'expandedTile$I$J$J$J$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, min, pref, max, request, offsets, spans, forward) {
var totalPlay = Math.min(allocated - pref, max - pref);
var factor = (max - pref == 0) ? 0.0 : totalPlay / (max - pref);
var totalOffset;
if (forward) {
totalOffset = 0;
for (var i = 0; i < spans.length; i++) {
offsets[i] = totalOffset;
var req = request[i];
var play = ($i$[0] = (factor * (req.maximum - req.preferred)), $i$[0]);
spans[i] = Math.min(req.preferred + play, 2147483647);
totalOffset = ($i$[0] = Math.min(totalOffset + spans[i], 2147483647), $i$[0]);
}
} else {
totalOffset = allocated;
for (var i = 0; i < spans.length; i++) {
var req = request[i];
var play = ($i$[0] = (factor * (req.maximum - req.preferred)), $i$[0]);
spans[i] = Math.min(req.preferred + play, 2147483647);
offsets[i] = totalOffset - spans[i];
totalOffset = ($i$[0] = Math.max(totalOffset - spans[i], 0), $i$[0]);
}
}}, 1);

Clazz.newMethod$(C$, 'calculateAlignedPositions$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA', function (allocated, total, children, offsets, spans) {
C$.calcAligned$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, total, children, offsets, spans, true);
}, 1);

Clazz.newMethod$(C$, 'calcAligned$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, total, children, offsets, spans, normal) {
var totalAlignment = normal ? total.alignment : 1.0 - total.alignment;
var totalAscent = ($i$[0] = (allocated * totalAlignment), $i$[0]);
var totalDescent = allocated - totalAscent;
for (var i = 0; i < children.length; i++) {
var req = children[i];
var alignment = normal ? req.alignment : 1.0 - req.alignment;
var maxAscent = ($i$[0] = (req.maximum * alignment), $i$[0]);
var maxDescent = req.maximum - maxAscent;
var ascent = Math.min(totalAscent, maxAscent);
var descent = Math.min(totalDescent, maxDescent);
offsets[i] = totalAscent - ascent;
spans[i] = Math.min(ascent + descent, 2147483647);
}
}, 1);

Clazz.newMethod$(C$, 'calculateAlignedPositions$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z', function (allocated, total, children, offsets, spans, normal) {
C$.calcAligned$I$javax_swing_SizeRequirements$javax_swing_SizeRequirementsA$IA$IA$Z(allocated, total, children, offsets, spans, normal);
}, 1);

Clazz.newMethod$(C$, 'adjustSizes$I$javax_swing_SizeRequirementsA', function (delta, children) {
return  Clazz.newArray$(Integer.TYPE, [0]);
}, 1);
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:49
