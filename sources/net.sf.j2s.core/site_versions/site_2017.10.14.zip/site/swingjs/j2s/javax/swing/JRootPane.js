(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JRootPane", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.windowDecorationStyle = 0;
this.menuBar = null;
this.contentPane = null;
this.layeredPane = null;
this.glassPane = null;
this.defaultButton = null;
this.defaultPressAction = null;
this.defaultReleaseAction = null;
this.useTrueDoubleBuffering = true;
this.paneCount = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (prefix, isApplet) {
Clazz.super(C$, this,1);
this.uiClassID = "RootPaneUI";
this.setName$S((I$[2] || (I$[2]=Clazz.load('sun.awt.AppContext'))).getAppContext().getThreadGroup().getName() + prefix + (++this.paneCount) + ".JRootPane" );
this.setGlassPane$java_awt_Component(this.createGlassPane());
this.setLayeredPane$javax_swing_JLayeredPane(this.createLayeredPane());
this.setContentPane$java_awt_Container(this.createContentPane());
this.setLayout$java_awt_LayoutManager(this.createRootLayout());
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'setDoubleBuffered$Z', function (aFlag) {
});

Clazz.newMethod$(C$, 'getWindowDecorationStyle', function () {
return this.windowDecorationStyle;
});

Clazz.newMethod$(C$, 'setWindowDecorationStyle$I', function (windowDecorationStyle) {
if (windowDecorationStyle < 0 || windowDecorationStyle > 8 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid decoration style"]);
}var oldWindowDecorationStyle = this.getWindowDecorationStyle();
this.windowDecorationStyle = windowDecorationStyle;
this.firePropertyChange$S$I$I("windowDecorationStyle", oldWindowDecorationStyle, windowDecorationStyle);
});

Clazz.newMethod$(C$, 'createLayeredPane', function () {
var p = Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.JLayeredPane'))));
p.setName$S(this.getName() + ".layeredPane");
return p;
});

Clazz.newMethod$(C$, 'createContentPane', function () {
var c = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JPanel'))));
c.setName$S(this.getName() + ".contentPane");
c.setLayout$java_awt_LayoutManager(((
(function(){var C$=Clazz.newClass$(P$, "JRootPane$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('java.awt.BorderLayout'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
if (constraints == null ) {
constraints = "Center";
}C$.superClazz.prototype.addLayoutComponent$java_awt_Component$O.apply(this, [comp, constraints]);
});
})()
), Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.BorderLayout'))), [this, null],P$.JRootPane$1)));
return c;
});

Clazz.newMethod$(C$, 'createGlassPane', function () {
var c = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JPanel'))));
c.setName$S(this.getName() + ".glassPane");
c.setVisible$Z(false);
c.setOpaque$Z(false);
return c;
});

Clazz.newMethod$(C$, 'createRootLayout', function () {
return Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.JRootPane').RootLayout))), [this, null]);
});

Clazz.newMethod$(C$, 'setJMenuBar$javax_swing_JMenuBar', function (menu) {
if (this.menuBar != null  && this.menuBar.getParent() === this.layeredPane  ) this.layeredPane.remove$java_awt_Component(this.menuBar);
this.menuBar = menu;
if (this.menuBar != null ) this.layeredPane.add$java_awt_Component$O(this.menuBar, (I$[3] || (I$[3]=Clazz.load('javax.swing.JLayeredPane'))).FRAME_CONTENT_LAYER);
});

Clazz.newMethod$(C$, 'setMenuBar$javax_swing_JMenuBar', function (menu) {
if (this.menuBar != null  && this.menuBar.getParent() === this.layeredPane  ) this.layeredPane.remove$java_awt_Component(this.menuBar);
this.menuBar = menu;
if (this.menuBar != null ) this.layeredPane.add$java_awt_Component$O(this.menuBar, (I$[3] || (I$[3]=Clazz.load('javax.swing.JLayeredPane'))).FRAME_CONTENT_LAYER);
});

Clazz.newMethod$(C$, 'getJMenuBar', function () {
return this.menuBar;
});

Clazz.newMethod$(C$, 'getMenuBar', function () {
return this.menuBar;
});

Clazz.newMethod$(C$, 'setContentPane$java_awt_Container', function (content) {
if (content == null ) throw Clazz.new(Clazz.load('java.awt.IllegalComponentStateException').c$$S,["contentPane cannot be set to null."]);
if (this.contentPane != null  && this.contentPane.getParent() === this.layeredPane  ) this.layeredPane.remove$java_awt_Component(this.contentPane);
this.contentPane = content;
content.isContentPane = true;
this.layeredPane.add$java_awt_Component$O(this.contentPane, (I$[3] || (I$[3]=Clazz.load('javax.swing.JLayeredPane'))).FRAME_CONTENT_LAYER);
});

Clazz.newMethod$(C$, 'getContentPane', function () {
return this.contentPane;
});

Clazz.newMethod$(C$, 'setLayeredPane$javax_swing_JLayeredPane', function (layered) {
if (layered == null ) throw Clazz.new(Clazz.load('java.awt.IllegalComponentStateException').c$$S,["layeredPane cannot be set to null."]);
if (this.layeredPane != null  && this.layeredPane.getParent() === this  ) this.remove$java_awt_Component(this.layeredPane);
this.layeredPane = layered;
this.add$java_awt_Component$I(this.layeredPane, -1);
});

Clazz.newMethod$(C$, 'getLayeredPane', function () {
return this.layeredPane;
});

Clazz.newMethod$(C$, 'setGlassPane$java_awt_Component', function (glass) {
if (glass == null ) {
throw Clazz.new(Clazz.load('java.lang.NullPointerException').c$$S,["glassPane cannot be set to null."]);
}var visible = false;
if (this.glassPane != null  && this.glassPane.getParent() === this  ) {
this.remove$java_awt_Component(this.glassPane);
visible = this.glassPane.isVisible();
}glass.setVisible$Z(visible);
this.glassPane = glass;
this.add$java_awt_Component$I(this.glassPane, 0);
if (visible) {
this.repaint();
}});

Clazz.newMethod$(C$, 'getGlassPane', function () {
return this.glassPane;
});

Clazz.newMethod$(C$, 'isValidateRoot', function () {
return true;
});

Clazz.newMethod$(C$, 'isOptimizedDrawingEnabled', function () {
return !this.glassPane.isVisible();
});

Clazz.newMethod$(C$, 'addNotify', function () {
C$.superClazz.prototype.addNotify.apply(this, []);
this.enableEvents$J(8);
});

Clazz.newMethod$(C$, 'removeNotify', function () {
C$.superClazz.prototype.removeNotify.apply(this, []);
});

Clazz.newMethod$(C$, 'setDefaultButton$javax_swing_JButton', function (defaultButton) {
var oldDefault = this.defaultButton;
if (oldDefault !== defaultButton ) {
this.defaultButton = defaultButton;
if (oldDefault != null ) {
oldDefault.repaint();
}if (defaultButton != null ) {
defaultButton.repaint();
}}this.firePropertyChange$S$O$O("defaultButton", oldDefault, defaultButton);
});

Clazz.newMethod$(C$, 'getDefaultButton', function () {
return this.defaultButton;
});

Clazz.newMethod$(C$, 'setUseTrueDoubleBuffering$Z', function (useTrueDoubleBuffering) {
this.useTrueDoubleBuffering = useTrueDoubleBuffering;
});

Clazz.newMethod$(C$, 'getUseTrueDoubleBuffering', function () {
return this.useTrueDoubleBuffering;
});

Clazz.newMethod$(C$, 'disableTrueDoubleBuffering', function () {
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
if (this.glassPane != null  && this.glassPane.getParent() === this   && this.getComponent$I(0) !== this.glassPane  ) {
this.add$java_awt_Component$I(this.glassPane, 0);
}return comp;
});

Clazz.newMethod$(C$, 'paramString', function () {
return C$.superClazz.prototype.paramString.apply(this, []);
});

Clazz.newMethod$(C$, 'setFrameViewer$swingjs_JSFrameViewer', function (v) {
this.layeredPane.setFrameViewer$swingjs_JSFrameViewer(v);
this.contentPane.setFrameViewer$swingjs_JSFrameViewer(v);
if (this.glassPane != null ) this.glassPane.setFrameViewer$swingjs_JSFrameViewer(v);
return C$.superClazz.prototype.setFrameViewer$swingjs_JSFrameViewer.apply(this, [v]);
});
;
(function(){var C$=Clazz.newClass$(P$.JRootPane, "DefaultAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.AbstractAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.owner = null;
this.root = null;
this.press = false;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JRootPane$Z', function (root, press) {
Clazz.super(C$, this,1);
this.root = root;
this.press = press;
}, 1);

Clazz.newMethod$(C$, 'setOwner$javax_swing_JButton', function (owner) {
this.owner = owner;
});

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.owner != null  && (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getRootPane$java_awt_Component(this.owner) === this.root  ) {
var model = this.owner.getModel();
if (this.press) {
model.setArmed$Z(true);
model.setPressed$Z(true);
} else {
model.setPressed$Z(false);
}}});

Clazz.newMethod$(C$, 'isEnabled', function () {
return this.owner.getModel().isEnabled();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JRootPane, "RootLayout", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'java.awt.LayoutManager2');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (parent) {
var rd;
var mbd;
var i = this.b$['javax.swing.JRootPane'].getInsets();
if (this.b$['javax.swing.JRootPane'].contentPane != null ) {
rd = this.b$['javax.swing.JRootPane'].contentPane.getPreferredSize();
} else {
rd = parent.getSize();
}if (this.b$['javax.swing.JRootPane'].menuBar != null  && this.b$['javax.swing.JRootPane'].menuBar.isVisible() ) {
mbd = this.b$['javax.swing.JRootPane'].menuBar.getPreferredSize();
} else {
mbd = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]);
}return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[Math.max(rd.width, mbd.width) + i.left + i.right , rd.height + mbd.height + i.top + i.bottom ]);
});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (parent) {
var rd;
var mbd;
var i = this.b$['javax.swing.JRootPane'].getInsets();
if (this.b$['javax.swing.JRootPane'].contentPane != null ) {
rd = this.b$['javax.swing.JRootPane'].contentPane.getMinimumSize();
} else {
rd = parent.getSize();
}if (this.b$['javax.swing.JRootPane'].menuBar != null  && this.b$['javax.swing.JRootPane'].menuBar.isVisible() ) {
mbd = this.b$['javax.swing.JRootPane'].menuBar.getMinimumSize();
} else {
mbd = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]);
}return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[Math.max(rd.width, mbd.width) + i.left + i.right , rd.height + mbd.height + i.top + i.bottom ]);
});

Clazz.newMethod$(C$, 'maximumLayoutSize$java_awt_Container', function (target) {
var rd;
var mbd;
var i = this.b$['javax.swing.JRootPane'].getInsets();
if (this.b$['javax.swing.JRootPane'].menuBar != null  && this.b$['javax.swing.JRootPane'].menuBar.isVisible() ) {
mbd = this.b$['javax.swing.JRootPane'].menuBar.getMaximumSize();
} else {
mbd = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]);
}if (this.b$['javax.swing.JRootPane'].contentPane != null ) {
rd = this.b$['javax.swing.JRootPane'].contentPane.getMaximumSize();
} else {
rd = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[2147483647, 2147483647 - i.top - i.bottom - mbd.height - 1 ]);
}return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[Math.min(rd.width, mbd.width) + i.left + i.right , rd.height + mbd.height + i.top + i.bottom ]);
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (parent) {
var b = parent.getBounds();
var i = this.b$['javax.swing.JRootPane'].getInsets();
var contentY = 0;
var w = b.width - i.right - i.left ;
var h = b.height - i.top - i.bottom ;
if (this.b$['javax.swing.JRootPane'].layeredPane != null ) {
this.b$['javax.swing.JRootPane'].layeredPane.setBounds$I$I$I$I(i.left, i.top, w, h);
}if (this.b$['javax.swing.JRootPane'].glassPane != null ) {
this.b$['javax.swing.JRootPane'].glassPane.setBounds$I$I$I$I(i.left, i.top, w, h);
}if (this.b$['javax.swing.JRootPane'].menuBar != null  && this.b$['javax.swing.JRootPane'].menuBar.isVisible() ) {
var mbd = this.b$['javax.swing.JRootPane'].menuBar.getPreferredSize();
this.b$['javax.swing.JRootPane'].menuBar.setBounds$I$I$I$I(0, 0, w, mbd.height);
contentY = contentY+(mbd.height);
}if (this.b$['javax.swing.JRootPane'].contentPane != null ) {
this.b$['javax.swing.JRootPane'].contentPane.setBounds$I$I$I$I(0, contentY, w, h - contentY);
}});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
});

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (comp, constraints) {
});

Clazz.newMethod$(C$, 'getLayoutAlignmentX$java_awt_Container', function (target) {
return 0.0;
});

Clazz.newMethod$(C$, 'getLayoutAlignmentY$java_awt_Container', function (target) {
return 0.0;
});

Clazz.newMethod$(C$, 'invalidateLayout$java_awt_Container', function (target) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:42
