(function(){var P$=Clazz.newPackage$("javax.print.attribute");
var C$=Clazz.newInterface$(P$, "AttributeSet");

})();
//Created 2017-10-14 13:31:29
