(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractListModel", null, null, 'javax.swing.ListModel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
}, 1);

Clazz.newMethod$(C$, 'addListDataListener$javax_swing_event_ListDataListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ListDataListener), l);
});

Clazz.newMethod$(C$, 'removeListDataListener$javax_swing_event_ListDataListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ListDataListener), l);
});

Clazz.newMethod$(C$, 'getListDataListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ListDataListener));
});

Clazz.newMethod$(C$, 'fireContentsChanged$O$I$I', function (source, index0, index1) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ListDataListener) ) {
if (e == null ) {
e = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ListDataEvent'))).c$$O$I$I$I,[source, 0, index0, index1]);
}(listeners[i + 1]).contentsChanged$javax_swing_event_ListDataEvent(e);
}}
});

Clazz.newMethod$(C$, 'fireIntervalAdded$O$I$I', function (source, index0, index1) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ListDataListener) ) {
if (e == null ) {
e = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ListDataEvent'))).c$$O$I$I$I,[source, 1, index0, index1]);
}(listeners[i + 1]).intervalAdded$javax_swing_event_ListDataEvent(e);
}}
});

Clazz.newMethod$(C$, 'fireIntervalRemoved$O$I$I', function (source, index0, index1) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ListDataListener) ) {
if (e == null ) {
e = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.ListDataEvent'))).c$$O$I$I$I,[source, 2, index0, index1]);
}(listeners[i + 1]).intervalRemoved$javax_swing_event_ListDataEvent(e);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:30
