(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "BorderFactory");
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.sharedRaisedBevel = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.border.BevelBorder'))).c$$I,[0]);
C$.sharedLoweredBevel = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.border.BevelBorder'))).c$$I,[1]);
C$.sharedEtchedBorder = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.border.EtchedBorder'))));
C$.emptyBorder = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.border.EmptyBorder'))).c$$I$I$I$I,[0, 0, 0, 0]);
C$.html5Border = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.border.EmptyBorder'))).c$$I$I$I$I,[0, 0, 0, 0]);
};

C$.sharedRaisedBevel = null;
C$.sharedLoweredBevel = null;
C$.sharedEtchedBorder = null;
C$.sharedRaisedEtchedBorder = null;
C$.emptyBorder = null;
C$.html5Border = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'createLineBorder$java_awt_Color', function (color) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.border.LineBorder'))).c$$java_awt_Color$I,[color, 1]);
}, 1);

Clazz.newMethod$(C$, 'createLineBorder$java_awt_Color$I', function (color, thickness) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.border.LineBorder'))).c$$java_awt_Color$I,[color, thickness]);
}, 1);

Clazz.newMethod$(C$, 'createRaisedBevelBorder', function () {
return C$.createSharedBevel$I(0);
}, 1);

Clazz.newMethod$(C$, 'createLoweredBevelBorder', function () {
return C$.createSharedBevel$I(1);
}, 1);

Clazz.newMethod$(C$, 'createBevelBorder$I', function (type) {
return C$.createSharedBevel$I(type);
}, 1);

Clazz.newMethod$(C$, 'createBevelBorder$I$java_awt_Color$java_awt_Color', function (type, highlight, shadow) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.border.BevelBorder'))).c$$I$java_awt_Color$java_awt_Color,[type, highlight, shadow]);
}, 1);

Clazz.newMethod$(C$, 'createBevelBorder$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (type, highlightOuter, highlightInner, shadowOuter, shadowInner) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.border.BevelBorder'))).c$$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[type, highlightOuter, highlightInner, shadowOuter, shadowInner]);
}, 1);

Clazz.newMethod$(C$, 'createSharedBevel$I', function (type) {
if (type == 0) {
return C$.sharedRaisedBevel;
} else if (type == 1) {
return C$.sharedLoweredBevel;
}return null;
}, 1);

Clazz.newMethod$(C$, 'createEtchedBorder', function () {
return C$.sharedEtchedBorder;
}, 1);

Clazz.newMethod$(C$, 'createEtchedBorder$java_awt_Color$java_awt_Color', function (highlight, shadow) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.border.EtchedBorder'))).c$$java_awt_Color$java_awt_Color,[highlight, shadow]);
}, 1);

Clazz.newMethod$(C$, 'createEtchedBorder$I', function (type) {
switch (type) {
case 0:
if (C$.sharedRaisedEtchedBorder == null ) {
C$.sharedRaisedEtchedBorder = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.border.EtchedBorder'))).c$$I,[0]);
}return C$.sharedRaisedEtchedBorder;
case 1:
return C$.sharedEtchedBorder;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["type must be one of EtchedBorder.RAISED or EtchedBorder.LOWERED"]);
}
}, 1);

Clazz.newMethod$(C$, 'createEtchedBorder$I$java_awt_Color$java_awt_Color', function (type, highlight, shadow) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.border.EtchedBorder'))).c$$I$java_awt_Color$java_awt_Color,[type, highlight, shadow]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$S', function (title) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$S,[title]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$javax_swing_border_Border', function (border) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$javax_swing_border_Border,[border]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$javax_swing_border_Border$S', function (border, title) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$javax_swing_border_Border$S,[border, title]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$javax_swing_border_Border$S$I$I', function (border, title, titleJustification, titlePosition) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$javax_swing_border_Border$S$I$I,[border, title, titleJustification, titlePosition]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$javax_swing_border_Border$S$I$I$java_awt_Font', function (border, title, titleJustification, titlePosition, titleFont) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$javax_swing_border_Border$S$I$I$java_awt_Font,[border, title, titleJustification, titlePosition, titleFont]);
}, 1);

Clazz.newMethod$(C$, 'createTitledBorder$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color', function (border, title, titleJustification, titlePosition, titleFont, titleColor) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.border.TitledBorder'))).c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color,[border, title, titleJustification, titlePosition, titleFont, titleColor]);
}, 1);

Clazz.newMethod$(C$, 'createEmptyBorder', function () {
return C$.emptyBorder;
}, 1);

Clazz.newMethod$(C$, 'createHTML5Border', function () {
return C$.html5Border;
}, 1);

Clazz.newMethod$(C$, 'createEmptyBorder$I$I$I$I', function (top, left, bottom, right) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.border.EmptyBorder'))).c$$I$I$I$I,[top, left, bottom, right]);
}, 1);

Clazz.newMethod$(C$, 'createCompoundBorder', function () {
return Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.border.CompoundBorder'))));
}, 1);

Clazz.newMethod$(C$, 'createCompoundBorder$javax_swing_border_Border$javax_swing_border_Border', function (outsideBorder, insideBorder) {
return Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.border.CompoundBorder'))).c$$javax_swing_border_Border$javax_swing_border_Border,[outsideBorder, insideBorder]);
}, 1);

Clazz.newMethod$(C$, 'createMatteBorder$I$I$I$I$java_awt_Color', function (top, left, bottom, right, color) {
return Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.border.MatteBorder'))).c$$I$I$I$I$java_awt_Color,[top, left, bottom, right, color]);
}, 1);

Clazz.newMethod$(C$, 'createMatteBorder$I$I$I$I$javax_swing_Icon', function (top, left, bottom, right, tileIcon) {
return Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.border.MatteBorder'))).c$$I$I$I$I$javax_swing_Icon,[top, left, bottom, right, tileIcon]);
}, 1);
})();
//Created 2017-10-14 13:31:31
