(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newClass$(P$, "EditorKit", null, null, 'Cloneable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'clone', function () {
var o;
try {
o = Clazz.clone(this);
} catch (cnse) {
if (Clazz.exceptionOf(cnse, CloneNotSupportedException)){
o = null;
} else {
throw cnse;
}
}
return o;
});

Clazz.newMethod$(C$, 'install$javax_swing_JEditorPane', function (c) {
});

Clazz.newMethod$(C$, 'deinstall$javax_swing_JEditorPane', function (c) {
});
})();
//Created 2017-10-14 13:32:02
