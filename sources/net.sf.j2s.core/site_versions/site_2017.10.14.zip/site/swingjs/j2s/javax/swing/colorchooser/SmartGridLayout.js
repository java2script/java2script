(function(){var P$=Clazz.newPackage$("javax.swing.colorchooser"),I$=[];
var C$=Clazz.newClass$(P$, "SmartGridLayout", null, null, 'java.awt.LayoutManager');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.rows = 2;
this.columns = 2;
this.xGap = 2;
this.yGap = 2;
this.componentCount = 0;
this.layoutGrid = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (numColumns, numRows) {
C$.$init$.apply(this);
this.rows = numRows;
this.columns = numColumns;
this.layoutGrid =  Clazz.newArray$(java.awt.Component, [numColumns, numRows]);
}, 1);

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (c) {
p$.buildLayoutGrid$java_awt_Container.apply(this, [c]);
var rowHeights =  Clazz.newArray$(Integer.TYPE, [this.rows]);
var columnWidths =  Clazz.newArray$(Integer.TYPE, [this.columns]);
for (var row = 0; row < this.rows; row++) {
rowHeights[row] = p$.computeRowHeight$I.apply(this, [row]);
}
for (var column = 0; column < this.columns; column++) {
columnWidths[column] = p$.computeColumnWidth$I.apply(this, [column]);
}
var insets = c.getInsets();
if (c.getComponentOrientation().isLeftToRight()) {
var horizLoc = insets.left;
for (var column = 0; column < this.columns; column++) {
var vertLoc = insets.top;
for (var row = 0; row < this.rows; row++) {
var current = this.layoutGrid[column][row];
current.setBounds$I$I$I$I(horizLoc, vertLoc, columnWidths[column], rowHeights[row]);
vertLoc = vertLoc+((rowHeights[row] + this.yGap));
}
horizLoc = horizLoc+((columnWidths[column] + this.xGap));
}
} else {
var horizLoc = c.getWidth() - insets.right;
for (var column = 0; column < this.columns; column++) {
var vertLoc = insets.top;
horizLoc = horizLoc-(columnWidths[column]);
for (var row = 0; row < this.rows; row++) {
var current = this.layoutGrid[column][row];
current.setBounds$I$I$I$I(horizLoc, vertLoc, columnWidths[column], rowHeights[row]);
vertLoc = vertLoc+((rowHeights[row] + this.yGap));
}
horizLoc = horizLoc-(this.xGap);
}
}});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (c) {
p$.buildLayoutGrid$java_awt_Container.apply(this, [c]);
var insets = c.getInsets();
var height = 0;
var width = 0;
for (var row = 0; row < this.rows; row++) {
height = height+(p$.computeRowHeight$I.apply(this, [row]));
}
for (var column = 0; column < this.columns; column++) {
width = width+(p$.computeColumnWidth$I.apply(this, [column]));
}
height = height+((this.yGap * (this.rows - 1)) + insets.top + insets.bottom );
width = width+((this.xGap * (this.columns - 1)) + insets.right + insets.left );
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, height]);
});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (c) {
return this.minimumLayoutSize$java_awt_Container(c);
});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (s, c) {
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
});

Clazz.newMethod$(C$, 'buildLayoutGrid$java_awt_Container', function (c) {
var children = c.getComponents();
for (var componentCount = 0; componentCount < children.length; componentCount++) {
var row = 0;
var column = 0;
if (componentCount != 0) {
column = componentCount % this.columns;
row = ($i$[0] = (componentCount - column)/this.columns, $i$[0]);
}this.layoutGrid[column][row] = children[componentCount];
}
});

Clazz.newMethod$(C$, 'computeColumnWidth$I', function (columnNum) {
var maxWidth = 1;
for (var row = 0; row < this.rows; row++) {
var width = this.layoutGrid[columnNum][row].getPreferredSize().width;
if (width > maxWidth) {
maxWidth = width;
}}
return maxWidth;
});

Clazz.newMethod$(C$, 'computeRowHeight$I', function (rowNum) {
var maxHeight = 1;
for (var column = 0; column < this.columns; column++) {
var height = this.layoutGrid[column][rowNum].getPreferredSize().height;
if (height > maxHeight) {
maxHeight = height;
}}
return maxHeight;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:53
