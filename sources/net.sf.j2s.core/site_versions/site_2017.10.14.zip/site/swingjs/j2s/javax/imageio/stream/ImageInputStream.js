(function(){var P$=Clazz.newPackage$("javax.imageio.stream");
var C$=Clazz.newInterface$(P$, "ImageInputStream");

})();
//Created 2017-10-14 13:31:28
