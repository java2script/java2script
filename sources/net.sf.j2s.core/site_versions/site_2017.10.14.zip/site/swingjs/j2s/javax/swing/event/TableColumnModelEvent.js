(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "TableColumnModelEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.fromIndex = 0;
this.toIndex = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_table_TableColumnModel$I$I', function (source, from, to) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.fromIndex = from;
this.toIndex = to;
}, 1);

Clazz.newMethod$(C$, 'getFromIndex', function () {
return this.fromIndex;
});

Clazz.newMethod$(C$, 'getToIndex', function () {
return this.toIndex;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
