(function(){var P$=Clazz.newPackage$("javax.swing.table");
var C$=Clazz.newClass$(P$, "TableStringConverter");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:00
