(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "IconUIResource", null, null, ['javax.swing.Icon', 'javax.swing.plaf.UIResource']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.delegate = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Icon', function (delegate) {
C$.$init$.apply(this);
if (delegate == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null delegate icon argument"]);
}this.delegate = delegate;
}, 1);

Clazz.newMethod$(C$, 'paintIcon$java_awt_Component$java_awt_Graphics$I$I', function (c, g, x, y) {
this.delegate.paintIcon$java_awt_Component$java_awt_Graphics$I$I(c, g, x, y);
});

Clazz.newMethod$(C$, 'getIconWidth', function () {
return this.delegate.getIconWidth();
});

Clazz.newMethod$(C$, 'getIconHeight', function () {
return this.delegate.getIconHeight();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:56
