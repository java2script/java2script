(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newInterface$(P$, "Scrollable");

})();
//Created 2017-10-14 13:31:49
