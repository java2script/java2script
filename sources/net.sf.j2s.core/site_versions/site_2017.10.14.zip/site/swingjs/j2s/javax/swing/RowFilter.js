(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "RowFilter", function(){
Clazz.newInstance$(this, arguments);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'checkIndices$IA', function (columns) {
for (var i = columns.length - 1; i >= 0; i--) {
if (columns[i] < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Index must be >= 0"]);
}}
}, 1);

Clazz.newMethod$(C$, 'regexFilter$S$IA', function (regex, indices) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.RowFilter').RegexFilter))).c$$java_util_regex_Pattern$IA,[(I$[2] || (I$[2]=Clazz.load('java.util.regex.Pattern'))).compile$S(regex), indices]);
}, 1);

Clazz.newMethod$(C$, 'dateFilter$javax_swing_RowFilter_ComparisonType$java_util_Date$IA', function (type, date, indices) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.RowFilter').DateFilter))).c$$javax_swing_RowFilter_ComparisonType$J$IA,[type, date.getTime(), indices]);
}, 1);

Clazz.newMethod$(C$, 'numberFilter$javax_swing_RowFilter_ComparisonType$Number$IA', function (type, number, indices) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.RowFilter').NumberFilter))).c$$javax_swing_RowFilter_ComparisonType$Number$IA,[type, number, indices]);
}, 1);

Clazz.newMethod$(C$, 'orFilter$Iterable', function (filters) {
return Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.RowFilter').OrFilter))).c$$Iterable,[filters]);
}, 1);

Clazz.newMethod$(C$, 'andFilter$Iterable', function (filters) {
return Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.RowFilter').AndFilter))).c$$Iterable,[filters]);
}, 1);

Clazz.newMethod$(C$, 'notFilter$javax_swing_RowFilter', function (filter) {
return Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.RowFilter').NotFilter))).c$$javax_swing_RowFilter,[filter]);
}, 1);
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "ComparisonType", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "BEFORE", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "AFTER", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "EQUAL", 2, []);
Clazz.newEnumConst$(vals, C$.c$, "NOT_EQUAL", 3, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "Entry", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getStringValue$I', function (index) {
var value = this.getValue$I(index);
return (value == null ) ? "" : value.toString();
});
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "GeneralFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.columns = null;
}, 1);

Clazz.newMethod$(C$, 'c$$IA', function (columns) {
Clazz.super(C$, this,1);
P$.RowFilter.checkIndices$IA(columns);
this.columns = columns;
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry', function (value) {
var count = value.getValueCount();
if (this.columns.length > 0) {
for (var i = this.columns.length - 1; i >= 0; i--) {
var index = this.columns[i];
if (index < count) {
if (this.include$javax_swing_RowFilter_Entry$I(value, index)) {
return true;
}}}
} else {
while (--count >= 0){
if (this.include$javax_swing_RowFilter_Entry$I(value, count)) {
return true;
}}
}return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "RegexFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter.GeneralFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.matcher = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_regex_Pattern$IA', function (regex, columns) {
C$.superClazz.c$$IA.apply(this, [columns]);
C$.$init$.apply(this);
if (regex == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Pattern must be non-null"]);
}this.matcher = regex.matcher$CharSequence("");
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry$I', function (value, index) {
this.matcher.reset$CharSequence(value.getStringValue$I(index));
return this.matcher.find();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "DateFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter.GeneralFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.date = 0;
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_RowFilter_ComparisonType$J$IA', function (type, date, columns) {
C$.superClazz.c$$IA.apply(this, [columns]);
C$.$init$.apply(this);
if (type == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["type must be non-null"]);
}this.type = type;
this.date = date;
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry$I', function (value, index) {
var v = value.getValue$I(index);
if (Clazz.instanceOf(v, "java.util.Date")) {
var vDate = (v).getTime();
switch (this.type) {
case P$.RowFilter.ComparisonType.BEFORE:
return (vDate < this.date);
case P$.RowFilter.ComparisonType.AFTER:
return (vDate > this.date);
case P$.RowFilter.ComparisonType.EQUAL:
return (vDate == this.date);
case P$.RowFilter.ComparisonType.NOT_EQUAL:
return (vDate != this.date);
default:
break;
}
}return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "NumberFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter.GeneralFilter');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.isComparable = false;
this.number = null;
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_RowFilter_ComparisonType$Number$IA', function (type, number, columns) {
C$.superClazz.c$$IA.apply(this, [columns]);
C$.$init$.apply(this);
if (type == null  || number == null  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["type and number must be non-null"]);
}this.type = type;
this.number = number;
this.isComparable = (Clazz.instanceOf(number, "java.lang.Comparable"));
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry$I', function (value, index) {
var v = value.getValue$I(index);
if (Clazz.instanceOf(v, "java.lang.Number")) {
var compareResult;
var vClass = v.getClass();
if (this.number.getClass() === vClass  && this.isComparable ) {
compareResult = (this.number).compareTo$TT(v);
} else {
compareResult = p$.longCompare$Number.apply(this, [v]);
}switch (this.type) {
case P$.RowFilter.ComparisonType.BEFORE:
return (compareResult > 0);
case P$.RowFilter.ComparisonType.AFTER:
return (compareResult < 0);
case P$.RowFilter.ComparisonType.EQUAL:
return (compareResult == 0);
case P$.RowFilter.ComparisonType.NOT_EQUAL:
return (compareResult != 0);
default:
break;
}
}return false;
});

Clazz.newMethod$(C$, 'longCompare$Number', function (o) {
var diff = this.number.longValue() - o.longValue();
if (diff < 0) {
return -1;
} else if (diff > 0) {
return 1;
}return 0;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "OrFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.filters = null;
}, 1);

Clazz.newMethod$(C$, 'c$$Iterable', function (filters) {
Clazz.super(C$, this,1);
this.filters = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.ArrayList'))));
for (var filter, $filter = filters.iterator (); $filter.hasNext () && ((filter = $filter.next ()) || true);) {
if (filter == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Filter must be non-null"]);
}this.filters.add$TE(filter);
}
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry', function (value) {
for (var filter, $filter = this.filters.iterator (); $filter.hasNext () && ((filter = $filter.next ()) || true);) {
if (filter.include$javax_swing_RowFilter_Entry(value)) {
return true;
}}
return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "AndFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter.OrFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$Iterable', function (filters) {
C$.superClazz.c$$Iterable.apply(this, [filters]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry', function (value) {
for (var filter, $filter = this.filters.iterator (); $filter.hasNext () && ((filter = $filter.next ()) || true);) {
if (!filter.include$javax_swing_RowFilter_Entry(value)) {
return false;
}}
return true;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.RowFilter, "NotFilter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.RowFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.filter = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_RowFilter', function (filter) {
Clazz.super(C$, this,1);
if (filter == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["filter must be non-null"]);
}this.filter = filter;
}, 1);

Clazz.newMethod$(C$, 'include$javax_swing_RowFilter_Entry', function (value) {
return !this.filter.include$javax_swing_RowFilter_Entry(value);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:49
