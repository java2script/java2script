(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newClass$(P$, "TreeSelectionEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.paths = null;
this.areNew = null;
this.oldLeadSelectionPath = null;
this.newLeadSelectionPath = null;
}, 1);

Clazz.newMethod$(C$, 'c$$O$javax_swing_tree_TreePathA$ZA$javax_swing_tree_TreePath$javax_swing_tree_TreePath', function (source, paths, areNew, oldLeadSelectionPath, newLeadSelectionPath) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.paths = paths;
this.areNew = areNew;
this.oldLeadSelectionPath = oldLeadSelectionPath;
this.newLeadSelectionPath = newLeadSelectionPath;
}, 1);

Clazz.newMethod$(C$, 'c$$O$javax_swing_tree_TreePath$Z$javax_swing_tree_TreePath$javax_swing_tree_TreePath', function (source, path, isNew, oldLeadSelectionPath, newLeadSelectionPath) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.paths =  Clazz.newArray$(javax.swing.tree.TreePath, [1]);
this.paths[0] = path;
this.areNew =  Clazz.newArray$(Boolean.TYPE, [1]);
this.areNew[0] = isNew;
this.oldLeadSelectionPath = oldLeadSelectionPath;
this.newLeadSelectionPath = newLeadSelectionPath;
}, 1);

Clazz.newMethod$(C$, 'getPaths', function () {
var numPaths;
var retPaths;
numPaths = this.paths.length;
retPaths =  Clazz.newArray$(javax.swing.tree.TreePath, [numPaths]);
System.arraycopy(this.paths, 0, retPaths, 0, numPaths);
return retPaths;
});

Clazz.newMethod$(C$, 'getPath', function () {
return this.paths[0];
});

Clazz.newMethod$(C$, 'isAddedPath', function () {
return this.areNew[0];
});

Clazz.newMethod$(C$, 'isAddedPath$javax_swing_tree_TreePath', function (path) {
for (var counter = this.paths.length - 1; counter >= 0; counter--) if (this.paths[counter].equals$O(path)) return this.areNew[counter];

throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["path is not a path identified by the TreeSelectionEvent"]);
});

Clazz.newMethod$(C$, 'isAddedPath$I', function (index) {
if (this.paths == null  || index < 0  || index >= this.paths.length ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index is beyond range of added paths identified by TreeSelectionEvent"]);
}return this.areNew[index];
});

Clazz.newMethod$(C$, 'getOldLeadSelectionPath', function () {
return this.oldLeadSelectionPath;
});

Clazz.newMethod$(C$, 'getNewLeadSelectionPath', function () {
return this.newLeadSelectionPath;
});

Clazz.newMethod$(C$, 'cloneWithSource$O', function (newSource) {
return Clazz.new(C$.c$$O$javax_swing_tree_TreePathA$ZA$javax_swing_tree_TreePath$javax_swing_tree_TreePath,[newSource, this.paths, this.areNew, this.oldLeadSelectionPath, this.newLeadSelectionPath]);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:55
