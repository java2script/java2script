(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultCellEditor", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.AbstractCellEditor', ['javax.swing.table.TableCellEditor', 'javax.swing.tree.TreeCellEditor']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.editorComponent = null;
this.delegate = null;
this.clickCountToStart = 1;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JTextField', function (textField) {
Clazz.super(C$, this,1);
this.editorComponent = textField;
this.clickCountToStart = 2;
this.delegate = ((
(function(){var C$=Clazz.newClass$(P$, "DefaultCellEditor$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load(Clazz.load('javax.swing.DefaultCellEditor').EditorDelegate));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
this.$finals.textField.setText$S((value != null ) ? value.toString() : "");
});

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return this.$finals.textField.getText();
});
})()
), Clazz.new((I$[0] || (I$[0]=Clazz.load(C$.EditorDelegate))), [this, {textField: textField}],P$.DefaultCellEditor$1));
textField.addActionListener$java_awt_event_ActionListener(this.delegate);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JCheckBox', function (checkBox) {
Clazz.super(C$, this,1);
this.editorComponent = checkBox;
this.delegate = ((
(function(){var C$=Clazz.newClass$(P$, "DefaultCellEditor$2", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load(Clazz.load('javax.swing.DefaultCellEditor').EditorDelegate));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
var selected = false;
if (Clazz.instanceOf(value, "java.lang.Boolean")) {
selected = (value).booleanValue();
} else if (Clazz.instanceOf(value, "java.lang.String")) {
selected = value.equals$O("true");
}this.$finals.checkBox.setSelected$Z(selected);
});

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return (I$[1] || (I$[1]=Clazz.load('Boolean'))).$valueOf(this.$finals.checkBox.isSelected());
});
})()
), Clazz.new((I$[0] || (I$[0]=Clazz.load(C$.EditorDelegate))), [this, {checkBox: checkBox}],P$.DefaultCellEditor$2));
checkBox.addActionListener$java_awt_event_ActionListener(this.delegate);
checkBox.setRequestFocusEnabled$Z(false);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComboBox', function (comboBox) {
Clazz.super(C$, this,1);
this.editorComponent = comboBox;
comboBox.putClientProperty$O$O("JComboBox.isTableCellEditor", Boolean.TRUE);
this.delegate = ((
(function(){var C$=Clazz.newClass$(P$, "DefaultCellEditor$3", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load(Clazz.load('javax.swing.DefaultCellEditor').EditorDelegate));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
this.$finals.comboBox.setSelectedItem$O(value);
});

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return this.$finals.comboBox.getSelectedItem();
});

Clazz.newMethod$(C$, 'shouldSelectCell$java_util_EventObject', function (anEvent) {
if (Clazz.instanceOf(anEvent, "java.awt.event.MouseEvent")) {
var e = anEvent;
return e.getID() != 506;
}return true;
});

Clazz.newMethod$(C$, 'stopCellEditing', function () {
if (this.$finals.comboBox.isEditable()) {
this.$finals.comboBox.actionPerformed$java_awt_event_ActionEvent(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S,[this.b$['javax.swing.DefaultCellEditor'], 0, ""]));
}return C$.superClazz.prototype.stopCellEditing.apply(this, []);
});
})()
), Clazz.new((I$[0] || (I$[0]=Clazz.load(C$.EditorDelegate))), [this, {comboBox: comboBox}],P$.DefaultCellEditor$3));
comboBox.addActionListener$java_awt_event_ActionListener(this.delegate);
}, 1);

Clazz.newMethod$(C$, 'getComponent', function () {
return this.editorComponent;
});

Clazz.newMethod$(C$, 'setClickCountToStart$I', function (count) {
this.clickCountToStart = count;
});

Clazz.newMethod$(C$, 'getClickCountToStart', function () {
return this.clickCountToStart;
});

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return this.delegate.getCellEditorValue();
});

Clazz.newMethod$(C$, 'isCellEditable$java_util_EventObject', function (anEvent) {
return this.delegate.isCellEditable$java_util_EventObject(anEvent);
});

Clazz.newMethod$(C$, 'shouldSelectCell$java_util_EventObject', function (anEvent) {
return this.delegate.shouldSelectCell$java_util_EventObject(anEvent);
});

Clazz.newMethod$(C$, 'stopCellEditing', function () {
return this.delegate.stopCellEditing();
});

Clazz.newMethod$(C$, 'cancelCellEditing', function () {
this.delegate.cancelCellEditing();
});

Clazz.newMethod$(C$, 'getTreeCellEditorComponent$javax_swing_JTree$O$Z$Z$Z$I', function (tree, value, isSelected, expanded, leaf, row) {
var stringValue = tree.convertValueToText$O$Z$Z$Z$I$Z(value, isSelected, expanded, leaf, row, false);
this.delegate.setValue$O(stringValue);
return this.editorComponent;
});

Clazz.newMethod$(C$, 'getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I', function (table, value, isSelected, row, column) {
this.delegate.setValue$O(value);
if (Clazz.instanceOf(this.editorComponent, "javax.swing.JCheckBox")) {
var renderer = table.getCellRenderer$I$I(row, column);
var c = renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(table, value, isSelected, true, row, column);
if (c != null ) {
this.editorComponent.setOpaque$Z(true);
this.editorComponent.setBackground$java_awt_Color(c.getBackground());
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
this.editorComponent.setBorder$javax_swing_border_Border((c).getBorder());
}} else {
this.editorComponent.setOpaque$Z(false);
}}return this.editorComponent;
});
;
(function(){var C$=Clazz.newClass$(P$.DefaultCellEditor, "EditorDelegate", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, ['java.awt.event.ActionListener', 'java.awt.event.ItemListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.value = null;
}, 1);

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return this.value;
});

Clazz.newMethod$(C$, 'setValue$O', function (value) {
this.value = value;
});

Clazz.newMethod$(C$, 'isCellEditable$java_util_EventObject', function (anEvent) {
if (Clazz.instanceOf(anEvent, "java.awt.event.MouseEvent")) {
return (anEvent).getClickCount() >= this.b$['javax.swing.DefaultCellEditor'].clickCountToStart;
}return true;
});

Clazz.newMethod$(C$, 'shouldSelectCell$java_util_EventObject', function (anEvent) {
return true;
});

Clazz.newMethod$(C$, 'startCellEditing$java_util_EventObject', function (anEvent) {
return true;
});

Clazz.newMethod$(C$, 'stopCellEditing', function () {
this.b$['javax.swing.DefaultCellEditor'].fireEditingStopped();
return true;
});

Clazz.newMethod$(C$, 'cancelCellEditing', function () {
this.b$['javax.swing.DefaultCellEditor'].fireEditingCanceled();
});

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['javax.swing.DefaultCellEditor'].stopCellEditing();
});

Clazz.newMethod$(C$, 'itemStateChanged$java_awt_event_ItemEvent', function (e) {
this.b$['javax.swing.DefaultCellEditor'].stopCellEditing();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:32
