(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "GroupLayout", function(){
Clazz.newInstance$(this, arguments);
}, null, 'java.awt.LayoutManager2');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.autocreatePadding = false;
this.autocreateContainerPadding = false;
this.horizontalGroup = null;
this.verticalGroup = null;
this.componentInfos = null;
this.host = null;
this.tmpParallelSet = null;
this.springsChanged = false;
this.isValid = false;
this.hasPreferredPaddingSprings = false;
this.layoutStyle = null;
this.honorsVisibility = false;
}, 1);

Clazz.newMethod$(C$, 'checkSize$I$I$I$Z', function (min, pref, max, isComponentSpring) {
C$.checkResizeType$I$Z(min, isComponentSpring);
if (!isComponentSpring && pref < 0 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Pref must be >= 0"]);
} else if (isComponentSpring) {
C$.checkResizeType$I$Z(pref, true);
}C$.checkResizeType$I$Z(max, isComponentSpring);
C$.checkLessThan$I$I(min, pref);
C$.checkLessThan$I$I(pref, max);
}, 1);

Clazz.newMethod$(C$, 'checkResizeType$I$Z', function (type, isComponentSpring) {
if (type < 0 && ((isComponentSpring && type != -1  && type != -2 ) || (!isComponentSpring && type != -2 ) ) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid size"]);
}}, 1);

Clazz.newMethod$(C$, 'checkLessThan$I$I', function (min, max) {
if (min >= 0 && max >= 0  && min > max ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Following is not met: min<=pref<=max"]);
}}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Container', function (host) {
C$.$init$.apply(this);
if (host == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Container must be non-null"]);
}this.honorsVisibility = true;
this.host = host;
this.setHorizontalGroup$javax_swing_GroupLayout_Group(this.createParallelGroup$javax_swing_GroupLayout_Alignment$Z((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).LEADING, true));
this.setVerticalGroup$javax_swing_GroupLayout_Group(this.createParallelGroup$javax_swing_GroupLayout_Alignment$Z((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).LEADING, true));
this.componentInfos = Clazz.new((I$[13] || (I$[13]=Clazz.load('java.util.HashMap'))));
this.tmpParallelSet = Clazz.new((I$[14] || (I$[14]=Clazz.load('java.util.HashSet'))));
}, 1);

Clazz.newMethod$(C$, 'setHonorsVisibility$Z', function (honorsVisibility) {
if (this.honorsVisibility != honorsVisibility ) {
this.honorsVisibility = honorsVisibility;
this.springsChanged = true;
this.isValid = false;
p$.invalidateHost.apply(this, []);
}});

Clazz.newMethod$(C$, 'getHonorsVisibility', function () {
return this.honorsVisibility;
});

Clazz.newMethod$(C$, 'setHonorsVisibility$java_awt_Component$Boolean', function (component, honorsVisibility) {
if (component == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Component must be non-null"]);
}p$.getComponentInfo$java_awt_Component.apply(this, [component]).setHonorsVisibility$Boolean(honorsVisibility);
this.springsChanged = true;
this.isValid = false;
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'setAutoCreateGaps$Z', function (autoCreatePadding) {
if (this.autocreatePadding != autoCreatePadding ) {
this.autocreatePadding = autoCreatePadding;
p$.invalidateHost.apply(this, []);
}});

Clazz.newMethod$(C$, 'getAutoCreateGaps', function () {
return this.autocreatePadding;
});

Clazz.newMethod$(C$, 'setAutoCreateContainerGaps$Z', function (autoCreateContainerPadding) {
if (this.autocreateContainerPadding != autoCreateContainerPadding ) {
this.autocreateContainerPadding = autoCreateContainerPadding;
this.horizontalGroup = p$.createTopLevelGroup$javax_swing_GroupLayout_Group.apply(this, [p$.getHorizontalGroup.apply(this, [])]);
this.verticalGroup = p$.createTopLevelGroup$javax_swing_GroupLayout_Group.apply(this, [p$.getVerticalGroup.apply(this, [])]);
p$.invalidateHost.apply(this, []);
}});

Clazz.newMethod$(C$, 'getAutoCreateContainerGaps', function () {
return this.autocreateContainerPadding;
});

Clazz.newMethod$(C$, 'setHorizontalGroup$javax_swing_GroupLayout_Group', function (group) {
if (group == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Group must be non-null"]);
}this.horizontalGroup = p$.createTopLevelGroup$javax_swing_GroupLayout_Group.apply(this, [group]);
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'getHorizontalGroup', function () {
var index = 0;
if (this.horizontalGroup.springs.size() > 1) {
index = 1;
}return this.horizontalGroup.springs.get$I(index);
});

Clazz.newMethod$(C$, 'setVerticalGroup$javax_swing_GroupLayout_Group', function (group) {
if (group == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Group must be non-null"]);
}this.verticalGroup = p$.createTopLevelGroup$javax_swing_GroupLayout_Group.apply(this, [group]);
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'getVerticalGroup', function () {
var index = 0;
if (this.verticalGroup.springs.size() > 1) {
index = 1;
}return this.verticalGroup.springs.get$I(index);
});

Clazz.newMethod$(C$, 'createTopLevelGroup$javax_swing_GroupLayout_Group', function (specifiedGroup) {
var group = this.createSequentialGroup();
if (this.getAutoCreateContainerGaps()) {
group.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ContainerAutoPreferredGapSpring))), [this, null]));
group.addGroup$javax_swing_GroupLayout_Group(specifiedGroup);
group.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ContainerAutoPreferredGapSpring))), [this, null]));
} else {
group.addGroup$javax_swing_GroupLayout_Group(specifiedGroup);
}return group;
});

Clazz.newMethod$(C$, 'createSequentialGroup', function () {
return Clazz.new((I$[15] || (I$[15]=Clazz.load(Clazz.load('javax.swing.GroupLayout').SequentialGroup))), [this, null]);
});

Clazz.newMethod$(C$, 'createParallelGroup', function () {
return this.createParallelGroup$javax_swing_GroupLayout_Alignment((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).LEADING);
});

Clazz.newMethod$(C$, 'createParallelGroup$javax_swing_GroupLayout_Alignment', function (alignment) {
return this.createParallelGroup$javax_swing_GroupLayout_Alignment$Z(alignment, true);
});

Clazz.newMethod$(C$, 'createParallelGroup$javax_swing_GroupLayout_Alignment$Z', function (alignment, resizable) {
if (alignment === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE ) {
return Clazz.new((I$[16] || (I$[16]=Clazz.load(Clazz.load('javax.swing.GroupLayout').BaselineGroup))).c$$Z, [this, null, resizable]);
}return Clazz.new((I$[17] || (I$[17]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ParallelGroup))).c$$javax_swing_GroupLayout_Alignment$Z, [this, null, alignment, resizable]);
});

Clazz.newMethod$(C$, 'createBaselineGroup$Z$Z', function (resizable, anchorBaselineToTop) {
return Clazz.new((I$[16] || (I$[16]=Clazz.load(Clazz.load('javax.swing.GroupLayout').BaselineGroup))).c$$Z$Z, [this, null, resizable, anchorBaselineToTop]);
});

Clazz.newMethod$(C$, 'linkSize$java_awt_ComponentA', function (components) {
this.linkSize$I$java_awt_ComponentA(0, components);
this.linkSize$I$java_awt_ComponentA(1, components);
});

Clazz.newMethod$(C$, 'linkSize$I$java_awt_ComponentA', function (axis, components) {
if (components == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Components must be non-null"]);
}for (var counter = components.length - 1; counter >= 0; counter--) {
var c = components[counter];
if (components[counter] == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Components must be non-null"]);
}p$.getComponentInfo$java_awt_Component.apply(this, [c]);
}
var glAxis;
if (axis == 0) {
glAxis = 0;
} else if (axis == 1) {
glAxis = 1;
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Axis must be one of SwingConstants.HORIZONTAL or SwingConstants.VERTICAL"]);
}var master = p$.getComponentInfo$java_awt_Component.apply(this, [components[components.length - 1]]).getLinkInfo$I(glAxis);
for (var counter = components.length - 2; counter >= 0; counter--) {
master.add$javax_swing_GroupLayout_ComponentInfo(p$.getComponentInfo$java_awt_Component.apply(this, [components[counter]]));
}
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'replace$java_awt_Component$java_awt_Component', function (existingComponent, newComponent) {
if (existingComponent == null  || newComponent == null  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Components must be non-null"]);
}if (this.springsChanged) {
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.horizontalGroup, 0]);
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.verticalGroup, 1]);
}var info = this.componentInfos.remove$O(existingComponent);
if (info == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Component must already exist"]);
}this.host.remove$java_awt_Component(existingComponent);
if (newComponent.getParent() !== this.host ) {
this.host.add$java_awt_Component(newComponent);
}info.setComponent$java_awt_Component(newComponent);
this.componentInfos.put$TK$TV(newComponent, info);
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'setLayoutStyle$javax_swing_LayoutStyle', function (layoutStyle) {
this.layoutStyle = layoutStyle;
p$.invalidateHost.apply(this, []);
});

Clazz.newMethod$(C$, 'getLayoutStyle', function () {
return this.layoutStyle;
});

Clazz.newMethod$(C$, 'getLayoutStyle0', function () {
var layoutStyle = this.getLayoutStyle();
if (layoutStyle == null ) {
layoutStyle = (I$[18] || (I$[18]=Clazz.load('javax.swing.LayoutStyle'))).getInstance();
}return layoutStyle;
});

Clazz.newMethod$(C$, 'invalidateHost', function () {
if (Clazz.instanceOf(this.host, "javax.swing.JComponent")) {
(this.host).revalidate();
} else {
this.host.invalidate();
}this.host.repaint();
});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, component) {
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (component) {
var info = this.componentInfos.remove$O(component);
if (info != null ) {
info.dispose();
this.springsChanged = true;
this.isValid = false;
}});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
p$.prepare$I.apply(this, [1]);
return p$.adjustSize$I$I.apply(this, [this.horizontalGroup.getPreferredSize$I(0), this.verticalGroup.getPreferredSize$I(1)]);
});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
p$.prepare$I.apply(this, [0]);
return p$.adjustSize$I$I.apply(this, [this.horizontalGroup.getMinimumSize$I(0), this.verticalGroup.getMinimumSize$I(1)]);
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (parent) {
p$.prepare$I.apply(this, [3]);
var insets = parent.getInsets();
var width = parent.getWidth() - insets.left - insets.right ;
var height = parent.getHeight() - insets.top - insets.bottom ;
var ltr = p$.isLeftToRight.apply(this, []);
if (this.getAutoCreateGaps() || this.getAutoCreateContainerGaps() || this.hasPreferredPaddingSprings  ) {
p$.calculateAutopadding$javax_swing_GroupLayout_Group$I$I$I$I.apply(this, [this.horizontalGroup, 0, 3, 0, width]);
p$.calculateAutopadding$javax_swing_GroupLayout_Group$I$I$I$I.apply(this, [this.verticalGroup, 1, 3, 0, height]);
}this.horizontalGroup.setSize$I$I$I(0, 0, width);
this.verticalGroup.setSize$I$I$I(1, 0, height);
for (var info, $info = this.componentInfos.values().iterator (); $info.hasNext () && ((info = $info.next ()) || true);) {
info.setBounds$java_awt_Insets$I$Z(insets, width, ltr);
}
});

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (component, constraints) {
});

Clazz.newMethod$(C$, 'maximumLayoutSize$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
p$.prepare$I.apply(this, [2]);
return p$.adjustSize$I$I.apply(this, [this.horizontalGroup.getMaximumSize$I(0), this.verticalGroup.getMaximumSize$I(1)]);
});

Clazz.newMethod$(C$, 'getLayoutAlignmentX$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
return 0.5;
});

Clazz.newMethod$(C$, 'getLayoutAlignmentY$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
return 0.5;
});

Clazz.newMethod$(C$, 'invalidateLayout$java_awt_Container', function (parent) {
p$.checkParent$java_awt_Container.apply(this, [parent]);
{
this.isValid = false;
}});

Clazz.newMethod$(C$, 'prepare$I', function (sizeType) {
var visChanged = false;
if (!this.isValid) {
this.isValid = true;
this.horizontalGroup.setSize$I$I$I(0, -2147483648, -2147483648);
this.verticalGroup.setSize$I$I$I(1, -2147483648, -2147483648);
for (var ci, $ci = this.componentInfos.values().iterator (); $ci.hasNext () && ((ci = $ci.next ()) || true);) {
if (ci.updateVisibility()) {
visChanged = true;
}ci.clearCachedSize();
}
}if (this.springsChanged) {
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.horizontalGroup, 0]);
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.verticalGroup, 1]);
}if (this.springsChanged || visChanged ) {
p$.checkComponents.apply(this, []);
this.horizontalGroup.removeAutopadding();
this.verticalGroup.removeAutopadding();
if (this.getAutoCreateGaps()) {
p$.insertAutopadding$Z.apply(this, [true]);
} else if (this.hasPreferredPaddingSprings || this.getAutoCreateContainerGaps() ) {
p$.insertAutopadding$Z.apply(this, [false]);
}this.springsChanged = false;
}if (sizeType != 3 && (this.getAutoCreateGaps() || this.getAutoCreateContainerGaps() || this.hasPreferredPaddingSprings  ) ) {
p$.calculateAutopadding$javax_swing_GroupLayout_Group$I$I$I$I.apply(this, [this.horizontalGroup, 0, sizeType, 0, 0]);
p$.calculateAutopadding$javax_swing_GroupLayout_Group$I$I$I$I.apply(this, [this.verticalGroup, 1, sizeType, 0, 0]);
}});

Clazz.newMethod$(C$, 'calculateAutopadding$javax_swing_GroupLayout_Group$I$I$I$I', function (group, axis, sizeType, origin, size) {
group.unsetAutopadding();
switch (sizeType) {
case 0:
size = group.getMinimumSize$I(axis);
break;
case 1:
size = group.getPreferredSize$I(axis);
break;
case 2:
size = group.getMaximumSize$I(axis);
break;
default:
break;
}
group.setSize$I$I$I(axis, origin, size);
group.calculateAutopadding$I(axis);
});

Clazz.newMethod$(C$, 'checkComponents', function () {
for (var info, $info = this.componentInfos.values().iterator (); $info.hasNext () && ((info = $info.next ()) || true);) {
if (info.horizontalSpring == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,[info.component + " is not attached to a horizontal group"]);
}if (info.verticalSpring == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,[info.component + " is not attached to a vertical group"]);
}}
});

Clazz.newMethod$(C$, 'registerComponents$javax_swing_GroupLayout_Group$I', function (group, axis) {
var springs = group.springs;
for (var counter = springs.size() - 1; counter >= 0; counter--) {
var spring = springs.get$I(counter);
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.ComponentSpring")) {
(spring).installIfNecessary$I(axis);
} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [spring, axis]);
}}
});

Clazz.newMethod$(C$, 'adjustSize$I$I', function (width, height) {
var insets = this.host.getInsets();
return Clazz.new((I$[19] || (I$[19]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width + insets.left + insets.right , height + insets.top + insets.bottom ]);
});

Clazz.newMethod$(C$, 'checkParent$java_awt_Container', function (parent) {
if (parent !== this.host ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["GroupLayout can only be used with one Container at a time"]);
}});

Clazz.newMethod$(C$, 'getComponentInfo$java_awt_Component', function (component) {
var info = this.componentInfos.get$O(component);
if (info == null ) {
info = Clazz.new((I$[20] || (I$[20]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ComponentInfo))).c$$java_awt_Component, [this, null, component]);
this.componentInfos.put$TK$TV(component, info);
if (component.getParent() !== this.host ) {
this.host.add$java_awt_Component(component);
}}return info;
});

Clazz.newMethod$(C$, 'insertAutopadding$Z', function (insert) {
this.horizontalGroup.insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z(0, Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), insert);
this.verticalGroup.insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z(1, Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]), insert);
});

Clazz.newMethod$(C$, 'areParallelSiblings$java_awt_Component$java_awt_Component$I', function (source, target, axis) {
var sourceInfo = p$.getComponentInfo$java_awt_Component.apply(this, [source]);
var targetInfo = p$.getComponentInfo$java_awt_Component.apply(this, [target]);
var sourceSpring;
var targetSpring;
if (axis == 0) {
sourceSpring = sourceInfo.horizontalSpring;
targetSpring = targetInfo.horizontalSpring;
} else {
sourceSpring = sourceInfo.verticalSpring;
targetSpring = targetInfo.verticalSpring;
}var sourcePath = this.tmpParallelSet;
sourcePath.clear();
var spring = sourceSpring.getParent();
while (spring != null ){
sourcePath.add$TE(spring);
spring = spring.getParent();
}
spring = targetSpring.getParent();
while (spring != null ){
if (sourcePath.contains$O(spring)) {
sourcePath.clear();
while (spring != null ){
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.ParallelGroup")) {
return true;
}spring = spring.getParent();
}
return false;
}spring = spring.getParent();
}
sourcePath.clear();
return false;
});

Clazz.newMethod$(C$, 'isLeftToRight', function () {
return this.host.getComponentOrientation().isLeftToRight();
});

Clazz.newMethod$(C$, 'toString', function () {
if (this.springsChanged) {
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.horizontalGroup, 0]);
p$.registerComponents$javax_swing_GroupLayout_Group$I.apply(this, [this.verticalGroup, 1]);
}var buffer = Clazz.new((I$[21] || (I$[21]=Clazz.load('java.lang.StringBuffer'))));
buffer.append$S("HORIZONTAL\u000a");
p$.createSpringDescription$StringBuffer$javax_swing_GroupLayout_Spring$S$I.apply(this, [buffer, this.horizontalGroup, "  ", 0]);
buffer.append$S("\u000aVERTICAL\u000a");
p$.createSpringDescription$StringBuffer$javax_swing_GroupLayout_Spring$S$I.apply(this, [buffer, this.verticalGroup, "  ", 1]);
return buffer.toString();
});

Clazz.newMethod$(C$, 'createSpringDescription$StringBuffer$javax_swing_GroupLayout_Spring$S$I', function (buffer, spring, indent, axis) {
var origin = "";
var padding = "";
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.ComponentSpring")) {
var cSpring = spring;
origin = Integer.toString(cSpring.getOrigin()) + " ";
var name = cSpring.getComponent().getName();
if (name != null ) {
origin = "name=" + name + ", " ;
}}if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
var paddingSpring = spring;
padding = ", userCreated=" + paddingSpring.getUserCreated() + ", matches=" + paddingSpring.getMatchDescription() ;
}buffer.append$S(indent + spring.getClass().getName() + " " + Integer.toHexString(spring.hashCode()) + " " + origin + ", size=" + spring.getSize() + ", alignment=" + spring.getAlignment() + " prefs=[" + spring.getMinimumSize$I(axis) + " " + spring.getPreferredSize$I(axis) + " " + spring.getMaximumSize$I(axis) + padding + "]\n" );
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
var springs = (spring).springs;
indent += "  ";
for (var counter = 0; counter < springs.size(); counter++) {
p$.createSpringDescription$StringBuffer$javax_swing_GroupLayout_Spring$S$I.apply(this, [buffer, springs.get$I(counter), indent, axis]);
}
}});
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "Alignment", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "LEADING", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "TRAILING", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "CENTER", 2, []);
Clazz.newEnumConst$(vals, C$.c$, "BASELINE", 3, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "Spring", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.size = 0;
this.min = 0;
this.max = 0;
this.pref = 0;
this.parent = null;
this.alignment = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
this.min = this.pref = this.max = -2147483648;
}, 1);

Clazz.newMethod$(C$, 'setParent$javax_swing_GroupLayout_Spring', function (parent) {
this.parent = parent;
});

Clazz.newMethod$(C$, 'getParent', function () {
return this.parent;
});

Clazz.newMethod$(C$, 'setAlignment$javax_swing_GroupLayout_Alignment', function (alignment) {
this.alignment = alignment;
});

Clazz.newMethod$(C$, 'getAlignment', function () {
return this.alignment;
});

Clazz.newMethod$(C$, 'getMinimumSize$I', function (axis) {
if (this.min == -2147483648) {
this.min = this.constrain$I(this.calculateMinimumSize$I(axis));
}return this.min;
});

Clazz.newMethod$(C$, 'getPreferredSize$I', function (axis) {
if (this.pref == -2147483648) {
this.pref = this.constrain$I(this.calculatePreferredSize$I(axis));
}return this.pref;
});

Clazz.newMethod$(C$, 'getMaximumSize$I', function (axis) {
if (this.max == -2147483648) {
this.max = this.constrain$I(this.calculateMaximumSize$I(axis));
}return this.max;
});

Clazz.newMethod$(C$, 'setSize$I$I$I', function (axis, origin, size) {
this.size = size;
if (size == -2147483648) {
this.unset();
}});

Clazz.newMethod$(C$, 'unset', function () {
this.size = this.min = this.pref = this.max = -2147483648;
});

Clazz.newMethod$(C$, 'getSize', function () {
return this.size;
});

Clazz.newMethod$(C$, 'constrain$I', function (value) {
return Math.min(value, 32767);
});

Clazz.newMethod$(C$, 'getBaseline', function () {
return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior', function () {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
});

Clazz.newMethod$(C$, 'isResizable$I', function (axis) {
var min = this.getMinimumSize$I(axis);
var pref = this.getPreferredSize$I(axis);
return (min != pref || pref != this.getMaximumSize$I(axis) );
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "Group", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Spring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.springs = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.springs = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))));
}, 1);

Clazz.newMethod$(C$, 'addGroup$javax_swing_GroupLayout_Group', function (group) {
return this.addSpring$javax_swing_GroupLayout_Spring(group);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component', function (component) {
return this.addComponent$java_awt_Component$I$I$I(component, -1, -1, -1);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component$I$I$I', function (component, min, pref, max) {
return this.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ComponentSpring))).c$$java_awt_Component$I$I$I, [this, null, component, min, pref, max]));
});

Clazz.newMethod$(C$, 'addGap$I', function (size) {
return this.addGap$I$I$I(size, size, size);
});

Clazz.newMethod$(C$, 'addGap$I$I$I', function (min, pref, max) {
return this.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.GroupLayout').GapSpring))).c$$I$I$I, [this, null, min, pref, max]));
});

Clazz.newMethod$(C$, 'getSpring$I', function (index) {
return this.springs.get$I(index);
});

Clazz.newMethod$(C$, 'indexOf$javax_swing_GroupLayout_Spring', function (spring) {
return this.springs.indexOf$O(spring);
});

Clazz.newMethod$(C$, 'addSpring$javax_swing_GroupLayout_Spring', function (spring) {
this.springs.add$TE(spring);
spring.setParent$javax_swing_GroupLayout_Spring(this);
if (!(Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) || !(spring).getUserCreated() ) {
this.b$['javax.swing.GroupLayout'].springsChanged = true;
}return this;
});

Clazz.newMethod$(C$, 'setSize$I$I$I', function (axis, origin, size) {
C$.superClazz.prototype.setSize$I$I$I.apply(this, [axis, origin, size]);
if (size == -2147483648) {
for (var counter = this.springs.size() - 1; counter >= 0; counter--) {
this.getSpring$I(counter).setSize$I$I$I(axis, origin, size);
}
} else {
this.setValidSize$I$I$I(axis, origin, size);
}});

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
return this.calculateSize$I$I(axis, 0);
});

Clazz.newMethod$(C$, 'calculatePreferredSize$I', function (axis) {
return this.calculateSize$I$I(axis, 1);
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
return this.calculateSize$I$I(axis, 2);
});

Clazz.newMethod$(C$, 'calculateSize$I$I', function (axis, type) {
var count = this.springs.size();
if (count == 0) {
return 0;
}if (count == 1) {
return this.getSpringSize$javax_swing_GroupLayout_Spring$I$I(this.getSpring$I(0), axis, type);
}var size = this.constrain$I(this.operator$I$I(this.getSpringSize$javax_swing_GroupLayout_Spring$I$I(this.getSpring$I(0), axis, type), this.getSpringSize$javax_swing_GroupLayout_Spring$I$I(this.getSpring$I(1), axis, type)));
for (var counter = 2; counter < count; counter++) {
size = this.constrain$I(this.operator$I$I(size, this.getSpringSize$javax_swing_GroupLayout_Spring$I$I(this.getSpring$I(counter), axis, type)));
}
return size;
});

Clazz.newMethod$(C$, 'getSpringSize$javax_swing_GroupLayout_Spring$I$I', function (spring, axis, type) {
switch (type) {
case 0:
return spring.getMinimumSize$I(axis);
case 1:
return spring.getPreferredSize$I(axis);
case 2:
return spring.getMaximumSize$I(axis);
}
return 0;
});

Clazz.newMethod$(C$, 'removeAutopadding', function () {
this.unset();
for (var counter = this.springs.size() - 1; counter >= 0; counter--) {
var spring = this.springs.get$I(counter);
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
if ((spring).getUserCreated()) {
(spring).reset();
} else {
this.springs.remove$I(counter);
}} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
(spring).removeAutopadding();
}}
});

Clazz.newMethod$(C$, 'unsetAutopadding', function () {
this.unset();
for (var counter = this.springs.size() - 1; counter >= 0; counter--) {
var spring = this.springs.get$I(counter);
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
(spring).unset();
} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
(spring).unsetAutopadding();
}}
});

Clazz.newMethod$(C$, 'calculateAutopadding$I', function (axis) {
for (var counter = this.springs.size() - 1; counter >= 0; counter--) {
var spring = this.springs.get$I(counter);
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
spring.unset();
(spring).calculatePadding$I(axis);
} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
(spring).calculateAutopadding$I(axis);
}}
this.unset();
});

Clazz.newMethod$(C$, 'willHaveZeroSize$Z', function (treatAutopaddingAsZeroSized) {
for (var i = this.springs.size() - 1; i >= 0; i--) {
var spring = this.springs.get$I(i);
if (!spring.willHaveZeroSize$Z(treatAutopaddingAsZeroSized)) {
return false;
}}
return true;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "SequentialGroup", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Group');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.baselineSpring = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'addGroup$javax_swing_GroupLayout_Group', function (group) {
return C$.superClazz.prototype.addGroup$javax_swing_GroupLayout_Group.apply(this, [group]);
});

Clazz.newMethod$(C$, 'addGroup$Z$javax_swing_GroupLayout_Group', function (useAsBaseline, group) {
C$.superClazz.prototype.addGroup$javax_swing_GroupLayout_Group.apply(this, [group]);
if (useAsBaseline) {
this.baselineSpring = group;
}return this;
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component', function (component) {
return C$.superClazz.prototype.addComponent$java_awt_Component.apply(this, [component]);
});

Clazz.newMethod$(C$, 'addComponent$Z$java_awt_Component', function (useAsBaseline, component) {
C$.superClazz.prototype.addComponent$java_awt_Component.apply(this, [component]);
if (useAsBaseline) {
this.baselineSpring = this.springs.get$I(this.springs.size() - 1);
}return this;
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component$I$I$I', function (component, min, pref, max) {
return C$.superClazz.prototype.addComponent$java_awt_Component$I$I$I.apply(this, [component, min, pref, max]);
});

Clazz.newMethod$(C$, 'addComponent$Z$java_awt_Component$I$I$I', function (useAsBaseline, component, min, pref, max) {
C$.superClazz.prototype.addComponent$java_awt_Component$I$I$I.apply(this, [component, min, pref, max]);
if (useAsBaseline) {
this.baselineSpring = this.springs.get$I(this.springs.size() - 1);
}return this;
});

Clazz.newMethod$(C$, 'addGap$I', function (size) {
return C$.superClazz.prototype.addGap$I.apply(this, [size]);
});

Clazz.newMethod$(C$, 'addGap$I$I$I', function (min, pref, max) {
return C$.superClazz.prototype.addGap$I$I$I.apply(this, [min, pref, max]);
});

Clazz.newMethod$(C$, 'addPreferredGap$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement', function (comp1, comp2, type) {
return this.addPreferredGap$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$I(comp1, comp2, type, -1, -2);
});

Clazz.newMethod$(C$, 'addPreferredGap$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$I', function (comp1, comp2, type, pref, max) {
if (type == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Type must be non-null"]);
}if (comp1 == null  || comp2 == null  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Components must be non-null"]);
}p$.checkPreferredGapValues$I$I.apply(this, [pref, max]);
return this.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.GroupLayout').PreferredGapSpring))).c$$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$I, [this, null, comp1, comp2, type, pref, max]));
});

Clazz.newMethod$(C$, 'addPreferredGap$javax_swing_LayoutStyle_ComponentPlacement', function (type) {
return this.addPreferredGap$javax_swing_LayoutStyle_ComponentPlacement$I$I(type, -1, -1);
});

Clazz.newMethod$(C$, 'addPreferredGap$javax_swing_LayoutStyle_ComponentPlacement$I$I', function (type, pref, max) {
if (type !== (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.LayoutStyle').ComponentPlacement))).RELATED  && type !== (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.LayoutStyle').ComponentPlacement))).UNRELATED  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Type must be one of LayoutStyle.ComponentPlacement.RELATED or LayoutStyle.ComponentPlacement.UNRELATED"]);
}p$.checkPreferredGapValues$I$I.apply(this, [pref, max]);
this.b$['javax.swing.GroupLayout'].hasPreferredPaddingSprings = true;
return this.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.GroupLayout').AutoPreferredGapSpring))).c$$javax_swing_LayoutStyle_ComponentPlacement$I$I, [this, null, type, pref, max]));
});

Clazz.newMethod$(C$, 'addContainerGap', function () {
return this.addContainerGap$I$I(-1, -1);
});

Clazz.newMethod$(C$, 'addContainerGap$I$I', function (pref, max) {
if ((pref < 0 && pref != -1 ) || (max < 0 && max != -1  && max != -2 ) || (pref >= 0 && max >= 0  && pref > max )  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Pref and max must be either DEFAULT_VALUE or >= 0 and pref <= max"]);
}this.b$['javax.swing.GroupLayout'].hasPreferredPaddingSprings = true;
return this.addSpring$javax_swing_GroupLayout_Spring(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ContainerAutoPreferredGapSpring))).c$$I$I, [this, null, pref, max]));
});

Clazz.newMethod$(C$, 'operator$I$I', function (a, b) {
return this.constrain$I(a) + this.constrain$I(b);
});

Clazz.newMethod$(C$, 'setValidSize$I$I$I', function (axis, origin, size) {
var pref = this.getPreferredSize$I(axis);
if (size == pref) {
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
var springPref = spring.getPreferredSize$I(axis);
spring.setSize$I$I$I(axis, origin, springPref);
origin = origin+(springPref);
}
} else if (this.springs.size() == 1) {
var spring = this.getSpring$I(0);
spring.setSize$I$I$I(axis, origin, Math.min(Math.max(size, spring.getMinimumSize$I(axis)), spring.getMaximumSize$I(axis)));
} else if (this.springs.size() > 1) {
p$.setValidSizeNotPreferred$I$I$I.apply(this, [axis, origin, size]);
}});

Clazz.newMethod$(C$, 'setValidSizeNotPreferred$I$I$I', function (axis, origin, size) {
var delta = size - this.getPreferredSize$I(axis);
var useMin = (delta < 0);
var springCount = this.springs.size();
if (useMin) {
delta = delta*(-1);
}var resizable = p$.buildResizableList$I$Z.apply(this, [axis, useMin]);
var resizableCount = resizable.size();
if (resizableCount > 0) {
var sDelta = ($i$[0] = delta/resizableCount, $i$[0]);
var slop = delta - sDelta * resizableCount;
var sizes =  Clazz.newArray$(Integer.TYPE, [springCount]);
var sign = useMin ? -1 : 1;
for (var counter = 0; counter < resizableCount; counter++) {
var springDelta = resizable.get$I(counter);
if ((counter + 1) == resizableCount) {
sDelta = sDelta+(slop);
}springDelta.delta = Math.min(sDelta, springDelta.delta);
delta = delta-(springDelta.delta);
if (springDelta.delta != sDelta && counter + 1 < resizableCount ) {
sDelta = ($i$[0] = delta/(resizableCount - counter - 1 ), $i$[0]);
slop = delta - sDelta * (resizableCount - counter - 1 );
}sizes[springDelta.index] = sign * springDelta.delta;
}
for (var counter = 0; counter < springCount; counter++) {
var spring = this.getSpring$I(counter);
var sSize = spring.getPreferredSize$I(axis) + sizes[counter];
spring.setSize$I$I$I(axis, origin, sSize);
origin = origin+(sSize);
}
} else {
for (var counter = 0; counter < springCount; counter++) {
var spring = this.getSpring$I(counter);
var sSize;
if (useMin) {
sSize = spring.getMinimumSize$I(axis);
} else {
sSize = spring.getMaximumSize$I(axis);
}spring.setSize$I$I$I(axis, origin, sSize);
origin = origin+(sSize);
}
}});

Clazz.newMethod$(C$, 'buildResizableList$I$Z', function (axis, useMin) {
var size = this.springs.size();
var sorted = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[size]);
for (var counter = 0; counter < size; counter++) {
var spring = this.getSpring$I(counter);
var sDelta;
if (useMin) {
sDelta = spring.getPreferredSize$I(axis) - spring.getMinimumSize$I(axis);
} else {
sDelta = spring.getMaximumSize$I(axis) - spring.getPreferredSize$I(axis);
}if (sDelta > 0) {
sorted.add$TE(Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.GroupLayout').SpringDelta))).c$$I$I,[counter, sDelta]));
}}
(I$[9] || (I$[9]=Clazz.load('java.util.Collections'))).sort$java_util_List(sorted);
return sorted;
});

Clazz.newMethod$(C$, 'indexOfNextNonZeroSpring$I$Z', function (index, treatAutopaddingAsZeroSized) {
while (index < this.springs.size()){
var spring = this.springs.get$I(index);
if (!spring.willHaveZeroSize$Z(treatAutopaddingAsZeroSized)) {
return index;
}index++;
}
return index;
});

Clazz.newMethod$(C$, 'insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z', function (axis, leadingPadding, trailingPadding, leading, trailing, insert) {
var newLeadingPadding = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[leadingPadding]);
var newTrailingPadding = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]);
var newLeading = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[leading]);
var newTrailing = null;
var counter = 0;
while (counter < this.springs.size()){
var spring = this.getSpring$I(counter);
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
if (newLeadingPadding.size() == 0) {
var padding = spring;
padding.setSources$java_util_List(newLeading);
newLeading.clear();
counter = p$.indexOfNextNonZeroSpring$I$Z.apply(this, [counter + 1, true]);
if (counter == this.springs.size()) {
if (!(Clazz.instanceOf(padding, "javax.swing.GroupLayout.ContainerAutoPreferredGapSpring"))) {
trailingPadding.add$TE(padding);
}} else {
newLeadingPadding.clear();
newLeadingPadding.add$TE(padding);
}} else {
counter = p$.indexOfNextNonZeroSpring$I$Z.apply(this, [counter + 1, true]);
}} else {
if (newLeading.size() > 0 && insert ) {
var padding = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.GroupLayout').AutoPreferredGapSpring))), [this, null]);
this.springs.add$I$TE(counter, padding);
continue;
}if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.ComponentSpring")) {
var cSpring = spring;
if (!cSpring.isVisible()) {
counter++;
continue;
}for (var gapSpring, $gapSpring = newLeadingPadding.iterator (); $gapSpring.hasNext () && ((gapSpring = $gapSpring.next ()) || true);) {
gapSpring.addTarget$javax_swing_GroupLayout_ComponentSpring$I(cSpring, axis);
}
newLeading.clear();
newLeadingPadding.clear();
counter = p$.indexOfNextNonZeroSpring$I$Z.apply(this, [counter + 1, false]);
if (counter == this.springs.size()) {
trailing.add$TE(cSpring);
} else {
newLeading.add$TE(cSpring);
}} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
if (newTrailing == null ) {
newTrailing = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]);
} else {
newTrailing.clear();
}newTrailingPadding.clear();
(spring).insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z(axis, newLeadingPadding, newTrailingPadding, newLeading, newTrailing, insert);
newLeading.clear();
newLeadingPadding.clear();
counter = p$.indexOfNextNonZeroSpring$I$Z.apply(this, [counter + 1, (newTrailing.size() == 0)]);
if (counter == this.springs.size()) {
trailing.addAll$java_util_Collection(newTrailing);
trailingPadding.addAll$java_util_Collection(newTrailingPadding);
} else {
newLeading.addAll$java_util_Collection(newTrailing);
newLeadingPadding.addAll$java_util_Collection(newTrailingPadding);
}} else {
newLeadingPadding.clear();
newLeading.clear();
counter++;
}}}
});

Clazz.newMethod$(C$, 'getBaseline', function () {
if (this.baselineSpring != null ) {
var baseline = this.baselineSpring.getBaseline();
if (baseline >= 0) {
var size = 0;
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
if (spring === this.baselineSpring ) {
return size + baseline;
} else {
size = size+(spring.getPreferredSize$I(1));
}}
}}return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior', function () {
if (this.isResizable$I(1)) {
if (!this.baselineSpring.isResizable$I(1)) {
var leadingResizable = false;
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
if (spring === this.baselineSpring ) {
break;
} else if (spring.isResizable$I(1)) {
leadingResizable = true;
break;
}}
var trailingResizable = false;
for (var i = this.springs.size() - 1; i >= 0; i--) {
var spring = this.springs.get$I(i);
if (spring === this.baselineSpring ) {
break;
}if (spring.isResizable$I(1)) {
trailingResizable = true;
break;
}}
if (leadingResizable && !trailingResizable ) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT;
} else if (!leadingResizable && trailingResizable ) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
}} else {
var brb = this.baselineSpring.getBaselineResizeBehavior();
if (brb === (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT ) {
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
if (spring === this.baselineSpring ) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
}if (spring.isResizable$I(1)) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
}}
} else if (brb === (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT ) {
for (var i = this.springs.size() - 1; i >= 0; i--) {
var spring = this.springs.get$I(i);
if (spring === this.baselineSpring ) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT;
}if (spring.isResizable$I(1)) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
}}
}}return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
}return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
});

Clazz.newMethod$(C$, 'checkPreferredGapValues$I$I', function (pref, max) {
if ((pref < 0 && pref != -1  && pref != -2 ) || (max < 0 && max != -1  && max != -2 ) || (pref >= 0 && max >= 0  && pref > max )  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Pref and max must be either DEFAULT_SIZE, PREFERRED_SIZE, or >= 0 and pref <= max"]);
}});
var $i$ = new Int32Array(1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "SpringDelta", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'Comparable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.index = 0;
this.delta = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (index, delta) {
C$.$init$.apply(this);
this.index = index;
this.delta = delta;
}, 1);

Clazz.newMethod$(C$, 'compareTo$javax_swing_GroupLayout_SpringDelta', function (o) {
return this.delta - o.delta;
});

Clazz.newMethod$(C$, 'toString', function () {
return C$.superClazz.prototype.toString.apply(this, []) + "[index=" + this.index + ", delta=" + this.delta + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "ParallelGroup", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Group');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.childAlignment = null;
this.resizable = false;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_GroupLayout_Alignment$Z', function (childAlignment, resizable) {
Clazz.super(C$, this,1);
this.childAlignment = childAlignment;
this.resizable = resizable;
}, 1);

Clazz.newMethod$(C$, 'addGroup$javax_swing_GroupLayout_Group', function (group) {
return C$.superClazz.prototype.addGroup$javax_swing_GroupLayout_Group.apply(this, [group]);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component', function (component) {
return C$.superClazz.prototype.addComponent$java_awt_Component.apply(this, [component]);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component$I$I$I', function (component, min, pref, max) {
return C$.superClazz.prototype.addComponent$java_awt_Component$I$I$I.apply(this, [component, min, pref, max]);
});

Clazz.newMethod$(C$, 'addGap$I', function (pref) {
return C$.superClazz.prototype.addGap$I.apply(this, [pref]);
});

Clazz.newMethod$(C$, 'addGap$I$I$I', function (min, pref, max) {
return C$.superClazz.prototype.addGap$I$I$I.apply(this, [min, pref, max]);
});

Clazz.newMethod$(C$, 'addGroup$javax_swing_GroupLayout_Alignment$javax_swing_GroupLayout_Group', function (alignment, group) {
p$.checkChildAlignment$javax_swing_GroupLayout_Alignment.apply(this, [alignment]);
group.setAlignment$javax_swing_GroupLayout_Alignment(alignment);
return this.addSpring$javax_swing_GroupLayout_Spring(group);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component$javax_swing_GroupLayout_Alignment', function (component, alignment) {
return this.addComponent$java_awt_Component$javax_swing_GroupLayout_Alignment$I$I$I(component, alignment, -1, -1, -1);
});

Clazz.newMethod$(C$, 'addComponent$java_awt_Component$javax_swing_GroupLayout_Alignment$I$I$I', function (component, alignment, min, pref, max) {
p$.checkChildAlignment$javax_swing_GroupLayout_Alignment.apply(this, [alignment]);
var spring = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.GroupLayout').ComponentSpring))).c$$java_awt_Component$I$I$I, [this, null, component, min, pref, max]);
spring.setAlignment$javax_swing_GroupLayout_Alignment(alignment);
return this.addSpring$javax_swing_GroupLayout_Spring(spring);
});

Clazz.newMethod$(C$, 'isResizable', function () {
return this.resizable;
});

Clazz.newMethod$(C$, 'operator$I$I', function (a, b) {
return Math.max(a, b);
});

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
if (!this.isResizable()) {
return this.getPreferredSize$I(axis);
}return C$.superClazz.prototype.calculateMinimumSize$I.apply(this, [axis]);
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
if (!this.isResizable()) {
return this.getPreferredSize$I(axis);
}return C$.superClazz.prototype.calculateMaximumSize$I.apply(this, [axis]);
});

Clazz.newMethod$(C$, 'setValidSize$I$I$I', function (axis, origin, size) {
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
this.setChildSize$javax_swing_GroupLayout_Spring$I$I$I(spring, axis, origin, size);
}
});

Clazz.newMethod$(C$, 'setChildSize$javax_swing_GroupLayout_Spring$I$I$I', function (spring, axis, origin, size) {
var alignment = spring.getAlignment();
var springSize = Math.min(Math.max(spring.getMinimumSize$I(axis), size), spring.getMaximumSize$I(axis));
if (alignment == null ) {
alignment = this.childAlignment;
}switch (alignment) {
case P$.GroupLayout.Alignment.TRAILING:
spring.setSize$I$I$I(axis, origin + size - springSize, springSize);
break;
case P$.GroupLayout.Alignment.CENTER:
spring.setSize$I$I$I(axis, origin + ($i$[0] = (size - springSize)/2, $i$[0]), springSize);
break;
default:
spring.setSize$I$I$I(axis, origin, springSize);
break;
}
});

Clazz.newMethod$(C$, 'insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z', function (axis, leadingPadding, trailingPadding, leading, trailing, insert) {
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.ComponentSpring")) {
if ((spring).isVisible()) {
for (var gapSpring, $gapSpring = leadingPadding.iterator (); $gapSpring.hasNext () && ((gapSpring = $gapSpring.next ()) || true);) {
gapSpring.addTarget$javax_swing_GroupLayout_ComponentSpring$I(spring, axis);
}
trailing.add$TE(spring);
}} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.Group")) {
(spring).insertAutopadding$I$java_util_List$java_util_List$java_util_List$java_util_List$Z(axis, leadingPadding, trailingPadding, leading, trailing, insert);
} else if (Clazz.instanceOf(spring, "javax.swing.GroupLayout.AutoPreferredGapSpring")) {
(spring).setSources$java_util_List(leading);
trailingPadding.add$TE(spring);
}}
});

Clazz.newMethod$(C$, 'checkChildAlignment$javax_swing_GroupLayout_Alignment', function (alignment) {
p$.checkChildAlignment$javax_swing_GroupLayout_Alignment$Z.apply(this, [alignment, (Clazz.instanceOf(this, "javax.swing.GroupLayout.BaselineGroup"))]);
});

Clazz.newMethod$(C$, 'checkChildAlignment$javax_swing_GroupLayout_Alignment$Z', function (alignment, allowsBaseline) {
if (alignment == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Alignment must be non-null"]);
}if (!allowsBaseline && alignment === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Alignment must be one of:LEADING, TRAILING or CENTER"]);
}});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "BaselineGroup", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.ParallelGroup');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.allSpringsHaveBaseline = false;
this.prefAscent = 0;
this.prefDescent = 0;
this.baselineAnchorSet = false;
this.baselineAnchoredToTop = false;
this.calcedBaseline = false;
}, 1);

Clazz.newMethod$(C$, 'c$$Z', function (resizable) {
C$.superClazz.c$$javax_swing_GroupLayout_Alignment$Z.apply(this, [(I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).LEADING, resizable]);
C$.$init$.apply(this);
this.prefAscent = this.prefDescent = -1;
this.calcedBaseline = false;
}, 1);

Clazz.newMethod$(C$, 'c$$Z$Z', function (resizable, baselineAnchoredToTop) {
C$.c$$Z.apply(this, [resizable]);
this.baselineAnchoredToTop = baselineAnchoredToTop;
this.baselineAnchorSet = true;
}, 1);

Clazz.newMethod$(C$, 'unset', function () {
C$.superClazz.prototype.unset.apply(this, []);
this.prefAscent = this.prefDescent = -1;
this.calcedBaseline = false;
});

Clazz.newMethod$(C$, 'setValidSize$I$I$I', function (axis, origin, size) {
p$.checkAxis$I.apply(this, [axis]);
if (this.prefAscent == -1) {
C$.superClazz.prototype.setValidSize$I$I$I.apply(this, [axis, origin, size]);
} else {
p$.baselineLayout$I$I.apply(this, [origin, size]);
}});

Clazz.newMethod$(C$, 'calculateSize$I$I', function (axis, type) {
p$.checkAxis$I.apply(this, [axis]);
if (!this.calcedBaseline) {
p$.calculateBaselineAndResizeBehavior.apply(this, []);
}if (type == 0) {
return p$.calculateMinSize.apply(this, []);
}if (type == 2) {
return p$.calculateMaxSize.apply(this, []);
}if (this.allSpringsHaveBaseline) {
return this.prefAscent + this.prefDescent;
}return Math.max(this.prefAscent + this.prefDescent, C$.superClazz.prototype.calculateSize$I$I.apply(this, [axis, type]));
});

Clazz.newMethod$(C$, 'calculateBaselineAndResizeBehavior', function () {
this.prefAscent = 0;
this.prefDescent = 0;
var baselineSpringCount = 0;
var resizeBehavior = null;
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
if (spring.getAlignment() == null  || spring.getAlignment() === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE  ) {
var baseline = spring.getBaseline();
if (baseline >= 0) {
if (spring.isResizable$I(1)) {
var brb = spring.getBaselineResizeBehavior();
if (resizeBehavior == null ) {
resizeBehavior = brb;
} else if (brb !== resizeBehavior ) {
resizeBehavior = (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
}}this.prefAscent = Math.max(this.prefAscent, baseline);
this.prefDescent = Math.max(this.prefDescent, spring.getPreferredSize$I(1) - baseline);
baselineSpringCount++;
}}}
if (!this.baselineAnchorSet) {
if (resizeBehavior === (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT ) {
this.baselineAnchoredToTop = false;
} else {
this.baselineAnchoredToTop = true;
}}this.allSpringsHaveBaseline = (baselineSpringCount == this.springs.size());
this.calcedBaseline = true;
});

Clazz.newMethod$(C$, 'calculateMaxSize', function () {
var maxAscent = this.prefAscent;
var maxDescent = this.prefDescent;
var nonBaselineMax = 0;
for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
var baseline;
var springMax = spring.getMaximumSize$I(1);
if ((spring.getAlignment() == null  || spring.getAlignment() === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE  ) && (baseline = spring.getBaseline()) >= 0 ) {
var springPref = spring.getPreferredSize$I(1);
if (springPref != springMax) {
switch (spring.getBaselineResizeBehavior()) {
case java.awt.Component.BaselineResizeBehavior.CONSTANT_ASCENT:
if (this.baselineAnchoredToTop) {
maxDescent = Math.max(maxDescent, springMax - baseline);
}break;
case java.awt.Component.BaselineResizeBehavior.CONSTANT_DESCENT:
if (!this.baselineAnchoredToTop) {
maxAscent = Math.max(maxAscent, springMax - springPref + baseline);
}break;
default:
break;
}
}} else {
nonBaselineMax = Math.max(nonBaselineMax, springMax);
}}
return Math.max(nonBaselineMax, maxAscent + maxDescent);
});

Clazz.newMethod$(C$, 'calculateMinSize', function () {
var minAscent = 0;
var minDescent = 0;
var nonBaselineMin = 0;
if (this.baselineAnchoredToTop) {
minAscent = this.prefAscent;
} else {
minDescent = this.prefDescent;
}for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
var springMin = spring.getMinimumSize$I(1);
var baseline;
if ((spring.getAlignment() == null  || spring.getAlignment() === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE  ) && (baseline = spring.getBaseline()) >= 0 ) {
var springPref = spring.getPreferredSize$I(1);
var brb = spring.getBaselineResizeBehavior();
switch (brb) {
case java.awt.Component.BaselineResizeBehavior.CONSTANT_ASCENT:
if (this.baselineAnchoredToTop) {
minDescent = Math.max(springMin - baseline, minDescent);
} else {
minAscent = Math.max(baseline, minAscent);
}break;
case java.awt.Component.BaselineResizeBehavior.CONSTANT_DESCENT:
if (!this.baselineAnchoredToTop) {
minAscent = Math.max(baseline - (springPref - springMin), minAscent);
} else {
minDescent = Math.max(springPref - baseline, minDescent);
}break;
default:
minAscent = Math.max(baseline, minAscent);
minDescent = Math.max(springPref - baseline, minDescent);
break;
}
} else {
nonBaselineMin = Math.max(nonBaselineMin, springMin);
}}
return Math.max(nonBaselineMin, minAscent + minDescent);
});

Clazz.newMethod$(C$, 'baselineLayout$I$I', function (origin, size) {
var ascent;
var descent;
if (this.baselineAnchoredToTop) {
ascent = this.prefAscent;
descent = size - ascent;
} else {
ascent = size - this.prefDescent;
descent = this.prefDescent;
}for (var spring, $spring = this.springs.iterator (); $spring.hasNext () && ((spring = $spring.next ()) || true);) {
var alignment = spring.getAlignment();
if (alignment == null  || alignment === (I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.GroupLayout').Alignment))).BASELINE  ) {
var baseline = spring.getBaseline();
if (baseline >= 0) {
var springMax = spring.getMaximumSize$I(1);
var springPref = spring.getPreferredSize$I(1);
var height = springPref;
var y;
switch (spring.getBaselineResizeBehavior()) {
case java.awt.Component.BaselineResizeBehavior.CONSTANT_ASCENT:
y = origin + ascent - baseline;
height = Math.min(descent, springMax - baseline) + baseline;
break;
case java.awt.Component.BaselineResizeBehavior.CONSTANT_DESCENT:
height = Math.min(ascent, springMax - springPref + baseline) + (springPref - baseline);
y = origin + ascent + (springPref - baseline)  - height;
break;
default:
y = origin + ascent - baseline;
break;
}
spring.setSize$I$I$I(1, y, height);
} else {
this.setChildSize$javax_swing_GroupLayout_Spring$I$I$I(spring, 1, origin, size);
}} else {
this.setChildSize$javax_swing_GroupLayout_Spring$I$I$I(spring, 1, origin, size);
}}
});

Clazz.newMethod$(C$, 'getBaseline', function () {
if (this.springs.size() > 1) {
this.getPreferredSize$I(1);
return this.prefAscent;
} else if (this.springs.size() == 1) {
return this.springs.get$I(0).getBaseline();
}return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior', function () {
if (this.springs.size() == 1) {
return this.springs.get$I(0).getBaselineResizeBehavior();
}if (this.baselineAnchoredToTop) {
return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
}return (I$[0] || (I$[0]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT;
});

Clazz.newMethod$(C$, 'checkAxis$I', function (axis) {
if (axis == 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalStateException').c$$S,["Baseline must be used along vertical axis"]);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "ComponentSpring", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Spring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.component = null;
this.origin = 0;
this.$min = 0;
this.$pref = 0;
this.$max = 0;
this.baseline = -1;
this.installed = false;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$I$I$I', function (component, min, pref, max) {
Clazz.super(C$, this,1);
this.component = component;
if (component == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Component must be non-null"]);
}P$.GroupLayout.checkSize$I$I$I$Z(min, pref, max, true);
this.$min = min;
this.$max = max;
this.$pref = pref;
this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [component]);
}, 1);

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
if (p$.isLinked$I.apply(this, [axis])) {
return p$.getLinkSize$I$I.apply(this, [axis, 0]);
}return this.calculateNonlinkedMinimumSize$I(axis);
});

Clazz.newMethod$(C$, 'calculatePreferredSize$I', function (axis) {
if (p$.isLinked$I.apply(this, [axis])) {
return p$.getLinkSize$I$I.apply(this, [axis, 1]);
}var min = this.getMinimumSize$I(axis);
var pref = this.calculateNonlinkedPreferredSize$I(axis);
var max = this.getMaximumSize$I(axis);
return Math.min(max, Math.max(min, pref));
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
if (p$.isLinked$I.apply(this, [axis])) {
return p$.getLinkSize$I$I.apply(this, [axis, 2]);
}return Math.max(this.getMinimumSize$I(axis), this.calculateNonlinkedMaximumSize$I(axis));
});

Clazz.newMethod$(C$, 'isVisible', function () {
return this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.getComponent()]).isVisible();
});

Clazz.newMethod$(C$, 'calculateNonlinkedMinimumSize$I', function (axis) {
if (!this.isVisible()) {
return 0;
}if (this.$min >= 0) {
return this.$min;
}if (this.$min == -2) {
return this.calculateNonlinkedPreferredSize$I(axis);
}return p$.getSizeAlongAxis$I$java_awt_Dimension.apply(this, [axis, this.component.getMinimumSize()]);
});

Clazz.newMethod$(C$, 'calculateNonlinkedPreferredSize$I', function (axis) {
if (!this.isVisible()) {
return 0;
}if (this.$pref >= 0) {
return this.$pref;
}return p$.getSizeAlongAxis$I$java_awt_Dimension.apply(this, [axis, this.component.getPreferredSize()]);
});

Clazz.newMethod$(C$, 'calculateNonlinkedMaximumSize$I', function (axis) {
if (!this.isVisible()) {
return 0;
}if (this.$max >= 0) {
return this.$max;
}if (this.$max == -2) {
return this.calculateNonlinkedPreferredSize$I(axis);
}return p$.getSizeAlongAxis$I$java_awt_Dimension.apply(this, [axis, this.component.getMaximumSize()]);
});

Clazz.newMethod$(C$, 'getSizeAlongAxis$I$java_awt_Dimension', function (axis, size) {
return (axis == 0) ? size.width : size.height;
});

Clazz.newMethod$(C$, 'getLinkSize$I$I', function (axis, type) {
if (!this.isVisible()) {
return 0;
}var ci = this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.component]);
return ci.getLinkSize$I$I(axis, type);
});

Clazz.newMethod$(C$, 'setSize$I$I$I', function (axis, origin, size) {
C$.superClazz.prototype.setSize$I$I$I.apply(this, [axis, origin, size]);
this.origin = origin;
if (size == -2147483648) {
this.baseline = -1;
}});

Clazz.newMethod$(C$, 'getOrigin', function () {
return this.origin;
});

Clazz.newMethod$(C$, 'setComponent$java_awt_Component', function (component) {
this.component = component;
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this.component;
});

Clazz.newMethod$(C$, 'getBaseline', function () {
if (this.baseline == -1) {
var horizontalSpring = this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.component]).horizontalSpring;
var width = horizontalSpring.getPreferredSize$I(0);
var height = this.getPreferredSize$I(1);
if (width > 0 && height > 0 ) {
this.baseline = this.component.getBaseline$I$I(width, height);
}}return this.baseline;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior', function () {
return this.getComponent().getBaselineResizeBehavior();
});

Clazz.newMethod$(C$, 'isLinked$I', function (axis) {
return this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.component]).isLinked$I(axis);
});

Clazz.newMethod$(C$, 'installIfNecessary$I', function (axis) {
if (!this.installed) {
this.installed = true;
if (axis == 0) {
this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.component]).horizontalSpring = this;
} else {
this.b$['javax.swing.GroupLayout'].getComponentInfo$java_awt_Component.apply(this.b$['javax.swing.GroupLayout'], [this.component]).verticalSpring = this;
}}});

Clazz.newMethod$(C$, 'willHaveZeroSize$Z', function (treatAutopaddingAsZeroSized) {
return !this.isVisible();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "PreferredGapSpring", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Spring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.source = null;
this.target = null;
this.type = null;
this.$pref = 0;
this.$max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$I', function (source, target, type, pref, max) {
Clazz.super(C$, this,1);
this.source = source;
this.target = target;
this.type = type;
this.$pref = pref;
this.$max = max;
}, 1);

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
return p$.getPadding$I.apply(this, [axis]);
});

Clazz.newMethod$(C$, 'calculatePreferredSize$I', function (axis) {
if (this.$pref == -1 || this.$pref == -2 ) {
return this.getMinimumSize$I(axis);
}var min = this.getMinimumSize$I(axis);
var max = this.getMaximumSize$I(axis);
return Math.min(max, Math.max(min, this.$pref));
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
if (this.$max == -2 || this.$max == -1 ) {
return p$.getPadding$I.apply(this, [axis]);
}return Math.max(this.getMinimumSize$I(axis), this.$max);
});

Clazz.newMethod$(C$, 'getPadding$I', function (axis) {
var position;
if (axis == 0) {
position = 3;
} else {
position = 5;
}return this.b$['javax.swing.GroupLayout'].getLayoutStyle0.apply(this.b$['javax.swing.GroupLayout'], []).getPreferredGap$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$java_awt_Container(this.source, this.target, this.type, position, this.b$['javax.swing.GroupLayout'].host);
});

Clazz.newMethod$(C$, 'willHaveZeroSize$Z', function (treatAutopaddingAsZeroSized) {
return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "GapSpring", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Spring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.$min = 0;
this.$pref = 0;
this.$max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I', function (min, pref, max) {
Clazz.super(C$, this,1);
P$.GroupLayout.checkSize$I$I$I$Z(min, pref, max, false);
this.$min = min;
this.$pref = pref;
this.$max = max;
}, 1);

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
if (this.$min == -2) {
return this.getPreferredSize$I(axis);
}return this.$min;
});

Clazz.newMethod$(C$, 'calculatePreferredSize$I', function (axis) {
return this.$pref;
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
if (this.$max == -2) {
return this.getPreferredSize$I(axis);
}return this.$max;
});

Clazz.newMethod$(C$, 'willHaveZeroSize$Z', function (treatAutopaddingAsZeroSized) {
return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "AutoPreferredGapSpring", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.Spring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.sources = null;
this.source = null;
this.matches = null;
this.$size = 0;
this.lastSize = 0;
this.$pref = 0;
this.$max = 0;
this.type = null;
this.userCreated = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.$pref = -2;
this.$max = -2;
this.type = (I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.LayoutStyle').ComponentPlacement))).RELATED;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (pref, max) {
Clazz.super(C$, this,1);
this.$pref = pref;
this.$max = max;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_LayoutStyle_ComponentPlacement$I$I', function (type, pref, max) {
Clazz.super(C$, this,1);
this.type = type;
this.$pref = pref;
this.$max = max;
this.userCreated = true;
}, 1);

Clazz.newMethod$(C$, 'setSources$java_util_List', function (sources) {
this.sources = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[sources]);
});

Clazz.newMethod$(C$, 'setUserCreated$Z', function (userCreated) {
this.userCreated = userCreated;
});

Clazz.newMethod$(C$, 'getUserCreated', function () {
return this.userCreated;
});

Clazz.newMethod$(C$, 'unset', function () {
this.lastSize = this.getSize();
C$.superClazz.prototype.unset.apply(this, []);
this.$size = 0;
});

Clazz.newMethod$(C$, 'reset', function () {
this.$size = 0;
this.sources = null;
this.source = null;
this.matches = null;
});

Clazz.newMethod$(C$, 'calculatePadding$I', function (axis) {
this.$size = -2147483648;
var maxPadding = -2147483648;
if (this.matches != null ) {
var p = this.b$['javax.swing.GroupLayout'].getLayoutStyle0.apply(this.b$['javax.swing.GroupLayout'], []);
var position;
if (axis == 0) {
if (this.b$['javax.swing.GroupLayout'].isLeftToRight.apply(this.b$['javax.swing.GroupLayout'], [])) {
position = 3;
} else {
position = 7;
}} else {
position = 5;
}for (var i = this.matches.size() - 1; i >= 0; i--) {
var match = this.matches.get$I(i);
maxPadding = Math.max(maxPadding, p$.calculatePadding$javax_swing_LayoutStyle$I$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring.apply(this, [p, position, match.source, match.target]));
}
}if (this.$size == -2147483648) {
this.$size = 0;
}if (maxPadding == -2147483648) {
maxPadding = 0;
}if (this.lastSize != -2147483648) {
this.$size = this.$size+(Math.min(maxPadding, this.lastSize));
}});

Clazz.newMethod$(C$, 'calculatePadding$javax_swing_LayoutStyle$I$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring', function (p, position, source, target) {
var delta = target.getOrigin() - (source.getOrigin() + source.getSize());
if (delta >= 0) {
var padding;
if ((Clazz.instanceOf(source.getComponent(), "javax.swing.JComponent")) && (Clazz.instanceOf(target.getComponent(), "javax.swing.JComponent")) ) {
padding = p.getPreferredGap$javax_swing_JComponent$javax_swing_JComponent$javax_swing_LayoutStyle_ComponentPlacement$I$java_awt_Container(source.getComponent(), target.getComponent(), this.type, position, this.b$['javax.swing.GroupLayout'].host);
} else {
padding = 10;
}if (padding > delta) {
this.$size = Math.max(this.$size, padding - delta);
}return padding;
}return 0;
});

Clazz.newMethod$(C$, 'addTarget$javax_swing_GroupLayout_ComponentSpring$I', function (spring, axis) {
var oAxis = (axis == 0) ? 1 : 0;
if (this.source != null ) {
if (this.b$['javax.swing.GroupLayout'].areParallelSiblings$java_awt_Component$java_awt_Component$I.apply(this.b$['javax.swing.GroupLayout'], [this.source.getComponent(), spring.getComponent(), oAxis])) {
p$.addValidTarget$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring.apply(this, [this.source, spring]);
}} else {
var component = spring.getComponent();
for (var counter = this.sources.size() - 1; counter >= 0; counter--) {
var source = this.sources.get$I(counter);
if (this.b$['javax.swing.GroupLayout'].areParallelSiblings$java_awt_Component$java_awt_Component$I.apply(this.b$['javax.swing.GroupLayout'], [source.getComponent(), component, oAxis])) {
p$.addValidTarget$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring.apply(this, [source, spring]);
}}
}});

Clazz.newMethod$(C$, 'addValidTarget$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring', function (source, target) {
if (this.matches == null ) {
this.matches = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]);
}this.matches.add$TE(Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.GroupLayout').AutoPreferredGapMatch))).c$$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring,[source, target]));
});

Clazz.newMethod$(C$, 'calculateMinimumSize$I', function (axis) {
return this.$size;
});

Clazz.newMethod$(C$, 'calculatePreferredSize$I', function (axis) {
if (this.$pref == -2 || this.$pref == -1 ) {
return this.$size;
}return Math.max(this.$size, this.$pref);
});

Clazz.newMethod$(C$, 'calculateMaximumSize$I', function (axis) {
if (this.$max >= 0) {
return Math.max(this.getPreferredSize$I(axis), this.$max);
}return this.$size;
});

Clazz.newMethod$(C$, 'getMatchDescription', function () {
return (this.matches == null ) ? "" : this.matches.toString();
});

Clazz.newMethod$(C$, 'toString', function () {
return C$.superClazz.prototype.toString.apply(this, []) + this.getMatchDescription();
});

Clazz.newMethod$(C$, 'willHaveZeroSize$Z', function (treatAutopaddingAsZeroSized) {
return treatAutopaddingAsZeroSized;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "AutoPreferredGapMatch", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.source = null;
this.target = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_GroupLayout_ComponentSpring$javax_swing_GroupLayout_ComponentSpring', function (source, target) {
C$.$init$.apply(this);
this.source = source;
this.target = target;
}, 1);

Clazz.newMethod$(C$, 'toString$javax_swing_GroupLayout_ComponentSpring', function (spring) {
return spring.getComponent().getName();
});

Clazz.newMethod$(C$, 'toString', function () {
return "[" + p$.toString$javax_swing_GroupLayout_ComponentSpring.apply(this, [this.source]) + "-" + p$.toString$javax_swing_GroupLayout_ComponentSpring.apply(this, [this.target]) + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "ContainerAutoPreferredGapSpring", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.GroupLayout.AutoPreferredGapSpring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.targets = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setUserCreated$Z(true);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (pref, max) {
C$.superClazz.c$$I$I.apply(this, [pref, max]);
C$.$init$.apply(this);
this.setUserCreated$Z(true);
}, 1);

Clazz.newMethod$(C$, 'addTarget$javax_swing_GroupLayout_ComponentSpring$I', function (spring, axis) {
if (this.targets == null ) {
this.targets = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[1]);
}this.targets.add$TE(spring);
});

Clazz.newMethod$(C$, 'calculatePadding$I', function (axis) {
var p = this.b$['javax.swing.GroupLayout'].getLayoutStyle0.apply(this.b$['javax.swing.GroupLayout'], []);
var maxPadding = 0;
var position;
this.$size = 0;
if (this.targets != null ) {
if (axis == 0) {
if (this.b$['javax.swing.GroupLayout'].isLeftToRight.apply(this.b$['javax.swing.GroupLayout'], [])) {
position = 7;
} else {
position = 3;
}} else {
position = 5;
}for (var i = this.targets.size() - 1; i >= 0; i--) {
var targetSpring = this.targets.get$I(i);
var padding = 10;
if (Clazz.instanceOf(targetSpring.getComponent(), "javax.swing.JComponent")) {
padding = p.getContainerGap$javax_swing_JComponent$I$java_awt_Container(targetSpring.getComponent(), position, this.b$['javax.swing.GroupLayout'].host);
maxPadding = Math.max(padding, maxPadding);
padding = padding-(targetSpring.getOrigin());
} else {
maxPadding = Math.max(padding, maxPadding);
}this.$size = Math.max(this.$size, padding);
}
} else {
if (axis == 0) {
if (this.b$['javax.swing.GroupLayout'].isLeftToRight.apply(this.b$['javax.swing.GroupLayout'], [])) {
position = 3;
} else {
position = 7;
}} else {
position = 5;
}if (this.sources != null ) {
for (var i = this.sources.size() - 1; i >= 0; i--) {
var sourceSpring = this.sources.get$I(i);
maxPadding = Math.max(maxPadding, p$.updateSize$javax_swing_LayoutStyle$javax_swing_GroupLayout_ComponentSpring$I.apply(this, [p, sourceSpring, position]));
}
} else if (this.source != null ) {
maxPadding = p$.updateSize$javax_swing_LayoutStyle$javax_swing_GroupLayout_ComponentSpring$I.apply(this, [p, this.source, position]);
}}if (this.lastSize != -2147483648) {
this.$size = this.$size+(Math.min(maxPadding, this.lastSize));
}});

Clazz.newMethod$(C$, 'updateSize$javax_swing_LayoutStyle$javax_swing_GroupLayout_ComponentSpring$I', function (p, sourceSpring, position) {
var padding = 10;
if (Clazz.instanceOf(sourceSpring.getComponent(), "javax.swing.JComponent")) {
padding = p.getContainerGap$javax_swing_JComponent$I$java_awt_Container(sourceSpring.getComponent(), position, this.b$['javax.swing.GroupLayout'].host);
}var delta = Math.max(0, this.getParent().getSize() - sourceSpring.getSize() - sourceSpring.getOrigin() );
this.$size = Math.max(this.$size, padding - delta);
return padding;
});

Clazz.newMethod$(C$, 'getMatchDescription', function () {
if (this.targets != null ) {
return "leading: " + this.targets.toString();
}if (this.sources != null ) {
return "trailing: " + this.sources.toString();
}return "--";
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "LinkInfo", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.axis = 0;
this.linked = null;
this.size = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (axis) {
C$.$init$.apply(this);
this.linked = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))));
this.size = -2147483648;
this.axis = axis;
}, 1);

Clazz.newMethod$(C$, 'add$javax_swing_GroupLayout_ComponentInfo', function (child) {
var childMaster = child.getLinkInfo$I$Z(this.axis, false);
if (childMaster == null ) {
this.linked.add$TE(child);
child.setLinkInfo$I$javax_swing_GroupLayout_LinkInfo(this.axis, this);
} else if (childMaster !== this ) {
this.linked.addAll$java_util_Collection(childMaster.linked);
for (var childInfo, $childInfo = childMaster.linked.iterator (); $childInfo.hasNext () && ((childInfo = $childInfo.next ()) || true);) {
childInfo.setLinkInfo$I$javax_swing_GroupLayout_LinkInfo(this.axis, this);
}
}this.clearCachedSize();
});

Clazz.newMethod$(C$, 'remove$javax_swing_GroupLayout_ComponentInfo', function (info) {
this.linked.remove$O(info);
info.setLinkInfo$I$javax_swing_GroupLayout_LinkInfo(this.axis, null);
if (this.linked.size() == 1) {
this.linked.get$I(0).setLinkInfo$I$javax_swing_GroupLayout_LinkInfo(this.axis, null);
}this.clearCachedSize();
});

Clazz.newMethod$(C$, 'clearCachedSize', function () {
this.size = -2147483648;
});

Clazz.newMethod$(C$, 'getSize$I', function (axis) {
if (this.size == -2147483648) {
this.size = p$.calculateLinkedSize$I.apply(this, [axis]);
}return this.size;
});

Clazz.newMethod$(C$, 'calculateLinkedSize$I', function (axis) {
var size = 0;
for (var info, $info = this.linked.iterator (); $info.hasNext () && ((info = $info.next ()) || true);) {
var spring;
if (axis == 0) {
spring = info.horizontalSpring;
} else {
spring = info.verticalSpring;
}size = Math.max(size, spring.calculateNonlinkedPreferredSize$I(axis));
}
return size;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GroupLayout, "ComponentInfo", function(){
Clazz.newInstance$(this, arguments[0], true);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.component = null;
this.horizontalSpring = null;
this.verticalSpring = null;
this.horizontalMaster = null;
this.verticalMaster = null;
this.visible = false;
this.honorsVisibility = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component', function (component) {
C$.$init$.apply(this);
this.component = component;
this.updateVisibility();
}, 1);

Clazz.newMethod$(C$, 'dispose', function () {
p$.removeSpring$javax_swing_GroupLayout_Spring.apply(this, [this.horizontalSpring]);
this.horizontalSpring = null;
p$.removeSpring$javax_swing_GroupLayout_Spring.apply(this, [this.verticalSpring]);
this.verticalSpring = null;
if (this.horizontalMaster != null ) {
this.horizontalMaster.remove$javax_swing_GroupLayout_ComponentInfo(this);
}if (this.verticalMaster != null ) {
this.verticalMaster.remove$javax_swing_GroupLayout_ComponentInfo(this);
}});

Clazz.newMethod$(C$, 'setHonorsVisibility$Boolean', function (honorsVisibility) {
this.honorsVisibility = honorsVisibility;
});

Clazz.newMethod$(C$, 'removeSpring$javax_swing_GroupLayout_Spring', function (spring) {
if (spring != null ) {
(spring.getParent()).springs.remove$O(spring);
}});

Clazz.newMethod$(C$, 'isVisible', function () {
return this.visible;
});

Clazz.newMethod$(C$, 'updateVisibility', function () {
var honorsVisibility;
if (this.honorsVisibility == null ) {
honorsVisibility = this.b$['javax.swing.GroupLayout'].getHonorsVisibility();
} else {
honorsVisibility = (this.honorsVisibility).booleanValue();
}var newVisible = (honorsVisibility) ? this.component.isVisible() : true;
if (this.visible != newVisible ) {
this.visible = newVisible;
return true;
}return false;
});

Clazz.newMethod$(C$, 'setBounds$java_awt_Insets$I$Z', function (insets, parentWidth, ltr) {
var x = this.horizontalSpring.getOrigin();
var w = this.horizontalSpring.getSize();
var y = this.verticalSpring.getOrigin();
var h = this.verticalSpring.getSize();
if (!ltr) {
x = parentWidth - x - w ;
}this.component.setBounds$I$I$I$I(x + insets.left, y + insets.top, w, h);
});

Clazz.newMethod$(C$, 'setComponent$java_awt_Component', function (component) {
this.component = component;
if (this.horizontalSpring != null ) {
this.horizontalSpring.setComponent$java_awt_Component(component);
}if (this.verticalSpring != null ) {
this.verticalSpring.setComponent$java_awt_Component(component);
}});

Clazz.newMethod$(C$, 'isLinked$I', function (axis) {
if (axis == 0) {
return this.horizontalMaster != null ;
}return (this.verticalMaster != null );
});

Clazz.newMethod$(C$, 'setLinkInfo$I$javax_swing_GroupLayout_LinkInfo', function (axis, linkInfo) {
if (axis == 0) {
this.horizontalMaster = linkInfo;
} else {
this.verticalMaster = linkInfo;
}});

Clazz.newMethod$(C$, 'getLinkInfo$I', function (axis) {
return p$.getLinkInfo$I$Z.apply(this, [axis, true]);
});

Clazz.newMethod$(C$, 'getLinkInfo$I$Z', function (axis, create) {
if (axis == 0) {
if (this.horizontalMaster == null  && create ) {
Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load('javax.swing.GroupLayout').LinkInfo))).c$$I,[0]).add$javax_swing_GroupLayout_ComponentInfo(this);
}return this.horizontalMaster;
} else {
if (this.verticalMaster == null  && create ) {
Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load('javax.swing.GroupLayout').LinkInfo))).c$$I,[1]).add$javax_swing_GroupLayout_ComponentInfo(this);
}return this.verticalMaster;
}});

Clazz.newMethod$(C$, 'clearCachedSize', function () {
if (this.horizontalMaster != null ) {
this.horizontalMaster.clearCachedSize();
}if (this.verticalMaster != null ) {
this.verticalMaster.clearCachedSize();
}});

Clazz.newMethod$(C$, 'getLinkSize$I$I', function (axis, type) {
if (axis == 0) {
return this.horizontalMaster.getSize$I(axis);
} else {
return this.verticalMaster.getSize$I(axis);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:33
