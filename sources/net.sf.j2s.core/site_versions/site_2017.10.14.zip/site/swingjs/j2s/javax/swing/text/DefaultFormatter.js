(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultFormatter", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JFormattedTextField.AbstractFormatter', 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.allowsInvalid = false;
this.overwriteMode = false;
this.commitOnEdit = false;
this.valueClass = null;
this.navigationFilter = null;
this.documentFilter = null;
this.replaceHolder = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.overwriteMode = true;
this.allowsInvalid = true;
}, 1);

Clazz.newMethod$(C$, 'install$javax_swing_JFormattedTextField', function (ftf) {
C$.superClazz.prototype.install$javax_swing_JFormattedTextField.apply(this, [ftf]);
this.positionCursorAtInitialLocation();
});

Clazz.newMethod$(C$, 'setCommitsOnValidEdit$Z', function (commit) {
this.commitOnEdit = commit;
});

Clazz.newMethod$(C$, 'getCommitsOnValidEdit', function () {
return this.commitOnEdit;
});

Clazz.newMethod$(C$, 'setOverwriteMode$Z', function (overwriteMode) {
this.overwriteMode = overwriteMode;
});

Clazz.newMethod$(C$, 'getOverwriteMode', function () {
return this.overwriteMode;
});

Clazz.newMethod$(C$, 'setAllowsInvalid$Z', function (allowsInvalid) {
this.allowsInvalid = allowsInvalid;
});

Clazz.newMethod$(C$, 'getAllowsInvalid', function () {
return this.allowsInvalid;
});

Clazz.newMethod$(C$, 'setValueClass$Class', function (valueClass) {
this.valueClass = valueClass;
});

Clazz.newMethod$(C$, 'getValueClass', function () {
return this.valueClass;
});

Clazz.newMethod$(C$, 'stringToValue$S', function (string) {
var vc = this.getValueClass();
var ftf = this.getFormattedTextField();
if (vc == null  && ftf != null  ) {
var value = ftf.getValue();
if (value != null ) {
vc = value.getClass();
}}return string;
});

Clazz.newMethod$(C$, 'valueToString$O', function (value) {
if (value == null ) {
return "";
}return value.toString();
});

Clazz.newMethod$(C$, 'getDocumentFilter', function () {
if (this.documentFilter == null ) {
this.documentFilter = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.text.DefaultFormatter').DefaultDocumentFilter))), [this, null]);
}return this.documentFilter;
});

Clazz.newMethod$(C$, 'getNavigationFilter', function () {
if (this.navigationFilter == null ) {
this.navigationFilter = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.DefaultFormatter').DefaultNavigationFilter))), [this, null]);
}return this.navigationFilter;
});

Clazz.newMethod$(C$, 'clone', function () {
var formatter = Clazz.clone(this);
formatter.navigationFilter = null;
formatter.documentFilter = null;
formatter.replaceHolder = null;
return formatter;
});

Clazz.newMethod$(C$, 'positionCursorAtInitialLocation', function () {
var ftf = this.getFormattedTextField();
if (ftf != null ) {
ftf.setCaretPosition$I(this.getInitialVisualPosition());
}});

Clazz.newMethod$(C$, 'getInitialVisualPosition', function () {
return p$.getNextNavigatableChar$I$I.apply(this, [0, 1]);
});

Clazz.newMethod$(C$, 'isNavigatable$I', function (offset) {
return true;
});

Clazz.newMethod$(C$, 'isLegalInsertText$S', function (text) {
return true;
});

Clazz.newMethod$(C$, 'getNextNavigatableChar$I$I', function (offset, direction) {
var max = this.getFormattedTextField().getDocument().getLength();
while (offset >= 0 && offset < max ){
if (this.isNavigatable$I(offset)) {
return offset;
}offset = offset+(direction);
}
return offset;
});

Clazz.newMethod$(C$, 'getReplaceString$I$I$S', function (offset, deleteLength, replaceString) {
var string = this.getFormattedTextField().getText();
var result;
result = string.substring(0, offset);
if (replaceString != null ) {
result += replaceString;
}if (offset + deleteLength < string.length$()) {
result += string.substring(offset + deleteLength);
}return result;
});

Clazz.newMethod$(C$, 'isValidEdit$javax_swing_text_DefaultFormatter_ReplaceHolder', function (rh) {
if (!this.getAllowsInvalid()) {
var newString = this.getReplaceString$I$I$S(rh.offset, rh.length, rh.text);
try {
rh.value = this.stringToValue$S(newString);
return true;
} catch (pe) {
if (Clazz.exceptionOf(pe, java.text.ParseException)){
return false;
} else {
throw pe;
}
}
}return true;
});

Clazz.newMethod$(C$, 'commitEdit', function () {
});

Clazz.newMethod$(C$, 'updateValue', function () {
this.updateValue$O(null);
});

Clazz.newMethod$(C$, 'updateValue$O', function (value) {
try {
if (value == null ) {
var string = this.getFormattedTextField().getText();
value = this.stringToValue$S(string);
}if (this.getCommitsOnValidEdit()) {
this.commitEdit();
}this.setEditValid$Z(true);
} catch (pe) {
if (Clazz.exceptionOf(pe, java.text.ParseException)){
this.setEditValid$Z(false);
} else {
throw pe;
}
}
});

Clazz.newMethod$(C$, 'getNextCursorPosition$I$I', function (offset, direction) {
var newOffset = p$.getNextNavigatableChar$I$I.apply(this, [offset, direction]);
var max = this.getFormattedTextField().getDocument().getLength();
if (!this.getAllowsInvalid()) {
if (direction == -1 && offset == newOffset ) {
newOffset = p$.getNextNavigatableChar$I$I.apply(this, [newOffset, 1]);
if (newOffset >= max) {
newOffset = offset;
}} else if (direction == 1 && newOffset >= max ) {
newOffset = p$.getNextNavigatableChar$I$I.apply(this, [max - 1, -1]);
if (newOffset < max) {
newOffset++;
}}}return newOffset;
});

Clazz.newMethod$(C$, 'repositionCursor$I$I', function (offset, direction) {
this.getFormattedTextField().getCaret().setDot$I(this.getNextCursorPosition$I$I(offset, direction));
});

Clazz.newMethod$(C$, 'getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA', function (text, pos, bias, direction, biasRet) {
var value = (text.getUI()).getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(text, pos, bias, direction, biasRet);
if (value == -1) {
return -1;
}if (!this.getAllowsInvalid() && (direction == 3 || direction == 7 ) ) {
var last = -1;
while (!this.isNavigatable$I(value) && value != last ){
last = value;
value = (text.getUI()).getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(text, value, bias, direction, biasRet);
}
var max = this.getFormattedTextField().getDocument().getLength();
if (last == value || value == max ) {
if (value == 0) {
biasRet[0] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
value = this.getInitialVisualPosition();
}if (value >= max && max > 0 ) {
biasRet[0] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
value = p$.getNextNavigatableChar$I$I.apply(this, [max - 1, -1]) + 1;
}}}return value;
});

Clazz.newMethod$(C$, 'canReplace$javax_swing_text_DefaultFormatter_ReplaceHolder', function (rh) {
return this.isValidEdit$javax_swing_text_DefaultFormatter_ReplaceHolder(rh);
});

Clazz.newMethod$(C$, 'replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, text, attrs) {
var rh = this.getReplaceHolder$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, length, text, attrs);
this.replace$javax_swing_text_DefaultFormatter_ReplaceHolder(rh);
});

Clazz.newMethod$(C$, 'replace$javax_swing_text_DefaultFormatter_ReplaceHolder', function (rh) {
var valid = true;
var direction = 1;
if (rh.length > 0 && (rh.text == null  || rh.text.length$() == 0 )  && (this.getFormattedTextField().getSelectionStart() != rh.offset || rh.length > 1 ) ) {
direction = -1;
}if (this.getOverwriteMode() && rh.text != null  ) {
rh.length = Math.min(Math.max(rh.length, rh.text.length$()), rh.fb.getDocument().getLength() - rh.offset);
}if ((rh.text != null  && !this.isLegalInsertText$S(rh.text) ) || !this.canReplace$javax_swing_text_DefaultFormatter_ReplaceHolder(rh) || (rh.length == 0 && (rh.text == null  || rh.text.length$() == 0 ) )  ) {
valid = false;
}if (valid) {
var cursor = rh.cursorPosition;
rh.fb.replace$I$I$S$javax_swing_text_AttributeSet(rh.offset, rh.length, rh.text, rh.attrs);
if (cursor == -1) {
cursor = rh.offset;
if (direction == 1 && rh.text != null  ) {
cursor = rh.offset + rh.text.length$();
}}this.updateValue$O(rh.value);
this.repositionCursor$I$I(cursor, direction);
return true;
} else {
this.invalidEdit();
}return false;
});

Clazz.newMethod$(C$, 'setDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias', function (fb, dot, bias) {
fb.setDot$I$javax_swing_text_Position_Bias(dot, bias);
});

Clazz.newMethod$(C$, 'moveDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias', function (fb, dot, bias) {
fb.moveDot$I$javax_swing_text_Position_Bias(dot, bias);
});

Clazz.newMethod$(C$, 'getReplaceHolder$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, text, attrs) {
if (this.replaceHolder == null ) {
this.replaceHolder = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.DefaultFormatter').ReplaceHolder))));
}this.replaceHolder.reset$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, length, text, attrs);
return this.replaceHolder;
});
;
(function(){var C$=Clazz.newClass$(P$.DefaultFormatter, "ReplaceHolder", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.fb = null;
this.offset = 0;
this.length = 0;
this.text = null;
this.attrs = null;
this.value = null;
this.cursorPosition = 0;
}, 1);

Clazz.newMethod$(C$, 'reset$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, text, attrs) {
this.fb = fb;
this.offset = offset;
this.length = length;
this.text = text;
this.attrs = attrs;
this.value = null;
this.cursorPosition = -1;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultFormatter, "DefaultNavigationFilter", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.NavigationFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias', function (fb, dot, bias) {
var tc = this.b$['javax.swing.text.DefaultFormatter'].getFormattedTextField();
if (tc.composedTextExists()) {
fb.setDot$I$javax_swing_text_Position_Bias(dot, bias);
} else {
this.b$['javax.swing.text.DefaultFormatter'].setDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias(fb, dot, bias);
}});

Clazz.newMethod$(C$, 'moveDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias', function (fb, dot, bias) {
var tc = this.b$['javax.swing.text.DefaultFormatter'].getFormattedTextField();
if (tc.composedTextExists()) {
fb.moveDot$I$javax_swing_text_Position_Bias(dot, bias);
} else {
this.b$['javax.swing.text.DefaultFormatter'].moveDot$javax_swing_text_NavigationFilter_FilterBypass$I$javax_swing_text_Position_Bias(fb, dot, bias);
}});

Clazz.newMethod$(C$, 'getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA', function (text, pos, bias, direction, biasRet) {
if (text.composedTextExists()) {
return (text.getUI()).getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(text, pos, bias, direction, biasRet);
} else {
return this.b$['javax.swing.text.DefaultFormatter'].getNextVisualPositionFrom$javax_swing_text_JTextComponent$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_BiasA(text, pos, bias, direction, biasRet);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultFormatter, "DefaultDocumentFilter", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.DocumentFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'remove$javax_swing_text_DocumentFilter_FilterBypass$I$I', function (fb, offset, length) {
var tc = this.b$['javax.swing.text.DefaultFormatter'].getFormattedTextField();
if (tc.composedTextExists()) {
fb.remove$I$I(offset, length);
} else {
this.b$['javax.swing.text.DefaultFormatter'].replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, length, null, null);
}});

Clazz.newMethod$(C$, 'insertString$javax_swing_text_DocumentFilter_FilterBypass$I$S$javax_swing_text_AttributeSet', function (fb, offset, string, attr) {
var tc = this.b$['javax.swing.text.DefaultFormatter'].getFormattedTextField();
if (tc.composedTextExists() || (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).isComposedTextAttributeDefined$javax_swing_text_AttributeSet(attr) ) {
fb.insertString$I$S$javax_swing_text_AttributeSet(offset, string, attr);
} else {
this.b$['javax.swing.text.DefaultFormatter'].replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, 0, string, attr);
}});

Clazz.newMethod$(C$, 'replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, text, attr) {
var tc = this.b$['javax.swing.text.DefaultFormatter'].getFormattedTextField();
if (tc.composedTextExists() || (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).isComposedTextAttributeDefined$javax_swing_text_AttributeSet(attr) ) {
fb.replace$I$I$S$javax_swing_text_AttributeSet(offset, length, text, attr);
} else {
this.b$['javax.swing.text.DefaultFormatter'].replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, length, text, attr);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:01
