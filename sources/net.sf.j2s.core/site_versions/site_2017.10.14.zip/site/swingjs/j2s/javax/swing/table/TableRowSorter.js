(function(){var P$=Clazz.newPackage$("javax.swing.table"),I$=[];
var C$=Clazz.newClass$(P$, "TableRowSorter", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.DefaultRowSorter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.tableModel = null;
this.stringConverter = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$TM.apply(this, [null]);
}, 1);

Clazz.newMethod$(C$, 'c$$TM', function (model) {
Clazz.super(C$, this,1);
this.setModel$TM(model);
}, 1);

Clazz.newMethod$(C$, 'setModel$TM', function (model) {
this.tableModel = model;
this.setModelWrapper$javax_swing_DefaultRowSorter_ModelWrapper(Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.table.TableRowSorter').TableRowSorterModelWrapper))), [this, null]));
});

Clazz.newMethod$(C$, 'setStringConverter$javax_swing_table_TableStringConverter', function (stringConverter) {
this.stringConverter = stringConverter;
});

Clazz.newMethod$(C$, 'getStringConverter', function () {
return this.stringConverter;
});

Clazz.newMethod$(C$, 'getComparator$I', function (column) {
var comparator = C$.superClazz.prototype.getComparator$I.apply(this, [column]);
if (comparator != null ) {
return comparator;
}return null;
});

Clazz.newMethod$(C$, 'useToString$I', function (column) {
var comparator = C$.superClazz.prototype.getComparator$I.apply(this, [column]);
if (comparator != null ) {
return false;
}var columnClass = this.getModel().getColumnClass$I(column);
if (columnClass === Clazz.getClass(java.lang.String) ) {
return false;
}if (Clazz.getClass(java.lang.Comparable).isAssignableFrom$Class(columnClass)) {
return false;
}return true;
});
;
(function(){var C$=Clazz.newClass$(P$.TableRowSorter, "TableRowSorterModelWrapper", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.DefaultRowSorter.ModelWrapper');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getModel', function () {
return this.b$['javax.swing.table.TableRowSorter'].tableModel;
});

Clazz.newMethod$(C$, 'getColumnCount', function () {
return (this.b$['javax.swing.table.TableRowSorter'].tableModel == null ) ? 0 : this.b$['javax.swing.table.TableRowSorter'].tableModel.getColumnCount();
});

Clazz.newMethod$(C$, 'getRowCount', function () {
return (this.b$['javax.swing.table.TableRowSorter'].tableModel == null ) ? 0 : this.b$['javax.swing.table.TableRowSorter'].tableModel.getRowCount();
});

Clazz.newMethod$(C$, 'getValueAt$I$I', function (row, column) {
return this.b$['javax.swing.table.TableRowSorter'].tableModel.getValueAt$I$I(row, column);
});

Clazz.newMethod$(C$, 'getStringValueAt$I$I', function (row, column) {
var converter = this.b$['javax.swing.table.TableRowSorter'].getStringConverter();
if (converter != null ) {
var value = converter.toString$javax_swing_table_TableModel$I$I(this.b$['javax.swing.table.TableRowSorter'].tableModel, row, column);
if (value != null ) {
return value;
}return "";
}var o = this.getValueAt$I$I(row, column);
if (o == null ) {
return "";
}var string = o.toString();
if (string == null ) {
return "";
}return string;
});

Clazz.newMethod$(C$, 'getIdentifier$I', function (index) {
return new Integer(index);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:00
