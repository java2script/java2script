(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JTable", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', ['javax.swing.event.TableModelListener', 'javax.swing.Scrollable', 'javax.swing.event.TableColumnModelListener', 'javax.swing.event.ListSelectionListener', 'javax.swing.event.CellEditorListener', 'javax.swing.event.RowSorterListener']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.dataModel = null;
this.columnModel = null;
this.selectionModel = null;
this.tableHeader = null;
this.rowHeight = 0;
this.rowMargin = 0;
this.gridColor = null;
this.showHorizontalLines = false;
this.showVerticalLines = false;
this.autoResizeMode = 0;
this.autoCreateColumnsFromModel = false;
this.preferredViewportSize = null;
this.rowSelectionAllowed = false;
this.cellSelectionEnabled = false;
this.editorComp = null;
this.cellEditor = null;
this.editingColumn = 0;
this.editingRow = 0;
this.defaultRenderersByColumnClass = null;
this.defaultEditorsByColumnClass = null;
this.selectionForeground = null;
this.selectionBackground = null;
this.rowModel = null;
this.dragEnabled = false;
this.surrendersFocusOnKeystroke = false;
this.editorRemover = null;
this.columnSelectionAdjusting = false;
this.rowSelectionAdjusting = false;
this.isRowHeightSet = false;
this.updateSelectionOnSort = false;
this.sortManager = null;
this.ignoreSortChange = false;
this.$sorterChanged = false;
this.autoCreateRowSorter = false;
this.fillsViewportHeight = false;
this.dropMode = (I$[11] || (I$[11]=Clazz.load('javax.swing.DropMode'))).USE_SELECTION;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_table_TableModel$javax_swing_table_TableColumnModel$javax_swing_ListSelectionModel.apply(this, [null, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_table_TableModel', function (dm) {
C$.c$$javax_swing_table_TableModel$javax_swing_table_TableColumnModel$javax_swing_ListSelectionModel.apply(this, [dm, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_table_TableModel$javax_swing_table_TableColumnModel', function (dm, cm) {
C$.c$$javax_swing_table_TableModel$javax_swing_table_TableColumnModel$javax_swing_ListSelectionModel.apply(this, [dm, cm, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_table_TableModel$javax_swing_table_TableColumnModel$javax_swing_ListSelectionModel', function (dm, cm, sm) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(null);
if (cm == null ) {
cm = this.createDefaultColumnModel();
this.autoCreateColumnsFromModel = true;
}this.setColumnModel$javax_swing_table_TableColumnModel(cm);
if (sm == null ) {
sm = this.createDefaultSelectionModel();
}this.setSelectionModel$javax_swing_ListSelectionModel(sm);
if (dm == null ) {
dm = this.createDefaultDataModel();
}this.setModel$javax_swing_table_TableModel(dm);
this.initializeLocalVars();
this.uiClassID = "TableUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (numRows, numColumns) {
C$.c$$javax_swing_table_TableModel.apply(this, [Clazz.new((I$[12] || (I$[12]=Clazz.load('javax.swing.table.DefaultTableModel'))).c$$I$I,[numRows, numColumns])]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_util_Vector$java_util_Vector', function (rowData, columnNames) {
C$.c$$javax_swing_table_TableModel.apply(this, [Clazz.new((I$[12] || (I$[12]=Clazz.load('javax.swing.table.DefaultTableModel'))).c$$java_util_Vector$java_util_Vector,[rowData, columnNames])]);
}, 1);

Clazz.newMethod$(C$, 'c$$OAA$OA', function (rowData, columnNames) {
C$.c$$javax_swing_table_TableModel.apply(this, [((
(function(){var C$=Clazz.newClass$(P$, "JTable$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.table.AbstractTableModel'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getColumnName$I', function (column) {
return this.$finals.columnNames[column].toString();
});

Clazz.newMethod$(C$, 'getRowCount', function () {
return this.$finals.rowData.length;
});

Clazz.newMethod$(C$, 'getColumnCount', function () {
return this.$finals.columnNames.length;
});

Clazz.newMethod$(C$, 'getValueAt$I$I', function (row, col) {
return this.$finals.rowData[row][col];
});

Clazz.newMethod$(C$, 'isCellEditable$I$I', function (row, column) {
return true;
});

Clazz.newMethod$(C$, 'setValueAt$O$I$I', function (value, row, col) {
this.$finals.rowData[row][col] = value;
this.fireTableCellUpdated$I$I(row, col);
});
})()
), Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.table.AbstractTableModel'))), [this, {columnNames: columnNames, rowData: rowData}],P$.JTable$1))]);
}, 1);

Clazz.newMethod$(C$, 'addNotify', function () {
C$.superClazz.prototype.addNotify.apply(this, []);
this.configureEnclosingScrollPane();
});

Clazz.newMethod$(C$, 'configureEnclosingScrollPane', function () {
var p = this.getParent();
if (Clazz.instanceOf(p, "javax.swing.JViewport")) {
var gp = p.getParent();
if (Clazz.instanceOf(gp, "javax.swing.JScrollPane")) {
var scrollPane = gp;
var viewport = scrollPane.getViewport();
if (viewport == null  || viewport.getView() !== this  ) {
return;
}scrollPane.setColumnHeaderView$java_awt_Component(this.getTableHeader());
p$.configureEnclosingScrollPaneUI.apply(this, []);
}}});

Clazz.newMethod$(C$, 'configureEnclosingScrollPaneUI', function () {
var p = this.getParent();
if (Clazz.instanceOf(p, "javax.swing.JViewport")) {
var gp = p.getParent();
if (Clazz.instanceOf(gp, "javax.swing.JScrollPane")) {
var scrollPane = gp;
var viewport = scrollPane.getViewport();
if (viewport == null  || viewport.getView() !== this  ) {
return;
}var border = scrollPane.getBorder();
if (border == null  || Clazz.instanceOf(border, "javax.swing.plaf.UIResource") ) {
var scrollPaneBorder = (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getBorder$O("Table.scrollPaneBorder");
if (scrollPaneBorder != null ) {
scrollPane.setBorder$javax_swing_border_Border(scrollPaneBorder);
}}var corner = scrollPane.getCorner$S("UPPER_TRAILING_CORNER");
if (corner == null  || Clazz.instanceOf(corner, "javax.swing.plaf.UIResource") ) {
corner = null;
try {
corner = (I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).get$O("Table.scrollPaneCornerComponent");
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
} else {
throw e;
}
}
scrollPane.setCorner$S$java_awt_Component("UPPER_TRAILING_CORNER", corner);
}}}});

Clazz.newMethod$(C$, 'removeNotify', function () {
});

Clazz.newMethod$(C$, 'unconfigureEnclosingScrollPane', function () {
var p = this.getParent();
if (Clazz.instanceOf(p, "javax.swing.JViewport")) {
var gp = p.getParent();
if (Clazz.instanceOf(gp, "javax.swing.JScrollPane")) {
var scrollPane = gp;
var viewport = scrollPane.getViewport();
if (viewport == null  || viewport.getView() !== this  ) {
return;
}scrollPane.setColumnHeaderView$java_awt_Component(null);
var corner = scrollPane.getCorner$S("UPPER_TRAILING_CORNER");
if (Clazz.instanceOf(corner, "javax.swing.plaf.UIResource")) {
scrollPane.setCorner$S$java_awt_Component("UPPER_TRAILING_CORNER", null);
}}}});

Clazz.newMethod$(C$, 'setUIProperty$S$O', function (propertyName, value) {
if (propertyName == "rowHeight") {
if (!this.isRowHeightSet) {
this.setRowHeight$I((value).intValue());
this.isRowHeightSet = false;
}return;
}C$.superClazz.prototype.setUIProperty$S$O.apply(this, [propertyName, value]);
});

Clazz.newMethod$(C$, 'createScrollPaneForTable$javax_swing_JTable', function (aTable) {
return Clazz.new((I$[14] || (I$[14]=Clazz.load('javax.swing.JScrollPane'))).c$$java_awt_Component,[aTable]);
}, 1);

Clazz.newMethod$(C$, 'setTableHeader$javax_swing_table_JTableHeader', function (tableHeader) {
if (this.tableHeader !== tableHeader ) {
var old = this.tableHeader;
if (old != null ) {
old.setTable$javax_swing_JTable(null);
}this.tableHeader = tableHeader;
if (tableHeader != null ) {
tableHeader.setTable$javax_swing_JTable(this);
}this.firePropertyChange$S$O$O("tableHeader", old, tableHeader);
}});

Clazz.newMethod$(C$, 'getTableHeader', function () {
return this.tableHeader;
});

Clazz.newMethod$(C$, 'setRowHeight$I', function (rowHeight) {
if (rowHeight <= 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["New row height less than 1"]);
}var old = this.rowHeight;
this.rowHeight = rowHeight;
this.rowModel = null;
if (this.sortManager != null ) {
this.sortManager.modelRowSizes = null;
}this.isRowHeightSet = true;
this.resizeAndRepaint();
this.firePropertyChange$S$I$I("rowHeight", old, rowHeight);
});

Clazz.newMethod$(C$, 'getRowHeight', function () {
return this.rowHeight;
});

Clazz.newMethod$(C$, 'getRowModel', function () {
if (this.rowModel == null ) {
this.rowModel = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.SizeSequence'))).c$$I$I,[this.getRowCount(), this.getRowHeight()]);
}return this.rowModel;
});

Clazz.newMethod$(C$, 'setRowHeight$I$I', function (row, rowHeight) {
if (rowHeight <= 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["New row height less than 1"]);
}p$.getRowModel.apply(this, []).setSize$I$I(row, rowHeight);
if (this.sortManager != null ) {
this.sortManager.setViewRowHeight$I$I(row, rowHeight);
}this.resizeAndRepaint();
});

Clazz.newMethod$(C$, 'getRowHeight$I', function (row) {
return (this.rowModel == null ) ? this.getRowHeight() : this.rowModel.getSize$I(row);
});

Clazz.newMethod$(C$, 'setRowMargin$I', function (rowMargin) {
var old = this.rowMargin;
this.rowMargin = rowMargin;
this.resizeAndRepaint();
this.firePropertyChange$S$I$I("rowMargin", old, rowMargin);
});

Clazz.newMethod$(C$, 'getRowMargin', function () {
return this.rowMargin;
});

Clazz.newMethod$(C$, 'setIntercellSpacing$java_awt_Dimension', function (intercellSpacing) {
this.setRowMargin$I(intercellSpacing.height);
this.getColumnModel().setColumnMargin$I(intercellSpacing.width);
this.resizeAndRepaint();
});

Clazz.newMethod$(C$, 'getIntercellSpacing', function () {
return Clazz.new((I$[15] || (I$[15]=Clazz.load('java.awt.Dimension'))).c$$I$I,[this.getColumnModel().getColumnMargin(), this.rowMargin]);
});

Clazz.newMethod$(C$, 'setGridColor$java_awt_Color', function (gridColor) {
if (gridColor == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["New color is null"]);
}var old = this.gridColor;
this.gridColor = gridColor;
this.firePropertyChange$S$O$O("gridColor", old, gridColor);
this.repaint();
});

Clazz.newMethod$(C$, 'getGridColor', function () {
return this.gridColor;
});

Clazz.newMethod$(C$, 'setShowGrid$Z', function (showGrid) {
this.setShowHorizontalLines$Z(showGrid);
this.setShowVerticalLines$Z(showGrid);
this.repaint();
});

Clazz.newMethod$(C$, 'setShowHorizontalLines$Z', function (showHorizontalLines) {
var old = this.showHorizontalLines;
this.showHorizontalLines = showHorizontalLines;
this.firePropertyChange$S$Z$Z("showHorizontalLines", old, showHorizontalLines);
this.repaint();
});

Clazz.newMethod$(C$, 'setShowVerticalLines$Z', function (showVerticalLines) {
var old = this.showVerticalLines;
this.showVerticalLines = showVerticalLines;
this.firePropertyChange$S$Z$Z("showVerticalLines", old, showVerticalLines);
this.repaint();
});

Clazz.newMethod$(C$, 'getShowHorizontalLines', function () {
return this.showHorizontalLines;
});

Clazz.newMethod$(C$, 'getShowVerticalLines', function () {
return this.showVerticalLines;
});

Clazz.newMethod$(C$, 'setAutoResizeMode$I', function (mode) {
if ((mode == 0) || (mode == 1) || (mode == 2) || (mode == 3) || (mode == 4)  ) {
var old = this.autoResizeMode;
this.autoResizeMode = mode;
this.resizeAndRepaint();
if (this.tableHeader != null ) {
this.tableHeader.resizeAndRepaint();
}this.firePropertyChange$S$I$I("autoResizeMode", old, this.autoResizeMode);
}});

Clazz.newMethod$(C$, 'getAutoResizeMode', function () {
return this.autoResizeMode;
});

Clazz.newMethod$(C$, 'setAutoCreateColumnsFromModel$Z', function (autoCreateColumnsFromModel) {
if (this.autoCreateColumnsFromModel != autoCreateColumnsFromModel ) {
var old = this.autoCreateColumnsFromModel;
this.autoCreateColumnsFromModel = autoCreateColumnsFromModel;
if (autoCreateColumnsFromModel) {
this.createDefaultColumnsFromModel();
}this.firePropertyChange$S$Z$Z("autoCreateColumnsFromModel", old, autoCreateColumnsFromModel);
}});

Clazz.newMethod$(C$, 'getAutoCreateColumnsFromModel', function () {
return this.autoCreateColumnsFromModel;
});

Clazz.newMethod$(C$, 'createDefaultColumnsFromModel', function () {
var m = this.getModel();
if (m != null ) {
var cm = this.getColumnModel();
while (cm.getColumnCount() > 0){
cm.removeColumn$javax_swing_table_TableColumn(cm.getColumn$I(0));
}
for (var i = 0; i < m.getColumnCount(); i++) {
var newColumn = Clazz.new((I$[16] || (I$[16]=Clazz.load('javax.swing.table.TableColumn'))).c$$I,[i]);
this.addColumn$javax_swing_table_TableColumn(newColumn);
}
}});

Clazz.newMethod$(C$, 'setDefaultRenderer$Class$javax_swing_table_TableCellRenderer', function (columnClass, renderer) {
if (renderer != null ) {
this.defaultRenderersByColumnClass.put$O$O(columnClass, renderer);
} else {
this.defaultRenderersByColumnClass.remove$O(columnClass);
}});

Clazz.newMethod$(C$, 'getDefaultRenderer$Class', function (columnClass) {
if (columnClass == null ) {
return null;
} else {
var renderer = this.defaultRenderersByColumnClass.get$O(columnClass);
if (renderer != null ) {
return renderer;
} else {
var c = null;
{
c = columnClass.getSuperclass && columnClass.getSuperclass();
}if (c == null  && columnClass !== Clazz.getClass(java.lang.Object)  ) {
c = Clazz.getClass(java.lang.Object);
}return this.getDefaultRenderer$Class(c);
}}});

Clazz.newMethod$(C$, 'setDefaultEditor$Class$javax_swing_table_TableCellEditor', function (columnClass, editor) {
if (editor != null ) {
this.defaultEditorsByColumnClass.put$O$O(columnClass, editor);
} else {
this.defaultEditorsByColumnClass.remove$O(columnClass);
}});

Clazz.newMethod$(C$, 'getDefaultEditor$Class', function (columnClass) {
if (columnClass == null ) {
return null;
} else {
var editor = this.defaultEditorsByColumnClass.get$O(columnClass);
if (editor != null ) {
return editor;
} else {
var c = null;
{
c = columnClass.getSuperclass && columnClass.getSuperclass();
}if (c == null  && columnClass !== Clazz.getClass(java.lang.Object)  ) {
c = Clazz.getClass(java.lang.Object);
}return this.getDefaultEditor$Class(c);
}}});

Clazz.newMethod$(C$, 'setDragEnabled$Z', function (b) {
this.dragEnabled = b;
});

Clazz.newMethod$(C$, 'getDragEnabled', function () {
return this.dragEnabled;
});

Clazz.newMethod$(C$, 'setDropMode$javax_swing_DropMode', function (dropMode) {
if (dropMode != null ) {
switch (dropMode) {
case P$.DropMode.USE_SELECTION:
case P$.DropMode.ON:
case P$.DropMode.INSERT:
case P$.DropMode.INSERT_ROWS:
case P$.DropMode.INSERT_COLS:
case P$.DropMode.ON_OR_INSERT:
case P$.DropMode.ON_OR_INSERT_ROWS:
case P$.DropMode.ON_OR_INSERT_COLS:
this.dropMode = dropMode;
return;
}
}throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[dropMode + ": Unsupported drop mode for table"]);
});

Clazz.newMethod$(C$, 'getDropMode', function () {
return this.dropMode;
});

Clazz.newMethod$(C$, 'setAutoCreateRowSorter$Z', function (autoCreateRowSorter) {
var oldValue = this.autoCreateRowSorter;
this.autoCreateRowSorter = autoCreateRowSorter;
if (autoCreateRowSorter) {
this.setRowSorter$javax_swing_RowSorter(Clazz.new((I$[17] || (I$[17]=Clazz.load('javax.swing.table.TableRowSorter'))).c$$TM,[this.getModel()]));
}this.firePropertyChange$S$Z$Z("autoCreateRowSorter", oldValue, autoCreateRowSorter);
});

Clazz.newMethod$(C$, 'getAutoCreateRowSorter', function () {
return this.autoCreateRowSorter;
});

Clazz.newMethod$(C$, 'setUpdateSelectionOnSort$Z', function (update) {
if (this.updateSelectionOnSort != update ) {
this.updateSelectionOnSort = update;
this.firePropertyChange$S$Z$Z("updateSelectionOnSort", !update, update);
}});

Clazz.newMethod$(C$, 'getUpdateSelectionOnSort', function () {
return this.updateSelectionOnSort;
});

Clazz.newMethod$(C$, 'setRowSorter$javax_swing_RowSorter', function (sorter) {
var oldRowSorter = null;
if (this.sortManager != null ) {
oldRowSorter = this.sortManager.sorter;
this.sortManager.dispose();
this.sortManager = null;
}this.rowModel = null;
p$.clearSelectionAndLeadAnchor.apply(this, []);
if (sorter != null ) {
this.sortManager = Clazz.new((I$[18] || (I$[18]=Clazz.load(Clazz.load('javax.swing.JTable').SortManager))).c$$javax_swing_RowSorter, [this, null, sorter]);
}this.resizeAndRepaint();
this.firePropertyChange$S$O$O("rowSorter", oldRowSorter, sorter);
this.firePropertyChange$S$O$O("sorter", oldRowSorter, sorter);
});

Clazz.newMethod$(C$, 'getRowSorter', function () {
return (this.sortManager != null ) ? this.sortManager.sorter : null;
});

Clazz.newMethod$(C$, 'setSelectionMode$I', function (selectionMode) {
this.clearSelection();
this.getSelectionModel().setSelectionMode$I(selectionMode);
this.getColumnModel().getSelectionModel().setSelectionMode$I(selectionMode);
});

Clazz.newMethod$(C$, 'setRowSelectionAllowed$Z', function (rowSelectionAllowed) {
var old = this.rowSelectionAllowed;
this.rowSelectionAllowed = rowSelectionAllowed;
if (old != rowSelectionAllowed ) {
this.repaint();
}this.firePropertyChange$S$Z$Z("rowSelectionAllowed", old, rowSelectionAllowed);
});

Clazz.newMethod$(C$, 'getRowSelectionAllowed', function () {
return this.rowSelectionAllowed;
});

Clazz.newMethod$(C$, 'setColumnSelectionAllowed$Z', function (columnSelectionAllowed) {
var old = this.columnModel.getColumnSelectionAllowed();
this.columnModel.setColumnSelectionAllowed$Z(columnSelectionAllowed);
if (old != columnSelectionAllowed ) {
this.repaint();
}this.firePropertyChange$S$Z$Z("columnSelectionAllowed", old, columnSelectionAllowed);
});

Clazz.newMethod$(C$, 'getColumnSelectionAllowed', function () {
return this.columnModel.getColumnSelectionAllowed();
});

Clazz.newMethod$(C$, 'setCellSelectionEnabled$Z', function (cellSelectionEnabled) {
this.setRowSelectionAllowed$Z(cellSelectionEnabled);
this.setColumnSelectionAllowed$Z(cellSelectionEnabled);
var old = this.cellSelectionEnabled;
this.cellSelectionEnabled = cellSelectionEnabled;
this.firePropertyChange$S$Z$Z("cellSelectionEnabled", old, cellSelectionEnabled);
});

Clazz.newMethod$(C$, 'getCellSelectionEnabled', function () {
return this.getRowSelectionAllowed() && this.getColumnSelectionAllowed() ;
});

Clazz.newMethod$(C$, 'selectAll', function () {
if (this.isEditing()) {
this.removeEditor();
}if (this.getRowCount() > 0 && this.getColumnCount() > 0 ) {
var oldLead;
var oldAnchor;
var selModel;
selModel = this.selectionModel;
selModel.setValueIsAdjusting$Z(true);
oldLead = p$.getAdjustedIndex$I$Z.apply(this, [selModel.getLeadSelectionIndex(), true]);
oldAnchor = p$.getAdjustedIndex$I$Z.apply(this, [selModel.getAnchorSelectionIndex(), true]);
this.setRowSelectionInterval$I$I(0, this.getRowCount() - 1);
(I$[2] || (I$[2]=Clazz.load('sun.swing.SwingUtilities2'))).setLeadAnchorWithoutSelection$javax_swing_ListSelectionModel$I$I(selModel, oldLead, oldAnchor);
selModel.setValueIsAdjusting$Z(false);
selModel = this.columnModel.getSelectionModel();
selModel.setValueIsAdjusting$Z(true);
oldLead = p$.getAdjustedIndex$I$Z.apply(this, [selModel.getLeadSelectionIndex(), false]);
oldAnchor = p$.getAdjustedIndex$I$Z.apply(this, [selModel.getAnchorSelectionIndex(), false]);
this.setColumnSelectionInterval$I$I(0, this.getColumnCount() - 1);
(I$[2] || (I$[2]=Clazz.load('sun.swing.SwingUtilities2'))).setLeadAnchorWithoutSelection$javax_swing_ListSelectionModel$I$I(selModel, oldLead, oldAnchor);
selModel.setValueIsAdjusting$Z(false);
}});

Clazz.newMethod$(C$, 'clearSelection', function () {
this.selectionModel.clearSelection();
this.columnModel.getSelectionModel().clearSelection();
});

Clazz.newMethod$(C$, 'clearSelectionAndLeadAnchor', function () {
this.selectionModel.setValueIsAdjusting$Z(true);
this.columnModel.getSelectionModel().setValueIsAdjusting$Z(true);
this.clearSelection();
this.selectionModel.setAnchorSelectionIndex$I(-1);
this.selectionModel.setLeadSelectionIndex$I(-1);
this.columnModel.getSelectionModel().setAnchorSelectionIndex$I(-1);
this.columnModel.getSelectionModel().setLeadSelectionIndex$I(-1);
this.selectionModel.setValueIsAdjusting$Z(false);
this.columnModel.getSelectionModel().setValueIsAdjusting$Z(false);
});

Clazz.newMethod$(C$, 'getAdjustedIndex$I$Z', function (index, row) {
var compare = row ? this.getRowCount() : this.getColumnCount();
return index < compare ? index : -1;
});

Clazz.newMethod$(C$, 'boundRow$I', function (row) {
if (row < 0 || row >= this.getRowCount() ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Row index out of range"]);
}return row;
});

Clazz.newMethod$(C$, 'boundColumn$I', function (col) {
if (col < 0 || col >= this.getColumnCount() ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Column index out of range"]);
}return col;
});

Clazz.newMethod$(C$, 'setRowSelectionInterval$I$I', function (index0, index1) {
this.selectionModel.setSelectionInterval$I$I(p$.boundRow$I.apply(this, [index0]), p$.boundRow$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'setColumnSelectionInterval$I$I', function (index0, index1) {
this.columnModel.getSelectionModel().setSelectionInterval$I$I(p$.boundColumn$I.apply(this, [index0]), p$.boundColumn$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'addRowSelectionInterval$I$I', function (index0, index1) {
this.selectionModel.addSelectionInterval$I$I(p$.boundRow$I.apply(this, [index0]), p$.boundRow$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'addColumnSelectionInterval$I$I', function (index0, index1) {
this.columnModel.getSelectionModel().addSelectionInterval$I$I(p$.boundColumn$I.apply(this, [index0]), p$.boundColumn$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'removeRowSelectionInterval$I$I', function (index0, index1) {
this.selectionModel.removeSelectionInterval$I$I(p$.boundRow$I.apply(this, [index0]), p$.boundRow$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'removeColumnSelectionInterval$I$I', function (index0, index1) {
this.columnModel.getSelectionModel().removeSelectionInterval$I$I(p$.boundColumn$I.apply(this, [index0]), p$.boundColumn$I.apply(this, [index1]));
});

Clazz.newMethod$(C$, 'getSelectedRow', function () {
return this.selectionModel.getMinSelectionIndex();
});

Clazz.newMethod$(C$, 'getSelectedColumn', function () {
return this.columnModel.getSelectionModel().getMinSelectionIndex();
});

Clazz.newMethod$(C$, 'getSelectedRows', function () {
var iMin = this.selectionModel.getMinSelectionIndex();
var iMax = this.selectionModel.getMaxSelectionIndex();
if ((iMin == -1) || (iMax == -1) ) {
return  Clazz.newArray$(Integer.TYPE, [0]);
}var rvTmp =  Clazz.newArray$(Integer.TYPE, [1 + (iMax - iMin)]);
var n = 0;
for (var i = iMin; i <= iMax; i++) {
if (this.selectionModel.isSelectedIndex$I(i)) {
rvTmp[n++] = i;
}}
var rv =  Clazz.newArray$(Integer.TYPE, [n]);
System.arraycopy(rvTmp, 0, rv, 0, n);
return rv;
});

Clazz.newMethod$(C$, 'getSelectedColumns', function () {
return this.columnModel.getSelectedColumns();
});

Clazz.newMethod$(C$, 'getSelectedRowCount', function () {
var iMin = this.selectionModel.getMinSelectionIndex();
var iMax = this.selectionModel.getMaxSelectionIndex();
var count = 0;
for (var i = iMin; i <= iMax; i++) {
if (this.selectionModel.isSelectedIndex$I(i)) {
count++;
}}
return count;
});

Clazz.newMethod$(C$, 'getSelectedColumnCount', function () {
return this.columnModel.getSelectedColumnCount();
});

Clazz.newMethod$(C$, 'isRowSelected$I', function (row) {
return this.selectionModel.isSelectedIndex$I(row);
});

Clazz.newMethod$(C$, 'isColumnSelected$I', function (column) {
return this.columnModel.getSelectionModel().isSelectedIndex$I(column);
});

Clazz.newMethod$(C$, 'isCellSelected$I$I', function (row, column) {
if (!this.getRowSelectionAllowed() && !this.getColumnSelectionAllowed() ) {
return false;
}return (!this.getRowSelectionAllowed() || this.isRowSelected$I(row) ) && (!this.getColumnSelectionAllowed() || this.isColumnSelected$I(column) ) ;
});

Clazz.newMethod$(C$, 'changeSelectionModel$javax_swing_ListSelectionModel$I$Z$Z$Z$I$Z', function (sm, index, toggle, extend, selected, anchor, anchorSelected) {
if (extend) {
if (toggle) {
if (anchorSelected) {
sm.addSelectionInterval$I$I(anchor, index);
} else {
sm.removeSelectionInterval$I$I(anchor, index);
if (Boolean.TRUE === this.getClientProperty$O("Table.isFileList") ) {
sm.addSelectionInterval$I$I(index, index);
sm.setAnchorSelectionIndex$I(anchor);
}}} else {
sm.setSelectionInterval$I$I(anchor, index);
}} else {
if (toggle) {
if (selected) {
sm.removeSelectionInterval$I$I(index, index);
} else {
sm.addSelectionInterval$I$I(index, index);
}} else {
sm.setSelectionInterval$I$I(index, index);
}}});

Clazz.newMethod$(C$, 'changeSelection$I$I$Z$Z', function (rowIndex, columnIndex, toggle, extend) {
var rsm = this.getSelectionModel();
var csm = this.getColumnModel().getSelectionModel();
var anchorRow = p$.getAdjustedIndex$I$Z.apply(this, [rsm.getAnchorSelectionIndex(), true]);
var anchorCol = p$.getAdjustedIndex$I$Z.apply(this, [csm.getAnchorSelectionIndex(), false]);
var anchorSelected = true;
if (anchorRow == -1) {
if (this.getRowCount() > 0) {
anchorRow = 0;
}anchorSelected = false;
}if (anchorCol == -1) {
if (this.getColumnCount() > 0) {
anchorCol = 0;
}anchorSelected = false;
}var selected = this.isCellSelected$I$I(rowIndex, columnIndex);
anchorSelected = anchorSelected && this.isCellSelected$I$I(anchorRow, anchorCol) ;
p$.changeSelectionModel$javax_swing_ListSelectionModel$I$Z$Z$Z$I$Z.apply(this, [csm, columnIndex, toggle, extend, selected, anchorCol, anchorSelected]);
p$.changeSelectionModel$javax_swing_ListSelectionModel$I$Z$Z$Z$I$Z.apply(this, [rsm, rowIndex, toggle, extend, selected, anchorRow, anchorSelected]);
if (this.getAutoscrolls()) {
var cellRect = this.getCellRect$I$I$Z(rowIndex, columnIndex, false);
if (cellRect != null ) {
this.scrollRectToVisible$java_awt_Rectangle(cellRect);
}}});

Clazz.newMethod$(C$, 'getSelectionForeground', function () {
return this.selectionForeground;
});

Clazz.newMethod$(C$, 'setSelectionForeground$java_awt_Color', function (selectionForeground) {
var old = this.selectionForeground;
this.selectionForeground = selectionForeground;
this.firePropertyChange$S$O$O("selectionForeground", old, selectionForeground);
if (!selectionForeground.equals$O(old)) {
this.repaint();
}});

Clazz.newMethod$(C$, 'getSelectionBackground', function () {
return this.selectionBackground;
});

Clazz.newMethod$(C$, 'setSelectionBackground$java_awt_Color', function (selectionBackground) {
var old = this.selectionBackground;
this.selectionBackground = selectionBackground;
this.firePropertyChange$S$O$O("selectionBackground", old, selectionBackground);
if (!selectionBackground.equals$O(old)) {
this.repaint();
}});

Clazz.newMethod$(C$, 'getColumn$O', function (identifier) {
var cm = this.getColumnModel();
var columnIndex = cm.getColumnIndex$O(identifier);
return cm.getColumn$I(columnIndex);
});

Clazz.newMethod$(C$, 'convertColumnIndexToModel$I', function (viewColumnIndex) {
if (viewColumnIndex < 0) {
return viewColumnIndex;
}return this.getColumnModel().getColumn$I(viewColumnIndex).getModelIndex();
});

Clazz.newMethod$(C$, 'convertColumnIndexToView$I', function (modelColumnIndex) {
if (modelColumnIndex < 0) {
return modelColumnIndex;
}var cm = this.getColumnModel();
for (var column = 0; column < this.getColumnCount(); column++) {
if (cm.getColumn$I(column).getModelIndex() == modelColumnIndex) {
return column;
}}
return -1;
});

Clazz.newMethod$(C$, 'convertRowIndexToView$I', function (modelRowIndex) {
var sorter = this.getRowSorter();
if (sorter != null ) {
return sorter.convertRowIndexToView$I(modelRowIndex);
}return modelRowIndex;
});

Clazz.newMethod$(C$, 'convertRowIndexToModel$I', function (viewRowIndex) {
var sorter = this.getRowSorter();
if (sorter != null ) {
return sorter.convertRowIndexToModel$I(viewRowIndex);
}return viewRowIndex;
});

Clazz.newMethod$(C$, 'getRowCount', function () {
var sorter = this.getRowSorter();
if (sorter != null ) {
return sorter.getViewRowCount();
}return this.getModel().getRowCount();
});

Clazz.newMethod$(C$, 'getColumnCount', function () {
return this.getColumnModel().getColumnCount();
});

Clazz.newMethod$(C$, 'getColumnName$I', function (column) {
return this.getModel().getColumnName$I(this.convertColumnIndexToModel$I(column));
});

Clazz.newMethod$(C$, 'getColumnClass$I', function (column) {
return this.getModel().getColumnClass$I(this.convertColumnIndexToModel$I(column));
});

Clazz.newMethod$(C$, 'getValueAt$I$I', function (row, column) {
return this.getModel().getValueAt$I$I(this.convertRowIndexToModel$I(row), this.convertColumnIndexToModel$I(column));
});

Clazz.newMethod$(C$, 'setValueAt$O$I$I', function (aValue, row, column) {
this.getModel().setValueAt$O$I$I(aValue, this.convertRowIndexToModel$I(row), this.convertColumnIndexToModel$I(column));
});

Clazz.newMethod$(C$, 'isCellEditable$I$I', function (row, column) {
return this.getModel().isCellEditable$I$I(this.convertRowIndexToModel$I(row), this.convertColumnIndexToModel$I(column));
});

Clazz.newMethod$(C$, 'addColumn$javax_swing_table_TableColumn', function (aColumn) {
if (aColumn.getHeaderValue() == null ) {
var modelColumn = aColumn.getModelIndex();
var columnName = this.getModel().getColumnName$I(modelColumn);
aColumn.setHeaderValue$O(columnName);
}this.getColumnModel().addColumn$javax_swing_table_TableColumn(aColumn);
});

Clazz.newMethod$(C$, 'removeColumn$javax_swing_table_TableColumn', function (aColumn) {
this.getColumnModel().removeColumn$javax_swing_table_TableColumn(aColumn);
});

Clazz.newMethod$(C$, 'moveColumn$I$I', function (column, targetColumn) {
this.getColumnModel().moveColumn$I$I(column, targetColumn);
});

Clazz.newMethod$(C$, 'columnAtPoint$java_awt_Point', function (point) {
var x = point.x;
if (!this.getComponentOrientation().isLeftToRight()) {
x = this.getWidth() - x - 1 ;
}return this.getColumnModel().getColumnIndexAtX$I(x);
});

Clazz.newMethod$(C$, 'rowAtPoint$java_awt_Point', function (point) {
var y = point.y;
var result = (this.rowModel == null ) ? ($i$[0] = y/this.getRowHeight(), $i$[0]) : this.rowModel.getIndex$I(y);
if (result < 0) {
return -1;
} else if (result >= this.getRowCount()) {
return -1;
} else {
return result;
}});

Clazz.newMethod$(C$, 'getCellRect$I$I$Z', function (row, column, includeSpacing) {
var r = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.awt.Rectangle'))));
var valid = true;
if (row < 0) {
valid = false;
} else if (row >= this.getRowCount()) {
r.y = this.getHeight();
valid = false;
} else {
r.height = this.getRowHeight$I(row);
r.y = (this.rowModel == null ) ? row * r.height : this.rowModel.getPosition$I(row);
}if (column < 0) {
if (!this.getComponentOrientation().isLeftToRight()) {
r.x = this.getWidth();
}valid = false;
} else if (column >= this.getColumnCount()) {
if (this.getComponentOrientation().isLeftToRight()) {
r.x = this.getWidth();
}valid = false;
} else {
var cm = this.getColumnModel();
if (this.getComponentOrientation().isLeftToRight()) {
for (var i = 0; i < column; i++) {
r.x = r.x+(cm.getColumn$I(i).getWidth());
}
} else {
for (var i = cm.getColumnCount() - 1; i > column; i--) {
r.x = r.x+(cm.getColumn$I(i).getWidth());
}
}r.width = cm.getColumn$I(column).getWidth();
}if (valid && !includeSpacing ) {
var rm = Math.min(this.getRowMargin(), r.height);
var cm = Math.min(this.getColumnModel().getColumnMargin(), r.width);
r.setBounds$I$I$I$I(r.x + ($i$[0] = cm/2, $i$[0]), r.y + ($i$[0] = rm/2, $i$[0]), r.width - cm, r.height - rm);
}return r;
});

Clazz.newMethod$(C$, 'viewIndexForColumn$javax_swing_table_TableColumn', function (aColumn) {
var cm = this.getColumnModel();
for (var column = 0; column < cm.getColumnCount(); column++) {
if (cm.getColumn$I(column) === aColumn ) {
return column;
}}
return -1;
});

Clazz.newMethod$(C$, 'doLayout', function () {
var resizingColumn = p$.getResizingColumn.apply(this, []);
if (resizingColumn == null ) {
p$.setWidthsFromPreferredWidths$Z.apply(this, [false]);
} else {
var columnIndex = p$.viewIndexForColumn$javax_swing_table_TableColumn.apply(this, [resizingColumn]);
var delta = this.getWidth() - this.getColumnModel().getTotalColumnWidth();
p$.accommodateDelta$I$I.apply(this, [columnIndex, delta]);
delta = this.getWidth() - this.getColumnModel().getTotalColumnWidth();
if (delta != 0) {
resizingColumn.setWidth$I(resizingColumn.getWidth() + delta);
}p$.setWidthsFromPreferredWidths$Z.apply(this, [true]);
}C$.superClazz.prototype.doLayout.apply(this, []);
});

Clazz.newMethod$(C$, 'getResizingColumn', function () {
return (this.tableHeader == null ) ? null : this.tableHeader.getResizingColumn();
});

Clazz.newMethod$(C$, 'sizeColumnsToFit$Z', function (lastColumnOnly) {
var oldAutoResizeMode = this.autoResizeMode;
this.setAutoResizeMode$I(lastColumnOnly ? 3 : 4);
this.sizeColumnsToFit$I(-1);
this.setAutoResizeMode$I(oldAutoResizeMode);
});

Clazz.newMethod$(C$, 'sizeColumnsToFit$I', function (resizingColumn) {
if (resizingColumn == -1) {
p$.setWidthsFromPreferredWidths$Z.apply(this, [false]);
} else {
if (this.autoResizeMode == 0) {
var aColumn = this.getColumnModel().getColumn$I(resizingColumn);
aColumn.setPreferredWidth$I(aColumn.getWidth());
} else {
var delta = this.getWidth() - this.getColumnModel().getTotalColumnWidth();
p$.accommodateDelta$I$I.apply(this, [resizingColumn, delta]);
p$.setWidthsFromPreferredWidths$Z.apply(this, [true]);
}}});

Clazz.newMethod$(C$, 'setWidthsFromPreferredWidths$Z', function (inverse) {
var totalWidth = this.getWidth();
var totalPreferred = this.getPreferredSize().width;
var target = !inverse ? totalWidth : totalPreferred;
var cm = this.columnModel;
var r = ((
(function(){var C$=Clazz.newClass$(P$, "JTable$2", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'javax.swing.JTable.Resizable3');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getElementCount', function () {
return this.$finals.cm.getColumnCount();
});

Clazz.newMethod$(C$, 'getLowerBoundAt$I', function (i) {
return this.$finals.cm.getColumn$I(i).getMinWidth();
});

Clazz.newMethod$(C$, 'getUpperBoundAt$I', function (i) {
return this.$finals.cm.getColumn$I(i).getMaxWidth();
});

Clazz.newMethod$(C$, 'getMidPointAt$I', function (i) {
if (!this.$finals.inverse) {
return this.$finals.cm.getColumn$I(i).getPreferredWidth();
} else {
return this.$finals.cm.getColumn$I(i).getWidth();
}});

Clazz.newMethod$(C$, 'setSizeAt$I$I', function (s, i) {
if (!this.$finals.inverse) {
this.$finals.cm.getColumn$I(i).setWidth$I(s);
} else {
this.$finals.cm.getColumn$I(i).setPreferredWidth$I(s);
}});
})()
), Clazz.new((I$[20] || (I$[20]=Clazz.load(P$.JTable$2))).$init$, [this, {cm: cm, inverse: inverse}]));
p$.adjustSizes$J$javax_swing_JTable_Resizable3$Z.apply(this, [target, r, inverse]);
});

Clazz.newMethod$(C$, 'accommodateDelta$I$I', function (resizingColumnIndex, delta) {
var columnCount = this.getColumnCount();
var from = resizingColumnIndex;
var to = columnCount;
switch (this.autoResizeMode) {
case 1:
from = from + 1;
to = Math.min(from + 1, columnCount);
break;
case 2:
from = from + 1;
to = columnCount;
break;
case 3:
from = columnCount - 1;
to = from + 1;
break;
case 4:
from = 0;
to = columnCount;
break;
default:
return;
}
var start = from;
var end = to;
var cm = this.columnModel;
var r = ((
(function(){var C$=Clazz.newClass$(P$, "JTable$3", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'javax.swing.JTable.Resizable3');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getElementCount', function () {
return this.$finals.end - this.$finals.start;
});

Clazz.newMethod$(C$, 'getLowerBoundAt$I', function (i) {
return this.$finals.cm.getColumn$I(i + this.$finals.start).getMinWidth();
});

Clazz.newMethod$(C$, 'getUpperBoundAt$I', function (i) {
return this.$finals.cm.getColumn$I(i + this.$finals.start).getMaxWidth();
});

Clazz.newMethod$(C$, 'getMidPointAt$I', function (i) {
return this.$finals.cm.getColumn$I(i + this.$finals.start).getWidth();
});

Clazz.newMethod$(C$, 'setSizeAt$I$I', function (s, i) {
this.$finals.cm.getColumn$I(i + this.$finals.start).setWidth$I(s);
});
})()
), Clazz.new((I$[21] || (I$[21]=Clazz.load(P$.JTable$3))).$init$, [this, {end: end, start: start, cm: cm}]));
var totalWidth = 0;
for (var i = from; i < to; i++) {
var aColumn = this.columnModel.getColumn$I(i);
var input = aColumn.getWidth();
totalWidth = totalWidth + input;
}
p$.adjustSizes$J$javax_swing_JTable_Resizable3$Z.apply(this, [totalWidth + delta, r, false]);
return;
});

Clazz.newMethod$(C$, 'adjustSizes$J$javax_swing_JTable_Resizable3$Z', function (target, r, inverse) {
var N = r.getElementCount();
var totalPreferred = 0;
for (var i = 0; i < N; i++) {
totalPreferred = totalPreferred+(r.getMidPointAt$I(i));
}
var s;
if ((target < totalPreferred) == !inverse ) {
s = ((
(function(){var C$=Clazz.newClass$(P$, "JTable$4", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'javax.swing.JTable.Resizable2');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getElementCount', function () {
return this.$finals.r.getElementCount();
});

Clazz.newMethod$(C$, 'getLowerBoundAt$I', function (i) {
return this.$finals.r.getLowerBoundAt$I(i);
});

Clazz.newMethod$(C$, 'getUpperBoundAt$I', function (i) {
return this.$finals.r.getMidPointAt$I(i);
});

Clazz.newMethod$(C$, 'setSizeAt$I$I', function (newSize, i) {
this.$finals.r.setSizeAt$I$I(newSize, i);
});
})()
), Clazz.new((I$[22] || (I$[22]=Clazz.load(P$.JTable$4))).$init$, [this, {r: r}]));
} else {
s = ((
(function(){var C$=Clazz.newClass$(P$, "JTable$5", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'javax.swing.JTable.Resizable2');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getElementCount', function () {
return this.$finals.r.getElementCount();
});

Clazz.newMethod$(C$, 'getLowerBoundAt$I', function (i) {
return this.$finals.r.getMidPointAt$I(i);
});

Clazz.newMethod$(C$, 'getUpperBoundAt$I', function (i) {
return this.$finals.r.getUpperBoundAt$I(i);
});

Clazz.newMethod$(C$, 'setSizeAt$I$I', function (newSize, i) {
this.$finals.r.setSizeAt$I$I(newSize, i);
});
})()
), Clazz.new((I$[23] || (I$[23]=Clazz.load(P$.JTable$5))).$init$, [this, {r: r}]));
}p$.adjustSizes$J$javax_swing_JTable_Resizable2$Z.apply(this, [target, s, !inverse]);
});

Clazz.newMethod$(C$, 'adjustSizes$J$javax_swing_JTable_Resizable2$Z', function (target, r, limitToRange) {
var totalLowerBound = 0;
var totalUpperBound = 0;
for (var i = 0; i < r.getElementCount(); i++) {
totalLowerBound = totalLowerBound+(r.getLowerBoundAt$I(i));
totalUpperBound = totalUpperBound+(r.getUpperBoundAt$I(i));
}
if (limitToRange) {
target = Math.min(Math.max(totalLowerBound, target), totalUpperBound);
}for (var i = 0; i < r.getElementCount(); i++) {
var lowerBound = r.getLowerBoundAt$I(i);
var upperBound = r.getUpperBoundAt$I(i);
var newSize;
if (totalLowerBound == totalUpperBound) {
newSize = lowerBound;
} else {
var f = (target - totalLowerBound) / (totalUpperBound - totalLowerBound);
newSize = ($i$[0] = Math.round(lowerBound + f * (upperBound - lowerBound)), $i$[0]);
}r.setSizeAt$I$I(newSize, i);
target = target-(newSize);
totalLowerBound = totalLowerBound-(lowerBound);
totalUpperBound = totalUpperBound-(upperBound);
}
});

Clazz.newMethod$(C$, 'getToolTipText$java_awt_event_MouseEvent', function (event) {
var tip = null;
var p = event.getPoint();
var hitColumnIndex = this.columnAtPoint$java_awt_Point(p);
var hitRowIndex = this.rowAtPoint$java_awt_Point(p);
if ((hitColumnIndex != -1) && (hitRowIndex != -1) ) {
var renderer = this.getCellRenderer$I$I(hitRowIndex, hitColumnIndex);
var component = this.prepareRenderer$javax_swing_table_TableCellRenderer$I$I(renderer, hitRowIndex, hitColumnIndex);
if (Clazz.instanceOf(component, "javax.swing.JComponent")) {
var cellRect = this.getCellRect$I$I$Z(hitRowIndex, hitColumnIndex, false);
p.translate$I$I(-cellRect.x, -cellRect.y);
var newEvent = Clazz.new((I$[24] || (I$[24]=Clazz.load('java.awt.event.MouseEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$I,[component, event.getID(), event.getWhen(), event.getModifiers(), p.x, p.y, event.getXOnScreen(), event.getYOnScreen(), event.getClickCount(), event.isPopupTrigger(), 0]);
tip = (component).getToolTipText$java_awt_event_MouseEvent(newEvent);
}}if (tip == null ) tip = this.getToolTipText();
return tip;
});

Clazz.newMethod$(C$, 'setSurrendersFocusOnKeystroke$Z', function (surrendersFocusOnKeystroke) {
this.surrendersFocusOnKeystroke = surrendersFocusOnKeystroke;
});

Clazz.newMethod$(C$, 'getSurrendersFocusOnKeystroke', function () {
return this.surrendersFocusOnKeystroke;
});

Clazz.newMethod$(C$, 'editCellAt$I$I', function (row, column) {
return this.editCellAt$I$I$java_util_EventObject(row, column, null);
});

Clazz.newMethod$(C$, 'editCellAt$I$I$java_util_EventObject', function (row, column, e) {
if (this.cellEditor != null  && !this.cellEditor.stopCellEditing() ) {
return false;
}if (row < 0 || row >= this.getRowCount()  || column < 0  || column >= this.getColumnCount() ) {
return false;
}if (!this.isCellEditable$I$I(row, column)) return false;
if (this.editorRemover == null ) {
}var editor = this.getCellEditor$I$I(row, column);
if (editor != null  && editor.isCellEditable$java_util_EventObject(e) ) {
this.editorComp = this.prepareEditor$javax_swing_table_TableCellEditor$I$I(editor, row, column);
if (this.editorComp == null ) {
this.removeEditor();
return false;
}this.editorComp.setBounds$java_awt_Rectangle(this.getCellRect$I$I$Z(row, column, false));
this.add$java_awt_Component(this.editorComp);
this.editorComp.validate();
this.editorComp.repaint();
this.setCellEditor$javax_swing_table_TableCellEditor(editor);
this.setEditingRow$I(row);
this.setEditingColumn$I(column);
editor.addCellEditorListener$javax_swing_event_CellEditorListener(this);
return true;
}return false;
});

Clazz.newMethod$(C$, 'isEditing', function () {
return (this.cellEditor == null ) ? false : true;
});

Clazz.newMethod$(C$, 'getEditorComponent', function () {
return this.editorComp;
});

Clazz.newMethod$(C$, 'getEditingColumn', function () {
return this.editingColumn;
});

Clazz.newMethod$(C$, 'getEditingRow', function () {
return this.editingRow;
});

Clazz.newMethod$(C$, 'getUI', function () {
return this.ui;
});

Clazz.newMethod$(C$, 'setUI$javax_swing_plaf_TableUI', function (ui) {
if (this.ui !== ui ) {
C$.superClazz.prototype.setUI$javax_swing_plaf_ComponentUI.apply(this, [ui]);
this.repaint();
}});

Clazz.newMethod$(C$, 'updateUI', function () {
var cm = this.getColumnModel();
for (var column = 0; column < cm.getColumnCount(); column++) {
var aColumn = cm.getColumn$I(column);
(I$[25] || (I$[25]=Clazz.load('javax.swing.SwingUtilities'))).updateRendererOrEditorUI$O(aColumn.getCellRenderer());
(I$[25] || (I$[25]=Clazz.load('javax.swing.SwingUtilities'))).updateRendererOrEditorUI$O(aColumn.getCellEditor());
(I$[25] || (I$[25]=Clazz.load('javax.swing.SwingUtilities'))).updateRendererOrEditorUI$O(aColumn.getHeaderRenderer());
}
var defaultRenderers = this.defaultRenderersByColumnClass.elements();
while (defaultRenderers.hasMoreElements()){
(I$[25] || (I$[25]=Clazz.load('javax.swing.SwingUtilities'))).updateRendererOrEditorUI$O(defaultRenderers.nextElement());
}
var defaultEditors = this.defaultEditorsByColumnClass.elements();
while (defaultEditors.hasMoreElements()){
(I$[25] || (I$[25]=Clazz.load('javax.swing.SwingUtilities'))).updateRendererOrEditorUI$O(defaultEditors.nextElement());
}
if (this.tableHeader != null  && this.tableHeader.getParent() == null  ) {
this.tableHeader.updateUI();
}p$.configureEnclosingScrollPaneUI.apply(this, []);
C$.superClazz.prototype.updateUI.apply(this, []);
});

Clazz.newMethod$(C$, 'setModel$javax_swing_table_TableModel', function (dataModel) {
if (dataModel == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Cannot set a null TableModel"]);
}if (this.dataModel !== dataModel ) {
var old = this.dataModel;
if (old != null ) {
old.removeTableModelListener$javax_swing_event_TableModelListener(this);
}this.dataModel = dataModel;
dataModel.addTableModelListener$javax_swing_event_TableModelListener(this);
this.tableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[26] || (I$[26]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I,[dataModel, -1]));
this.firePropertyChange$S$O$O("model", old, dataModel);
if (this.getAutoCreateRowSorter()) {
this.setRowSorter$javax_swing_RowSorter(Clazz.new((I$[17] || (I$[17]=Clazz.load('javax.swing.table.TableRowSorter'))).c$$TM,[dataModel]));
}}});

Clazz.newMethod$(C$, 'getModel', function () {
return this.dataModel;
});

Clazz.newMethod$(C$, 'setColumnModel$javax_swing_table_TableColumnModel', function (columnModel) {
if (columnModel == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Cannot set a null ColumnModel"]);
}var old = this.columnModel;
if (columnModel !== old ) {
if (old != null ) {
old.removeColumnModelListener$javax_swing_event_TableColumnModelListener(this);
}this.columnModel = columnModel;
columnModel.addColumnModelListener$javax_swing_event_TableColumnModelListener(this);
if (this.tableHeader != null ) {
this.tableHeader.setColumnModel$javax_swing_table_TableColumnModel(columnModel);
}this.firePropertyChange$S$O$O("columnModel", old, columnModel);
this.resizeAndRepaint();
}});

Clazz.newMethod$(C$, 'getColumnModel', function () {
return this.columnModel;
});

Clazz.newMethod$(C$, 'setSelectionModel$javax_swing_ListSelectionModel', function (newModel) {
if (newModel == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Cannot set a null SelectionModel"]);
}var oldModel = this.selectionModel;
if (newModel !== oldModel ) {
if (oldModel != null ) {
oldModel.removeListSelectionListener$javax_swing_event_ListSelectionListener(this);
}this.selectionModel = newModel;
newModel.addListSelectionListener$javax_swing_event_ListSelectionListener(this);
this.firePropertyChange$S$O$O("selectionModel", oldModel, newModel);
this.repaint();
}});

Clazz.newMethod$(C$, 'getSelectionModel', function () {
return this.selectionModel;
});

Clazz.newMethod$(C$, 'sorterChanged$javax_swing_event_RowSorterEvent', function (e) {
if (e.getType() === (I$[27] || (I$[27]=Clazz.load(Clazz.load('javax.swing.event.RowSorterEvent').Type))).SORT_ORDER_CHANGED ) {
var header = this.getTableHeader();
if (header != null ) {
header.repaint();
}} else if (e.getType() === (I$[27] || (I$[27]=Clazz.load(Clazz.load('javax.swing.event.RowSorterEvent').Type))).SORTED ) {
this.$sorterChanged = true;
if (!this.ignoreSortChange) {
p$.sortedTableChanged$javax_swing_event_RowSorterEvent$javax_swing_event_TableModelEvent.apply(this, [e, null]);
}}});

Clazz.newMethod$(C$, 'sortedTableChanged$javax_swing_event_RowSorterEvent$javax_swing_event_TableModelEvent', function (sortedEvent, e) {
var editingModelIndex = -1;
var change = (e != null ) ? Clazz.new((I$[28] || (I$[28]=Clazz.load(Clazz.load('javax.swing.JTable').ModelChange))).c$$javax_swing_event_TableModelEvent, [this, null, e]) : null;
if ((change == null  || !change.allRowsChanged ) && this.editingRow != -1 ) {
editingModelIndex = p$.convertRowIndexToModel$javax_swing_event_RowSorterEvent$I.apply(this, [sortedEvent, this.editingRow]);
}this.sortManager.prepareForChange$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange(sortedEvent, change);
if (e != null ) {
if (change.type == 0) {
p$.repaintSortedRows$javax_swing_JTable_ModelChange.apply(this, [change]);
}p$.notifySorter$javax_swing_JTable_ModelChange.apply(this, [change]);
if (change.type != 0) {
this.$sorterChanged = true;
}} else {
this.$sorterChanged = true;
}this.sortManager.processChange$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange$Z(sortedEvent, change, this.$sorterChanged);
if (this.$sorterChanged) {
if (this.editingRow != -1) {
var newIndex = (editingModelIndex == -1) ? -1 : p$.convertRowIndexToView$I$javax_swing_JTable_ModelChange.apply(this, [editingModelIndex, change]);
p$.restoreSortingEditingRow$I.apply(this, [newIndex]);
}if (e == null  || change.type != 0 ) {
this.resizeAndRepaint();
}}if (change != null  && change.allRowsChanged ) {
p$.clearSelectionAndLeadAnchor.apply(this, []);
this.resizeAndRepaint();
}});

Clazz.newMethod$(C$, 'repaintSortedRows$javax_swing_JTable_ModelChange', function (change) {
if (change.startModelIndex > change.endModelIndex || change.startModelIndex + 10 < change.endModelIndex ) {
this.repaint();
return;
}var eventColumn = change.event.getColumn();
var columnViewIndex = eventColumn;
if (columnViewIndex == -1) {
columnViewIndex = 0;
} else {
columnViewIndex = this.convertColumnIndexToView$I(columnViewIndex);
if (columnViewIndex == -1) {
return;
}}var modelIndex = change.startModelIndex;
while (modelIndex <= change.endModelIndex){
var viewIndex = this.convertRowIndexToView$I(modelIndex++);
if (viewIndex != -1) {
var dirty = this.getCellRect$I$I$Z(viewIndex, columnViewIndex, false);
var x = dirty.x;
var w = dirty.width;
if (eventColumn == -1) {
x = 0;
w = this.getWidth();
}this.repaint$I$I$I$I(x, dirty.y, w, dirty.height);
}}
});

Clazz.newMethod$(C$, 'restoreSortingSelection$IA$I$javax_swing_JTable_ModelChange', function (selection, lead, change) {
for (var i = selection.length - 1; i >= 0; i--) {
selection[i] = p$.convertRowIndexToView$I$javax_swing_JTable_ModelChange.apply(this, [selection[i], change]);
}
lead = p$.convertRowIndexToView$I$javax_swing_JTable_ModelChange.apply(this, [lead, change]);
if (selection.length == 0 || (selection.length == 1 && selection[0] == this.getSelectedRow() ) ) {
return;
}this.selectionModel.setValueIsAdjusting$Z(true);
this.selectionModel.clearSelection();
for (var i = selection.length - 1; i >= 0; i--) {
if (selection[i] != -1) {
this.selectionModel.addSelectionInterval$I$I(selection[i], selection[i]);
}}
(I$[2] || (I$[2]=Clazz.load('sun.swing.SwingUtilities2'))).setLeadAnchorWithoutSelection$javax_swing_ListSelectionModel$I$I(this.selectionModel, lead, lead);
this.selectionModel.setValueIsAdjusting$Z(false);
});

Clazz.newMethod$(C$, 'restoreSortingEditingRow$I', function (editingRow) {
if (editingRow == -1) {
var editor = this.getCellEditor();
if (editor != null ) {
editor.cancelCellEditing();
if (this.getCellEditor() != null ) {
this.removeEditor();
}}} else {
this.editingRow = editingRow;
this.repaint();
}});

Clazz.newMethod$(C$, 'notifySorter$javax_swing_JTable_ModelChange', function (change) {
try {
this.ignoreSortChange = true;
this.$sorterChanged = false;
switch (change.type) {
case 0:
if (change.event.getLastRow() == 2147483647) {
this.sortManager.sorter.allRowsChanged();
} else if (change.event.getColumn() == -1) {
this.sortManager.sorter.rowsUpdated$I$I(change.startModelIndex, change.endModelIndex);
} else {
this.sortManager.sorter.rowsUpdated$I$I$I(change.startModelIndex, change.endModelIndex, change.event.getColumn());
}break;
case 1:
this.sortManager.sorter.rowsInserted$I$I(change.startModelIndex, change.endModelIndex);
break;
case -1:
this.sortManager.sorter.rowsDeleted$I$I(change.startModelIndex, change.endModelIndex);
break;
}
} finally {
this.ignoreSortChange = false;
}
});

Clazz.newMethod$(C$, 'convertRowIndexToView$I$javax_swing_JTable_ModelChange', function (modelIndex, change) {
if (modelIndex < 0) {
return -1;
}if (change != null  && modelIndex >= change.startModelIndex ) {
if (change.type == 1) {
if (modelIndex + change.length >= change.modelRowCount) {
return -1;
}return this.sortManager.sorter.convertRowIndexToView$I(modelIndex + change.length);
} else if (change.type == -1) {
if (modelIndex <= change.endModelIndex) {
return -1;
} else {
if (modelIndex - change.length >= change.modelRowCount) {
return -1;
}return this.sortManager.sorter.convertRowIndexToView$I(modelIndex - change.length);
}}}if (modelIndex >= this.getModel().getRowCount()) {
return -1;
}return this.sortManager.sorter.convertRowIndexToView$I(modelIndex);
});

Clazz.newMethod$(C$, 'convertSelectionToModel$javax_swing_event_RowSorterEvent', function (e) {
var selection = this.getSelectedRows();
for (var i = selection.length - 1; i >= 0; i--) {
selection[i] = p$.convertRowIndexToModel$javax_swing_event_RowSorterEvent$I.apply(this, [e, selection[i]]);
}
return selection;
});

Clazz.newMethod$(C$, 'convertRowIndexToModel$javax_swing_event_RowSorterEvent$I', function (e, viewIndex) {
if (e != null ) {
if (e.getPreviousRowCount() == 0) {
return viewIndex;
}return e.convertPreviousRowIndexToModel$I(viewIndex);
}if (viewIndex < 0 || viewIndex >= this.getRowCount() ) {
return -1;
}return this.convertRowIndexToModel$I(viewIndex);
});

Clazz.newMethod$(C$, 'tableChanged$javax_swing_event_TableModelEvent', function (e) {
if (e == null  || e.getFirstRow() == -1 ) {
p$.clearSelectionAndLeadAnchor.apply(this, []);
this.rowModel = null;
if (this.sortManager != null ) {
try {
this.ignoreSortChange = true;
this.sortManager.sorter.modelStructureChanged();
} finally {
this.ignoreSortChange = false;
}
this.sortManager.allChanged();
}if (this.getAutoCreateColumnsFromModel()) {
this.createDefaultColumnsFromModel();
return;
}this.resizeAndRepaint();
return;
}if (this.sortManager != null ) {
p$.sortedTableChanged$javax_swing_event_RowSorterEvent$javax_swing_event_TableModelEvent.apply(this, [null, e]);
return;
}if (this.rowModel != null ) {
this.repaint();
}if (e.getType() == 1) {
p$.tableRowsInserted$javax_swing_event_TableModelEvent.apply(this, [e]);
return;
}if (e.getType() == -1) {
p$.tableRowsDeleted$javax_swing_event_TableModelEvent.apply(this, [e]);
return;
}var modelColumn = e.getColumn();
var start = e.getFirstRow();
var end = e.getLastRow();
var dirtyRegion;
if (modelColumn == -1) {
dirtyRegion = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[0, start * this.getRowHeight(), this.getColumnModel().getTotalColumnWidth(), 0]);
} else {
var column = this.convertColumnIndexToView$I(modelColumn);
dirtyRegion = this.getCellRect$I$I$Z(start, column, false);
}if (end != 2147483647) {
dirtyRegion.height = (end - start + 1) * this.getRowHeight();
this.repaint$I$I$I$I(dirtyRegion.x, dirtyRegion.y, dirtyRegion.width, dirtyRegion.height);
} else {
p$.clearSelectionAndLeadAnchor.apply(this, []);
this.resizeAndRepaint();
this.rowModel = null;
}});

Clazz.newMethod$(C$, 'tableRowsInserted$javax_swing_event_TableModelEvent', function (e) {
var start = e.getFirstRow();
var end = e.getLastRow();
if (start < 0) {
start = 0;
}if (end < 0) {
end = this.getRowCount() - 1;
}var length = end - start + 1;
this.selectionModel.insertIndexInterval$I$I$Z(start, length, true);
if (this.rowModel != null ) {
this.rowModel.insertEntries$I$I$I(start, length, this.getRowHeight());
}var rh = this.getRowHeight();
var drawRect = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[0, start * rh, this.getColumnModel().getTotalColumnWidth(), (this.getRowCount() - start) * rh]);
this.revalidate();
this.repaint$java_awt_Rectangle(drawRect);
});

Clazz.newMethod$(C$, 'tableRowsDeleted$javax_swing_event_TableModelEvent', function (e) {
var start = e.getFirstRow();
var end = e.getLastRow();
if (start < 0) {
start = 0;
}if (end < 0) {
end = this.getRowCount() - 1;
}var deletedCount = end - start + 1;
var previousRowCount = this.getRowCount() + deletedCount;
this.selectionModel.removeIndexInterval$I$I(start, end);
if (this.rowModel != null ) {
this.rowModel.removeEntries$I$I(start, deletedCount);
}var rh = this.getRowHeight();
var drawRect = Clazz.new((I$[19] || (I$[19]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[0, start * rh, this.getColumnModel().getTotalColumnWidth(), (previousRowCount - start) * rh]);
this.revalidate();
this.repaint$java_awt_Rectangle(drawRect);
});

Clazz.newMethod$(C$, 'columnAdded$javax_swing_event_TableColumnModelEvent', function (e) {
if (this.isEditing()) {
this.removeEditor();
}this.resizeAndRepaint();
});

Clazz.newMethod$(C$, 'columnRemoved$javax_swing_event_TableColumnModelEvent', function (e) {
if (this.isEditing()) {
this.removeEditor();
}this.resizeAndRepaint();
});

Clazz.newMethod$(C$, 'columnMoved$javax_swing_event_TableColumnModelEvent', function (e) {
if (this.isEditing()) {
this.removeEditor();
}this.repaint();
});

Clazz.newMethod$(C$, 'columnMarginChanged$javax_swing_event_ChangeEvent', function (e) {
if (this.isEditing()) {
this.removeEditor();
}var resizingColumn = p$.getResizingColumn.apply(this, []);
if (resizingColumn != null  && this.autoResizeMode == 0 ) {
resizingColumn.setPreferredWidth$I(resizingColumn.getWidth());
}this.resizeAndRepaint();
});

Clazz.newMethod$(C$, 'limit$I$I$I', function (i, a, b) {
return Math.min(b, Math.max(i, a));
});

Clazz.newMethod$(C$, 'columnSelectionChanged$javax_swing_event_ListSelectionEvent', function (e) {
var isAdjusting = e.getValueIsAdjusting();
if (this.columnSelectionAdjusting && !isAdjusting ) {
this.columnSelectionAdjusting = false;
return;
}this.columnSelectionAdjusting = isAdjusting;
if (this.getRowCount() <= 0 || this.getColumnCount() <= 0 ) {
return;
}var firstIndex = p$.limit$I$I$I.apply(this, [e.getFirstIndex(), 0, this.getColumnCount() - 1]);
var lastIndex = p$.limit$I$I$I.apply(this, [e.getLastIndex(), 0, this.getColumnCount() - 1]);
var minRow = 0;
var maxRow = this.getRowCount() - 1;
if (this.getRowSelectionAllowed()) {
minRow = this.selectionModel.getMinSelectionIndex();
maxRow = this.selectionModel.getMaxSelectionIndex();
var leadRow = p$.getAdjustedIndex$I$Z.apply(this, [this.selectionModel.getLeadSelectionIndex(), true]);
if (minRow == -1 || maxRow == -1 ) {
if (leadRow == -1) {
return;
}minRow = maxRow = leadRow;
} else {
if (leadRow != -1) {
minRow = Math.min(minRow, leadRow);
maxRow = Math.max(maxRow, leadRow);
}}}var firstColumnRect = this.getCellRect$I$I$Z(minRow, firstIndex, false);
var lastColumnRect = this.getCellRect$I$I$Z(maxRow, lastIndex, false);
var dirtyRegion = firstColumnRect.union$java_awt_Rectangle(lastColumnRect);
this.repaint$java_awt_Rectangle(dirtyRegion);
});

Clazz.newMethod$(C$, 'valueChanged$javax_swing_event_ListSelectionEvent', function (e) {
if (this.sortManager != null ) {
this.sortManager.viewSelectionChanged$javax_swing_event_ListSelectionEvent(e);
}var isAdjusting = e.getValueIsAdjusting();
if (this.rowSelectionAdjusting && !isAdjusting ) {
this.rowSelectionAdjusting = false;
return;
}this.rowSelectionAdjusting = isAdjusting;
if (this.getRowCount() <= 0 || this.getColumnCount() <= 0 ) {
return;
}var firstIndex = p$.limit$I$I$I.apply(this, [e.getFirstIndex(), 0, this.getRowCount() - 1]);
var lastIndex = p$.limit$I$I$I.apply(this, [e.getLastIndex(), 0, this.getRowCount() - 1]);
var firstRowRect = this.getCellRect$I$I$Z(firstIndex, 0, false);
var lastRowRect = this.getCellRect$I$I$Z(lastIndex, this.getColumnCount() - 1, false);
var dirtyRegion = firstRowRect.union$java_awt_Rectangle(lastRowRect);
this.repaint$java_awt_Rectangle(dirtyRegion);
});

Clazz.newMethod$(C$, 'editingStopped$javax_swing_event_ChangeEvent', function (e) {
var editor = this.getCellEditor();
if (editor != null ) {
var value = editor.getCellEditorValue();
this.setValueAt$O$I$I(value, this.editingRow, this.editingColumn);
this.removeEditor();
}});

Clazz.newMethod$(C$, 'editingCanceled$javax_swing_event_ChangeEvent', function (e) {
this.removeEditor();
});

Clazz.newMethod$(C$, 'setPreferredScrollableViewportSize$java_awt_Dimension', function (size) {
this.preferredViewportSize = size;
});

Clazz.newMethod$(C$, 'getPreferredScrollableViewportSize', function () {
return this.preferredViewportSize;
});

Clazz.newMethod$(C$, 'getScrollableUnitIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
var leadingRow;
var leadingCol;
var leadingCellRect;
var leadingVisibleEdge;
var leadingCellEdge;
var leadingCellSize;
leadingRow = p$.getLeadingRow$java_awt_Rectangle.apply(this, [visibleRect]);
leadingCol = p$.getLeadingCol$java_awt_Rectangle.apply(this, [visibleRect]);
if (orientation == 1 && leadingRow < 0 ) {
return this.getRowHeight();
} else if (orientation == 0 && leadingCol < 0 ) {
return 100;
}leadingCellRect = this.getCellRect$I$I$Z(leadingRow, leadingCol, true);
leadingVisibleEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
leadingCellEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [leadingCellRect, orientation]);
if (orientation == 1) {
leadingCellSize = leadingCellRect.height;
} else {
leadingCellSize = leadingCellRect.width;
}if (leadingVisibleEdge == leadingCellEdge) {
if (direction < 0) {
var retVal = 0;
if (orientation == 1) {
while (--leadingRow >= 0){
retVal = this.getRowHeight$I(leadingRow);
if (retVal != 0) {
break;
}}
} else {
while (--leadingCol >= 0){
retVal = this.getCellRect$I$I$Z(leadingRow, leadingCol, true).width;
if (retVal != 0) {
break;
}}
}return retVal;
} else {
return leadingCellSize;
}} else {
var hiddenAmt = Math.abs(leadingVisibleEdge - leadingCellEdge);
var visibleAmt = leadingCellSize - hiddenAmt;
if (direction > 0) {
return visibleAmt;
} else {
return hiddenAmt;
}}});

Clazz.newMethod$(C$, 'getScrollableBlockIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
if (this.getRowCount() == 0) {
if (1 == orientation) {
var rh = this.getRowHeight();
return (rh > 0) ? Math.max(rh, (($i$[0] = visibleRect.height/rh, $i$[0])) * rh) : visibleRect.height;
} else {
return visibleRect.width;
}}if (null == this.rowModel  && 1 == orientation ) {
var row = this.rowAtPoint$java_awt_Point(visibleRect.getLocation());
var col = this.columnAtPoint$java_awt_Point(visibleRect.getLocation());
var cellRect = this.getCellRect$I$I$Z(row, col, true);
if (cellRect.y == visibleRect.y) {
var rh = this.getRowHeight();
return Math.max(rh, (($i$[0] = visibleRect.height/rh, $i$[0])) * rh);
}}if (direction < 0) {
return p$.getPreviousBlockIncrement$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
} else {
return p$.getNextBlockIncrement$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
}});

Clazz.newMethod$(C$, 'getPreviousBlockIncrement$java_awt_Rectangle$I', function (visibleRect, orientation) {
var row;
var col;
var newEdge;
var newCellLoc;
var visibleLeadingEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
var leftToRight = this.getComponentOrientation().isLeftToRight();
var newLeadingEdge;
if (orientation == 1) {
newEdge = visibleLeadingEdge - visibleRect.height;
var x = visibleRect.x + (leftToRight ? 0 : visibleRect.width);
newCellLoc = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[x, newEdge]);
} else if (leftToRight) {
newEdge = visibleLeadingEdge - visibleRect.width;
newCellLoc = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[newEdge, visibleRect.y]);
} else {
newEdge = visibleLeadingEdge + visibleRect.width;
newCellLoc = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[newEdge - 1, visibleRect.y]);
}row = this.rowAtPoint$java_awt_Point(newCellLoc);
col = this.columnAtPoint$java_awt_Point(newCellLoc);
if (!!(orientation == 1 & row < 0)) {
newLeadingEdge = 0;
} else if (!!(orientation == 0 & col < 0)) {
if (leftToRight) {
newLeadingEdge = 0;
} else {
newLeadingEdge = this.getWidth();
}} else {
var newCellRect = this.getCellRect$I$I$Z(row, col, true);
var newCellLeadingEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [newCellRect, orientation]);
var newCellTrailingEdge = p$.trailingEdge$java_awt_Rectangle$I.apply(this, [newCellRect, orientation]);
if ((orientation == 1 || leftToRight ) && (newCellTrailingEdge >= visibleLeadingEdge) ) {
newLeadingEdge = newCellLeadingEdge;
} else if (orientation == 0 && !leftToRight  && newCellTrailingEdge <= visibleLeadingEdge ) {
newLeadingEdge = newCellLeadingEdge;
} else if (newEdge == newCellLeadingEdge) {
newLeadingEdge = newCellLeadingEdge;
} else {
newLeadingEdge = newCellTrailingEdge;
}}return Math.abs(visibleLeadingEdge - newLeadingEdge);
});

Clazz.newMethod$(C$, 'getNextBlockIncrement$java_awt_Rectangle$I', function (visibleRect, orientation) {
var trailingRow = p$.getTrailingRow$java_awt_Rectangle.apply(this, [visibleRect]);
var trailingCol = p$.getTrailingCol$java_awt_Rectangle.apply(this, [visibleRect]);
var cellRect;
var cellFillsVis;
var cellLeadingEdge;
var cellTrailingEdge;
var newLeadingEdge;
var visibleLeadingEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [visibleRect, orientation]);
if (orientation == 1 && trailingRow < 0 ) {
return visibleRect.height;
} else if (orientation == 0 && trailingCol < 0 ) {
return visibleRect.width;
}cellRect = this.getCellRect$I$I$Z(trailingRow, trailingCol, true);
cellLeadingEdge = p$.leadingEdge$java_awt_Rectangle$I.apply(this, [cellRect, orientation]);
cellTrailingEdge = p$.trailingEdge$java_awt_Rectangle$I.apply(this, [cellRect, orientation]);
if (orientation == 1 || this.getComponentOrientation().isLeftToRight() ) {
cellFillsVis = cellLeadingEdge <= visibleLeadingEdge;
} else {
cellFillsVis = cellLeadingEdge >= visibleLeadingEdge;
}if (cellFillsVis) {
newLeadingEdge = cellTrailingEdge;
} else if (cellTrailingEdge == p$.trailingEdge$java_awt_Rectangle$I.apply(this, [visibleRect, orientation])) {
newLeadingEdge = cellTrailingEdge;
} else {
newLeadingEdge = cellLeadingEdge;
}return Math.abs(newLeadingEdge - visibleLeadingEdge);
});

Clazz.newMethod$(C$, 'getLeadingRow$java_awt_Rectangle', function (visibleRect) {
var leadingPoint;
if (this.getComponentOrientation().isLeftToRight()) {
leadingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y]);
} else {
leadingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x + visibleRect.width - 1, visibleRect.y]);
}return this.rowAtPoint$java_awt_Point(leadingPoint);
});

Clazz.newMethod$(C$, 'getLeadingCol$java_awt_Rectangle', function (visibleRect) {
var leadingPoint;
if (this.getComponentOrientation().isLeftToRight()) {
leadingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y]);
} else {
leadingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x + visibleRect.width - 1, visibleRect.y]);
}return this.columnAtPoint$java_awt_Point(leadingPoint);
});

Clazz.newMethod$(C$, 'getTrailingRow$java_awt_Rectangle', function (visibleRect) {
var trailingPoint;
if (this.getComponentOrientation().isLeftToRight()) {
trailingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y + visibleRect.height - 1]);
} else {
trailingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x + visibleRect.width - 1, visibleRect.y + visibleRect.height - 1]);
}return this.rowAtPoint$java_awt_Point(trailingPoint);
});

Clazz.newMethod$(C$, 'getTrailingCol$java_awt_Rectangle', function (visibleRect) {
var trailingPoint;
if (this.getComponentOrientation().isLeftToRight()) {
trailingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x + visibleRect.width - 1, visibleRect.y]);
} else {
trailingPoint = Clazz.new((I$[29] || (I$[29]=Clazz.load('java.awt.Point'))).c$$I$I,[visibleRect.x, visibleRect.y]);
}return this.columnAtPoint$java_awt_Point(trailingPoint);
});

Clazz.newMethod$(C$, 'leadingEdge$java_awt_Rectangle$I', function (rect, orientation) {
if (orientation == 1) {
return rect.y;
} else if (this.getComponentOrientation().isLeftToRight()) {
return rect.x;
} else {
return rect.x + rect.width;
}});

Clazz.newMethod$(C$, 'trailingEdge$java_awt_Rectangle$I', function (rect, orientation) {
if (orientation == 1) {
return rect.y + rect.height;
} else if (this.getComponentOrientation().isLeftToRight()) {
return rect.x + rect.width;
} else {
return rect.x;
}});

Clazz.newMethod$(C$, 'getScrollableTracksViewportWidth', function () {
return !(this.autoResizeMode == 0);
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportHeight', function () {
return this.getFillsViewportHeight() && Clazz.instanceOf(this.getParent(), "javax.swing.JViewport") && ((this.getParent()).getHeight() > this.getPreferredSize().height)  ;
});

Clazz.newMethod$(C$, 'setFillsViewportHeight$Z', function (fillsViewportHeight) {
var old = this.fillsViewportHeight;
this.fillsViewportHeight = fillsViewportHeight;
this.resizeAndRepaint();
this.firePropertyChange$S$Z$Z("fillsViewportHeight", old, fillsViewportHeight);
});

Clazz.newMethod$(C$, 'getFillsViewportHeight', function () {
return this.fillsViewportHeight;
});

Clazz.newMethod$(C$, 'processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z', function (ks, e, condition, pressed) {
var retValue = C$.superClazz.prototype.processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z.apply(this, [ks, e, condition, pressed]);
if (!retValue && condition == 1  && this.isFocusOwner()  && !Boolean.FALSE.equals(this.getClientProperty$O("JTable.autoStartsEdit")) ) {
var editorComponent = this.getEditorComponent();
if (editorComponent == null ) {
if (e == null  || e.getID() != 401 ) {
return false;
}var code = e.getKeyCode();
if (code == 16 || code == 17  || code == 18 ) {
return false;
}var leadRow = this.getSelectionModel().getLeadSelectionIndex();
var leadColumn = this.getColumnModel().getSelectionModel().getLeadSelectionIndex();
if (leadRow != -1 && leadColumn != -1  && !this.isEditing() ) {
if (!this.editCellAt$I$I$java_util_EventObject(leadRow, leadColumn, e)) {
return false;
}}editorComponent = this.getEditorComponent();
if (editorComponent == null ) {
return false;
}}if (Clazz.instanceOf(editorComponent, "javax.swing.JComponent")) {
retValue = (editorComponent).processKeyBinding$javax_swing_KeyStroke$java_awt_event_KeyEvent$I$Z(ks, e, 0, pressed);
if (this.getSurrendersFocusOnKeystroke()) {
editorComponent.requestFocus();
}}}return retValue;
});

Clazz.newMethod$(C$, 'setLazyValue$java_util_Hashtable$Class$S', function (h, c, s) {
h.put$TK$TV(c, Clazz.new((I$[30] || (I$[30]=Clazz.load('sun.swing.SwingLazyValue'))).c$$S,[s]));
});

Clazz.newMethod$(C$, 'setLazyRenderer$Class$S', function (c, s) {
p$.setLazyValue$java_util_Hashtable$Class$S.apply(this, [this.defaultRenderersByColumnClass, c, s]);
});

Clazz.newMethod$(C$, 'createDefaultRenderers', function () {
this.defaultRenderersByColumnClass = Clazz.new((I$[31] || (I$[31]=Clazz.load('javax.swing.UIDefaults'))).c$$I$F,[8, 0.75]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.Object), "javax.swing.table.DefaultTableCellRenderer$UIResource"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.String), "javax.swing.table.DefaultTableCellRenderer$UIResource"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.Number), "javax.swing.JTable$NumberRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.Float), "javax.swing.JTable$DoubleRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.Double), "javax.swing.JTable$DoubleRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.util.Date), "javax.swing.JTable$DateRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(javax.swing.Icon), "javax.swing.JTable$IconRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(javax.swing.ImageIcon), "javax.swing.JTable$IconRenderer"]);
p$.setLazyRenderer$Class$S.apply(this, [Clazz.getClass(java.lang.Boolean), "javax.swing.JTable$BooleanRenderer"]);
});

Clazz.newMethod$(C$, 'setLazyEditor$Class$S', function (c, s) {
p$.setLazyValue$java_util_Hashtable$Class$S.apply(this, [this.defaultEditorsByColumnClass, c, s]);
});

Clazz.newMethod$(C$, 'createDefaultEditors', function () {
this.defaultEditorsByColumnClass = Clazz.new((I$[31] || (I$[31]=Clazz.load('javax.swing.UIDefaults'))).c$$I$F,[3, 0.75]);
p$.setLazyEditor$Class$S.apply(this, [Clazz.getClass(java.lang.Object), "javax.swing.JTable$GenericEditor"]);
p$.setLazyEditor$Class$S.apply(this, [Clazz.getClass(java.lang.Number), "javax.swing.JTable$NumberEditor"]);
p$.setLazyEditor$Class$S.apply(this, [Clazz.getClass(java.lang.Boolean), "javax.swing.JTable$BooleanEditor"]);
});

Clazz.newMethod$(C$, 'initializeLocalVars', function () {
this.updateSelectionOnSort = true;
this.setOpaque$Z(true);
this.createDefaultRenderers();
this.createDefaultEditors();
this.setTableHeader$javax_swing_table_JTableHeader(this.createDefaultTableHeader());
this.setShowGrid$Z(true);
this.setAutoResizeMode$I(2);
this.setRowHeight$I(16);
this.isRowHeightSet = false;
this.setRowMargin$I(1);
this.setRowSelectionAllowed$Z(true);
this.setCellEditor$javax_swing_table_TableCellEditor(null);
this.setEditingColumn$I(-1);
this.setEditingRow$I(-1);
this.setSurrendersFocusOnKeystroke$Z(false);
this.setPreferredScrollableViewportSize$java_awt_Dimension(Clazz.new((I$[15] || (I$[15]=Clazz.load('java.awt.Dimension'))).c$$I$I,[450, 400]));
this.setAutoscrolls$Z(true);
});

Clazz.newMethod$(C$, 'createDefaultDataModel', function () {
return Clazz.new((I$[12] || (I$[12]=Clazz.load('javax.swing.table.DefaultTableModel'))));
});

Clazz.newMethod$(C$, 'createDefaultColumnModel', function () {
return Clazz.new((I$[32] || (I$[32]=Clazz.load('javax.swing.table.DefaultTableColumnModel'))));
});

Clazz.newMethod$(C$, 'createDefaultSelectionModel', function () {
return Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.DefaultListSelectionModel'))));
});

Clazz.newMethod$(C$, 'createDefaultTableHeader', function () {
return Clazz.new((I$[33] || (I$[33]=Clazz.load('javax.swing.table.JTableHeader'))).c$$javax_swing_table_TableColumnModel,[this.columnModel]);
});

Clazz.newMethod$(C$, 'resizeAndRepaint', function () {
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'getCellEditor', function () {
return this.cellEditor;
});

Clazz.newMethod$(C$, 'setCellEditor$javax_swing_table_TableCellEditor', function (anEditor) {
var oldEditor = this.cellEditor;
this.cellEditor = anEditor;
this.firePropertyChange$S$O$O("tableCellEditor", oldEditor, anEditor);
});

Clazz.newMethod$(C$, 'setEditingColumn$I', function (aColumn) {
this.editingColumn = aColumn;
});

Clazz.newMethod$(C$, 'setEditingRow$I', function (aRow) {
this.editingRow = aRow;
});

Clazz.newMethod$(C$, 'getCellRenderer$I$I', function (row, column) {
var tableColumn = this.getColumnModel().getColumn$I(column);
var renderer = tableColumn.getCellRenderer();
if (renderer == null ) {
renderer = this.getDefaultRenderer$Class(this.getColumnClass$I(column));
}return renderer;
});

Clazz.newMethod$(C$, 'prepareRenderer$javax_swing_table_TableCellRenderer$I$I', function (renderer, row, column) {
var value = this.getValueAt$I$I(row, column);
var isSelected = false;
var hasFocus = false;
if (!this.isPaintingForPrint()) {
isSelected = this.isCellSelected$I$I(row, column);
var rowIsLead = (this.selectionModel.getLeadSelectionIndex() == row);
var colIsLead = (this.columnModel.getSelectionModel().getLeadSelectionIndex() == column);
hasFocus = (rowIsLead && colIsLead ) && this.isFocusOwner() ;
}return renderer.getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I(this, value, isSelected, hasFocus, row, column);
});

Clazz.newMethod$(C$, 'getCellEditor$I$I', function (row, column) {
var tableColumn = this.getColumnModel().getColumn$I(column);
var editor = tableColumn.getCellEditor();
if (editor == null ) {
editor = this.getDefaultEditor$Class(this.getColumnClass$I(column));
}return editor;
});

Clazz.newMethod$(C$, 'prepareEditor$javax_swing_table_TableCellEditor$I$I', function (editor, row, column) {
var value = this.getValueAt$I$I(row, column);
var isSelected = this.isCellSelected$I$I(row, column);
var comp = editor.getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I(this, value, isSelected, row, column);
return comp;
});

Clazz.newMethod$(C$, 'removeEditor', function () {
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.JTable, "PrintMode", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "NORMAL", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "FIT_WIDTH", 1, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})()
var C$=Clazz.newInterface$(P$.JTable, "Resizable2", function(){
});

var C$=Clazz.newInterface$(P$.JTable, "Resizable3", function(){
}, null, 'javax.swing.JTable.Resizable2');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

;
(function(){var C$=Clazz.newClass$(P$.JTable, "SortManager", function(){
Clazz.newInstance$(this, arguments[0], true);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.sorter = null;
this.modelSelection = null;
this.modelLeadIndex = 0;
this.syncingSelection = false;
this.lastModelSelection = null;
this.modelRowSizes = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_RowSorter', function (sorter) {
C$.$init$.apply(this);
this.sorter = sorter;
sorter.addRowSorterListener$javax_swing_event_RowSorterListener(this.b$['javax.swing.JTable']);
}, 1);

Clazz.newMethod$(C$, 'dispose', function () {
if (this.sorter != null ) {
this.sorter.removeRowSorterListener$javax_swing_event_RowSorterListener(this.b$['javax.swing.JTable']);
}});

Clazz.newMethod$(C$, 'setViewRowHeight$I$I', function (viewIndex, rowHeight) {
if (this.modelRowSizes == null ) {
this.modelRowSizes = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.SizeSequence'))).c$$I$I,[this.b$['javax.swing.JTable'].getModel().getRowCount(), this.b$['javax.swing.JTable'].getRowHeight()]);
}this.modelRowSizes.setSize$I$I(this.b$['javax.swing.JTable'].convertRowIndexToModel$I(viewIndex), rowHeight);
});

Clazz.newMethod$(C$, 'allChanged', function () {
this.modelLeadIndex = -1;
this.modelSelection = null;
this.modelRowSizes = null;
});

Clazz.newMethod$(C$, 'viewSelectionChanged$javax_swing_event_ListSelectionEvent', function (e) {
if (!this.syncingSelection && this.modelSelection != null  ) {
this.modelSelection = null;
}});

Clazz.newMethod$(C$, 'prepareForChange$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange', function (sortEvent, change) {
if (this.b$['javax.swing.JTable'].getUpdateSelectionOnSort()) {
p$.cacheSelection$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange.apply(this, [sortEvent, change]);
}});

Clazz.newMethod$(C$, 'cacheSelection$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange', function (sortEvent, change) {
if (sortEvent != null ) {
if (this.modelSelection == null  && this.sorter.getViewRowCount() != this.b$['javax.swing.JTable'].getModel().getRowCount() ) {
this.modelSelection = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.DefaultListSelectionModel'))));
var viewSelection = this.b$['javax.swing.JTable'].getSelectionModel();
var min = viewSelection.getMinSelectionIndex();
var max = viewSelection.getMaxSelectionIndex();
var modelIndex;
for (var viewIndex = min; viewIndex <= max; viewIndex++) {
if (viewSelection.isSelectedIndex$I(viewIndex)) {
modelIndex = this.b$['javax.swing.JTable'].convertRowIndexToModel$javax_swing_event_RowSorterEvent$I.apply(this.b$['javax.swing.JTable'], [sortEvent, viewIndex]);
if (modelIndex != -1) {
this.modelSelection.addSelectionInterval$I$I(modelIndex, modelIndex);
}}}
modelIndex = this.b$['javax.swing.JTable'].convertRowIndexToModel$javax_swing_event_RowSorterEvent$I.apply(this.b$['javax.swing.JTable'], [sortEvent, viewSelection.getLeadSelectionIndex()]);
(I$[2] || (I$[2]=Clazz.load('sun.swing.SwingUtilities2'))).setLeadAnchorWithoutSelection$javax_swing_ListSelectionModel$I$I(this.modelSelection, modelIndex, modelIndex);
} else if (this.modelSelection == null ) {
p$.cacheModelSelection$javax_swing_event_RowSorterEvent.apply(this, [sortEvent]);
}} else if (change.allRowsChanged) {
this.modelSelection = null;
} else if (this.modelSelection != null ) {
switch (change.type) {
case -1:
this.modelSelection.removeIndexInterval$I$I(change.startModelIndex, change.endModelIndex);
break;
case 1:
this.modelSelection.insertIndexInterval$I$I$Z(change.startModelIndex, change.endModelIndex, true);
break;
default:
break;
}
} else {
p$.cacheModelSelection$javax_swing_event_RowSorterEvent.apply(this, [null]);
}});

Clazz.newMethod$(C$, 'cacheModelSelection$javax_swing_event_RowSorterEvent', function (sortEvent) {
this.lastModelSelection = this.b$['javax.swing.JTable'].convertSelectionToModel$javax_swing_event_RowSorterEvent.apply(this.b$['javax.swing.JTable'], [sortEvent]);
this.modelLeadIndex = this.b$['javax.swing.JTable'].convertRowIndexToModel$javax_swing_event_RowSorterEvent$I.apply(this.b$['javax.swing.JTable'], [sortEvent, this.b$['javax.swing.JTable'].selectionModel.getLeadSelectionIndex()]);
});

Clazz.newMethod$(C$, 'processChange$javax_swing_event_RowSorterEvent$javax_swing_JTable_ModelChange$Z', function (sortEvent, change, sorterChanged) {
if (change != null ) {
if (change.allRowsChanged) {
this.modelRowSizes = null;
this.b$['javax.swing.JTable'].rowModel = null;
} else if (this.modelRowSizes != null ) {
if (change.type == 1) {
this.modelRowSizes.insertEntries$I$I$I(change.startModelIndex, change.endModelIndex - change.startModelIndex + 1, this.b$['javax.swing.JTable'].getRowHeight());
} else if (change.type == -1) {
this.modelRowSizes.removeEntries$I$I(change.startModelIndex, change.endModelIndex - change.startModelIndex + 1);
}}}if (sorterChanged) {
p$.setViewRowHeightsFromModel.apply(this, []);
p$.restoreSelection$javax_swing_JTable_ModelChange.apply(this, [change]);
}});

Clazz.newMethod$(C$, 'setViewRowHeightsFromModel', function () {
if (this.modelRowSizes != null ) {
this.b$['javax.swing.JTable'].rowModel.setSizes$I$I(this.b$['javax.swing.JTable'].getRowCount(), this.b$['javax.swing.JTable'].getRowHeight());
for (var viewIndex = this.b$['javax.swing.JTable'].getRowCount() - 1; viewIndex >= 0; viewIndex--) {
var modelIndex = this.b$['javax.swing.JTable'].convertRowIndexToModel$I(viewIndex);
this.b$['javax.swing.JTable'].rowModel.setSize$I$I(viewIndex, this.modelRowSizes.getSize$I(modelIndex));
}
}});

Clazz.newMethod$(C$, 'restoreSelection$javax_swing_JTable_ModelChange', function (change) {
this.syncingSelection = true;
if (this.lastModelSelection != null ) {
this.b$['javax.swing.JTable'].restoreSortingSelection$IA$I$javax_swing_JTable_ModelChange.apply(this.b$['javax.swing.JTable'], [this.lastModelSelection, this.modelLeadIndex, change]);
this.lastModelSelection = null;
} else if (this.modelSelection != null ) {
var viewSelection = this.b$['javax.swing.JTable'].getSelectionModel();
viewSelection.setValueIsAdjusting$Z(true);
viewSelection.clearSelection();
var min = this.modelSelection.getMinSelectionIndex();
var max = this.modelSelection.getMaxSelectionIndex();
var viewIndex;
for (var modelIndex = min; modelIndex <= max; modelIndex++) {
if (this.modelSelection.isSelectedIndex$I(modelIndex)) {
viewIndex = this.b$['javax.swing.JTable'].convertRowIndexToView$I(modelIndex);
if (viewIndex != -1) {
viewSelection.addSelectionInterval$I$I(viewIndex, viewIndex);
}}}
var viewLeadIndex = this.modelSelection.getLeadSelectionIndex();
if (viewLeadIndex != -1) {
viewLeadIndex = this.b$['javax.swing.JTable'].convertRowIndexToView$I(viewLeadIndex);
}(I$[2] || (I$[2]=Clazz.load('sun.swing.SwingUtilities2'))).setLeadAnchorWithoutSelection$javax_swing_ListSelectionModel$I$I(viewSelection, viewLeadIndex, viewLeadIndex);
viewSelection.setValueIsAdjusting$Z(false);
}this.syncingSelection = false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "ModelChange", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.startModelIndex = 0;
this.endModelIndex = 0;
this.type = 0;
this.modelRowCount = 0;
this.event = null;
this.length = 0;
this.allRowsChanged = false;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_event_TableModelEvent', function (e) {
C$.$init$.apply(this);
this.startModelIndex = Math.max(0, e.getFirstRow());
this.endModelIndex = e.getLastRow();
this.modelRowCount = this.b$['javax.swing.JTable'].getModel().getRowCount();
if (this.endModelIndex < 0) {
this.endModelIndex = Math.max(0, this.modelRowCount - 1);
}this.length = this.endModelIndex - this.startModelIndex + 1;
this.type = e.getType();
this.event = e;
this.allRowsChanged = (e.getLastRow() == 2147483647);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "NumberRenderer", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.table.DefaultTableCellRenderer.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setHorizontalAlignment$I(4);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "DoubleRenderer", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JTable.NumberRenderer');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.formatter = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
if (this.formatter == null ) {
this.formatter = (I$[3] || (I$[3]=Clazz.load('java.text.NumberFormat'))).getInstance();
}this.setText$S((value == null ) ? "" : this.formatter.format$O(value));
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "DateRenderer", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.table.DefaultTableCellRenderer.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.formatter = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
if (this.formatter == null ) {
this.formatter = (I$[4] || (I$[4]=Clazz.load('java.text.DateFormat'))).getDateInstance();
}this.setText$S((value == null ) ? "" : this.formatter.format$O(value));
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "IconRenderer", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.table.DefaultTableCellRenderer.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setHorizontalAlignment$I(0);
}, 1);

Clazz.newMethod$(C$, 'setValue$O', function (value) {
this.setIcon$javax_swing_Icon((Clazz.instanceOf(value, "javax.swing.Icon")) ? value : null);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "BooleanRenderer", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JCheckBox', ['javax.swing.table.TableCellRenderer', 'javax.swing.plaf.UIResource']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.noFocusBorder = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.border.EmptyBorder'))).c$$I$I$I$I,[1, 1, 1, 1]);
};

C$.noFocusBorder = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setHorizontalAlignment$I(0);
this.setBorderPainted$Z(true);
}, 1);

Clazz.newMethod$(C$, 'getTableCellRendererComponent$javax_swing_JTable$O$Z$Z$I$I', function (table, value, isSelected, hasFocus, row, column) {
if (isSelected) {
this.setForeground$java_awt_Color(table.getSelectionForeground());
C$.superClazz.prototype.setBackground$java_awt_Color.apply(this, [table.getSelectionBackground()]);
} else {
this.setForeground$java_awt_Color(table.getForeground());
this.setBackground$java_awt_Color(table.getBackground());
}this.setSelected$Z((value != null  && (value).booleanValue() ));
if (hasFocus) {
this.setBorder$javax_swing_border_Border((I$[6] || (I$[6]=Clazz.load('javax.swing.UIManager'))).getBorder$O("Table.focusCellHighlightBorder"));
} else {
this.setBorder$javax_swing_border_Border(C$.noFocusBorder);
}return this;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "GenericEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.DefaultCellEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.argTypes =  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass(java.lang.String)]);
this.constructorClass = null;
this.value = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$javax_swing_JTextField.apply(this, [Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.JTextField'))))]);
C$.$init$.apply(this);
this.getComponent().setName$S("Table.editor");
}, 1);

Clazz.newMethod$(C$, 'stopCellEditing', function () {
var s = C$.superClazz.prototype.getCellEditorValue.apply(this, []);
try {
if ("".equals$O(s) || this.constructorClass === Clazz.getClass(java.lang.String)  ) {
if (this.constructorClass === Clazz.getClass(java.lang.String) ) {
this.value = s;
return C$.superClazz.prototype.stopCellEditing.apply(this, []);
}}var haveConstructor = true;
{
haveConstructor = !!constructor.getConstructor;
}if (this.constructorClass === Clazz.getClass(java.lang.String) ) {
this.value = s;
} else if (haveConstructor) {
this.value = this.constructorClass.getConstructor$ClassA(this.argTypes).newInstance$OA( Clazz.newArray$(java.lang.Object, -1, [s]));
} else {
{
debugger;
}}} catch (e) {
(this.getComponent()).setBorder$javax_swing_border_Border(Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.border.LineBorder'))).c$$java_awt_Color,[(I$[9] || (I$[9]=Clazz.load('java.awt.Color'))).red]));
return false;
}
return C$.superClazz.prototype.stopCellEditing.apply(this, []);
});

Clazz.newMethod$(C$, 'getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I', function (table, value, isSelected, row, column) {
this.value = null;
(this.getComponent()).setBorder$javax_swing_border_Border(Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.border.LineBorder'))).c$$java_awt_Color,[(I$[9] || (I$[9]=Clazz.load('java.awt.Color'))).black]));
try {
var type = table.getColumnClass$I(column);
if (type === Clazz.getClass(java.lang.Object) ) {
type = Clazz.getClass(java.lang.String);
}this.constructorClass = type;
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return null;
} else {
throw e;
}
}
return C$.superClazz.prototype.getTableCellEditorComponent$javax_swing_JTable$O$Z$I$I.apply(this, [table, value, isSelected, row, column]);
});

Clazz.newMethod$(C$, 'getCellEditorValue', function () {
return this.value;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "NumberEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JTable.GenericEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
(this.getComponent()).setHorizontalAlignment$I(4);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JTable, "BooleanEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.DefaultCellEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$javax_swing_JCheckBox.apply(this, [Clazz.new((I$[10] || (I$[10]=Clazz.load('javax.swing.JCheckBox'))))]);
C$.$init$.apply(this);
var checkBox = this.getComponent();
checkBox.setHorizontalAlignment$I(0);
}, 1);
})()
})();
//Created 2017-10-14 13:31:44
