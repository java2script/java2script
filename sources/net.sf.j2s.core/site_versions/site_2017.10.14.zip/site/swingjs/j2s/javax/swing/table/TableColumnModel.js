(function(){var P$=Clazz.newPackage$("javax.swing.table");
var C$=Clazz.newInterface$(P$, "TableColumnModel");

})();
//Created 2017-10-14 13:32:00
