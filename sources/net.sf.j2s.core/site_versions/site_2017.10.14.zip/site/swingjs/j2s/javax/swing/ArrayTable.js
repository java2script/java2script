(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ArrayTable", null, null, 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.table = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'put$O$O', function (key, value) {
if (this.table == null ) {
this.table =  Clazz.newArray$(java.lang.Object, -1, [key, value]);
} else {
var size = this.size();
if (size < 8) {
if (this.containsKey$O(key)) {
var tmp = this.table;
for (var i = 0; i < tmp.length - 1; i = i+(2)) {
if (tmp[i].equals$O(key)) {
tmp[i + 1] = value;
break;
}}
} else {
var array = this.table;
var i = array.length;
var tmp =  Clazz.newArray$(java.lang.Object, [i + 2]);
System.arraycopy(array, 0, tmp, 0, i);
tmp[i] = key;
tmp[i + 1] = value;
this.table = tmp;
}} else {
if ((size == 8) && p$.isArray.apply(this, []) ) {
p$.grow.apply(this, []);
}(this.table).put$TK$TV(key, value);
}}});

Clazz.newMethod$(C$, 'get$O', function (key) {
var value = null;
if (this.table != null ) {
if (p$.isArray.apply(this, [])) {
var array = this.table;
for (var i = 0; i < array.length - 1; i = i+(2)) {
if (array[i].equals$O(key)) {
value = array[i + 1];
break;
}}
} else {
value = (this.table).get$O(key);
}}return value;
});

Clazz.newMethod$(C$, 'size', function () {
var size;
if (this.table == null ) return 0;
if (p$.isArray.apply(this, [])) {
size = ($i$[0] = (this.table).length/2, $i$[0]);
} else {
size = (this.table).size();
}return size;
});

Clazz.newMethod$(C$, 'containsKey$O', function (key) {
var contains = false;
if (this.table != null ) {
if (p$.isArray.apply(this, [])) {
var array = this.table;
for (var i = 0; i < array.length - 1; i = i+(2)) {
if (array[i].equals$O(key)) {
contains = true;
break;
}}
} else {
contains = (this.table).containsKey$O(key);
}}return contains;
});

Clazz.newMethod$(C$, 'remove$O', function (key) {
var value = null;
if (key == null ) {
return null;
}if (this.table != null ) {
if (p$.isArray.apply(this, [])) {
var index = -1;
var array = this.table;
for (var i = array.length - 2; i >= 0; i = i-(2)) {
if (array[i].equals$O(key)) {
index = i;
value = array[i + 1];
break;
}}
if (index != -1) {
var tmp =  Clazz.newArray$(java.lang.Object, [array.length - 2]);
System.arraycopy(array, 0, tmp, 0, index);
if (index < tmp.length) System.arraycopy(array, index + 2, tmp, index, tmp.length - index);
this.table = (tmp.length == 0) ? null : tmp;
}} else {
value = (this.table).remove$O(key);
}if (this.size() == 7 && !p$.isArray.apply(this, []) ) {
p$.shrink.apply(this, []);
}}return value;
});

Clazz.newMethod$(C$, 'clear', function () {
this.table = null;
});

Clazz.newMethod$(C$, 'clone', function () {
var newArrayTable = Clazz.new(C$);
if (p$.isArray.apply(this, [])) {
var array = this.table;
for (var i = 0; i < array.length - 1; i = i+(2)) {
newArrayTable.put$O$O(array[i], array[i + 1]);
}
} else {
var tmp = this.table;
var keys = tmp.keys();
while (keys.hasMoreElements()){
var o = keys.nextElement();
newArrayTable.put$O$O(o, tmp.get$O(o));
}
}return newArrayTable;
});

Clazz.newMethod$(C$, 'getKeys$OA', function (keys) {
if (this.table == null ) {
return null;
}if (p$.isArray.apply(this, [])) {
var array = this.table;
if (keys == null ) {
keys =  Clazz.newArray$(java.lang.Object, [($i$[0] = array.length/2, $i$[0])]);
}for (var i = 0, index = 0; i < array.length - 1; i = i+(2), index++) {
keys[index] = array[i];
}
} else {
var tmp = this.table;
var enum_ = tmp.keys();
var counter = tmp.size();
if (keys == null ) {
keys =  Clazz.newArray$(java.lang.Object, [counter]);
}while (counter > 0){
keys[--counter] = enum_.nextElement();
}
}return keys;
});

Clazz.newMethod$(C$, 'isArray', function () {
return (Clazz.instanceOf(this.table, Clazz.arrayClass$(java.lang.Object, 1)));
});

Clazz.newMethod$(C$, 'grow', function () {
var array = this.table;
var tmp = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Hashtable'))).c$$I,[($i$[0] = array.length/2, $i$[0])]);
for (var i = 0; i < array.length; i = i+(2)) {
tmp.put$TK$TV(array[i], array[i + 1]);
}
this.table = tmp;
});

Clazz.newMethod$(C$, 'shrink', function () {
var tmp = this.table;
var array =  Clazz.newArray$(java.lang.Object, [tmp.size() * 2]);
var keys = tmp.keys();
var j = 0;
while (keys.hasMoreElements()){
var o = keys.nextElement();
array[j] = o;
array[j + 1] = tmp.get$O(o);
j = j+(2);
}
this.table = array;
});
var $i$ = new Int32Array(1);
})();
//Created 2017-10-14 13:31:31
