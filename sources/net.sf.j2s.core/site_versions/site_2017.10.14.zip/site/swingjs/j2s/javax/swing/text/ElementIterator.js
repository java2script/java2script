(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "ElementIterator", function(){
Clazz.newInstance$(this, arguments);
}, null, 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.root = null;
this.elementStack = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document', function (document) {
C$.$init$.apply(this);
this.root = document.getDefaultRootElement();
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (root) {
C$.$init$.apply(this);
this.root = root;
}, 1);

Clazz.newMethod$(C$, 'clone', function () {
try {
var it = Clazz.new(C$.c$$javax_swing_text_Element,[this.root]);
if (this.elementStack != null ) {
it.elementStack = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Stack'))));
for (var i = 0; i < this.elementStack.size(); i++) {
var item = this.elementStack.elementAt$I(i);
var clonee = item.clone();
it.elementStack.push$TE(clonee);
}
}return it;
} catch (e) {
if (Clazz.exceptionOf(e, CloneNotSupportedException)){
throw Clazz.new((I$[1] || (I$[1]=Clazz.load('java.lang.InternalError'))));
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'first', function () {
if (this.root == null ) {
return null;
}this.elementStack = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Stack'))));
if (this.root.getElementCount() != 0) {
this.elementStack.push$TE(Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.ElementIterator').StackItem))).c$$javax_swing_text_Element, [this, null, this.root]));
}return this.root;
});

Clazz.newMethod$(C$, 'depth', function () {
if (this.elementStack == null ) {
return 0;
}return this.elementStack.size();
});

Clazz.newMethod$(C$, 'current', function () {
if (this.elementStack == null ) {
return this.first();
}if (!this.elementStack.empty()) {
var item = this.elementStack.peek();
var elem = item.getElement();
var index = item.getIndex();
if (index == -1) {
return elem;
}return elem.getElement$I(index);
}return null;
});

Clazz.newMethod$(C$, 'next', function () {
if (this.elementStack == null ) {
return this.first();
}if (this.elementStack.isEmpty()) {
return null;
}var item = this.elementStack.peek();
var elem = item.getElement();
var index = item.getIndex();
if (index + 1 < elem.getElementCount()) {
var child = elem.getElement$I(index + 1);
if (child.isLeaf()) {
item.incrementIndex();
} else {
this.elementStack.push$TE(Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.ElementIterator').StackItem))).c$$javax_swing_text_Element, [this, null, child]));
}return child;
} else {
this.elementStack.pop();
if (!this.elementStack.isEmpty()) {
var top = this.elementStack.peek();
top.incrementIndex();
return this.next();
}}return null;
});

Clazz.newMethod$(C$, 'previous', function () {
var stackSize;
if (this.elementStack == null  || (stackSize = this.elementStack.size()) == 0 ) {
return null;
}var item = this.elementStack.peek();
var elem = item.getElement();
var index = item.getIndex();
if (index > 0) {
return p$.getDeepestLeaf$javax_swing_text_Element.apply(this, [elem.getElement$I(--index)]);
} else if (index == 0) {
return elem;
} else if (index == -1) {
if (stackSize == 1) {
return null;
}var top = this.elementStack.pop();
item = this.elementStack.peek();
this.elementStack.push$TE(top);
elem = item.getElement();
index = item.getIndex();
return ((index == -1) ? elem : p$.getDeepestLeaf$javax_swing_text_Element.apply(this, [elem.getElement$I(index)]));
}return null;
});

Clazz.newMethod$(C$, 'getDeepestLeaf$javax_swing_text_Element', function (parent) {
if (parent.isLeaf()) {
return parent;
}var childCount = parent.getElementCount();
if (childCount == 0) {
return parent;
}return p$.getDeepestLeaf$javax_swing_text_Element.apply(this, [parent.getElement$I(childCount - 1)]);
});
;
(function(){var C$=Clazz.newClass$(P$.ElementIterator, "StackItem", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.item = null;
this.childIndex = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.$init$.apply(this);
this.item = elem;
this.childIndex = -1;
}, 1);

Clazz.newMethod$(C$, 'incrementIndex', function () {
this.childIndex++;
});

Clazz.newMethod$(C$, 'getElement', function () {
return this.item;
});

Clazz.newMethod$(C$, 'getIndex', function () {
return this.childIndex;
});

Clazz.newMethod$(C$, 'clone', function () {
return Clazz.clone(this);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
