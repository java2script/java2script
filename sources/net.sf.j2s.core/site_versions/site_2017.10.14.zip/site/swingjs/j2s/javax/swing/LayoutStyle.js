(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "LayoutStyle");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setInstance$javax_swing_LayoutStyle', function (style) {
{
if (style == null ) {
(I$[0] || (I$[0]=Clazz.load('sun.awt.AppContext'))).getAppContext().remove$O(Clazz.getClass(javax.swing.LayoutStyle));
} else {
(I$[0] || (I$[0]=Clazz.load('sun.awt.AppContext'))).getAppContext().put$O$O(Clazz.getClass(javax.swing.LayoutStyle), style);
}}}, 1);

Clazz.newMethod$(C$, 'getInstance', function () {
var style;
{
style = (I$[0] || (I$[0]=Clazz.load('sun.awt.AppContext'))).getAppContext().get$O(Clazz.getClass(javax.swing.LayoutStyle));
}if (style == null ) {
return (I$[1] || (I$[1]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getLayoutStyle();
}return style;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
;
(function(){var C$=Clazz.newClass$(P$.LayoutStyle, "ComponentPlacement", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "RELATED", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "UNRELATED", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "INDENT", 2, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})()
})();
//Created 2017-10-14 13:31:47
