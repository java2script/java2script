(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JPanel", null, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_LayoutManager$Z', function (layout, isDoubleBuffered) {
Clazz.super(C$, this,1);
this.setLayout$java_awt_LayoutManager(layout);
this.setUIProperty$S$O("opaque", Boolean.TRUE);
this.uiClassID = "PanelUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_LayoutManager', function (layout) {
C$.c$$java_awt_LayoutManager$Z.apply(this, [layout, true]);
}, 1);

Clazz.newMethod$(C$, 'c$$Z', function (isDoubleBuffered) {
C$.c$$java_awt_LayoutManager$Z.apply(this, [Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.FlowLayout')))), isDoubleBuffered]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$Z.apply(this, [true]);
}, 1);
})();
//Created 2017-10-14 13:31:40
