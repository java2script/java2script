(function(){var P$=Clazz.newPackage$("javax.swing.plaf.basic"),I$=[];
var C$=Clazz.newClass$(P$, "BasicBorders", function(){
Clazz.newInstance$(this, arguments);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getButtonBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var buttonBorder = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').CompoundBorderUIResource))).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').ButtonBorder))).c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[table.getColor$O("Button.shadow"), table.getColor$O("Button.darkShadow"), table.getColor$O("Button.light"), table.getColor$O("Button.highlight")]), Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').MarginBorder))))]);
return buttonBorder;
}, 1);

Clazz.newMethod$(C$, 'getRadioButtonBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var radioButtonBorder = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').CompoundBorderUIResource))).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').RadioButtonBorder))).c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[table.getColor$O("RadioButton.shadow"), table.getColor$O("RadioButton.darkShadow"), table.getColor$O("RadioButton.light"), table.getColor$O("RadioButton.highlight")]), Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').MarginBorder))))]);
return radioButtonBorder;
}, 1);

Clazz.newMethod$(C$, 'getToggleButtonBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var toggleButtonBorder = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').CompoundBorderUIResource))).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').ToggleButtonBorder))).c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[table.getColor$O("ToggleButton.shadow"), table.getColor$O("ToggleButton.darkShadow"), table.getColor$O("ToggleButton.light"), table.getColor$O("ToggleButton.highlight")]), Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').MarginBorder))))]);
return toggleButtonBorder;
}, 1);

Clazz.newMethod$(C$, 'getMenuBarBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var menuBarBorder = Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').MenuBarBorder))).c$$java_awt_Color$java_awt_Color,[table.getColor$O("MenuBar.shadow"), table.getColor$O("MenuBar.highlight")]);
return menuBarBorder;
}, 1);

Clazz.newMethod$(C$, 'getSplitPaneBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var splitPaneBorder = Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').SplitPaneBorder))).c$$java_awt_Color$java_awt_Color,[table.getColor$O("SplitPane.highlight"), table.getColor$O("SplitPane.darkShadow")]);
return splitPaneBorder;
}, 1);

Clazz.newMethod$(C$, 'getTextFieldBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var textFieldBorder = Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.plaf.basic.BasicBorders').FieldBorder))).c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[table.getColor$O("TextField.shadow"), table.getColor$O("TextField.darkShadow"), table.getColor$O("TextField.light"), table.getColor$O("TextField.highlight")]);
return textFieldBorder;
}, 1);

Clazz.newMethod$(C$, 'getProgressBarBorder', function () {
var progressBarBorder = Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').LineBorderUIResource))).c$$java_awt_Color$I,[(I$[12] || (I$[12]=Clazz.load('java.awt.Color'))).green, 2]);
return progressBarBorder;
}, 1);

Clazz.newMethod$(C$, 'getInternalFrameBorder', function () {
var table = (I$[2] || (I$[2]=Clazz.load('javax.swing.UIManager'))).getLookAndFeelDefaults();
var internalFrameBorder = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').CompoundBorderUIResource))).c$$javax_swing_border_Border$javax_swing_border_Border,[Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.border.BevelBorder'))).c$$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color,[0, table.getColor$O("InternalFrame.borderLight"), table.getColor$O("InternalFrame.borderHighlight"), table.getColor$O("InternalFrame.borderDarkShadow"), table.getColor$O("InternalFrame.borderShadow")]), (I$[14] || (I$[14]=Clazz.load('javax.swing.BorderFactory'))).createLineBorder$java_awt_Color$I(table.getColor$O("InternalFrame.borderColor"), 1)]);
return internalFrameBorder;
}, 1);
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "RolloverButtonBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.plaf.basic.BasicBorders.ButtonBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (shadow, darkShadow, highlight, lightHighlight) {
C$.superClazz.c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color.apply(this, [shadow, darkShadow, highlight, lightHighlight]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, w, h) {
var b = c;
var model = b.getModel();
var shade = this.shadow;
var p = b.getParent();
if (p != null  && p.getBackground().equals$O(this.shadow) ) {
shade = this.darkShadow;
}if ((model.isRollover() && !(model.isPressed() && !model.isArmed() ) ) || model.isSelected() ) {
var oldColor = g.getColor();
g.translate$I$I(x, y);
if (model.isPressed() && model.isArmed()  || model.isSelected() ) {
g.setColor$java_awt_Color(shade);
g.drawRect$I$I$I$I(0, 0, w - 1, h - 1);
g.setColor$java_awt_Color(this.lightHighlight);
g.drawLine$I$I$I$I(w - 1, 0, w - 1, h - 1);
g.drawLine$I$I$I$I(0, h - 1, w - 1, h - 1);
} else {
g.setColor$java_awt_Color(this.lightHighlight);
g.drawRect$I$I$I$I(0, 0, w - 1, h - 1);
g.setColor$java_awt_Color(shade);
g.drawLine$I$I$I$I(w - 1, 0, w - 1, h - 1);
g.drawLine$I$I$I$I(0, h - 1, w - 1, h - 1);
}g.translate$I$I(-x, -y);
g.setColor$java_awt_Color(oldColor);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "RolloverMarginBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.EmptyBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$I$I$I$I.apply(this, [3, 3, 3, 3]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
var margin = null;
if (Clazz.instanceOf(c, "javax.swing.AbstractButton")) {
margin = (c).getMargin();
}if (margin == null  || Clazz.instanceOf(margin, "javax.swing.plaf.UIResource") ) {
insets.left = this.left;
insets.top = this.top;
insets.right = this.right;
insets.bottom = this.bottom;
} else {
insets.left = margin.left;
insets.top = margin.top;
insets.right = margin.right;
insets.bottom = margin.bottom;
}return insets;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "ButtonBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.AbstractBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.shadow = null;
this.darkShadow = null;
this.highlight = null;
this.lightHighlight = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (shadow, darkShadow, highlight, lightHighlight) {
Clazz.super(C$, this,1);
this.shadow = shadow;
this.darkShadow = darkShadow;
this.highlight = highlight;
this.lightHighlight = lightHighlight;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
var isPressed = false;
var isDefault = false;
if (Clazz.instanceOf(c, "javax.swing.AbstractButton")) {
var b = c;
var model = b.getModel();
isPressed = model.isPressed() && model.isArmed() ;
if (Clazz.instanceOf(c, "javax.swing.JButton")) {
isDefault = (c).isDefaultButton();
}}(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawBezel$java_awt_Graphics$I$I$I$I$Z$Z$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, isPressed, isDefault, this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.top = 2;
insets.left = insets.bottom = insets.right = 3;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "ToggleButtonBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.plaf.basic.BasicBorders.ButtonBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (shadow, darkShadow, highlight, lightHighlight) {
C$.superClazz.c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color.apply(this, [shadow, darkShadow, highlight, lightHighlight]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawBezel$java_awt_Graphics$I$I$I$I$Z$Z$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, false, false, this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[2, 2, 2, 2]);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.top = insets.left = insets.bottom = insets.right = 2;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "RadioButtonBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.plaf.basic.BasicBorders.ButtonBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (shadow, darkShadow, highlight, lightHighlight) {
C$.superClazz.c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color.apply(this, [shadow, darkShadow, highlight, lightHighlight]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
if (Clazz.instanceOf(c, "javax.swing.AbstractButton")) {
var b = c;
var model = b.getModel();
if (model.isArmed() && model.isPressed()  || model.isSelected() ) {
(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawLoweredBezel$java_awt_Graphics$I$I$I$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
} else {
(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawBezel$java_awt_Graphics$I$I$I$I$Z$Z$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, false, b.isFocusPainted() && b.hasFocus() , this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
}} else {
(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawBezel$java_awt_Graphics$I$I$I$I$Z$Z$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, false, false, this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
}});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.top = insets.left = insets.bottom = insets.right = 2;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "MenuBarBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.AbstractBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.shadow = null;
this.highlight = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color', function (shadow, highlight) {
Clazz.super(C$, this,1);
this.shadow = shadow;
this.highlight = highlight;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
var oldColor = g.getColor();
g.translate$I$I(x, y);
g.setColor$java_awt_Color(this.shadow);
g.drawLine$I$I$I$I(0, height - 2, width, height - 2);
g.setColor$java_awt_Color(this.highlight);
g.drawLine$I$I$I$I(0, height - 1, width, height - 1);
g.translate$I$I(-x, -y);
g.setColor$java_awt_Color(oldColor);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.top = 0;
insets.left = 0;
insets.bottom = 2;
insets.right = 0;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "MarginBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.AbstractBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
var margin = null;
if (Clazz.instanceOf(c, "javax.swing.AbstractButton")) {
var b = c;
margin = b.getMargin();
} else if (Clazz.instanceOf(c, "javax.swing.JToolBar")) {
var t = c;
margin = t.getMargin();
} else if (Clazz.instanceOf(c, "javax.swing.text.JTextComponent")) {
var t = c;
margin = t.getMargin();
}insets.top = margin != null  ? margin.top : 0;
insets.left = margin != null  ? margin.left : 0;
insets.bottom = margin != null  ? margin.bottom : 0;
insets.right = margin != null  ? margin.right : 0;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "FieldBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.AbstractBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.shadow = null;
this.darkShadow = null;
this.highlight = null;
this.lightHighlight = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (shadow, darkShadow, highlight, lightHighlight) {
Clazz.super(C$, this,1);
this.shadow = shadow;
this.highlight = highlight;
this.darkShadow = darkShadow;
this.lightHighlight = lightHighlight;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
(I$[1] || (I$[1]=Clazz.load('javax.swing.plaf.basic.BasicGraphicsUtils'))).drawEtchedRect$java_awt_Graphics$I$I$I$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color(g, x, y, width, height, this.shadow, this.darkShadow, this.highlight, this.lightHighlight);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
var margin = null;
if (Clazz.instanceOf(c, "javax.swing.text.JTextComponent")) {
margin = (c).getMargin();
}insets.top = margin != null  ? 2 + margin.top : 2;
insets.left = margin != null  ? 2 + margin.left : 2;
insets.bottom = margin != null  ? 2 + margin.bottom : 2;
insets.right = margin != null  ? 2 + margin.right : 2;
return insets;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BasicBorders, "SplitPaneBorder", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, ['javax.swing.border.Border', 'javax.swing.plaf.UIResource']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.highlight = null;
this.shadow = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color', function (highlight, shadow) {
C$.$init$.apply(this);
this.highlight = highlight;
this.shadow = shadow;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
var child;
var cBounds;
var splitPane = c;
child = splitPane.getLeftComponent();
g.setColor$java_awt_Color(c.getBackground());
g.drawRect$I$I$I$I(x, y, width - 1, height - 1);
if (splitPane.getOrientation() == 1) {
if (child != null ) {
cBounds = child.getBounds();
g.setColor$java_awt_Color(this.shadow);
g.drawLine$I$I$I$I(0, 0, cBounds.width + 1, 0);
g.drawLine$I$I$I$I(0, 1, 0, cBounds.height + 1);
g.setColor$java_awt_Color(this.highlight);
g.drawLine$I$I$I$I(0, cBounds.height + 1, cBounds.width + 1, cBounds.height + 1);
}child = splitPane.getRightComponent();
if (child != null ) {
cBounds = child.getBounds();
var maxX = cBounds.x + cBounds.width;
var maxY = cBounds.y + cBounds.height;
g.setColor$java_awt_Color(this.shadow);
g.drawLine$I$I$I$I(cBounds.x - 1, 0, maxX, 0);
g.setColor$java_awt_Color(this.highlight);
g.drawLine$I$I$I$I(cBounds.x - 1, maxY, maxX, maxY);
g.drawLine$I$I$I$I(maxX, 0, maxX, maxY + 1);
}} else {
if (child != null ) {
cBounds = child.getBounds();
g.setColor$java_awt_Color(this.shadow);
g.drawLine$I$I$I$I(0, 0, cBounds.width + 1, 0);
g.drawLine$I$I$I$I(0, 1, 0, cBounds.height);
g.setColor$java_awt_Color(this.highlight);
g.drawLine$I$I$I$I(1 + cBounds.width, 0, 1 + cBounds.width, cBounds.height + 1);
g.drawLine$I$I$I$I(0, cBounds.height + 1, 0, cBounds.height + 1);
}child = splitPane.getRightComponent();
if (child != null ) {
cBounds = child.getBounds();
var maxX = cBounds.x + cBounds.width;
var maxY = cBounds.y + cBounds.height;
g.setColor$java_awt_Color(this.shadow);
g.drawLine$I$I$I$I(0, cBounds.y - 1, 0, maxY);
g.drawLine$I$I$I$I(maxX, cBounds.y - 1, maxX, cBounds.y - 1);
g.setColor$java_awt_Color(this.highlight);
g.drawLine$I$I$I$I(0, maxY, cBounds.width + 1, maxY);
g.drawLine$I$I$I$I(maxX, cBounds.y, maxX, maxY);
}}});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[1, 1, 1, 1]);
});

Clazz.newMethod$(C$, 'isBorderOpaque', function () {
return true;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:58
