(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newInterface$(P$, "AttributeSet", function(){
});

var C$=Clazz.newInterface$(P$.AttributeSet, "FontAttribute", function(){
});

var C$=Clazz.newInterface$(P$.AttributeSet, "ColorAttribute", function(){
});

var C$=Clazz.newInterface$(P$.AttributeSet, "CharacterAttribute", function(){
});

var C$=Clazz.newInterface$(P$.AttributeSet, "ParagraphAttribute", function(){
});

})();
//Created 2017-10-14 13:32:00
