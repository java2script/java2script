(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractWriter");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.it = null;
this.out = null;
this.indentLevel = 0;
this.indentSpace = 2;
this.doc = null;
this.maxLineLength = 100;
this.currLength = 0;
this.startOffset = 0;
this.endOffset = 0;
this.offsetIndent = 0;
this.lineSeparator = null;
this.canWrapLines = false;
this.$isLineEmpty = false;
this.indentChars = null;
this.tempChars = null;
this.newlineChars = null;
this.segment = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_Writer$javax_swing_text_Document', function (w, doc) {
C$.c$$java_io_Writer$javax_swing_text_Document$I$I.apply(this, [w, doc, 0, doc.getLength()]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_Writer$javax_swing_text_Document$I$I', function (w, doc, pos, len) {
C$.$init$.apply(this);
this.doc = doc;
this.it = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.text.ElementIterator'))).c$$javax_swing_text_Element,[doc.getDefaultRootElement()]);
this.out = w;
this.startOffset = pos;
this.endOffset = pos + len;
var docNewline = doc.getProperty$O("__EndOfLine__");
if (Clazz.instanceOf(docNewline, "java.lang.String")) {
this.setLineSeparator$S(docNewline);
} else {
var newline = null;
try {
newline = System.getProperty("line.separator");
} catch (se) {
if (Clazz.exceptionOf(se, SecurityException)){
} else {
throw se;
}
}
if (newline == null ) {
newline = "\u000a";
}this.setLineSeparator$S(newline);
}this.canWrapLines = true;
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_Writer$javax_swing_text_Element', function (w, root) {
C$.c$$java_io_Writer$javax_swing_text_Element$I$I.apply(this, [w, root, 0, root.getEndOffset()]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_Writer$javax_swing_text_Element$I$I', function (w, root, pos, len) {
C$.$init$.apply(this);
this.doc = root.getDocument();
this.it = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.text.ElementIterator'))).c$$javax_swing_text_Element,[root]);
this.out = w;
this.startOffset = pos;
this.endOffset = pos + len;
this.canWrapLines = true;
}, 1);

Clazz.newMethod$(C$, 'getStartOffset', function () {
return this.startOffset;
});

Clazz.newMethod$(C$, 'getEndOffset', function () {
return this.endOffset;
});

Clazz.newMethod$(C$, 'getElementIterator', function () {
return this.it;
});

Clazz.newMethod$(C$, 'getWriter', function () {
return this.out;
});

Clazz.newMethod$(C$, 'getDocument', function () {
return this.doc;
});

Clazz.newMethod$(C$, 'inRange$javax_swing_text_Element', function (next) {
var startOffset = this.getStartOffset();
var endOffset = this.getEndOffset();
if ((next.getStartOffset() >= startOffset && next.getStartOffset() < endOffset ) || (startOffset >= next.getStartOffset() && startOffset < next.getEndOffset() ) ) {
return true;
}return false;
});

Clazz.newMethod$(C$, 'getText$javax_swing_text_Element', function (elem) {
return this.doc.getText$I$I(elem.getStartOffset(), elem.getEndOffset() - elem.getStartOffset());
});

Clazz.newMethod$(C$, 'text$javax_swing_text_Element', function (elem) {
var start = Math.max(this.getStartOffset(), elem.getStartOffset());
var end = Math.min(this.getEndOffset(), elem.getEndOffset());
if (start < end) {
if (this.segment == null ) {
this.segment = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.text.Segment'))));
}this.getDocument().getText$I$I$javax_swing_text_Segment(start, end - start, this.segment);
if (this.segment.count > 0) {
this.write$CA$I$I(this.segment.array, this.segment.offset, this.segment.count);
}}});

Clazz.newMethod$(C$, 'setLineLength$I', function (l) {
this.maxLineLength = l;
});

Clazz.newMethod$(C$, 'getLineLength', function () {
return this.maxLineLength;
});

Clazz.newMethod$(C$, 'setCurrentLineLength$I', function (length) {
this.currLength = length;
this.$isLineEmpty = (this.currLength == 0);
});

Clazz.newMethod$(C$, 'getCurrentLineLength', function () {
return this.currLength;
});

Clazz.newMethod$(C$, 'isLineEmpty', function () {
return this.$isLineEmpty;
});

Clazz.newMethod$(C$, 'setCanWrapLines$Z', function (newValue) {
this.canWrapLines = newValue;
});

Clazz.newMethod$(C$, 'getCanWrapLines', function () {
return this.canWrapLines;
});

Clazz.newMethod$(C$, 'setIndentSpace$I', function (space) {
this.indentSpace = space;
});

Clazz.newMethod$(C$, 'getIndentSpace', function () {
return this.indentSpace;
});

Clazz.newMethod$(C$, 'setLineSeparator$S', function (value) {
this.lineSeparator = value;
});

Clazz.newMethod$(C$, 'getLineSeparator', function () {
return this.lineSeparator;
});

Clazz.newMethod$(C$, 'incrIndent', function () {
if (this.offsetIndent > 0) {
this.offsetIndent++;
} else {
if (++this.indentLevel * this.getIndentSpace() >= this.getLineLength()) {
this.offsetIndent++;
--this.indentLevel;
}}});

Clazz.newMethod$(C$, 'decrIndent', function () {
if (this.offsetIndent > 0) {
--this.offsetIndent;
} else {
this.indentLevel--;
}});

Clazz.newMethod$(C$, 'getIndentLevel', function () {
return this.indentLevel;
});

Clazz.newMethod$(C$, 'indent', function () {
var max = this.getIndentLevel() * this.getIndentSpace();
if (this.indentChars == null  || max > this.indentChars.length ) {
this.indentChars =  Clazz.newArray$(Character.TYPE, [max]);
for (var counter = 0; counter < max; counter++) {
this.indentChars[counter] = ' ';
}
}var length = this.getCurrentLineLength();
var wasEmpty = this.isLineEmpty();
this.output$CA$I$I(this.indentChars, 0, max);
if (wasEmpty && length == 0 ) {
this.$isLineEmpty = true;
}});

Clazz.newMethod$(C$, 'write$C', function (ch) {
if (this.tempChars == null ) {
this.tempChars =  Clazz.newArray$(Character.TYPE, [128]);
}this.tempChars[0] = ch;
this.write$CA$I$I(this.tempChars, 0, 1);
});

Clazz.newMethod$(C$, 'write$S', function (content) {
if (content == null ) {
return;
}var size = content.length$();
if (this.tempChars == null  || this.tempChars.length < size ) {
this.tempChars =  Clazz.newArray$(Character.TYPE, [size]);
}content.getChars$I$I$CA$I(0, size, this.tempChars, 0);
this.write$CA$I$I(this.tempChars, 0, size);
});

Clazz.newMethod$(C$, 'writeLineSeparator', function () {
var newline = this.getLineSeparator();
var length = newline.length$();
if (this.newlineChars == null  || this.newlineChars.length < length ) {
this.newlineChars =  Clazz.newArray$(Character.TYPE, [length]);
}newline.getChars$I$I$CA$I(0, length, this.newlineChars, 0);
this.output$CA$I$I(this.newlineChars, 0, length);
this.setCurrentLineLength$I(0);
});

Clazz.newMethod$(C$, 'write$CA$I$I', function (chars, startIndex, length) {
if (!this.getCanWrapLines()) {
var lastIndex = startIndex;
var endIndex = startIndex + length;
var newlineIndex = p$.indexOf$CA$C$I$I.apply(this, [chars, '\u000a', startIndex, endIndex]);
while (newlineIndex != -1){
if (newlineIndex > lastIndex) {
this.output$CA$I$I(chars, lastIndex, newlineIndex - lastIndex);
}this.writeLineSeparator();
lastIndex = newlineIndex + 1;
newlineIndex = p$.indexOf$CA$C$I$I.apply(this, [chars, '\u000a', lastIndex, endIndex]);
}
if (lastIndex < endIndex) {
this.output$CA$I$I(chars, lastIndex, endIndex - lastIndex);
}} else {
var lastIndex = startIndex;
var endIndex = startIndex + length;
var lineLength = this.getCurrentLineLength();
var maxLength = this.getLineLength();
while (lastIndex < endIndex){
var newlineIndex = p$.indexOf$CA$C$I$I.apply(this, [chars, '\u000a', lastIndex, endIndex]);
var needsNewline = false;
var forceNewLine = false;
lineLength = this.getCurrentLineLength();
if (newlineIndex != -1 && (lineLength + (newlineIndex - lastIndex)) < maxLength ) {
if (newlineIndex > lastIndex) {
this.output$CA$I$I(chars, lastIndex, newlineIndex - lastIndex);
}lastIndex = newlineIndex + 1;
forceNewLine = true;
} else if (newlineIndex == -1 && (lineLength + (endIndex - lastIndex)) < maxLength ) {
if (endIndex > lastIndex) {
this.output$CA$I$I(chars, lastIndex, endIndex - lastIndex);
}lastIndex = endIndex;
} else {
var breakPoint = -1;
var maxBreak = Math.min(endIndex - lastIndex, maxLength - lineLength - 1 );
var counter = 0;
while (counter < maxBreak){
if (Character.isWhitespace(chars[counter + lastIndex])) {
breakPoint = counter;
}counter++;
}
if (breakPoint != -1) {
breakPoint = breakPoint+(lastIndex + 1);
this.output$CA$I$I(chars, lastIndex, breakPoint - lastIndex);
lastIndex = breakPoint;
needsNewline = true;
} else {
counter = Math.max(0, maxBreak);
maxBreak = endIndex - lastIndex;
while (counter < maxBreak){
if (Character.isWhitespace(chars[counter + lastIndex])) {
breakPoint = counter;
break;
}counter++;
}
if (breakPoint == -1) {
this.output$CA$I$I(chars, lastIndex, endIndex - lastIndex);
breakPoint = endIndex;
} else {
breakPoint = breakPoint+(lastIndex);
if (chars[breakPoint] == '\u000a') {
this.output$CA$I$I(chars, lastIndex, breakPoint++ - lastIndex);
forceNewLine = true;
} else {
this.output$CA$I$I(chars, lastIndex, ++breakPoint - lastIndex);
needsNewline = true;
}}lastIndex = breakPoint;
}}if (forceNewLine || needsNewline || lastIndex < endIndex  ) {
this.writeLineSeparator();
if (lastIndex < endIndex || !forceNewLine ) {
this.indent();
}}}
}});

Clazz.newMethod$(C$, 'writeAttributes$javax_swing_text_AttributeSet', function (attr) {
var names = attr.getAttributeNames();
while (names.hasMoreElements()){
var name = names.nextElement();
this.write$S(" " + name + "=" + attr.getAttribute$O(name) );
}
});

Clazz.newMethod$(C$, 'output$CA$I$I', function (content, start, length) {
this.getWriter().write$CA$I$I(content, start, length);
this.setCurrentLineLength$I(this.getCurrentLineLength() + length);
});

Clazz.newMethod$(C$, 'indexOf$CA$C$I$I', function (chars, sChar, startIndex, endIndex) {
while (startIndex < endIndex){
if (chars[startIndex] == sChar) {
return startIndex;
}startIndex++;
}
return -1;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:00
