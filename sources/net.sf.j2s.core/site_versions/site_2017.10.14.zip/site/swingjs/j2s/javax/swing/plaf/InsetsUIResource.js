(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "InsetsUIResource", null, 'java.awt.Insets', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I', function (top, left, bottom, right) {
C$.superClazz.c$$I$I$I$I.apply(this, [top, left, bottom, right]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:56
