(function(){var P$=Clazz.newPackage$("javax.swing.plaf");
var C$=Clazz.newClass$(P$, "ComponentInputMapUIResource", null, 'javax.swing.ComponentInputMap', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComponent', function (component) {
C$.superClazz.c$$javax_swing_JComponent.apply(this, [component]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:55
