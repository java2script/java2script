(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "GapContent", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.GapVector', 'javax.swing.text.AbstractDocument.Content');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.empty =  Clazz.newArray$(Character.TYPE, [0]);
};

C$.empty = null;

Clazz.newMethod$(C$, '$init$', function () {
this.marks = null;
this.search = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I.apply(this, [10]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (initialLength) {
C$.superClazz.c$$I.apply(this, [Math.max(initialLength, 2)]);
C$.$init$.apply(this);
var implied =  Clazz.newArray$(Character.TYPE, [1]);
implied[0] = '\u000a';
this.replace$I$I$O$I(0, 0, implied, implied.length);
this.marks = Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.GapContent').MarkVector))));
this.search = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.text.GapContent').MarkData))).c$$I, [this, null, 0]);
}, 1);

Clazz.newMethod$(C$, 'allocateArray$I', function (len) {
return  Clazz.newArray$(Character.TYPE, [len]);
});

Clazz.newMethod$(C$, 'getArrayLength', function () {
var carray = this.getArray();
return carray.length;
});

Clazz.newMethod$(C$, 'length$', function () {
var len = this.getArrayLength() - (this.getGapEnd() - this.getGapStart());
return len;
});

Clazz.newMethod$(C$, 'insertString$I$S', function (where, str) {
if (where > this.length$() || where < 0 ) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Invalid insert", this.length$()]);
}var chars = str.toCharArray();
this.replace$I$I$O$I(where, 0, chars, chars.length);
return Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.text.GapContent').InsertUndo))).c$$I$I, [this, null, where, str.length$()]);
});

Clazz.newMethod$(C$, 'remove$I$I', function (where, nitems) {
if (where + nitems >= this.length$()) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Invalid remove", this.length$() + 1]);
}var removedString = this.getString$I$I(where, nitems);
var edit = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.GapContent').RemoveUndo))).c$$I$S, [this, null, where, removedString]);
this.replace$I$I$O$I(where, nitems, C$.empty, 0);
return edit;
});

Clazz.newMethod$(C$, 'getString$I$I', function (where, len) {
var s = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.text.Segment'))));
this.getChars$I$I$javax_swing_text_Segment(where, len, s);
return  String.instantialize(s.array, s.offset, s.count);
});

Clazz.newMethod$(C$, 'getChars$I$I$javax_swing_text_Segment', function (where, len, chars) {
var end = where + len;
if (where < 0 || end < 0 ) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Invalid location", -1]);
}if (end > this.length$() || where > this.length$() ) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Invalid location", this.length$() + 1]);
}var g0 = this.getGapStart();
var g1 = this.getGapEnd();
var array = this.getArray();
if ((where + len) <= g0) {
chars.array = array;
chars.offset = where;
} else if (where >= g0) {
chars.array = array;
chars.offset = g1 + where - g0;
} else {
var before = g0 - where;
if (chars.isPartialReturn()) {
chars.array = array;
chars.offset = where;
chars.count = before;
return;
}chars.array =  Clazz.newArray$(Character.TYPE, [len]);
chars.offset = 0;
System.arraycopy(array, where, chars.array, 0, before);
System.arraycopy(array, g1, chars.array, before, len - before);
}chars.count = len;
});

Clazz.newMethod$(C$, 'createPosition$I', function (offset) {
var g0 = this.getGapStart();
var g1 = this.getGapEnd();
var index = (offset < g0) ? offset : offset + (g1 - g0);
this.search.index = index;
var sortIndex = this.findSortIndex$javax_swing_text_GapContent_MarkData(this.search);
var m;
var position;
if (sortIndex < this.marks.size() && (m = this.marks.elementAt$I(sortIndex)).index == index  && (position = m.getPosition()) != null  ) {
} else {
position = Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.GapContent').StickyPosition))), [this, null]);
m = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.text.GapContent').MarkData))).c$$I$javax_swing_text_GapContent_StickyPosition, [this, null, index, position]);
position.setMark$javax_swing_text_GapContent_MarkData(m);
this.marks.insertElementAt$javax_swing_text_GapContent_MarkData$I(m, sortIndex);
}return position;
});

Clazz.newMethod$(C$, 'shiftEnd$I', function (newSize) {
var oldGapEnd = this.getGapEnd();
C$.superClazz.prototype.shiftEnd$I.apply(this, [newSize]);
var dg = this.getGapEnd() - oldGapEnd;
var adjustIndex = this.findMarkAdjustIndex$I(oldGapEnd);
var n = this.marks.size();
for (var i = adjustIndex; i < n; i++) {
var mark = this.marks.elementAt$I(i);
mark.index = mark.index+(dg);
}
});

Clazz.newMethod$(C$, 'getNewArraySize$I', function (reqSize) {
if (reqSize < 524288) {
return C$.superClazz.prototype.getNewArraySize$I.apply(this, [reqSize]);
} else {
return reqSize + 524288;
}});

Clazz.newMethod$(C$, 'shiftGap$I', function (newGapStart) {
var oldGapStart = this.getGapStart();
var dg = newGapStart - oldGapStart;
var oldGapEnd = this.getGapEnd();
var newGapEnd = oldGapEnd + dg;
var gapSize = oldGapEnd - oldGapStart;
C$.superClazz.prototype.shiftGap$I.apply(this, [newGapStart]);
if (dg > 0) {
var adjustIndex = this.findMarkAdjustIndex$I(oldGapStart);
var n = this.marks.size();
for (var i = adjustIndex; i < n; i++) {
var mark = this.marks.elementAt$I(i);
if (mark.index >= newGapEnd) {
break;
}mark.index = mark.index-(gapSize);
}
} else if (dg < 0) {
var adjustIndex = this.findMarkAdjustIndex$I(newGapStart);
var n = this.marks.size();
for (var i = adjustIndex; i < n; i++) {
var mark = this.marks.elementAt$I(i);
if (mark.index >= oldGapEnd) {
break;
}mark.index = mark.index+(gapSize);
}
}this.resetMarksAtZero();
});

Clazz.newMethod$(C$, 'resetMarksAtZero', function () {
if (this.marks != null  && this.getGapStart() == 0 ) {
var g1 = this.getGapEnd();
for (var counter = 0, maxCounter = this.marks.size(); counter < maxCounter; counter++) {
var mark = this.marks.elementAt$I(counter);
if (mark.index <= g1) {
mark.index = 0;
} else {
break;
}}
}});

Clazz.newMethod$(C$, 'shiftGapStartDown$I', function (newGapStart) {
var adjustIndex = this.findMarkAdjustIndex$I(newGapStart);
var n = this.marks.size();
var g0 = this.getGapStart();
var g1 = this.getGapEnd();
for (var i = adjustIndex; i < n; i++) {
var mark = this.marks.elementAt$I(i);
if (mark.index > g0) {
break;
}mark.index = g1;
}
C$.superClazz.prototype.shiftGapStartDown$I.apply(this, [newGapStart]);
this.resetMarksAtZero();
});

Clazz.newMethod$(C$, 'shiftGapEndUp$I', function (newGapEnd) {
var adjustIndex = this.findMarkAdjustIndex$I(this.getGapEnd());
var n = this.marks.size();
for (var i = adjustIndex; i < n; i++) {
var mark = this.marks.elementAt$I(i);
if (mark.index >= newGapEnd) {
break;
}mark.index = newGapEnd;
}
C$.superClazz.prototype.shiftGapEndUp$I.apply(this, [newGapEnd]);
this.resetMarksAtZero();
});

Clazz.newMethod$(C$, 'compare$javax_swing_text_GapContent_MarkData$javax_swing_text_GapContent_MarkData', function (o1, o2) {
if (o1.index < o2.index) {
return -1;
} else if (o1.index > o2.index) {
return 1;
} else {
return 0;
}});

Clazz.newMethod$(C$, 'findMarkAdjustIndex$I', function (searchIndex) {
this.search.index = Math.max(searchIndex, 1);
var index = this.findSortIndex$javax_swing_text_GapContent_MarkData(this.search);
for (var i = index - 1; i >= 0; i--) {
var d = this.marks.elementAt$I(i);
if (d.index != this.search.index) {
break;
}index = index-(1);
}
return index;
});

Clazz.newMethod$(C$, 'findSortIndex$javax_swing_text_GapContent_MarkData', function (o) {
var lower = 0;
var upper = this.marks.size() - 1;
var mid = 0;
if (upper == -1) {
return 0;
}var cmp = 0;
var last = this.marks.elementAt$I(upper);
cmp = this.compare$javax_swing_text_GapContent_MarkData$javax_swing_text_GapContent_MarkData(o, last);
if (cmp > 0) return upper + 1;
while (lower <= upper){
mid = lower + (($i$[0] = (upper - lower)/2, $i$[0]));
var entry = this.marks.elementAt$I(mid);
cmp = this.compare$javax_swing_text_GapContent_MarkData$javax_swing_text_GapContent_MarkData(o, entry);
if (cmp == 0) {
return mid;
} else if (cmp < 0) {
upper = mid - 1;
} else {
lower = mid + 1;
}}
return (cmp < 0) ? mid : mid + 1;
});

Clazz.newMethod$(C$, 'removeUnusedMarks', function () {
var n = this.marks.size();
var cleaned = Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.GapContent').MarkVector))).c$$I,[n]);
for (var i = 0; i < n; i++) {
var mark = this.marks.elementAt$I(i);
if (mark != null ) {
cleaned.addElement$javax_swing_text_GapContent_MarkData(mark);
}}
this.marks = cleaned;
});

Clazz.newMethod$(C$, 'getPositionsInRange$java_util_Vector$I$I', function (v, offset, length) {
var endOffset = offset + length;
var startIndex;
var endIndex;
var g0 = this.getGapStart();
var g1 = this.getGapEnd();
if (offset < g0) {
if (offset == 0) {
startIndex = 0;
} else {
startIndex = this.findMarkAdjustIndex$I(offset);
}if (endOffset >= g0) {
endIndex = this.findMarkAdjustIndex$I(endOffset + (g1 - g0) + 1 );
} else {
endIndex = this.findMarkAdjustIndex$I(endOffset + 1);
}} else {
startIndex = this.findMarkAdjustIndex$I(offset + (g1 - g0));
endIndex = this.findMarkAdjustIndex$I(endOffset + (g1 - g0) + 1 );
}var placeIn = (v == null ) ? Clazz.new((I$[6] || (I$[6]=Clazz.load('java.util.Vector'))).c$$I,[Math.max(1, endIndex - startIndex)]) : v;
for (var counter = startIndex; counter < endIndex; counter++) {
placeIn.addElement$TE(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.text.GapContent').UndoPosRef))).c$$javax_swing_text_GapContent_MarkData, [this, null, this.marks.elementAt$I(counter)]));
}
return placeIn;
});

Clazz.newMethod$(C$, 'updateUndoPositions$java_util_Vector$I$I', function (positions, offset, length) {
var endOffset = offset + length;
var g1 = this.getGapEnd();
var startIndex;
var endIndex = this.findMarkAdjustIndex$I(g1 + 1);
if (offset != 0) {
startIndex = this.findMarkAdjustIndex$I(g1);
} else {
startIndex = 0;
}for (var counter = positions.size() - 1; counter >= 0; counter--) {
var ref = positions.elementAt$I(counter);
ref.resetLocation$I$I(endOffset, g1);
}
if (startIndex < endIndex) {
var sorted =  Clazz.newArray$(java.lang.Object, [endIndex - startIndex]);
var addIndex = 0;
var counter;
if (offset == 0) {
for (counter = startIndex; counter < endIndex; counter++) {
var mark = this.marks.elementAt$I(counter);
if (mark.index == 0) {
sorted[addIndex++] = mark;
}}
for (counter = startIndex; counter < endIndex; counter++) {
var mark = this.marks.elementAt$I(counter);
if (mark.index != 0) {
sorted[addIndex++] = mark;
}}
} else {
for (counter = startIndex; counter < endIndex; counter++) {
var mark = this.marks.elementAt$I(counter);
if (mark.index != g1) {
sorted[addIndex++] = mark;
}}
for (counter = startIndex; counter < endIndex; counter++) {
var mark = this.marks.elementAt$I(counter);
if (mark.index == g1) {
sorted[addIndex++] = mark;
}}
}this.marks.replaceRange$I$I$OA(startIndex, endIndex, sorted);
}});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "MarkData", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.ref = null;
this.index = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (index) {
C$.$init$.apply(this);
this.index = index;
}, 1);

Clazz.newMethod$(C$, 'c$$I$javax_swing_text_GapContent_StickyPosition', function (index, position) {
C$.$init$.apply(this);
this.ref = position;
this.index = index;
}, 1);

Clazz.newMethod$(C$, 'getOffset', function () {
var g0 = this.b$['javax.swing.text.GapContent'].getGapStart();
var g1 = this.b$['javax.swing.text.GapContent'].getGapEnd();
var offs = (this.index < g0) ? this.index : this.index - (g1 - g0);
return Math.max(offs, 0);
});

Clazz.newMethod$(C$, 'getPosition', function () {
return this.ref;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "StickyPosition", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.text.Position');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.mark = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setMark$javax_swing_text_GapContent_MarkData', function (mark) {
this.mark = mark;
});

Clazz.newMethod$(C$, 'getOffset', function () {
return this.mark.getOffset();
});

Clazz.newMethod$(C$, 'toString', function () {
return Integer.toString(this.getOffset());
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "MarkVector", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.GapVector');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.oneMark =  Clazz.newArray$(javax.swing.text.GapContent.MarkData, [1]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (size) {
C$.superClazz.c$$I.apply(this, [size]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'allocateArray$I', function (len) {
return  Clazz.newArray$(javax.swing.text.GapContent.MarkData, [len]);
});

Clazz.newMethod$(C$, 'getArrayLength', function () {
var marks = this.getArray();
return marks.length;
});

Clazz.newMethod$(C$, 'size', function () {
var len = this.getArrayLength() - (this.getGapEnd() - this.getGapStart());
return len;
});

Clazz.newMethod$(C$, 'insertElementAt$javax_swing_text_GapContent_MarkData$I', function (m, index) {
this.oneMark[0] = m;
this.replace$I$I$O$I(index, 0, this.oneMark, 1);
});

Clazz.newMethod$(C$, 'addElement$javax_swing_text_GapContent_MarkData', function (m) {
this.insertElementAt$javax_swing_text_GapContent_MarkData$I(m, this.size());
});

Clazz.newMethod$(C$, 'elementAt$I', function (index) {
var g0 = this.getGapStart();
var g1 = this.getGapEnd();
var array = this.getArray();
if (index < g0) {
return array[index];
} else {
index = index+(g1 - g0);
return array[index];
}});

Clazz.newMethod$(C$, 'replaceRange$I$I$OA', function (start, end, marks) {
var g0 = this.getGapStart();
var g1 = this.getGapEnd();
var index = start;
var newIndex = 0;
var array = this.getArray();
if (start >= g0) {
index = index+((g1 - g0));
end = end+((g1 - g0));
} else if (end >= g0) {
end = end+((g1 - g0));
while (index < g0){
array[index++] = marks[newIndex++];
}
index = g1;
} else {
while (index < end){
array[index++] = marks[newIndex++];
}
}while (index < end){
array[index++] = marks[newIndex++];
}
});
})()
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "UndoPosRef", function(){
Clazz.newInstance$(this, arguments[0], true);
});


Clazz.newMethod$(C$, '$init$', function () {
this.undoLocation = 0;
this.rec = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_GapContent_MarkData', function (rec) {
C$.$init$.apply(this);
this.rec = rec;
this.undoLocation = rec.getOffset();
}, 1);

Clazz.newMethod$(C$, 'resetLocation$I$I', function (endOffset, g1) {
if (this.undoLocation != endOffset) {
this.rec.index = this.undoLocation;
} else {
this.rec.index = g1;
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "InsertUndo", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.undo.AbstractUndoableEdit');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.offset = 0;
this.length = 0;
this.string = null;
this.posRefs = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (offset, length) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.offset = offset;
this.length = length;
}, 1);

Clazz.newMethod$(C$, 'undo', function () {
C$.superClazz.prototype.undo.apply(this, []);
try {
this.posRefs = this.b$['javax.swing.text.GapContent'].getPositionsInRange$java_util_Vector$I$I(null, this.offset, this.length);
this.string = this.b$['javax.swing.text.GapContent'].getString$I$I(this.offset, this.length);
this.b$['javax.swing.text.GapContent'].remove$I$I(this.offset, this.length);
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
throw Clazz.new(Clazz.load('javax.swing.undo.CannotUndoException'));
} else {
throw bl;
}
}
});

Clazz.newMethod$(C$, 'redo', function () {
C$.superClazz.prototype.redo.apply(this, []);
try {
this.b$['javax.swing.text.GapContent'].insertString$I$S(this.offset, this.string);
this.string = null;
if (this.posRefs != null ) {
this.b$['javax.swing.text.GapContent'].updateUndoPositions$java_util_Vector$I$I(this.posRefs, this.offset, this.length);
this.posRefs = null;
}} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
throw Clazz.new(Clazz.load('javax.swing.undo.CannotRedoException'));
} else {
throw bl;
}
}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GapContent, "RemoveUndo", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.undo.AbstractUndoableEdit');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.offset = 0;
this.length = 0;
this.string = null;
this.posRefs = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$S', function (offset, string) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.offset = offset;
this.string = string;
this.length = string.length$();
this.posRefs = this.b$['javax.swing.text.GapContent'].getPositionsInRange$java_util_Vector$I$I(null, offset, this.length);
}, 1);

Clazz.newMethod$(C$, 'undo', function () {
C$.superClazz.prototype.undo.apply(this, []);
try {
this.b$['javax.swing.text.GapContent'].insertString$I$S(this.offset, this.string);
if (this.posRefs != null ) {
this.b$['javax.swing.text.GapContent'].updateUndoPositions$java_util_Vector$I$I(this.posRefs, this.offset, this.length);
this.posRefs = null;
}this.string = null;
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
throw Clazz.new(Clazz.load('javax.swing.undo.CannotUndoException'));
} else {
throw bl;
}
}
});

Clazz.newMethod$(C$, 'redo', function () {
C$.superClazz.prototype.redo.apply(this, []);
try {
this.string = this.b$['javax.swing.text.GapContent'].getString$I$I(this.offset, this.length);
this.posRefs = this.b$['javax.swing.text.GapContent'].getPositionsInRange$java_util_Vector$I$I(null, this.offset, this.length);
this.b$['javax.swing.text.GapContent'].remove$I$I(this.offset, this.length);
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
throw Clazz.new(Clazz.load('javax.swing.undo.CannotRedoException'));
} else {
throw bl;
}
}
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:02
