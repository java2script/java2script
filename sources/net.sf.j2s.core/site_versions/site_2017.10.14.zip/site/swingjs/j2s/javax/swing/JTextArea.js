(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JTextArea", null, 'javax.swing.text.JTextComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.rows = 0;
this.columns = 0;
this.columnWidth = 0;
this.rowHeight = 0;
this.wrap = false;
this.word = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_text_Document$S$I$I.apply(this, [null, null, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (text) {
C$.c$$javax_swing_text_Document$S$I$I.apply(this, [null, text, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (rows, columns) {
C$.c$$javax_swing_text_Document$S$I$I.apply(this, [null, null, rows, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$S$I$I', function (text, rows, columns) {
C$.c$$javax_swing_text_Document$S$I$I.apply(this, [null, text, rows, columns]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document', function (doc) {
C$.c$$javax_swing_text_Document$S$I$I.apply(this, [doc, null, 0, 0]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Document$S$I$I', function (doc, text, rows, columns) {
C$.superClazz.c$$S.apply(this, ["TextAreaUI"]);
C$.$init$.apply(this);
this.rows = rows;
this.columns = columns;
if (doc == null ) {
doc = this.createDefaultModel();
}this.setDocument$javax_swing_text_Document(doc);
if (text != null ) {
this.setText$S(text);
this.select$I$I(0, 0);
}if (rows < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["rows: " + rows]);
}if (columns < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["columns: " + columns]);
}(I$[0] || (I$[0]=Clazz.load('javax.swing.LookAndFeel'))).installProperty$javax_swing_JComponent$S$O(this, "focusTraversalKeysForward", (I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getManagingFocusForwardTraversalKeys());
(I$[0] || (I$[0]=Clazz.load('javax.swing.LookAndFeel'))).installProperty$javax_swing_JComponent$S$O(this, "focusTraversalKeysBackward", (I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getManagingFocusBackwardTraversalKeys());
}, 1);

Clazz.newMethod$(C$, 'createDefaultModel', function () {
return (I$[2] || (I$[2]=Clazz.load('swingjs.JSToolkit'))).getPlainDocument$javax_swing_JComponent(this);
});

Clazz.newMethod$(C$, 'setTabSize$I', function (size) {
var doc = this.getDocument();
if (doc != null ) {
var old = this.getTabSize();
doc.putProperty$O$O("tabSize",  new Integer(size));
this.firePropertyChange$S$I$I("tabSize", old, size);
}});

Clazz.newMethod$(C$, 'getTabSize', function () {
var size = 8;
var doc = this.getDocument();
if (doc != null ) {
var i = doc.getProperty$O("tabSize");
if (i != null ) {
size = i.intValue();
}}return size;
});

Clazz.newMethod$(C$, 'setLineWrap$Z', function (wrap) {
var old = this.wrap;
this.wrap = wrap;
this.firePropertyChange$S$Z$Z("lineWrap", old, wrap);
});

Clazz.newMethod$(C$, 'getLineWrap', function () {
return this.wrap;
});

Clazz.newMethod$(C$, 'setWrapStyleWord$Z', function (word) {
var old = this.word;
this.word = word;
this.firePropertyChange$S$Z$Z("wrapStyleWord", old, word);
});

Clazz.newMethod$(C$, 'getWrapStyleWord', function () {
return this.word;
});

Clazz.newMethod$(C$, 'getLineOfOffset$I', function (offset) {
var doc = this.getDocument();
if (offset < 0) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Can\'t translate offset to line", -1]);
} else if (offset > doc.getLength()) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Can\'t translate offset to line", doc.getLength() + 1]);
} else {
var map = this.getDocument().getDefaultRootElement();
return map.getElementIndex$I(offset);
}});

Clazz.newMethod$(C$, 'getLineCount', function () {
var map = this.getDocument().getDefaultRootElement();
return map.getElementCount();
});

Clazz.newMethod$(C$, 'getLineStartOffset$I', function (line) {
var lineCount = this.getLineCount();
if (line < 0) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Negative line", -1]);
} else if (line >= lineCount) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["No such line", this.getDocument().getLength() + 1]);
} else {
var map = this.getDocument().getDefaultRootElement();
var lineElem = map.getElement$I(line);
return lineElem.getStartOffset();
}});

Clazz.newMethod$(C$, 'getLineEndOffset$I', function (line) {
var lineCount = this.getLineCount();
if (line < 0) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["Negative line", -1]);
} else if (line >= lineCount) {
throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["No such line", this.getDocument().getLength() + 1]);
} else {
var map = this.getDocument().getDefaultRootElement();
var lineElem = map.getElement$I(line);
var endOffset = lineElem.getEndOffset();
return ((line == lineCount - 1) ? (endOffset - 1) : endOffset);
}});

Clazz.newMethod$(C$, 'insert$S$I', function (str, pos) {
var doc = this.getDocument();
if (doc != null ) {
try {
doc.insertString$I$S$javax_swing_text_AttributeSet(pos, str, null);
} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'append$S', function (str) {
var doc = this.getDocument();
if (doc != null ) {
try {
doc.insertString$I$S$javax_swing_text_AttributeSet(doc.getLength(), str, null);
} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'replaceRange$S$I$I', function (str, start, end) {
if (end < start) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["end before start"]);
}var doc = this.getDocument();
if (doc != null ) {
try {
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).replace$I$I$S$javax_swing_text_AttributeSet(start, end - start, str, null);
} else {
doc.remove$I$I(start, end - start);
doc.insertString$I$S$javax_swing_text_AttributeSet(start, str, null);
}} catch (e) {
if (Clazz.exceptionOf(e, P$.text.BadLocationException)){
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
}});

Clazz.newMethod$(C$, 'getRows', function () {
return this.rows;
});

Clazz.newMethod$(C$, 'setRows$I', function (rows) {
var oldVal = this.rows;
if (rows < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["rows less than zero."]);
}if (rows != oldVal) {
this.rows = rows;
this.invalidate();
}});

Clazz.newMethod$(C$, 'getRowHeight', function () {
if (this.rowHeight == 0) {
var metrics = this.getFontMetrics$java_awt_Font(this.getFont());
this.rowHeight = metrics.getHeight();
}return this.rowHeight;
});

Clazz.newMethod$(C$, 'getColumns', function () {
return this.columns;
});

Clazz.newMethod$(C$, 'setColumns$I', function (columns) {
var oldVal = this.columns;
if (columns < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["columns less than zero."]);
}if (columns != oldVal) {
this.columns = columns;
this.invalidate();
}});

Clazz.newMethod$(C$, 'getColumnWidth', function () {
if (this.columnWidth == 0) {
var metrics = this.getFontMetrics$java_awt_Font(this.getFont());
this.columnWidth = metrics.charWidth$C('m');
}return this.columnWidth;
});

Clazz.newMethod$(C$, 'getPreferredSize', function () {
var d = this.getPrefSizeJComp();
d = (d == null ) ? Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[400, 400]) : d;
var insets = this.getInsets();
if (this.columns != 0) {
d.width = Math.max(d.width, this.columns * this.getColumnWidth() + insets.left + insets.right);
}if (this.rows != 0) {
d.height = Math.max(d.height, this.rows * this.getRowHeight() + insets.top + insets.bottom);
}return d;
});

Clazz.newMethod$(C$, 'setFont$java_awt_Font', function (f) {
C$.superClazz.prototype.setFont$java_awt_Font.apply(this, [f]);
this.rowHeight = 0;
this.columnWidth = 0;
});

Clazz.newMethod$(C$, 'paramString', function () {
var wrapString = (this.wrap ? "true" : "false");
var wordString = (this.word ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",colums=" + this.columns + ",columWidth=" + this.columnWidth + ",rows=" + this.rows + ",rowHeight=" + this.rowHeight + ",word=" + wordString + ",wrap=" + wrapString ;
});

Clazz.newMethod$(C$, 'getScrollableTracksViewportWidth', function () {
return (this.wrap) ? true : C$.superClazz.prototype.getScrollableTracksViewportWidth.apply(this, []);
});

Clazz.newMethod$(C$, 'getPreferredScrollableViewportSize', function () {
var size = C$.superClazz.prototype.getPreferredScrollableViewportSize.apply(this, []);
size = (size == null ) ? Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[400, 400]) : size;
var insets = this.getInsets();
size.width = (this.columns == 0) ? size.width : this.columns * this.getColumnWidth() + insets.left + insets.right;
size.height = (this.rows == 0) ? size.height : this.rows * this.getRowHeight() + insets.top + insets.bottom;
return size;
});

Clazz.newMethod$(C$, 'getScrollableUnitIncrement$java_awt_Rectangle$I$I', function (visibleRect, orientation, direction) {
switch (orientation) {
case 1:
return this.getRowHeight();
case 0:
return this.getColumnWidth();
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid orientation: " + orientation]);
}
});
})();
//Created 2017-10-14 13:31:45
