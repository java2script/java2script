(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ProgressMonitorInputStream", null, 'java.io.FilterInputStream');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.monitor = null;
this.nread = 0;
this.size = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$O$java_io_InputStream', function (parentComponent, message, $in) {
C$.superClazz.c$$java_io_InputStream.apply(this, [$in]);
C$.$init$.apply(this);
try {
this.size = $in.available();
} catch (ioe) {
if (Clazz.exceptionOf(ioe, java.io.IOException)){
this.size = 0;
} else {
throw ioe;
}
}
this.monitor = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.ProgressMonitor'))).c$$java_awt_Component$O$S$I$I,[parentComponent, message, null, 0, this.size]);
}, 1);

Clazz.newMethod$(C$, 'getProgressMonitor', function () {
return this.monitor;
});

Clazz.newMethod$(C$, 'read', function () {
return this.readByteAsInt();
});

Clazz.newMethod$(C$, 'readByteAsInt', function () {
var c = this.$in.read();
if (c >= 0) this.monitor.setProgress$I(++this.nread);
if (this.monitor.isCanceled()) {
var exc = Clazz.new(Clazz.load('java.io.InterruptedIOException').c$$S,["progress"]);
exc.bytesTransferred = this.nread;
throw exc;
}return c;
});

Clazz.newMethod$(C$, 'read$BA', function (b) {
var nr = this.$in.read$BA(b);
if (nr > 0) this.monitor.setProgress$I(this.nread = this.nread+(nr));
if (this.monitor.isCanceled()) {
var exc = Clazz.new(Clazz.load('java.io.InterruptedIOException').c$$S,["progress"]);
exc.bytesTransferred = this.nread;
throw exc;
}return nr;
});

Clazz.newMethod$(C$, 'read$BA$I$I', function (b, off, len) {
var nr = this.$in.read$BA$I$I(b, off, len);
if (nr > 0) this.monitor.setProgress$I(this.nread = this.nread+(nr));
if (this.monitor.isCanceled()) {
var exc = Clazz.new(Clazz.load('java.io.InterruptedIOException').c$$S,["progress"]);
exc.bytesTransferred = this.nread;
throw exc;
}return nr;
});

Clazz.newMethod$(C$, 'skip$J', function (n) {
var nr = this.$in.skip$J(n);
if (nr > 0) this.monitor.setProgress$I(this.nread = this.nread+(nr));
return nr;
});

Clazz.newMethod$(C$, 'close', function () {
this.$in.close();
this.monitor.close();
});

Clazz.newMethod$(C$, 'reset', function () {
this.$in.reset();
this.nread = this.size - this.$in.available();
this.monitor.setProgress$I(this.nread);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:48
