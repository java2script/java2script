(function(){var P$=Clazz.newPackage$("javax.swing.table");
var C$=Clazz.newInterface$(P$, "TableCellEditor", null, null, 'javax.swing.CellEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:59
