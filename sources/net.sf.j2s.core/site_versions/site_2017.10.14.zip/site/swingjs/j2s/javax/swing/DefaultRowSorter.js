(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultRowSorter", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.RowSorter');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.sortsOnUpdates = false;
this.viewToModel = null;
this.modelToView = null;
this.comparators = null;
this.$isSortable = null;
this.cachedSortKeys = null;
this.sortComparators = null;
this.filter = null;
this.filterEntry = null;
this.sortKeys = null;
this.$useToString = null;
this.sorted = false;
this.maxSortKeys = 0;
this.modelWrapper = null;
this.modelRowCount = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.sortKeys = (I$[0] || (I$[0]=Clazz.load('java.util.Collections'))).emptyList();
this.maxSortKeys = 3;
}, 1);

Clazz.newMethod$(C$, 'setModelWrapper$javax_swing_DefaultRowSorter_ModelWrapper', function (modelWrapper) {
if (modelWrapper == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["modelWrapper most be non-null"]);
}var last = this.modelWrapper;
this.modelWrapper = modelWrapper;
if (last != null ) {
this.modelStructureChanged();
} else {
this.modelRowCount = this.getModelWrapper().getRowCount();
}});

Clazz.newMethod$(C$, 'getModelWrapper', function () {
return this.modelWrapper;
});

Clazz.newMethod$(C$, 'getModel', function () {
return this.getModelWrapper().getModel();
});

Clazz.newMethod$(C$, 'setSortable$I$Z', function (column, sortable) {
p$.checkColumn$I.apply(this, [column]);
if (this.$isSortable == null ) {
this.$isSortable =  Clazz.newArray$(Boolean.TYPE, [this.getModelWrapper().getColumnCount()]);
for (var i = this.$isSortable.length - 1; i >= 0; i--) {
this.$isSortable[i] = true;
}
}this.$isSortable[column] = sortable;
});

Clazz.newMethod$(C$, 'isSortable$I', function (column) {
p$.checkColumn$I.apply(this, [column]);
return (this.$isSortable == null ) ? true : this.$isSortable[column];
});

Clazz.newMethod$(C$, 'setSortKeys$java_util_List', function (sortKeys) {
var old = this.sortKeys;
if (sortKeys != null  && sortKeys.size() > 0 ) {
var max = this.getModelWrapper().getColumnCount();
for (var key, $key = sortKeys.iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
if (key == null  || key.getColumn() < 0  || key.getColumn() >= max ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid SortKey"]);
}}
this.sortKeys = (I$[0] || (I$[0]=Clazz.load('java.util.Collections'))).unmodifiableList$java_util_List(Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[sortKeys]));
} else {
this.sortKeys = (I$[0] || (I$[0]=Clazz.load('java.util.Collections'))).emptyList();
}if (!this.sortKeys.equals$O(old)) {
this.fireSortOrderChanged();
if (this.viewToModel == null ) {
this.sort();
} else {
p$.sortExistingData.apply(this, []);
}}});

Clazz.newMethod$(C$, 'getSortKeys', function () {
return this.sortKeys;
});

Clazz.newMethod$(C$, 'setMaxSortKeys$I', function (max) {
if (max < 1) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid max"]);
}this.maxSortKeys = max;
});

Clazz.newMethod$(C$, 'getMaxSortKeys', function () {
return this.maxSortKeys;
});

Clazz.newMethod$(C$, 'setSortsOnUpdates$Z', function (sortsOnUpdates) {
this.sortsOnUpdates = sortsOnUpdates;
});

Clazz.newMethod$(C$, 'getSortsOnUpdates', function () {
return this.sortsOnUpdates;
});

Clazz.newMethod$(C$, 'setRowFilter$javax_swing_RowFilter', function (filter) {
this.filter = filter;
this.sort();
});

Clazz.newMethod$(C$, 'getRowFilter', function () {
return this.filter;
});

Clazz.newMethod$(C$, 'toggleSortOrder$I', function (column) {
p$.checkColumn$I.apply(this, [column]);
if (this.isSortable$I(column)) {
var keys = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$java_util_Collection,[this.getSortKeys()]);
var sortKey;
var sortIndex;
for (sortIndex = keys.size() - 1; sortIndex >= 0; sortIndex--) {
if (keys.get$I(sortIndex).getColumn() == column) {
break;
}}
if (sortIndex == -1) {
sortKey = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.RowSorter').SortKey))).c$$I$javax_swing_SortOrder,[column, (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).ASCENDING]);
keys.add$I$TE(0, sortKey);
} else if (sortIndex == 0) {
keys.set$I$TE(0, p$.toggle$javax_swing_RowSorter_SortKey.apply(this, [keys.get$I(0)]));
} else {
keys.remove$I(sortIndex);
keys.add$I$TE(0, Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.RowSorter').SortKey))).c$$I$javax_swing_SortOrder,[column, (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).ASCENDING]));
}if (keys.size() > this.getMaxSortKeys()) {
keys = keys.subList$I$I(0, this.getMaxSortKeys());
}this.setSortKeys$java_util_List(keys);
}});

Clazz.newMethod$(C$, 'toggle$javax_swing_RowSorter_SortKey', function (key) {
if (key.getSortOrder() === (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).ASCENDING ) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.RowSorter').SortKey))).c$$I$javax_swing_SortOrder,[key.getColumn(), (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).DESCENDING]);
}return Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.RowSorter').SortKey))).c$$I$javax_swing_SortOrder,[key.getColumn(), (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).ASCENDING]);
});

Clazz.newMethod$(C$, 'convertRowIndexToView$I', function (index) {
if (this.modelToView == null ) {
if (index < 0 || index >= this.getModelWrapper().getRowCount() ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid index"]);
}return index;
}return this.modelToView[index];
});

Clazz.newMethod$(C$, 'convertRowIndexToModel$I', function (index) {
if (this.viewToModel == null ) {
if (index < 0 || index >= this.getModelWrapper().getRowCount() ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid index"]);
}return index;
}return this.viewToModel[index].modelIndex;
});

Clazz.newMethod$(C$, 'isUnsorted', function () {
var keys = this.getSortKeys();
var keySize = keys.size();
return (keySize == 0 || keys.get$I(0).getSortOrder() === (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).UNSORTED  );
});

Clazz.newMethod$(C$, 'sortExistingData', function () {
var lastViewToModel = p$.getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA.apply(this, [this.viewToModel]);
p$.updateUseToString.apply(this, []);
p$.cacheSortKeys$java_util_List.apply(this, [this.getSortKeys()]);
if (p$.isUnsorted.apply(this, [])) {
if (this.getRowFilter() == null ) {
this.viewToModel = null;
this.modelToView = null;
} else {
var included = 0;
for (var i = 0; i < this.modelToView.length; i++) {
if (this.modelToView[i] != -1) {
this.viewToModel[included].modelIndex = i;
this.modelToView[i] = included++;
}}
}} else {
(I$[4] || (I$[4]=Clazz.load('java.util.Arrays'))).sort$OA(this.viewToModel);
p$.setModelToViewFromViewToModel$Z.apply(this, [false]);
}this.fireRowSorterChanged$IA(lastViewToModel);
});

Clazz.newMethod$(C$, 'sort', function () {
this.sorted = true;
var lastViewToModel = p$.getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA.apply(this, [this.viewToModel]);
p$.updateUseToString.apply(this, []);
if (p$.isUnsorted.apply(this, [])) {
this.cachedSortKeys =  Clazz.newArray$(javax.swing.RowSorter.SortKey, [0]);
if (this.getRowFilter() == null ) {
if (this.viewToModel != null ) {
this.viewToModel = null;
this.modelToView = null;
} else {
return;
}} else {
p$.initializeFilteredMapping.apply(this, []);
}} else {
p$.cacheSortKeys$java_util_List.apply(this, [this.getSortKeys()]);
if (this.getRowFilter() != null ) {
p$.initializeFilteredMapping.apply(this, []);
} else {
p$.createModelToView$I.apply(this, [this.getModelWrapper().getRowCount()]);
p$.createViewToModel$I.apply(this, [this.getModelWrapper().getRowCount()]);
}(I$[4] || (I$[4]=Clazz.load('java.util.Arrays'))).sort$OA(this.viewToModel);
p$.setModelToViewFromViewToModel$Z.apply(this, [false]);
}this.fireRowSorterChanged$IA(lastViewToModel);
});

Clazz.newMethod$(C$, 'updateUseToString', function () {
var i = this.getModelWrapper().getColumnCount();
if (this.$useToString == null  || this.$useToString.length != i ) {
this.$useToString =  Clazz.newArray$(Boolean.TYPE, [i]);
}for (--i; i >= 0; i--) {
this.$useToString[i] = this.useToString$I(i);
}
});

Clazz.newMethod$(C$, 'initializeFilteredMapping', function () {
var rowCount = this.getModelWrapper().getRowCount();
var i;
var j;
var excludedCount = 0;
p$.createModelToView$I.apply(this, [rowCount]);
for (i = 0; i < rowCount; i++) {
if (p$.include$I.apply(this, [i])) {
this.modelToView[i] = i - excludedCount;
} else {
this.modelToView[i] = -1;
excludedCount++;
}}
p$.createViewToModel$I.apply(this, [rowCount - excludedCount]);
for (i = 0, j = 0; i < rowCount; i++) {
if (this.modelToView[i] != -1) {
this.viewToModel[j++].modelIndex = i;
}}
});

Clazz.newMethod$(C$, 'createModelToView$I', function (rowCount) {
if (this.modelToView == null  || this.modelToView.length != rowCount ) {
this.modelToView =  Clazz.newArray$(Integer.TYPE, [rowCount]);
}});

Clazz.newMethod$(C$, 'createViewToModel$I', function (rowCount) {
var recreateFrom = 0;
if (this.viewToModel != null ) {
recreateFrom = Math.min(rowCount, this.viewToModel.length);
if (this.viewToModel.length != rowCount) {
var oldViewToModel = this.viewToModel;
this.viewToModel =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [rowCount]);
System.arraycopy(oldViewToModel, 0, this.viewToModel, 0, recreateFrom);
}} else {
this.viewToModel =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [rowCount]);
}var i;
for (i = 0; i < recreateFrom; i++) {
this.viewToModel[i].modelIndex = i;
}
for (i = recreateFrom; i < rowCount; i++) {
this.viewToModel[i] = Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.DefaultRowSorter').Row))).c$$javax_swing_DefaultRowSorter$I,[this, i]);
}
});

Clazz.newMethod$(C$, 'cacheSortKeys$java_util_List', function (keys) {
var keySize = keys.size();
this.sortComparators =  Clazz.newArray$(java.util.Comparator, [keySize]);
for (var i = 0; i < keySize; i++) {
this.sortComparators[i] = p$.getComparator0$I.apply(this, [keys.get$I(i).getColumn()]);
}
this.cachedSortKeys = keys.toArray$TTA( Clazz.newArray$(javax.swing.RowSorter.SortKey, [keySize]));
});

Clazz.newMethod$(C$, 'useToString$I', function (column) {
return (this.getComparator$I(column) == null );
});

Clazz.newMethod$(C$, 'setModelToViewFromViewToModel$Z', function (unsetFirst) {
var i;
if (unsetFirst) {
for (i = this.modelToView.length - 1; i >= 0; i--) {
this.modelToView[i] = -1;
}
}for (i = this.viewToModel.length - 1; i >= 0; i--) {
this.modelToView[this.viewToModel[i].modelIndex] = i;
}
});

Clazz.newMethod$(C$, 'getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA', function (viewToModel) {
if (viewToModel != null ) {
var viewToModelI =  Clazz.newArray$(Integer.TYPE, [viewToModel.length]);
for (var i = viewToModel.length - 1; i >= 0; i--) {
viewToModelI[i] = viewToModel[i].modelIndex;
}
return viewToModelI;
}return  Clazz.newArray$(Integer.TYPE, [0]);
});

Clazz.newMethod$(C$, 'setComparator$I$java_util_Comparator', function (column, comparator) {
p$.checkColumn$I.apply(this, [column]);
if (this.comparators == null ) {
this.comparators =  Clazz.newArray$(java.util.Comparator, [this.getModelWrapper().getColumnCount()]);
}this.comparators[column] = comparator;
});

Clazz.newMethod$(C$, 'getComparator$I', function (column) {
p$.checkColumn$I.apply(this, [column]);
if (this.comparators != null ) {
return this.comparators[column];
}return null;
});

Clazz.newMethod$(C$, 'getComparator0$I', function (column) {
var comparator = this.getComparator$I(column);
if (comparator != null ) {
return comparator;
}return null;
});

Clazz.newMethod$(C$, 'getFilterEntry$I', function (modelIndex) {
if (this.filterEntry == null ) {
this.filterEntry = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.DefaultRowSorter').FilterEntry))), [this, null]);
}this.filterEntry.modelIndex = modelIndex;
return this.filterEntry;
});

Clazz.newMethod$(C$, 'getViewRowCount', function () {
if (this.viewToModel != null ) {
return this.viewToModel.length;
}return this.getModelWrapper().getRowCount();
});

Clazz.newMethod$(C$, 'getModelRowCount', function () {
return this.getModelWrapper().getRowCount();
});

Clazz.newMethod$(C$, 'allChanged', function () {
this.modelToView = null;
this.viewToModel = null;
this.comparators = null;
this.$isSortable = null;
if (p$.isUnsorted.apply(this, [])) {
this.sort();
} else {
this.setSortKeys$java_util_List(null);
}});

Clazz.newMethod$(C$, 'modelStructureChanged', function () {
p$.allChanged.apply(this, []);
this.modelRowCount = this.getModelWrapper().getRowCount();
});

Clazz.newMethod$(C$, 'allRowsChanged', function () {
this.modelRowCount = this.getModelWrapper().getRowCount();
this.sort();
});

Clazz.newMethod$(C$, 'rowsInserted$I$I', function (firstRow, endRow) {
p$.checkAgainstModel$I$I.apply(this, [firstRow, endRow]);
var newModelRowCount = this.getModelWrapper().getRowCount();
if (endRow >= newModelRowCount) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid range"]);
}this.modelRowCount = newModelRowCount;
if (p$.shouldOptimizeChange$I$I.apply(this, [firstRow, endRow])) {
p$.rowsInserted0$I$I.apply(this, [firstRow, endRow]);
}});

Clazz.newMethod$(C$, 'rowsDeleted$I$I', function (firstRow, endRow) {
p$.checkAgainstModel$I$I.apply(this, [firstRow, endRow]);
if (firstRow >= this.modelRowCount || endRow >= this.modelRowCount ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid range"]);
}this.modelRowCount = this.getModelWrapper().getRowCount();
if (p$.shouldOptimizeChange$I$I.apply(this, [firstRow, endRow])) {
p$.rowsDeleted0$I$I.apply(this, [firstRow, endRow]);
}});

Clazz.newMethod$(C$, 'rowsUpdated$I$I', function (firstRow, endRow) {
p$.checkAgainstModel$I$I.apply(this, [firstRow, endRow]);
if (firstRow >= this.modelRowCount || endRow >= this.modelRowCount ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid range"]);
}if (this.getSortsOnUpdates()) {
if (p$.shouldOptimizeChange$I$I.apply(this, [firstRow, endRow])) {
p$.rowsUpdated0$I$I.apply(this, [firstRow, endRow]);
}} else {
this.sorted = false;
}});

Clazz.newMethod$(C$, 'rowsUpdated$I$I$I', function (firstRow, endRow, column) {
p$.checkColumn$I.apply(this, [column]);
this.rowsUpdated$I$I(firstRow, endRow);
});

Clazz.newMethod$(C$, 'checkAgainstModel$I$I', function (firstRow, endRow) {
if (firstRow > endRow || firstRow < 0  || endRow < 0  || firstRow > this.modelRowCount ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Invalid range"]);
}});

Clazz.newMethod$(C$, 'include$I', function (row) {
var filter = this.getRowFilter();
if (filter != null ) {
return filter.include$javax_swing_RowFilter_Entry(p$.getFilterEntry$I.apply(this, [row]));
}return true;
});

Clazz.newMethod$(C$, 'compare$I$I', function (model1, model2) {
var column;
var sortOrder;
var v1;
var v2;
var result;
for (var counter = 0; counter < this.cachedSortKeys.length; counter++) {
column = this.cachedSortKeys[counter].getColumn();
sortOrder = this.cachedSortKeys[counter].getSortOrder();
if (sortOrder === (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).UNSORTED ) {
result = model1 - model2;
} else {
v1 = this.getModelWrapper().getValueAt$I$I(model1, column);
v2 = this.getModelWrapper().getValueAt$I$I(model2, column);
if (v1 == null ) {
if (v2 == null ) {
result = 0;
} else {
result = -1;
}} else if (v2 == null ) {
result = 1;
} else {
var c = this.sortComparators[counter];
{
result = (c != null ? c.compare$O$O(v1, v2) : typeof c == "object" ? ((v1 = v1.toString()) < (v2 = v2.toString) ? -1 : v1 == v2 ? 0 : 1) : (v1 < v2 ? -1 : v1 == v2 ? 0 : 1));
}}if (sortOrder === (I$[3] || (I$[3]=Clazz.load('javax.swing.SortOrder'))).DESCENDING ) {
result = result*(-1);
}}if (result != 0) {
return result;
}}
return model1 - model2;
});

Clazz.newMethod$(C$, 'isTransformed', function () {
return (this.viewToModel != null );
});

Clazz.newMethod$(C$, 'insertInOrder$java_util_List$javax_swing_DefaultRowSorter_RowA', function (toAdd, current) {
var last = 0;
var index;
var max = toAdd.size();
for (var i = 0; i < max; i++) {
index = (I$[4] || (I$[4]=Clazz.load('java.util.Arrays'))).binarySearch$OA$O(current, toAdd.get$I(i));
if (index < 0) {
index = -1 - index;
}System.arraycopy(current, last, this.viewToModel, last + i, index - last);
this.viewToModel[index + i] = toAdd.get$I(i);
last = index;
}
System.arraycopy(current, last, this.viewToModel, last + max, current.length - last);
});

Clazz.newMethod$(C$, 'shouldOptimizeChange$I$I', function (firstRow, lastRow) {
if (!p$.isTransformed.apply(this, [])) {
return false;
}if (!this.sorted || (lastRow - firstRow) > ($i$[0] = this.viewToModel.length/10, $i$[0]) ) {
this.sort();
return false;
}return true;
});

Clazz.newMethod$(C$, 'rowsInserted0$I$I', function (firstRow, lastRow) {
var oldViewToModel = p$.getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA.apply(this, [this.viewToModel]);
var i;
var delta = (lastRow - firstRow) + 1;
var added = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[delta]);
for (i = firstRow; i <= lastRow; i++) {
if (p$.include$I.apply(this, [i])) {
added.add$TE(Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.DefaultRowSorter').Row))).c$$javax_swing_DefaultRowSorter$I,[this, i]));
}}
var viewIndex;
for (i = this.modelToView.length - 1; i >= firstRow; i--) {
viewIndex = this.modelToView[i];
if (viewIndex != -1) {
this.viewToModel[viewIndex].modelIndex = this.viewToModel[viewIndex].modelIndex+(delta);
}}
if (added.size() > 0) {
(I$[0] || (I$[0]=Clazz.load('java.util.Collections'))).sort$java_util_List(added);
var lastViewToModel = this.viewToModel;
this.viewToModel =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [this.viewToModel.length + added.size()]);
p$.insertInOrder$java_util_List$javax_swing_DefaultRowSorter_RowA.apply(this, [added, lastViewToModel]);
}p$.createModelToView$I.apply(this, [this.getModelWrapper().getRowCount()]);
p$.setModelToViewFromViewToModel$Z.apply(this, [true]);
this.fireRowSorterChanged$IA(oldViewToModel);
});

Clazz.newMethod$(C$, 'rowsDeleted0$I$I', function (firstRow, lastRow) {
var oldViewToModel = p$.getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA.apply(this, [this.viewToModel]);
var removedFromView = 0;
var i;
var viewIndex;
for (i = firstRow; i <= lastRow; i++) {
viewIndex = this.modelToView[i];
if (viewIndex != -1) {
removedFromView++;
this.viewToModel[viewIndex] = null;
}}
var delta = lastRow - firstRow + 1;
for (i = this.modelToView.length - 1; i > lastRow; i--) {
viewIndex = this.modelToView[i];
if (viewIndex != -1) {
this.viewToModel[viewIndex].modelIndex = this.viewToModel[viewIndex].modelIndex-(delta);
}}
if (removedFromView > 0) {
var newViewToModel =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [this.viewToModel.length - removedFromView]);
var newIndex = 0;
var last = 0;
for (i = 0; i < this.viewToModel.length; i++) {
if (this.viewToModel[i] == null ) {
System.arraycopy(this.viewToModel, last, newViewToModel, newIndex, i - last);
newIndex = newIndex+((i - last));
last = i + 1;
}}
System.arraycopy(this.viewToModel, last, newViewToModel, newIndex, this.viewToModel.length - last);
this.viewToModel = newViewToModel;
}p$.createModelToView$I.apply(this, [this.getModelWrapper().getRowCount()]);
p$.setModelToViewFromViewToModel$Z.apply(this, [true]);
this.fireRowSorterChanged$IA(oldViewToModel);
});

Clazz.newMethod$(C$, 'rowsUpdated0$I$I', function (firstRow, lastRow) {
var oldViewToModel = p$.getViewToModelAsInts$javax_swing_DefaultRowSorter_RowA.apply(this, [this.viewToModel]);
var i;
var j;
var delta = lastRow - firstRow + 1;
var modelIndex;
if (this.getRowFilter() == null ) {
var updated =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [delta]);
for (j = 0, i = firstRow; i <= lastRow; i++, j++) {
updated[j] = this.viewToModel[this.modelToView[i]];
}
(I$[4] || (I$[4]=Clazz.load('java.util.Arrays'))).sort$OA(updated);
var intermediary =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [this.viewToModel.length - delta]);
for (i = 0, j = 0; i < this.viewToModel.length; i++) {
modelIndex = this.viewToModel[i].modelIndex;
if (modelIndex < firstRow || modelIndex > lastRow ) {
intermediary[j++] = this.viewToModel[i];
}}
p$.insertInOrder$java_util_List$javax_swing_DefaultRowSorter_RowA.apply(this, [(I$[4] || (I$[4]=Clazz.load('java.util.Arrays'))).asList$TTA(updated), intermediary]);
p$.setModelToViewFromViewToModel$Z.apply(this, [false]);
} else {
var updated = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.ArrayList'))).c$$I,[delta]);
var newlyVisible = 0;
var newlyHidden = 0;
var effected = 0;
for (i = firstRow; i <= lastRow; i++) {
if (this.modelToView[i] == -1) {
if (p$.include$I.apply(this, [i])) {
updated.add$TE(Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.DefaultRowSorter').Row))).c$$javax_swing_DefaultRowSorter$I,[this, i]));
newlyVisible++;
}} else {
if (!p$.include$I.apply(this, [i])) {
newlyHidden++;
} else {
updated.add$TE(this.viewToModel[this.modelToView[i]]);
}this.modelToView[i] = -2;
effected++;
}}
(I$[0] || (I$[0]=Clazz.load('java.util.Collections'))).sort$java_util_List(updated);
var intermediary =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [this.viewToModel.length - effected]);
for (i = 0, j = 0; i < this.viewToModel.length; i++) {
modelIndex = this.viewToModel[i].modelIndex;
if (this.modelToView[modelIndex] != -2) {
intermediary[j++] = this.viewToModel[i];
}}
if (newlyVisible != newlyHidden) {
this.viewToModel =  Clazz.newArray$(javax.swing.DefaultRowSorter.Row, [this.viewToModel.length + newlyVisible - newlyHidden]);
}p$.insertInOrder$java_util_List$javax_swing_DefaultRowSorter_RowA.apply(this, [updated, intermediary]);
p$.setModelToViewFromViewToModel$Z.apply(this, [true]);
}this.fireRowSorterChanged$IA(oldViewToModel);
});

Clazz.newMethod$(C$, 'checkColumn$I', function (column) {
if (column < 0 || column >= this.getModelWrapper().getColumnCount() ) {
throw Clazz.new(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["column beyond range of TableModel"]);
}});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.DefaultRowSorter, "ModelWrapper", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getStringValueAt$I$I', function (row, column) {
var o = this.getValueAt$I$I(row, column);
if (o == null ) {
return "";
}var string = o.toString();
if (string == null ) {
return "";
}return string;
});
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultRowSorter, "FilterEntry", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.RowFilter.Entry');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.modelIndex = 0;
}, 1);

Clazz.newMethod$(C$, 'getModel', function () {
return this.b$['javax.swing.DefaultRowSorter'].getModelWrapper().getModel();
});

Clazz.newMethod$(C$, 'getValueCount', function () {
return this.b$['javax.swing.DefaultRowSorter'].getModelWrapper().getColumnCount();
});

Clazz.newMethod$(C$, 'getValue$I', function (index) {
return this.b$['javax.swing.DefaultRowSorter'].getModelWrapper().getValueAt$I$I(this.modelIndex, index);
});

Clazz.newMethod$(C$, 'getStringValue$I', function (index) {
return this.b$['javax.swing.DefaultRowSorter'].getModelWrapper().getStringValueAt$I$I(this.modelIndex, index);
});

Clazz.newMethod$(C$, 'getIdentifier', function () {
return this.b$['javax.swing.DefaultRowSorter'].getModelWrapper().getIdentifier$I(this.modelIndex);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultRowSorter, "Row", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'Comparable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.sorter = null;
this.modelIndex = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_DefaultRowSorter$I', function (sorter, index) {
C$.$init$.apply(this);
this.sorter = sorter;
this.modelIndex = index;
}, 1);

Clazz.newMethod$(C$, 'compareTo$javax_swing_DefaultRowSorter_Row', function (o) {
return this.sorter.compare$I$I(this.modelIndex, o.modelIndex);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:33
