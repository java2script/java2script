(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JSpinner", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.DISABLED_ACTION = Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.JSpinner').DisabledAction))));
};

C$.DISABLED_ACTION = null;

Clazz.newMethod$(C$, '$init$', function () {
this.model = null;
this.editor = null;
this.modelListener = null;
this.changeEvent = null;
this.editorExplicitlySet = false;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_SpinnerModel', function (model) {
Clazz.super(C$, this,1);
this.model = model;
this.editor = this.createEditor$javax_swing_SpinnerModel(model);
this.setUIProperty$S$O("opaque", new Boolean(true));
this.uiClassID = "SpinnerUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$javax_swing_SpinnerModel.apply(this, [Clazz.new((I$[8] || (I$[8]=Clazz.load('javax.swing.SpinnerNumberModel'))))]);
}, 1);

Clazz.newMethod$(C$, 'createEditor$javax_swing_SpinnerModel', function (model) {
if (Clazz.instanceOf(model, "javax.swing.SpinnerListModel")) {
return Clazz.new((I$[9] || (I$[9]=Clazz.load(Clazz.load('javax.swing.JSpinner').ListEditor))).c$$javax_swing_JSpinner,[this]);
} else if (Clazz.instanceOf(model, "javax.swing.SpinnerNumberModel")) {
return Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.JSpinner').NumberEditor))).c$$javax_swing_JSpinner,[this]);
} else {
return Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.JSpinner').DefaultEditor))).c$$javax_swing_JSpinner,[this]);
}});

Clazz.newMethod$(C$, 'setModel$javax_swing_SpinnerModel', function (model) {
if (model == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null model"]);
}if (!model.equals$O(this.model)) {
var oldModel = this.model;
this.model = model;
if (this.modelListener != null ) {
oldModel.removeChangeListener$javax_swing_event_ChangeListener(this.modelListener);
this.model.addChangeListener$javax_swing_event_ChangeListener(this.modelListener);
}this.firePropertyChange$S$O$O("model", oldModel, model);
if (!this.editorExplicitlySet) {
this.setEditor$javax_swing_JComponent(this.createEditor$javax_swing_SpinnerModel(model));
this.editorExplicitlySet = false;
}this.repaint();
this.revalidate();
}});

Clazz.newMethod$(C$, 'getModel', function () {
return this.model;
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.getModel().getValue();
});

Clazz.newMethod$(C$, 'setValue$O', function (value) {
this.getModel().setValue$O(value);
});

Clazz.newMethod$(C$, 'getNextValue', function () {
return this.getModel().getNextValue();
});

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (listener) {
if (this.modelListener == null ) {
this.modelListener = Clazz.new((I$[12] || (I$[12]=Clazz.load(Clazz.load('javax.swing.JSpinner').ModelListener))), [this, null]);
this.getModel().addChangeListener$javax_swing_event_ChangeListener(this.modelListener);
}this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), listener);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (listener) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), listener);
});

Clazz.newMethod$(C$, 'getChangeListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ChangeListener));
});

Clazz.newMethod$(C$, 'fireStateChanged', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ChangeListener) ) {
if (this.changeEvent == null ) {
this.changeEvent = Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
}(listeners[i + 1]).stateChanged$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'getPreviousValue', function () {
return this.getModel().getPreviousValue();
});

Clazz.newMethod$(C$, 'setEditor$javax_swing_JComponent', function (editor) {
if (editor == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null editor"]);
}if (!editor.equals$O(this.editor)) {
var oldEditor = this.editor;
this.editor = editor;
if (Clazz.instanceOf(oldEditor, "javax.swing.JSpinner.DefaultEditor")) {
(oldEditor).dismiss$javax_swing_JSpinner(this);
}this.editorExplicitlySet = true;
this.firePropertyChange$S$O$O("editor", oldEditor, editor);
this.revalidate();
this.repaint();
}});

Clazz.newMethod$(C$, 'getEditor', function () {
return this.editor;
});

Clazz.newMethod$(C$, 'commitEdit', function () {
var editor = this.getEditor();
if (Clazz.instanceOf(editor, "javax.swing.JSpinner.DefaultEditor")) {
(editor).commitEdit();
}});
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "ModelListener", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
this.b$['javax.swing.JSpinner'].fireStateChanged();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "DefaultEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JPanel', ['javax.swing.event.ChangeListener', 'java.beans.PropertyChangeListener', 'java.awt.LayoutManager']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JSpinner', function (spinner) {
C$.superClazz.c$$java_awt_LayoutManager.apply(this, [null]);
C$.$init$.apply(this);
var ftf = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.JFormattedTextField'))));
ftf.setName$S("Spinner.formattedTextField");
ftf.setValue$O(spinner.getValue());
ftf.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
ftf.setEditable$Z(false);
ftf.setInheritsPopupMenu$Z(true);
var toolTipText = spinner.getToolTipText();
if (toolTipText != null ) {
ftf.setToolTipText$S(toolTipText);
}this.add$java_awt_Component(ftf);
this.setLayout$java_awt_LayoutManager(this);
spinner.addChangeListener$javax_swing_event_ChangeListener(this);
var ftfMap = ftf.getActionMap();
if (ftfMap != null ) {
ftfMap.put$O$javax_swing_Action("increment", P$.JSpinner.DISABLED_ACTION);
ftfMap.put$O$javax_swing_Action("decrement", P$.JSpinner.DISABLED_ACTION);
}}, 1);

Clazz.newMethod$(C$, 'dismiss$javax_swing_JSpinner', function (spinner) {
spinner.removeChangeListener$javax_swing_event_ChangeListener(this);
});

Clazz.newMethod$(C$, 'getSpinner', function () {
for (var c = this; c != null ; c = c.getParent()) {
if (Clazz.instanceOf(c, "javax.swing.JSpinner")) {
return c;
}}
return null;
});

Clazz.newMethod$(C$, 'getTextField', function () {
return this.getComponent$I(0);
});

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var spinner = (e.getSource());
this.getTextField().setValue$O(spinner.getValue());
});

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (e) {
var spinner = this.getSpinner();
if (spinner == null ) {
return;
}var source = e.getSource();
var name = e.getPropertyName();
if ((Clazz.instanceOf(source, "javax.swing.JFormattedTextField")) && "value".equals$O(name) ) {
var lastValue = spinner.getValue();
try {
spinner.setValue$O(this.getTextField().getValue());
} catch (iae) {
if (Clazz.exceptionOf(iae, IllegalArgumentException)){
try {
(source).setValue$O(lastValue);
} catch (iae2) {
if (Clazz.exceptionOf(iae2, IllegalArgumentException)){
} else {
throw iae2;
}
}
} else {
throw iae;
}
}
}});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, child) {
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (child) {
});

Clazz.newMethod$(C$, 'insetSize$java_awt_Container', function (parent) {
var insets = parent.getInsets();
var w = insets.left + insets.right;
var h = insets.top + insets.bottom;
return Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Dimension'))).c$$I$I,[w, h]);
});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (parent) {
var preferredSize = p$.insetSize$java_awt_Container.apply(this, [parent]);
if (parent.getComponentCount() > 0) {
var childSize = this.getComponent$I(0).getPreferredSize();
preferredSize.width = preferredSize.width+(childSize.width);
preferredSize.height = preferredSize.height+(childSize.height);
}return preferredSize;
});

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (parent) {
var minimumSize = p$.insetSize$java_awt_Container.apply(this, [parent]);
if (parent.getComponentCount() > 0) {
var childSize = this.getComponent$I(0).getMinimumSize();
minimumSize.width = minimumSize.width+(childSize.width);
minimumSize.height = minimumSize.height+(childSize.height);
}return minimumSize;
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (parent) {
if (parent.getComponentCount() > 0) {
var insets = parent.getInsets();
var w = parent.getWidth() - (insets.left + insets.right);
var h = parent.getHeight() - (insets.top + insets.bottom);
this.getComponent$I(0).setBounds$I$I$I$I(insets.left, insets.top, w, h);
}});

Clazz.newMethod$(C$, 'commitEdit', function () {
});

Clazz.newMethod$(C$, 'getBaseline$I$I', function (width, height) {
C$.superClazz.prototype.getBaseline$I$I.apply(this, [width, height]);
var insets = this.getInsets();
width = width - insets.left - insets.right ;
height = height - insets.top - insets.bottom ;
var baseline = this.getComponent$I(0).getBaseline$I$I(width, height);
if (baseline >= 0) {
return baseline + insets.top;
}return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior', function () {
return this.getComponent$I(0).getBaselineResizeBehavior();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "NumberEditorFormatter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.NumberFormatter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.model = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_SpinnerNumberModel$java_text_NumberFormat', function (model, format) {
C$.superClazz.c$$java_text_NumberFormat.apply(this, [format]);
C$.$init$.apply(this);
this.model = model;
this.setValueClass$Class(model.getValue().getClass());
}, 1);

Clazz.newMethod$(C$, 'setMinimum$Comparable', function (min) {
this.model.setMinimum$Comparable(min);
});

Clazz.newMethod$(C$, 'getMinimum', function () {
return this.model.getMinimum();
});

Clazz.newMethod$(C$, 'setMaximum$Comparable', function (max) {
this.model.setMaximum$Comparable(max);
});

Clazz.newMethod$(C$, 'getMaximum', function () {
return this.model.getMaximum();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "NumberEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JSpinner.DefaultEditor');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getDefaultPattern$java_util_Locale', function (locale) {
return null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JSpinner', function (spinner) {
C$.c$$javax_swing_JSpinner$S.apply(this, [spinner, C$.getDefaultPattern$java_util_Locale(spinner.getLocale())]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JSpinner$S', function (spinner, decimalFormatPattern) {
C$.c$$javax_swing_JSpinner$java_text_DecimalFormat.apply(this, [spinner, Clazz.new((I$[2] || (I$[2]=Clazz.load('java.text.DecimalFormat'))).c$$S,[decimalFormatPattern])]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JSpinner$java_text_DecimalFormat', function (spinner, format) {
C$.superClazz.c$$javax_swing_JSpinner.apply(this, [spinner]);
C$.$init$.apply(this);
if (!(Clazz.instanceOf(spinner.getModel(), "javax.swing.SpinnerNumberModel"))) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["model not a SpinnerNumberModel"]);
}var model = spinner.getModel();
var formatter = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.JSpinner').NumberEditorFormatter))).c$$javax_swing_SpinnerNumberModel$java_text_NumberFormat,[model, format]);
var factory = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[formatter]);
var ftf = this.getTextField();
ftf.setEditable$Z(true);
ftf.setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(factory);
ftf.setHorizontalAlignment$I(4);
try {
var maxString = formatter.valueToString$O(model.getMinimum());
var minString = formatter.valueToString$O(model.getMaximum());
ftf.setColumns$I(Math.max(maxString.length$(), minString.length$()));
} catch (e) {
if (Clazz.exceptionOf(e, java.text.ParseException)){
} else {
throw e;
}
}
}, 1);

Clazz.newMethod$(C$, 'getFormat', function () {
return ((this.getTextField().getFormatter())).getFormat();
});

Clazz.newMethod$(C$, 'getModel', function () {
return (this.getSpinner().getModel());
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "ListEditor", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JSpinner.DefaultEditor');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JSpinner', function (spinner) {
C$.superClazz.c$$javax_swing_JSpinner.apply(this, [spinner]);
C$.$init$.apply(this);
if (!(Clazz.instanceOf(spinner.getModel(), "javax.swing.SpinnerListModel"))) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["model not a SpinnerListModel"]);
}this.getTextField().setEditable$Z(true);
this.getTextField().setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load(Clazz.load('javax.swing.JSpinner').ListEditor).ListFormatter))), [this, null])]));
}, 1);

Clazz.newMethod$(C$, 'getModel', function () {
return (this.getSpinner().getModel());
});
;
(function(){var C$=Clazz.newClass$(P$.JSpinner.ListEditor, "ListFormatter", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.JFormattedTextField.AbstractFormatter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.filter = null;
}, 1);

Clazz.newMethod$(C$, 'valueToString$O', function (value) {
if (value == null ) {
return "";
}return value.toString();
});

Clazz.newMethod$(C$, 'stringToValue$S', function (string) {
return string;
});

Clazz.newMethod$(C$, 'getDocumentFilter', function () {
if (this.filter == null ) {
this.filter = Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load(Clazz.load(Clazz.load('javax.swing.JSpinner').ListEditor).ListFormatter).Filter))), [this, null]);
}return this.filter;
});
;
(function(){var C$=Clazz.newClass$(P$.JSpinner.ListEditor.ListFormatter, "Filter", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.DocumentFilter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet', function (fb, offset, length, string, attrs) {
if (string != null  && (offset + length) == fb.getDocument().getLength() ) {
var next = this.b$['javax.swing.JSpinner.ListEditor'].getModel().findNextMatch$S(fb.getDocument().getText$I$I(0, offset) + string);
var value = (next != null ) ? next.toString() : null;
if (value != null ) {
fb.remove$I$I(0, offset + length);
fb.insertString$I$S$javax_swing_text_AttributeSet(0, value, null);
this.b$['javax.swing.JSpinner.ListEditor.ListFormatter'].getFormattedTextField().select$I$I(offset + string.length$(), value.length$());
return;
}}C$.superClazz.prototype.replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet.apply(this, [fb, offset, length, string, attrs]);
});

Clazz.newMethod$(C$, 'insertString$javax_swing_text_DocumentFilter_FilterBypass$I$S$javax_swing_text_AttributeSet', function (fb, offset, string, attr) {
this.replace$javax_swing_text_DocumentFilter_FilterBypass$I$I$S$javax_swing_text_AttributeSet(fb, offset, 0, string, attr);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JSpinner, "DisabledAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, null, 'javax.swing.Action');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getValue$S', function (key) {
return null;
});

Clazz.newMethod$(C$, 'putValue$S$O', function (key, value) {
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (b) {
});

Clazz.newMethod$(C$, 'isEnabled', function () {
return false;
});

Clazz.newMethod$(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
});

Clazz.newMethod$(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
});

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (ae) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:43
