(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SpinnerNumberModel", null, 'javax.swing.AbstractSpinnerModel');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.stepSize = null;
this.value = null;
this.minimum = null;
this.maximum = null;
}, 1);

Clazz.newMethod$(C$, 'c$$Number$Comparable$Comparable$Number', function (value, minimum, maximum, stepSize) {
Clazz.super(C$, this,1);
if ((value == null ) || (stepSize == null ) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["value and stepSize must be non-null"]);
}if (!(((minimum == null ) || (minimum.compareTo$TT(value) <= 0) ) && ((maximum == null ) || (maximum.compareTo$TT(value) >= 0) ) )) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["(minimum <= value <= maximum) is false"]);
}this.value = value;
this.minimum = minimum;
this.maximum = maximum;
this.stepSize = stepSize;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I', function (value, minimum, maximum, stepSize) {
C$.c$$Number$Comparable$Comparable$Number.apply(this, [ new Integer(value),  new Integer(minimum),  new Integer(maximum),  new Integer(stepSize)]);
}, 1);

Clazz.newMethod$(C$, 'c$$D$D$D$D', function (value, minimum, maximum, stepSize) {
C$.c$$Number$Comparable$Comparable$Number.apply(this, [ new Double(value),  new Double(minimum),  new Double(maximum),  new Double(stepSize)]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$Number$Comparable$Comparable$Number.apply(this, [ new Integer(0), null, null,  new Integer(1)]);
}, 1);

Clazz.newMethod$(C$, 'setMinimum$Comparable', function (minimum) {
if ((minimum == null ) ? (this.minimum != null ) : !minimum.equals$O(this.minimum)) {
this.minimum = minimum;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getMinimum', function () {
return this.minimum;
});

Clazz.newMethod$(C$, 'setMaximum$Comparable', function (maximum) {
if ((maximum == null ) ? (this.maximum != null ) : !maximum.equals$O(this.maximum)) {
this.maximum = maximum;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getMaximum', function () {
return this.maximum;
});

Clazz.newMethod$(C$, 'setStepSize$Number', function (stepSize) {
if (stepSize == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null stepSize"]);
}if (!stepSize.equals$O(this.stepSize)) {
this.stepSize = stepSize;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getStepSize', function () {
return this.stepSize;
});

Clazz.newMethod$(C$, 'incrValue$I', function (dir) {
var newValue;
if ((Clazz.instanceOf(this.value, "java.lang.Float")) || (Clazz.instanceOf(this.value, "java.lang.Double")) ) {
var v = this.value.doubleValue() + (this.stepSize.doubleValue() * dir);
if (Clazz.instanceOf(this.value, "java.lang.Double")) {
newValue =  new Double(v);
} else {
newValue =  new Float(v);
}} else {
var v = this.value.longValue() + (this.stepSize.longValue() * dir);
if (Clazz.instanceOf(this.value, "java.lang.Long")) {
newValue =  new Long(v);
} else if (Clazz.instanceOf(this.value, "java.lang.Integer")) {
newValue =  new Integer(($i$[0] = v, $i$[0]));
} else if (Clazz.instanceOf(this.value, "java.lang.Short")) {
newValue =  new Short(($s$[0] = v, $s$[0]));
} else {
newValue =  new Byte(($b$[0] = v, $b$[0]));
}}if ((this.maximum != null ) && (this.maximum.compareTo$TT(newValue) < 0) ) {
return null;
}if ((this.minimum != null ) && (this.minimum.compareTo$TT(newValue) > 0) ) {
return null;
} else {
return newValue;
}});

Clazz.newMethod$(C$, 'getNextValue', function () {
return p$.incrValue$I.apply(this, [1]);
});

Clazz.newMethod$(C$, 'getPreviousValue', function () {
return p$.incrValue$I.apply(this, [-1]);
});

Clazz.newMethod$(C$, 'getNumber', function () {
return this.value;
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.value;
});

Clazz.newMethod$(C$, 'setValue$O', function (value) {
if ((value == null ) || !(Clazz.instanceOf(value, "java.lang.Number")) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["illegal value"]);
}if (!value.equals$O(this.value)) {
this.value = value;
this.fireStateChanged();
}});
var $i$ = new Int32Array(1);
var $s$ = new Int16Array(1);
var $b$ = new Int8Array(1);
})();
//Created 2017-10-14 13:31:50
