(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newInterface$(P$, "MutableAttributeSet", null, null, 'javax.swing.text.AttributeSet');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:32:03
