(function(){var P$=Clazz.newPackage$("javax.sound.sampled");
var C$=Clazz.newClass$(P$, "Control", function(){
Clazz.newInstance$(this, arguments);
});


Clazz.newMethod$(C$, '$init$', function () {
this.type = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_sound_sampled_Control_Type', function (type) {
C$.$init$.apply(this);
this.type = type;
}, 1);

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'toString', function () {
return  String.instantialize(this.getType() + " Control");
});
;
(function(){var C$=Clazz.newClass$(P$.Control, "Type", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.name = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name = name;
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (obj) {
return C$.superClazz.prototype.equals$O.apply(this, [obj]);
});

Clazz.newMethod$(C$, 'hashCode', function () {
return C$.superClazz.prototype.hashCode.apply(this, []);
});

Clazz.newMethod$(C$, 'toString', function () {
return this.name;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:29
