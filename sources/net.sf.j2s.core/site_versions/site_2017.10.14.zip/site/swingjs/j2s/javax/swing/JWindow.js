(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JWindow", null, 'java.awt.Window', 'javax.swing.RootPaneContainer');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

C$.windowCount = 0;

Clazz.newMethod$(C$, '$init$', function () {
this.rootPane = null;
this.rootPaneCheckingEnabled = false;
this.transferHandler = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_awt_Frame.apply(this, [null]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_GraphicsConfiguration', function (gc) {
C$.c$$java_awt_Window$java_awt_GraphicsConfiguration.apply(this, [null, gc]);
C$.superClazz.prototype.setFocusableWindowState$Z.apply(this, [false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame', function (owner) {
C$.superClazz.c$$java_awt_Window.apply(this, [owner == null  ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame() : owner]);
C$.$init$.apply(this);
if (owner == null ) {
var ownerShutdownListener = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
this.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}this.windowInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window', function (owner) {
C$.superClazz.c$$java_awt_Window.apply(this, [owner == null  ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame() : owner]);
C$.$init$.apply(this);
if (owner == null ) {
var ownerShutdownListener = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
this.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}this.windowInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window$java_awt_GraphicsConfiguration', function (owner, gc) {
C$.superClazz.c$$java_awt_Window$java_awt_GraphicsConfiguration.apply(this, [owner == null  ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame() : owner, gc]);
C$.$init$.apply(this);
if (owner == null ) {
var ownerShutdownListener = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
this.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}this.windowInit();
}, 1);

Clazz.newMethod$(C$, 'windowInit', function () {
this.setLocale$java_util_Locale((I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getDefaultLocale());
this.setRootPane$javax_swing_JRootPane(this.createRootPane());
this.rootPane.setFrameViewer$swingjs_JSFrameViewer(this.setFrameViewer$swingjs_JSFrameViewer(null));
this.setRootPaneCheckingEnabled$Z(true);
this.uiClassID = "WindowUI";
this.updateUI();
this.addNotify();
this.rootPane.addNotify();
});

Clazz.newMethod$(C$, 'createRootPane', function () {
var rp = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.JRootPane'))).c$$S$Z,["_Window" + (++C$.windowCount), false]);
rp.setOpaque$Z(true);
return rp;
});

Clazz.newMethod$(C$, 'isRootPaneCheckingEnabled', function () {
return this.rootPaneCheckingEnabled;
});

Clazz.newMethod$(C$, 'setTransferHandler$javax_swing_TransferHandler', function (newHandler) {
var oldHandler = this.transferHandler;
this.transferHandler = newHandler;
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).installSwingDropTargetAsNecessary$java_awt_Component$javax_swing_TransferHandler(this, this.transferHandler);
this.firePropertyChange$S$O$O("transferHandler", oldHandler, newHandler);
});

Clazz.newMethod$(C$, 'getTransferHandler', function () {
return this.transferHandler;
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'setRootPaneCheckingEnabled$Z', function (enabled) {
this.rootPaneCheckingEnabled = enabled;
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
if (this.isRootPaneCheckingEnabled()) {
return this.getContentPane().add$java_awt_Component$O$I(comp, constraints, index);
}return this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (comp) {
if (comp === this.rootPane ) {
C$.superClazz.prototype.remove$java_awt_Component.apply(this, [comp]);
} else {
this.getContentPane().remove$java_awt_Component(comp);
}});

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (manager) {
if (this.isRootPaneCheckingEnabled()) {
this.getContentPane().setLayout$java_awt_LayoutManager(manager);
} else {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [manager]);
}});

Clazz.newMethod$(C$, 'getRootPane', function () {
return this.rootPane;
});

Clazz.newMethod$(C$, 'setRootPane$javax_swing_JRootPane', function (root) {
if (this.rootPane != null ) {
this.remove$java_awt_Component(this.rootPane);
}this.rootPane = root;
if (this.rootPane != null ) {
var checkingEnabled = this.isRootPaneCheckingEnabled();
try {
this.setRootPaneCheckingEnabled$Z(false);
this.add$java_awt_Component$O(this.rootPane, "Center");
} finally {
this.setRootPaneCheckingEnabled$Z(checkingEnabled);
}
}});

Clazz.newMethod$(C$, 'getContentPane', function () {
return this.getRootPane().getContentPane();
});

Clazz.newMethod$(C$, 'setContentPane$java_awt_Container', function (contentPane) {
this.getRootPane().setContentPane$java_awt_Container(contentPane);
});

Clazz.newMethod$(C$, 'getLayeredPane', function () {
return this.getRootPane().getLayeredPane();
});

Clazz.newMethod$(C$, 'setLayeredPane$javax_swing_JLayeredPane', function (layeredPane) {
this.getRootPane().setLayeredPane$javax_swing_JLayeredPane(layeredPane);
});

Clazz.newMethod$(C$, 'getGlassPane', function () {
return this.getRootPane().getGlassPane();
});

Clazz.newMethod$(C$, 'setGlassPane$java_awt_Component', function (glassPane) {
this.getRootPane().setGlassPane$java_awt_Component(glassPane);
});

Clazz.newMethod$(C$, 'getGraphics', function () {
(I$[1] || (I$[1]=Clazz.load('javax.swing.JComponent'))).getGraphicsInvoked$java_awt_Component(this);
return C$.superClazz.prototype.getGraphics.apply(this, []);
});

Clazz.newMethod$(C$, 'repaint$J$I$I$I$I', function (time, x, y, width, height) {
if ((I$[3] || (I$[3]=Clazz.load('javax.swing.RepaintManager'))).HANDLE_TOP_LEVEL_PAINT) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.RepaintManager'))).currentManager$java_awt_Component(this).addDirtyRegion$java_awt_Window$I$I$I$I(this, x, y, width, height);
} else {
C$.superClazz.prototype.repaint$J$I$I$I$I.apply(this, [time, x, y, width, height]);
}});

Clazz.newMethod$(C$, 'paramString', function () {
var rootPaneCheckingEnabledString = (this.rootPaneCheckingEnabled ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",rootPaneCheckingEnabled=" + rootPaneCheckingEnabledString ;
});
})();
//Created 2017-10-14 13:31:47
