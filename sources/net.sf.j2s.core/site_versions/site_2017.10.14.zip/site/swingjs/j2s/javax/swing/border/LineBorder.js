(function(){var P$=Clazz.newPackage$("javax.swing.border"),I$=[];
var C$=Clazz.newClass$(P$, "LineBorder", null, 'javax.swing.border.AbstractBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

C$.blackLine = null;
C$.grayLine = null;

Clazz.newMethod$(C$, '$init$', function () {
this.thickness = 0;
this.lineColor = null;
this.roundedCorners = false;
}, 1);

Clazz.newMethod$(C$, 'createBlackLineBorder', function () {
if (C$.blackLine == null ) {
C$.blackLine = Clazz.new(C$.c$$java_awt_Color$I,[(I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).black, 1]);
}return C$.blackLine;
}, 1);

Clazz.newMethod$(C$, 'createGrayLineBorder', function () {
if (C$.grayLine == null ) {
C$.grayLine = Clazz.new(C$.c$$java_awt_Color$I,[(I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).gray, 1]);
}return C$.grayLine;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color', function (color) {
C$.c$$java_awt_Color$I$Z.apply(this, [color, 1, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$I', function (color, thickness) {
C$.c$$java_awt_Color$I$Z.apply(this, [color, thickness, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$I$Z', function (color, thickness, roundedCorners) {
Clazz.super(C$, this,1);
this.lineColor = color;
this.thickness = thickness;
this.roundedCorners = roundedCorners;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
if ((this.thickness > 0) && (Clazz.instanceOf(g, "java.awt.Graphics2D")) ) {
var g2d = g;
var oldColor = g2d.getColor();
g2d.setColor$java_awt_Color(this.lineColor);
var outer;
var inner;
var offs = this.thickness;
var size = offs + offs;
if (this.roundedCorners) {
var arc = offs + size;
outer = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('java.awt.geom.RoundRectangle2D').Float))).c$$F$F$F$F$F$F,[x, y, width, height, arc, arc]);
inner = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('java.awt.geom.RoundRectangle2D').Float))).c$$F$F$F$F$F$F,[x + offs, y + offs, width - size, height - size, arc, arc]);
} else {
outer = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('java.awt.geom.Rectangle2D').Float))).c$$F$F$F$F,[x, y, width, height]);
inner = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('java.awt.geom.Rectangle2D').Float))).c$$F$F$F$F,[x + offs, y + offs, width - size, height - size]);
}var path = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('java.awt.geom.Path2D').Float))).c$$I,[0]);
path.append$java_awt_Shape$Z(outer, false);
path.append$java_awt_Shape$Z(inner, false);
g2d.fill$java_awt_Shape(path);
g2d.setColor$java_awt_Color(oldColor);
}});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[this.thickness, this.thickness, this.thickness, this.thickness]);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.left = insets.top = insets.right = insets.bottom = this.thickness;
return insets;
});

Clazz.newMethod$(C$, 'getLineColor', function () {
return this.lineColor;
});

Clazz.newMethod$(C$, 'getThickness', function () {
return this.thickness;
});

Clazz.newMethod$(C$, 'getRoundedCorners', function () {
return this.roundedCorners;
});

Clazz.newMethod$(C$, 'isBorderOpaque', function () {
return !this.roundedCorners;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:52
