(function(){var P$=Clazz.newPackage$("javax.imageio"),I$=[];
var C$=Clazz.newClass$(P$, "ImageIO", function(){
Clazz.newInstance$(this, arguments);
});
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.PNG = 0;
C$.JPG = 1;
C$.GIF = 2;
C$.BMP = 3;
C$.readerTypes =  Clazz.newArray$(java.lang.String, -1, ["image/png", "image/jpeg", "image/x-png", "image/vnd.wap.wbmp", "image/gif", "image/bmp"]);
C$.readerMap =  Clazz.newArray$(Integer.TYPE, -1, [C$.PNG, C$.JPG, C$.PNG, C$.BMP, C$.GIF, C$.BMP]);
C$.readerFormatNames =  Clazz.newArray$(java.lang.String, -1, ["jpg", "BMP", "bmp", "JPG", "wbmp", "jpeg", "png", "PNG", "JPEG", "WBMP", "GIF", "gif"]);
C$.readerSuffixes =  Clazz.newArray$(java.lang.String, -1, ["jpg", "bmp", "jpeg", "wbmp", "png", "gif"]);
};

C$.PNG = 0;
C$.JPG = 0;
C$.GIF = 0;
C$.BMP = 0;
C$.readerTypes = null;
C$.readerMap = null;
C$.readerFormatNames = null;
C$.readerSuffixes = null;

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'setUseCache$Z', function (useCache) {
}, 1);

Clazz.newMethod$(C$, 'getUseCache', function () {
return false;
}, 1);

Clazz.newMethod$(C$, 'setCacheDirectory$java_io_File', function (cacheDirectory) {
}, 1);

Clazz.newMethod$(C$, 'getCacheDirectory', function () {
return null;
}, 1);

Clazz.newMethod$(C$, 'getReaderFormatNames', function () {
return C$.readerFormatNames;
}, 1);

Clazz.newMethod$(C$, 'getReaderMIMETypes', function () {
return C$.readerTypes;
}, 1);

Clazz.newMethod$(C$, 'getReaderFileSuffixes', function () {
return C$.readerSuffixes;
}, 1);

Clazz.newMethod$(C$, 'read$java_io_InputStream', function (input) {
return (I$[1] || (I$[1]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit().createImage$BA((I$[0] || (I$[0]=Clazz.load('swingjs.JSUtil'))).getSignedStreamBytes$java_io_BufferedInputStream(Clazz.instanceOf(input, "java.io.BufferedInputStream") ? input : Clazz.new((I$[2] || (I$[2]=Clazz.load('java.io.BufferedInputStream'))).c$$java_io_InputStream,[input])));
}, 1);

Clazz.newMethod$(C$, 'read$java_net_URL', function (input) {
return C$.read$java_io_InputStream(input.openStream());
}, 1);

Clazz.newMethod$(C$, 'read$javax_imageio_stream_ImageInputStream', function (stream) {
(I$[0] || (I$[0]=Clazz.load('swingjs.JSUtil'))).notImplemented$S("ImageIO.read(ImageInputStream");
return null;
}, 1);

Clazz.newMethod$(C$, 'write$java_awt_image_RenderedImage$S$javax_imageio_stream_ImageOutputStream', function (im, formatName, output) {
(I$[0] || (I$[0]=Clazz.load('swingjs.JSUtil'))).notImplemented$S("ImageIO.write(RenderedImage, String, ImageOutputStream");
return false;
}, 1);

Clazz.newMethod$(C$, 'write$java_awt_image_RenderedImage$S$java_io_File', function (im, formatName, output) {
if (im == null  || output == null   || formatName == null  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ImageIO.write(RenderedImage,String,File)"]);
}var writer = C$.getWriter$java_awt_image_RenderedImage$S(im, formatName);
return (writer != null  && writer.write$S$java_io_OutputStream(output.getName(), null) );
}, 1);

Clazz.newMethod$(C$, 'write$java_awt_image_RenderedImage$S$java_io_OutputStream', function (im, formatName, output) {
if (im == null  || output == null   || formatName == null  ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["ImageIO.write(RenderedImage,String,OutputStream)"]);
}var writer = C$.getWriter$java_awt_image_RenderedImage$S(im, formatName);
return (writer != null  && writer.write$S$java_io_OutputStream(null, output) );
}, 1);

Clazz.newMethod$(C$, 'getWriter$java_awt_image_RenderedImage$S', function (im, formatName) {
try {
return (I$[3] || (I$[3]=Clazz.load('javajs.api.Interface'))).getInstanceWithParams$S$ClassA$OA("javax.imageio.ImageWriter",  Clazz.newArray$(java.lang.Class, -1, [Clazz.getClass(java.awt.image.RenderedImage), Clazz.getClass(java.lang.String)]),  Clazz.newArray$(java.lang.Object, -1, [im, formatName]));
} catch (e) {
if (Clazz.exceptionOf(e, Exception)){
return null;
} else {
throw e;
}
}
}, 1);
;
(function(){var C$=Clazz.newClass$(P$.ImageIO, "CacheInfo", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.useCache = false;
this.hasPermission = Boolean.TRUE;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getUseCache', function () {
return this.useCache;
});

Clazz.newMethod$(C$, 'setUseCache$Z', function (useCache) {
this.useCache = useCache;
});

Clazz.newMethod$(C$, 'getCacheDirectory', function () {
return null;
});

Clazz.newMethod$(C$, 'setCacheDirectory$java_io_File', function (cacheDirectory) {
(I$[0] || (I$[0]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
});

Clazz.newMethod$(C$, 'getHasPermission', function () {
return this.hasPermission;
});

Clazz.newMethod$(C$, 'setHasPermission$Boolean', function (hasPermission) {
this.hasPermission = hasPermission;
});
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
