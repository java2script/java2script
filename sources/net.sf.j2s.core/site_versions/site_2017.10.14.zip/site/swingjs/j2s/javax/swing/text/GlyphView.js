(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "GlyphView", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.View', ['javax.swing.text.TabableView', 'Cloneable']);
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

C$.defaultPainter = null;

Clazz.newMethod$(C$, '$init$', function () {
this.offset = 0;
this.length = 0;
this.impliedCR = false;
this.skipWidth = false;
this.expander = null;
this.x = 0;
this.painter = null;
this.justificationInfo = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.superClazz.c$$javax_swing_text_Element.apply(this, [elem]);
C$.$init$.apply(this);
this.offset = 0;
this.length = 0;
var parent = elem.getParentElement();
var attr = elem.getAttributes();
this.impliedCR = (attr != null  && attr.getAttribute$O("CR") != null   && parent != null   && parent.getElementCount() > 1 );
this.skipWidth = elem.getName().equals$O("br");
}, 1);

Clazz.newMethod$(C$, 'clone', function () {
var o;
try {
o = Clazz.clone(this);
} catch (cnse) {
if (Clazz.exceptionOf(cnse, CloneNotSupportedException)){
o = null;
} else {
throw cnse;
}
}
return o;
});

Clazz.newMethod$(C$, 'getGlyphPainter', function () {
return this.painter;
});

Clazz.newMethod$(C$, 'setGlyphPainter$javax_swing_text_GlyphView_GlyphPainter', function (p) {
this.painter = p;
});

Clazz.newMethod$(C$, 'getText$I$I', function (p0, p1) {
var text = (I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).getSharedSegment();
try {
var doc = this.getDocument();
doc.getText$I$I$javax_swing_text_Segment(p0, p1 - p0, text);
} catch (bl) {
if (Clazz.exceptionOf(bl, P$.BadLocationException)){
throw Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.StateInvariantError'))).c$$S,["GlyphView: Stale view: " + bl]);
} else {
throw bl;
}
}
return text;
});

Clazz.newMethod$(C$, 'getBackground', function () {
var doc = this.getDocument();
if (Clazz.instanceOf(doc, "javax.swing.text.StyledDocument")) {
var attr = this.getAttributes();
if (attr.isDefined$O((I$[3] || (I$[3]=Clazz.load('javax.swing.text.StyleConstants'))).Background)) {
return (doc).getBackground$javax_swing_text_AttributeSet(attr);
}}return null;
});

Clazz.newMethod$(C$, 'getForeground', function () {
var doc = this.getDocument();
if (Clazz.instanceOf(doc, "javax.swing.text.StyledDocument")) {
var attr = this.getAttributes();
return (doc).getForeground$javax_swing_text_AttributeSet(attr);
}var c = this.getContainer();
if (c != null ) {
return c.getForeground();
}return null;
});

Clazz.newMethod$(C$, 'getFont', function () {
var doc = this.getDocument();
if (Clazz.instanceOf(doc, "javax.swing.text.StyledDocument")) {
var attr = this.getAttributes();
return (doc).getFont$javax_swing_text_AttributeSet(attr);
}var c = this.getContainer();
if (c != null ) {
return c.getFont();
}return null;
});

Clazz.newMethod$(C$, 'isUnderline', function () {
var attr = this.getAttributes();
return (I$[3] || (I$[3]=Clazz.load('javax.swing.text.StyleConstants'))).isUnderline$javax_swing_text_AttributeSet(attr);
});

Clazz.newMethod$(C$, 'isStrikeThrough', function () {
var attr = this.getAttributes();
return (I$[3] || (I$[3]=Clazz.load('javax.swing.text.StyleConstants'))).isStrikeThrough$javax_swing_text_AttributeSet(attr);
});

Clazz.newMethod$(C$, 'isSubscript', function () {
var attr = this.getAttributes();
return (I$[3] || (I$[3]=Clazz.load('javax.swing.text.StyleConstants'))).isSubscript$javax_swing_text_AttributeSet(attr);
});

Clazz.newMethod$(C$, 'isSuperscript', function () {
var attr = this.getAttributes();
return (I$[3] || (I$[3]=Clazz.load('javax.swing.text.StyleConstants'))).isSuperscript$javax_swing_text_AttributeSet(attr);
});

Clazz.newMethod$(C$, 'getTabExpander', function () {
return this.expander;
});

Clazz.newMethod$(C$, 'checkPainter', function () {
if (this.painter == null ) {
if (C$.defaultPainter == null ) {
var classname = "javax.swing.text.GlyphPainter1";
try {
var c;
var loader = this.getClass().getClassLoader();
if (loader != null ) {
c = loader.loadClass$S(classname);
} else {
c = Clazz._4Name(classname);
}var o = c.newInstance();
if (Clazz.instanceOf(o, "javax.swing.text.GlyphView.GlyphPainter")) {
C$.defaultPainter = o;
}} catch (e) {
throw Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.StateInvariantError'))).c$$S,["GlyphView: Can't load glyph painter: " + classname]);
}
}this.setGlyphPainter$javax_swing_text_GlyphView_GlyphPainter(C$.defaultPainter.getPainter$javax_swing_text_GlyphView$I$I(this, this.getStartOffset(), this.getEndOffset()));
}});

Clazz.newMethod$(C$, 'getTabbedSpan$F$javax_swing_text_TabExpander', function (x, e) {
this.checkPainter();
var old = this.expander;
this.expander = e;
if (this.expander !== old ) {
this.preferenceChanged$javax_swing_text_View$Z$Z(null, true, false);
}this.x = ($i$[0] = x, $i$[0]);
var p0 = this.getStartOffset();
var p1 = this.getEndOffset();
var width = this.painter.getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F(this, p0, p1, this.expander, x);
return width;
});

Clazz.newMethod$(C$, 'getPartialSpan$I$I', function (p0, p1) {
this.checkPainter();
var width = this.painter.getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F(this, p0, p1, this.expander, this.x);
return width;
});

Clazz.newMethod$(C$, 'getStartOffset', function () {
var e = this.getElement();
return (this.length > 0) ? e.getStartOffset() + this.offset : e.getStartOffset();
});

Clazz.newMethod$(C$, 'getEndOffset', function () {
var e = this.getElement();
return (this.length > 0) ? e.getStartOffset() + this.offset + this.length  : e.getEndOffset();
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics$java_awt_Shape', function (g, a) {
});

Clazz.newMethod$(C$, 'paintTextUsingColor$java_awt_Graphics$java_awt_Shape$java_awt_Color$I$I', function (g, a, c, p0, p1) {
g.setColor$java_awt_Color(c);
this.painter.paint$javax_swing_text_GlyphView$java_awt_Graphics$java_awt_Shape$I$I(this, g, a, p0, p1);
var underline = this.isUnderline();
var strike = this.isStrikeThrough();
if (underline || strike ) {
var alloc = (Clazz.instanceOf(a, "java.awt.Rectangle")) ? a : a.getBounds();
var parent = this.getParent();
if ((parent != null ) && (parent.getEndOffset() == p1) ) {
var s = this.getText$I$I(p0, p1);
while (Character.isWhitespace(s.last())){
p1 = p1-(1);
s.count = s.count-(1);
}
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(s);
}var x0 = alloc.x;
var p = this.getStartOffset();
if (p != p0) {
x0 = x0+(($i$[0] = this.painter.getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F(this, p, p0, this.getTabExpander(), x0), $i$[0]));
}var x1 = x0 + ($i$[0] = this.painter.getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F(this, p0, p1, this.getTabExpander(), x0), $i$[0]);
var y = alloc.y + alloc.height - ($i$[0] = this.painter.getDescent$javax_swing_text_GlyphView(this), $i$[0]);
if (underline) {
var yTmp = y + 1;
g.drawLine$I$I$I$I(x0, yTmp, x1, yTmp);
}if (strike) {
var yTmp = y - ($i$[0] = (this.painter.getAscent$javax_swing_text_GlyphView(this) * 0.3), $i$[0]);
g.drawLine$I$I$I$I(x0, yTmp, x1, yTmp);
}}});

Clazz.newMethod$(C$, 'getPreferredSpan$I', function (axis) {
if (this.impliedCR) {
return 0;
}this.checkPainter();
var p0 = this.getStartOffset();
var p1 = this.getEndOffset();
switch (axis) {
case 0:
if (this.skipWidth) {
return 0;
}return this.painter.getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F(this, p0, p1, this.expander, this.x);
case 1:
var h = this.painter.getHeight$javax_swing_text_GlyphView(this);
if (this.isSuperscript()) {
h += h / 3;
}return h;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Invalid axis: " + axis]);
}
});

Clazz.newMethod$(C$, 'getAlignment$I', function (axis) {
this.checkPainter();
if (axis == 1) {
var sup = this.isSuperscript();
var sub = this.isSubscript();
var h = this.painter.getHeight$javax_swing_text_GlyphView(this);
var d = this.painter.getDescent$javax_swing_text_GlyphView(this);
var a = this.painter.getAscent$javax_swing_text_GlyphView(this);
var align;
if (sup) {
align = 1.0;
} else if (sub) {
align = (h > 0 ) ? (h - (d + (a / 2))) / h : 0;
} else {
align = (h > 0 ) ? (h - d) / h : 0;
}return align;
}return C$.superClazz.prototype.getAlignment$I.apply(this, [axis]);
});

Clazz.newMethod$(C$, 'modelToView$I$java_awt_Shape$javax_swing_text_Position_Bias', function (pos, a, b) {
this.checkPainter();
return this.painter.modelToView$javax_swing_text_GlyphView$I$javax_swing_text_Position_Bias$java_awt_Shape(this, pos, b, a);
});

Clazz.newMethod$(C$, 'viewToModel$F$F$java_awt_Shape$javax_swing_text_Position_BiasA', function (x, y, a, biasReturn) {
this.checkPainter();
return this.painter.viewToModel$javax_swing_text_GlyphView$F$F$java_awt_Shape$javax_swing_text_Position_BiasA(this, x, y, a, biasReturn);
});

Clazz.newMethod$(C$, 'getBreakWeight$I$F$F', function (axis, pos, len) {
if (axis == 0) {
this.checkPainter();
var p0 = this.getStartOffset();
var p1 = this.painter.getBoundedPosition$javax_swing_text_GlyphView$I$F$F(this, p0, pos, len);
if (p1 == p0) {
return 0;
}if (p$.getBreakSpot$I$I.apply(this, [p0, p1]) != -1) {
return 2000;
}if (p1 == this.getEndOffset()) {
return 1000;
} else {
return 999;
}}return C$.superClazz.prototype.getBreakWeight$I$F$F.apply(this, [axis, pos, len]);
});

Clazz.newMethod$(C$, 'breakView$I$I$F$F', function (axis, p0, pos, len) {
if (axis == 0) {
this.checkPainter();
var p1 = this.painter.getBoundedPosition$javax_swing_text_GlyphView$I$F$F(this, p0, pos, len);
var breakSpot = p$.getBreakSpot$I$I.apply(this, [p0, p1]);
if (breakSpot != -1) {
p1 = breakSpot;
}if (p0 == this.getStartOffset() && p1 == this.getEndOffset() ) {
return this;
}var v = this.createFragment$I$I(p0, p1);
v.x = ($i$[0] = pos, $i$[0]);
return v;
}return this;
});

Clazz.newMethod$(C$, 'getBreakSpot$I$I', function (p0, p1) {
var doc = this.getDocument();
if (doc != null  && Boolean.TRUE.equals(doc.getProperty$O((I$[4] || (I$[4]=Clazz.load('javax.swing.text.AbstractDocument'))).MultiByteProperty)) ) {
return p$.getBreakSpotUseBreakIterator$I$I.apply(this, [p0, p1]);
}return p$.getBreakSpotUseWhitespace$I$I.apply(this, [p0, p1]);
});

Clazz.newMethod$(C$, 'getBreakSpotUseWhitespace$I$I', function (p0, p1) {
var s = this.getText$I$I(p0, p1);
for (var ch = s.last(); ch != '\uffff'; ch = s.previous()) {
if (Character.isWhitespace(ch)) {
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(s);
return s.getIndex() - s.getBeginIndex() + 1 + p0;
}}
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(s);
return -1;
});

Clazz.newMethod$(C$, 'getBreakSpotUseBreakIterator$I$I', function (p0, p1) {
return 0;
});

Clazz.newMethod$(C$, 'createFragment$I$I', function (p0, p1) {
this.checkPainter();
var elem = this.getElement();
var v = this.clone();
v.offset = p0 - elem.getStartOffset();
v.length = p1 - p0;
v.painter = this.painter.getPainter$javax_swing_text_GlyphView$I$I(v, p0, p1);
v.justificationInfo = null;
return v;
});

Clazz.newMethod$(C$, 'getNextVisualPositionFrom$I$javax_swing_text_Position_Bias$java_awt_Shape$I$javax_swing_text_Position_BiasA', function (pos, b, a, direction, biasRet) {
return this.painter.getNextVisualPositionFrom$javax_swing_text_GlyphView$I$javax_swing_text_Position_Bias$java_awt_Shape$I$javax_swing_text_Position_BiasA(this, pos, b, a, direction, biasRet);
});

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (e, a, f) {
this.justificationInfo = null;
p$.syncCR.apply(this, []);
this.preferenceChanged$javax_swing_text_View$Z$Z(null, true, false);
});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (e, a, f) {
this.justificationInfo = null;
p$.syncCR.apply(this, []);
this.preferenceChanged$javax_swing_text_View$Z$Z(null, true, false);
});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (e, a, f) {
p$.syncCR.apply(this, []);
this.preferenceChanged$javax_swing_text_View$Z$Z(null, true, true);
});

Clazz.newMethod$(C$, 'syncCR', function () {
if (this.impliedCR) {
var parent = this.getElement().getParentElement();
this.impliedCR = (parent != null  && parent.getElementCount() > 1 );
}});

Clazz.newMethod$(C$, 'getJustificationInfo$I', function (rowStartOffset) {
if (this.justificationInfo != null ) {
return this.justificationInfo;
}var TRAILING = 0;
var CONTENT = 1;
var SPACES = 2;
var startOffset = this.getStartOffset();
var endOffset = this.getEndOffset();
var segment = this.getText$I$I(startOffset, endOffset);
var txtOffset = segment.offset;
var txtEnd = segment.offset + segment.count - 1;
var startContentPosition = txtEnd + 1;
var endContentPosition = txtOffset - 1;
var trailingSpaces = 0;
var contentSpaces = 0;
var leadingSpaces = 0;
var hasTab = false;
var spaceMap = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.util.BitSet'))).c$$I,[endOffset - startOffset + 1]);
for (var i = txtEnd, state = 0; i >= txtOffset; i--) {
if (' ' == segment.array[i]) {
spaceMap.set$I(i - txtOffset);
if (state == 0) {
trailingSpaces++;
} else if (state == 1) {
state = 2;
leadingSpaces = 1;
} else if (state == 2) {
leadingSpaces++;
}} else if ('\u0009' == segment.array[i]) {
hasTab = true;
break;
} else {
if (state == 0) {
if ('\u000a' != segment.array[i] && '\u000d' != segment.array[i] ) {
state = 1;
endContentPosition = i;
}} else if (state == 1) {
} else if (state == 2) {
contentSpaces = contentSpaces+(leadingSpaces);
leadingSpaces = 0;
}startContentPosition = i;
}}
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(segment);
var startJustifiableContent = -1;
if (startContentPosition < txtEnd) {
startJustifiableContent = startContentPosition - txtOffset;
}var endJustifiableContent = -1;
if (endContentPosition > txtOffset) {
endJustifiableContent = endContentPosition - txtOffset;
}this.justificationInfo = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.GlyphView').JustificationInfo))).c$$I$I$I$I$I$Z$java_util_BitSet,[startJustifiableContent, endJustifiableContent, leadingSpaces, contentSpaces, trailingSpaces, hasTab, spaceMap]);
return this.justificationInfo;
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.GlyphView, "JustificationInfo", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.start = 0;
this.end = 0;
this.leadingSpaces = 0;
this.contentSpaces = 0;
this.trailingSpaces = 0;
this.hasTab = false;
this.spaceMap = null;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I$I$Z$java_util_BitSet', function (start, end, leadingSpaces, contentSpaces, trailingSpaces, hasTab, spaceMap) {
C$.$init$.apply(this);
this.start = start;
this.end = end;
this.leadingSpaces = leadingSpaces;
this.contentSpaces = contentSpaces;
this.trailingSpaces = trailingSpaces;
this.hasTab = hasTab;
this.spaceMap = spaceMap;
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.GlyphView, "GlyphPainter", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getPainter$javax_swing_text_GlyphView$I$I', function (v, p0, p1) {
return this;
});

Clazz.newMethod$(C$, 'getNextVisualPositionFrom$javax_swing_text_GlyphView$I$javax_swing_text_Position_Bias$java_awt_Shape$I$javax_swing_text_Position_BiasA', function (v, pos, b, a, direction, biasRet) {
var startOffset = v.getStartOffset();
var endOffset = v.getEndOffset();
switch (direction) {
case 1:
case 5:
if (pos != -1) {
return -1;
}var container = v.getContainer();
if (Clazz.instanceOf(container, "javax.swing.text.JTextComponent")) {
var c = (container).getCaret();
var magicPoint;
magicPoint = (c != null ) ? c.getMagicCaretPosition() : null;
if (magicPoint == null ) {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return startOffset;
}var value = v.viewToModel$F$F$java_awt_Shape$javax_swing_text_Position_BiasA(magicPoint.x, 0.0, a, biasRet);
return value;
}break;
case 3:
if (startOffset == v.getDocument().getLength()) {
if (pos == -1) {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return startOffset;
}return -1;
}if (pos == -1) {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return startOffset;
}if (pos == endOffset) {
return -1;
}if (++pos == endOffset) {
return -1;
} else {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
}return pos;
case 7:
if (startOffset == v.getDocument().getLength()) {
if (pos == -1) {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return startOffset;
}return -1;
}if (pos == -1) {
biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return endOffset - 1;
}if (pos == startOffset) {
return -1;
}biasRet[0] = (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return (pos - 1);
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Bad direction: " + direction]);
}
return pos;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
