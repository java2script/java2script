(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JSeparator", null, 'javax.swing.JComponent', 'javax.swing.SwingConstants');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.orientation = 0;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (orientation) {
C$.c$$I$S.apply(this, [orientation, "SeparatorUI"]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$S', function (orientation, sid) {
Clazz.super(C$, this,1);
p$.checkOrientation$I.apply(this, [orientation]);
this.orientation = orientation;
this.setFocusable$Z(false);
this.uiClassID = sid;
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'getOrientation', function () {
return this.orientation;
});

Clazz.newMethod$(C$, 'setOrientation$I', function (orientation) {
if (this.orientation == orientation) {
return;
}var oldValue = this.orientation;
p$.checkOrientation$I.apply(this, [orientation]);
this.orientation = orientation;
this.firePropertyChange$S$I$I("orientation", oldValue, orientation);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'checkOrientation$I', function (orientation) {
switch (orientation) {
case 1:
case 0:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["orientation must be one of: VERTICAL, HORIZONTAL"]);
}
});

Clazz.newMethod$(C$, 'paramString', function () {
var orientationString = (this.orientation == 0 ? "HORIZONTAL" : "VERTICAL");
return C$.superClazz.prototype.paramString.apply(this, []) + ",orientation=" + orientationString ;
});
})();
//Created 2017-10-14 13:31:43
