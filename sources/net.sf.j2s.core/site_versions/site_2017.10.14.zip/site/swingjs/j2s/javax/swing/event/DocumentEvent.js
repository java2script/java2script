(function(){var P$=Clazz.newPackage$("javax.swing.event");
var C$=Clazz.newInterface$(P$, "DocumentEvent", function(){
});

;
(function(){var C$=Clazz.newClass$(P$.DocumentEvent, "EventType", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.INSERT = Clazz.new(C$.c$$S,["INSERT"]);
C$.REMOVE = Clazz.new(C$.c$$S,["REMOVE"]);
C$.CHANGE = Clazz.new(C$.c$$S,["CHANGE"]);
};

C$.INSERT = null;
C$.REMOVE = null;
C$.CHANGE = null;

Clazz.newMethod$(C$, '$init$', function () {
this.typeString = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (s) {
C$.$init$.apply(this);
this.typeString = s;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return this.typeString;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
var C$=Clazz.newInterface$(P$.DocumentEvent, "ElementChange", function(){
});

})();
//Created 2017-10-14 13:31:54
