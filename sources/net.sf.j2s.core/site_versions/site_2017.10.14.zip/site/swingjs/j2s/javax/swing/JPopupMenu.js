(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JPopupMenu", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.MenuElement');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.defaultLWPopupEnabledKey =  new Clazz._O();
C$.popupPostionFixDisabled = false;
};

C$.defaultLWPopupEnabledKey = null;
C$.popupPostionFixDisabled = false;

Clazz.newMethod$(C$, '$init$', function () {
this.invoker = null;
this.popup = null;
this.frame = null;
this.desiredLocationX = 0;
this.desiredLocationY = 0;
this.label = null;
this.$paintBorder = true;
this.margin = null;
this.lightWeightPopup = true;
this.selectionModel = null;
}, 1);

Clazz.newMethod$(C$, 'setDefaultLightWeightPopupEnabled$Z', function (aFlag) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLWPopupEnabledKey, (I$[1] || (I$[1]=Clazz.load('Boolean'))).$valueOf(aFlag));
}, 1);

Clazz.newMethod$(C$, 'getDefaultLightWeightPopupEnabled', function () {
var b = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.defaultLWPopupEnabledKey);
if (b == null ) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLWPopupEnabledKey, Boolean.TRUE);
return true;
}return b.booleanValue();
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$S.apply(this, [null]);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (label) {
Clazz.super(C$, this,1);
this.label = label;
this.lightWeightPopup = C$.getDefaultLightWeightPopupEnabled();
this.setSelectionModel$javax_swing_SingleSelectionModel(Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.DefaultSingleSelectionModel')))));
this.enableEvents$J(16);
this.setOpaque$Z(true);
this.uiClassID = "PopupMenuUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'processFocusEvent$java_awt_event_FocusEvent', function (evt) {
C$.superClazz.prototype.processFocusEvent$java_awt_event_FocusEvent.apply(this, [evt]);
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent', function (evt) {
(I$[3] || (I$[3]=Clazz.load('javax.swing.MenuSelectionManager'))).defaultManager().processKeyEvent$java_awt_event_KeyEvent(evt);
if (evt.isConsumed()) {
return;
}C$.superClazz.prototype.processKeyEvent$java_awt_event_KeyEvent.apply(this, [evt]);
});

Clazz.newMethod$(C$, 'getSelectionModel', function () {
return this.selectionModel;
});

Clazz.newMethod$(C$, 'setSelectionModel$javax_swing_SingleSelectionModel', function (model) {
this.selectionModel = model;
});

Clazz.newMethod$(C$, 'add$javax_swing_JMenuItem', function (menuItem) {
C$.superClazz.prototype.add$java_awt_Component.apply(this, [menuItem]);
return menuItem;
});

Clazz.newMethod$(C$, 'add$S', function (s) {
return this.add$javax_swing_JMenuItem(Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JMenuItem'))).c$$S,[s]));
});

Clazz.newMethod$(C$, 'add$javax_swing_Action', function (a) {
var mi = this.createActionComponent$javax_swing_Action(a);
mi.setAction$javax_swing_Action(a);
this.add$javax_swing_JMenuItem(mi);
return mi;
});

Clazz.newMethod$(C$, 'adjustPopupLocationToFitScreen$I$I', function (xposition, yposition) {
var p = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.Point'))).c$$I$I,[xposition, yposition]);
if (C$.popupPostionFixDisabled == true  || (I$[6] || (I$[6]=Clazz.load('java.awt.GraphicsEnvironment'))).isHeadless() ) return p;
return p;
});

Clazz.newMethod$(C$, 'createActionComponent$javax_swing_Action', function (a) {
var mi = ((
(function(){var C$=Clazz.newClass$(P$, "JPopupMenu$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.JMenuItem'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'createActionPropertyChangeListener$javax_swing_Action', function (a) {
var pcl = this.b$['javax.swing.JPopupMenu'].createActionChangeListener$javax_swing_JMenuItem(this);
if (pcl == null ) {
pcl = C$.superClazz.prototype.createActionPropertyChangeListener$javax_swing_Action.apply(this, [a]);
}return pcl;
});
})()
), Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JMenuItem'))), [this, null],P$.JPopupMenu$1));
mi.setHorizontalTextPosition$I(11);
mi.setVerticalTextPosition$I(0);
return mi;
});

Clazz.newMethod$(C$, 'createActionChangeListener$javax_swing_JMenuItem', function (b) {
return b.createActionPropertyChangeListener0$javax_swing_Action(b.getAction());
});

Clazz.newMethod$(C$, 'remove$I', function (pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}if (pos > this.getComponentCount() - 1) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index greater than the number of items."]);
}C$.superClazz.prototype.remove$I.apply(this, [pos]);
});

Clazz.newMethod$(C$, 'setLightWeightPopupEnabled$Z', function (aFlag) {
this.lightWeightPopup = aFlag;
});

Clazz.newMethod$(C$, 'isLightWeightPopupEnabled', function () {
return this.lightWeightPopup;
});

Clazz.newMethod$(C$, 'getLabel', function () {
return this.label;
});

Clazz.newMethod$(C$, 'setLabel$S', function (label) {
var oldValue = this.label;
this.label = label;
this.firePropertyChange$S$O$O("label", oldValue, label);
this.invalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'addSeparator', function () {
this.add$java_awt_Component(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.JPopupMenu').Separator)))));
});

Clazz.newMethod$(C$, 'insert$javax_swing_Action$I', function (a, index) {
var mi = this.createActionComponent$javax_swing_Action(a);
mi.setAction$javax_swing_Action(a);
this.insert$java_awt_Component$I(mi, index);
});

Clazz.newMethod$(C$, 'insert$java_awt_Component$I', function (component, index) {
if (index < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}var nitems = this.getComponentCount();
var tempItems = Clazz.new((I$[8] || (I$[8]=Clazz.load('java.util.Vector'))));
for (var i = index; i < nitems; i++) {
tempItems.addElement$TE(this.getComponent$I(index));
this.remove$I(index);
}
this.add$java_awt_Component(component);
for (var i = 0; i < tempItems.size(); i++) {
this.add$java_awt_Component(tempItems.elementAt$I(i));
}
});

Clazz.newMethod$(C$, 'addPopupMenuListener$javax_swing_event_PopupMenuListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.PopupMenuListener), l);
});

Clazz.newMethod$(C$, 'removePopupMenuListener$javax_swing_event_PopupMenuListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.PopupMenuListener), l);
});

Clazz.newMethod$(C$, 'getPopupMenuListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.PopupMenuListener));
});

Clazz.newMethod$(C$, 'addMenuKeyListener$javax_swing_event_MenuKeyListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.MenuKeyListener), l);
});

Clazz.newMethod$(C$, 'removeMenuKeyListener$javax_swing_event_MenuKeyListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.MenuKeyListener), l);
});

Clazz.newMethod$(C$, 'getMenuKeyListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.MenuKeyListener));
});

Clazz.newMethod$(C$, 'firePopupMenuWillBecomeVisible', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuWillBecomeVisible$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'firePopupMenuWillBecomeInvisible', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuWillBecomeInvisible$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'firePopupMenuCanceled', function () {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.PopupMenuListener) ) {
if (e == null ) e = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.PopupMenuEvent'))).c$$O,[this]);
(listeners[i + 1]).popupMenuCanceled$javax_swing_event_PopupMenuEvent(e);
}}
});

Clazz.newMethod$(C$, 'alwaysOnTop', function () {
return true;
});

Clazz.newMethod$(C$, 'pack', function () {
if (this.popup != null ) {
var pref = this.getPreferredSize();
if (pref == null  || pref.width != this.getWidth()  || pref.height != this.getHeight() ) {
this.popup = p$.getPopup.apply(this, []);
} else {
this.validate();
}}});

Clazz.newMethod$(C$, 'setVisible$Z', function (b) {
if (b == this.isVisible() ) return;
this.getUI().setVisible$Z(true);
{
}});

Clazz.newMethod$(C$, 'getPopup', function () {
var oldPopup = this.popup;
if (oldPopup != null ) {
oldPopup.hide();
}var popupFactory = (I$[10] || (I$[10]=Clazz.load('javax.swing.PopupFactory'))).getSharedInstance();
if (this.isLightWeightPopupEnabled()) {
popupFactory.setPopupType$I(0);
} else {
popupFactory.setPopupType$I(1);
}var p = this.adjustPopupLocationToFitScreen$I$I(this.desiredLocationX, this.desiredLocationY);
this.desiredLocationX = p.x;
this.desiredLocationY = p.y;
var newPopup = (this.getUI()).getPopup$javax_swing_JPopupMenu$I$I(this, this.desiredLocationX, this.desiredLocationY);
popupFactory.setPopupType$I(0);
newPopup.show();
return newPopup;
});

Clazz.newMethod$(C$, 'isVisible', function () {
if (this.popup != null ) return true;
 else return false;
});

Clazz.newMethod$(C$, 'setLocation$I$I', function (x, y) {
var oldX = this.desiredLocationX;
var oldY = this.desiredLocationY;
this.desiredLocationX = x;
this.desiredLocationY = y;
if (this.popup != null  && (x != oldX || y != oldY ) ) {
this.popup = p$.getPopup.apply(this, []);
}});

Clazz.newMethod$(C$, 'isPopupMenu', function () {
return ((this.invoker != null ) && !(Clazz.instanceOf(this.invoker, "javax.swing.JMenu")) );
});

Clazz.newMethod$(C$, 'getInvoker', function () {
return this.invoker;
});

Clazz.newMethod$(C$, 'setInvoker$java_awt_Component', function (invoker) {
var oldInvoker = this.invoker;
this.invoker = invoker;
if ((oldInvoker !== this.invoker ) && (this.ui != null ) ) {
this.ui.uninstallUI$java_awt_Component(this);
this.ui.installUI$java_awt_Component(this);
}this.invalidate();
});

Clazz.newMethod$(C$, 'show$java_awt_Component$I$I', function (invoker, x, y) {
this.setInvoker$java_awt_Component(invoker);
var invokerOrigin;
if (invoker != null ) {
invokerOrigin = invoker.getLocationOnScreen();
var lx;
var ly;
lx = (invokerOrigin.x) + (x);
ly = (invokerOrigin.y) + (y);
if (lx > 2147483647) lx = 2147483647;
if (lx < -2147483648) lx = -2147483648;
if (ly > 2147483647) ly = 2147483647;
if (ly < -2147483648) ly = -2147483648;
this.setLocation$I$I(($i$[0] = lx, $i$[0]), ($i$[0] = ly, $i$[0]));
} else {
this.setLocation$I$I(x, y);
}this.setVisible$Z(true);
});

Clazz.newMethod$(C$, 'getRootPopupMenu', function () {
var mp = this;
while ((mp != null ) && (mp.isPopupMenu() != true ) && (mp.getInvoker() != null ) && (mp.getInvoker().getParent() != null ) && (Clazz.instanceOf(mp.getInvoker().getParent(), "javax.swing.JPopupMenu"))  ){
mp = mp.getInvoker().getParent();
}
return mp;
});

Clazz.newMethod$(C$, 'getComponentAtIndex$I', function (i) {
return this.getComponent$I(i);
});

Clazz.newMethod$(C$, 'getComponentIndex$java_awt_Component', function (c) {
var ncomponents = this.getComponentCount();
var component = this.getComponents();
for (var i = 0; i < ncomponents; i++) {
var comp = component[i];
if (comp === c ) return i;
}
return -1;
});

Clazz.newMethod$(C$, 'setPopupSize$java_awt_Dimension', function (d) {
var oldSize = this.getPreferredSize();
this.setPreferredSize$java_awt_Dimension(d);
if (this.popup != null ) {
var newSize = this.getPreferredSize();
if (!oldSize.equals$O(newSize)) {
this.popup = p$.getPopup.apply(this, []);
}}});

Clazz.newMethod$(C$, 'setPopupSize$I$I', function (width, height) {
this.setPopupSize$java_awt_Dimension(Clazz.new((I$[11] || (I$[11]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, height]));
});

Clazz.newMethod$(C$, 'setSelected$java_awt_Component', function (sel) {
var model = this.getSelectionModel();
var index = this.getComponentIndex$java_awt_Component(sel);
model.setSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'isBorderPainted', function () {
return this.$paintBorder;
});

Clazz.newMethod$(C$, 'setBorderPainted$Z', function (b) {
this.$paintBorder = b;
this.repaint();
});

Clazz.newMethod$(C$, 'paintBorder$java_awt_Graphics', function (g) {
if (this.isBorderPainted()) {
C$.superClazz.prototype.paintBorder$java_awt_Graphics.apply(this, [g]);
}});

Clazz.newMethod$(C$, 'getMargin', function () {
if (this.margin == null ) {
return Clazz.new((I$[12] || (I$[12]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
} else {
return this.margin;
}});

Clazz.newMethod$(C$, 'isSubPopupMenu$javax_swing_JPopupMenu', function (popup) {
var ncomponents = this.getComponentCount();
var component = this.getComponents();
for (var i = 0; i < ncomponents; i++) {
var comp = component[i];
if (Clazz.instanceOf(comp, "javax.swing.JMenu")) {
var menu = comp;
var subPopup = menu.getPopupMenu();
if (subPopup === popup ) return true;
if (subPopup.isSubPopupMenu$javax_swing_JPopupMenu(popup)) return true;
}}
return false;
});

Clazz.newMethod$(C$, 'paramString', function () {
var labelString = (this.label != null  ? this.label : "");
var paintBorderString = (this.$paintBorder ? "true" : "false");
var marginString = (this.margin != null  ? this.margin.toString() : "");
var lightWeightPopupEnabledString = (this.isLightWeightPopupEnabled() ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",desiredLocationX=" + this.desiredLocationX + ",desiredLocationY=" + this.desiredLocationY + ",label=" + labelString + ",lightWeightPopupEnabled=" + lightWeightPopupEnabledString + ",margin=" + marginString + ",paintBorder=" + paintBorderString ;
});

Clazz.newMethod$(C$, 'processMouseEvent$java_awt_event_MouseEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (event, path, manager) {
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (e, path, manager) {
var mke = Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.event.MenuKeyEvent'))).c$$java_awt_Component$I$J$I$I$C$javax_swing_MenuElementA$javax_swing_MenuSelectionManager,[e.getComponent(), e.getID(), e.getWhen(), e.getModifiers(), e.getKeyCode(), e.getKeyChar(), path, manager]);
p$.processMenuKeyEvent$javax_swing_event_MenuKeyEvent.apply(this, [mke]);
if (mke.isConsumed()) {
e.consume();
}});

Clazz.newMethod$(C$, 'processMenuKeyEvent$javax_swing_event_MenuKeyEvent', function (e) {
switch (e.getID()) {
case 401:
p$.fireMenuKeyPressed$javax_swing_event_MenuKeyEvent.apply(this, [e]);
break;
case 402:
p$.fireMenuKeyReleased$javax_swing_event_MenuKeyEvent.apply(this, [e]);
break;
case 400:
p$.fireMenuKeyTyped$javax_swing_event_MenuKeyEvent.apply(this, [e]);
break;
default:
break;
}
});

Clazz.newMethod$(C$, 'fireMenuKeyPressed$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyPressed$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuKeyReleased$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyReleased$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'fireMenuKeyTyped$javax_swing_event_MenuKeyEvent', function (event) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuKeyListener) ) {
(listeners[i + 1]).menuKeyTyped$javax_swing_event_MenuKeyEvent(event);
}}
});

Clazz.newMethod$(C$, 'menuSelectionChanged$Z', function (isIncluded) {
});

Clazz.newMethod$(C$, 'getSubElements', function () {
var result;
var tmp = Clazz.new((I$[8] || (I$[8]=Clazz.load('java.util.Vector'))));
var c = this.getComponentCount();
var i;
var m;
for (i = 0; i < c; i++) {
m = this.getComponent$I(i);
if (Clazz.instanceOf(m, "javax.swing.MenuElement")) tmp.addElement$TE(m);
}
result =  Clazz.newArray$(javax.swing.MenuElement, [tmp.size()]);
for (i = 0, c = tmp.size(); i < c; i++) result[i] = tmp.elementAt$I(i);

return result;
});

Clazz.newMethod$(C$, 'getComponent', function () {
return this;
});

Clazz.newMethod$(C$, 'isPopupTrigger$java_awt_event_MouseEvent', function (e) {
return (this.getUI()).isPopupTrigger$java_awt_event_MouseEvent(e);
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.JPopupMenu, "Separator", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JSeparator');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$I$S.apply(this, [0, "PopupMenuSeparatorUI"]);
C$.$init$.apply(this);
}, 1);
})()
})();
//Created 2017-10-14 13:31:41
