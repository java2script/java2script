(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SwingUtilities", function(){
Clazz.newInstance$(this, arguments);
}, null, 'javax.swing.SwingConstants');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'installSwingDropTargetAsNecessary$java_awt_Component$javax_swing_TransferHandler', function (c, t) {
}, 1);

Clazz.newMethod$(C$, 'isRectangleContainingRectangle$java_awt_Rectangle$java_awt_Rectangle', function (a, b) {
if (b.x >= a.x && (b.x + b.width) <= (a.x + a.width)  && b.y >= a.y  && (b.y + b.height) <= (a.y + a.height) ) {
return true;
}return false;
}, 1);

Clazz.newMethod$(C$, 'getLocalBounds$java_awt_Component', function (aComponent) {
var b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[aComponent.getBounds()]);
b.x = b.y = 0;
return b;
}, 1);

Clazz.newMethod$(C$, 'getWindowAncestor$java_awt_Component', function (c) {
for (var p = c.getParent(); p != null ; p = p.getParent()) {
if (Clazz.instanceOf(p, "java.awt.Window")) {
return p;
}}
return null;
}, 1);

Clazz.newMethod$(C$, 'convertScreenLocationToParent$java_awt_Container$I$I', function (parent, x, y) {
for (var p = parent; p != null ; p = p.getParent()) {
if (Clazz.instanceOf(p, "java.awt.Window")) {
var point = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[x, y]);
C$.convertPointFromScreen$java_awt_Point$java_awt_Component(point, parent);
return point;
}}
throw Clazz.new((I$[2] || (I$[2]=Clazz.load('java.lang.Error'))).c$$S,["convertScreenLocationToParent: no window ancestor"]);
}, 1);

Clazz.newMethod$(C$, 'convertPoint$java_awt_Component$java_awt_Point$java_awt_Component', function (source, aPoint, destination) {
var p;
if (source == null  && destination == null  ) return aPoint;
if (source == null ) {
source = C$.getWindowAncestor$java_awt_Component(destination);
if (source == null ) throw Clazz.new((I$[2] || (I$[2]=Clazz.load('java.lang.Error'))).c$$S,["Source component not connected to component tree hierarchy"]);
}p = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$java_awt_Point,[aPoint]);
C$.convertPointToScreen$java_awt_Point$java_awt_Component(p, source);
if (destination == null ) {
destination = C$.getWindowAncestor$java_awt_Component(source);
if (destination == null ) throw Clazz.new((I$[2] || (I$[2]=Clazz.load('java.lang.Error'))).c$$S,["Destination component not connected to component tree hierarchy"]);
}C$.convertPointFromScreen$java_awt_Point$java_awt_Component(p, destination);
return p;
}, 1);

Clazz.newMethod$(C$, 'convertPoint$java_awt_Component$I$I$java_awt_Component', function (source, x, y, destination) {
var point = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[x, y]);
return C$.convertPoint$java_awt_Component$java_awt_Point$java_awt_Component(source, point, destination);
}, 1);

Clazz.newMethod$(C$, 'convertRectangle$java_awt_Component$java_awt_Rectangle$java_awt_Component', function (source, aRectangle, destination) {
var point = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[aRectangle.x, aRectangle.y]);
point = C$.convertPoint$java_awt_Component$java_awt_Point$java_awt_Component(source, point, destination);
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[point.x, point.y, aRectangle.width, aRectangle.height]);
}, 1);

Clazz.newMethod$(C$, 'getAncestorOfClass$Class$java_awt_Component', function (c, comp) {
if (comp == null  || c == null  ) return null;
var parent = comp.getParent();
while (parent != null  && !(c.isInstance$O(parent)) )parent = parent.getParent();

return parent;
}, 1);

Clazz.newMethod$(C$, 'getAncestorNamed$S$java_awt_Component', function (name, comp) {
if (comp == null  || name == null  ) return null;
var parent = comp.getParent();
while (parent != null  && !(name.equals$O(parent.getName())) )parent = parent.getParent();

return parent;
}, 1);

Clazz.newMethod$(C$, 'getDeepestComponentAt$java_awt_Component$I$I', function (parent, x, y) {
if (!parent.contains$I$I(x, y)) {
return null;
}if (Clazz.instanceOf(parent, "java.awt.Container")) {
var components = (parent).getComponents();
for (var i = 0; i < components.length; i++) {
var comp = components[i];
if (comp != null  && comp.isVisible() ) {
var loc = comp.getLocation();
if (Clazz.instanceOf(comp, "java.awt.Container")) {
comp = C$.getDeepestComponentAt$java_awt_Component$I$I(comp, x - loc.x, y - loc.y);
} else {
comp = comp.getComponentAt$I$I(x - loc.x, y - loc.y);
}if (comp != null  && comp.isVisible() ) {
return comp;
}}}
}return parent;
}, 1);

Clazz.newMethod$(C$, 'convertMouseEvent$java_awt_Component$java_awt_event_MouseEvent$java_awt_Component', function (source, sourceEvent, destination) {
var p = C$.convertPoint$java_awt_Component$java_awt_Point$java_awt_Component(source, Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[sourceEvent.getX(), sourceEvent.getY()]), destination);
var newSource;
if (destination != null ) newSource = destination;
 else newSource = source;
var newEvent;
if (Clazz.instanceOf(sourceEvent, "java.awt.event.MouseWheelEvent")) {
var sourceWheelEvent = sourceEvent;
newEvent = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.event.MouseWheelEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$I$I$I,[newSource, sourceWheelEvent.getID(), sourceWheelEvent.getWhen(), sourceWheelEvent.getModifiers(), p.x, p.y, sourceWheelEvent.getXOnScreen(), sourceWheelEvent.getYOnScreen(), sourceWheelEvent.getClickCount(), sourceWheelEvent.isPopupTrigger(), sourceWheelEvent.getScrollType(), sourceWheelEvent.getScrollAmount(), sourceWheelEvent.getWheelRotation()]);
} else if (Clazz.instanceOf(sourceEvent, "javax.swing.event.MenuDragMouseEvent")) {
var sourceMenuDragEvent = sourceEvent;
newEvent = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.event.MenuDragMouseEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$javax_swing_MenuElementA$javax_swing_MenuSelectionManager,[newSource, sourceMenuDragEvent.getID(), sourceMenuDragEvent.getWhen(), sourceMenuDragEvent.getModifiers(), p.x, p.y, sourceMenuDragEvent.getXOnScreen(), sourceMenuDragEvent.getYOnScreen(), sourceMenuDragEvent.getClickCount(), sourceMenuDragEvent.isPopupTrigger(), sourceMenuDragEvent.getPath(), sourceMenuDragEvent.getMenuSelectionManager()]);
} else {
newEvent = Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.event.MouseEvent'))).c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$I,[newSource, sourceEvent.getID(), sourceEvent.getWhen(), sourceEvent.getModifiers(), p.x, p.y, sourceEvent.getXOnScreen(), sourceEvent.getYOnScreen(), sourceEvent.getClickCount(), sourceEvent.isPopupTrigger(), 0]);
}return newEvent;
}, 1);

Clazz.newMethod$(C$, 'convertPointToScreen$java_awt_Point$java_awt_Component', function (p, c) {
var x;
var y;
do {
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
x = (c).getX();
y = (c).getY();
} else if (Clazz.instanceOf(c, "java.applet.Applet") || Clazz.instanceOf(c, "java.awt.Window") ) {
try {
var pp = c.getLocationOnScreen();
x = pp.x;
y = pp.y;
} catch (icse) {
if (Clazz.exceptionOf(icse, java.awt.IllegalComponentStateException)){
x = c.getX();
y = c.getY();
} else {
throw icse;
}
}
} else {
x = c.getX();
y = c.getY();
}p.x = p.x+(x);
p.y = p.y+(y);
if (Clazz.instanceOf(c, "java.awt.Window") || Clazz.instanceOf(c, "java.applet.Applet") ) break;
c = c.getParent();
} while (c != null );
}, 1);

Clazz.newMethod$(C$, 'convertPointFromScreen$java_awt_Point$java_awt_Component', function (p, c) {
var x;
var y;
do {
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
x = (c).getX();
y = (c).getY();
} else if (Clazz.instanceOf(c, "java.applet.Applet") || Clazz.instanceOf(c, "java.awt.Window") ) {
try {
var pp = c.getLocationOnScreen();
x = pp.x;
y = pp.y;
} catch (icse) {
if (Clazz.exceptionOf(icse, java.awt.IllegalComponentStateException)){
x = c.getX();
y = c.getY();
} else {
throw icse;
}
}
} else {
x = c.getX();
y = c.getY();
}p.x = p.x-(x);
p.y = p.y-(y);
if (Clazz.instanceOf(c, "java.awt.Window") || Clazz.instanceOf(c, "java.applet.Applet") ) break;
c = c.getParent();
} while (c != null );
}, 1);

Clazz.newMethod$(C$, 'windowForComponent$java_awt_Component', function (c) {
return C$.getWindowAncestor$java_awt_Component(c);
}, 1);

Clazz.newMethod$(C$, 'isDescendingFrom$java_awt_Component$java_awt_Component', function (a, b) {
if (a === b ) return true;
for (var p = a.getParent(); p != null ; p = p.getParent()) if (p === b ) return true;

return false;
}, 1);

Clazz.newMethod$(C$, 'computeIntersection$I$I$I$I$java_awt_Rectangle', function (x, y, width, height, dest) {
var x1 = (x > dest.x) ? x : dest.x;
var x2 = ((x + width) < (dest.x + dest.width)) ? (x + width) : (dest.x + dest.width);
var y1 = (y > dest.y) ? y : dest.y;
var y2 = ((y + height) < (dest.y + dest.height) ? (y + height) : (dest.y + dest.height));
dest.x = x1;
dest.y = y1;
dest.width = x2 - x1;
dest.height = y2 - y1;
if (dest.width < 0 || dest.height < 0 ) {
dest.x = dest.y = dest.width = dest.height = 0;
}return dest;
}, 1);

Clazz.newMethod$(C$, 'computeUnion$I$I$I$I$java_awt_Rectangle', function (x, y, width, height, dest) {
var x1 = (x < dest.x) ? x : dest.x;
var x2 = ((x + width) > (dest.x + dest.width)) ? (x + width) : (dest.x + dest.width);
var y1 = (y < dest.y) ? y : dest.y;
var y2 = ((y + height) > (dest.y + dest.height)) ? (y + height) : (dest.y + dest.height);
dest.x = x1;
dest.y = y1;
dest.width = (x2 - x1);
dest.height = (y2 - y1);
return dest;
}, 1);

Clazz.newMethod$(C$, 'computeDifference$java_awt_Rectangle$java_awt_Rectangle', function (rectA, rectB) {
if (rectB == null  || !rectA.intersects$java_awt_Rectangle(rectB)  || C$.isRectangleContainingRectangle$java_awt_Rectangle$java_awt_Rectangle(rectB, rectA) ) {
return  Clazz.newArray$(java.awt.Rectangle, [0]);
}var t = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))));
var a = null;
var b = null;
var c = null;
var d = null;
var result;
var rectCount = 0;
if (C$.isRectangleContainingRectangle$java_awt_Rectangle$java_awt_Rectangle(rectA, rectB)) {
t.x = rectA.x;
t.y = rectA.y;
t.width = rectB.x - rectA.x;
t.height = rectA.height;
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.x = rectB.x;
t.y = rectA.y;
t.width = rectB.width;
t.height = rectB.y - rectA.y;
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.x = rectB.x;
t.y = rectB.y + rectB.height;
t.width = rectB.width;
t.height = rectA.y + rectA.height - (rectB.y + rectB.height);
if (t.width > 0 && t.height > 0 ) {
c = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.x = rectB.x + rectB.width;
t.y = rectA.y;
t.width = rectA.x + rectA.width - (rectB.x + rectB.width);
t.height = rectA.height;
if (t.width > 0 && t.height > 0 ) {
d = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else {
if (rectB.x <= rectA.x && rectB.y <= rectA.y ) {
if ((rectB.x + rectB.width) > (rectA.x + rectA.width)) {
t.x = rectA.x;
t.y = rectB.y + rectB.height;
t.width = rectA.width;
t.height = rectA.y + rectA.height - (rectB.y + rectB.height);
if (t.width > 0 && t.height > 0 ) {
a = t;
rectCount++;
}} else if ((rectB.y + rectB.height) > (rectA.y + rectA.height)) {
t.setBounds$I$I$I$I((rectB.x + rectB.width), rectA.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), rectA.height);
if (t.width > 0 && t.height > 0 ) {
a = t;
rectCount++;
}} else {
t.setBounds$I$I$I$I((rectB.x + rectB.width), rectA.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), (rectB.y + rectB.height) - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.setBounds$I$I$I$I(rectA.x, (rectB.y + rectB.height), rectA.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}}} else if (rectB.x <= rectA.x && (rectB.y + rectB.height) >= (rectA.y + rectA.height) ) {
if ((rectB.x + rectB.width) > (rectA.x + rectA.width)) {
t.setBounds$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = t;
rectCount++;
}} else {
t.setBounds$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I((rectB.x + rectB.width), rectB.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), (rectA.y + rectA.height) - rectB.y);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}}} else if (rectB.x <= rectA.x) {
if ((rectB.x + rectB.width) >= (rectA.x + rectA.width)) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, (rectB.y + rectB.height), rectA.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I((rectB.x + rectB.width), rectB.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), rectB.height);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, (rectB.y + rectB.height), rectA.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
c = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}}} else if (rectB.x <= (rectA.x + rectA.width) && (rectB.x + rectB.width) > (rectA.x + rectA.width) ) {
if (rectB.y <= rectA.y && (rectB.y + rectB.height) > (rectA.y + rectA.height) ) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectB.x - rectA.x, rectA.height);
if (t.width > 0 && t.height > 0 ) {
a = t;
rectCount++;
}} else if (rectB.y <= rectA.y) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectB.x - rectA.x, (rectB.y + rectB.height) - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, (rectB.y + rectB.height), rectA.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else if ((rectB.y + rectB.height) > (rectA.y + rectA.height)) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, rectB.y, rectB.x - rectA.x, (rectA.y + rectA.height) - rectB.y);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectA.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, rectB.y, rectB.x - rectA.x, rectB.height);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectA.x, (rectB.y + rectB.height), rectA.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
c = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}}} else if (rectB.x >= rectA.x && (rectB.x + rectB.width) <= (rectA.x + rectA.width) ) {
if (rectB.y <= rectA.y && (rectB.y + rectB.height) > (rectA.y + rectA.height) ) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectB.x - rectA.x, rectA.height);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I((rectB.x + rectB.width), rectA.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), rectA.height);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else if (rectB.y <= rectA.y) {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectB.x - rectA.x, rectA.height);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectB.x, (rectB.y + rectB.height), rectB.width, (rectA.y + rectA.height) - (rectB.y + rectB.height));
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I((rectB.x + rectB.width), rectA.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), rectA.height);
if (t.width > 0 && t.height > 0 ) {
c = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}} else {
t.reshape$I$I$I$I(rectA.x, rectA.y, rectB.x - rectA.x, rectA.height);
if (t.width > 0 && t.height > 0 ) {
a = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I(rectB.x, rectA.y, rectB.width, rectB.y - rectA.y);
if (t.width > 0 && t.height > 0 ) {
b = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}t.reshape$I$I$I$I((rectB.x + rectB.width), rectA.y, (rectA.x + rectA.width) - (rectB.x + rectB.width), rectA.height);
if (t.width > 0 && t.height > 0 ) {
c = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Rectangle,[t]);
rectCount++;
}}}}result =  Clazz.newArray$(java.awt.Rectangle, [rectCount]);
rectCount = 0;
if (a != null ) result[rectCount++] = a;
if (b != null ) result[rectCount++] = b;
if (c != null ) result[rectCount++] = c;
if (d != null ) result[rectCount++] = d;
return result;
}, 1);

Clazz.newMethod$(C$, 'isLeftMouseButton$java_awt_event_MouseEvent', function (anEvent) {
return ((anEvent.getModifiers() & 16) != 0);
}, 1);

Clazz.newMethod$(C$, 'isMiddleMouseButton$java_awt_event_MouseEvent', function (anEvent) {
return ((anEvent.getModifiers() & 8) == 8);
}, 1);

Clazz.newMethod$(C$, 'isRightMouseButton$java_awt_event_MouseEvent', function (anEvent) {
return ((anEvent.getModifiers() & 4) == 4);
}, 1);

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics$java_awt_Component$java_awt_Container$I$I$I$I', function (g, c, p, x, y, w, h) {
C$.getCellRendererPane$java_awt_Component$java_awt_Container(c, p).paintComponent$java_awt_Graphics$java_awt_Component$java_awt_Container$I$I$I$I$Z(g, c, p, x, y, w, h, false);
}, 1);

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics$java_awt_Component$java_awt_Container$java_awt_Rectangle', function (g, c, p, r) {
C$.paintComponent$java_awt_Graphics$java_awt_Component$java_awt_Container$I$I$I$I(g, c, p, r.x, r.y, r.width, r.height);
}, 1);

Clazz.newMethod$(C$, 'getCellRendererPane$java_awt_Component$java_awt_Container', function (c, p) {
var shell = c.getParent();
if (Clazz.instanceOf(shell, "javax.swing.CellRendererPane")) {
if (shell.getParent() !== p ) {
p.add$java_awt_Component(shell);
}} else {
shell = (I$[6] || (I$[6]=Clazz.load('swingjs.api.Interface'))).getInstance$S$Z("javax.swing.CellRendererPane", false);
shell.add$java_awt_Component(c);
p.add$java_awt_Component(shell);
}return shell;
}, 1);

Clazz.newMethod$(C$, 'updateComponentTreeUI$java_awt_Component', function (c) {
C$.updateComponentTreeUI0$java_awt_Component(c);
c.invalidate();
c.validate();
c.repaint();
}, 1);

Clazz.newMethod$(C$, 'updateComponentTreeUI0$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
var jc = c;
jc.updateUI();
var jpm = jc.getComponentPopupMenu();
if (jpm != null ) {
C$.updateComponentTreeUI$java_awt_Component(jpm);
}}var children = null;
if (Clazz.instanceOf(c, "javax.swing.JMenu")) {
children = (c).getMenuComponents();
} else if (Clazz.instanceOf(c, "java.awt.Container")) {
children = (c).getComponents();
}if (children != null ) {
for (var i = 0; i < children.length; i++) {
C$.updateComponentTreeUI0$java_awt_Component(children[i]);
}
}}, 1);

Clazz.newMethod$(C$, 'invokeLater$Runnable', function (doRun) {
(I$[7] || (I$[7]=Clazz.load('java.awt.EventQueue'))).invokeLater$Runnable(doRun);
}, 1);

Clazz.newMethod$(C$, 'invokeAndWait$Runnable', function (doRun) {
(I$[7] || (I$[7]=Clazz.load('java.awt.EventQueue'))).invokeAndWait$Runnable(doRun);
}, 1);

Clazz.newMethod$(C$, 'isEventDispatchThread', function () {
return (I$[7] || (I$[7]=Clazz.load('java.awt.EventQueue'))).isDispatchThread();
}, 1);

Clazz.newMethod$(C$, 'getRootPane$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "javax.swing.RootPaneContainer")) {
return (c).getRootPane();
}for (; c != null ; c = c.getParent()) {
if (Clazz.instanceOf(c, "javax.swing.JRootPane")) {
return c;
}}
return null;
}, 1);

Clazz.newMethod$(C$, 'getRoot$java_awt_Component', function (c) {
var applet = null;
for (var p = c; p != null ; p = p.getParent()) {
if (Clazz.instanceOf(p, "java.awt.Window")) {
return p;
}if (Clazz.instanceOf(p, "java.applet.Applet")) {
applet = p;
}}
return applet;
}, 1);

Clazz.newMethod$(C$, 'processKeyBindings$java_awt_event_KeyEvent', function (event) {
if (event != null ) {
if (event.isConsumed()) {
return false;
}var component = event.getComponent();
var pressed = (event.getID() == 401);
if (!C$.isValidKeyEventForKeyBindings$java_awt_event_KeyEvent(event)) {
return false;
}while (component != null ){
if (Clazz.instanceOf(component, "javax.swing.JComponent")) {
return (component).processKeyBindings$java_awt_event_KeyEvent$Z(event, pressed);
}if ((Clazz.instanceOf(component, "java.applet.Applet")) || (Clazz.instanceOf(component, "java.awt.Window")) ) {
return (I$[8] || (I$[8]=Clazz.load('javax.swing.JComponent'))).processKeyBindingsForAllComponents$java_awt_event_KeyEvent$java_awt_Container$Z(event, component, pressed);
}component = component.getParent();
}
}return false;
}, 1);

Clazz.newMethod$(C$, 'isValidKeyEventForKeyBindings$java_awt_event_KeyEvent', function (e) {
if (e.getID() == 400) {
var mod = e.getModifiers();
if (((mod & 8) != 0) && ((mod & 2) == 0) ) {
return false;
}}return true;
}, 1);

Clazz.newMethod$(C$, 'notifyAction$javax_swing_Action$javax_swing_KeyStroke$java_awt_event_KeyEvent$O$I', function (action, ks, event, sender, modifiers) {
if (action == null ) {
return false;
}if (Clazz.instanceOf(action, "sun.swing.UIAction")) {
if (!(action).isEnabled$O(sender)) {
return false;
}} else if (!action.isEnabled()) {
return false;
}var commandO;
var stayNull;
commandO = action.getValue$S("ActionCommandKey");
if (commandO == null  && (I$[8] || (I$[8]=Clazz.load('javax.swing.JComponent'))).isActionStandin$javax_swing_Action(action) ) {
stayNull = true;
} else {
stayNull = false;
}var command;
if (commandO != null ) {
command = commandO.toString();
} else if (!stayNull && event.getKeyChar() != '\uffff' ) {
command = String.valueOf(event.getKeyChar());
} else {
command = null;
}action.actionPerformed$java_awt_event_ActionEvent(Clazz.new((I$[9] || (I$[9]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S$J$I,[sender, 1001, command, event.getWhen(), modifiers]));
return true;
}, 1);

Clazz.newMethod$(C$, 'replaceUIInputMap$javax_swing_JComponent$I$javax_swing_InputMap', function (component, type, uiInputMap) {
var map = component.getInputMap$I$Z(type, (uiInputMap != null ));
while (map != null ){
var parent = map.getParent();
if (parent == null  || (Clazz.instanceOf(parent, "javax.swing.plaf.UIResource")) ) {
map.setParent$javax_swing_InputMap(uiInputMap);
return;
}map = parent;
}
}, 1);

Clazz.newMethod$(C$, 'replaceUIActionMap$javax_swing_JComponent$javax_swing_ActionMap', function (component, uiActionMap) {
var map = component.getActionMap$Z((uiActionMap != null ));
while (map != null ){
var parent = map.getParent();
if (parent == null  || (Clazz.instanceOf(parent, "javax.swing.plaf.UIResource")) ) {
map.setParent$javax_swing_ActionMap(uiActionMap);
return;
}map = parent;
}
}, 1);

Clazz.newMethod$(C$, 'getUIInputMap$javax_swing_JComponent$I', function (component, condition) {
var map = component.getInputMap$I$Z(condition, false);
while (map != null ){
var parent = map.getParent();
if (Clazz.instanceOf(parent, "javax.swing.plaf.UIResource")) {
return parent;
}map = parent;
}
return null;
}, 1);

Clazz.newMethod$(C$, 'getUIActionMap$javax_swing_JComponent', function (component) {
var map = component.getActionMap$Z(false);
while (map != null ){
var parent = map.getParent();
if (Clazz.instanceOf(parent, "javax.swing.plaf.UIResource")) {
return parent;
}map = parent;
}
return null;
}, 1);

Clazz.newMethod$(C$, 'getSharedOwnerFrame', function () {
var p = (I$[10] || (I$[10]=Clazz.load('swingjs.JSUtil'))).getAppletViewer();
var f = p.sharedOwnerFrame;
return (f == null  ? (p.sharedOwnerFrame = Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.SwingUtilities').SharedOwnerFrame))))) : f);
}, 1);

Clazz.newMethod$(C$, 'getSharedOwnerFrameShutdownListener', function () {
var sharedOwnerFrame = C$.getSharedOwnerFrame();
return sharedOwnerFrame;
}, 1);

Clazz.newMethod$(C$, 'appContextGet$O', function (key) {
return (I$[12] || (I$[12]=Clazz.load('sun.awt.AppContext'))).getAppContext().get$O(key);
}, 1);

Clazz.newMethod$(C$, 'appContextPut$O$O', function (key, value) {
(I$[12] || (I$[12]=Clazz.load('sun.awt.AppContext'))).getAppContext().put$O$O(key, value);
}, 1);

Clazz.newMethod$(C$, 'appContextRemove$O', function (key) {
(I$[12] || (I$[12]=Clazz.load('sun.awt.AppContext'))).getAppContext().remove$O(key);
}, 1);

Clazz.newMethod$(C$, 'loadSystemClass$S', function (className) {
return Clazz._4Name(className, true, (I$[13] || (I$[13]=Clazz.load('Thread'))).currentThread().getContextClassLoader());
}, 1);

Clazz.newMethod$(C$, 'isLeftToRight$java_awt_Component', function (c) {
return c.getComponentOrientation().isLeftToRight();
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
throw Clazz.new((I$[2] || (I$[2]=Clazz.load('java.lang.Error'))).c$$S,["SwingUtilities is just a container for static methods"]);
}, 1);

Clazz.newMethod$(C$, 'doesIconReferenceImage$javax_swing_Icon$java_awt_Image', function (icon, image) {
var iconImage = (icon != null  && (Clazz.instanceOf(icon, "javax.swing.ImageIcon")) ) ? (icon).getImage() : null;
return (iconImage === image );
}, 1);

Clazz.newMethod$(C$, 'findDisplayedMnemonicIndex$S$I', function (text, mnemonic) {
if (text == null  || mnemonic == 0  ) {
return -1;
}var uc = Character.toUpperCase(String.fromCharCode(mnemonic));
var lc = Character.toLowerCase(String.fromCharCode(mnemonic));
var uci = text.indexOf(uc.$c());
var lci = text.indexOf(lc.$c());
if (uci == -1) {
return lci;
} else if (lci == -1) {
return uci;
} else {
return (lci < uci) ? lci : uci;
}}, 1);

Clazz.newMethod$(C$, 'calculateInnerArea$javax_swing_JComponent$java_awt_Rectangle', function (c, r) {
if (c == null ) {
return null;
}var rect = r;
var insets = c.getInsets();
if (rect == null ) {
rect = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Rectangle'))));
}rect.x = insets.left;
rect.y = insets.top;
rect.width = c.getWidth() - insets.left - insets.right ;
rect.height = c.getHeight() - insets.top - insets.bottom ;
return rect;
}, 1);

Clazz.newMethod$(C$, 'updateRendererOrEditorUI$O', function (rendererOrEditor) {
if (rendererOrEditor == null ) {
return;
}var component = null;
if (Clazz.instanceOf(rendererOrEditor, "java.awt.Component")) {
component = rendererOrEditor;
}if (Clazz.instanceOf(rendererOrEditor, "javax.swing.DefaultCellEditor")) {
component = (rendererOrEditor).getComponent();
}if (component != null ) {
C$.updateComponentTreeUI$java_awt_Component(component);
}}, 1);
;
(function(){var C$=Clazz.newClass$(P$.SwingUtilities, "SharedOwnerFrame", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JFrame', 'java.awt.event.WindowListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'addNotify', function () {
this.updateUI();
this.getOrCreatePeer();
C$.superClazz.prototype.addNotify.apply(this, []);
this.installListeners();
});

Clazz.newMethod$(C$, 'installListeners', function () {
var windows = this.getOwnedWindows();
for (var ind = 0; ind < windows.length; ind++) {
var window = windows[ind];
if (window != null ) {
window.removeWindowListener$java_awt_event_WindowListener(this);
window.addWindowListener$java_awt_event_WindowListener(this);
}}
});

Clazz.newMethod$(C$, 'windowClosed$java_awt_event_WindowEvent', function (e) {
var windows = this.getOwnedWindows();
for (var ind = 0; ind < windows.length; ind++) {
var window = windows[ind];
if (window != null ) {
if (window.isDisplayable()) {
return;
}window.removeWindowListener$java_awt_event_WindowListener(this);
}this.dispose();
}
});

Clazz.newMethod$(C$, 'windowOpened$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'windowIconified$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'windowDeiconified$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'windowActivated$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'windowDeactivated$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMethod$(C$, 'show', function () {
});

Clazz.newMethod$(C$, 'dispose', function () {
});
})()
})();
//Created 2017-10-14 13:31:51
