(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultHighlighter", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.LayeredHighlighter');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.noHighlights =  Clazz.newArray$(javax.swing.text.Highlighter.Highlight, [0]);
C$.DefaultPainter = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.DefaultHighlighter').DefaultHighlightPainter))).c$$java_awt_Color,[null]);
};

C$.noHighlights = null;
C$.DefaultPainter = null;

Clazz.newMethod$(C$, '$init$', function () {
this.highlights = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Vector'))));
this.component = null;
this.drawsLayeredHighlights = false;
this.safeDamager = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.DefaultHighlighter').SafeDamager))), [this, null]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
this.drawsLayeredHighlights = true;
}, 1);

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
var len = this.highlights.size();
for (var i = 0; i < len; i++) {
var info = this.highlights.elementAt$I(i);
if (!(Clazz.instanceOf(info, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo"))) {
var a = this.component.getBounds();
var insets = this.component.getInsets();
a.x = insets.left;
a.y = insets.top;
a.width = a.width-(insets.left + insets.right);
a.height = a.height-(insets.top + insets.bottom);
for (; i < len; i++) {
info = this.highlights.elementAt$I(i);
if (!(Clazz.instanceOf(info, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo"))) {
var p = info.getPainter();
p.paint$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent(g, info.getStartOffset(), info.getEndOffset(), a, this.component);
}}
}}
});

Clazz.newMethod$(C$, 'install$javax_swing_text_JTextComponent', function (c) {
this.component = c;
this.removeAllHighlights();
});

Clazz.newMethod$(C$, 'deinstall$javax_swing_text_JTextComponent', function (c) {
this.component = null;
});

Clazz.newMethod$(C$, 'addHighlight$I$I$javax_swing_text_Highlighter_HighlightPainter', function (p0, p1, p) {
var doc = this.component.getDocument();
var i = (this.getDrawsLayeredHighlights() && (Clazz.instanceOf(p, "javax.swing.text.LayeredHighlighter.LayerPainter")) ) ? Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.text.DefaultHighlighter').LayeredHighlightInfo))), [this, null]) : Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.text.DefaultHighlighter').HighlightInfo))), [this, null]);
i.painter = p;
i.p0 = doc.createPosition$I(p0);
i.p1 = doc.createPosition$I(p1);
this.highlights.addElement$TE(i);
p$.safeDamageRange$I$I.apply(this, [p0, p1]);
return i;
});

Clazz.newMethod$(C$, 'removeHighlight$O', function (tag) {
if (Clazz.instanceOf(tag, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo")) {
var lhi = tag;
if (lhi.width > 0 && lhi.height > 0 ) {
this.component.repaint$I$I$I$I(lhi.x, lhi.y, lhi.width, lhi.height);
}} else {
var info = tag;
p$.safeDamageRange$javax_swing_text_Position$javax_swing_text_Position.apply(this, [info.p0, info.p1]);
}this.highlights.removeElement$O(tag);
});

Clazz.newMethod$(C$, 'removeAllHighlights', function () {
var mapper = this.component.getUI();
if (this.getDrawsLayeredHighlights()) {
var len = this.highlights.size();
if (len != 0) {
var minX = 0;
var minY = 0;
var maxX = 0;
var maxY = 0;
var p0 = -1;
var p1 = -1;
for (var i = 0; i < len; i++) {
var hi = this.highlights.elementAt$I(i);
if (Clazz.instanceOf(hi, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo")) {
var info = hi;
minX = Math.min(minX, info.x);
minY = Math.min(minY, info.y);
maxX = Math.max(maxX, info.x + info.width);
maxY = Math.max(maxY, info.y + info.height);
} else {
if (p0 == -1) {
p0 = hi.p0.getOffset();
p1 = hi.p1.getOffset();
} else {
p0 = Math.min(p0, hi.p0.getOffset());
p1 = Math.max(p1, hi.p1.getOffset());
}}}
if (minX != maxX && minY != maxY ) {
this.component.repaint$I$I$I$I(minX, minY, maxX - minX, maxY - minY);
}if (p0 != -1) {
try {
p$.safeDamageRange$I$I.apply(this, [p0, p1]);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
} else {
throw e;
}
}
}this.highlights.removeAllElements();
}} else if (mapper != null ) {
var len = this.highlights.size();
if (len != 0) {
var p0 = 2147483647;
var p1 = 0;
for (var i = 0; i < len; i++) {
var info = this.highlights.elementAt$I(i);
p0 = Math.min(p0, info.p0.getOffset());
p1 = Math.max(p1, info.p1.getOffset());
}
try {
p$.safeDamageRange$I$I.apply(this, [p0, p1]);
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
} else {
throw e;
}
}
this.highlights.removeAllElements();
}}});

Clazz.newMethod$(C$, 'changeHighlight$O$I$I', function (tag, p0, p1) {
var doc = this.component.getDocument();
if (Clazz.instanceOf(tag, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo")) {
var lhi = tag;
if (lhi.width > 0 && lhi.height > 0 ) {
this.component.repaint$I$I$I$I(lhi.x, lhi.y, lhi.width, lhi.height);
}lhi.width = lhi.height = 0;
lhi.p0 = doc.createPosition$I(p0);
lhi.p1 = doc.createPosition$I(p1);
p$.safeDamageRange$I$I.apply(this, [Math.min(p0, p1), Math.max(p0, p1)]);
} else {
var info = tag;
var oldP0 = info.p0.getOffset();
var oldP1 = info.p1.getOffset();
if (p0 == oldP0) {
p$.safeDamageRange$I$I.apply(this, [Math.min(oldP1, p1), Math.max(oldP1, p1)]);
} else if (p1 == oldP1) {
p$.safeDamageRange$I$I.apply(this, [Math.min(p0, oldP0), Math.max(p0, oldP0)]);
} else {
p$.safeDamageRange$I$I.apply(this, [oldP0, oldP1]);
p$.safeDamageRange$I$I.apply(this, [p0, p1]);
}info.p0 = doc.createPosition$I(p0);
info.p1 = doc.createPosition$I(p1);
}});

Clazz.newMethod$(C$, 'getHighlights', function () {
var size = this.highlights.size();
if (size == 0) {
return C$.noHighlights;
}var h =  Clazz.newArray$(javax.swing.text.Highlighter.Highlight, [size]);
this.highlights.copyInto$OA(h);
return h;
});

Clazz.newMethod$(C$, 'paintLayeredHighlights$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent$javax_swing_text_View', function (g, p0, p1, viewBounds, editor, view) {
for (var counter = this.highlights.size() - 1; counter >= 0; counter--) {
var tag = this.highlights.elementAt$I(counter);
if (Clazz.instanceOf(tag, "javax.swing.text.DefaultHighlighter.LayeredHighlightInfo")) {
var lhi = tag;
var start = lhi.getStartOffset();
var end = lhi.getEndOffset();
if ((p0 < start && p1 > start ) || (p0 >= start && p0 < end ) ) {
lhi.paintLayeredHighlights$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent$javax_swing_text_View(g, p0, p1, viewBounds, editor, view);
}}}
});

Clazz.newMethod$(C$, 'safeDamageRange$javax_swing_text_Position$javax_swing_text_Position', function (p0, p1) {
this.safeDamager.damageRange$javax_swing_text_Position$javax_swing_text_Position(p0, p1);
});

Clazz.newMethod$(C$, 'safeDamageRange$I$I', function (a0, a1) {
var doc = this.component.getDocument();
p$.safeDamageRange$javax_swing_text_Position$javax_swing_text_Position.apply(this, [doc.createPosition$I(a0), doc.createPosition$I(a1)]);
});

Clazz.newMethod$(C$, 'setDrawsLayeredHighlights$Z', function (newValue) {
this.drawsLayeredHighlights = newValue;
});

Clazz.newMethod$(C$, 'getDrawsLayeredHighlights', function () {
return this.drawsLayeredHighlights;
});
;
(function(){var C$=Clazz.newClass$(P$.DefaultHighlighter, "DefaultHighlightPainter", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.LayeredHighlighter.LayerPainter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.color = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color', function (c) {
Clazz.super(C$, this,1);
this.color = c;
}, 1);

Clazz.newMethod$(C$, 'getColor', function () {
return this.color;
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent', function (g, offs0, offs1, bounds, c) {
var alloc = bounds.getBounds();
try {
var mapper = c.getUI();
var p0 = mapper.modelToView$javax_swing_text_JTextComponent$I(c, offs0);
var p1 = mapper.modelToView$javax_swing_text_JTextComponent$I(c, offs1);
var color = this.getColor();
if (color == null ) {
g.setColor$java_awt_Color(c.getSelectionColor());
} else {
g.setColor$java_awt_Color(color);
}if (p0.y == p1.y) {
var r = p0.union$java_awt_Rectangle(p1);
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
} else {
var p0ToMarginWidth = alloc.x + alloc.width - p0.x;
g.fillRect$I$I$I$I(p0.x, p0.y, p0ToMarginWidth, p0.height);
if ((p0.y + p0.height) != p1.y) {
g.fillRect$I$I$I$I(alloc.x, p0.y + p0.height, alloc.width, p1.y - (p0.y + p0.height));
}g.fillRect$I$I$I$I(alloc.x, p1.y, (p1.x - alloc.x), p1.height);
}} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
} else {
throw e;
}
}
});

Clazz.newMethod$(C$, 'paintLayer$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent$javax_swing_text_View', function (g, offs0, offs1, bounds, c, view) {
var color = this.getColor();
if (color == null ) {
g.setColor$java_awt_Color(c.getSelectionColor());
} else {
g.setColor$java_awt_Color(color);
}var r;
if (offs0 == view.getStartOffset() && offs1 == view.getEndOffset() ) {
if (Clazz.instanceOf(bounds, "java.awt.Rectangle")) {
r = bounds;
} else {
r = bounds.getBounds();
}} else {
try {
var shape = view.modelToView$I$javax_swing_text_Position_Bias$I$javax_swing_text_Position_Bias$java_awt_Shape(offs0, (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward, offs1, (I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Backward, bounds);
r = (Clazz.instanceOf(shape, "java.awt.Rectangle")) ? shape : shape.getBounds();
} catch (e) {
if (Clazz.exceptionOf(e, P$.BadLocationException)){
r = null;
} else {
throw e;
}
}
}if (r != null ) {
r.width = Math.max(r.width, 1);
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
}return r;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultHighlighter, "HighlightInfo", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.text.Highlighter.Highlight');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.p0 = null;
this.p1 = null;
this.painter = null;
}, 1);

Clazz.newMethod$(C$, 'getStartOffset', function () {
return this.p0.getOffset();
});

Clazz.newMethod$(C$, 'getEndOffset', function () {
return this.p1.getOffset();
});

Clazz.newMethod$(C$, 'getPainter', function () {
return this.painter;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultHighlighter, "LayeredHighlightInfo", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.text.DefaultHighlighter.HighlightInfo');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.x = 0;
this.y = 0;
this.width = 0;
this.height = 0;
}, 1);

Clazz.newMethod$(C$, 'union$java_awt_Shape', function (bounds) {
if (bounds == null ) return;
var alloc;
if (Clazz.instanceOf(bounds, "java.awt.Rectangle")) {
alloc = bounds;
} else {
alloc = bounds.getBounds();
}if (this.width == 0 || this.height == 0 ) {
this.x = alloc.x;
this.y = alloc.y;
this.width = alloc.width;
this.height = alloc.height;
} else {
this.width = Math.max(this.x + this.width, alloc.x + alloc.width);
this.height = Math.max(this.y + this.height, alloc.y + alloc.height);
this.x = Math.min(this.x, alloc.x);
this.width = this.width-(this.x);
this.y = Math.min(this.y, alloc.y);
this.height = this.height-(this.y);
}});

Clazz.newMethod$(C$, 'paintLayeredHighlights$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent$javax_swing_text_View', function (g, p0, p1, viewBounds, editor, view) {
var start = this.getStartOffset();
var end = this.getEndOffset();
p0 = Math.max(start, p0);
p1 = Math.min(end, p1);
this.union$java_awt_Shape((this.painter).paintLayer$java_awt_Graphics$I$I$java_awt_Shape$javax_swing_text_JTextComponent$javax_swing_text_View(g, p0, p1, viewBounds, editor, view));
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.DefaultHighlighter, "SafeDamager", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.p0 = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Vector'))).c$$I,[10]);
this.p1 = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Vector'))).c$$I,[10]);
this.lastDoc = null;
}, 1);

Clazz.newMethod$(C$, 'run', function () {
if (this.b$['javax.swing.text.DefaultHighlighter'].component != null ) {
var mapper = this.b$['javax.swing.text.DefaultHighlighter'].component.getUI();
if (mapper != null  && this.lastDoc === this.b$['javax.swing.text.DefaultHighlighter'].component.getDocument()  ) {
var len = this.p0.size();
for (var i = 0; i < len; i++) {
mapper.damageRange$javax_swing_text_JTextComponent$I$I(this.b$['javax.swing.text.DefaultHighlighter'].component, (this.p0.get$I(i)).getOffset(), (this.p1.get$I(i)).getOffset());
}
}}this.p0.clear();
this.p1.clear();
this.lastDoc = null;
});

Clazz.newMethod$(C$, 'damageRange$javax_swing_text_Position$javax_swing_text_Position', function (pos0, pos1) {
if (this.b$['javax.swing.text.DefaultHighlighter'].component == null ) {
this.p0.clear();
this.lastDoc = null;
return;
}var addToQueue = this.p0.isEmpty();
var curDoc = this.b$['javax.swing.text.DefaultHighlighter'].component.getDocument();
if (curDoc !== this.lastDoc ) {
if (!this.p0.isEmpty()) {
this.p0.clear();
this.p1.clear();
}this.lastDoc = curDoc;
}this.p0.add$TE(pos0);
this.p1.add$TE(pos1);
if (addToQueue) {
(I$[2] || (I$[2]=Clazz.load('javax.swing.SwingUtilities'))).invokeLater$Runnable(this);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:32:02
