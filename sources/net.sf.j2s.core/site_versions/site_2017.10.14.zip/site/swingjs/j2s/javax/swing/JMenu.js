(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JMenu", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JMenuItem', 'javax.swing.MenuElement');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.$popupMenu = null;
this.menuChangeListener = null;
this.menuEvent = null;
this.delay = 0;
this.customMenuLocation = null;
this.popupListener = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S$javax_swing_Icon$I$S.apply(this, ["", null, -2147483648, "MenuUI"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (s) {
C$.superClazz.c$$S$javax_swing_Icon$I$S.apply(this, [s, null, -2147483648, "MenuUI"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Action', function (a) {
C$.superClazz.c$$S$javax_swing_Icon$I$S.apply(this, ["", null, -2147483648, "MenuUI"]);
C$.$init$.apply(this);
this.setAction$javax_swing_Action(a);
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (s, b) {
C$.superClazz.c$$S$javax_swing_Icon$I$S.apply(this, [s, null, -2147483648, "MenuUI"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'initFocusability', function () {
});

Clazz.newMethod$(C$, 'updateUI', function () {
C$.superClazz.prototype.updateUI.apply(this, []);
if (this.$popupMenu != null ) {
this.$popupMenu.setUI$javax_swing_plaf_ComponentUI((I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getUI$java_awt_Component(this.$popupMenu));
}});

Clazz.newMethod$(C$, 'setModel$javax_swing_ButtonModel', function (newModel) {
var oldModel = this.getModel();
C$.superClazz.prototype.setModel$javax_swing_ButtonModel.apply(this, [newModel]);
if (oldModel != null  && this.menuChangeListener != null  ) {
oldModel.removeChangeListener$javax_swing_event_ChangeListener(this.menuChangeListener);
this.menuChangeListener = null;
}this.model = newModel;
if (newModel != null ) {
this.menuChangeListener = p$.createMenuChangeListener.apply(this, []);
newModel.addChangeListener$javax_swing_event_ChangeListener(this.menuChangeListener);
}});

Clazz.newMethod$(C$, 'isSelected', function () {
return this.getModel().isSelected();
});

Clazz.newMethod$(C$, 'setSelected$Z', function (b) {
var model = this.getModel();
if (b != model.isSelected() ) {
this.getModel().setSelected$Z(b);
}});

Clazz.newMethod$(C$, 'isPopupMenuVisible', function () {
p$.ensurePopupMenuCreated.apply(this, []);
return this.$popupMenu.isVisible();
});

Clazz.newMethod$(C$, 'setPopupMenuVisible$Z', function (b) {
var isVisible = this.isPopupMenuVisible();
if (b != isVisible  && (this.isEnabled() || !b ) ) {
p$.ensurePopupMenuCreated.apply(this, []);
if ((b == true ) && this.isShowing() ) {
var p = p$.getCustomMenuLocation.apply(this, []);
if (p == null ) {
p = this.getPopupMenuOrigin();
}this.getPopupMenu().show$java_awt_Component$I$I(this, p.x, p.y);
} else {
this.getPopupMenu().setVisible$Z(false);
}}});

Clazz.newMethod$(C$, 'getPopupMenuOrigin', function () {
var x = 0;
var y = 0;
var pm = this.getPopupMenu();
var s = this.getSize();
var pmSize = pm.getSize();
if (pmSize.width == 0) {
pmSize = pm.getPreferredSize();
}var position = this.getLocationOnScreen();
var toolkit = (I$[1] || (I$[1]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit();
var gc = this.getGraphicsConfiguration();
var screenBounds = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Dimension,[toolkit.getScreenSize()]);
if (gc != null ) {
screenBounds = gc.getBounds();
var screenInsets = toolkit.getScreenInsets$java_awt_GraphicsConfiguration(gc);
screenBounds.width = screenBounds.width-(Math.abs(screenInsets.left + screenInsets.right));
screenBounds.height = screenBounds.height-(Math.abs(screenInsets.top + screenInsets.bottom));
position.x = position.x-(Math.abs(screenInsets.left));
position.y = position.y-(Math.abs(screenInsets.top));
}var parent = this.getParent();
if (Clazz.instanceOf(parent, "javax.swing.JPopupMenu")) {
var xOffset = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getInt$O("Menu.submenuPopupOffsetX");
var yOffset = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getInt$O("Menu.submenuPopupOffsetY");
if ((I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).isLeftToRight$java_awt_Component(this)) {
x = s.width + xOffset;
if (position.x + x + pmSize.width  >= screenBounds.width + screenBounds.x && screenBounds.width - s.width < 2 * (position.x - screenBounds.x) ) {
x = 0 - xOffset - pmSize.width ;
}} else {
x = 0 - xOffset - pmSize.width ;
if (position.x + x < screenBounds.x && screenBounds.width - s.width > 2 * (position.x - screenBounds.x) ) {
x = s.width + xOffset;
}}y = yOffset;
if (position.y + y + pmSize.height  >= screenBounds.height + screenBounds.y && screenBounds.height - s.height < 2 * (position.y - screenBounds.y) ) {
y = s.height - yOffset - pmSize.height ;
}} else {
var xOffset = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getInt$O("Menu.menuPopupOffsetX");
var yOffset = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getInt$O("Menu.menuPopupOffsetY");
if ((I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).isLeftToRight$java_awt_Component(this)) {
x = xOffset;
if (position.x + x + pmSize.width  >= screenBounds.width + screenBounds.x && screenBounds.width - s.width < 2 * (position.x - screenBounds.x) ) {
x = s.width - xOffset - pmSize.width ;
}} else {
x = s.width - xOffset - pmSize.width ;
if (position.x + x < screenBounds.x && screenBounds.width - s.width > 2 * (position.x - screenBounds.x) ) {
x = xOffset;
}}y = s.height + yOffset;
if (position.y + y + pmSize.height  >= screenBounds.height && screenBounds.height - s.height < 2 * (position.y - screenBounds.y) ) {
y = 0 - yOffset - pmSize.height ;
}}return Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.Point'))).c$$I$I,[x, y]);
});

Clazz.newMethod$(C$, 'getDelay', function () {
return this.delay;
});

Clazz.newMethod$(C$, 'setDelay$I', function (d) {
if (d < 0) throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Delay must be a positive integer"]);
this.delay = d;
});

Clazz.newMethod$(C$, 'ensurePopupMenuCreated', function () {
if (this.$popupMenu == null ) {
this.$popupMenu = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.JPopupMenu'))));
this.$popupMenu.setInvoker$java_awt_Component(this);
this.popupListener = this.createWinListener$javax_swing_JPopupMenu(this.$popupMenu);
}});

Clazz.newMethod$(C$, 'getCustomMenuLocation', function () {
return this.customMenuLocation;
});

Clazz.newMethod$(C$, 'setMenuLocation$I$I', function (x, y) {
this.customMenuLocation = Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.Point'))).c$$I$I,[x, y]);
if (this.$popupMenu != null ) this.$popupMenu.setLocation$I$I(x, y);
});

Clazz.newMethod$(C$, 'add$javax_swing_JMenuItem', function (menuItem) {
p$.ensurePopupMenuCreated.apply(this, []);
return this.$popupMenu.add$javax_swing_JMenuItem(menuItem);
});

Clazz.newMethod$(C$, 'add$java_awt_Component', function (c) {
p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.add$java_awt_Component(c);
return c;
});

Clazz.newMethod$(C$, 'add$java_awt_Component$I', function (c, index) {
p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.add$java_awt_Component$I(c, index);
return c;
});

Clazz.newMethod$(C$, 'add$S', function (s) {
return this.add$javax_swing_JMenuItem(Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JMenuItem'))).c$$S,[s]));
});

Clazz.newMethod$(C$, 'add$javax_swing_Action', function (a) {
var mi = this.createActionComponent$javax_swing_Action(a);
mi.setAction$javax_swing_Action(a);
this.add$javax_swing_JMenuItem(mi);
return mi;
});

Clazz.newMethod$(C$, 'createActionComponent$javax_swing_Action', function (a) {
var mi = ((
(function(){var C$=Clazz.newClass$(P$, "JMenu$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.JMenuItem'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'createActionPropertyChangeListener$javax_swing_Action', function (a) {
var pcl = this.b$['javax.swing.JMenu'].createActionChangeListener$javax_swing_JMenuItem(this);
if (pcl == null ) {
pcl = C$.superClazz.prototype.createActionPropertyChangeListener$javax_swing_Action.apply(this, [a]);
}return pcl;
});
})()
), Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JMenuItem'))), [this, null],P$.JMenu$1));
mi.setHorizontalTextPosition$I(11);
mi.setVerticalTextPosition$I(0);
return mi;
});

Clazz.newMethod$(C$, 'createActionChangeListener$javax_swing_JMenuItem', function (b) {
return b.createActionPropertyChangeListener0$javax_swing_Action(b.getAction());
});

Clazz.newMethod$(C$, 'addSeparator', function () {
p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.addSeparator();
});

Clazz.newMethod$(C$, 'insert$S$I', function (s, pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.insert$java_awt_Component$I(Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JMenuItem'))).c$$S,[s]), pos);
});

Clazz.newMethod$(C$, 'insert$javax_swing_JMenuItem$I', function (mi, pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.insert$java_awt_Component$I(mi, pos);
return mi;
});

Clazz.newMethod$(C$, 'insert$javax_swing_Action$I', function (a, pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}p$.ensurePopupMenuCreated.apply(this, []);
var mi = Clazz.new((I$[6] || (I$[6]=Clazz.load('javax.swing.JMenuItem'))).c$$javax_swing_Action,[a]);
mi.setHorizontalTextPosition$I(11);
mi.setVerticalTextPosition$I(0);
this.$popupMenu.insert$java_awt_Component$I(mi, pos);
return mi;
});

Clazz.newMethod$(C$, 'insertSeparator$I', function (index) {
if (index < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}p$.ensurePopupMenuCreated.apply(this, []);
this.$popupMenu.insert$java_awt_Component$I(Clazz.new((I$[7] || (I$[7]=Clazz.load(Clazz.load('javax.swing.JPopupMenu').Separator)))), index);
});

Clazz.newMethod$(C$, 'getItem$I', function (pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}var c = this.getMenuComponent$I(pos);
if (Clazz.instanceOf(c, "javax.swing.JMenuItem")) {
var mi = c;
return mi;
}return null;
});

Clazz.newMethod$(C$, 'getItemCount', function () {
return this.getMenuComponentCount();
});

Clazz.newMethod$(C$, 'isTearOff', function () {
throw Clazz.new((I$[8] || (I$[8]=Clazz.load('java.lang.Error'))).c$$S,["boolean isTearOff() {} not yet implemented"]);
});

Clazz.newMethod$(C$, 'remove$javax_swing_JMenuItem', function (item) {
this.remove$java_awt_Component(item);
});

Clazz.newMethod$(C$, 'remove$I', function (pos) {
if (pos < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index less than zero."]);
}if (pos > this.getItemCount()) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["index greater than the number of items."]);
}if (this.$popupMenu != null ) this.$popupMenu.remove$I(pos);
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "javax.swing.JMenuItem")) if (this.$popupMenu != null ) this.$popupMenu.remove$java_awt_Component(c);
if (this.$popupMenu != null ) this.$popupMenu.remove$java_awt_Component(c);
});

Clazz.newMethod$(C$, 'removeAll', function () {
if (this.$popupMenu != null ) this.$popupMenu.removeAll();
});

Clazz.newMethod$(C$, 'getMenuComponentCount', function () {
var componentCount = 0;
if (this.$popupMenu != null ) componentCount = this.$popupMenu.getComponentCount();
return componentCount;
});

Clazz.newMethod$(C$, 'getMenuComponent$I', function (n) {
if (this.$popupMenu != null ) return this.$popupMenu.getComponent$I(n);
return null;
});

Clazz.newMethod$(C$, 'getMenuComponents', function () {
if (this.$popupMenu != null ) return this.$popupMenu.getComponents();
return  Clazz.newArray$(java.awt.Component, [0]);
});

Clazz.newMethod$(C$, 'isTopLevelMenu', function () {
if (Clazz.instanceOf(this.getParent(), "javax.swing.JMenuBar")) return true;
return false;
});

Clazz.newMethod$(C$, 'isMenuComponent$java_awt_Component', function (c) {
if (c === this ) return true;
if (Clazz.instanceOf(c, "javax.swing.JPopupMenu")) {
var comp = c;
if (comp === this.getPopupMenu() ) return true;
}var ncomponents = this.getMenuComponentCount();
var component = this.getMenuComponents();
for (var i = 0; i < ncomponents; i++) {
var comp = component[i];
if (comp === c ) return true;
if (Clazz.instanceOf(comp, "javax.swing.JMenu")) {
var subMenu = comp;
if (subMenu.isMenuComponent$java_awt_Component(c)) return true;
}}
return false;
});

Clazz.newMethod$(C$, 'getPopupMenu', function () {
p$.ensurePopupMenuCreated.apply(this, []);
return this.$popupMenu;
});

Clazz.newMethod$(C$, 'addMenuListener$javax_swing_event_MenuListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.MenuListener), l);
});

Clazz.newMethod$(C$, 'removeMenuListener$javax_swing_event_MenuListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.MenuListener), l);
});

Clazz.newMethod$(C$, 'getMenuListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.MenuListener));
});

Clazz.newMethod$(C$, 'fireMenuSelected', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuListener) ) {
if (listeners[i + 1] == null ) {
throw Clazz.new((I$[8] || (I$[8]=Clazz.load('java.lang.Error'))).c$$S,[this.getText() + " has a NULL Listener!! " + i ]);
} else {
if (this.menuEvent == null ) this.menuEvent = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.MenuEvent'))).c$$O,[this]);
(listeners[i + 1]).menuSelected$javax_swing_event_MenuEvent(this.menuEvent);
}}}
});

Clazz.newMethod$(C$, 'fireMenuDeselected', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuListener) ) {
if (listeners[i + 1] == null ) {
throw Clazz.new((I$[8] || (I$[8]=Clazz.load('java.lang.Error'))).c$$S,[this.getText() + " has a NULL Listener!! " + i ]);
} else {
if (this.menuEvent == null ) this.menuEvent = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.MenuEvent'))).c$$O,[this]);
(listeners[i + 1]).menuDeselected$javax_swing_event_MenuEvent(this.menuEvent);
}}}
});

Clazz.newMethod$(C$, 'fireMenuCanceled', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.MenuListener) ) {
if (listeners[i + 1] == null ) {
throw Clazz.new((I$[8] || (I$[8]=Clazz.load('java.lang.Error'))).c$$S,[this.getText() + " has a NULL Listener!! " + i ]);
} else {
if (this.menuEvent == null ) this.menuEvent = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.event.MenuEvent'))).c$$O,[this]);
(listeners[i + 1]).menuCanceled$javax_swing_event_MenuEvent(this.menuEvent);
}}}
});

Clazz.newMethod$(C$, 'configureAcceleratorFromAction$javax_swing_Action', function (a) {
});

Clazz.newMethod$(C$, 'createMenuChangeListener', function () {
return Clazz.new((I$[10] || (I$[10]=Clazz.load(Clazz.load('javax.swing.JMenu').MenuChangeListener))), [this, null]);
});

Clazz.newMethod$(C$, 'createWinListener$javax_swing_JPopupMenu', function (p) {
return Clazz.new((I$[11] || (I$[11]=Clazz.load(Clazz.load('javax.swing.JMenu').WinListener))).c$$javax_swing_JPopupMenu, [this, null, p]);
});

Clazz.newMethod$(C$, 'menuSelectionChanged$Z', function (isIncluded) {
this.setSelected$Z(isIncluded);
});

Clazz.newMethod$(C$, 'getSubElements', function () {
if (this.$popupMenu == null ) return  Clazz.newArray$(javax.swing.MenuElement, [0]);
 else {
var result =  Clazz.newArray$(javax.swing.MenuElement, [1]);
result[0] = this.$popupMenu;
return result;
}});

Clazz.newMethod$(C$, 'getComponent', function () {
return this;
});

Clazz.newMethod$(C$, 'applyComponentOrientation$java_awt_ComponentOrientation', function (o) {
C$.superClazz.prototype.applyComponentOrientation$java_awt_ComponentOrientation.apply(this, [o]);
if (this.$popupMenu != null ) {
var ncomponents = this.getMenuComponentCount();
for (var i = 0; i < ncomponents; ++i) {
this.getMenuComponent$I(i).applyComponentOrientation$java_awt_ComponentOrientation(o);
}
this.$popupMenu.setComponentOrientation$java_awt_ComponentOrientation(o);
}});

Clazz.newMethod$(C$, 'setComponentOrientation$java_awt_ComponentOrientation', function (o) {
C$.superClazz.prototype.setComponentOrientation$java_awt_ComponentOrientation.apply(this, [o]);
if (this.$popupMenu != null ) {
this.$popupMenu.setComponentOrientation$java_awt_ComponentOrientation(o);
}});

Clazz.newMethod$(C$, 'setAccelerator$javax_swing_KeyStroke', function (keyStroke) {
throw Clazz.new((I$[8] || (I$[8]=Clazz.load('java.lang.Error'))).c$$S,["setAccelerator() is not defined for JMenu.  Use setMnemonic() instead."]);
});

Clazz.newMethod$(C$, 'processKeyEvent$java_awt_event_KeyEvent', function (evt) {
(I$[12] || (I$[12]=Clazz.load('javax.swing.MenuSelectionManager'))).defaultManager().processKeyEvent$java_awt_event_KeyEvent(evt);
if (evt.isConsumed()) return;
C$.superClazz.prototype.processKeyEvent$java_awt_event_KeyEvent.apply(this, [evt]);
});

Clazz.newMethod$(C$, 'doClick$I', function (pressTime) {
var me = p$.buildMenuElementArray$javax_swing_JMenu.apply(this, [this]);
(I$[12] || (I$[12]=Clazz.load('javax.swing.MenuSelectionManager'))).defaultManager().setSelectedPath$javax_swing_MenuElementA(me);
});

Clazz.newMethod$(C$, 'buildMenuElementArray$javax_swing_JMenu', function (leaf) {
var elements = Clazz.new((I$[13] || (I$[13]=Clazz.load('java.util.Vector'))));
var current = leaf.getPopupMenu();
var pop;
var menu;
var bar;
while (true){
if (Clazz.instanceOf(current, "javax.swing.JPopupMenu")) {
pop = current;
elements.insertElementAt$TE$I(pop, 0);
current = pop.getInvoker();
} else if (Clazz.instanceOf(current, "javax.swing.JMenu")) {
menu = current;
elements.insertElementAt$TE$I(menu, 0);
current = menu.getParent();
} else if (Clazz.instanceOf(current, "javax.swing.JMenuBar")) {
bar = current;
elements.insertElementAt$TE$I(bar, 0);
var me =  Clazz.newArray$(javax.swing.MenuElement, [elements.size()]);
elements.copyInto$OA(me);
return me;
}}
});

Clazz.newMethod$(C$, 'paramString', function () {
return C$.superClazz.prototype.paramString.apply(this, []);
});
;
(function(){var C$=Clazz.newClass$(P$.JMenu, "MenuChangeListener", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.isSelected = false;
}, 1);

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var model = e.getSource();
var modelSelected = model.isSelected();
if (modelSelected != this.isSelected ) {
if (modelSelected == true ) {
this.b$['javax.swing.JMenu'].fireMenuSelected();
} else {
this.b$['javax.swing.JMenu'].fireMenuDeselected();
}this.isSelected = modelSelected;
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JMenu, "WinListener", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.popupMenu = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JPopupMenu', function (p) {
Clazz.super(C$, this,1);
this.popupMenu = p;
}, 1);

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['javax.swing.JMenu'].setSelected$Z(false);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:40
