(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JColorChooser", null, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.selectionModel = null;
this.previewPanel = null;
this.chooserPanels =  Clazz.newArray$(javax.swing.colorchooser.AbstractColorChooserPanel, [0]);
this.dragEnabled = false;
}, 1);

Clazz.newMethod$(C$, 'showDialog$java_awt_Component$S$java_awt_Color', function (component, title, initialColor) {
var pane = Clazz.new(C$.c$$java_awt_Color,[initialColor != null  ? initialColor : (I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).white]);
var ok = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.ColorTracker'))).c$$javax_swing_JColorChooser,[pane]);
var dialog = C$.createDialog$java_awt_Component$S$Z$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener(component, title, true, pane, ok, null);
dialog.addComponentListener$java_awt_event_ComponentListener(Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.ColorChooserDialog').DisposeOnClose)))));
dialog.show();
return ok.getColor();
}, 1);

Clazz.newMethod$(C$, 'createDialog$java_awt_Component$S$Z$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener', function (c, title, modal, chooserPane, okListener, cancelListener) {
var window = (I$[3] || (I$[3]=Clazz.load('javax.swing.JOptionPane'))).getWindowForComponent$java_awt_Component(c);
var dialog;
if (Clazz.instanceOf(window, "java.awt.Frame")) {
dialog = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.ColorChooserDialog'))).c$$java_awt_Frame$S$Z$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener,[window, title, modal, c, chooserPane, okListener, cancelListener]);
} else {
dialog = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.ColorChooserDialog'))).c$$java_awt_Dialog$S$Z$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener,[window, title, modal, c, chooserPane, okListener, cancelListener]);
}return dialog;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_awt_Color.apply(this, [(I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).white]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color', function (initialColor) {
C$.c$$javax_swing_colorchooser_ColorSelectionModel.apply(this, [Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.colorchooser.DefaultColorSelectionModel'))).c$$java_awt_Color,[initialColor])]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_colorchooser_ColorSelectionModel', function (model) {
Clazz.super(C$, this,1);
this.selectionModel = model;
this.uiClassID = "ColorChooserUI";
this.updateUI();
this.dragEnabled = false;
}, 1);

Clazz.newMethod$(C$, 'getColor', function () {
return this.selectionModel.getSelectedColor();
});

Clazz.newMethod$(C$, 'setColor$java_awt_Color', function (color) {
this.selectionModel.setSelectedColor$java_awt_Color(color);
});

Clazz.newMethod$(C$, 'setColor$I$I$I', function (r, g, b) {
this.setColor$java_awt_Color(Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Color'))).c$$I$I$I,[r, g, b]));
});

Clazz.newMethod$(C$, 'setColor$I', function (c) {
this.setColor$I$I$I((c >> 16) & 255, (c >> 8) & 255, c & 255);
});

Clazz.newMethod$(C$, 'setDragEnabled$Z', function (b) {
this.dragEnabled = b;
});

Clazz.newMethod$(C$, 'getDragEnabled', function () {
return this.dragEnabled;
});

Clazz.newMethod$(C$, 'setPreviewPanel$javax_swing_JComponent', function (preview) {
if (this.previewPanel !== preview ) {
var oldPreview = this.previewPanel;
this.previewPanel = preview;
this.firePropertyChange$S$O$O("previewPanel", oldPreview, preview);
}});

Clazz.newMethod$(C$, 'getPreviewPanel', function () {
return this.previewPanel;
});

Clazz.newMethod$(C$, 'addChooserPanel$javax_swing_colorchooser_AbstractColorChooserPanel', function (panel) {
var oldPanels = this.getChooserPanels();
var newPanels =  Clazz.newArray$(javax.swing.colorchooser.AbstractColorChooserPanel, [oldPanels.length + 1]);
System.arraycopy(oldPanels, 0, newPanels, 0, oldPanels.length);
newPanels[newPanels.length - 1] = panel;
this.setChooserPanels$javax_swing_colorchooser_AbstractColorChooserPanelA(newPanels);
});

Clazz.newMethod$(C$, 'removeChooserPanel$javax_swing_colorchooser_AbstractColorChooserPanel', function (panel) {
var containedAt = -1;
for (var i = 0; i < this.chooserPanels.length; i++) {
if (this.chooserPanels[i] === panel ) {
containedAt = i;
break;
}}
if (containedAt == -1) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["chooser panel not in this chooser"]);
}var newArray =  Clazz.newArray$(javax.swing.colorchooser.AbstractColorChooserPanel, [this.chooserPanels.length - 1]);
if (containedAt == this.chooserPanels.length - 1) {
System.arraycopy(this.chooserPanels, 0, newArray, 0, newArray.length);
} else if (containedAt == 0) {
System.arraycopy(this.chooserPanels, 1, newArray, 0, newArray.length);
} else {
System.arraycopy(this.chooserPanels, 0, newArray, 0, containedAt);
System.arraycopy(this.chooserPanels, containedAt + 1, newArray, containedAt, (this.chooserPanels.length - containedAt - 1 ));
}this.setChooserPanels$javax_swing_colorchooser_AbstractColorChooserPanelA(newArray);
return panel;
});

Clazz.newMethod$(C$, 'setChooserPanels$javax_swing_colorchooser_AbstractColorChooserPanelA', function (panels) {
var oldValue = this.chooserPanels;
this.chooserPanels = panels;
this.firePropertyChange$S$O$O("chooserPanels", oldValue, panels);
});

Clazz.newMethod$(C$, 'getChooserPanels', function () {
return this.chooserPanels;
});

Clazz.newMethod$(C$, 'getSelectionModel', function () {
return this.selectionModel;
});

Clazz.newMethod$(C$, 'setSelectionModel$javax_swing_colorchooser_ColorSelectionModel', function (newModel) {
var oldModel = this.selectionModel;
this.selectionModel = newModel;
this.firePropertyChange$S$O$O("selectionModel", oldModel, newModel);
});

Clazz.newMethod$(C$, 'paramString', function () {
var chooserPanelsString = Clazz.new((I$[6] || (I$[6]=Clazz.load('java.lang.StringBuffer'))).c$$S,[""]);
for (var i = 0; i < this.chooserPanels.length; i++) {
chooserPanelsString.append$S("[" + this.chooserPanels[i].toString() + "]" );
}
var previewPanelString = (this.previewPanel != null  ? this.previewPanel.toString() : "");
return C$.superClazz.prototype.paramString.apply(this, []) + ",chooserPanels=" + chooserPanelsString.toString() + ",previewPanel=" + previewPanelString ;
});
})();
//Created 2017-10-14 13:31:35
