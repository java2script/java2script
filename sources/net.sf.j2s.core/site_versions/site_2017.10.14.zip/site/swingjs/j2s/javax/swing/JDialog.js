(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JDialog", null, 'java.awt.Dialog', ['javax.swing.WindowConstants', 'javax.swing.RootPaneContainer']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.defaultLookAndFeelDecoratedKey =  new Clazz._O();
};

C$.defaultLookAndFeelDecoratedKey = null;
C$.dialogCount = 0;

Clazz.newMethod$(C$, '$init$', function () {
this.defaultCloseOperation = 1;
this.rootPane = null;
this.rootPaneCheckingEnabled = false;
this.transferHandler = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_awt_Frame$Z.apply(this, [null, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame', function (owner) {
C$.c$$java_awt_Frame$Z.apply(this, [owner, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$Z', function (owner, modal) {
C$.c$$java_awt_Frame$S$Z.apply(this, [owner, null, modal]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S', function (owner, title) {
C$.c$$java_awt_Frame$S$Z.apply(this, [owner, title, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S$Z', function (owner, title, modal) {
C$.superClazz.c$$java_awt_Frame$S$Z.apply(this, [owner == null  ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame() : owner, title, modal]);
C$.$init$.apply(this);
if (owner == null ) {
var ownerShutdownListener = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
this.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S$Z$java_awt_GraphicsConfiguration', function (owner, title, modal, gc) {
C$.superClazz.c$$java_awt_Frame$S$Z$java_awt_GraphicsConfiguration.apply(this, [owner == null  ? (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrame() : owner, title, modal, gc]);
C$.$init$.apply(this);
if (owner == null ) {
var ownerShutdownListener = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).getSharedOwnerFrameShutdownListener();
this.addWindowListener$java_awt_event_WindowListener(ownerShutdownListener);
}this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog', function (owner) {
C$.c$$java_awt_Dialog$Z.apply(this, [owner, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$Z', function (owner, modal) {
C$.c$$java_awt_Dialog$S$Z.apply(this, [owner, null, modal]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S', function (owner, title) {
C$.c$$java_awt_Dialog$S$Z.apply(this, [owner, title, false]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S$Z', function (owner, title, modal) {
C$.superClazz.c$$java_awt_Dialog$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S$Z$java_awt_GraphicsConfiguration', function (owner, title, modal, gc) {
C$.superClazz.c$$java_awt_Dialog$S$Z$java_awt_GraphicsConfiguration.apply(this, [owner, title, modal, gc]);
C$.$init$.apply(this);
this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window', function (owner) {
C$.c$$java_awt_Window$java_awt_Dialog_ModalityType.apply(this, [owner, (I$[1] || (I$[1]=Clazz.load(Clazz.load('java.awt.Dialog').ModalityType))).MODELESS]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window$java_awt_Dialog_ModalityType', function (owner, modalityType) {
C$.c$$java_awt_Window$S$java_awt_Dialog_ModalityType.apply(this, [owner, null, modalityType]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window$S', function (owner, title) {
C$.c$$java_awt_Window$S$java_awt_Dialog_ModalityType.apply(this, [owner, title, (I$[1] || (I$[1]=Clazz.load(Clazz.load('java.awt.Dialog').ModalityType))).MODELESS]);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window$S$java_awt_Dialog_ModalityType', function (owner, title, modalityType) {
C$.superClazz.c$$java_awt_Window$S$java_awt_Dialog_ModalityType.apply(this, [owner, title, modalityType]);
C$.$init$.apply(this);
this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Window$S$java_awt_Dialog_ModalityType$java_awt_GraphicsConfiguration', function (owner, title, modalityType, gc) {
C$.superClazz.c$$java_awt_Window$S$java_awt_Dialog_ModalityType$java_awt_GraphicsConfiguration.apply(this, [owner, title, modalityType, gc]);
C$.$init$.apply(this);
this.dialogInit();
}, 1);

Clazz.newMethod$(C$, 'dialogInit', function () {
this.enableEvents$J(72);
this.setLocale$java_util_Locale((I$[2] || (I$[2]=Clazz.load('javax.swing.JComponent'))).getDefaultLocale());
this.setRootPane$javax_swing_JRootPane(this.createRootPane());
this.rootPane.setFrameViewer$swingjs_JSFrameViewer(this.setFrameViewer$swingjs_JSFrameViewer(null));
this.setRootPaneCheckingEnabled$Z(true);
if (C$.isDefaultLookAndFeelDecorated()) {
var supportsWindowDecorations = (I$[3] || (I$[3]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getSupportsWindowDecorations();
if (supportsWindowDecorations) {
this.setUndecorated$Z(true);
this.getRootPane().setWindowDecorationStyle$I(2);
}}this.uiClassID = "DialogUI";
this.updateUI();
this.addNotify();
this.rootPane.addNotify();
});

Clazz.newMethod$(C$, 'createRootPane', function () {
var rp = Clazz.new((I$[4] || (I$[4]=Clazz.load('javax.swing.JRootPane'))).c$$S$Z,["_Dialog" + (++C$.dialogCount), false]);
rp.setOpaque$Z(true);
return rp;
});

Clazz.newMethod$(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superClazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
switch (this.defaultCloseOperation) {
case 1:
this.setVisible$Z(false);
break;
case 2:
this.dispose();
break;
case 0:
default:
break;
}
}});

Clazz.newMethod$(C$, 'setDefaultCloseOperation$I', function (operation) {
if (operation != 0 && operation != 1  && operation != 2 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["defaultCloseOperation must be one of: DO_NOTHING_ON_CLOSE, HIDE_ON_CLOSE, or DISPOSE_ON_CLOSE"]);
}var oldValue = this.defaultCloseOperation;
this.defaultCloseOperation = operation;
this.firePropertyChange$S$I$I("defaultCloseOperation", oldValue, operation);
});

Clazz.newMethod$(C$, 'getDefaultCloseOperation', function () {
return this.defaultCloseOperation;
});

Clazz.newMethod$(C$, 'setTransferHandler$javax_swing_TransferHandler', function (newHandler) {
var oldHandler = this.transferHandler;
this.transferHandler = newHandler;
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).installSwingDropTargetAsNecessary$java_awt_Component$javax_swing_TransferHandler(this, this.transferHandler);
this.firePropertyChange$S$O$O("transferHandler", oldHandler, newHandler);
});

Clazz.newMethod$(C$, 'getTransferHandler', function () {
return this.transferHandler;
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'setJMenuBar$javax_swing_JMenuBar', function (menu) {
this.getRootPane().setMenuBar$javax_swing_JMenuBar(menu);
});

Clazz.newMethod$(C$, 'getJMenuBar', function () {
return this.getRootPane().getMenuBar();
});

Clazz.newMethod$(C$, 'isRootPaneCheckingEnabled', function () {
return this.rootPaneCheckingEnabled;
});

Clazz.newMethod$(C$, 'setRootPaneCheckingEnabled$Z', function (enabled) {
this.rootPaneCheckingEnabled = enabled;
});

Clazz.newMethod$(C$, 'addImpl$java_awt_Component$O$I', function (comp, constraints, index) {
if (this.isRootPaneCheckingEnabled()) {
return this.getContentPane().add$java_awt_Component$O$I(comp, constraints, index);
}return this.addImplCont$java_awt_Component$O$I(comp, constraints, index);
});

Clazz.newMethod$(C$, 'remove$java_awt_Component', function (comp) {
if (comp === this.rootPane ) {
C$.superClazz.prototype.remove$java_awt_Component.apply(this, [comp]);
} else {
this.getContentPane().remove$java_awt_Component(comp);
}});

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (manager) {
if (this.isRootPaneCheckingEnabled()) {
this.getContentPane().setLayout$java_awt_LayoutManager(manager);
} else {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [manager]);
}});

Clazz.newMethod$(C$, 'getRootPane', function () {
return this.rootPane;
});

Clazz.newMethod$(C$, 'setRootPane$javax_swing_JRootPane', function (root) {
if (this.rootPane != null ) {
this.remove$java_awt_Component(this.rootPane);
}this.rootPane = root;
if (this.rootPane != null ) {
var checkingEnabled = this.isRootPaneCheckingEnabled();
try {
this.setRootPaneCheckingEnabled$Z(false);
this.add$java_awt_Component$O(this.rootPane, "Center");
} finally {
this.setRootPaneCheckingEnabled$Z(checkingEnabled);
}
}});

Clazz.newMethod$(C$, 'getContentPane', function () {
return this.getRootPane().getContentPane();
});

Clazz.newMethod$(C$, 'setContentPane$java_awt_Container', function (contentPane) {
this.getRootPane().setContentPane$java_awt_Container(contentPane);
});

Clazz.newMethod$(C$, 'getLayeredPane', function () {
return this.getRootPane().getLayeredPane();
});

Clazz.newMethod$(C$, 'setLayeredPane$javax_swing_JLayeredPane', function (layeredPane) {
this.getRootPane().setLayeredPane$javax_swing_JLayeredPane(layeredPane);
});

Clazz.newMethod$(C$, 'getGlassPane', function () {
return this.getRootPane().getGlassPane();
});

Clazz.newMethod$(C$, 'setGlassPane$java_awt_Component', function (glassPane) {
this.getRootPane().setGlassPane$java_awt_Component(glassPane);
});

Clazz.newMethod$(C$, 'getGraphics', function () {
(I$[2] || (I$[2]=Clazz.load('javax.swing.JComponent'))).getGraphicsInvoked$java_awt_Component(this);
return C$.superClazz.prototype.getGraphics.apply(this, []);
});

Clazz.newMethod$(C$, 'repaint$J$I$I$I$I', function (time, x, y, width, height) {
if ((I$[5] || (I$[5]=Clazz.load('javax.swing.RepaintManager'))).HANDLE_TOP_LEVEL_PAINT) {
(I$[5] || (I$[5]=Clazz.load('javax.swing.RepaintManager'))).currentManager$java_awt_Component(this).addDirtyRegion$java_awt_Window$I$I$I$I(this, x, y, width, height);
} else {
C$.superClazz.prototype.repaint$J$I$I$I$I.apply(this, [time, x, y, width, height]);
}});

Clazz.newMethod$(C$, 'setDefaultLookAndFeelDecorated$Z', function (defaultLookAndFeelDecorated) {
if (defaultLookAndFeelDecorated) {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLookAndFeelDecoratedKey, Boolean.TRUE);
} else {
(I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextPut$O$O(C$.defaultLookAndFeelDecoratedKey, Boolean.FALSE);
}}, 1);

Clazz.newMethod$(C$, 'isDefaultLookAndFeelDecorated', function () {
var defaultLookAndFeelDecorated = (I$[0] || (I$[0]=Clazz.load('javax.swing.SwingUtilities'))).appContextGet$O(C$.defaultLookAndFeelDecoratedKey);
if (defaultLookAndFeelDecorated == null ) {
defaultLookAndFeelDecorated = Boolean.FALSE;
}return defaultLookAndFeelDecorated.booleanValue();
}, 1);

Clazz.newMethod$(C$, 'paramString', function () {
var defaultCloseOperationString;
if (this.defaultCloseOperation == 1) {
defaultCloseOperationString = "HIDE_ON_CLOSE";
} else if (this.defaultCloseOperation == 2) {
defaultCloseOperationString = "DISPOSE_ON_CLOSE";
} else if (this.defaultCloseOperation == 0) {
defaultCloseOperationString = "DO_NOTHING_ON_CLOSE";
} else defaultCloseOperationString = "";
var rootPaneString = (this.rootPane != null  ? this.rootPane.toString() : "");
var rootPaneCheckingEnabledString = (this.rootPaneCheckingEnabled ? "true" : "false");
return C$.superClazz.prototype.paramString.apply(this, []) + ",defaultCloseOperation=" + defaultCloseOperationString + ",rootPane=" + rootPaneString + ",rootPaneCheckingEnabled=" + rootPaneCheckingEnabledString ;
});
})();
//Created 2017-10-14 13:31:37
