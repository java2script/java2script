(function(){var P$=Clazz.newPackage$("javax.imageio.stream");
var C$=Clazz.newInterface$(P$, "ImageOutputStream", null, null, ['javax.imageio.stream.ImageInputStream', 'java.io.DataOutput']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

})();
//Created 2017-10-14 13:31:28
