(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "ListDataEvent", null, 'java.util.EventObject');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.type = 0;
this.index0 = 0;
this.index1 = 0;
}, 1);

Clazz.newMethod$(C$, 'getType', function () {
return this.type;
});

Clazz.newMethod$(C$, 'getIndex0', function () {
return this.index0;
});

Clazz.newMethod$(C$, 'getIndex1', function () {
return this.index1;
});

Clazz.newMethod$(C$, 'c$$O$I$I$I', function (source, type, index0, index1) {
C$.superClazz.c$.apply(this, [source]);
C$.$init$.apply(this);
this.type = type;
this.index0 = Math.min(index0, index1);
this.index1 = Math.max(index0, index1);
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return this.getClass().getName() + "[type=" + this.type + ",index0=" + this.index0 + ",index1=" + this.index1 + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
