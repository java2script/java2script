(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newClass$(P$, "SortOrder", null, 'Enum');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
var vals = [];
Clazz.newEnumConst$(vals, C$.c$, "ASCENDING", 0, []);
Clazz.newEnumConst$(vals, C$.c$, "DESCENDING", 1, []);
Clazz.newEnumConst$(vals, C$.c$, "UNSORTED", 2, []);
Clazz.newMethod$(C$, 'values', function() { return vals }, 1);
Clazz.newMethod$(Enum, 'valueOf$Class$S', function(cl, name) { return cl[name] }, 1);
})();
//Created 2017-10-14 13:31:49
