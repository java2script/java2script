(function(){var P$=Clazz.newPackage$("javax.swing.colorchooser");
var C$=Clazz.newInterface$(P$, "ColorSelectionModel");

})();
//Created 2017-10-14 13:31:53
