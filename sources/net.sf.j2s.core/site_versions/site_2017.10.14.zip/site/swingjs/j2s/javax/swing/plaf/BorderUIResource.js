(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "BorderUIResource", function(){
Clazz.newInstance$(this, arguments);
}, null, ['javax.swing.border.Border', 'javax.swing.plaf.UIResource']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

C$.etched = null;
C$.loweredBevel = null;
C$.raisedBevel = null;
C$.blackLine = null;

Clazz.newMethod$(C$, '$init$', function () {
this.delegate = null;
}, 1);

Clazz.newMethod$(C$, 'getEtchedBorderUIResource', function () {
if (C$.etched == null ) {
C$.etched = Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').EtchedBorderUIResource))));
}return C$.etched;
}, 1);

Clazz.newMethod$(C$, 'getLoweredBevelBorderUIResource', function () {
if (C$.loweredBevel == null ) {
C$.loweredBevel = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').BevelBorderUIResource))).c$$I,[1]);
}return C$.loweredBevel;
}, 1);

Clazz.newMethod$(C$, 'getRaisedBevelBorderUIResource', function () {
if (C$.raisedBevel == null ) {
C$.raisedBevel = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').BevelBorderUIResource))).c$$I,[0]);
}return C$.raisedBevel;
}, 1);

Clazz.newMethod$(C$, 'getBlackLineBorderUIResource', function () {
if (C$.blackLine == null ) {
C$.blackLine = Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.plaf.BorderUIResource').LineBorderUIResource))).c$$java_awt_Color,[(I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).black]);
}return C$.blackLine;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border', function (delegate) {
C$.$init$.apply(this);
if (delegate == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null border delegate argument"]);
}this.delegate = delegate;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
this.delegate.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, x, y, width, height);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.delegate.getBorderInsets$java_awt_Component(c);
});

Clazz.newMethod$(C$, 'isBorderOpaque', function () {
return this.delegate.isBorderOpaque();
});
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "CompoundBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.CompoundBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$javax_swing_border_Border', function (outsideBorder, insideBorder) {
C$.superClazz.c$$javax_swing_border_Border$javax_swing_border_Border.apply(this, [outsideBorder, insideBorder]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "EmptyBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.EmptyBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I', function (top, left, bottom, right) {
C$.superClazz.c$$I$I$I$I.apply(this, [top, left, bottom, right]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Insets', function (insets) {
C$.superClazz.c$$java_awt_Insets.apply(this, [insets]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "LineBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.LineBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color', function (color) {
C$.superClazz.c$$java_awt_Color.apply(this, [color]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$I', function (color, thickness) {
C$.superClazz.c$$java_awt_Color$I.apply(this, [color, thickness]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "BevelBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.BevelBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (bevelType) {
C$.superClazz.c$$I.apply(this, [bevelType]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$java_awt_Color$java_awt_Color', function (bevelType, highlight, shadow) {
C$.superClazz.c$$I$java_awt_Color$java_awt_Color.apply(this, [bevelType, highlight, shadow]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color', function (bevelType, highlightOuter, highlightInner, shadowOuter, shadowInner) {
C$.superClazz.c$$I$java_awt_Color$java_awt_Color$java_awt_Color$java_awt_Color.apply(this, [bevelType, highlightOuter, highlightInner, shadowOuter, shadowInner]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "EtchedBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.EtchedBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (etchType) {
C$.superClazz.c$$I.apply(this, [etchType]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Color$java_awt_Color', function (highlight, shadow) {
C$.superClazz.c$$java_awt_Color$java_awt_Color.apply(this, [highlight, shadow]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$java_awt_Color$java_awt_Color', function (etchType, highlight, shadow) {
C$.superClazz.c$$I$java_awt_Color$java_awt_Color.apply(this, [etchType, highlight, shadow]);
C$.$init$.apply(this);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "MatteBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.MatteBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I$java_awt_Color', function (top, left, bottom, right, color) {
C$.superClazz.c$$I$I$I$I$java_awt_Color.apply(this, [top, left, bottom, right, color]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I$javax_swing_Icon', function (top, left, bottom, right, tileIcon) {
C$.superClazz.c$$I$I$I$I$javax_swing_Icon.apply(this, [top, left, bottom, right, tileIcon]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Icon', function (tileIcon) {
C$.superClazz.c$$javax_swing_Icon.apply(this, [tileIcon]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.BorderUIResource, "TitledBorderUIResource", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.border.TitledBorder', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (title) {
C$.superClazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border', function (border) {
C$.superClazz.c$$javax_swing_border_Border.apply(this, [border]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S', function (border, title) {
C$.superClazz.c$$javax_swing_border_Border$S.apply(this, [border, title]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I', function (border, title, titleJustification, titlePosition) {
C$.superClazz.c$$javax_swing_border_Border$S$I$I.apply(this, [border, title, titleJustification, titlePosition]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I$java_awt_Font', function (border, title, titleJustification, titlePosition, titleFont) {
C$.superClazz.c$$javax_swing_border_Border$S$I$I$java_awt_Font.apply(this, [border, title, titleJustification, titlePosition, titleFont]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color', function (border, title, titleJustification, titlePosition, titleFont, titleColor) {
C$.superClazz.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [border, title, titleJustification, titlePosition, titleFont, titleColor]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:55
