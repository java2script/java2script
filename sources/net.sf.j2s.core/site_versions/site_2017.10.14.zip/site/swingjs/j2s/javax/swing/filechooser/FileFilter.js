(function(){var P$=Clazz.newPackage$("javax.swing.filechooser");
var C$=Clazz.newClass$(P$, "FileFilter");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$SA', function (options) {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'accept$java_io_File', function (f) {
return true;
});

Clazz.newMethod$(C$, 'getDescription', function () {
return "not implemented";
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:55
