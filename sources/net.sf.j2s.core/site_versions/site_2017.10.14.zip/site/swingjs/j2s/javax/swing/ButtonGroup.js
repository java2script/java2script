(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ButtonGroup");


Clazz.newMethod$(C$, '$init$', function () {
this.buttons = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))));
this.selection = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'add$javax_swing_AbstractButton', function (b) {
if (b == null ) {
return;
}this.buttons.addElement$TE(b);
if (b.isSelected()) {
if (this.selection == null ) {
this.selection = b.getModel();
} else {
b.setSelected$Z(false);
}}b.getModel().setGroup$javax_swing_ButtonGroup(this);
});

Clazz.newMethod$(C$, 'remove$javax_swing_AbstractButton', function (b) {
if (b == null ) {
return;
}this.buttons.removeElement$O(b);
if (b.getModel() === this.selection ) {
this.selection = null;
}b.getModel().setGroup$javax_swing_ButtonGroup(null);
});

Clazz.newMethod$(C$, 'clearSelection', function () {
if (this.selection != null ) {
var oldSelection = this.selection;
this.selection = null;
oldSelection.setSelected$Z(false);
}});

Clazz.newMethod$(C$, 'getElements', function () {
return this.buttons.elements();
});

Clazz.newMethod$(C$, 'getSelection', function () {
return this.selection;
});

Clazz.newMethod$(C$, 'setSelected$javax_swing_ButtonModel$Z', function (m, b) {
if (b && m != null   && m !== this.selection  ) {
var oldSelection = this.selection;
this.selection = m;
if (oldSelection != null ) {
oldSelection.setSelected$Z(false);
}m.setSelected$Z(true);
}});

Clazz.newMethod$(C$, 'isSelected$javax_swing_ButtonModel', function (m) {
return (m === this.selection );
});

Clazz.newMethod$(C$, 'getButtonCount', function () {
if (this.buttons == null ) {
return 0;
} else {
return this.buttons.size();
}});
})();
//Created 2017-10-14 13:31:31
