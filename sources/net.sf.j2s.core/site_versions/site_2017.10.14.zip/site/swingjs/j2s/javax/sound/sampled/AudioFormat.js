(function(){var P$=Clazz.newPackage$("javax.sound.sampled"),I$=[];
var C$=Clazz.newClass$(P$, "AudioFormat", function(){
Clazz.newInstance$(this, arguments);
});


Clazz.newMethod$(C$, '$init$', function () {
this.encoding = null;
this.sampleRate = 0;
this.sampleSizeInBits = 0;
this.channels = 0;
this.frameSize = 0;
this.frameRate = 0;
this.bigEndian = false;
this.$properties = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_sound_sampled_AudioFormat_Encoding$F$I$I$I$F$Z', function (encoding, sampleRate, sampleSizeInBits, channels, frameSize, frameRate, bigEndian) {
C$.$init$.apply(this);
this.encoding = encoding;
this.sampleRate = sampleRate;
this.sampleSizeInBits = sampleSizeInBits;
this.channels = channels;
this.frameSize = frameSize;
this.frameRate = frameRate;
this.bigEndian = bigEndian;
this.$properties = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_sound_sampled_AudioFormat_Encoding$F$I$I$I$F$Z$java_util_Map', function (encoding, sampleRate, sampleSizeInBits, channels, frameSize, frameRate, bigEndian, properties) {
C$.c$$javax_sound_sampled_AudioFormat_Encoding$F$I$I$I$F$Z.apply(this, [encoding, sampleRate, sampleSizeInBits, channels, frameSize, frameRate, bigEndian]);
this.$properties = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.HashMap'))).c$$java_util_Map,[properties]);
}, 1);

Clazz.newMethod$(C$, 'c$$F$I$I$Z$Z', function (sampleRate, sampleSizeInBits, channels, signed, bigEndian) {
C$.c$$javax_sound_sampled_AudioFormat_Encoding$F$I$I$I$F$Z.apply(this, [(signed == true  ? (I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.sound.sampled.AudioFormat').Encoding))).PCM_SIGNED : (I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.sound.sampled.AudioFormat').Encoding))).PCM_UNSIGNED), sampleRate, sampleSizeInBits, channels, (channels == -1 || sampleSizeInBits == -1 ) ? -1 : (($i$[0] = (sampleSizeInBits + 7)/8, $i$[0])) * channels, sampleRate, bigEndian]);
}, 1);

Clazz.newMethod$(C$, 'getEncoding', function () {
return this.encoding;
});

Clazz.newMethod$(C$, 'getSampleRate', function () {
return this.sampleRate;
});

Clazz.newMethod$(C$, 'getSampleSizeInBits', function () {
return this.sampleSizeInBits;
});

Clazz.newMethod$(C$, 'getChannels', function () {
return this.channels;
});

Clazz.newMethod$(C$, 'getFrameSize', function () {
return this.frameSize;
});

Clazz.newMethod$(C$, 'getFrameRate', function () {
return this.frameRate;
});

Clazz.newMethod$(C$, 'isBigEndian', function () {
return this.bigEndian;
});

Clazz.newMethod$(C$, 'properties', function () {
var ret;
if (this.$properties == null ) {
ret = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.HashMap'))).c$$I,[0]);
} else {
ret = (this.$properties.clone());
}return (I$[2] || (I$[2]=Clazz.load('java.util.Collections'))).unmodifiableMap$java_util_Map(ret);
});

Clazz.newMethod$(C$, 'getProperty$S', function (key) {
if (this.$properties == null ) {
return null;
}return this.$properties.get$O(key);
});

Clazz.newMethod$(C$, 'matches$javax_sound_sampled_AudioFormat', function (format) {
if (format.getEncoding().equals$O(this.getEncoding()) && ((format.getSampleRate() == -1.0 ) || (format.getSampleRate() == this.getSampleRate() ) ) && (format.getSampleSizeInBits() == this.getSampleSizeInBits()) && (format.getChannels() == this.getChannels() && (format.getFrameSize() == this.getFrameSize())  && ((format.getFrameRate() == -1.0 ) || (format.getFrameRate() == this.getFrameRate() ) )  && ((format.getSampleSizeInBits() <= 8) || (format.isBigEndian() == this.isBigEndian() ) ) )  ) return true;
return false;
});

Clazz.newMethod$(C$, 'toString', function () {
var sEncoding = "";
if (this.getEncoding() != null ) {
sEncoding = this.getEncoding().toString() + " ";
}var sSampleRate;
if (this.getSampleRate() == -1.0 ) {
sSampleRate = "unknown sample rate, ";
} else {
sSampleRate = "" + new Float(this.getSampleRate()).toString() + " Hz, " ;
}var sSampleSizeInBits;
if (this.getSampleSizeInBits() == -1.0 ) {
sSampleSizeInBits = "unknown bits per sample, ";
} else {
sSampleSizeInBits = "" + this.getSampleSizeInBits() + " bit, " ;
}var sChannels;
if (this.getChannels() == 1) {
sChannels = "mono, ";
} else if (this.getChannels() == 2) {
sChannels = "stereo, ";
} else {
if (this.getChannels() == -1) {
sChannels = " unknown number of channels, ";
} else {
sChannels = "" + this.getChannels() + " channels, " ;
}}var sFrameSize;
if (this.getFrameSize() == -1.0 ) {
sFrameSize = "unknown frame size, ";
} else {
sFrameSize = "" + this.getFrameSize() + " bytes/frame, " ;
}var sFrameRate = "";
if (Math.abs(this.getSampleRate() - this.getFrameRate()) > 1.0E-5 ) {
if (this.getFrameRate() == -1.0 ) {
sFrameRate = "unknown frame rate, ";
} else {
sFrameRate = new Float(this.getFrameRate()).toString() + " frames/second, ";
}}var sEndian = "";
if ((this.getEncoding().equals$O((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.sound.sampled.AudioFormat').Encoding))).PCM_SIGNED) || this.getEncoding().equals$O((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.sound.sampled.AudioFormat').Encoding))).PCM_UNSIGNED) ) && ((this.getSampleSizeInBits() > 8) || (this.getSampleSizeInBits() == -1) ) ) {
if (this.isBigEndian()) {
sEndian = "big-endian";
} else {
sEndian = "little-endian";
}}return sEncoding + sSampleRate + sSampleSizeInBits + sChannels + sFrameSize + sFrameRate + sEndian ;
});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.AudioFormat, "Encoding", function(){
Clazz.newInstance$(this, arguments[0], false);
});

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.PCM_SIGNED = Clazz.new(C$.c$$S,["PCM_SIGNED"]);
C$.PCM_UNSIGNED = Clazz.new(C$.c$$S,["PCM_UNSIGNED"]);
C$.ULAW = Clazz.new(C$.c$$S,["ULAW"]);
C$.ALAW = Clazz.new(C$.c$$S,["ALAW"]);
};

C$.PCM_SIGNED = null;
C$.PCM_UNSIGNED = null;
C$.ULAW = null;
C$.ALAW = null;

Clazz.newMethod$(C$, '$init$', function () {
this.name = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (name) {
C$.$init$.apply(this);
this.name = name;
}, 1);

Clazz.newMethod$(C$, 'equals$O', function (obj) {
if (this.toString() == null ) {
return (obj != null ) && (obj.toString() == null ) ;
}if (Clazz.instanceOf(obj, "javax.sound.sampled.AudioFormat.Encoding")) {
return this.toString().equals$O(obj.toString());
}return false;
});

Clazz.newMethod$(C$, 'hashCode', function () {
if (this.toString() == null ) {
return 0;
}return this.toString().hashCode();
});

Clazz.newMethod$(C$, 'toString', function () {
return this.name;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:29
