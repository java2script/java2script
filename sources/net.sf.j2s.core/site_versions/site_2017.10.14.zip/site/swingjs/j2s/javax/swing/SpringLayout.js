(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SpringLayout", function(){
Clazz.newInstance$(this, arguments);
}, null, 'java.awt.LayoutManager2');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.ALL_HORIZONTAL =  Clazz.newArray$(java.lang.String, -1, ["West", "Width", "East", "HorizontalCenter"]);
C$.ALL_VERTICAL =  Clazz.newArray$(java.lang.String, -1, ["North", "Height", "South", "VerticalCenter", "Baseline"]);
};

C$.ALL_HORIZONTAL = null;
C$.ALL_VERTICAL = null;

Clazz.newMethod$(C$, '$init$', function () {
this.componentConstraints = Clazz.new((I$[3] || (I$[3]=Clazz.load('java.util.HashMap'))));
this.cyclicReference = (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(-2147483648);
this.cyclicSprings = null;
this.acyclicSprings = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'resetCyclicStatuses', function () {
this.cyclicSprings = Clazz.new((I$[4] || (I$[4]=Clazz.load('java.util.HashSet'))));
this.acyclicSprings = Clazz.new((I$[4] || (I$[4]=Clazz.load('java.util.HashSet'))));
});

Clazz.newMethod$(C$, 'setParent$java_awt_Container', function (p) {
p$.resetCyclicStatuses.apply(this, []);
var pc = this.getConstraints$java_awt_Component(p);
pc.setX$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(0));
pc.setY$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(0));
var width = pc.getWidth();
if (Clazz.instanceOf(width, "javax.swing.Spring.WidthSpring") && (width).c === p  ) {
pc.setWidth$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I$I$I(0, 0, 2147483647));
}var height = pc.getHeight();
if (Clazz.instanceOf(height, "javax.swing.Spring.HeightSpring") && (height).c === p  ) {
pc.setHeight$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I$I$I(0, 0, 2147483647));
}});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_Spring', function (s) {
if (s == null ) {
return false;
}if (this.cyclicSprings.contains$O(s)) {
return true;
}if (this.acyclicSprings.contains$O(s)) {
return false;
}this.cyclicSprings.add$TE(s);
var result = s.isCyclic$javax_swing_SpringLayout(this);
if (!result) {
this.acyclicSprings.add$TE(s);
this.cyclicSprings.remove$O(s);
} else {
System.err.println$S(s + " is cyclic. ");
}return result;
});

Clazz.newMethod$(C$, 'abandonCycles$javax_swing_Spring', function (s) {
return this.isCyclic$javax_swing_Spring(s) ? this.cyclicReference : s;
});

Clazz.newMethod$(C$, 'addLayoutComponent$S$java_awt_Component', function (name, c) {
});

Clazz.newMethod$(C$, 'removeLayoutComponent$java_awt_Component', function (c) {
this.componentConstraints.remove$O(c);
});

Clazz.newMethod$(C$, 'addInsets$I$I$java_awt_Container', function (width, height, p) {
var i = p.getInsets();
return Clazz.new((I$[5] || (I$[5]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width + i.left + i.right , height + i.top + i.bottom ]);
}, 1);

Clazz.newMethod$(C$, 'minimumLayoutSize$java_awt_Container', function (parent) {
p$.setParent$java_awt_Container.apply(this, [parent]);
var pc = this.getConstraints$java_awt_Component(parent);
return C$.addInsets$I$I$java_awt_Container(p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getWidth()]).getMinimumValue(), p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getHeight()]).getMinimumValue(), parent);
});

Clazz.newMethod$(C$, 'preferredLayoutSize$java_awt_Container', function (parent) {
p$.setParent$java_awt_Container.apply(this, [parent]);
var pc = this.getConstraints$java_awt_Component(parent);
return C$.addInsets$I$I$java_awt_Container(p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getWidth()]).getPreferredValue(), p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getHeight()]).getPreferredValue(), parent);
});

Clazz.newMethod$(C$, 'maximumLayoutSize$java_awt_Container', function (parent) {
p$.setParent$java_awt_Container.apply(this, [parent]);
var pc = this.getConstraints$java_awt_Component(parent);
return C$.addInsets$I$I$java_awt_Container(p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getWidth()]).getMaximumValue(), p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getHeight()]).getMaximumValue(), parent);
});

Clazz.newMethod$(C$, 'addLayoutComponent$java_awt_Component$O', function (component, constraints) {
if (Clazz.instanceOf(constraints, "javax.swing.SpringLayout.Constraints")) {
p$.putConstraints$java_awt_Component$javax_swing_SpringLayout_Constraints.apply(this, [component, constraints]);
}});

Clazz.newMethod$(C$, 'getLayoutAlignmentX$java_awt_Container', function (p) {
return 0.5;
});

Clazz.newMethod$(C$, 'getLayoutAlignmentY$java_awt_Container', function (p) {
return 0.5;
});

Clazz.newMethod$(C$, 'invalidateLayout$java_awt_Container', function (p) {
});

Clazz.newMethod$(C$, 'putConstraint$S$java_awt_Component$I$S$java_awt_Component', function (e1, c1, pad, e2, c2) {
this.putConstraint$S$java_awt_Component$javax_swing_Spring$S$java_awt_Component(e1, c1, (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(pad), e2, c2);
});

Clazz.newMethod$(C$, 'putConstraint$S$java_awt_Component$javax_swing_Spring$S$java_awt_Component', function (e1, c1, s, e2, c2) {
p$.putConstraint$S$java_awt_Component$javax_swing_Spring.apply(this, [e1, c1, (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).sum$javax_swing_Spring$javax_swing_Spring(s, this.getConstraint$S$java_awt_Component(e2, c2))]);
});

Clazz.newMethod$(C$, 'putConstraint$S$java_awt_Component$javax_swing_Spring', function (e, c, s) {
if (s != null ) {
this.getConstraints$java_awt_Component(c).setConstraint$S$javax_swing_Spring(e, s);
}});

Clazz.newMethod$(C$, 'applyDefaults$java_awt_Component$javax_swing_SpringLayout_Constraints', function (c, constraints) {
if (constraints == null ) {
constraints = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.SpringLayout').Constraints))));
}if (constraints.c == null ) {
constraints.c = c;
}if (constraints.horizontalHistory.size() < 2) {
p$.applyDefaults$javax_swing_SpringLayout_Constraints$S$javax_swing_Spring$S$javax_swing_Spring$java_util_List.apply(this, [constraints, "West", (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(0), "Width", (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).width$java_awt_Component(c), constraints.horizontalHistory]);
}if (constraints.verticalHistory.size() < 2) {
p$.applyDefaults$javax_swing_SpringLayout_Constraints$S$javax_swing_Spring$S$javax_swing_Spring$java_util_List.apply(this, [constraints, "North", (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(0), "Height", (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).height$java_awt_Component(c), constraints.verticalHistory]);
}return constraints;
});

Clazz.newMethod$(C$, 'applyDefaults$javax_swing_SpringLayout_Constraints$S$javax_swing_Spring$S$javax_swing_Spring$java_util_List', function (constraints, name1, spring1, name2, spring2, history) {
if (history.size() == 0) {
constraints.setConstraint$S$javax_swing_Spring(name1, spring1);
constraints.setConstraint$S$javax_swing_Spring(name2, spring2);
} else {
if (constraints.getConstraint$S(name2) == null ) {
constraints.setConstraint$S$javax_swing_Spring(name2, spring2);
} else {
constraints.setConstraint$S$javax_swing_Spring(name1, spring1);
}(I$[7] || (I$[7]=Clazz.load('java.util.Collections'))).rotate$java_util_List$I(history, 1);
}});

Clazz.newMethod$(C$, 'putConstraints$java_awt_Component$javax_swing_SpringLayout_Constraints', function (component, constraints) {
this.componentConstraints.put$TK$TV(component, p$.applyDefaults$java_awt_Component$javax_swing_SpringLayout_Constraints.apply(this, [component, constraints]));
});

Clazz.newMethod$(C$, 'getConstraints$java_awt_Component', function (c) {
var result = this.componentConstraints.get$O(c);
if (result == null ) {
if (Clazz.instanceOf(c, "javax.swing.JComponent")) {
var cp = (c).getClientProperty$O(Clazz.getClass(javax.swing.SpringLayout));
if (Clazz.instanceOf(cp, "javax.swing.SpringLayout.Constraints")) {
return p$.applyDefaults$java_awt_Component$javax_swing_SpringLayout_Constraints.apply(this, [c, cp]);
}}result = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.SpringLayout').Constraints))));
p$.putConstraints$java_awt_Component$javax_swing_SpringLayout_Constraints.apply(this, [c, result]);
}return result;
});

Clazz.newMethod$(C$, 'getConstraint$S$java_awt_Component', function (edgeName, c) {
edgeName = edgeName.intern();
return Clazz.new((I$[8] || (I$[8]=Clazz.load(Clazz.load('javax.swing.SpringLayout').SpringProxy))).c$$S$java_awt_Component$javax_swing_SpringLayout,[edgeName, c, this]);
});

Clazz.newMethod$(C$, 'layoutContainer$java_awt_Container', function (parent) {
p$.setParent$java_awt_Container.apply(this, [parent]);
var n = parent.getComponentCount();
this.getConstraints$java_awt_Component(parent).reset();
for (var i = 0; i < n; i++) {
this.getConstraints$java_awt_Component(parent.getComponent$I(i)).reset();
}
var insets = parent.getInsets();
var pc = this.getConstraints$java_awt_Component(parent);
p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getX()]).setValue$I(0);
p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getY()]).setValue$I(0);
p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getWidth()]).setValue$I(parent.getWidth() - insets.left - insets.right );
p$.abandonCycles$javax_swing_Spring.apply(this, [pc.getHeight()]).setValue$I(parent.getHeight() - insets.top - insets.bottom );
for (var i = 0; i < n; i++) {
var c = parent.getComponent$I(i);
var cc = this.getConstraints$java_awt_Component(c);
var x = p$.abandonCycles$javax_swing_Spring.apply(this, [cc.getX()]).getValue();
var y = p$.abandonCycles$javax_swing_Spring.apply(this, [cc.getY()]).getValue();
var width = p$.abandonCycles$javax_swing_Spring.apply(this, [cc.getWidth()]).getValue();
var height = p$.abandonCycles$javax_swing_Spring.apply(this, [cc.getHeight()]).getValue();
c.setBounds$I$I$I$I(insets.left + x, insets.top + y, width, height);
}
});
;
(function(){var C$=Clazz.newClass$(P$.SpringLayout, "Constraints", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.x = null;
this.y = null;
this.width = null;
this.height = null;
this.east = null;
this.south = null;
this.horizontalCenter = null;
this.verticalCenter = null;
this.baseline = null;
this.horizontalHistory = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.util.Lst'))));
this.verticalHistory = Clazz.new((I$[0] || (I$[0]=Clazz.load('javajs.util.Lst'))));
this.c = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$javax_swing_Spring', function (x, y) {
C$.$init$.apply(this);
this.setX$javax_swing_Spring(x);
this.setY$javax_swing_Spring(y);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$javax_swing_Spring$javax_swing_Spring$javax_swing_Spring', function (x, y, width, height) {
C$.$init$.apply(this);
this.setX$javax_swing_Spring(x);
this.setY$javax_swing_Spring(y);
this.setWidth$javax_swing_Spring(width);
this.setHeight$javax_swing_Spring(height);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component', function (c) {
C$.$init$.apply(this);
this.c = c;
this.setX$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(c.getX()));
this.setY$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).constant$I(c.getY()));
this.setWidth$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).width$java_awt_Component(c));
this.setHeight$javax_swing_Spring((I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).height$java_awt_Component(c));
}, 1);

Clazz.newMethod$(C$, 'pushConstraint$S$javax_swing_Spring$Z', function (name, value, horizontal) {
var valid = true;
var history = horizontal ? this.horizontalHistory : this.verticalHistory;
if (history.contains$O(name)) {
history.remove$O(name);
valid = false;
} else if (history.size() == 2 && value != null  ) {
history.removeItemAt$I(0);
valid = false;
}if (value != null ) {
history.addLast$TV(name);
}if (!valid) {
var all = horizontal ? P$.SpringLayout.ALL_HORIZONTAL : P$.SpringLayout.ALL_VERTICAL;
for (var i = 0; i < all.length; i++) {
var s = all[i];
if (!history.contains$O(s)) {
this.setConstraint$S$javax_swing_Spring(s, null);
}}
}});

Clazz.newMethod$(C$, 'sum$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
return (s1 == null  || s2 == null  ) ? null : (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).sum$javax_swing_Spring$javax_swing_Spring(s1, s2);
});

Clazz.newMethod$(C$, 'difference$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
return (s1 == null  || s2 == null  ) ? null : (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).difference$javax_swing_Spring$javax_swing_Spring(s1, s2);
});

Clazz.newMethod$(C$, 'scale$javax_swing_Spring$F', function (s, factor) {
return (s == null ) ? null : (I$[1] || (I$[1]=Clazz.load('javax.swing.Spring'))).scale$javax_swing_Spring$F(s, factor);
});

Clazz.newMethod$(C$, 'getBaselineFromHeight$I', function (height) {
if (height < 0) {
return -this.c.getBaseline$I$I(this.c.getPreferredSize().width, -height);
}return this.c.getBaseline$I$I(this.c.getPreferredSize().width, height);
});

Clazz.newMethod$(C$, 'getHeightFromBaseLine$I', function (baseline) {
var prefSize = this.c.getPreferredSize();
var prefHeight = prefSize.height;
var prefBaseline = this.c.getBaseline$I$I(prefSize.width, prefHeight);
if (prefBaseline == baseline) {
return prefHeight;
}switch (this.c.getBaselineResizeBehavior()) {
case java.awt.Component.BaselineResizeBehavior.CONSTANT_DESCENT:
return prefHeight + (baseline - prefBaseline);
case java.awt.Component.BaselineResizeBehavior.CENTER_OFFSET:
return prefHeight + 2 * (baseline - prefBaseline);
case java.awt.Component.BaselineResizeBehavior.CONSTANT_ASCENT:
default:
}
return -2147483648;
});

Clazz.newMethod$(C$, 'heightToRelativeBaseline$javax_swing_Spring', function (s) {
return ((
(function(){var C$=Clazz.newClass$(P$, "SpringLayout$Constraints$1", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load(Clazz.load('javax.swing.Spring').SpringMap));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'map$I', function (i) {
return this.b$['javax.swing.SpringLayout.Constraints'].getBaselineFromHeight$I.apply(this.b$['javax.swing.SpringLayout.Constraints'], [i]);
});

Clazz.newMethod$(C$, 'inv$I', function (i) {
return this.b$['javax.swing.SpringLayout.Constraints'].getHeightFromBaseLine$I.apply(this.b$['javax.swing.SpringLayout.Constraints'], [i]);
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.Spring').SpringMap))).c$$javax_swing_Spring, [this, null, s],P$.SpringLayout$Constraints$1));
});

Clazz.newMethod$(C$, 'relativeBaselineToHeight$javax_swing_Spring', function (s) {
return ((
(function(){var C$=Clazz.newClass$(P$, "SpringLayout$Constraints$2", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load(Clazz.load('javax.swing.Spring').SpringMap));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'map$I', function (i) {
return this.b$['javax.swing.SpringLayout.Constraints'].getHeightFromBaseLine$I.apply(this.b$['javax.swing.SpringLayout.Constraints'], [i]);
});

Clazz.newMethod$(C$, 'inv$I', function (i) {
return this.b$['javax.swing.SpringLayout.Constraints'].getBaselineFromHeight$I.apply(this.b$['javax.swing.SpringLayout.Constraints'], [i]);
});
})()
), Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.Spring').SpringMap))).c$$javax_swing_Spring, [this, null, s],P$.SpringLayout$Constraints$2));
});

Clazz.newMethod$(C$, 'defined$java_util_List$S$S', function (history, s1, s2) {
return history.contains$O(s1) && history.contains$O(s2) ;
});

Clazz.newMethod$(C$, 'setX$javax_swing_Spring', function (x) {
this.x = x;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["West", x, true]);
});

Clazz.newMethod$(C$, 'getX', function () {
if (this.x == null ) {
if (p$.defined$java_util_List$S$S.apply(this, [this.horizontalHistory, "East", "Width"])) {
this.x = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.east, this.width]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.horizontalHistory, "HorizontalCenter", "Width"])) {
this.x = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.horizontalCenter, p$.scale$javax_swing_Spring$F.apply(this, [this.width, 0.5])]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.horizontalHistory, "HorizontalCenter", "East"])) {
this.x = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [p$.scale$javax_swing_Spring$F.apply(this, [this.horizontalCenter, 2.0]), this.east]);
}}return this.x;
});

Clazz.newMethod$(C$, 'setY$javax_swing_Spring', function (y) {
this.y = y;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["North", y, false]);
});

Clazz.newMethod$(C$, 'getY', function () {
if (this.y == null ) {
if (p$.defined$java_util_List$S$S.apply(this, [this.verticalHistory, "South", "Height"])) {
this.y = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.south, this.height]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.verticalHistory, "VerticalCenter", "Height"])) {
this.y = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.verticalCenter, p$.scale$javax_swing_Spring$F.apply(this, [this.height, 0.5])]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.verticalHistory, "VerticalCenter", "South"])) {
this.y = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [p$.scale$javax_swing_Spring$F.apply(this, [this.verticalCenter, 2.0]), this.south]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.verticalHistory, "Baseline", "Height"])) {
this.y = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.baseline, p$.heightToRelativeBaseline$javax_swing_Spring.apply(this, [this.height])]);
} else if (p$.defined$java_util_List$S$S.apply(this, [this.verticalHistory, "Baseline", "South"])) {
this.y = p$.scale$javax_swing_Spring$F.apply(this, [p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.baseline, p$.heightToRelativeBaseline$javax_swing_Spring.apply(this, [this.south])]), 2.0]);
}}return this.y;
});

Clazz.newMethod$(C$, 'setWidth$javax_swing_Spring', function (width) {
this.width = width;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["Width", width, true]);
});

Clazz.newMethod$(C$, 'getWidth', function () {
if (this.width == null ) {
if (this.horizontalHistory.contains$O("East")) {
this.width = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.east, this.getX()]);
} else if (this.horizontalHistory.contains$O("HorizontalCenter")) {
this.width = p$.scale$javax_swing_Spring$F.apply(this, [p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.horizontalCenter, this.getX()]), 2.0]);
}}return this.width;
});

Clazz.newMethod$(C$, 'setHeight$javax_swing_Spring', function (height) {
this.height = height;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["Height", height, false]);
});

Clazz.newMethod$(C$, 'getHeight', function () {
if (this.height == null ) {
if (this.verticalHistory.contains$O("South")) {
this.height = p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.south, this.getY()]);
} else if (this.verticalHistory.contains$O("VerticalCenter")) {
this.height = p$.scale$javax_swing_Spring$F.apply(this, [p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.verticalCenter, this.getY()]), 2.0]);
} else if (this.verticalHistory.contains$O("Baseline")) {
this.height = p$.relativeBaselineToHeight$javax_swing_Spring.apply(this, [p$.difference$javax_swing_Spring$javax_swing_Spring.apply(this, [this.baseline, this.getY()])]);
}}return this.height;
});

Clazz.newMethod$(C$, 'setEast$javax_swing_Spring', function (east) {
this.east = east;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["East", east, true]);
});

Clazz.newMethod$(C$, 'getEast', function () {
if (this.east == null ) {
this.east = p$.sum$javax_swing_Spring$javax_swing_Spring.apply(this, [this.getX(), this.getWidth()]);
}return this.east;
});

Clazz.newMethod$(C$, 'setSouth$javax_swing_Spring', function (south) {
this.south = south;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["South", south, false]);
});

Clazz.newMethod$(C$, 'getSouth', function () {
if (this.south == null ) {
this.south = p$.sum$javax_swing_Spring$javax_swing_Spring.apply(this, [this.getY(), this.getHeight()]);
}return this.south;
});

Clazz.newMethod$(C$, 'getHorizontalCenter', function () {
if (this.horizontalCenter == null ) {
this.horizontalCenter = p$.sum$javax_swing_Spring$javax_swing_Spring.apply(this, [this.getX(), p$.scale$javax_swing_Spring$F.apply(this, [this.getWidth(), 0.5])]);
}return this.horizontalCenter;
});

Clazz.newMethod$(C$, 'setHorizontalCenter$javax_swing_Spring', function (horizontalCenter) {
this.horizontalCenter = horizontalCenter;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["HorizontalCenter", horizontalCenter, true]);
});

Clazz.newMethod$(C$, 'getVerticalCenter', function () {
if (this.verticalCenter == null ) {
this.verticalCenter = p$.sum$javax_swing_Spring$javax_swing_Spring.apply(this, [this.getY(), p$.scale$javax_swing_Spring$F.apply(this, [this.getHeight(), 0.5])]);
}return this.verticalCenter;
});

Clazz.newMethod$(C$, 'setVerticalCenter$javax_swing_Spring', function (verticalCenter) {
this.verticalCenter = verticalCenter;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["VerticalCenter", verticalCenter, false]);
});

Clazz.newMethod$(C$, 'getBaseline', function () {
if (this.baseline == null ) {
this.baseline = p$.sum$javax_swing_Spring$javax_swing_Spring.apply(this, [this.getY(), p$.heightToRelativeBaseline$javax_swing_Spring.apply(this, [this.getHeight()])]);
}return this.baseline;
});

Clazz.newMethod$(C$, 'setBaseline$javax_swing_Spring', function (baseline) {
this.baseline = baseline;
p$.pushConstraint$S$javax_swing_Spring$Z.apply(this, ["Baseline", baseline, false]);
});

Clazz.newMethod$(C$, 'setConstraint$S$javax_swing_Spring', function (edgeName, s) {
edgeName = edgeName.intern();
if (edgeName == "West") {
this.setX$javax_swing_Spring(s);
} else if (edgeName == "North") {
this.setY$javax_swing_Spring(s);
} else if (edgeName == "East") {
p$.setEast$javax_swing_Spring.apply(this, [s]);
} else if (edgeName == "South") {
p$.setSouth$javax_swing_Spring.apply(this, [s]);
} else if (edgeName == "HorizontalCenter") {
p$.setHorizontalCenter$javax_swing_Spring.apply(this, [s]);
} else if (edgeName == "Width") {
this.setWidth$javax_swing_Spring(s);
} else if (edgeName == "Height") {
this.setHeight$javax_swing_Spring(s);
} else if (edgeName == "VerticalCenter") {
p$.setVerticalCenter$javax_swing_Spring.apply(this, [s]);
} else if (edgeName == "Baseline") {
p$.setBaseline$javax_swing_Spring.apply(this, [s]);
}});

Clazz.newMethod$(C$, 'getConstraint$S', function (edgeName) {
edgeName = edgeName.intern();
return (edgeName == "West") ? this.getX() : (edgeName == "North") ? this.getY() : (edgeName == "East") ? p$.getEast.apply(this, []) : (edgeName == "South") ? p$.getSouth.apply(this, []) : (edgeName == "Width") ? this.getWidth() : (edgeName == "Height") ? this.getHeight() : (edgeName == "HorizontalCenter") ? p$.getHorizontalCenter.apply(this, []) : (edgeName == "VerticalCenter") ? p$.getVerticalCenter.apply(this, []) : (edgeName == "Baseline") ? p$.getBaseline.apply(this, []) : null;
});

Clazz.newMethod$(C$, 'reset', function () {
var allSprings =  Clazz.newArray$(javax.swing.Spring, -1, [this.x, this.y, this.width, this.height, this.east, this.south, this.horizontalCenter, this.verticalCenter, this.baseline]);
for (var i = 0; i < allSprings.length; i++) {
var s = allSprings[i];
if (s != null ) {
s.setValue$I(-2147483648);
}}
});
})()
;
(function(){var C$=Clazz.newClass$(P$.SpringLayout, "SpringProxy", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.edgeName = null;
this.c = null;
this.l = null;
}, 1);

Clazz.newMethod$(C$, 'c$$S$java_awt_Component$javax_swing_SpringLayout', function (edgeName, c, l) {
Clazz.super(C$, this,1);
this.edgeName = edgeName;
this.c = c;
this.l = l;
}, 1);

Clazz.newMethod$(C$, 'getConstraint', function () {
return this.l.getConstraints$java_awt_Component(this.c).getConstraint$S(this.edgeName);
});

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return p$.getConstraint.apply(this, []).getMinimumValue();
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return p$.getConstraint.apply(this, []).getPreferredValue();
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return p$.getConstraint.apply(this, []).getMaximumValue();
});

Clazz.newMethod$(C$, 'getValue', function () {
return p$.getConstraint.apply(this, []).getValue();
});

Clazz.newMethod$(C$, 'setValue$I', function (size) {
p$.getConstraint.apply(this, []).setValue$I(size);
});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return l.isCyclic$javax_swing_Spring(p$.getConstraint.apply(this, []));
});

Clazz.newMethod$(C$, 'toString', function () {
return "SpringProxy for " + this.edgeName + " edge of " + this.c.getName() + "." ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:50
