(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "FlowView", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.text.BoxView');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.layoutSpan = 0;
this.layoutPool = null;
this.strategy = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element$I', function (elem, axis) {
C$.superClazz.c$$javax_swing_text_Element$I.apply(this, [elem, axis]);
C$.$init$.apply(this);
this.layoutSpan = 2147483647;
this.strategy = Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.FlowView').FlowStrategy))));
}, 1);

Clazz.newMethod$(C$, 'getFlowAxis', function () {
if (this.getAxis() == 1) {
return 0;
}return 1;
});

Clazz.newMethod$(C$, 'getFlowSpan$I', function (index) {
return this.layoutSpan;
});

Clazz.newMethod$(C$, 'getFlowStart$I', function (index) {
return 0;
});

Clazz.newMethod$(C$, 'loadChildren$javax_swing_text_ViewFactory', function (f) {
if (this.layoutPool == null ) {
this.layoutPool = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.text.FlowView').LogicalView))).c$$javax_swing_text_Element,[this.getElement()]);
}this.layoutPool.setParent$javax_swing_text_View(this);
this.strategy.insertUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle(this, null, null);
});

Clazz.newMethod$(C$, 'getViewIndexAtPosition$I', function (pos) {
if (pos >= this.getStartOffset() && (pos < this.getEndOffset()) ) {
for (var counter = 0; counter < this.getViewCount(); counter++) {
var v = this.getView$I(counter);
if (pos >= v.getStartOffset() && pos < v.getEndOffset() ) {
return counter;
}}
}return -1;
});

Clazz.newMethod$(C$, 'layout$I$I', function (width, height) {
var faxis = this.getFlowAxis();
var newSpan;
if (faxis == 0) {
newSpan = width;
} else {
newSpan = height;
}if (this.layoutSpan != newSpan) {
this.layoutChanged$I(faxis);
this.layoutChanged$I(this.getAxis());
this.layoutSpan = newSpan;
}if (!this.isLayoutValid$I(faxis)) {
var heightAxis = this.getAxis();
var oldFlowHeight = ((heightAxis == 0) ? this.getWidth() : this.getHeight());
this.strategy.layout$javax_swing_text_FlowView(this);
var newFlowHeight = ($i$[0] = this.getPreferredSpan$I(heightAxis), $i$[0]);
if (oldFlowHeight != newFlowHeight) {
var p = this.getParent();
if (p != null ) {
p.preferenceChanged$javax_swing_text_View$Z$Z(this, (heightAxis == 0), (heightAxis == 1));
}var host = this.getContainer();
if (host != null ) {
host.repaint();
}}}C$.superClazz.prototype.layout$I$I.apply(this, [width, height]);
});

Clazz.newMethod$(C$, 'calculateMinorAxisRequirements$I$javax_swing_SizeRequirements', function (axis, r) {
if (r == null ) {
r = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.SizeRequirements'))));
}var pref = this.layoutPool.getPreferredSpan$I(axis);
var min = this.layoutPool.getMinimumSpan$I(axis);
r.minimum = ($i$[0] = min, $i$[0]);
r.preferred = Math.max(r.minimum, ($i$[0] = pref, $i$[0]));
r.maximum = 2147483647;
r.alignment = 0.5;
return r;
});

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (changes, a, f) {
this.layoutPool.insertUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory(changes, a, f);
this.strategy.insertUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle(this, changes, this.getInsideAllocation$java_awt_Shape(a));
});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (changes, a, f) {
this.layoutPool.removeUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory(changes, a, f);
this.strategy.removeUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle(this, changes, this.getInsideAllocation$java_awt_Shape(a));
});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (changes, a, f) {
this.layoutPool.changedUpdate$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory(changes, a, f);
this.strategy.changedUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle(this, changes, this.getInsideAllocation$java_awt_Shape(a));
});

Clazz.newMethod$(C$, 'setParent$javax_swing_text_View', function (parent) {
C$.superClazz.prototype.setParent$javax_swing_text_View.apply(this, [parent]);
if (parent == null  && this.layoutPool != null  ) {
this.layoutPool.setParent$javax_swing_text_View(null);
}});
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.FlowView, "FlowStrategy", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
this.damageStart = 2147483647;
this.viewBuffer = null;
}, 1);

Clazz.newMethod$(C$, 'addDamage$javax_swing_text_FlowView$I', function (fv, offset) {
if (offset >= fv.getStartOffset() && offset < fv.getEndOffset() ) {
this.damageStart = Math.min(this.damageStart, offset);
}});

Clazz.newMethod$(C$, 'unsetDamage', function () {
this.damageStart = 2147483647;
});

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle', function (fv, e, alloc) {
if (e != null ) {
this.addDamage$javax_swing_text_FlowView$I(fv, e.getOffset());
}if (alloc != null ) {
var host = fv.getContainer();
if (host != null ) {
host.repaint$I$I$I$I(alloc.x, alloc.y, alloc.width, alloc.height);
}} else {
fv.preferenceChanged$javax_swing_text_View$Z$Z(null, true, true);
}});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle', function (fv, e, alloc) {
this.addDamage$javax_swing_text_FlowView$I(fv, e.getOffset());
if (alloc != null ) {
var host = fv.getContainer();
if (host != null ) {
host.repaint$I$I$I$I(alloc.x, alloc.y, alloc.width, alloc.height);
}} else {
fv.preferenceChanged$javax_swing_text_View$Z$Z(null, true, true);
}});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_text_FlowView$javax_swing_event_DocumentEvent$java_awt_Rectangle', function (fv, e, alloc) {
this.addDamage$javax_swing_text_FlowView$I(fv, e.getOffset());
if (alloc != null ) {
var host = fv.getContainer();
if (host != null ) {
host.repaint$I$I$I$I(alloc.x, alloc.y, alloc.width, alloc.height);
}} else {
fv.preferenceChanged$javax_swing_text_View$Z$Z(null, true, true);
}});

Clazz.newMethod$(C$, 'getLogicalView$javax_swing_text_FlowView', function (fv) {
return fv.layoutPool;
});

Clazz.newMethod$(C$, 'layout$javax_swing_text_FlowView', function (fv) {
var pool = this.getLogicalView$javax_swing_text_FlowView(fv);
var rowIndex;
var p0;
var p1 = fv.getEndOffset();
if (fv.majorAllocValid) {
if (this.damageStart == 2147483647) {
return;
}while ((rowIndex = fv.getViewIndexAtPosition$I(this.damageStart)) < 0){
this.damageStart--;
}
if (rowIndex > 0) {
rowIndex--;
}p0 = fv.getView$I(rowIndex).getStartOffset();
} else {
rowIndex = 0;
p0 = fv.getStartOffset();
}this.reparentViews$javax_swing_text_View$I(pool, p0);
this.viewBuffer = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))).c$$I$I,[10, 10]);
var rowCount = fv.getViewCount();
while (p0 < p1){
var row;
if (rowIndex >= rowCount) {
row = fv.createRow();
fv.append$javax_swing_text_View(row);
} else {
row = fv.getView$I(rowIndex);
}p0 = this.layoutRow$javax_swing_text_FlowView$I$I(fv, rowIndex, p0);
rowIndex++;
}
this.viewBuffer = null;
if (rowIndex < rowCount) {
fv.replace$I$I$javax_swing_text_ViewA(rowIndex, rowCount - rowIndex, null);
}this.unsetDamage();
});

Clazz.newMethod$(C$, 'layoutRow$javax_swing_text_FlowView$I$I', function (fv, rowIndex, pos) {
var row = fv.getView$I(rowIndex);
var x = fv.getFlowStart$I(rowIndex);
var spanLeft = fv.getFlowSpan$I(rowIndex);
var end = fv.getEndOffset();
var te = (Clazz.instanceOf(fv, "javax.swing.text.TabExpander")) ? fv : null;
var flowAxis = fv.getFlowAxis();
var breakWeight = 0;
var breakX = 0.0;
var breakSpan = 0.0;
var breakIndex = -1;
var n = 0;
this.viewBuffer.clear();
while (pos < end && spanLeft >= 0  ){
var v = this.createView$javax_swing_text_FlowView$I$I$I(fv, pos, ($i$[0] = spanLeft, $i$[0]), rowIndex);
if (v == null ) {
break;
}var bw = v.getBreakWeight$I$F$F(flowAxis, x, spanLeft);
if (bw >= 3000) {
var w = v.breakView$I$I$F$F(flowAxis, pos, x, spanLeft);
if (w != null ) {
this.viewBuffer.add$TE(w);
} else if (n == 0) {
this.viewBuffer.add$TE(v);
}break;
} else if (bw >= breakWeight && bw > 0 ) {
breakWeight = bw;
breakX = x;
breakSpan = spanLeft;
breakIndex = n;
}var chunkSpan;
if (flowAxis == 0 && Clazz.instanceOf(v, "javax.swing.text.TabableView") ) {
chunkSpan = (v).getTabbedSpan$F$javax_swing_text_TabExpander(x, te);
} else {
chunkSpan = v.getPreferredSpan$I(flowAxis);
}if (chunkSpan > spanLeft  && breakIndex >= 0 ) {
if (breakIndex < n) {
v = this.viewBuffer.get$I(breakIndex);
}for (var i = n - 1; i >= breakIndex; i--) {
this.viewBuffer.remove$I(i);
}
v = v.breakView$I$I$F$F(flowAxis, v.getStartOffset(), breakX, breakSpan);
}spanLeft -= chunkSpan;
x += chunkSpan;
this.viewBuffer.add$TE(v);
pos = v.getEndOffset();
n++;
}
var views =  Clazz.newArray$(javax.swing.text.View, [this.viewBuffer.size()]);
this.viewBuffer.toArray$TTA(views);
row.replace$I$I$javax_swing_text_ViewA(0, row.getViewCount(), views);
return (views.length > 0 ? row.getEndOffset() : pos);
});

Clazz.newMethod$(C$, 'adjustRow$javax_swing_text_FlowView$I$I$I', function (fv, rowIndex, desiredSpan, x) {
var flowAxis = fv.getFlowAxis();
var r = fv.getView$I(rowIndex);
var n = r.getViewCount();
var span = 0;
var bestWeight = 0;
var bestSpan = 0;
var bestIndex = -1;
var v;
for (var i = 0; i < n; i++) {
v = r.getView$I(i);
var spanLeft = desiredSpan - span;
var w = v.getBreakWeight$I$F$F(flowAxis, x + span, spanLeft);
if ((w >= bestWeight) && (w > 0) ) {
bestWeight = w;
bestIndex = i;
bestSpan = span;
if (w >= 3000) {
break;
}}span = ($i$[0] = span+(v.getPreferredSpan$I(flowAxis)), $i$[0]);
}
if (bestIndex < 0) {
return;
}var spanLeft = desiredSpan - bestSpan;
v = r.getView$I(bestIndex);
v = v.breakView$I$I$F$F(flowAxis, v.getStartOffset(), x + bestSpan, spanLeft);
var va =  Clazz.newArray$(javax.swing.text.View, [1]);
va[0] = v;
var lv = this.getLogicalView$javax_swing_text_FlowView(fv);
var p0 = r.getView$I(bestIndex).getStartOffset();
var p1 = r.getEndOffset();
for (var i = 0; i < lv.getViewCount(); i++) {
var tmpView = lv.getView$I(i);
if (tmpView.getEndOffset() > p1) {
break;
}if (tmpView.getStartOffset() >= p0) {
tmpView.setParent$javax_swing_text_View(lv);
}}
r.replace$I$I$javax_swing_text_ViewA(bestIndex, n - bestIndex, va);
});

Clazz.newMethod$(C$, 'reparentViews$javax_swing_text_View$I', function (pool, startPos) {
var n = pool.getViewIndex$I$javax_swing_text_Position_Bias(startPos, (I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward);
if (n >= 0) {
for (var i = n; i < pool.getViewCount(); i++) {
pool.getView$I(i).setParent$javax_swing_text_View(pool);
}
}});

Clazz.newMethod$(C$, 'createView$javax_swing_text_FlowView$I$I$I', function (fv, startOffset, spanLeft, rowIndex) {
var lv = this.getLogicalView$javax_swing_text_FlowView(fv);
var childIndex = lv.getViewIndex$I$javax_swing_text_Position_Bias(startOffset, (I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward);
var v = lv.getView$I(childIndex);
if (startOffset == v.getStartOffset()) {
return v;
}v = v.createFragment$I$I(startOffset, v.getEndOffset());
return v;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.FlowView, "LogicalView", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.CompositeView');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_text_Element', function (elem) {
C$.superClazz.c$$javax_swing_text_Element.apply(this, [elem]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getViewIndexAtPosition$I', function (pos) {
var elem = this.getElement();
if (elem.isLeaf()) {
return 0;
}return C$.superClazz.prototype.getViewIndexAtPosition$I.apply(this, [pos]);
});

Clazz.newMethod$(C$, 'loadChildren$javax_swing_text_ViewFactory', function (f) {
var elem = this.getElement();
if (elem.isLeaf()) {
var v = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.LabelView'))).c$$javax_swing_text_Element,[elem]);
this.append$javax_swing_text_View(v);
} else {
C$.superClazz.prototype.loadChildren$javax_swing_text_ViewFactory.apply(this, [f]);
}});

Clazz.newMethod$(C$, 'getAttributes', function () {
var p = this.getParent();
return (p != null ) ? p.getAttributes() : null;
});

Clazz.newMethod$(C$, 'getPreferredSpan$I', function (axis) {
var maxpref = 0;
var pref = 0;
var n = this.getViewCount();
for (var i = 0; i < n; i++) {
var v = this.getView$I(i);
pref += v.getPreferredSpan$I(axis);
if (v.getBreakWeight$I$F$F(axis, 0, 2147483647) >= 3000) {
maxpref = Math.max(maxpref, pref);
pref = 0;
}}
maxpref = Math.max(maxpref, pref);
return maxpref;
});

Clazz.newMethod$(C$, 'getMinimumSpan$I', function (axis) {
var maxmin = 0;
var min = 0;
var nowrap = false;
var n = this.getViewCount();
for (var i = 0; i < n; i++) {
var v = this.getView$I(i);
if (v.getBreakWeight$I$F$F(axis, 0, 2147483647) == 0) {
min += v.getPreferredSpan$I(axis);
nowrap = true;
} else if (nowrap) {
maxmin = Math.max(min, maxmin);
nowrap = false;
min = 0;
}if (Clazz.instanceOf(v, "javax.swing.text.ComponentView")) {
maxmin = Math.max(maxmin, v.getMinimumSpan$I(axis));
}}
maxmin = Math.max(maxmin, min);
return maxmin;
});

Clazz.newMethod$(C$, 'forwardUpdateToView$javax_swing_text_View$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory', function (v, e, a, f) {
var parent = v.getParent();
v.setParent$javax_swing_text_View(this);
C$.superClazz.prototype.forwardUpdateToView$javax_swing_text_View$javax_swing_event_DocumentEvent$java_awt_Shape$javax_swing_text_ViewFactory.apply(this, [v, e, a, f]);
v.setParent$javax_swing_text_View(parent);
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics$java_awt_Shape', function (g, allocation) {
});

Clazz.newMethod$(C$, 'isBefore$I$I$java_awt_Rectangle', function (x, y, alloc) {
return false;
});

Clazz.newMethod$(C$, 'isAfter$I$I$java_awt_Rectangle', function (x, y, alloc) {
return false;
});

Clazz.newMethod$(C$, 'getViewAtPoint$I$I$java_awt_Rectangle', function (x, y, alloc) {
return null;
});

Clazz.newMethod$(C$, 'childAllocation$I$java_awt_Rectangle', function (index, a) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
