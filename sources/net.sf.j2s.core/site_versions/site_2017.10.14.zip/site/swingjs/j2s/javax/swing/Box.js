(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "Box", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (axis) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.BoxLayout'))).c$$java_awt_Container$I,[this, axis])]);
}, 1);

Clazz.newMethod$(C$, 'createHorizontalBox', function () {
return Clazz.new(C$.c$$I,[0]);
}, 1);

Clazz.newMethod$(C$, 'createVerticalBox', function () {
return Clazz.new(C$.c$$I,[1]);
}, 1);

Clazz.newMethod$(C$, 'createRigidArea$java_awt_Dimension', function (d) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[d, d, d]);
}, 1);

Clazz.newMethod$(C$, 'createHorizontalStrut$I', function (width) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[width, 32767])]);
}, 1);

Clazz.newMethod$(C$, 'createVerticalStrut$I', function (height) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, height]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, height]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[32767, height])]);
}, 1);

Clazz.newMethod$(C$, 'createGlue', function () {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[32767, 32767])]);
}, 1);

Clazz.newMethod$(C$, 'createHorizontalGlue', function () {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[32767, 0])]);
}, 1);

Clazz.newMethod$(C$, 'createVerticalGlue', function () {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Box').Filler))).c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension,[Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 0]), Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[0, 32767])]);
}, 1);

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (l) {
throw Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.AWTError'))).c$$S,["Illegal request"]);
});

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (this.ui != null ) {
C$.superClazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
} else if (this.isOpaque()) {
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(0, 0, this.getWidth(), this.getHeight());
}});
;
(function(){var C$=Clazz.newClass$(P$.Box, "Filler", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JComponent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension', function (min, pref, max) {
Clazz.super(C$, this,1);
this.setMinimumSize$java_awt_Dimension(min);
this.setPreferredSize$java_awt_Dimension(pref);
this.setMaximumSize$java_awt_Dimension(max);
}, 1);

Clazz.newMethod$(C$, 'changeShape$java_awt_Dimension$java_awt_Dimension$java_awt_Dimension', function (min, pref, max) {
this.setMinimumSize$java_awt_Dimension(min);
this.setPreferredSize$java_awt_Dimension(pref);
this.setMaximumSize$java_awt_Dimension(max);
this.revalidate();
});

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (this.ui != null ) {
C$.superClazz.prototype.paintComponent$java_awt_Graphics.apply(this, [g]);
} else if (this.isOpaque()) {
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(0, 0, this.getWidth(), this.getHeight());
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:31
