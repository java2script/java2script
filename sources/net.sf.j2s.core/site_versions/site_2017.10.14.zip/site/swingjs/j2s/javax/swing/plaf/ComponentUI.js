(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "ComponentUI", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'installUI$java_awt_Component', function (component) {
});

Clazz.newMethod$(C$, 'uninstallUI$java_awt_Component', function (c) {
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics$javax_swing_JComponent', function (g, c) {
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics$javax_swing_JComponent', function (g, c) {
});

Clazz.newMethod$(C$, 'getPreferredSize', function () {
return null;
});

Clazz.newMethod$(C$, 'getMinimumSize', function () {
return this.getPreferredSize();
});

Clazz.newMethod$(C$, 'getMaximumSize', function () {
return null;
});

Clazz.newMethod$(C$, 'contains$javax_swing_JComponent$I$I', function (c, x, y) {
return c.inside$I$I(x, y);
});

Clazz.newMethod$(C$, 'createUI$javax_swing_JComponent', function (c) {
throw Clazz.new((I$[0] || (I$[0]=Clazz.load('java.lang.Error'))).c$$S,["ComponentUI.createUI not implemented."]);
}, 1);

Clazz.newMethod$(C$, 'getBaseline$javax_swing_JComponent$I$I', function (c, width, height) {
return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior$javax_swing_JComponent', function (c) {
return (I$[1] || (I$[1]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
});
})();
//Created 2017-10-14 13:31:56
