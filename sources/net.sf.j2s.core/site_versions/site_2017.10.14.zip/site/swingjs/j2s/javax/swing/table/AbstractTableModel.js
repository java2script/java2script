(function(){var P$=Clazz.newPackage$("javax.swing.table"),I$=[];
var C$=Clazz.newClass$(P$, "AbstractTableModel", null, null, 'javax.swing.table.TableModel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
}, 1);

Clazz.newMethod$(C$, 'getColumnName$I', function (column) {
var result = "";
for (; column >= 0; column = ($i$[0] = column/26, $i$[0]) - 1) {
result = String.fromCharCode(((String.fromCharCode((column % 26))).$c() + 65)) + result;
}
return result;
});

Clazz.newMethod$(C$, 'findColumn$S', function (columnName) {
for (var i = 0; i < this.getColumnCount(); i++) {
if (columnName.equals$O(this.getColumnName$I(i))) {
return i;
}}
return -1;
});

Clazz.newMethod$(C$, 'getColumnClass$I', function (columnIndex) {
return Clazz.getClass(java.lang.Object);
});

Clazz.newMethod$(C$, 'isCellEditable$I$I', function (rowIndex, columnIndex) {
return false;
});

Clazz.newMethod$(C$, 'setValueAt$O$I$I', function (aValue, rowIndex, columnIndex) {
});

Clazz.newMethod$(C$, 'addTableModelListener$javax_swing_event_TableModelListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.TableModelListener), l);
});

Clazz.newMethod$(C$, 'removeTableModelListener$javax_swing_event_TableModelListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.TableModelListener), l);
});

Clazz.newMethod$(C$, 'getTableModelListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.TableModelListener));
});

Clazz.newMethod$(C$, 'fireTableDataChanged', function () {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel,[this]));
});

Clazz.newMethod$(C$, 'fireTableStructureChanged', function () {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I,[this, -1]));
});

Clazz.newMethod$(C$, 'fireTableRowsInserted$I$I', function (firstRow, lastRow) {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I$I$I$I,[this, firstRow, lastRow, -1, 1]));
});

Clazz.newMethod$(C$, 'fireTableRowsUpdated$I$I', function (firstRow, lastRow) {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I$I$I$I,[this, firstRow, lastRow, -1, 0]));
});

Clazz.newMethod$(C$, 'fireTableRowsDeleted$I$I', function (firstRow, lastRow) {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I$I$I$I,[this, firstRow, lastRow, -1, -1]));
});

Clazz.newMethod$(C$, 'fireTableCellUpdated$I$I', function (row, column) {
this.fireTableChanged$javax_swing_event_TableModelEvent(Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.TableModelEvent'))).c$$javax_swing_table_TableModel$I$I$I,[this, row, row, column]));
});

Clazz.newMethod$(C$, 'fireTableChanged$javax_swing_event_TableModelEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.TableModelListener) ) {
(listeners[i + 1]).tableChanged$javax_swing_event_TableModelEvent(e);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:59
