(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "Spring", function(){
Clazz.newInstance$(this, arguments);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'range$Z', function (contract) {
return contract ? (this.getPreferredValue() - this.getMinimumValue()) : (this.getMaximumValue() - this.getPreferredValue());
});

Clazz.newMethod$(C$, 'getStrain', function () {
var delta = (this.getValue() - this.getPreferredValue());
return delta / p$.range$Z.apply(this, [this.getValue() < this.getPreferredValue()]);
});

Clazz.newMethod$(C$, 'setStrain$D', function (strain) {
this.setValue$I(this.getPreferredValue() + ($i$[0] = (strain * p$.range$Z.apply(this, [strain < 0 ])), $i$[0]));
});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return false;
});

Clazz.newMethod$(C$, 'constant$I', function (pref) {
return C$.constant$I$I$I(pref, pref, pref);
}, 1);

Clazz.newMethod$(C$, 'constant$I$I$I', function (min, pref, max) {
return Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.Spring').StaticSpring))).c$$I$I$I,[min, pref, max]);
}, 1);

Clazz.newMethod$(C$, 'minus$javax_swing_Spring', function (s) {
return Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.Spring').NegativeSpring))).c$$javax_swing_Spring,[s]);
}, 1);

Clazz.newMethod$(C$, 'sum$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load(Clazz.load('javax.swing.Spring').SumSpring))).c$$javax_swing_Spring$javax_swing_Spring,[s1, s2]);
}, 1);

Clazz.newMethod$(C$, 'max$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.Spring').MaxSpring))).c$$javax_swing_Spring$javax_swing_Spring,[s1, s2]);
}, 1);

Clazz.newMethod$(C$, 'difference$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
return C$.sum$javax_swing_Spring$javax_swing_Spring(s1, C$.minus$javax_swing_Spring(s2));
}, 1);

Clazz.newMethod$(C$, 'scale$javax_swing_Spring$F', function (s, factor) {
C$.checkArg$O(s);
return Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.Spring').ScaleSpring))).c$$javax_swing_Spring$F,[s, factor]);
}, 1);

Clazz.newMethod$(C$, 'width$java_awt_Component', function (c) {
C$.checkArg$O(c);
return Clazz.new((I$[5] || (I$[5]=Clazz.load(Clazz.load('javax.swing.Spring').WidthSpring))).c$$java_awt_Component,[c]);
}, 1);

Clazz.newMethod$(C$, 'height$java_awt_Component', function (c) {
C$.checkArg$O(c);
return Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.Spring').HeightSpring))).c$$java_awt_Component,[c]);
}, 1);

Clazz.newMethod$(C$, 'checkArg$O', function (s) {
if (s == null ) {
throw Clazz.new(Clazz.load('java.lang.NullPointerException').c$$S,["Argument must not be null"]);
}}, 1);
var $i$ = new Int32Array(1);
;
(function(){var C$=Clazz.newClass$(P$.Spring, "AbstractSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.size = -2147483648;
}, 1);

Clazz.newMethod$(C$, 'getValue', function () {
return this.size != -2147483648 ? this.size : this.getPreferredValue();
});

Clazz.newMethod$(C$, 'setValue$I', function (size) {
if (this.size == size) {
return;
}if (size == -2147483648) {
this.clear();
} else {
this.setNonClearValue$I(size);
}});

Clazz.newMethod$(C$, 'clear', function () {
this.size = -2147483648;
});

Clazz.newMethod$(C$, 'setNonClearValue$I', function (size) {
this.size = size;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "StaticSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.AbstractSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.min = 0;
this.pref = 0;
this.$max = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (pref) {
C$.c$$I$I$I.apply(this, [pref, pref, pref]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I', function (min, pref, max) {
Clazz.super(C$, this,1);
this.min = min;
this.pref = pref;
this.$max = max;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "StaticSpring [" + this.min + ", " + this.pref + ", " + this.$max + "]" ;
});

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return this.min;
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return this.pref;
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return this.$max;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "NegativeSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.s = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring', function (s) {
Clazz.super(C$, this,1);
this.s = s;
}, 1);

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return -this.s.getMaximumValue();
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return -this.s.getPreferredValue();
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return -this.s.getMinimumValue();
});

Clazz.newMethod$(C$, 'getValue', function () {
return -this.s.getValue();
});

Clazz.newMethod$(C$, 'setValue$I', function (size) {
this.s.setValue$I(-size);
});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return this.s.isCyclic$javax_swing_SpringLayout(l);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "ScaleSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.s = null;
this.factor = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$F', function (s, factor) {
Clazz.super(C$, this,1);
this.s = s;
this.factor = factor;
}, 1);

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return Math.round((this.factor < 0  ? this.s.getMaximumValue() : this.s.getMinimumValue()) * this.factor);
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return Math.round(this.s.getPreferredValue() * this.factor);
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return Math.round((this.factor < 0  ? this.s.getMinimumValue() : this.s.getMaximumValue()) * this.factor);
});

Clazz.newMethod$(C$, 'getValue', function () {
return Math.round(this.s.getValue() * this.factor);
});

Clazz.newMethod$(C$, 'setValue$I', function (value) {
if (value == -2147483648) {
this.s.setValue$I(-2147483648);
} else {
this.s.setValue$I(Math.round(value / this.factor));
}});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return this.s.isCyclic$javax_swing_SpringLayout(l);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "WidthSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.AbstractSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.c = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component', function (c) {
Clazz.super(C$, this,1);
this.c = c;
}, 1);

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return this.c.getMinimumSize().width;
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return this.c.getPreferredSize().width;
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return Math.min(32767, this.c.getMaximumSize().width);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "HeightSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.AbstractSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.c = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component', function (c) {
Clazz.super(C$, this,1);
this.c = c;
}, 1);

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return this.c.getMinimumSize().height;
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return this.c.getPreferredSize().height;
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return Math.min(32767, this.c.getMaximumSize().height);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "SpringMap", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.s = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring', function (s) {
Clazz.super(C$, this,1);
this.s = s;
}, 1);

Clazz.newMethod$(C$, 'getMinimumValue', function () {
return this.map$I(this.s.getMinimumValue());
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
return this.map$I(this.s.getPreferredValue());
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
return Math.min(32767, this.map$I(this.s.getMaximumValue()));
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.map$I(this.s.getValue());
});

Clazz.newMethod$(C$, 'setValue$I', function (value) {
if (value == -2147483648) {
this.s.setValue$I(-2147483648);
} else {
this.s.setValue$I(this.inv$I(value));
}});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return this.s.isCyclic$javax_swing_SpringLayout(l);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "CompoundSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.StaticSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.s1 = null;
this.s2 = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
C$.superClazz.c$$I.apply(this, [-2147483648]);
C$.$init$.apply(this);
this.s1 = s1;
this.s2 = s2;
}, 1);

Clazz.newMethod$(C$, 'toString', function () {
return "CompoundSpring of " + this.s1 + " and " + this.s2 ;
});

Clazz.newMethod$(C$, 'clear', function () {
C$.superClazz.prototype.clear.apply(this, []);
this.min = this.pref = this.$max = -2147483648;
this.s1.setValue$I(-2147483648);
this.s2.setValue$I(-2147483648);
});

Clazz.newMethod$(C$, 'getMinimumValue', function () {
if (this.min == -2147483648) {
this.min = this.op$I$I(this.s1.getMinimumValue(), this.s2.getMinimumValue());
}return this.min;
});

Clazz.newMethod$(C$, 'getPreferredValue', function () {
if (this.pref == -2147483648) {
this.pref = this.op$I$I(this.s1.getPreferredValue(), this.s2.getPreferredValue());
}return this.pref;
});

Clazz.newMethod$(C$, 'getMaximumValue', function () {
if (this.$max == -2147483648) {
this.$max = this.op$I$I(this.s1.getMaximumValue(), this.s2.getMaximumValue());
}return this.$max;
});

Clazz.newMethod$(C$, 'getValue', function () {
if (this.size == -2147483648) {
this.size = this.op$I$I(this.s1.getValue(), this.s2.getValue());
}return this.size;
});

Clazz.newMethod$(C$, 'isCyclic$javax_swing_SpringLayout', function (l) {
return l.isCyclic$javax_swing_Spring(this.s1) || l.isCyclic$javax_swing_Spring(this.s2) ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "SumSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.CompoundSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
C$.superClazz.c$$javax_swing_Spring$javax_swing_Spring.apply(this, [s1, s2]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'op$I$I', function (x, y) {
return x + y;
});

Clazz.newMethod$(C$, 'setNonClearValue$I', function (size) {
C$.superClazz.prototype.setNonClearValue$I.apply(this, [size]);
this.s1.setStrain$D(this.getStrain());
this.s2.setValue$I(size - this.s1.getValue());
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.Spring, "MaxSpring", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.Spring.CompoundSpring');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_Spring$javax_swing_Spring', function (s1, s2) {
C$.superClazz.c$$javax_swing_Spring$javax_swing_Spring.apply(this, [s1, s2]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'op$I$I', function (x, y) {
return Math.max(x, y);
});

Clazz.newMethod$(C$, 'setNonClearValue$I', function (size) {
C$.superClazz.prototype.setNonClearValue$I.apply(this, [size]);
this.s1.setValue$I(size);
this.s2.setValue$I(size);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:50
