(function(){var P$=Clazz.newPackage$("javax.imageio");
var C$=Clazz.newClass$(P$, "IIOException", null, 'java.io.IOException');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (message) {
C$.superClazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S$Throwable', function (message, cause) {
C$.superClazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
this.initCause$Throwable(cause);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:28
