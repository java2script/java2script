(function(){var P$=Clazz.newPackage$("javax.swing.text");
var C$=Clazz.newClass$(P$, "ChangedCharSetException", null, 'java.io.IOException');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.charSetSpec = null;
this.charSetKey = false;
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (charSetSpec, charSetKey) {
Clazz.super(C$, this,1);
this.charSetSpec = charSetSpec;
this.charSetKey = charSetKey;
}, 1);

Clazz.newMethod$(C$, 'getCharSetSpec', function () {
return this.charSetSpec;
});

Clazz.newMethod$(C$, 'keyEqualsCharSet', function () {
return this.charSetKey;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:00
