(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "LookAndFeel");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'installColors$javax_swing_JComponent$S$S', function (c, defaultBgName, defaultFgName) {
var bg = c.getBackground();
if (bg == null  || Clazz.instanceOf(bg, "javax.swing.plaf.UIResource") ) c.setBackground$java_awt_Color((I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getColor$O(defaultBgName));
var fg = c.getForeground();
if (fg == null  || Clazz.instanceOf(fg, "javax.swing.plaf.UIResource") ) c.setForeground$java_awt_Color((I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getColor$O(defaultFgName));
}, 1);

Clazz.newMethod$(C$, 'installColorsAndFont$javax_swing_JComponent$S$S$S', function (c, defaultBgName, defaultFgName, defaultFontName) {
var f = c.getFont();
if (f == null  || Clazz.instanceOf(f, "javax.swing.plaf.UIResource") ) {
c.setFont$java_awt_Font((I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getFont$O(defaultFontName));
}if (defaultBgName != null ) C$.installColors$javax_swing_JComponent$S$S(c, defaultBgName, defaultFgName);
}, 1);

Clazz.newMethod$(C$, 'installBorder$javax_swing_JComponent$S', function (c, defaultBorderName) {
var b = c.getBorder();
if (b == null  || Clazz.instanceOf(b, "javax.swing.plaf.UIResource") ) {
c.setBorder$javax_swing_border_Border((I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getBorder$O(defaultBorderName));
}}, 1);

Clazz.newMethod$(C$, 'uninstallBorder$javax_swing_JComponent', function (c) {
if (Clazz.instanceOf(c.getBorder(), "javax.swing.plaf.UIResource")) {
c.setBorder$javax_swing_border_Border(null);
}}, 1);

Clazz.newMethod$(C$, 'installProperty$javax_swing_JComponent$S$O', function (c, propertyName, propertyValue) {
if (Clazz.instanceOf(c, "javax.swing.JPasswordField")) {
if (!(c).customSetUIProperty$S$O(propertyName, propertyValue)) {
c.setUIProperty$S$O(propertyName, propertyValue);
}} else {
c.setUIProperty$S$O(propertyName, propertyValue);
}}, 1);

Clazz.newMethod$(C$, 'makeKeyBindings$OA', function (keyBindingList) {
(I$[1] || (I$[1]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
return null;
}, 1);

Clazz.newMethod$(C$, 'makeInputMap$OA', function (keys) {
var retMap = Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.plaf.InputMapUIResource'))));
C$.loadKeyBindings$javax_swing_InputMap$OA(retMap, keys);
return retMap;
}, 1);

Clazz.newMethod$(C$, 'makeComponentInputMap$javax_swing_JComponent$OA', function (c, keys) {
var retMap = Clazz.new((I$[3] || (I$[3]=Clazz.load('javax.swing.plaf.ComponentInputMapUIResource'))).c$$javax_swing_JComponent,[c]);
C$.loadKeyBindings$javax_swing_InputMap$OA(retMap, keys);
return retMap;
}, 1);

Clazz.newMethod$(C$, 'loadKeyBindings$javax_swing_InputMap$OA', function (retMap, keys) {
if (keys != null ) {
for (var counter = 0, maxCounter = keys.length; counter < maxCounter; counter++) {
var keyStrokeO = keys[counter++];
var ks = (Clazz.instanceOf(keyStrokeO, "javax.swing.KeyStroke")) ? keyStrokeO : (I$[4] || (I$[4]=Clazz.load('javax.swing.KeyStroke'))).getKeyStroke$S(keyStrokeO);
retMap.put$javax_swing_KeyStroke$O(ks, keys[counter]);
}
}}, 1);

Clazz.newMethod$(C$, 'makeIcon$Class$S', function (baseClass, gifFile) {
(I$[1] || (I$[1]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
return null;
}, 1);

Clazz.newMethod$(C$, 'getLayoutStyle', function () {
return (I$[5] || (I$[5]=Clazz.load('sun.swing.DefaultLayoutStyle'))).getInstance();
});

Clazz.newMethod$(C$, 'provideErrorFeedback$java_awt_Component', function (component) {
(I$[1] || (I$[1]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
});

Clazz.newMethod$(C$, 'getDesktopPropertyValue$S$O', function (systemPropertyName, fallbackValue) {
(I$[1] || (I$[1]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
return fallbackValue;
}, 1);

Clazz.newMethod$(C$, 'getDisabledIcon$javax_swing_JComponent$javax_swing_Icon', function (component, icon) {
(I$[1] || (I$[1]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
return null;
});

Clazz.newMethod$(C$, 'getDisabledSelectedIcon$javax_swing_JComponent$javax_swing_Icon', function (component, icon) {
return this.getDisabledIcon$javax_swing_JComponent$javax_swing_Icon(component, icon);
});

Clazz.newMethod$(C$, 'getSupportsWindowDecorations', function () {
return false;
});

Clazz.newMethod$(C$, 'initialize', function () {
});

Clazz.newMethod$(C$, 'uninitialize', function () {
});

Clazz.newMethod$(C$, 'getDefaults', function () {
return null;
});

Clazz.newMethod$(C$, 'toString', function () {
return "[" + this.getDescription() + " - " + this.getClass().getName() + "]" ;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:48
