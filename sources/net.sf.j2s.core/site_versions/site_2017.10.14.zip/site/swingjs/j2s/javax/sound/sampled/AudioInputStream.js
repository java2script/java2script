(function(){var P$=Clazz.newPackage$("javax.sound.sampled"),I$=[];
var C$=Clazz.newClass$(P$, "AudioInputStream", null, 'java.io.InputStream');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.stream = null;
this.format = null;
this.frameLength = 0;
this.frameSize = 0;
this.framePos = 0;
this.markpos = 0;
this.pushBackBuffer = null;
this.pushBackLen = 0;
this.markPushBackBuffer = null;
this.markPushBackLen = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$java_io_InputStream$javax_sound_sampled_AudioFormat$J', function (stream, format, length) {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
this.format = format;
this.frameLength = length;
this.frameSize = format.getFrameSize();
if (this.frameSize == -1 || this.frameSize <= 0 ) {
this.frameSize = 1;
}this.stream = stream;
this.framePos = 0;
this.markpos = 0;
}, 1);

Clazz.newMethod$(C$, 'getFormat', function () {
return this.format;
});

Clazz.newMethod$(C$, 'getFrameLength', function () {
return this.frameLength;
});

Clazz.newMethod$(C$, 'readByteAsInt', function () {
if (this.frameSize != 1) {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["cannot read a single byte if frame size > 1"]);
}var data =  Clazz.newArray$(Byte.TYPE, [1]);
var temp = this.read$BA(data);
if (temp <= 0) {
return -1;
}return data[0] & 255;
});

Clazz.newMethod$(C$, 'read$BA', function (b) {
return this.read$BA$I$I(b, 0, b.length);
});

Clazz.newMethod$(C$, 'read$BA$I$I', function (b, off, len) {
if ((len % this.frameSize) != 0) {
len = len-((len % this.frameSize));
if (len == 0) {
return 0;
}}if (this.frameLength != -1) {
if (this.framePos >= this.frameLength) {
return -1;
} else {
if ((($i$[0] = len/this.frameSize, $i$[0])) > (this.frameLength - this.framePos)) {
len = ($i$[0] = (this.frameLength - this.framePos), $i$[0]) * this.frameSize;
}}}var bytesRead = 0;
var thisOff = off;
if (this.pushBackLen > 0 && len >= this.pushBackLen ) {
System.arraycopy(this.pushBackBuffer, 0, b, off, this.pushBackLen);
thisOff = thisOff+(this.pushBackLen);
len = len-(this.pushBackLen);
bytesRead = bytesRead+(this.pushBackLen);
this.pushBackLen = 0;
}var thisBytesRead = this.stream.read$BA$I$I(b, thisOff, len);
if (thisBytesRead == -1) {
return -1;
}if (thisBytesRead > 0) {
bytesRead = bytesRead+(thisBytesRead);
}if (bytesRead > 0) {
this.pushBackLen = bytesRead % this.frameSize;
if (this.pushBackLen > 0) {
if (this.pushBackBuffer == null ) {
this.pushBackBuffer =  Clazz.newArray$(Byte.TYPE, [this.frameSize]);
}System.arraycopy(b, off + bytesRead - this.pushBackLen, this.pushBackBuffer, 0, this.pushBackLen);
bytesRead = bytesRead-(this.pushBackLen);
}this.framePos = this.framePos+(($i$[0] = bytesRead/this.frameSize, $i$[0]));
}return bytesRead;
});

Clazz.newMethod$(C$, 'read', function () {
return this.readByteAsInt();
});

Clazz.newMethod$(C$, 'skip$J', function (n) {
if ((n % this.frameSize) != 0) {
n = n-((n % this.frameSize));
}if (this.frameLength != -1) {
if ((n/this.frameSize|0) > (this.frameLength - this.framePos)) {
n = (this.frameLength - this.framePos) * this.frameSize;
}}var temp = this.stream.skip$J(n);
if (temp % this.frameSize != 0) {
throw Clazz.new(Clazz.load('java.io.IOException').c$$S,["Could not skip an integer number of frames."]);
}if (temp >= 0) {
this.framePos = this.framePos+(temp/this.frameSize|0);
}return temp;
});

Clazz.newMethod$(C$, 'available', function () {
var temp = this.stream.available();
if ((this.frameLength != -1) && ((($i$[0] = temp/this.frameSize, $i$[0])) > (this.frameLength - this.framePos)) ) {
return ($i$[0] = (this.frameLength - this.framePos), $i$[0]) * this.frameSize;
} else {
return temp;
}});

Clazz.newMethod$(C$, 'close', function () {
this.stream.close();
});

Clazz.newMethod$(C$, 'mark$I', function (readlimit) {
this.stream.mark$I(readlimit);
if (this.markSupported()) {
this.markpos = this.framePos;
this.markPushBackLen = this.pushBackLen;
if (this.markPushBackLen > 0) {
if (this.markPushBackBuffer == null ) {
this.markPushBackBuffer =  Clazz.newArray$(Byte.TYPE, [this.frameSize]);
}System.arraycopy(this.pushBackBuffer, 0, this.markPushBackBuffer, 0, this.markPushBackLen);
}}});

Clazz.newMethod$(C$, 'reset', function () {
this.stream.reset();
this.framePos = this.markpos;
this.pushBackLen = this.markPushBackLen;
if (this.pushBackLen > 0) {
if (this.pushBackBuffer == null ) {
this.pushBackBuffer =  Clazz.newArray$(Byte.TYPE, [this.frameSize - 1]);
}System.arraycopy(this.markPushBackBuffer, 0, this.pushBackBuffer, 0, this.pushBackLen);
}});

Clazz.newMethod$(C$, 'markSupported', function () {
return this.stream.markSupported();
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:29
