(function(){var P$=Clazz.newPackage$("javax.swing.border"),I$=[];
var C$=Clazz.newClass$(P$, "EmptyBorder", null, 'javax.swing.border.AbstractBorder');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.left = 0;
this.right = 0;
this.top = 0;
this.bottom = 0;
}, 1);

Clazz.newMethod$(C$, 'c$$I$I$I$I', function (top, left, bottom, right) {
Clazz.super(C$, this,1);
this.top = top;
this.right = right;
this.bottom = bottom;
this.left = left;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Insets', function (borderInsets) {
Clazz.super(C$, this,1);
this.top = borderInsets.top;
this.right = borderInsets.right;
this.bottom = borderInsets.bottom;
this.left = borderInsets.left;
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets();
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
insets.left = this.left;
insets.top = this.top;
insets.right = this.right;
insets.bottom = this.bottom;
return insets;
});

Clazz.newMethod$(C$, 'getBorderInsets', function () {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[this.top, this.left, this.bottom, this.right]);
});

Clazz.newMethod$(C$, 'isBorderOpaque', function () {
return false;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:52
