(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newInterface$(P$, "MenuElement");

})();
//Created 2017-10-14 13:31:48
