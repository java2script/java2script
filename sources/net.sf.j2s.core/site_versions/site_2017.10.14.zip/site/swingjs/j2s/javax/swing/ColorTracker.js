(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ColorTracker", null, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.chooser = null;
this.color = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JColorChooser', function (c) {
C$.$init$.apply(this);
this.chooser = c;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.color = this.chooser.getColor();
});

Clazz.newMethod$(C$, 'getColor', function () {
return this.color;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:35
