(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "AncestorNotifier", null, null, ['java.awt.event.ComponentListener', 'java.beans.PropertyChangeListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.firstInvisibleAncestor = null;
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
this.root = null;
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JComponent', function (root) {
C$.$init$.apply(this);
this.root = root;
this.addListeners$java_awt_Component$Z(root, true);
}, 1);

Clazz.newMethod$(C$, 'addAncestorListener$javax_swing_event_AncestorListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.AncestorListener), l);
});

Clazz.newMethod$(C$, 'removeAncestorListener$javax_swing_event_AncestorListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.AncestorListener), l);
});

Clazz.newMethod$(C$, 'getAncestorListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.AncestorListener));
});

Clazz.newMethod$(C$, 'fireAncestorAdded$javax_swing_JComponent$I$java_awt_Container$java_awt_Container', function (source, id, ancestor, ancestorParent) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.AncestorListener) ) {
var ancestorEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.AncestorEvent'))).c$$javax_swing_JComponent$I$java_awt_Container$java_awt_Container,[source, id, ancestor, ancestorParent]);
(listeners[i + 1]).ancestorAdded$javax_swing_event_AncestorEvent(ancestorEvent);
}}
});

Clazz.newMethod$(C$, 'fireAncestorRemoved$javax_swing_JComponent$I$java_awt_Container$java_awt_Container', function (source, id, ancestor, ancestorParent) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.AncestorListener) ) {
var ancestorEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.AncestorEvent'))).c$$javax_swing_JComponent$I$java_awt_Container$java_awt_Container,[source, id, ancestor, ancestorParent]);
(listeners[i + 1]).ancestorRemoved$javax_swing_event_AncestorEvent(ancestorEvent);
}}
});

Clazz.newMethod$(C$, 'fireAncestorMoved$javax_swing_JComponent$I$java_awt_Container$java_awt_Container', function (source, id, ancestor, ancestorParent) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.AncestorListener) ) {
var ancestorEvent = Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.event.AncestorEvent'))).c$$javax_swing_JComponent$I$java_awt_Container$java_awt_Container,[source, id, ancestor, ancestorParent]);
(listeners[i + 1]).ancestorMoved$javax_swing_event_AncestorEvent(ancestorEvent);
}}
});

Clazz.newMethod$(C$, 'removeAllListeners', function () {
this.removeListeners$java_awt_Component(this.root);
});

Clazz.newMethod$(C$, 'addListeners$java_awt_Component$Z', function (ancestor, addToFirst) {
var a;
this.firstInvisibleAncestor = null;
for (a = ancestor; this.firstInvisibleAncestor == null ; a = a.getParent()) {
if (addToFirst || a !== ancestor  ) {
a.addComponentListener$java_awt_event_ComponentListener(this);
if (Clazz.instanceOf(a, "javax.swing.JComponent")) {
var jAncestor = a;
jAncestor.addPropertyChangeListener$java_beans_PropertyChangeListener(this);
}}if (!a.isVisible() || a.getParent() == null   || Clazz.instanceOf(a, "java.awt.Window") ) {
this.firstInvisibleAncestor = a;
}}
if (Clazz.instanceOf(this.firstInvisibleAncestor, "java.awt.Window") && this.firstInvisibleAncestor.isVisible() ) {
this.firstInvisibleAncestor = null;
}});

Clazz.newMethod$(C$, 'removeListeners$java_awt_Component', function (ancestor) {
var a;
for (a = ancestor; a != null ; a = a.getParent()) {
a.removeComponentListener$java_awt_event_ComponentListener(this);
if (Clazz.instanceOf(a, "javax.swing.JComponent")) {
var jAncestor = a;
jAncestor.removePropertyChangeListener$java_beans_PropertyChangeListener(this);
}if (a === this.firstInvisibleAncestor  || Clazz.instanceOf(a, "java.awt.Window") ) {
break;
}}
});

Clazz.newMethod$(C$, 'componentResized$java_awt_event_ComponentEvent', function (e) {
});

Clazz.newMethod$(C$, 'componentMoved$java_awt_event_ComponentEvent', function (e) {
var source = e.getComponent();
this.fireAncestorMoved$javax_swing_JComponent$I$java_awt_Container$java_awt_Container(this.root, 3, source, source.getParent());
});

Clazz.newMethod$(C$, 'componentShown$java_awt_event_ComponentEvent', function (e) {
var ancestor = e.getComponent();
if (ancestor === this.firstInvisibleAncestor ) {
this.addListeners$java_awt_Component$Z(ancestor, false);
if (this.firstInvisibleAncestor == null ) {
this.fireAncestorAdded$javax_swing_JComponent$I$java_awt_Container$java_awt_Container(this.root, 1, ancestor, ancestor.getParent());
}}});

Clazz.newMethod$(C$, 'componentHidden$java_awt_event_ComponentEvent', function (e) {
var ancestor = e.getComponent();
var needsNotify = this.firstInvisibleAncestor == null ;
if (!(Clazz.instanceOf(ancestor, "java.awt.Window"))) {
this.removeListeners$java_awt_Component(ancestor.getParent());
}this.firstInvisibleAncestor = ancestor;
if (needsNotify) {
this.fireAncestorRemoved$javax_swing_JComponent$I$java_awt_Container$java_awt_Container(this.root, 2, ancestor, ancestor.getParent());
}});

Clazz.newMethod$(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (evt) {
var s = evt.getPropertyName();
if (s != null  && (s.equals$O("parent") || s.equals$O("ancestor") ) ) {
var component = evt.getSource();
if (evt.getNewValue() != null ) {
if (component === this.firstInvisibleAncestor ) {
this.addListeners$java_awt_Component$Z(component, false);
if (this.firstInvisibleAncestor == null ) {
this.fireAncestorAdded$javax_swing_JComponent$I$java_awt_Container$java_awt_Container(this.root, 1, component, component.getParent());
}}} else {
var needsNotify = this.firstInvisibleAncestor == null ;
var oldParent = evt.getOldValue();
this.removeListeners$java_awt_Component(oldParent);
this.firstInvisibleAncestor = component;
if (needsNotify) {
this.fireAncestorRemoved$javax_swing_JComponent$I$java_awt_Container$java_awt_Container(this.root, 2, component, oldParent);
}}}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:31
