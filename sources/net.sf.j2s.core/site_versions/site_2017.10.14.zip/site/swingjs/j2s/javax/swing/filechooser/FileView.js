(function(){var P$=Clazz.newPackage$("javax.swing.filechooser");
var C$=Clazz.newClass$(P$, "FileView");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getName$java_io_File', function (f) {
return f.getName();
});

Clazz.newMethod$(C$, 'getDescription$java_io_File', function (f) {
return null;
});

Clazz.newMethod$(C$, 'getTypeDescription$java_io_File', function (f) {
return null;
});

Clazz.newMethod$(C$, 'getIcon$java_io_File', function (f) {
return null;
});

Clazz.newMethod$(C$, 'isTraversable$java_io_File', function (f) {
return null;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:55
