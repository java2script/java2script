(function(){var P$=Clazz.newPackage$("javax.swing.colorchooser"),I$=[];
var C$=Clazz.newClass$(P$, "ColorChooserComponentFactory");
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getDefaultChooserPanels', function () {
var choosers =  Clazz.newArray$(javax.swing.colorchooser.AbstractColorChooserPanel, -1, [Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.colorchooser.DefaultRGBChooserPanel'))))]);
return choosers;
}, 1);

Clazz.newMethod$(C$, 'getPreviewPanel', function () {
return Clazz.new((I$[1] || (I$[1]=Clazz.load('javax.swing.colorchooser.DefaultPreviewPanel'))));
}, 1);
})();
//Created 2017-10-14 13:31:53
