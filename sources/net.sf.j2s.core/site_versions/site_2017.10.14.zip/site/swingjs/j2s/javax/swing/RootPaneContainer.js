(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newInterface$(P$, "RootPaneContainer");

})();
//Created 2017-10-14 13:31:49
