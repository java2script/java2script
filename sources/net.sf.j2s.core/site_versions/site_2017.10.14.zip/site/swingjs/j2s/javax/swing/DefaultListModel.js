(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultListModel", null, 'javax.swing.AbstractListModel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.delegate = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))));
}, 1);

Clazz.newMethod$(C$, 'getSize', function () {
return this.delegate.size();
});

Clazz.newMethod$(C$, 'getElementAt$I', function (index) {
return this.delegate.elementAt$I(index);
});

Clazz.newMethod$(C$, 'copyInto$OA', function (anArray) {
this.delegate.copyInto$OA(anArray);
});

Clazz.newMethod$(C$, 'trimToSize', function () {
this.delegate.trimToSize();
});

Clazz.newMethod$(C$, 'ensureCapacity$I', function (minCapacity) {
this.delegate.ensureCapacity$I(minCapacity);
});

Clazz.newMethod$(C$, 'setSize$I', function (newSize) {
var oldSize = this.delegate.size();
this.delegate.setSize$I(newSize);
if (oldSize > newSize) {
this.fireIntervalRemoved$O$I$I(this, newSize, oldSize - 1);
} else if (oldSize < newSize) {
this.fireIntervalAdded$O$I$I(this, oldSize, newSize - 1);
}});

Clazz.newMethod$(C$, 'capacity', function () {
return this.delegate.capacity();
});

Clazz.newMethod$(C$, 'size', function () {
return this.delegate.size();
});

Clazz.newMethod$(C$, 'isEmpty', function () {
return this.delegate.isEmpty();
});

Clazz.newMethod$(C$, 'elements', function () {
return this.delegate.elements();
});

Clazz.newMethod$(C$, 'contains$O', function (elem) {
return this.delegate.contains$O(elem);
});

Clazz.newMethod$(C$, 'indexOf$O', function (elem) {
return this.delegate.indexOf$O(elem);
});

Clazz.newMethod$(C$, 'indexOf$O$I', function (elem, index) {
return this.delegate.indexOf$O$I(elem, index);
});

Clazz.newMethod$(C$, 'lastIndexOf$O', function (elem) {
return this.delegate.lastIndexOf$O(elem);
});

Clazz.newMethod$(C$, 'lastIndexOf$O$I', function (elem, index) {
return this.delegate.lastIndexOf$O$I(elem, index);
});

Clazz.newMethod$(C$, 'elementAt$I', function (index) {
return this.delegate.elementAt$I(index);
});

Clazz.newMethod$(C$, 'firstElement', function () {
return this.delegate.firstElement();
});

Clazz.newMethod$(C$, 'lastElement', function () {
return this.delegate.lastElement();
});

Clazz.newMethod$(C$, 'setElementAt$O$I', function (obj, index) {
this.delegate.setElementAt$TE$I(obj, index);
this.fireContentsChanged$O$I$I(this, index, index);
});

Clazz.newMethod$(C$, 'removeElementAt$I', function (index) {
this.delegate.removeElementAt$I(index);
this.fireIntervalRemoved$O$I$I(this, index, index);
});

Clazz.newMethod$(C$, 'insertElementAt$O$I', function (obj, index) {
this.delegate.insertElementAt$TE$I(obj, index);
this.fireIntervalAdded$O$I$I(this, index, index);
});

Clazz.newMethod$(C$, 'addElement$O', function (obj) {
var index = this.delegate.size();
this.delegate.addElement$TE(obj);
this.fireIntervalAdded$O$I$I(this, index, index);
});

Clazz.newMethod$(C$, 'removeElement$O', function (obj) {
var index = this.indexOf$O(obj);
var rv = this.delegate.removeElement$O(obj);
if (index >= 0) {
this.fireIntervalRemoved$O$I$I(this, index, index);
}return rv;
});

Clazz.newMethod$(C$, 'removeAllElements', function () {
var index1 = this.delegate.size() - 1;
this.delegate.removeAllElements();
if (index1 >= 0) {
this.fireIntervalRemoved$O$I$I(this, 0, index1);
}});

Clazz.newMethod$(C$, 'toString', function () {
return this.delegate.toString();
});

Clazz.newMethod$(C$, 'toArray', function () {
var rv =  Clazz.newArray$(java.lang.Object, [this.delegate.size()]);
this.delegate.copyInto$OA(rv);
return rv;
});

Clazz.newMethod$(C$, 'get$I', function (index) {
return this.delegate.elementAt$I(index);
});

Clazz.newMethod$(C$, 'set$I$O', function (index, element) {
var rv = this.delegate.elementAt$I(index);
this.delegate.setElementAt$TE$I(element, index);
this.fireContentsChanged$O$I$I(this, index, index);
return rv;
});

Clazz.newMethod$(C$, 'add$I$O', function (index, element) {
this.delegate.insertElementAt$TE$I(element, index);
this.fireIntervalAdded$O$I$I(this, index, index);
});

Clazz.newMethod$(C$, 'remove$I', function (index) {
var rv = this.delegate.elementAt$I(index);
this.delegate.removeElementAt$I(index);
this.fireIntervalRemoved$O$I$I(this, index, index);
return rv;
});

Clazz.newMethod$(C$, 'clear', function () {
var index1 = this.delegate.size() - 1;
this.delegate.removeAllElements();
if (index1 >= 0) {
this.fireIntervalRemoved$O$I$I(this, 0, index1);
}});

Clazz.newMethod$(C$, 'removeRange$I$I', function (fromIndex, toIndex) {
if (fromIndex > toIndex) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["fromIndex must be <= toIndex"]);
}for (var i = toIndex; i >= fromIndex; i--) {
this.delegate.removeElementAt$I(i);
}
this.fireIntervalRemoved$O$I$I(this, fromIndex, toIndex);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:32
