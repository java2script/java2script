(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultButtonModel", null, null, 'javax.swing.ButtonModel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.stateMask = 0;
this.actionCommand = null;
this.group = null;
this.mnemonic = 0;
this.changeEvent = null;
this.listenerList = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.event.EventListenerList'))));
this.menuItem = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
this.stateMask = 0;
this.setEnabled$Z(true);
}, 1);

Clazz.newMethod$(C$, 'setActionCommand$S', function (actionCommand) {
this.actionCommand = actionCommand;
});

Clazz.newMethod$(C$, 'getActionCommand', function () {
return this.actionCommand;
});

Clazz.newMethod$(C$, 'isArmed', function () {
return (this.stateMask & 1) != 0;
});

Clazz.newMethod$(C$, 'isSelected', function () {
return (this.stateMask & 2) != 0;
});

Clazz.newMethod$(C$, 'isEnabled', function () {
return (this.stateMask & 8) != 0;
});

Clazz.newMethod$(C$, 'isPressed', function () {
return (this.stateMask & 4) != 0;
});

Clazz.newMethod$(C$, 'isRollover', function () {
return (this.stateMask & 16) != 0;
});

Clazz.newMethod$(C$, 'setArmed$Z', function (b) {
if (this.isMenuItem() && (I$[1] || (I$[1]=Clazz.load('javax.swing.UIManager'))).getBoolean$O("MenuItem.disabledAreNavigable") ) {
if ((this.isArmed() == b )) {
return;
}} else {
if ((this.isArmed() == b ) || !this.isEnabled() ) {
return;
}}if (b) {
this.stateMask = this.stateMask|(1);
} else {
this.stateMask = this.stateMask&(-2);
}this.fireStateChanged();
});

Clazz.newMethod$(C$, 'setEnabled$Z', function (b) {
if (this.isEnabled() == b ) {
return;
}if (b) {
this.stateMask = this.stateMask|(8);
} else {
this.stateMask = this.stateMask&(-9);
this.stateMask = this.stateMask&(-2);
this.stateMask = this.stateMask&(-5);
}this.fireStateChanged();
});

Clazz.newMethod$(C$, 'setSelected$Z', function (b) {
if (this.isSelected() == b ) {
return;
}if (b) {
this.stateMask = this.stateMask|(2);
} else {
this.stateMask = this.stateMask&(-3);
}this.fireItemStateChanged$java_awt_event_ItemEvent(Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.event.ItemEvent'))).c$$java_awt_ItemSelectable$I$O$I,[this, 701, this, b ? 1 : 2]));
this.fireStateChanged();
});

Clazz.newMethod$(C$, 'setPressed$Z', function (b) {
if ((this.isPressed() == b ) || !this.isEnabled() ) {
return;
}if (b) {
this.stateMask = this.stateMask|(4);
} else {
this.stateMask = this.stateMask&(-5);
}if (!this.isPressed() && this.isArmed() ) {
var modifiers = 0;
var currentEvent = (I$[3] || (I$[3]=Clazz.load('java.awt.EventQueue'))).getCurrentEvent();
if (Clazz.instanceOf(currentEvent, "java.awt.event.InputEvent")) {
modifiers = (currentEvent).getModifiers();
} else if (Clazz.instanceOf(currentEvent, "java.awt.event.ActionEvent")) {
modifiers = (currentEvent).getModifiers();
}this.fireActionPerformed$java_awt_event_ActionEvent(Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.event.ActionEvent'))).c$$O$I$S$J$I,[this, 1001, this.getActionCommand(), (I$[3] || (I$[3]=Clazz.load('java.awt.EventQueue'))).getMostRecentEventTime(), modifiers]));
}this.fireStateChanged();
});

Clazz.newMethod$(C$, 'setRollover$Z', function (b) {
if ((this.isRollover() == b ) || !this.isEnabled() ) {
return;
}if (b) {
this.stateMask = this.stateMask|(16);
} else {
this.stateMask = this.stateMask&(-17);
}this.fireStateChanged();
});

Clazz.newMethod$(C$, 'setMnemonic$I', function (key) {
this.mnemonic = key;
this.fireStateChanged();
});

Clazz.newMethod$(C$, 'getMnemonic', function () {
return this.mnemonic;
});

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(javax.swing.event.ChangeListener), l);
});

Clazz.newMethod$(C$, 'getChangeListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(javax.swing.event.ChangeListener));
});

Clazz.newMethod$(C$, 'fireStateChanged', function () {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(javax.swing.event.ChangeListener) ) {
if (this.changeEvent == null ) this.changeEvent = Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.event.ChangeEvent'))).c$$O,[this]);
(listeners[i + 1]).stateChanged$javax_swing_event_ChangeEvent(this.changeEvent);
}}
});

Clazz.newMethod$(C$, 'addActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'removeActionListener$java_awt_event_ActionListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ActionListener), l);
});

Clazz.newMethod$(C$, 'getActionListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ActionListener));
});

Clazz.newMethod$(C$, 'fireActionPerformed$java_awt_event_ActionEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ActionListener) ) {
(listeners[i + 1]).actionPerformed$java_awt_event_ActionEvent(e);
}}
});

Clazz.newMethod$(C$, 'addItemListener$java_awt_event_ItemListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.ItemListener), l);
});

Clazz.newMethod$(C$, 'removeItemListener$java_awt_event_ItemListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.ItemListener), l);
});

Clazz.newMethod$(C$, 'getItemListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.ItemListener));
});

Clazz.newMethod$(C$, 'fireItemStateChanged$java_awt_event_ItemEvent', function (e) {
var listeners = this.listenerList.getListenerList();
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.ItemListener) ) {
(listeners[i + 1]).itemStateChanged$java_awt_event_ItemEvent(e);
}}
});

Clazz.newMethod$(C$, 'getListeners$Class', function (listenerType) {
return this.listenerList.getListeners$Class(listenerType);
});

Clazz.newMethod$(C$, 'getSelectedObjects', function () {
return null;
});

Clazz.newMethod$(C$, 'setGroup$javax_swing_ButtonGroup', function (group) {
this.group = group;
});

Clazz.newMethod$(C$, 'getGroup', function () {
return this.group;
});

Clazz.newMethod$(C$, 'isMenuItem', function () {
return this.menuItem;
});

Clazz.newMethod$(C$, 'setMenuItem$Z', function (menuItem) {
this.menuItem = menuItem;
});
})();
//Created 2017-10-14 13:31:32
