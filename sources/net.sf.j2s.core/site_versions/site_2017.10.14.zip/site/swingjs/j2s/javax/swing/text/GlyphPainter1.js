(function(){var P$=Clazz.newPackage$("javax.swing.text"),I$=[];
var C$=Clazz.newClass$(P$, "GlyphPainter1", null, 'javax.swing.text.GlyphView.GlyphPainter');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.metrics = null;
}, 1);

Clazz.newMethod$(C$, 'getSpan$javax_swing_text_GlyphView$I$I$javax_swing_text_TabExpander$F', function (v, p0, p1, e, x) {
this.sync$javax_swing_text_GlyphView(v);
var text = v.getText$I$I(p0, p1);
var justificationData = p$.getJustificationData$javax_swing_text_GlyphView.apply(this, [v]);
var width = (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).getTabbedTextWidth$javax_swing_text_View$javax_swing_text_Segment$java_awt_FontMetrics$I$javax_swing_text_TabExpander$I$IA(v, text, this.metrics, ($i$[0] = x, $i$[0]), e, p0, justificationData);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(text);
return width;
});

Clazz.newMethod$(C$, 'getHeight$javax_swing_text_GlyphView', function (v) {
this.sync$javax_swing_text_GlyphView(v);
return this.metrics.getHeight();
});

Clazz.newMethod$(C$, 'getAscent$javax_swing_text_GlyphView', function (v) {
this.sync$javax_swing_text_GlyphView(v);
return this.metrics.getAscent();
});

Clazz.newMethod$(C$, 'getDescent$javax_swing_text_GlyphView', function (v) {
this.sync$javax_swing_text_GlyphView(v);
return this.metrics.getDescent();
});

Clazz.newMethod$(C$, 'paint$javax_swing_text_GlyphView$java_awt_Graphics$java_awt_Shape$I$I', function (v, g, a, p0, p1) {
});

Clazz.newMethod$(C$, 'modelToView$javax_swing_text_GlyphView$I$javax_swing_text_Position_Bias$java_awt_Shape', function (v, pos, bias, a) {
this.sync$javax_swing_text_GlyphView(v);
var alloc = (Clazz.instanceOf(a, "java.awt.Rectangle")) ? a : a.getBounds();
var p0 = v.getStartOffset();
var p1 = v.getEndOffset();
var expander = v.getTabExpander();
var text;
if (pos == p1) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[alloc.x + alloc.width, alloc.y, 0, this.metrics.getHeight()]);
}if ((pos >= p0) && (pos <= p1) ) {
text = v.getText$I$I(p0, pos);
var justificationData = p$.getJustificationData$javax_swing_text_GlyphView.apply(this, [v]);
var width = (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).getTabbedTextWidth$javax_swing_text_View$javax_swing_text_Segment$java_awt_FontMetrics$I$javax_swing_text_TabExpander$I$IA(v, text, this.metrics, alloc.x, expander, p0, justificationData);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(text);
return Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[alloc.x + width, alloc.y, 0, this.metrics.getHeight()]);
}throw Clazz.new(Clazz.load('javax.swing.text.BadLocationException').c$$S$I,["modelToView - can\'t convert", p1]);
});

Clazz.newMethod$(C$, 'viewToModel$javax_swing_text_GlyphView$F$F$java_awt_Shape$javax_swing_text_Position_BiasA', function (v, x, y, a, biasReturn) {
this.sync$javax_swing_text_GlyphView(v);
var alloc = (Clazz.instanceOf(a, "java.awt.Rectangle")) ? a : a.getBounds();
var p0 = v.getStartOffset();
var p1 = v.getEndOffset();
var expander = v.getTabExpander();
var text = v.getText$I$I(p0, p1);
var justificationData = p$.getJustificationData$javax_swing_text_GlyphView.apply(this, [v]);
var offs = (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).getTabbedTextOffset$javax_swing_text_View$javax_swing_text_Segment$java_awt_FontMetrics$I$I$javax_swing_text_TabExpander$I$IA(v, text, this.metrics, alloc.x, ($i$[0] = x, $i$[0]), expander, p0, justificationData);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(text);
var retValue = p0 + offs;
if (retValue == p1) {
retValue--;
}biasReturn[0] = (I$[3] || (I$[3]=Clazz.load(Clazz.load('javax.swing.text.Position').Bias))).Forward;
return retValue;
});

Clazz.newMethod$(C$, 'getBoundedPosition$javax_swing_text_GlyphView$I$F$F', function (v, p0, x, len) {
this.sync$javax_swing_text_GlyphView(v);
var expander = v.getTabExpander();
var s = v.getText$I$I(p0, v.getEndOffset());
var justificationData = p$.getJustificationData$javax_swing_text_GlyphView.apply(this, [v]);
var index = (I$[0] || (I$[0]=Clazz.load('javax.swing.text.Utilities'))).getTabbedTextOffset$javax_swing_text_View$javax_swing_text_Segment$java_awt_FontMetrics$I$I$javax_swing_text_TabExpander$I$Z$IA(v, s, this.metrics, ($i$[0] = x, $i$[0]), ($i$[0] = (x + len), $i$[0]), expander, p0, false, justificationData);
(I$[1] || (I$[1]=Clazz.load('javax.swing.text.SegmentCache'))).releaseSharedSegment$javax_swing_text_Segment(s);
var p1 = p0 + index;
return p1;
});

Clazz.newMethod$(C$, 'sync$javax_swing_text_GlyphView', function (v) {
var f = v.getFont();
if ((this.metrics == null ) || (!f.equals$O(this.metrics.getFont())) ) {
var c = v.getContainer();
this.metrics = (c != null ) ? c.getFontMetrics$java_awt_Font(f) : (I$[4] || (I$[4]=Clazz.load('java.awt.Toolkit'))).getDefaultToolkit().getFontMetrics$java_awt_Font(f);
}});

Clazz.newMethod$(C$, 'getJustificationData$javax_swing_text_GlyphView', function (v) {
var parent = v.getParent();
var ret = null;
if (Clazz.instanceOf(parent, "javax.swing.text.ParagraphView.Row")) {
var row = (parent);
ret = row.justificationData;
}return ret;
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:32:02
