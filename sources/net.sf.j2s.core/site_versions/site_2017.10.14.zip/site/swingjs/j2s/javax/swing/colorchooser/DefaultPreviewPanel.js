(function(){var P$=Clazz.newPackage$("javax.swing.colorchooser"),I$=[];
var C$=Clazz.newClass$(P$, "DefaultPreviewPanel", null, 'javax.swing.JPanel');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.squareSize = 25;
this.squareGap = 5;
this.innerGap = 5;
this.textGap = 5;
this.sampleText = (I$[0] || (I$[0]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.sampleText");
this.swatchWidth = 50;
this.oldColor = null;
}, 1);

Clazz.newMethod$(C$, 'getColorChooser', function () {
return (I$[1] || (I$[1]=Clazz.load('javax.swing.SwingUtilities'))).getAncestorOfClass$Class$java_awt_Component(Clazz.getClass(javax.swing.JColorChooser), this);
});

Clazz.newMethod$(C$, 'getPreferredSize', function () {
var host = p$.getColorChooser.apply(this, []);
if (host == null ) {
host = this;
}var fm = host.getFontMetrics$java_awt_Font(this.getFont());
var height = fm.getHeight();
var width = fm.stringWidth$S(this.sampleText);
var y = height * 3 + this.textGap * 3;
var x = this.squareSize * 3 + this.squareGap * 2 + this.swatchWidth + width + this.textGap * 3;
return Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Dimension'))).c$$I$I,[x, y]);
});

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (this.oldColor == null ) this.oldColor = this.getForeground();
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(0, 0, this.getWidth(), this.getHeight());
if (this.getComponentOrientation().isLeftToRight()) {
var squareWidth = p$.paintSquares$java_awt_Graphics$I.apply(this, [g, 0]);
var textWidth = p$.paintText$java_awt_Graphics$I.apply(this, [g, squareWidth]);
p$.paintSwatch$java_awt_Graphics$I.apply(this, [g, squareWidth + textWidth]);
} else {
var swatchWidth = p$.paintSwatch$java_awt_Graphics$I.apply(this, [g, 0]);
var textWidth = p$.paintText$java_awt_Graphics$I.apply(this, [g, swatchWidth]);
p$.paintSquares$java_awt_Graphics$I.apply(this, [g, swatchWidth + textWidth]);
}});

Clazz.newMethod$(C$, 'paintSwatch$java_awt_Graphics$I', function (g, offsetX) {
var swatchX = offsetX;
g.setColor$java_awt_Color(this.oldColor);
g.fillRect$I$I$I$I(swatchX, 0, this.swatchWidth, (this.squareSize) + (($i$[0] = this.squareGap/2, $i$[0])));
g.setColor$java_awt_Color(this.getForeground());
g.fillRect$I$I$I$I(swatchX, (this.squareSize) + (($i$[0] = this.squareGap/2, $i$[0])), this.swatchWidth, (this.squareSize) + (($i$[0] = this.squareGap/2, $i$[0])));
return (swatchX + this.swatchWidth);
});

Clazz.newMethod$(C$, 'paintText$java_awt_Graphics$I', function (g, offsetX) {
g.setFont$java_awt_Font(this.getFont());
var fm = this.getFont().getFontMetrics();
var ascent = fm.getAscent();
var height = fm.getHeight();
var width = fm.stringWidth$S(this.sampleText);
var textXOffset = offsetX + this.textGap;
var color = this.getForeground();
g.setColor$java_awt_Color(color);
g.drawString$S$I$I(this.sampleText, textXOffset + (($i$[0] = this.textGap/2, $i$[0])), ascent + 2);
g.fillRect$I$I$I$I(textXOffset, (height) + this.textGap, width + (this.textGap), height + 2);
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).black);
g.drawString$S$I$I(this.sampleText, textXOffset + (($i$[0] = this.textGap/2, $i$[0])), height + ascent + this.textGap + 2 );
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(textXOffset, (height + this.textGap) * 2, width + (this.textGap), height + 2);
g.setColor$java_awt_Color(color);
g.drawString$S$I$I(this.sampleText, textXOffset + (($i$[0] = this.textGap/2, $i$[0])), ((height + this.textGap) * 2) + ascent + 2 );
return width + this.textGap * 3;
});

Clazz.newMethod$(C$, 'paintSquares$java_awt_Graphics$I', function (g, offsetX) {
var squareXOffset = offsetX;
var color = this.getForeground();
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(squareXOffset, 0, this.squareSize, this.squareSize);
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap, this.innerGap, this.squareSize - (this.innerGap * 2), this.squareSize - (this.innerGap * 2));
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap * 2, this.innerGap * 2, this.squareSize - (this.innerGap * 4), this.squareSize - (this.innerGap * 4));
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset, this.squareSize + this.squareGap, this.squareSize, this.squareSize);
g.translate$I$I(this.squareSize + this.squareGap, 0);
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).black);
g.fillRect$I$I$I$I(squareXOffset, 0, this.squareSize, this.squareSize);
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap, this.innerGap, this.squareSize - (this.innerGap * 2), this.squareSize - (this.innerGap * 2));
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap * 2, this.innerGap * 2, this.squareSize - (this.innerGap * 4), this.squareSize - (this.innerGap * 4));
g.translate$I$I(-(this.squareSize + this.squareGap), 0);
g.translate$I$I(this.squareSize + this.squareGap, this.squareSize + this.squareGap);
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(squareXOffset, 0, this.squareSize, this.squareSize);
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap, this.innerGap, this.squareSize - (this.innerGap * 2), this.squareSize - (this.innerGap * 2));
g.translate$I$I(-(this.squareSize + this.squareGap), -(this.squareSize + this.squareGap));
g.translate$I$I((this.squareSize + this.squareGap) * 2, 0);
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).white);
g.fillRect$I$I$I$I(squareXOffset, 0, this.squareSize, this.squareSize);
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap, this.innerGap, this.squareSize - (this.innerGap * 2), this.squareSize - (this.innerGap * 2));
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).black);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap * 2, this.innerGap * 2, this.squareSize - (this.innerGap * 4), this.squareSize - (this.innerGap * 4));
g.translate$I$I(-((this.squareSize + this.squareGap) * 2), 0);
g.translate$I$I((this.squareSize + this.squareGap) * 2, (this.squareSize + this.squareGap));
g.setColor$java_awt_Color((I$[3] || (I$[3]=Clazz.load('java.awt.Color'))).black);
g.fillRect$I$I$I$I(squareXOffset, 0, this.squareSize, this.squareSize);
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(squareXOffset + this.innerGap, this.innerGap, this.squareSize - (this.innerGap * 2), this.squareSize - (this.innerGap * 2));
g.translate$I$I(-((this.squareSize + this.squareGap) * 2), -(this.squareSize + this.squareGap));
return (this.squareSize * 3 + this.squareGap * 2);
});
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:53
