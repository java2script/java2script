(function(){var P$=Clazz.newPackage$("javax.swing.plaf"),I$=[];
var C$=Clazz.newClass$(P$, "FontUIResource", null, 'java.awt.Font', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$S$I$I', function (name, style, size) {
C$.superClazz.c$$S$I$I.apply(this, [name, style, size]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Font', function (font) {
C$.superClazz.c$$java_awt_Font.apply(this, [font]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:56
