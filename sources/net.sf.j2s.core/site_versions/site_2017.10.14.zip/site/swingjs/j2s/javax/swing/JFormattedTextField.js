(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JFormattedTextField", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JTextField');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.$defaultActions =  Clazz.newArray$(javax.swing.Action, -1, [Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.JFormattedTextField').CommitAction)))), Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JFormattedTextField').CancelAction))))]);
};

C$.$defaultActions = null;

Clazz.newMethod$(C$, '$init$', function () {
this.factory = null;
this.format = null;
this.value = null;
this.editValid = false;
this.focusLostBehavior = 0;
this.edited = false;
this.documentListener = null;
this.textFormatterActionMap = null;
this.focusLostHandler = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$javax_swing_text_Document$S$I.apply(this, [null, null, 0]);
C$.$init$.apply(this);
this.uiClassID = "FormattedTextFieldUI";
this.updateUI();
this.enableEvents$J(4);
this.setFocusLostBehavior$I(1);
}, 1);

Clazz.newMethod$(C$, 'c$$O', function (value) {
C$.c$.apply(this, []);
this.setValue$O(value);
}, 1);

Clazz.newMethod$(C$, 'c$$java_text_Format', function (format) {
C$.c$.apply(this, []);
this.setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(p$.getDefaultFormatterFactory$O.apply(this, [format]));
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatter', function (formatter) {
C$.c$$javax_swing_JFormattedTextField_AbstractFormatterFactory.apply(this, [Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[formatter])]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatterFactory', function (factory) {
C$.c$.apply(this, []);
this.setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(factory);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_JFormattedTextField_AbstractFormatterFactory$O', function (factory, currentValue) {
C$.c$$O.apply(this, [currentValue]);
this.setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(factory);
}, 1);

Clazz.newMethod$(C$, 'setFocusLostBehavior$I', function (behavior) {
if (behavior != 0 && behavior != 1  && behavior != 3  && behavior != 2 ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["setFocusLostBehavior must be one of: JFormattedTextField.COMMIT, JFormattedTextField.COMMIT_OR_REVERT, JFormattedTextField.PERSIST or JFormattedTextField.REVERT"]);
}this.focusLostBehavior = behavior;
});

Clazz.newMethod$(C$, 'getFocusLostBehavior', function () {
return this.focusLostBehavior;
});

Clazz.newMethod$(C$, 'setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory', function (tf) {
var oldFactory = this.factory = tf;
this.firePropertyChange$S$O$O("formatterFactory", oldFactory, tf);
p$.setValue$O$Z$Z.apply(this, [this.getValue(), true, false]);
});

Clazz.newMethod$(C$, 'getFormatterFactory', function () {
return this.factory;
});

Clazz.newMethod$(C$, 'setFormatter$javax_swing_JFormattedTextField_AbstractFormatter', function (format) {
var oldFormat = this.format;
if (oldFormat != null ) {
oldFormat.uninstall();
}p$.setEditValid$Z.apply(this, [true]);
this.format = format;
if (format != null ) {
format.install$javax_swing_JFormattedTextField(this);
}p$.setEdited$Z.apply(this, [false]);
this.firePropertyChange$S$O$O("textFormatter", oldFormat, format);
});

Clazz.newMethod$(C$, 'getFormatter', function () {
return this.format;
});

Clazz.newMethod$(C$, 'setValue$O', function (value) {
if (value != null  && this.getFormatterFactory() == null  ) {
this.setFormatterFactory$javax_swing_JFormattedTextField_AbstractFormatterFactory(p$.getDefaultFormatterFactory$O.apply(this, [value]));
}p$.setValue$O$Z$Z.apply(this, [value, true, true]);
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.value;
});

Clazz.newMethod$(C$, 'commitEdit', function () {
var format = this.getFormatter();
if (format != null ) {
p$.setValue$O$Z$Z.apply(this, [format.stringToValue$S(this.getText()), false, true]);
}});

Clazz.newMethod$(C$, 'setEditValid$Z', function (isValid) {
if (isValid != this.editValid ) {
this.editValid = isValid;
this.firePropertyChange$S$O$O("editValid", (I$[3] || (I$[3]=Clazz.load('Boolean'))).$valueOf(!isValid), (I$[3] || (I$[3]=Clazz.load('Boolean'))).$valueOf(isValid));
}});

Clazz.newMethod$(C$, 'isEditValid', function () {
return this.editValid;
});

Clazz.newMethod$(C$, 'invalidEdit', function () {
});

Clazz.newMethod$(C$, 'processInputMethodEvent$java_awt_event_InputMethodEvent', function (e) {
C$.superClazz.prototype.processInputMethodEvent$java_awt_event_InputMethodEvent.apply(this, [e]);
});

Clazz.newMethod$(C$, 'processFocusEvent$java_awt_event_FocusEvent', function (e) {
C$.superClazz.prototype.processFocusEvent$java_awt_event_FocusEvent.apply(this, [e]);
if (e.isTemporary()) {
return;
}if (p$.isEdited.apply(this, []) && e.getID() == 1005 ) {
if (this.focusLostHandler == null ) {
this.focusLostHandler = Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.JFormattedTextField').FocusLostHandler))), [this, null]);
}this.focusLostHandler.run();
} else if (!p$.isEdited.apply(this, [])) {
p$.setValue$O$Z$Z.apply(this, [this.getValue(), true, true]);
}});

Clazz.newMethod$(C$, 'getActions', function () {
return (I$[5] || (I$[5]=Clazz.load('javax.swing.text.TextAction'))).augmentList$javax_swing_ActionA$javax_swing_ActionA(C$.superClazz.prototype.getActions.apply(this, []), C$.$defaultActions);
});

Clazz.newMethod$(C$, 'setDocument$javax_swing_text_Document', function (doc) {
if (this.documentListener != null  && this.getDocument() != null  ) {
this.getDocument().removeDocumentListener$javax_swing_event_DocumentListener(this.documentListener);
}C$.superClazz.prototype.setDocument$javax_swing_text_Document.apply(this, [doc]);
if (this.documentListener == null ) {
this.documentListener = Clazz.new((I$[6] || (I$[6]=Clazz.load(Clazz.load('javax.swing.JFormattedTextField').DocumentHandler))), [this, null]);
}doc.addDocumentListener$javax_swing_event_DocumentListener(this.documentListener);
});

Clazz.newMethod$(C$, 'setFormatterActions$javax_swing_ActionA', function (actions) {
if (actions == null ) {
if (this.textFormatterActionMap != null ) {
this.textFormatterActionMap.clear();
}} else {
if (this.textFormatterActionMap == null ) {
var map = this.getActionMap();
this.textFormatterActionMap = Clazz.new((I$[7] || (I$[7]=Clazz.load('javax.swing.ActionMap'))));
while (map != null ){
var parent = map.getParent();
if (Clazz.instanceOf(parent, "javax.swing.plaf.UIResource") || parent == null  ) {
map.setParent$javax_swing_ActionMap(this.textFormatterActionMap);
this.textFormatterActionMap.setParent$javax_swing_ActionMap(parent);
break;
}map = parent;
}
}for (var counter = actions.length - 1; counter >= 0; counter--) {
var key = actions[counter].getValue$S("Name");
if (key != null ) {
this.textFormatterActionMap.put$O$javax_swing_Action(key, actions[counter]);
}}
}});

Clazz.newMethod$(C$, 'setValue$O$Z$Z', function (value, createFormat, firePC) {
var oldValue = this.value;
this.value = value;
if (createFormat) {
var factory = this.getFormatterFactory();
var atf;
if (factory != null ) {
atf = factory.getFormatter$javax_swing_JFormattedTextField(this);
} else {
atf = null;
}this.setFormatter$javax_swing_JFormattedTextField_AbstractFormatter(atf);
} else {
p$.setEditValid$Z.apply(this, [true]);
}p$.setEdited$Z.apply(this, [false]);
if (firePC) {
this.firePropertyChange$S$O$O("value", oldValue, value);
}});

Clazz.newMethod$(C$, 'setEdited$Z', function (edited) {
this.edited = edited;
});

Clazz.newMethod$(C$, 'isEdited', function () {
return this.edited;
});

Clazz.newMethod$(C$, 'getDefaultFormatterFactory$O', function (type) {
if (Clazz.instanceOf(type, "java.text.DateFormat")) {
(I$[8] || (I$[8]=Clazz.load('swingjs.JSUtil'))).notImplemented$S(null);
return null;
}if (Clazz.instanceOf(type, "java.text.NumberFormat")) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.text.NumberFormatter'))).c$$java_text_NumberFormat,[type])]);
}if (Clazz.instanceOf(type, "java.text.Format")) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[Clazz.new((I$[10] || (I$[10]=Clazz.load('javax.swing.text.InternationalFormatter'))).c$$java_text_Format,[type])]);
}if (Clazz.instanceOf(type, "java.util.Date")) {
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.text.DateFormatter'))))]);
}if (Clazz.instanceOf(type, "java.lang.Number")) {
var displayFormatter = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.text.NumberFormatter'))));
(displayFormatter).setValueClass$Class(type.getClass());
var editFormatter = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.text.NumberFormatter'))).c$$java_text_NumberFormat,[Clazz.new((I$[12] || (I$[12]=Clazz.load('java.text.DecimalFormat'))).c$$S,["#.#"])]);
(editFormatter).setValueClass$Class(type.getClass());
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter$javax_swing_JFormattedTextField_AbstractFormatter,[displayFormatter, displayFormatter, editFormatter]);
}return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.swing.text.DefaultFormatterFactory'))).c$$javax_swing_JFormattedTextField_AbstractFormatter,[Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.text.DefaultFormatter'))))]);
});
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "FocusLostHandler", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'Runnable');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'run', function () {
var fb = this.b$['javax.swing.JFormattedTextField'].getFocusLostBehavior();
if (fb == 0 || fb == 1 ) {
try {
this.b$['javax.swing.JFormattedTextField'].commitEdit();
this.b$['javax.swing.JFormattedTextField'].setValue$O$Z$Z(this.b$['javax.swing.JFormattedTextField'].getValue(), true, true);
} catch (pe) {
if (Clazz.exceptionOf(pe, java.text.ParseException)){
if (fb == 1) {
this.b$['javax.swing.JFormattedTextField'].setValue$O$Z$Z(this.b$['javax.swing.JFormattedTextField'].getValue(), true, true);
}} else {
throw pe;
}
}
} else if (fb == 2) {
this.b$['javax.swing.JFormattedTextField'].setValue$O$Z$Z(this.b$['javax.swing.JFormattedTextField'].getValue(), true, true);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "AbstractFormatterFactory", function(){
Clazz.newInstance$(this, arguments[0], false);
});


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "AbstractFormatter", function(){
Clazz.newInstance$(this, arguments[0], false);
});
var p$=C$.prototype;


Clazz.newMethod$(C$, '$init$', function () {
this.ftf = null;
}, 1);

Clazz.newMethod$(C$, 'install$javax_swing_JFormattedTextField', function (ftf) {
if (this.ftf != null ) {
this.uninstall();
}this.ftf = ftf;
if (ftf != null ) {
try {
ftf.setText$S(this.valueToString$O(ftf.getValue()));
} catch (pe) {
if (Clazz.exceptionOf(pe, java.text.ParseException)){
ftf.setText$S("");
this.setEditValid$Z(false);
} else {
throw pe;
}
}
p$.installDocumentFilter$javax_swing_text_DocumentFilter.apply(this, [this.getDocumentFilter()]);
ftf.setFormatterActions$javax_swing_ActionA(this.getActions());
}});

Clazz.newMethod$(C$, 'uninstall', function () {
if (this.ftf != null ) {
p$.installDocumentFilter$javax_swing_text_DocumentFilter.apply(this, [null]);
this.ftf.setFormatterActions$javax_swing_ActionA(null);
}});

Clazz.newMethod$(C$, 'getFormattedTextField', function () {
return this.ftf;
});

Clazz.newMethod$(C$, 'invalidEdit', function () {
var ftf = this.getFormattedTextField();
if (ftf != null ) {
ftf.invalidEdit();
}});

Clazz.newMethod$(C$, 'setEditValid$Z', function (valid) {
var ftf = this.getFormattedTextField();
if (ftf != null ) {
ftf.setEditValid$Z(valid);
}});

Clazz.newMethod$(C$, 'getActions', function () {
return null;
});

Clazz.newMethod$(C$, 'getDocumentFilter', function () {
return null;
});

Clazz.newMethod$(C$, 'getNavigationFilter', function () {
return null;
});

Clazz.newMethod$(C$, 'clone', function () {
var formatter = Clazz.clone(this);
formatter.ftf = null;
return formatter;
});

Clazz.newMethod$(C$, 'installDocumentFilter$javax_swing_text_DocumentFilter', function (filter) {
var ftf = this.getFormattedTextField();
if (ftf != null ) {
var doc = ftf.getDocument();
if (Clazz.instanceOf(doc, "swingjs.api.JSMinimalAbstractDocument")) {
(doc).setDocumentFilter$javax_swing_text_DocumentFilter(filter);
}doc.putProperty$O$O(Clazz.getClass(javax.swing.text.DocumentFilter), null);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "CommitAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.JTextField.NotifyAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JFormattedTextField")) {
try {
(target).commitEdit();
} catch (pe) {
if (Clazz.exceptionOf(pe, java.text.ParseException)){
(target).invalidEdit();
return;
} else {
throw pe;
}
}
}C$.superClazz.prototype.actionPerformed$java_awt_event_ActionEvent.apply(this, [e]);
});

Clazz.newMethod$(C$, 'isEnabled', function () {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JFormattedTextField")) {
var ftf = target;
if (!ftf.isEdited()) {
return false;
}return true;
}return C$.superClazz.prototype.isEnabled.apply(this, []);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "CancelAction", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'javax.swing.text.TextAction');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$$S.apply(this, ["reset-field-edit"]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JFormattedTextField")) {
var ftf = target;
ftf.setValue$O(ftf.getValue());
}});

Clazz.newMethod$(C$, 'isEnabled', function () {
var target = this.getFocusedComponent();
if (Clazz.instanceOf(target, "javax.swing.JFormattedTextField")) {
var ftf = target;
if (!ftf.isEdited()) {
return false;
}return true;
}return C$.superClazz.prototype.isEnabled.apply(this, []);
});
})()
;
(function(){var C$=Clazz.newClass$(P$.JFormattedTextField, "DocumentHandler", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.DocumentListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'insertUpdate$javax_swing_event_DocumentEvent', function (e) {
this.b$['javax.swing.JFormattedTextField'].setEdited$Z.apply(this.b$['javax.swing.JFormattedTextField'], [true]);
});

Clazz.newMethod$(C$, 'removeUpdate$javax_swing_event_DocumentEvent', function (e) {
this.b$['javax.swing.JFormattedTextField'].setEdited$Z.apply(this.b$['javax.swing.JFormattedTextField'], [true]);
});

Clazz.newMethod$(C$, 'changedUpdate$javax_swing_event_DocumentEvent', function (e) {
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:38
