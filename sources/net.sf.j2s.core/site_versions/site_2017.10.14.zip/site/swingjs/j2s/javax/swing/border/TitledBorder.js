(function(){var P$=Clazz.newPackage$("javax.swing.border"),I$=[];
var C$=Clazz.newClass$(P$, "TitledBorder", null, 'javax.swing.border.AbstractBorder');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.title = null;
this.border = null;
this.titlePosition = 0;
this.titleJustification = 0;
this.titleFont = null;
this.titleColor = null;
this.textLoc = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Point'))));
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (title) {
C$.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [null, title, 4, 0, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border', function (border) {
C$.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [border, "", 4, 0, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S', function (border, title) {
C$.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [border, title, 4, 0, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I', function (border, title, titleJustification, titlePosition) {
C$.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [border, title, titleJustification, titlePosition, null, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I$java_awt_Font', function (border, title, titleJustification, titlePosition, titleFont) {
C$.c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color.apply(this, [border, title, titleJustification, titlePosition, titleFont, null]);
}, 1);

Clazz.newMethod$(C$, 'c$$javax_swing_border_Border$S$I$I$java_awt_Font$java_awt_Color', function (border, title, titleJustification, titlePosition, titleFont, titleColor) {
Clazz.super(C$, this,1);
this.title = title;
this.border = border;
this.titleFont = titleFont;
this.titleColor = titleColor;
this.setTitleJustification$I(titleJustification);
this.setTitlePosition$I(titlePosition);
}, 1);

Clazz.newMethod$(C$, 'paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I', function (c, g, x, y, width, height) {
var border = this.getBorder();
if (this.getTitle() == null  || this.getTitle().equals$O("") ) {
if (border != null ) {
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, x, y, width, height);
}return;
}var grooveRect = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Rectangle'))).c$$I$I$I$I,[x + 2, y + 2, width - 4, height - 4]);
var font = g.getFont();
var color = g.getColor();
g.setFont$java_awt_Font(this.getFont$java_awt_Component(c));
var fm = this.getFont$java_awt_Component(c).getFontMetrics();
var fontHeight = fm.getHeight();
var descent = fm.getDescent();
var ascent = fm.getAscent();
var diff;
var stringWidth = fm.stringWidth$S(this.getTitle());
var insets;
if (border != null ) {
insets = border.getBorderInsets$java_awt_Component(c);
} else {
insets = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
}var titlePos = this.getTitlePosition();
switch (titlePos) {
case 1:
diff = ascent + descent + (Math.max(2, 4) - 2) ;
grooveRect.y = grooveRect.y+(diff);
grooveRect.height = grooveRect.height-(diff);
this.textLoc.y = grooveRect.y - (descent + 2);
break;
case 2:
case 0:
diff = Math.max(0, ((($i$[0] = ascent/2, $i$[0])) + 2) - 2);
grooveRect.y = grooveRect.y+(diff);
grooveRect.height = grooveRect.height-(diff);
this.textLoc.y = (grooveRect.y - descent) + ($i$[0] = (insets.top + ascent + descent )/2, $i$[0]);
break;
case 3:
this.textLoc.y = grooveRect.y + insets.top + ascent + 2 ;
break;
case 4:
this.textLoc.y = (grooveRect.y + grooveRect.height) - (insets.bottom + descent + 2 );
break;
case 5:
grooveRect.height = grooveRect.height-(($i$[0] = fontHeight/2, $i$[0]));
this.textLoc.y = ((grooveRect.y + grooveRect.height) - descent) + ($i$[0] = ((ascent + descent) - insets.bottom)/2, $i$[0]);
break;
case 6:
grooveRect.height = grooveRect.height-(fontHeight);
this.textLoc.y = grooveRect.y + grooveRect.height + ascent + 2 ;
break;
}
var justification = this.getTitleJustification();
if (P$.AbstractBorder.isLeftToRight$java_awt_Component(c)) {
if (justification == 4 || justification == 0 ) {
justification = 1;
} else if (justification == 5) {
justification = 3;
}} else {
if (justification == 4 || justification == 0 ) {
justification = 3;
} else if (justification == 5) {
justification = 1;
}}switch (justification) {
case 1:
this.textLoc.x = grooveRect.x + 5 + insets.left ;
break;
case 3:
this.textLoc.x = (grooveRect.x + grooveRect.width) - (stringWidth + 5 + insets.right );
break;
case 2:
this.textLoc.x = grooveRect.x + (($i$[0] = (grooveRect.width - stringWidth)/2, $i$[0]));
break;
}
if (border != null ) {
if (((titlePos == 2 || titlePos == 0 ) && (grooveRect.y > this.textLoc.y - ascent) ) || (titlePos == 5 && (grooveRect.y + grooveRect.height < this.textLoc.y + descent) ) ) {
var clipRect = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Rectangle'))));
var saveClip = g.getClipBounds();
var cg = g;
var pt = cg.mark();
clipRect.setBounds$java_awt_Rectangle(saveClip);
if (C$.computeIntersection$java_awt_Rectangle$I$I$I$I(clipRect, x, y, this.textLoc.x - 1 - x , height)) {
g.setClip$java_awt_Shape(clipRect);
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, grooveRect.x, grooveRect.y, grooveRect.width, grooveRect.height);
cg.reset$I(pt);
cg.mark();
}clipRect.setBounds$java_awt_Rectangle(saveClip);
if (C$.computeIntersection$java_awt_Rectangle$I$I$I$I(clipRect, this.textLoc.x + stringWidth + 1 , y, x + width - (this.textLoc.x + stringWidth + 1 ), height)) {
g.setClip$java_awt_Shape(clipRect);
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, grooveRect.x, grooveRect.y, grooveRect.width, grooveRect.height);
cg.reset$I(pt);
cg.mark();
}if (titlePos == 2 || titlePos == 0 ) {
clipRect.setBounds$java_awt_Rectangle(saveClip);
if (C$.computeIntersection$java_awt_Rectangle$I$I$I$I(clipRect, this.textLoc.x - 1, this.textLoc.y + descent, stringWidth + 2, y + height - this.textLoc.y - descent)) {
g.setClip$java_awt_Shape(clipRect);
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, grooveRect.x, grooveRect.y, grooveRect.width, grooveRect.height);
cg.reset$I(pt);
cg.mark();
}} else {
clipRect.setBounds$java_awt_Rectangle(saveClip);
if (C$.computeIntersection$java_awt_Rectangle$I$I$I$I(clipRect, this.textLoc.x - 1, y, stringWidth + 2, this.textLoc.y - ascent - y )) {
g.setClip$java_awt_Shape(clipRect);
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, grooveRect.x, grooveRect.y, grooveRect.width, grooveRect.height);
cg.reset$I(pt);
cg.mark();
}}g.setClip$java_awt_Shape(saveClip);
cg.reset$I(pt);
} else {
border.paintBorder$java_awt_Component$java_awt_Graphics$I$I$I$I(c, g, grooveRect.x, grooveRect.y, grooveRect.width, grooveRect.height);
}}g.setColor$java_awt_Color(this.getTitleColor());
g.drawString$S$I$I(this.getTitle(), this.textLoc.x, this.textLoc.y);
g.setFont$java_awt_Font(font);
g.setColor$java_awt_Color(color);
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component', function (c) {
return this.getBorderInsets$java_awt_Component$java_awt_Insets(c, Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]));
});

Clazz.newMethod$(C$, 'getBorderInsets$java_awt_Component$java_awt_Insets', function (c, insets) {
var fm;
var descent = 0;
var ascent = 16;
var height = 16;
var border = this.getBorder();
if (border != null ) {
if (Clazz.instanceOf(border, "javax.swing.border.AbstractBorder")) {
(border).getBorderInsets$java_awt_Component$java_awt_Insets(c, insets);
} else {
var i = border.getBorderInsets$java_awt_Component(c);
insets.top = i.top;
insets.right = i.right;
insets.bottom = i.bottom;
insets.left = i.left;
}} else {
insets.left = insets.top = insets.right = insets.bottom = 0;
}insets.left = insets.left+(4);
insets.right = insets.right+(4);
insets.top = insets.top+(4);
insets.bottom = insets.bottom+(4);
if (c == null  || this.getTitle() == null   || this.getTitle().equals$O("") ) {
return insets;
}var font = this.getFont$java_awt_Component(c);
fm = c.getFontMetrics$java_awt_Font(font);
if (fm != null ) {
descent = fm.getDescent();
ascent = fm.getAscent();
height = fm.getHeight();
}switch (this.getTitlePosition()) {
case 1:
insets.top = insets.top+(ascent + descent + (Math.max(2, 4) - 2) );
break;
case 2:
case 0:
insets.top = insets.top+(ascent + descent);
break;
case 3:
insets.top = insets.top+(ascent + descent + 2 );
break;
case 4:
insets.bottom = insets.bottom+(ascent + descent + 2 );
break;
case 5:
insets.bottom = insets.bottom+(ascent + descent);
break;
case 6:
insets.bottom = insets.bottom+(height);
break;
}
return insets;
});

Clazz.newMethod$(C$, 'isBorderOpaque', function () {
return false;
});

Clazz.newMethod$(C$, 'getTitle', function () {
return this.title;
});

Clazz.newMethod$(C$, 'getBorder', function () {
var b = this.border;
if (b == null ) b = (I$[3] || (I$[3]=Clazz.load('javax.swing.UIManager'))).getBorder$O("TitledBorder.border");
return b;
});

Clazz.newMethod$(C$, 'getTitlePosition', function () {
if (this.titlePosition == 0) {
var value = (I$[3] || (I$[3]=Clazz.load('javax.swing.UIManager'))).get$O("TitledBorder.position");
if (Clazz.instanceOf(value, "java.lang.String")) {
var s = value;
if ("ABOVE_TOP".equalsIgnoreCase$S(s)) {
return 1;
} else if ("TOP".equalsIgnoreCase$S(s)) {
return 2;
} else if ("BELOW_TOP".equalsIgnoreCase$S(s)) {
return 3;
} else if ("ABOVE_BOTTOM".equalsIgnoreCase$S(s)) {
return 4;
} else if ("BOTTOM".equalsIgnoreCase$S(s)) {
return 5;
} else if ("BELOW_BOTTOM".equalsIgnoreCase$S(s)) {
return 6;
}} else if (Clazz.instanceOf(value, "java.lang.Integer")) {
var i = (value).intValue();
if (i >= 0 && i <= 6 ) {
return i;
}}}return this.titlePosition;
});

Clazz.newMethod$(C$, 'getTitleJustification', function () {
return this.titleJustification;
});

Clazz.newMethod$(C$, 'getTitleFont', function () {
var f = this.titleFont;
if (f == null ) f = (I$[3] || (I$[3]=Clazz.load('javax.swing.UIManager'))).getFont$O("TitledBorder.font");
return f;
});

Clazz.newMethod$(C$, 'getTitleColor', function () {
var c = this.titleColor;
if (c == null ) c = (I$[3] || (I$[3]=Clazz.load('javax.swing.UIManager'))).getColor$O("TitledBorder.titleColor");
return c;
});

Clazz.newMethod$(C$, 'setTitle$S', function (title) {
this.title = title;
});

Clazz.newMethod$(C$, 'setBorder$javax_swing_border_Border', function (border) {
this.border = border;
});

Clazz.newMethod$(C$, 'setTitlePosition$I', function (titlePosition) {
switch (titlePosition) {
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 0:
this.titlePosition = titlePosition;
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[titlePosition + " is not a valid title position."]);
}
});

Clazz.newMethod$(C$, 'setTitleJustification$I', function (titleJustification) {
switch (titleJustification) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 5:
this.titleJustification = titleJustification;
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,[titleJustification + " is not a valid title justification."]);
}
});

Clazz.newMethod$(C$, 'setTitleFont$java_awt_Font', function (titleFont) {
this.titleFont = titleFont;
});

Clazz.newMethod$(C$, 'setTitleColor$java_awt_Color', function (titleColor) {
this.titleColor = titleColor;
});

Clazz.newMethod$(C$, 'getMinimumSize$java_awt_Component', function (c) {
var insets = this.getBorderInsets$java_awt_Component(c);
var minSize = Clazz.new((I$[4] || (I$[4]=Clazz.load('java.awt.Dimension'))).c$$I$I,[insets.right + insets.left, insets.top + insets.bottom]);
var font = this.getFont$java_awt_Component(c);
var fm = c.getFontMetrics$java_awt_Font(font);
switch (this.getTitlePosition()) {
case 1:
case 6:
minSize.width = Math.max(fm.stringWidth$S(this.getTitle()), minSize.width);
break;
case 3:
case 4:
case 2:
case 5:
case 0:
default:
minSize.width = minSize.width+(fm.stringWidth$S(this.getTitle()));
}
return minSize;
});

Clazz.newMethod$(C$, 'getBaseline$java_awt_Component$I$I', function (c, width, height) {
if (c == null ) {
throw Clazz.new(Clazz.load('java.lang.NullPointerException').c$$S,["Must supply non-null component"]);
}if (height < 0) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Height must be >= 0"]);
}var title = this.getTitle();
if (title != null  && !"".equals$O(title) ) {
var font = this.getFont$java_awt_Component(c);
var border2 = this.getBorder();
var borderInsets;
if (border2 != null ) {
borderInsets = border2.getBorderInsets$java_awt_Component(c);
} else {
borderInsets = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Insets'))).c$$I$I$I$I,[0, 0, 0, 0]);
}var fm = c.getFontMetrics$java_awt_Font(font);
var fontHeight = fm.getHeight();
var descent = fm.getDescent();
var ascent = fm.getAscent();
var y = 2;
var h = height - 4;
var diff;
switch (this.getTitlePosition()) {
case 1:
diff = ascent + descent + (Math.max(2, 4) - 2) ;
return y + diff - (descent + 2);
case 2:
case 0:
diff = Math.max(0, ((($i$[0] = ascent/2, $i$[0])) + 2) - 2);
return (y + diff - descent) + ($i$[0] = (borderInsets.top + ascent + descent )/2, $i$[0]);
case 3:
return y + borderInsets.top + ascent + 2 ;
case 4:
return (y + h) - (borderInsets.bottom + descent + 2 );
case 5:
h = h-(($i$[0] = fontHeight/2, $i$[0]));
return ((y + h) - descent) + ($i$[0] = ((ascent + descent) - borderInsets.bottom)/2, $i$[0]);
case 6:
h = h-(fontHeight);
return y + h + ascent + 2 ;
}
}return -1;
});

Clazz.newMethod$(C$, 'getBaselineResizeBehavior$java_awt_Component', function (c) {
C$.superClazz.prototype.getBaselineResizeBehavior$java_awt_Component.apply(this, [c]);
switch (this.getTitlePosition()) {
case 1:
case 2:
case 0:
case 3:
return (I$[5] || (I$[5]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_ASCENT;
case 4:
case 5:
case 6:
return (I$[5] || (I$[5]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).CONSTANT_DESCENT;
}
return (I$[5] || (I$[5]=Clazz.load(Clazz.load('java.awt.Component').BaselineResizeBehavior))).OTHER;
});

Clazz.newMethod$(C$, 'getFont$java_awt_Component', function (c) {
var font;
if ((font = this.getTitleFont()) != null ) {
return font;
} else if (c != null  && (font = c.getFont()) != null  ) {
return font;
}return Clazz.new((I$[6] || (I$[6]=Clazz.load('java.awt.Font'))).c$$S$I$I,["Dialog", 0, 12]);
});

Clazz.newMethod$(C$, 'computeIntersection$java_awt_Rectangle$I$I$I$I', function (dest, rx, ry, rw, rh) {
var x1 = Math.max(rx, dest.x);
var x2 = Math.min(rx + rw, dest.x + dest.width);
var y1 = Math.max(ry, dest.y);
var y2 = Math.min(ry + rh, dest.y + dest.height);
dest.x = x1;
dest.y = y1;
dest.width = x2 - x1;
dest.height = y2 - y1;
if (dest.width <= 0 || dest.height <= 0 ) {
return false;
}return true;
}, 1);
var $i$ = new Int32Array(1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:53
