(function(){var P$=Clazz.newPackage$("javax.sound.sampled");
var C$=Clazz.newClass$(P$, "LineUnavailableException", null, 'Exception');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (message) {
C$.superClazz.c$$S.apply(this, [message]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2017-10-14 13:31:29
