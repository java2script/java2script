(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "InputMap");


Clazz.newMethod$(C$, '$init$', function () {
this.arrayTable = null;
this.parent = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'setParent$javax_swing_InputMap', function (map) {
this.parent = map;
});

Clazz.newMethod$(C$, 'getParent', function () {
return this.parent;
});

Clazz.newMethod$(C$, 'put$javax_swing_KeyStroke$O', function (keyStroke, actionMapKey) {
if (keyStroke == null ) {
return;
}if (actionMapKey == null ) {
this.remove$javax_swing_KeyStroke(keyStroke);
} else {
if (this.arrayTable == null ) {
this.arrayTable = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.ArrayTable'))));
}this.arrayTable.put$O$O(keyStroke, actionMapKey);
}});

Clazz.newMethod$(C$, 'get$javax_swing_KeyStroke', function (keyStroke) {
if (this.arrayTable == null ) {
var parent = this.getParent();
if (parent != null ) {
return parent.get$javax_swing_KeyStroke(keyStroke);
}return null;
}var value = this.arrayTable.get$O(keyStroke);
if (value == null ) {
var parent = this.getParent();
if (parent != null ) {
return parent.get$javax_swing_KeyStroke(keyStroke);
}}return value;
});

Clazz.newMethod$(C$, 'remove$javax_swing_KeyStroke', function (key) {
if (this.arrayTable != null ) {
this.arrayTable.remove$O(key);
}});

Clazz.newMethod$(C$, 'clear', function () {
if (this.arrayTable != null ) {
this.arrayTable.clear();
}});

Clazz.newMethod$(C$, 'keys', function () {
if (this.arrayTable == null ) {
return null;
}var keys =  Clazz.newArray$(javax.swing.KeyStroke, [this.arrayTable.size()]);
this.arrayTable.getKeys$OA(keys);
return keys;
});

Clazz.newMethod$(C$, 'size', function () {
if (this.arrayTable == null ) {
return 0;
}return this.arrayTable.size();
});

Clazz.newMethod$(C$, 'allKeys', function () {
var count = this.size();
var parent = this.getParent();
if (count == 0) {
if (parent != null ) {
return parent.allKeys();
}return this.keys();
}if (parent == null ) {
return this.keys();
}var keys = this.keys();
var pKeys = parent.allKeys();
if (pKeys == null ) {
return keys;
}if (keys == null ) {
return pKeys;
}var keyMap = Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.HashMap'))));
var counter;
for (counter = keys.length - 1; counter >= 0; counter--) {
keyMap.put$TK$TV(keys[counter], keys[counter]);
}
for (counter = pKeys.length - 1; counter >= 0; counter--) {
keyMap.put$TK$TV(pKeys[counter], pKeys[counter]);
}
var allKeys =  Clazz.newArray$(javax.swing.KeyStroke, [keyMap.size()]);
return keyMap.keySet().toArray$TTA(allKeys);
});
})();
//Created 2017-10-14 13:31:33
