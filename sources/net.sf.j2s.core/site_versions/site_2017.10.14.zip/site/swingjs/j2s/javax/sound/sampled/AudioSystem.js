(function(){var P$=Clazz.newPackage$("javax.sound.sampled"),I$=[];
var C$=Clazz.newClass$(P$, "AudioSystem");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'getLine$javax_sound_sampled_Line_Info', function (info) {
var line = (I$[0] || (I$[0]=Clazz.load('swingjs.JSToolkit'))).getAudioLine$javax_sound_sampled_Line_Info(info);
if (line != null ) return line;
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["No line matching " + info.toString() + " is supported." ]);
}, 1);

Clazz.newMethod$(C$, 'getAudioInputStream$java_io_ByteArrayInputStream', function (stream) {
return (I$[1] || (I$[1]=Clazz.load('swingjs.JSAudio'))).getAudioInputStream$java_io_ByteArrayInputStream(stream);
}, 1);

Clazz.newMethod$(C$, 'getAudioFileFormat$java_net_URL', function (url) {
var ais = C$.getAudioInputStream$java_net_URL(url);
var format = (ais == null  ? null : ais.getFormat());
if (format == null ) throw Clazz.new(Clazz.load('javax.sound.sampled.UnsupportedAudioFileException').c$$S,["file is not a supported file type"]);
return Clazz.new((I$[2] || (I$[2]=Clazz.load('javax.sound.sampled.AudioFileFormat'))).c$$javax_sound_sampled_AudioFileFormat_Type$javax_sound_sampled_AudioFormat$I,[(I$[2] || (I$[2]=Clazz.load('javax.sound.sampled.AudioFileFormat'))).Type.getType$javax_sound_sampled_AudioFormat(format), format, -1]);
}, 1);

Clazz.newMethod$(C$, 'getAudioInputStream$java_io_InputStream', function (stream) {
if (Clazz.instanceOf(stream, "java.io.ByteArrayInputStream")) return C$.getAudioInputStream$java_io_ByteArrayInputStream(stream);
return C$.getAudioInputStream$java_io_ByteArrayInputStream(Clazz.new((I$[3] || (I$[3]=Clazz.load('java.io.ByteArrayInputStream'))).c$$BA,[(I$[4] || (I$[4]=Clazz.load('javajs.util.Rdr'))).getLimitedStreamBytes$java_io_InputStream$J(stream, -1)]));
}, 1);

Clazz.newMethod$(C$, 'getAudioInputStream$java_net_URL', function (url) {
return C$.getAudioInputStream$java_io_InputStream((I$[5] || (I$[5]=Clazz.load('swingjs.JSUtil'))).getURLInputStream$java_net_URL$Z(url, false));
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:29
