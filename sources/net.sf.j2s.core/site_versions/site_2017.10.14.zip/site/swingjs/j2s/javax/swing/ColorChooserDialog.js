(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "ColorChooserDialog", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JDialog');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.initialColor = null;
this.chooserPane = null;
this.cancelButton = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Dialog$S$Z$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener', function (owner, title, modal, c, chooserPane, okListener, cancelListener) {
C$.superClazz.c$$java_awt_Dialog$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
this.initColorChooserDialog$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener(c, chooserPane, okListener, cancelListener);
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Frame$S$Z$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener', function (owner, title, modal, c, chooserPane, okListener, cancelListener) {
C$.superClazz.c$$java_awt_Frame$S$Z.apply(this, [owner, title, modal]);
C$.$init$.apply(this);
this.initColorChooserDialog$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener(c, chooserPane, okListener, cancelListener);
}, 1);

Clazz.newMethod$(C$, 'initColorChooserDialog$java_awt_Component$javax_swing_JColorChooser$java_awt_event_ActionListener$java_awt_event_ActionListener', function (c, chooserPane, okListener, cancelListener) {
this.chooserPane = chooserPane;
var okString = (I$[7] || (I$[7]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.okText");
var cancelString = (I$[7] || (I$[7]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.cancelText");
var resetString = (I$[7] || (I$[7]=Clazz.load('javax.swing.UIManager'))).getString$O("ColorChooser.resetText");
var contentPane = this.getContentPane();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new((I$[8] || (I$[8]=Clazz.load('java.awt.BorderLayout')))));
contentPane.add$java_awt_Component$O(chooserPane, "Center");
var buttonPane = Clazz.new((I$[9] || (I$[9]=Clazz.load('javax.swing.JPanel'))));
buttonPane.setLayout$java_awt_LayoutManager(Clazz.new((I$[10] || (I$[10]=Clazz.load('java.awt.FlowLayout'))).c$$I,[1]));
var okButton = Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.JButton'))).c$$S,[okString]);
this.getRootPane().setDefaultButton$javax_swing_JButton(okButton);
okButton.setActionCommand$S("OK");
okButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass$(P$, "ColorChooserDialog$1", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['javax.swing.ColorChooserDialog'].hide();
});
})()
), Clazz.new((I$[12] || (I$[12]=Clazz.load(P$.ColorChooserDialog$1))).$init$, [this, null])));
if (okListener != null ) {
okButton.addActionListener$java_awt_event_ActionListener(okListener);
}buttonPane.add$java_awt_Component(okButton);
this.cancelButton = Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.JButton'))).c$$S,[cancelString]);
var cancelKeyAction = ((
(function(){var C$=Clazz.newClass$(P$, "ColorChooserDialog$2", function(){Clazz.newInstance$(this, arguments[0], true);}, Clazz.load('javax.swing.AbstractAction'));

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
(e.getSource()).fireActionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new((I$[13] || (I$[13]=Clazz.load('javax.swing.AbstractAction'))), [this, null],P$.ColorChooserDialog$2));
var cancelKeyStroke = (I$[14] || (I$[14]=Clazz.load('javax.swing.KeyStroke'))).getKeyStroke$I$I(27, 0);
var inputMap = this.cancelButton.getInputMap$I(2);
var actionMap = this.cancelButton.getActionMap();
if (inputMap != null  && actionMap != null  ) {
inputMap.put$javax_swing_KeyStroke$O(cancelKeyStroke, "cancel");
actionMap.put$O$javax_swing_Action("cancel", cancelKeyAction);
}this.cancelButton.setActionCommand$S("cancel");
this.cancelButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass$(P$, "ColorChooserDialog$3", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['javax.swing.ColorChooserDialog'].hide();
});
})()
), Clazz.new((I$[15] || (I$[15]=Clazz.load(P$.ColorChooserDialog$3))).$init$, [this, null])));
if (cancelListener != null ) {
this.cancelButton.addActionListener$java_awt_event_ActionListener(cancelListener);
}buttonPane.add$java_awt_Component(this.cancelButton);
var resetButton = Clazz.new((I$[11] || (I$[11]=Clazz.load('javax.swing.JButton'))).c$$S,[resetString]);
resetButton.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass$(P$, "ColorChooserDialog$4", function(){Clazz.newInstance$(this, arguments[0], true);}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['javax.swing.ColorChooserDialog'].reset();
});
})()
), Clazz.new((I$[16] || (I$[16]=Clazz.load(P$.ColorChooserDialog$4))).$init$, [this, null])));
var mnemonic = (I$[17] || (I$[17]=Clazz.load('sun.swing.SwingUtilities2'))).getUIDefaultsInt$O$I("ColorChooser.resetMnemonic", -1);
if (mnemonic != -1) {
resetButton.setMnemonic$I(mnemonic);
}buttonPane.add$java_awt_Component(resetButton);
contentPane.add$java_awt_Component$O(buttonPane, "South");
if ((I$[18] || (I$[18]=Clazz.load('javax.swing.JDialog'))).isDefaultLookAndFeelDecorated()) {
var supportsWindowDecorations = (I$[7] || (I$[7]=Clazz.load('javax.swing.UIManager'))).getLookAndFeel().getSupportsWindowDecorations();
if (supportsWindowDecorations) {
this.getRootPane().setWindowDecorationStyle$I(5);
}}this.applyComponentOrientation$java_awt_ComponentOrientation(((c == null ) ? this.getRootPane() : c).getComponentOrientation());
this.pack();
this.setLocationRelativeTo$java_awt_Component(c);
this.addWindowListener$java_awt_event_WindowListener(Clazz.new((I$[19] || (I$[19]=Clazz.load(Clazz.load('javax.swing.ColorChooserDialog').Closer))), [this, null]));
});

Clazz.newMethod$(C$, 'show', function () {
this.initialColor = this.chooserPane.getColor();
C$.superClazz.prototype.show.apply(this, []);
});

Clazz.newMethod$(C$, 'reset', function () {
this.chooserPane.setColor$java_awt_Color(this.initialColor);
});
;
(function(){var C$=Clazz.newClass$(P$.ColorChooserDialog, "Closer", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['javax.swing.ColorChooserDialog'].cancelButton.doClick$I(0);
var w = e.getWindow();
w.hide();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
;
(function(){var C$=Clazz.newClass$(P$.ColorChooserDialog, "DisposeOnClose", function(){
Clazz.newInstance$(this, arguments[0], false);
}, 'java.awt.event.ComponentAdapter');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'componentHidden$java_awt_event_ComponentEvent', function (e) {
var w = e.getComponent();
w.dispose();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:35
