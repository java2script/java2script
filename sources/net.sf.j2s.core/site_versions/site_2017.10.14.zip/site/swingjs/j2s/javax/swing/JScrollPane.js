(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JScrollPane", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'javax.swing.ScrollPaneConstants');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.viewportBorder = null;
this.verticalScrollBarPolicy = 20;
this.horizontalScrollBarPolicy = 30;
this.viewport = null;
this.verticalScrollBar = null;
this.horizontalScrollBar = null;
this.rowHeader = null;
this.columnHeader = null;
this.lowerLeft = null;
this.lowerRight = null;
this.upperLeft = null;
this.upperRight = null;
this.wheelScrollState = true;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$I$I', function (view, vsbPolicy, hsbPolicy) {
Clazz.super(C$, this,1);
this.setLayout$java_awt_LayoutManager(Clazz.new((I$[0] || (I$[0]=Clazz.load(Clazz.load('javax.swing.ScrollPaneLayout').UIResource)))));
this.setVerticalScrollBarPolicy$I(vsbPolicy);
this.setHorizontalScrollBarPolicy$I(hsbPolicy);
this.setViewport$javax_swing_JViewport(this.createViewport());
this.setVerticalScrollBar$javax_swing_JScrollBar(this.createVerticalScrollBar());
this.setHorizontalScrollBar$javax_swing_JScrollBar(this.createHorizontalScrollBar());
if (view != null ) {
this.setViewportView$java_awt_Component(view);
}this.setUIProperty$S$O("opaque", new Boolean(true));
this.uiClassID = "ScrollPaneUI";
this.updateUI();
if (!this.getComponentOrientation().isLeftToRight()) {
this.viewport.setViewPosition$java_awt_Point(Clazz.new((I$[1] || (I$[1]=Clazz.load('java.awt.Point'))).c$$I$I,[2147483647, 0]));
}}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component', function (view) {
C$.c$$java_awt_Component$I$I.apply(this, [view, 20, 30]);
}, 1);

Clazz.newMethod$(C$, 'c$$I$I', function (vsbPolicy, hsbPolicy) {
C$.c$$java_awt_Component$I$I.apply(this, [null, vsbPolicy, hsbPolicy]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_awt_Component$I$I.apply(this, [null, 20, 30]);
}, 1);

Clazz.newMethod$(C$, 'setLayout$java_awt_LayoutManager', function (layout) {
if (Clazz.instanceOf(layout, "javax.swing.ScrollPaneLayout")) {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [layout]);
(layout).syncWithScrollPane$javax_swing_JScrollPane(this);
} else if (layout == null ) {
C$.superClazz.prototype.setLayout$java_awt_LayoutManager.apply(this, [layout]);
} else {
var s = "layout of JScrollPane must be a ScrollPaneLayout";
throw Clazz.new(Clazz.load('java.lang.ClassCastException').c$$S,[s]);
}});

Clazz.newMethod$(C$, 'isValidateRoot', function () {
return true;
});

Clazz.newMethod$(C$, 'getVerticalScrollBarPolicy', function () {
return this.verticalScrollBarPolicy;
});

Clazz.newMethod$(C$, 'setVerticalScrollBarPolicy$I', function (policy) {
switch (policy) {
case 20:
case 21:
case 22:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid verticalScrollBarPolicy"]);
}
var old = this.verticalScrollBarPolicy;
this.verticalScrollBarPolicy = policy;
this.firePropertyChange$S$I$I("verticalScrollBarPolicy", old, policy);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'getHorizontalScrollBarPolicy', function () {
return this.horizontalScrollBarPolicy;
});

Clazz.newMethod$(C$, 'setHorizontalScrollBarPolicy$I', function (policy) {
switch (policy) {
case 30:
case 31:
case 32:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid horizontalScrollBarPolicy"]);
}
var old = this.horizontalScrollBarPolicy;
this.horizontalScrollBarPolicy = policy;
this.firePropertyChange$S$I$I("horizontalScrollBarPolicy", old, policy);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'getViewportBorder', function () {
return this.viewportBorder;
});

Clazz.newMethod$(C$, 'setViewportBorder$javax_swing_border_Border', function (viewportBorder) {
var oldValue = this.viewportBorder;
this.viewportBorder = viewportBorder;
this.firePropertyChange$S$O$O("viewportBorder", oldValue, viewportBorder);
});

Clazz.newMethod$(C$, 'getViewportBorderBounds', function () {
var borderR = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.Rectangle'))).c$$java_awt_Dimension,[this.getSize()]);
var insets = this.getInsets();
borderR.x = insets.left;
borderR.y = insets.top;
borderR.width = borderR.width-(insets.left + insets.right);
borderR.height = borderR.height-(insets.top + insets.bottom);
var leftToRight = (I$[3] || (I$[3]=Clazz.load('javax.swing.SwingUtilities'))).isLeftToRight$java_awt_Component(this);
var colHead = this.getColumnHeader();
if ((colHead != null ) && (colHead.isVisible()) ) {
var colHeadHeight = colHead.getHeight();
borderR.y = borderR.y+(colHeadHeight);
borderR.height = borderR.height-(colHeadHeight);
}var rowHead = this.getRowHeader();
if ((rowHead != null ) && (rowHead.isVisible()) ) {
var rowHeadWidth = rowHead.getWidth();
if (leftToRight) {
borderR.x = borderR.x+(rowHeadWidth);
}borderR.width = borderR.width-(rowHeadWidth);
}var vsb = this.getVerticalScrollBar();
if ((vsb != null ) && (vsb.isVisible()) ) {
var vsbWidth = vsb.getWidth();
if (!leftToRight) {
borderR.x = borderR.x+(vsbWidth);
}borderR.width = borderR.width-(vsbWidth);
}var hsb = this.getHorizontalScrollBar();
if ((hsb != null ) && (hsb.isVisible()) ) {
borderR.height = borderR.height-(hsb.getHeight());
}return borderR;
});

Clazz.newMethod$(C$, 'createHorizontalScrollBar', function () {
return Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.JScrollPane').ScrollBar))).c$$I, [this, null, 0]);
});

Clazz.newMethod$(C$, 'getHorizontalScrollBar', function () {
return this.horizontalScrollBar;
});

Clazz.newMethod$(C$, 'setHorizontalScrollBar$javax_swing_JScrollBar', function (horizontalScrollBar) {
var old = this.getHorizontalScrollBar();
this.horizontalScrollBar = horizontalScrollBar;
if (horizontalScrollBar != null ) {
this.add$java_awt_Component$O(horizontalScrollBar, "HORIZONTAL_SCROLLBAR");
} else if (old != null ) {
this.remove$java_awt_Component(old);
}this.firePropertyChange$S$O$O("horizontalScrollBar", old, horizontalScrollBar);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'createVerticalScrollBar', function () {
return Clazz.new((I$[4] || (I$[4]=Clazz.load(Clazz.load('javax.swing.JScrollPane').ScrollBar))).c$$I, [this, null, 1]);
});

Clazz.newMethod$(C$, 'getVerticalScrollBar', function () {
return this.verticalScrollBar;
});

Clazz.newMethod$(C$, 'setVerticalScrollBar$javax_swing_JScrollBar', function (verticalScrollBar) {
var old = this.getVerticalScrollBar();
this.verticalScrollBar = verticalScrollBar;
this.add$java_awt_Component$O(verticalScrollBar, "VERTICAL_SCROLLBAR");
this.firePropertyChange$S$O$O("verticalScrollBar", old, verticalScrollBar);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'createViewport', function () {
return Clazz.new((I$[5] || (I$[5]=Clazz.load('javax.swing.JViewport'))));
});

Clazz.newMethod$(C$, 'getViewport', function () {
return this.viewport;
});

Clazz.newMethod$(C$, 'setViewport$javax_swing_JViewport', function (viewport) {
var old = this.getViewport();
this.viewport = viewport;
if (viewport != null ) {
this.add$java_awt_Component$O(viewport, "VIEWPORT");
} else if (old != null ) {
this.remove$java_awt_Component(old);
}this.firePropertyChange$S$O$O("viewport", old, viewport);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'setViewportView$java_awt_Component', function (view) {
if (this.getViewport() == null ) {
this.setViewport$javax_swing_JViewport(this.createViewport());
}this.getViewport().setView$java_awt_Component(view);
});

Clazz.newMethod$(C$, 'getRowHeader', function () {
return this.rowHeader;
});

Clazz.newMethod$(C$, 'setRowHeader$javax_swing_JViewport', function (rowHeader) {
var old = this.getRowHeader();
this.rowHeader = rowHeader;
if (rowHeader != null ) {
this.add$java_awt_Component$O(rowHeader, "ROW_HEADER");
} else if (old != null ) {
this.remove$java_awt_Component(old);
}this.firePropertyChange$S$O$O("rowHeader", old, rowHeader);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'setRowHeaderView$java_awt_Component', function (view) {
if (this.getRowHeader() == null ) {
this.setRowHeader$javax_swing_JViewport(this.createViewport());
}this.getRowHeader().setView$java_awt_Component(view);
});

Clazz.newMethod$(C$, 'getColumnHeader', function () {
return this.columnHeader;
});

Clazz.newMethod$(C$, 'setColumnHeader$javax_swing_JViewport', function (columnHeader) {
var old = this.getColumnHeader();
this.columnHeader = columnHeader;
if (columnHeader != null ) {
this.add$java_awt_Component$O(columnHeader, "COLUMN_HEADER");
} else if (old != null ) {
this.remove$java_awt_Component(old);
}this.firePropertyChange$S$O$O("columnHeader", old, columnHeader);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'setColumnHeaderView$java_awt_Component', function (view) {
if (this.getColumnHeader() == null ) {
this.setColumnHeader$javax_swing_JViewport(this.createViewport());
}this.getColumnHeader().setView$java_awt_Component(view);
});

Clazz.newMethod$(C$, 'getCorner$S', function (key) {
var isLeftToRight = this.getComponentOrientation().isLeftToRight();
if (key.equals$O("LOWER_LEADING_CORNER")) {
key = isLeftToRight ? "LOWER_LEFT_CORNER" : "LOWER_RIGHT_CORNER";
} else if (key.equals$O("LOWER_TRAILING_CORNER")) {
key = isLeftToRight ? "LOWER_RIGHT_CORNER" : "LOWER_LEFT_CORNER";
} else if (key.equals$O("UPPER_LEADING_CORNER")) {
key = isLeftToRight ? "UPPER_LEFT_CORNER" : "UPPER_RIGHT_CORNER";
} else if (key.equals$O("UPPER_TRAILING_CORNER")) {
key = isLeftToRight ? "UPPER_RIGHT_CORNER" : "UPPER_LEFT_CORNER";
}if (key.equals$O("LOWER_LEFT_CORNER")) {
return this.lowerLeft;
} else if (key.equals$O("LOWER_RIGHT_CORNER")) {
return this.lowerRight;
} else if (key.equals$O("UPPER_LEFT_CORNER")) {
return this.upperLeft;
} else if (key.equals$O("UPPER_RIGHT_CORNER")) {
return this.upperRight;
} else {
return null;
}});

Clazz.newMethod$(C$, 'setCorner$S$java_awt_Component', function (key, corner) {
var old;
var isLeftToRight = this.getComponentOrientation().isLeftToRight();
if (key.equals$O("LOWER_LEADING_CORNER")) {
key = isLeftToRight ? "LOWER_LEFT_CORNER" : "LOWER_RIGHT_CORNER";
} else if (key.equals$O("LOWER_TRAILING_CORNER")) {
key = isLeftToRight ? "LOWER_RIGHT_CORNER" : "LOWER_LEFT_CORNER";
} else if (key.equals$O("UPPER_LEADING_CORNER")) {
key = isLeftToRight ? "UPPER_LEFT_CORNER" : "UPPER_RIGHT_CORNER";
} else if (key.equals$O("UPPER_TRAILING_CORNER")) {
key = isLeftToRight ? "UPPER_RIGHT_CORNER" : "UPPER_LEFT_CORNER";
}if (key.equals$O("LOWER_LEFT_CORNER")) {
old = this.lowerLeft;
this.lowerLeft = corner;
} else if (key.equals$O("LOWER_RIGHT_CORNER")) {
old = this.lowerRight;
this.lowerRight = corner;
} else if (key.equals$O("UPPER_LEFT_CORNER")) {
old = this.upperLeft;
this.upperLeft = corner;
} else if (key.equals$O("UPPER_RIGHT_CORNER")) {
old = this.upperRight;
this.upperRight = corner;
} else {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid corner key"]);
}if (old != null ) {
this.remove$java_awt_Component(old);
}if (corner != null ) {
this.add$java_awt_Component$O(corner, key);
}this.firePropertyChange$S$O$O(key, old, corner);
this.revalidate();
this.repaint();
});

Clazz.newMethod$(C$, 'setComponentOrientation$java_awt_ComponentOrientation', function (co) {
C$.superClazz.prototype.setComponentOrientation$java_awt_ComponentOrientation.apply(this, [co]);
if (this.verticalScrollBar != null ) this.verticalScrollBar.setComponentOrientation$java_awt_ComponentOrientation(co);
if (this.horizontalScrollBar != null ) this.horizontalScrollBar.setComponentOrientation$java_awt_ComponentOrientation(co);
});

Clazz.newMethod$(C$, 'isWheelScrollingEnabled', function () {
return this.wheelScrollState;
});

Clazz.newMethod$(C$, 'setWheelScrollingEnabled$Z', function (handleWheel) {
var old = this.wheelScrollState;
this.wheelScrollState = handleWheel;
this.firePropertyChange$S$Z$Z("wheelScrollingEnabled", old, handleWheel);
});
;
(function(){var C$=Clazz.newClass$(P$.JScrollPane, "ScrollBar", function(){
Clazz.newInstance$(this, arguments[0], true);
}, 'javax.swing.JScrollBar', 'javax.swing.plaf.UIResource');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.unitIncrementSet = false;
this.blockIncrementSet = false;
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (orientation) {
C$.superClazz.c$$I.apply(this, [orientation]);
C$.$init$.apply(this);
this.putClientProperty$O$O("JScrollBar.fastWheelScrolling", Boolean.TRUE);
}, 1);

Clazz.newMethod$(C$, 'setUnitIncrement$I', function (unitIncrement) {
this.unitIncrementSet = true;
this.putClientProperty$O$O("JScrollBar.fastWheelScrolling", null);
C$.superClazz.prototype.setUnitIncrement$I.apply(this, [unitIncrement]);
});

Clazz.newMethod$(C$, 'getUnitIncrement$I', function (direction) {
var vp = this.b$['javax.swing.JScrollPane'].getViewport();
if (!this.unitIncrementSet && (vp != null ) && (Clazz.instanceOf(vp.getView(), "javax.swing.Scrollable"))  ) {
var view = (vp.getView());
var vr = vp.getViewRect();
return view.getScrollableUnitIncrement$java_awt_Rectangle$I$I(vr, this.getOrientation(), direction);
} else {
return C$.superClazz.prototype.getUnitIncrement$I.apply(this, [direction]);
}});

Clazz.newMethod$(C$, 'setBlockIncrement$I', function (blockIncrement) {
this.blockIncrementSet = true;
this.putClientProperty$O$O("JScrollBar.fastWheelScrolling", null);
C$.superClazz.prototype.setBlockIncrement$I.apply(this, [blockIncrement]);
});

Clazz.newMethod$(C$, 'getBlockIncrement$I', function (direction) {
var vp = this.b$['javax.swing.JScrollPane'].getViewport();
if (this.blockIncrementSet || vp == null  ) {
return C$.superClazz.prototype.getBlockIncrement$I.apply(this, [direction]);
} else if (Clazz.instanceOf(vp.getView(), "javax.swing.Scrollable")) {
var view = (vp.getView());
var vr = vp.getViewRect();
return view.getScrollableBlockIncrement$java_awt_Rectangle$I$I(vr, this.getOrientation(), direction);
} else if (this.getOrientation() == 1) {
return vp.getExtentSize().height;
} else {
return vp.getExtentSize().width;
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:42
