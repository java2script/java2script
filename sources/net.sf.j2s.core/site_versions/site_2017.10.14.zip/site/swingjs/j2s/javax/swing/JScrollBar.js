(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "JScrollBar", function(){
Clazz.newInstance$(this, arguments);
}, 'javax.swing.JComponent', 'java.awt.Adjustable');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.fwdAdjustmentEvents = null;
this.model = null;
this.orientation = 0;
this.unitIncrement = 0;
this.blockIncrement = 0;
}, 1);

Clazz.newMethod$(C$, 'checkOrientation$I', function (orientation) {
switch (orientation) {
case 1:
case 0:
break;
default:
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["orientation must be one of: VERTICAL, HORIZONTAL"]);
}
});

Clazz.newMethod$(C$, 'c$$I$I$I$I$I', function (orientation, value, extent, min, max) {
Clazz.super(C$, this,1);
p$.checkOrientation$I.apply(this, [orientation]);
this.unitIncrement = 1;
this.blockIncrement = (extent == 0) ? 1 : extent;
this.orientation = orientation;
this.model = Clazz.new((I$[0] || (I$[0]=Clazz.load('javax.swing.DefaultBoundedRangeModel'))).c$$I$I$I$I,[value, extent, min, max]);
this.model.addChangeListener$javax_swing_event_ChangeListener(this.fwdAdjustmentEvents = Clazz.new((I$[1] || (I$[1]=Clazz.load(Clazz.load('javax.swing.JScrollBar').ModelListener))), [this, null]));
this.setRequestFocusEnabled$Z(false);
this.uiClassID = "ScrollBarUI";
this.updateUI();
}, 1);

Clazz.newMethod$(C$, 'c$$I', function (orientation) {
C$.c$$I$I$I$I$I.apply(this, [orientation, 0, 10, 0, 100]);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$I.apply(this, [1]);
}, 1);

Clazz.newMethod$(C$, 'addChangeListener$javax_swing_event_ChangeListener', function (l) {
this.model.addChangeListener$javax_swing_event_ChangeListener(l);
});

Clazz.newMethod$(C$, 'removeChangeListener$javax_swing_event_ChangeListener', function (l) {
this.model.removeChangeListener$javax_swing_event_ChangeListener(l);
});

Clazz.newMethod$(C$, 'getOrientation', function () {
return this.orientation;
});

Clazz.newMethod$(C$, 'setOrientation$I', function (orientation) {
p$.checkOrientation$I.apply(this, [orientation]);
var oldValue = this.orientation;
this.orientation = orientation;
this.firePropertyChange$S$I$I("orientation", oldValue, orientation);
if (orientation != oldValue) {
this.revalidate();
}});

Clazz.newMethod$(C$, 'getModel', function () {
return this.model;
});

Clazz.newMethod$(C$, 'setModel$javax_swing_BoundedRangeModel', function (newModel) {
var oldModel = this.model;
if (this.model != null ) {
this.model.removeChangeListener$javax_swing_event_ChangeListener(this.fwdAdjustmentEvents);
}this.model = newModel;
if (this.model != null ) {
this.model.addChangeListener$javax_swing_event_ChangeListener(this.fwdAdjustmentEvents);
}this.firePropertyChange$S$O$O("model", oldModel, this.model);
});

Clazz.newMethod$(C$, 'getUnitIncrement$I', function (direction) {
return this.unitIncrement;
});

Clazz.newMethod$(C$, 'setUnitIncrement$I', function (unitIncrement) {
var oldValue = this.unitIncrement;
this.unitIncrement = unitIncrement;
this.firePropertyChange$S$I$I("unitIncrement", oldValue, unitIncrement);
});

Clazz.newMethod$(C$, 'getBlockIncrement$I', function (direction) {
return this.blockIncrement;
});

Clazz.newMethod$(C$, 'setBlockIncrement$I', function (blockIncrement) {
var oldValue = this.blockIncrement;
this.blockIncrement = blockIncrement;
this.firePropertyChange$S$I$I("blockIncrement", oldValue, blockIncrement);
});

Clazz.newMethod$(C$, 'getUnitIncrement', function () {
return this.unitIncrement;
});

Clazz.newMethod$(C$, 'getBlockIncrement', function () {
return this.blockIncrement;
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.getModel().getValue();
});

Clazz.newMethod$(C$, 'setValue$I', function (value) {
var m = this.getModel();
m.setValue$I(value);
});

Clazz.newMethod$(C$, 'getVisibleAmount', function () {
return this.getModel().getExtent();
});

Clazz.newMethod$(C$, 'setVisibleAmount$I', function (extent) {
this.getModel().setExtent$I(extent);
});

Clazz.newMethod$(C$, 'getMinimum', function () {
return this.getModel().getMinimum();
});

Clazz.newMethod$(C$, 'setMinimum$I', function (minimum) {
this.getModel().setMinimum$I(minimum);
});

Clazz.newMethod$(C$, 'getMaximum', function () {
return this.getModel().getMaximum();
});

Clazz.newMethod$(C$, 'setMaximum$I', function (maximum) {
this.getModel().setMaximum$I(maximum);
});

Clazz.newMethod$(C$, 'getValueIsAdjusting', function () {
return this.getModel().getValueIsAdjusting();
});

Clazz.newMethod$(C$, 'setValueIsAdjusting$Z', function (b) {
var m = this.getModel();
m.setValueIsAdjusting$Z(b);
});

Clazz.newMethod$(C$, 'setValues$I$I$I$I', function (newValue, newExtent, newMin, newMax) {
var m = this.getModel();
m.setRangeProperties$I$I$I$I$Z(newValue, newExtent, newMin, newMax, m.getValueIsAdjusting());
});

Clazz.newMethod$(C$, 'addAdjustmentListener$java_awt_event_AdjustmentListener', function (l) {
this.listenerList.add$Class$TT(Clazz.getClass(java.awt.event.AdjustmentListener), l);
});

Clazz.newMethod$(C$, 'removeAdjustmentListener$java_awt_event_AdjustmentListener', function (l) {
this.listenerList.remove$Class$TT(Clazz.getClass(java.awt.event.AdjustmentListener), l);
});

Clazz.newMethod$(C$, 'getAdjustmentListeners', function () {
return this.listenerList.getListeners$Class(Clazz.getClass(java.awt.event.AdjustmentListener));
});

Clazz.newMethod$(C$, 'fireAdjustmentValueChanged$I$I$I', function (id, type, value) {
p$.fireAdjustmentValueChanged$I$I$I$Z.apply(this, [id, type, value, this.getValueIsAdjusting()]);
});

Clazz.newMethod$(C$, 'fireAdjustmentValueChanged$I$I$I$Z', function (id, type, value, isAdjusting) {
var listeners = this.listenerList.getListenerList();
var e = null;
for (var i = listeners.length - 2; i >= 0; i = i-(2)) {
if (listeners[i] === Clazz.getClass(java.awt.event.AdjustmentListener) ) {
if (e == null ) {
e = Clazz.new((I$[2] || (I$[2]=Clazz.load('java.awt.event.AdjustmentEvent'))).c$$java_awt_Adjustable$I$I$I$Z,[this, id, type, value, isAdjusting]);
}(listeners[i + 1]).adjustmentValueChanged$java_awt_event_AdjustmentEvent(e);
}}
});

Clazz.newMethod$(C$, 'getMinimumSize', function () {
var pref = this.getPreferredSize();
if (this.orientation == 1) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[pref.width, 5]);
} else {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[5, pref.height]);
}});

Clazz.newMethod$(C$, 'getMaximumSize', function () {
var pref = this.getPreferredSize();
if (this.getOrientation() == 1) {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[pref.width, 32767]);
} else {
return Clazz.new((I$[3] || (I$[3]=Clazz.load('java.awt.Dimension'))).c$$I$I,[32767, pref.height]);
}});

Clazz.newMethod$(C$, 'setEnabled$Z', function (x) {
C$.superClazz.prototype.setEnabled$Z.apply(this, [x]);
var children = this.getComponents();
for (var i = 0; i < children.length; i++) {
children[i].setEnabled$Z(x);
}
});

Clazz.newMethod$(C$, 'paramString', function () {
var orientationString = (this.orientation == 0 ? "HORIZONTAL" : "VERTICAL");
return C$.superClazz.prototype.paramString.apply(this, []) + ",blockIncrement=" + this.blockIncrement + ",orientation=" + orientationString + ",unitIncrement=" + this.unitIncrement ;
});
;
(function(){var C$=Clazz.newClass$(P$.JScrollBar, "ModelListener", function(){
Clazz.newInstance$(this, arguments[0], true);
}, null, 'javax.swing.event.ChangeListener');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'stateChanged$javax_swing_event_ChangeEvent', function (e) {
var obj = e.getSource();
if (Clazz.instanceOf(obj, "javax.swing.BoundedRangeModel")) {
var id = 601;
var type = 5;
var model = obj;
var value = model.getValue();
var isAdjusting = model.getValueIsAdjusting();
this.b$['javax.swing.JScrollBar'].fireAdjustmentValueChanged$I$I$I$Z.apply(this.b$['javax.swing.JScrollBar'], [id, type, value, isAdjusting]);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})()
})();
//Created 2017-10-14 13:31:42
