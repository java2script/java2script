(function(){var P$=Clazz.newPackage$("javax.swing.event"),I$=[];
var C$=Clazz.newClass$(P$, "MenuDragMouseEvent", null, 'java.awt.event.MouseEvent');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.path = null;
this.manager = null;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$I$J$I$I$I$I$Z$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (source, id, when, modifiers, x, y, clickCount, popupTrigger, p, m) {
C$.superClazz.c$$java_awt_Component$I$J$I$I$I$I$Z.apply(this, [source, id, when, modifiers, x, y, clickCount, popupTrigger]);
C$.$init$.apply(this);
this.path = p;
this.manager = m;
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$javax_swing_MenuElementA$javax_swing_MenuSelectionManager', function (source, id, when, modifiers, x, y, xAbs, yAbs, clickCount, popupTrigger, p, m) {
C$.superClazz.c$$java_awt_Component$I$J$I$I$I$I$I$I$Z$I.apply(this, [source, id, when, modifiers, x, y, xAbs, yAbs, clickCount, popupTrigger, 0]);
C$.$init$.apply(this);
this.path = p;
this.manager = m;
}, 1);

Clazz.newMethod$(C$, 'getPath', function () {
return this.path;
});

Clazz.newMethod$(C$, 'getMenuSelectionManager', function () {
return this.manager;
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-10-14 13:31:54
