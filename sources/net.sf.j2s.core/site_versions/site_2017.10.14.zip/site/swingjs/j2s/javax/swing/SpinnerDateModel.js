(function(){var P$=Clazz.newPackage$("javax.swing"),I$=[];
var C$=Clazz.newClass$(P$, "SpinnerDateModel", null, 'javax.swing.AbstractSpinnerModel');
var p$=C$.prototype;

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.start = null;
this.end = null;
this.value = null;
this.calendarField = 0;
}, 1);

Clazz.newMethod$(C$, 'calendarFieldOK$I', function (calendarField) {
switch (calendarField) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 5:
case 6:
case 7:
case 8:
case 9:
case 10:
case 11:
case 12:
case 13:
case 14:
return true;
default:
return false;
}
});

Clazz.newMethod$(C$, 'c$$java_util_Date$Comparable$Comparable$I', function (value, start, end, calendarField) {
Clazz.super(C$, this,1);
if (value == null ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["value is null"]);
}if (!p$.calendarFieldOK$I.apply(this, [calendarField])) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid calendarField"]);
}if (!(((start == null ) || (start.compareTo$TT(value) <= 0) ) && ((end == null ) || (end.compareTo$TT(value) >= 0) ) )) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["(start <= value <= end) is false"]);
}this.value = (I$[0] || (I$[0]=Clazz.load('java.util.Calendar'))).getInstance();
this.start = start;
this.end = end;
this.calendarField = calendarField;
this.value.setTime$java_util_Date(value);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.c$$java_util_Date$Comparable$Comparable$I.apply(this, [Clazz.new((I$[1] || (I$[1]=Clazz.load('java.util.Date')))), null, null, 5]);
}, 1);

Clazz.newMethod$(C$, 'setStart$Comparable', function (start) {
if ((start == null ) ? (this.start != null ) : !start.equals$O(this.start)) {
this.start = start;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getStart', function () {
return this.start;
});

Clazz.newMethod$(C$, 'setEnd$Comparable', function (end) {
if ((end == null ) ? (this.end != null ) : !end.equals$O(this.end)) {
this.end = end;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getEnd', function () {
return this.end;
});

Clazz.newMethod$(C$, 'setCalendarField$I', function (calendarField) {
if (!p$.calendarFieldOK$I.apply(this, [calendarField])) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["invalid calendarField"]);
}if (calendarField != this.calendarField) {
this.calendarField = calendarField;
this.fireStateChanged();
}});

Clazz.newMethod$(C$, 'getCalendarField', function () {
return this.calendarField;
});

Clazz.newMethod$(C$, 'getNextValue', function () {
var cal = (I$[0] || (I$[0]=Clazz.load('java.util.Calendar'))).getInstance();
cal.setTime$java_util_Date(this.value.getTime());
cal.add$I$I(this.calendarField, 1);
var next = cal.getTime();
return ((this.end == null ) || (this.end.compareTo$TT(next) >= 0) ) ? next : null;
});

Clazz.newMethod$(C$, 'getPreviousValue', function () {
var cal = (I$[0] || (I$[0]=Clazz.load('java.util.Calendar'))).getInstance();
cal.setTime$java_util_Date(this.value.getTime());
cal.add$I$I(this.calendarField, -1);
var prev = cal.getTime();
return ((this.start == null ) || (this.start.compareTo$TT(prev) <= 0) ) ? prev : null;
});

Clazz.newMethod$(C$, 'getDate', function () {
return this.value.getTime();
});

Clazz.newMethod$(C$, 'getValue', function () {
return this.value.getTime();
});

Clazz.newMethod$(C$, 'setValue$O', function (value) {
if ((value == null ) || !(Clazz.instanceOf(value, "java.util.Date")) ) {
throw Clazz.new(Clazz.load('java.lang.IllegalArgumentException').c$$S,["illegal value"]);
}if (!value.equals$O(this.value.getTime())) {
this.value.setTime$java_util_Date(value);
this.fireStateChanged();
}});
})();
//Created 2017-10-14 13:31:50
