(function(){var P$=Clazz.newPackage$("javax.swing");
var C$=Clazz.newInterface$(P$, "ListSelectionModel");

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
C$.SINGLE_SELECTION = 0;
C$.SINGLE_INTERVAL_SELECTION = 1;
C$.MULTIPLE_INTERVAL_SELECTION = 2;
};

C$.SINGLE_SELECTION = 0;
C$.SINGLE_INTERVAL_SELECTION = 0;
C$.MULTIPLE_INTERVAL_SELECTION = 0;
})();
//Created 2017-10-14 13:31:47
