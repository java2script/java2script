(function(){var P$=Clazz.newPackage$("com.falstad"),I$=[];
var C$=Clazz.newClass$(P$, "CircOscCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.pg = null;
}, 1);

Clazz.newMethod$(C$, 'c$$com_falstad_CircOscFrame', function (p) {
Clazz.super(C$, this,1);
this.pg = p;
}, 1);

Clazz.newMethod$(C$, 'getPreferredSize', function () {
return Clazz.new((I$[0]||(I$[0]=Clazz.load('java.awt.Dimension'))).c$$I$I,[300, 400]);
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateCircOsc$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateCircOsc$java_awt_Graphics(g);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:12:21
