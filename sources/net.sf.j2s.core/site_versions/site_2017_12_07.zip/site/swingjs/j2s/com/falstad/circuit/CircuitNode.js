(function(){var P$=Clazz.newPackage$("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass$(P$, "CircuitNode");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, '$init0$', function () {
var c;if((c = C$.superClazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.links = null;
this.internal = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
this.links = Clazz.new((I$[0]||(I$[0]=Clazz.load('java.util.Vector'))));
}, 1);
})();
//Created 2017-12-07 06:12:38
