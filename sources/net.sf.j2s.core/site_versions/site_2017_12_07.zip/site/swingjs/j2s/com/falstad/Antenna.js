(function(){var P$=Clazz.newPackage$("com.falstad"),I$=[];
var C$=Clazz.newClass$(P$, "Antenna", null, 'a2s.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);};

C$.ogf = null;

Clazz.newMethod$(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMethod$(C$, 'destroyFrame', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
});

Clazz.newMethod$(C$, 'init', function () {
C$.ogf = Clazz.new((I$[1]||(I$[1]=Clazz.load('com.falstad.AntennaFrame'))).c$$com_falstad_Antenna,[this]);
C$.ogf.init();
});

Clazz.newMethod$(C$, 'destroy', function () {
if (C$.ogf != null ) C$.ogf.dispose();
C$.ogf = null;
});

Clazz.newMethod$(C$, 'main', function (args) {
C$.ogf = Clazz.new((I$[1]||(I$[1]=Clazz.load('com.falstad.AntennaFrame'))).c$$com_falstad_Antenna,[null]);
C$.ogf.init();
}, 1);

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
C$.superClazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (C$.ogf == null ) s = "Applet is finished.";
 else if (C$.ogf.useFrame) C$.ogf.triggerShow();
if (C$.ogf == null  || C$.ogf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:12:18
