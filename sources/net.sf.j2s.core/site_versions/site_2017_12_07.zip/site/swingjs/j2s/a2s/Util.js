(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Util");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'drawString$java_awt_Graphics$S$I$I', function (g, text, x, y) {
{
g.drawStringUnique(text, x, y);
}}, 1);

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:16:09
