(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Choice", null, 'javax.swing.JComboBox');

C$.$clinit$ = function() {Clazz.load(C$, 1);};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'select$I', function (index) {
this.setSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'select$S', function (key) {
this.setSelectedItem$O(key);
});

Clazz.newMethod$(C$, 'add$S', function (label) {
this.addItem$O(label);
});

Clazz.newMethod$(C$, 'getItem$I', function (n) {
return this.getItemAt$I(n);
});

Clazz.newMethod$(C$);
})();
//Created 2017-12-07 06:16:07
