(function(){var P$=Clazz.newPackage$("com.falstad.circuit"),I$=[];
var C$=Clazz.newClass$(P$, "CircuitNode");


Clazz.newMethod$(C$, '$init$', function () {
this.x = 0;
this.y = 0;
this.links = null;
this.internal = false;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.$init$.apply(this);
this.links = Clazz.new((I$[0] || (I$[0]=Clazz.load('java.util.Vector'))));
}, 1);
})();
//Created 2017-11-21 22:23:19
