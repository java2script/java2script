(function(){var P$=Clazz.newPackage$("com.falstad"),I$=[];
var C$=Clazz.newClass$(P$, "BarWaves", null, 'a2s.Applet');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};

C$.mf = null;

Clazz.newMethod$(C$, '$init$', function () {
this.started = false;
}, 1);

Clazz.newMethod$(C$, 'destroyFrame', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf = null;
});

Clazz.newMethod$(C$, 'start', function () {
C$.mf = Clazz.new((I$[0] || (I$[0]=Clazz.load('com.falstad.BarWavesFrame'))).c$$com_falstad_BarWaves,[this]);
C$.mf.init();
C$.mf.handleResize();
System.out.println$S("init");
});

Clazz.newMethod$(C$, 'main', function (args) {
C$.mf = Clazz.new((I$[0] || (I$[0]=Clazz.load('com.falstad.BarWavesFrame'))).c$$com_falstad_BarWaves,[null]);
C$.mf.init();
}, 1);

Clazz.newMethod$(C$, 'destroy', function () {
if (C$.mf != null ) C$.mf.dispose();
C$.mf = null;
});

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
System.out.println$O(C$.mf.cv.getSize());
C$.superClazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var s = "Applet is open in a separate window.";
if (!this.started) s = "Applet is starting.";
 else if (C$.mf == null ) s = "Applet is finished.";
 else if (C$.mf.useFrame) C$.mf.triggerShow();
if (C$.mf == null  || C$.mf.useFrame ) g.drawString$S$I$I(s, 10, 30);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:01
