(function(){var P$=Clazz.newPackage$("com.falstad.circuit");
var C$=Clazz.newClass$(P$, "CircuitNodeLink");


Clazz.newMethod$(C$, '$init$', function () {
this.num = 0;
this.elm = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:19
