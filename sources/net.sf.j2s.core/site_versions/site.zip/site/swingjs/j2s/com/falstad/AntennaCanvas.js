(function(){var P$=Clazz.newPackage$("com.falstad"),I$=[];
var C$=Clazz.newClass$(P$, "AntennaCanvas", null, 'a2s.Canvas');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.pg = null;
}, 1);

Clazz.newMethod$(C$, 'c$$com_falstad_AntennaFrame', function (p) {
Clazz.super(C$, this,1);
this.pg = p;
}, 1);

Clazz.newMethod$(C$, 'getPreferredSize', function () {
return Clazz.new((I$[0] || (I$[0]=Clazz.load('java.awt.Dimension'))).c$$I$I,[300, 400]);
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
this.pg.updateAntenna$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'paintComponent$java_awt_Graphics', function (g) {
this.pg.updateAntenna$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:22:59
