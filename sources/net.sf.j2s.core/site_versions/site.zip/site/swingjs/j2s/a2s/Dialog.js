(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Dialog", null, 'javax.swing.JDialog');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$a2s_Frame$S$Z', function (c, title, isModal) {
C$.superClazz.c$$java_awt_Frame$S$Z.apply(this, [c, title, isModal]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:37
