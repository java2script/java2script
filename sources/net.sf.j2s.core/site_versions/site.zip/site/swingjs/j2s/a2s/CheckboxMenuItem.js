(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "CheckboxMenuItem", null, 'javax.swing.JCheckBoxMenuItem');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (string) {
C$.superClazz.c$$S.apply(this, [string]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
Clazz.super(C$, this,1);
}, 1);

Clazz.newMethod$(C$, 'c$$S$Z', function (string, b) {
C$.superClazz.c$$S$Z.apply(this, [string, b]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'getState', function () {
return this.isSelected();
});

Clazz.newMethod$(C$, 'setState$Z', function (tf) {
this.setSelected$Z(tf);
});
})();
//Created 2017-11-21 22:23:36
