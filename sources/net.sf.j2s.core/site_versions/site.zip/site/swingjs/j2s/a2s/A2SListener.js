(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "A2SListener", null, null, ['java.awt.event.AdjustmentListener', 'java.awt.event.ActionListener', 'java.awt.event.KeyListener', 'java.awt.event.MouseListener', 'java.awt.event.MouseMotionListener']);

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.applet = null;
}, 1);

Clazz.newMethod$(C$, 'c$$a2s_Applet', function (applet) {
C$.$init$.apply(this);
this.applet = applet;
}, 1);

Clazz.newMethod$(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'keyTyped$java_awt_event_KeyEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'keyPressed$java_awt_event_KeyEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'keyReleased$java_awt_event_KeyEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
Clazz.new((I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).c$$java_awt_Component$java_awt_AWTEvent,[this.applet, e]).run();
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:35
