(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Choice", null, 'javax.swing.JComboBox');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'select$I', function (index) {
this.setSelectedIndex$I(index);
});

Clazz.newMethod$(C$, 'select$S', function (key) {
this.setSelectedItem$O(key);
});

Clazz.newMethod$(C$, 'add$S', function (label) {
this.addItem$O(label);
});

Clazz.newMethod$(C$, 'getItem$I', function (n) {
return this.getItemAt$I(n);
});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:36
