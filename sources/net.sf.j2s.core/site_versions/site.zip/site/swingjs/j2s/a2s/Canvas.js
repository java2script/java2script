(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Canvas", null, 'a2s.Panel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
this.notified = false;
}, 1);

Clazz.newMethod$(C$, 'paint$java_awt_Graphics', function (g) {
this.update$java_awt_Graphics(g);
});

Clazz.newMethod$(C$, 'update$java_awt_Graphics', function (g) {
if (!this.notified) System.out.println$S("neither paint(g) nor update(g) is implemented for " + this);
this.notified = true;
{
this.paintComponent && this.paintComponent(g);
}});

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:36
