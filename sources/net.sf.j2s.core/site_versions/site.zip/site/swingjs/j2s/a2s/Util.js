(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Util");


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'drawString$java_awt_Graphics$S$I$I', function (g, text, x, y) {
{
g.drawStringUnique(text, x, y);
}}, 1);

Clazz.newMethod$(C$, 'c$', function(){Clazz.super(C$, this,1);
}, 1);
})();
//Created 2017-11-21 22:23:39
