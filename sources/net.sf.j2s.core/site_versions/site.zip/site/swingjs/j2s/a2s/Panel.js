(function(){var P$=Clazz.newPackage$("a2s"),I$=[];
var C$=Clazz.newClass$(P$, "Panel", null, 'javax.swing.JPanel');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$java_awt_LayoutManager', function (layout) {
C$.superClazz.c$$java_awt_LayoutManager.apply(this, [layout]);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMethod$(C$, 'add$java_awt_Component', function (comp) {
C$.superClazz.prototype.add$java_awt_Component.apply(this, [comp]);
return (I$[0] || (I$[0]=Clazz.load('a2s.A2SEvent'))).addComponent$java_util_EventListener$java_awt_Component(this.getTopLevelAncestor(), comp);
});
})();
//Created 2017-11-21 22:23:38
