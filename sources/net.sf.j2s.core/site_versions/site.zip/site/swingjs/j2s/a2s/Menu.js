(function(){var P$=Clazz.newPackage$("a2s");
var C$=Clazz.newClass$(P$, "Menu", null, 'javax.swing.JMenu');

C$.$clinit$ = function() {delete C$.$clinit$;Clazz.load(C$, 1);
};


Clazz.newMethod$(C$, '$init$', function () {
}, 1);

Clazz.newMethod$(C$, 'c$$S', function (title) {
C$.superClazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
title = null;
}, 1);

Clazz.newMethod$(C$, 'c$', function () {
C$.superClazz.c$.apply(this, []);
C$.$init$.apply(this);
var s = null;
}, 1);

Clazz.newMethod$(C$, 'countItems', function () {
return C$.superClazz.prototype.getComponentCount.apply(this, []);
});
})();
//Created 2017-11-21 22:23:37
