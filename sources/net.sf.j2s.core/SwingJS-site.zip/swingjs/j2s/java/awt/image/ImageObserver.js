(function(){var P$=Clazz.newPackage("java.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageObserver");
})();
;Clazz.setTVer('3.2.2.04');//Created 2018-09-06 15:45:23 Java2ScriptVisitor version 3.2.2.04 net.sf.j2s.core.jar version 3.2.2.04
