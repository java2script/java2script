﻿$_L(["java.util.AbstractList","$.AbstractMap","$.AbstractSet","$.Collection","$.List","$.Map","$.RandomAccess","$.Set","$.SortedMap","$.SortedSet","java.lang.UnsupportedOperationException","java.lang.reflect.Array","java.util.Iterator","$.Random"],"java.util.Collections",["java.lang.IllegalArgumentException","$.IndexOutOfBoundsException","$.NullPointerException","java.util.ArrayList","$.Arrays","$.Enumeration","$.ListIterator","$.NoSuchElementException"],function(){
c$=$_T(java.util,"Collections");
$_H();
c$=$_C(function(){
this.c=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableCollection",null,[java.util.Collection,java.io.Serializable]);
$_K(c$,
function(a){
if(a==null)throw new NullPointerException();
this.c=a;
},"java.util.Collection");
$_M(c$,"size",
function(){
return this.c.size();
});
$_M(c$,"isEmpty",
function(){
return this.c.isEmpty();
});
$_M(c$,"contains",
function(a){
return this.c.contains(a);
},"~O");
$_M(c$,"toArray",
function(){
return this.c.toArray();
});
$_M(c$,"toArray",
function(a){
return this.c.toArray(a);
},"~A");
$_M(c$,"toString",
function(){
return this.c.toString();
});
$_M(c$,"iterator",
function(){
return(function(i$,v$){
if(!$_D("java.util.Collections.UnmodifiableCollection$1")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.i=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableCollection$1",null,java.util.Iterator);
$_Y(c$,function(){
this.i=this.b$["java.util.Collections.UnmodifiableCollection"].c.iterator();
});
$_M(c$,"hasNext",
function(){
return this.i.hasNext();
});
$_M(c$,"next",
function(){
return this.i.next();
});
$_V(c$,"remove",
function(){
throw new UnsupportedOperationException();
});
c$=$_P();
}
return $_N(java.util.Collections.UnmodifiableCollection$1,i$,v$);
})(this,null);
});
$_V(c$,"add",
function(a){
throw new UnsupportedOperationException();
},"~O");
$_V(c$,"remove",
function(a){
throw new UnsupportedOperationException();
},"~O");
$_M(c$,"containsAll",
function(a){
return this.c.containsAll(a);
},"java.util.Collection");
$_V(c$,"addAll",
function(a){
throw new UnsupportedOperationException();
},"java.util.Collection");
$_V(c$,"removeAll",
function(a){
throw new UnsupportedOperationException();
},"java.util.Collection");
$_V(c$,"retainAll",
function(a){
throw new UnsupportedOperationException();
},"java.util.Collection");
$_V(c$,"clear",
function(){
throw new UnsupportedOperationException();
});
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"UnmodifiableSet",java.util.Collections.UnmodifiableCollection,[java.util.Set,java.io.Serializable]);
$_V(c$,"equals",
function(a){
return this.c.equals(a);
},"~O");
$_V(c$,"hashCode",
function(){
return this.c.hashCode();
});
c$=$_P();
$_H();
c$=$_C(function(){
this.ss=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableSortedSet",java.util.Collections.UnmodifiableSet,[java.util.SortedSet,java.io.Serializable]);
$_K(c$,
function(a){
$_R(this,java.util.Collections.UnmodifiableSortedSet,[a]);
this.ss=a;
},"java.util.SortedSet");
$_M(c$,"comparator",
function(){
return this.ss.comparator();
});
$_M(c$,"subSet",
function(a,b){
return new java.util.Collections.UnmodifiableSortedSet(this.ss.subSet(a,b));
},"~O,~O");
$_M(c$,"headSet",
function(a){
return new java.util.Collections.UnmodifiableSortedSet(this.ss.headSet(a));
},"~O");
$_M(c$,"tailSet",
function(a){
return new java.util.Collections.UnmodifiableSortedSet(this.ss.tailSet(a));
},"~O");
$_M(c$,"first",
function(){
return this.ss.first();
});
$_M(c$,"last",
function(){
return this.ss.last();
});
c$=$_P();
$_H();
c$=$_C(function(){
this.list=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableList",java.util.Collections.UnmodifiableCollection,java.util.List);
$_K(c$,
function(a){
$_R(this,java.util.Collections.UnmodifiableList,[a]);
this.list=a;
},"java.util.List");
$_M(c$,"equals",
function(a){
return this.list.equals(a);
},"~O");
$_M(c$,"hashCode",
function(){
return this.list.hashCode();
});
$_M(c$,"get",
function(a){
return this.list.get(a);
},"~N");
$_V(c$,"set",
function(a,b){
throw new UnsupportedOperationException();
},"~N,~O");
$_M(c$,"add",
function(a,b){
throw new UnsupportedOperationException();
},"~N,~O");
$_M(c$,"remove",
function(a){
throw new UnsupportedOperationException();
},"~N");
$_M(c$,"indexOf",
function(a){
return this.list.indexOf(a);
},"~O");
$_M(c$,"lastIndexOf",
function(a){
return this.list.lastIndexOf(a);
},"~O");
$_M(c$,"addAll",
function(a,b){
throw new UnsupportedOperationException();
},"~N,java.util.Collection");
$_M(c$,"listIterator",
function(){
return this.listIterator(0);
});
$_M(c$,"listIterator",
function(a){
return(function(i$,v$){
if(!$_D("java.util.Collections.UnmodifiableList$1")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.i=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableList$1",null,java.util.ListIterator);
$_Y(c$,function(){
this.i=this.b$["java.util.Collections.UnmodifiableList"].list.listIterator(index);
});
$_M(c$,"hasNext",
function(){
return this.i.hasNext();
});
$_M(c$,"next",
function(){
return this.i.next();
});
$_M(c$,"hasPrevious",
function(){
return this.i.hasPrevious();
});
$_M(c$,"previous",
function(){
return this.i.previous();
});
$_M(c$,"nextIndex",
function(){
return this.i.nextIndex();
});
$_M(c$,"previousIndex",
function(){
return this.i.previousIndex();
});
$_V(c$,"remove",
function(){
throw new UnsupportedOperationException();
});
$_V(c$,"set",
function(b){
throw new UnsupportedOperationException();
},"~O");
$_V(c$,"add",
function(b){
throw new UnsupportedOperationException();
},"~O");
c$=$_P();
}
return $_N(java.util.Collections.UnmodifiableList$1,i$,v$);
})(this,null);
},"~N");
$_M(c$,"subList",
function(a,b){
return new java.util.Collections.UnmodifiableList(this.list.subList(a,b));
},"~N,~N");
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"UnmodifiableRandomAccessList",java.util.Collections.UnmodifiableList,java.util.RandomAccess);
$_V(c$,"subList",
function(a,b){
return new java.util.Collections.UnmodifiableRandomAccessList(this.list.subList(a,b));
},"~N,~N");
c$=$_P();
$_H();
c$=$_C(function(){
this.m=null;
this.$keySet=null;
this.$entrySet=null;
this.$values=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableMap",null,[java.util.Map,java.io.Serializable]);
$_H();
c$=$_T(java.util.Collections.UnmodifiableMap,"UnmodifiableEntrySet",java.util.Collections.UnmodifiableSet);
$_H();
c$=$_C(function(){
this.e=null;
$_Z(this,arguments);
},java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet,"UnmodifiableEntry",null,java.util.Map.Entry);
$_K(c$,
function(a){
this.e=a;
},"java.util.Map.Entry");
$_M(c$,"getKey",
function(){
return this.e.getKey();
});
$_M(c$,"getValue",
function(){
return this.e.getValue();
});
$_V(c$,"setValue",
function(a){
throw new UnsupportedOperationException();
},"~O");
$_M(c$,"hashCode",
function(){
return this.e.hashCode();
});
$_V(c$,"equals",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return java.util.Collections.eq(this.e.getKey(),b.getKey())&&java.util.Collections.eq(this.e.getValue(),b.getValue());
},"~O");
$_M(c$,"toString",
function(){
return this.e.toString();
});
c$=$_P();
$_V(c$,"iterator",
function(){
return(function(i$,v$){
if(!$_D("java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet$1")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.i=null;
$_Z(this,arguments);
},java.util.Collections.UnmodifiableMap,"UnmodifiableEntrySet$1",null,java.util.Iterator);
$_Y(c$,function(){
this.i=this.b$["java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet"].c.iterator();
});
$_M(c$,"hasNext",
function(){
return this.i.hasNext();
});
$_M(c$,"next",
function(){
return new java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet.UnmodifiableEntry(this.i.next());
});
$_V(c$,"remove",
function(){
throw new UnsupportedOperationException();
});
c$=$_P();
}
return $_N(java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet$1,i$,v$);
})(this,null);
});
$_M(c$,"toArray",
function(){
var a=this.c.toArray();
for(var b=0;b<a.length;b++)a[b]=new java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet.UnmodifiableEntry(a[b]);

return a;
});
$_M(c$,"toArray",
function(a){
var b=this.c.toArray(a.length==0?a:java.lang.reflect.Array.newInstance(a.getClass().getComponentType(),0));
for(var c=0;c<b.length;c++)b[c]=new java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet.UnmodifiableEntry(b[c]);

if(b.length>a.length)return b;
System.arraycopy(b,0,a,0,b.length);
if(a.length>b.length)a[b.length]=null;
return a;
},"~A");
$_V(c$,"contains",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
return this.c.contains(new java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet.UnmodifiableEntry(a));
},"~O");
$_V(c$,"containsAll",
function(a){
var b=a.iterator();
while(b.hasNext())if(!this.contains(b.next()))return false;

return true;
},"java.util.Collection");
$_V(c$,"equals",
function(a){
if(a==this)return true;
if(!($_O(a,java.util.Set)))return false;
var b=a;
if(b.size()!=this.c.size())return false;
return this.containsAll(b);
},"~O");
c$=$_P();
$_K(c$,
function(a){
if(a==null)throw new NullPointerException();
this.m=a;
},"java.util.Map");
$_M(c$,"size",
function(){
return this.m.size();
});
$_M(c$,"isEmpty",
function(){
return this.m.isEmpty();
});
$_M(c$,"containsKey",
function(a){
return this.m.containsKey(a);
},"~O");
$_M(c$,"containsValue",
function(a){
return this.m.containsValue(a);
},"~O");
$_M(c$,"get",
function(a){
return this.m.get(a);
},"~O");
$_V(c$,"put",
function(a,b){
throw new UnsupportedOperationException();
},"~O,~O");
$_V(c$,"remove",
function(a){
throw new UnsupportedOperationException();
},"~O");
$_V(c$,"putAll",
function(a){
throw new UnsupportedOperationException();
},"java.util.Map");
$_V(c$,"clear",
function(){
throw new UnsupportedOperationException();
});
$_M(c$,"keySet",
function(){
if(this.$keySet==null)this.$keySet=java.util.Collections.unmodifiableSet(this.m.keySet());
return this.$keySet;
});
$_M(c$,"entrySet",
function(){
if(this.$entrySet==null)this.$entrySet=new java.util.Collections.UnmodifiableMap.UnmodifiableEntrySet(this.m.entrySet());
return this.$entrySet;
});
$_M(c$,"values",
function(){
if(this.$values==null)this.$values=java.util.Collections.unmodifiableCollection(this.m.values());
return this.$values;
});
$_M(c$,"equals",
function(a){
return this.m.equals(a);
},"~O");
$_M(c$,"hashCode",
function(){
return this.m.hashCode();
});
$_M(c$,"toString",
function(){
return this.m.toString();
});
c$=$_P();
$_H();
c$=$_C(function(){
this.sm=null;
$_Z(this,arguments);
},java.util.Collections,"UnmodifiableSortedMap",java.util.Collections.UnmodifiableMap,[java.util.SortedMap,java.io.Serializable]);
$_K(c$,
function(a){
$_R(this,java.util.Collections.UnmodifiableSortedMap,[a]);
this.sm=a;
},"java.util.SortedMap");
$_M(c$,"comparator",
function(){
return this.sm.comparator();
});
$_M(c$,"subMap",
function(a,b){
return new java.util.Collections.UnmodifiableSortedMap(this.sm.subMap(a,b));
},"~O,~O");
$_M(c$,"headMap",
function(a){
return new java.util.Collections.UnmodifiableSortedMap(this.sm.headMap(a));
},"~O");
$_M(c$,"tailMap",
function(a){
return new java.util.Collections.UnmodifiableSortedMap(this.sm.tailMap(a));
},"~O");
$_M(c$,"firstKey",
function(){
return this.sm.firstKey();
});
$_M(c$,"lastKey",
function(){
return this.sm.lastKey();
});
c$=$_P();
$_H();
c$=$_C(function(){
this.c=null;
this.mutex=null;
$_Z(this,arguments);
},java.util.Collections,"SynchronizedCollection",null,[java.util.Collection,java.io.Serializable]);
$_K(c$,
function(a){
if(a==null)throw new NullPointerException();
this.c=a;
this.mutex=this;
},"java.util.Collection");
$_K(c$,
function(a,b){
this.c=a;
this.mutex=b;
},"java.util.Collection,~O");
$_M(c$,"size",
function(){
{
return this.c.size();
}});
$_M(c$,"isEmpty",
function(){
{
return this.c.isEmpty();
}});
$_M(c$,"contains",
function(a){
{
return this.c.contains(a);
}},"~O");
$_M(c$,"toArray",
function(){
{
return this.c.toArray();
}});
$_M(c$,"toArray",
function(a){
{
return this.c.toArray(a);
}},"~A");
$_M(c$,"iterator",
function(){
return this.c.iterator();
});
$_M(c$,"add",
function(a){
{
return this.c.add(a);
}},"~O");
$_M(c$,"remove",
function(a){
{
return this.c.remove(a);
}},"~O");
$_M(c$,"containsAll",
function(a){
{
return this.c.containsAll(a);
}},"java.util.Collection");
$_M(c$,"addAll",
function(a){
{
return this.c.addAll(a);
}},"java.util.Collection");
$_M(c$,"removeAll",
function(a){
{
return this.c.removeAll(a);
}},"java.util.Collection");
$_M(c$,"retainAll",
function(a){
{
return this.c.retainAll(a);
}},"java.util.Collection");
$_M(c$,"clear",
function(){
{
this.c.clear();
}});
$_M(c$,"toString",
function(){
{
return this.c.toString();
}});
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"SynchronizedSet",java.util.Collections.SynchronizedCollection,java.util.Set);
$_V(c$,"equals",
function(a){
{
return this.c.equals(a);
}},"~O");
$_V(c$,"hashCode",
function(){
{
return this.c.hashCode();
}});
c$=$_P();
$_H();
c$=$_C(function(){
this.ss=null;
$_Z(this,arguments);
},java.util.Collections,"SynchronizedSortedSet",java.util.Collections.SynchronizedSet,java.util.SortedSet);
$_K(c$,
function(a){
$_R(this,java.util.Collections.SynchronizedSortedSet,[a]);
this.ss=a;
},"java.util.SortedSet");
$_K(c$,
function(a,b){
$_R(this,java.util.Collections.SynchronizedSortedSet,[a,b]);
this.ss=a;
},"java.util.SortedSet,~O");
$_M(c$,"comparator",
function(){
{
return this.ss.comparator();
}});
$_M(c$,"subSet",
function(a,b){
{
return new java.util.Collections.SynchronizedSortedSet(this.ss.subSet(a,b),this.mutex);
}},"~O,~O");
$_M(c$,"headSet",
function(a){
{
return new java.util.Collections.SynchronizedSortedSet(this.ss.headSet(a),this.mutex);
}},"~O");
$_M(c$,"tailSet",
function(a){
{
return new java.util.Collections.SynchronizedSortedSet(this.ss.tailSet(a),this.mutex);
}},"~O");
$_M(c$,"first",
function(){
{
return this.ss.first();
}});
$_M(c$,"last",
function(){
{
return this.ss.last();
}});
c$=$_P();
$_H();
c$=$_C(function(){
this.list=null;
$_Z(this,arguments);
},java.util.Collections,"SynchronizedList",java.util.Collections.SynchronizedCollection,java.util.List);
$_K(c$,
function(a){
$_R(this,java.util.Collections.SynchronizedList,[a]);
this.list=a;
},"java.util.List");
$_K(c$,
function(a,b){
$_R(this,java.util.Collections.SynchronizedList,[a,b]);
this.list=a;
},"java.util.List,~O");
$_M(c$,"equals",
function(a){
{
return this.list.equals(a);
}},"~O");
$_M(c$,"hashCode",
function(){
{
return this.list.hashCode();
}});
$_M(c$,"get",
function(a){
{
return this.list.get(a);
}},"~N");
$_M(c$,"set",
function(a,b){
{
return this.list.set(a,b);
}},"~N,~O");
$_M(c$,"add",
function(a,b){
{
this.list.add(a,b);
}},"~N,~O");
$_M(c$,"remove",
function(a){
{
return this.list.remove(a);
}},"~N");
$_M(c$,"indexOf",
function(a){
{
return this.list.indexOf(a);
}},"~O");
$_M(c$,"lastIndexOf",
function(a){
{
return this.list.lastIndexOf(a);
}},"~O");
$_M(c$,"addAll",
function(a,b){
{
return this.list.addAll(a,b);
}},"~N,java.util.Collection");
$_M(c$,"listIterator",
function(){
return this.list.listIterator();
});
$_M(c$,"listIterator",
function(a){
return this.list.listIterator(a);
},"~N");
$_M(c$,"subList",
function(a,b){
{
return new java.util.Collections.SynchronizedList(this.list.subList(a,b),this.mutex);
}},"~N,~N");
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"SynchronizedRandomAccessList",java.util.Collections.SynchronizedList,java.util.RandomAccess);
$_V(c$,"subList",
function(a,b){
{
return new java.util.Collections.SynchronizedRandomAccessList(this.list.subList(a,b),this.mutex);
}},"~N,~N");
c$=$_P();
$_H();
c$=$_C(function(){
this.m=null;
this.mutex=null;
this.$keySet=null;
this.$entrySet=null;
this.$values=null;
$_Z(this,arguments);
},java.util.Collections,"SynchronizedMap",null,[java.util.Map,java.io.Serializable]);
$_K(c$,
function(a){
if(a==null)throw new NullPointerException();
this.m=a;
this.mutex=this;
},"java.util.Map");
$_K(c$,
function(a,b){
this.m=a;
this.mutex=b;
},"java.util.Map,~O");
$_M(c$,"size",
function(){
{
return this.m.size();
}});
$_M(c$,"isEmpty",
function(){
{
return this.m.isEmpty();
}});
$_M(c$,"containsKey",
function(a){
{
return this.m.containsKey(a);
}},"~O");
$_M(c$,"containsValue",
function(a){
{
return this.m.containsValue(a);
}},"~O");
$_M(c$,"get",
function(a){
{
return this.m.get(a);
}},"~O");
$_M(c$,"put",
function(a,b){
{
return this.m.put(a,b);
}},"~O,~O");
$_M(c$,"remove",
function(a){
{
return this.m.remove(a);
}},"~O");
$_M(c$,"putAll",
function(a){
{
this.m.putAll(a);
}},"java.util.Map");
$_M(c$,"clear",
function(){
{
this.m.clear();
}});
$_M(c$,"keySet",
function(){
{
if(this.$keySet==null)this.$keySet=new java.util.Collections.SynchronizedSet(this.m.keySet(),this.mutex);
return this.$keySet;
}});
$_M(c$,"entrySet",
function(){
{
if(this.$entrySet==null)this.$entrySet=new java.util.Collections.SynchronizedSet(this.m.entrySet(),this.mutex);
return this.$entrySet;
}});
$_M(c$,"values",
function(){
{
if(this.$values==null)this.$values=new java.util.Collections.SynchronizedCollection(this.m.values(),this.mutex);
return this.$values;
}});
$_M(c$,"equals",
function(a){
{
return this.m.equals(a);
}},"~O");
$_M(c$,"hashCode",
function(){
{
return this.m.hashCode();
}});
$_M(c$,"toString",
function(){
{
return this.m.toString();
}});
c$=$_P();
$_H();
c$=$_C(function(){
this.sm=null;
$_Z(this,arguments);
},java.util.Collections,"SynchronizedSortedMap",java.util.Collections.SynchronizedMap,java.util.SortedMap);
$_K(c$,
function(a){
$_R(this,java.util.Collections.SynchronizedSortedMap,[a]);
this.sm=a;
},"java.util.SortedMap");
$_K(c$,
function(a,b){
$_R(this,java.util.Collections.SynchronizedSortedMap,[a,b]);
this.sm=a;
},"java.util.SortedMap,~O");
$_M(c$,"comparator",
function(){
{
return this.sm.comparator();
}});
$_M(c$,"subMap",
function(a,b){
{
return new java.util.Collections.SynchronizedSortedMap(this.sm.subMap(a,b),this.mutex);
}},"~O,~O");
$_M(c$,"headMap",
function(a){
{
return new java.util.Collections.SynchronizedSortedMap(this.sm.headMap(a),this.mutex);
}},"~O");
$_M(c$,"tailMap",
function(a){
{
return new java.util.Collections.SynchronizedSortedMap(this.sm.tailMap(a),this.mutex);
}},"~O");
$_M(c$,"firstKey",
function(){
{
return this.sm.firstKey();
}});
$_M(c$,"lastKey",
function(){
{
return this.sm.lastKey();
}});
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"EmptySet",java.util.AbstractSet,java.io.Serializable);
$_V(c$,"iterator",
function(){
return(function(i$,v$){
if(!$_D("java.util.Collections.EmptySet$1")){
$_H();
c$=$_W(java.util.Collections,"EmptySet$1",null,java.util.Iterator);
$_V(c$,"hasNext",
function(){
return false;
});
$_V(c$,"next",
function(){
throw new java.util.NoSuchElementException();
});
$_V(c$,"remove",
function(){
throw new UnsupportedOperationException();
});
c$=$_P();
}
return $_N(java.util.Collections.EmptySet$1,i$,v$);
})(this,null);
});
$_V(c$,"size",
function(){
return 0;
});
$_V(c$,"contains",
function(a){
return false;
},"~O");
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"EmptyList",java.util.AbstractList,[java.util.RandomAccess,java.io.Serializable]);
$_V(c$,"size",
function(){
return 0;
});
$_V(c$,"contains",
function(a){
return false;
},"~O");
$_V(c$,"get",
function(a){
throw new IndexOutOfBoundsException("Index: "+a);
},"~N");
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"EmptyMap",java.util.AbstractMap,java.io.Serializable);
$_V(c$,"size",
function(){
return 0;
});
$_V(c$,"isEmpty",
function(){
return true;
});
$_V(c$,"containsKey",
function(a){
return false;
},"~O");
$_V(c$,"containsValue",
function(a){
return false;
},"~O");
$_V(c$,"get",
function(a){
return null;
},"~O");
$_V(c$,"keySet",
function(){
return java.util.Collections.EMPTY_SET;
});
$_V(c$,"values",
function(){
return java.util.Collections.EMPTY_SET;
});
$_V(c$,"entrySet",
function(){
return java.util.Collections.EMPTY_SET;
});
$_V(c$,"equals",
function(a){
return($_O(a,java.util.Map))&&(a).size()==0;
},"~O");
$_V(c$,"hashCode",
function(){
return 0;
});
c$=$_P();
$_H();
c$=$_C(function(){
this.element=null;
$_Z(this,arguments);
},java.util.Collections,"SingletonSet",java.util.AbstractSet,java.io.Serializable);
$_K(c$,
function(a){
$_R(this,java.util.Collections.SingletonSet,[]);
this.element=a;
},"~O");
$_V(c$,"iterator",
function(){
return(function(i$,v$){
if(!$_D("java.util.Collections.SingletonSet$1")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.$hasNext=true;
$_Z(this,arguments);
},java.util.Collections,"SingletonSet$1",null,java.util.Iterator);
$_V(c$,"hasNext",
function(){
return this.$hasNext;
});
$_V(c$,"next",
function(){
if(this.$hasNext){
this.$hasNext=false;
return this.b$["java.util.Collections.SingletonSet"].element;
}throw new java.util.NoSuchElementException();
});
$_V(c$,"remove",
function(){
throw new UnsupportedOperationException();
});
c$=$_P();
}
return $_N(java.util.Collections.SingletonSet$1,i$,v$);
})(this,null);
});
$_V(c$,"size",
function(){
return 1;
});
$_V(c$,"contains",
function(a){
return java.util.Collections.eq(a,this.element);
},"~O");
c$=$_P();
$_H();
c$=$_C(function(){
this.element=null;
$_Z(this,arguments);
},java.util.Collections,"SingletonList",java.util.AbstractList,[java.util.RandomAccess,java.io.Serializable]);
$_K(c$,
function(a){
$_R(this,java.util.Collections.SingletonList,[]);
this.element=a;
},"~O");
$_V(c$,"size",
function(){
return 1;
});
$_V(c$,"contains",
function(a){
return java.util.Collections.eq(a,this.element);
},"~O");
$_V(c$,"get",
function(a){
if(a!=0)throw new IndexOutOfBoundsException("Index: "+a+", Size: 1");
return this.element;
},"~N");
c$=$_P();
$_H();
c$=$_C(function(){
this.k=null;
this.v=null;
this.$$keySet=null;
this.$entrySet=null;
this.$$values=null;
$_Z(this,arguments);
},java.util.Collections,"SingletonMap",java.util.AbstractMap,java.io.Serializable);
$_H();
c$=$_C(function(){
this.k=null;
this.v=null;
$_Z(this,arguments);
},java.util.Collections.SingletonMap,"ImmutableEntry",null,java.util.Map.Entry);
$_K(c$,
function(a,b){
this.k=a;
this.v=b;
},"~O,~O");
$_M(c$,"getKey",
function(){
return this.k;
});
$_M(c$,"getValue",
function(){
return this.v;
});
$_V(c$,"setValue",
function(a){
throw new UnsupportedOperationException();
},"~O");
$_V(c$,"equals",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return java.util.Collections.eq(b.getKey(),this.k)&&java.util.Collections.eq(b.getValue(),this.v);
},"~O");
$_V(c$,"hashCode",
function(){
return((this.k==null?0:this.k.hashCode())^(this.v==null?0:this.v.hashCode()));
});
$_V(c$,"toString",
function(){
return this.k+"="+this.v;
});
c$=$_P();
$_K(c$,
function(a,b){
$_R(this,java.util.Collections.SingletonMap,[]);
this.k=a;
this.v=b;
},"~O,~O");
$_V(c$,"size",
function(){
return 1;
});
$_V(c$,"isEmpty",
function(){
return false;
});
$_V(c$,"containsKey",
function(a){
return java.util.Collections.eq(a,this.k);
},"~O");
$_V(c$,"containsValue",
function(a){
return java.util.Collections.eq(a,this.v);
},"~O");
$_V(c$,"get",
function(a){
return(java.util.Collections.eq(a,this.k)?this.v:null);
},"~O");
$_V(c$,"keySet",
function(){
if(this.$$keySet==null)this.$$keySet=java.util.Collections.singleton(this.k);
return this.$$keySet;
});
$_V(c$,"entrySet",
function(){
if(this.$entrySet==null)this.$entrySet=java.util.Collections.singleton(new java.util.Collections.SingletonMap.ImmutableEntry(this.k,this.v));
return this.$entrySet;
});
$_V(c$,"values",
function(){
if(this.$$values==null)this.$$values=java.util.Collections.singleton(this.v);
return this.$$values;
});
c$=$_P();
$_H();
c$=$_C(function(){
this.n=0;
this.element=null;
$_Z(this,arguments);
},java.util.Collections,"CopiesList",java.util.AbstractList,[java.util.RandomAccess,java.io.Serializable]);
$_K(c$,
function(a,b){
$_R(this,java.util.Collections.CopiesList,[]);
if(a<0)throw new IllegalArgumentException("List length = "+a);
this.n=a;
this.element=b;
},"~N,~O");
$_V(c$,"size",
function(){
return this.n;
});
$_V(c$,"contains",
function(a){
return this.n!=0&&java.util.Collections.eq(a,this.element);
},"~O");
$_V(c$,"get",
function(a){
if(a<0||a>=this.n)throw new IndexOutOfBoundsException("Index: "+a+", Size: "+this.n);
return this.element;
},"~N");
c$=$_P();
$_H();
c$=$_T(java.util.Collections,"ReverseComparator",null,[java.util.Comparator,java.io.Serializable]);
$_V(c$,"compare",
function(a,b){
var c=a;
var d=b;
var e=c.compareTo(d);
return-(e|(e>>>1));
},"~O,~O");
c$=$_P();
c$.sort=$_M(c$,"sort",
function(list){
var a=list.toArray();
java.util.Arrays.sort(a);
var i=list.listIterator();
for(var j=0;j<a.length;j++){
i.next();
i.set(a[j]);
}
},"java.util.List");
c$.sort=$_M(c$,"sort",
function(list,c){
var a=list.toArray();
java.util.Arrays.sort(a,c);
var i=list.listIterator();
for(var j=0;j<a.length;j++){
i.next();
i.set(a[j]);
}
},"java.util.List,java.util.Comparator");
c$.binarySearch=$_M(c$,"binarySearch",
function(list,key){
if($_O(list,java.util.RandomAccess)||list.size()<5000)return java.util.Collections.indexedBinarySearch(list,key);
else return java.util.Collections.iteratorBinarySearch(list,key);
},"java.util.List,~O");
c$.indexedBinarySearch=$_M(c$,"indexedBinarySearch",
($fz=function(list,key){
var low=0;
var high=list.size()-1;
while(low<=high){
var mid=(low+high)>>1;
var midVal=list.get(mid);
var cmp=(midVal).compareTo(key);
if(cmp<0)low=mid+1;
else if(cmp>0)high=mid-1;
else return mid;
}
return-(low+1);
},$fz.isPrivate=true,$fz),"java.util.List,~O");
c$.iteratorBinarySearch=$_M(c$,"iteratorBinarySearch",
($fz=function(list,key){
var low=0;
var high=list.size()-1;
var i=list.listIterator();
while(low<=high){
var mid=(low+high)>>1;
var midVal=java.util.Collections.get(i,mid);
var cmp=(midVal).compareTo(key);
if(cmp<0)low=mid+1;
else if(cmp>0)high=mid-1;
else return mid;
}
return-(low+1);
},$fz.isPrivate=true,$fz),"java.util.List,~O");
c$.get=$_M(c$,"get",
($fz=function(i,index){
var obj=null;
var pos=i.nextIndex();
if(pos<=index){
do{
obj=i.next();
}while(pos++<index);
}else{
do{
obj=i.previous();
}while(--pos>index);
}return obj;
},$fz.isPrivate=true,$fz),"java.util.ListIterator,~N");
c$.binarySearch=$_M(c$,"binarySearch",
function(list,key,c){
if(c==null)return java.util.Collections.binarySearch(list,key);
if($_O(list,java.util.RandomAccess)||list.size()<5000)return java.util.Collections.indexedBinarySearch(list,key,c);
else return java.util.Collections.iteratorBinarySearch(list,key,c);
},"java.util.List,~O,java.util.Comparator");
c$.indexedBinarySearch=$_M(c$,"indexedBinarySearch",
($fz=function(l,key,c){
var low=0;
var high=l.size()-1;
while(low<=high){
var mid=(low+high)>>1;
var midVal=l.get(mid);
var cmp=c.compare(midVal,key);
if(cmp<0)low=mid+1;
else if(cmp>0)high=mid-1;
else return mid;
}
return-(low+1);
},$fz.isPrivate=true,$fz),"java.util.List,~O,java.util.Comparator");
c$.iteratorBinarySearch=$_M(c$,"iteratorBinarySearch",
($fz=function(l,key,c){
var low=0;
var high=l.size()-1;
var i=l.listIterator();
while(low<=high){
var mid=(low+high)>>1;
var midVal=java.util.Collections.get(i,mid);
var cmp=c.compare(midVal,key);
if(cmp<0)low=mid+1;
else if(cmp>0)high=mid-1;
else return mid;
}
return-(low+1);
},$fz.isPrivate=true,$fz),"java.util.List,~O,java.util.Comparator");
c$.reverse=$_M(c$,"reverse",
function(list){
var size=list.size();
if(size<18||$_O(list,java.util.RandomAccess)){
for(var i=0,mid=size>>1,j=size-1;i<mid;i++,j--)java.util.Collections.swap(list,i,j);

}else{
var fwd=list.listIterator();
var rev=list.listIterator(size);
for(var i=0,mid=list.size()>>1;i<mid;i++){
var tmp=fwd.next();
fwd.set(rev.previous());
rev.set(tmp);
}
}},"java.util.List");
c$.shuffle=$_M(c$,"shuffle",
function(list){
java.util.Collections.shuffle(list,java.util.Collections.r);
},"java.util.List");
c$.shuffle=$_M(c$,"shuffle",
function(list,rnd){
var size=list.size();
if(size<5||$_O(list,java.util.RandomAccess)){
for(var i=size;i>1;i--)java.util.Collections.swap(list,i-1,rnd.nextInt(i));

}else{
var arr=list.toArray();
for(var i=size;i>1;i--)java.util.Collections.swap(arr,i-1,rnd.nextInt(i));

var it=list.listIterator();
for(var i=0;i<arr.length;i++){
it.next();
it.set(arr[i]);
}
}},"java.util.List,java.util.Random");
c$.swap=$_M(c$,"swap",
function(list,i,j){
list.set(i,list.set(j,list.get(i)));
},"java.util.List,~N,~N");
c$.swap=$_M(c$,"swap",
($fz=function(arr,i,j){
var tmp=arr[i];
arr[i]=arr[j];
arr[j]=tmp;
},$fz.isPrivate=true,$fz),"~A,~N,~N");
c$.fill=$_M(c$,"fill",
function(list,obj){
var size=list.size();
if(size<25||$_O(list,java.util.RandomAccess)){
for(var i=0;i<size;i++)list.set(i,obj);

}else{
var itr=list.listIterator();
for(var i=0;i<size;i++){
itr.next();
itr.set(obj);
}
}},"java.util.List,~O");
c$.copy=$_M(c$,"copy",
function(dest,src){
var srcSize=src.size();
if(srcSize>dest.size())throw new IndexOutOfBoundsException("Source does not fit in dest");
if(srcSize<10||($_O(src,java.util.RandomAccess)&&$_O(dest,java.util.RandomAccess))){
for(var i=0;i<srcSize;i++)dest.set(i,src.get(i));

}else{
var di=dest.listIterator();
var si=src.listIterator();
for(var i=0;i<srcSize;i++){
di.next();
di.set(si.next());
}
}},"java.util.List,java.util.List");
c$.min=$_M(c$,"min",
function(coll){
var i=coll.iterator();
var candidate=(i.next());
while(i.hasNext()){
var next=(i.next());
if(next.compareTo(candidate)<0)candidate=next;
}
return candidate;
},"java.util.Collection");
c$.min=$_M(c$,"min",
function(coll,comp){
if(comp==null)return java.util.Collections.min(coll);
var i=coll.iterator();
var candidate=i.next();
while(i.hasNext()){
var next=i.next();
if(comp.compare(next,candidate)<0)candidate=next;
}
return candidate;
},"java.util.Collection,java.util.Comparator");
c$.max=$_M(c$,"max",
function(coll){
var i=coll.iterator();
var candidate=(i.next());
while(i.hasNext()){
var next=(i.next());
if(next.compareTo(candidate)>0)candidate=next;
}
return candidate;
},"java.util.Collection");
c$.max=$_M(c$,"max",
function(coll,comp){
if(comp==null)return java.util.Collections.max(coll);
var i=coll.iterator();
var candidate=i.next();
while(i.hasNext()){
var next=i.next();
if(comp.compare(next,candidate)>0)candidate=next;
}
return candidate;
},"java.util.Collection,java.util.Comparator");
c$.rotate=$_M(c$,"rotate",
function(list,distance){
if($_O(list,java.util.RandomAccess)||list.size()<100)java.util.Collections.rotate1(list,distance);
else java.util.Collections.rotate2(list,distance);
},"java.util.List,~N");
c$.rotate1=$_M(c$,"rotate1",
($fz=function(list,distance){
var size=list.size();
if(size==0)return;
distance=distance%size;
if(distance<0)distance+=size;
if(distance==0)return;
for(var cycleStart=0,nMoved=0;nMoved!=size;cycleStart++){
var displaced=list.get(cycleStart);
var i=cycleStart;
do{
i+=distance;
if(i>=size)i-=size;
displaced=list.set(i,displaced);
nMoved++;
}while(i!=cycleStart);
}
},$fz.isPrivate=true,$fz),"java.util.List,~N");
c$.rotate2=$_M(c$,"rotate2",
($fz=function(list,distance){
var size=list.size();
if(size==0)return;
var mid=-distance%size;
if(mid<0)mid+=size;
if(mid==0)return;
java.util.Collections.reverse(list.subList(0,mid));
java.util.Collections.reverse(list.subList(mid,size));
java.util.Collections.reverse(list);
},$fz.isPrivate=true,$fz),"java.util.List,~N");
c$.replaceAll=$_M(c$,"replaceAll",
function(list,oldVal,newVal){
var result=false;
var size=list.size();
if(size<11||$_O(list,java.util.RandomAccess)){
if(oldVal==null){
for(var i=0;i<size;i++){
if(list.get(i)==null){
list.set(i,newVal);
result=true;
}}
}else{
for(var i=0;i<size;i++){
if(oldVal.equals(list.get(i))){
list.set(i,newVal);
result=true;
}}
}}else{
var itr=list.listIterator();
if(oldVal==null){
for(var i=0;i<size;i++){
if(itr.next()==null){
itr.set(newVal);
result=true;
}}
}else{
for(var i=0;i<size;i++){
if(oldVal.equals(itr.next())){
itr.set(newVal);
result=true;
}}
}}return result;
},"java.util.List,~O,~O");
c$.indexOfSubList=$_M(c$,"indexOfSubList",
function(source,target){
var sourceSize=source.size();
var targetSize=target.size();
var maxCandidate=sourceSize-targetSize;
if(sourceSize<35||($_O(source,java.util.RandomAccess)&&$_O(target,java.util.RandomAccess))){
nextCand:for(var candidate=0;candidate<=maxCandidate;candidate++){
for(var i=0,j=candidate;i<targetSize;i++,j++)if(!java.util.Collections.eq(target.get(i),source.get(j)))continue nextCand;
return candidate;
}
}else{
var si=source.listIterator();
nextCand:for(var candidate=0;candidate<=maxCandidate;candidate++){
var ti=target.listIterator();
for(var i=0;i<targetSize;i++){
if(!java.util.Collections.eq(ti.next(),si.next())){
for(var j=0;j<i;j++)si.previous();

continue nextCand;}}
return candidate;
}
}return-1;
},"java.util.List,java.util.List");
c$.lastIndexOfSubList=$_M(c$,"lastIndexOfSubList",
function(source,target){
var sourceSize=source.size();
var targetSize=target.size();
var maxCandidate=sourceSize-targetSize;
if(sourceSize<35||$_O(source,java.util.RandomAccess)){
nextCand:for(var candidate=maxCandidate;candidate>=0;candidate--){
for(var i=0,j=candidate;i<targetSize;i++,j++)if(!java.util.Collections.eq(target.get(i),source.get(j)))continue nextCand;
return candidate;
}
}else{
if(maxCandidate<0)return-1;
var si=source.listIterator(maxCandidate);
nextCand:for(var candidate=maxCandidate;candidate>=0;candidate--){
var ti=target.listIterator();
for(var i=0;i<targetSize;i++){
if(!java.util.Collections.eq(ti.next(),si.next())){
if(candidate!=0){
for(var j=0;j<=i+1;j++)si.previous();

}continue nextCand;}}
return candidate;
}
}return-1;
},"java.util.List,java.util.List");
c$.unmodifiableCollection=$_M(c$,"unmodifiableCollection",
function(c){
return new java.util.Collections.UnmodifiableCollection(c);
},"java.util.Collection");
c$.unmodifiableSet=$_M(c$,"unmodifiableSet",
function(s){
return new java.util.Collections.UnmodifiableSet(s);
},"java.util.Set");
c$.unmodifiableSortedSet=$_M(c$,"unmodifiableSortedSet",
function(s){
return new java.util.Collections.UnmodifiableSortedSet(s);
},"java.util.SortedSet");
c$.unmodifiableList=$_M(c$,"unmodifiableList",
function(list){
return($_O(list,java.util.RandomAccess)?new java.util.Collections.UnmodifiableRandomAccessList(list):new java.util.Collections.UnmodifiableList(list));
},"java.util.List");
c$.unmodifiableMap=$_M(c$,"unmodifiableMap",
function(m){
return new java.util.Collections.UnmodifiableMap(m);
},"java.util.Map");
c$.unmodifiableSortedMap=$_M(c$,"unmodifiableSortedMap",
function(m){
return new java.util.Collections.UnmodifiableSortedMap(m);
},"java.util.SortedMap");
c$.synchronizedCollection=$_M(c$,"synchronizedCollection",
function(c){
return new java.util.Collections.SynchronizedCollection(c);
},"java.util.Collection");
c$.synchronizedCollection=$_M(c$,"synchronizedCollection",
function(c,mutex){
return new java.util.Collections.SynchronizedCollection(c,mutex);
},"java.util.Collection,~O");
c$.synchronizedSet=$_M(c$,"synchronizedSet",
function(s){
return new java.util.Collections.SynchronizedSet(s);
},"java.util.Set");
c$.synchronizedSet=$_M(c$,"synchronizedSet",
function(s,mutex){
return new java.util.Collections.SynchronizedSet(s,mutex);
},"java.util.Set,~O");
c$.synchronizedSortedSet=$_M(c$,"synchronizedSortedSet",
function(s){
return new java.util.Collections.SynchronizedSortedSet(s);
},"java.util.SortedSet");
c$.synchronizedList=$_M(c$,"synchronizedList",
function(list){
return($_O(list,java.util.RandomAccess)?new java.util.Collections.SynchronizedRandomAccessList(list):new java.util.Collections.SynchronizedList(list));
},"java.util.List");
c$.synchronizedList=$_M(c$,"synchronizedList",
function(list,mutex){
return($_O(list,java.util.RandomAccess)?new java.util.Collections.SynchronizedRandomAccessList(list,mutex):new java.util.Collections.SynchronizedList(list,mutex));
},"java.util.List,~O");
c$.synchronizedMap=$_M(c$,"synchronizedMap",
function(m){
return new java.util.Collections.SynchronizedMap(m);
},"java.util.Map");
c$.synchronizedSortedMap=$_M(c$,"synchronizedSortedMap",
function(m){
return new java.util.Collections.SynchronizedSortedMap(m);
},"java.util.SortedMap");
c$.singleton=$_M(c$,"singleton",
function(o){
return new java.util.Collections.SingletonSet(o);
},"~O");
c$.singletonList=$_M(c$,"singletonList",
function(o){
return new java.util.Collections.SingletonList(o);
},"~O");
c$.singletonMap=$_M(c$,"singletonMap",
function(key,value){
return new java.util.Collections.SingletonMap(key,value);
},"~O,~O");
c$.nCopies=$_M(c$,"nCopies",
function(n,o){
return new java.util.Collections.CopiesList(n,o);
},"~N,~O");
c$.reverseOrder=$_M(c$,"reverseOrder",
function(){
return java.util.Collections.REVERSE_ORDER;
});
c$.enumeration=$_M(c$,"enumeration",
function(c){
return(function(i$,v$){
if(!$_D("java.util.Collections$1")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.i=null;
$_Z(this,arguments);
},java.util,"Collections$1",null,java.util.Enumeration);
$_Y(c$,function(){
this.i=c.iterator();
});
$_M(c$,"hasMoreElements",
function(){
return this.i.hasNext();
});
$_M(c$,"nextElement",
function(){
return this.i.next();
});
c$=$_P();
}
return $_N(java.util.Collections$1,i$,v$);
})(this,null);
},"java.util.Collection");
c$.list=$_M(c$,"list",
function(e){
var l=new java.util.ArrayList();
while(e.hasMoreElements())l.add(e.nextElement());

return l;
},"java.util.Enumeration");
c$.eq=$_M(c$,"eq",
($fz=function(o1,o2){
return(o1==null?o2==null:o1.equals(o2));
},$fz.isPrivate=true,$fz),"~O,~O");
$_S(c$,
"BINARYSEARCH_THRESHOLD",5000,
"REVERSE_THRESHOLD",18,
"SHUFFLE_THRESHOLD",5,
"FILL_THRESHOLD",25,
"ROTATE_THRESHOLD",100,
"COPY_THRESHOLD",10,
"REPLACEALL_THRESHOLD",11,
"INDEXOFSUBLIST_THRESHOLD",35);
c$.r=c$.prototype.r=new java.util.Random();
c$.EMPTY_SET=c$.prototype.EMPTY_SET=new java.util.Collections.EmptySet();
c$.EMPTY_LIST=c$.prototype.EMPTY_LIST=new java.util.Collections.EmptyList();
c$.EMPTY_MAP=c$.prototype.EMPTY_MAP=new java.util.Collections.EmptyMap();
c$.REVERSE_ORDER=c$.prototype.REVERSE_ORDER=new java.util.Collections.ReverseComparator();
});
