$_L(["java.util.Iterator"],"java.util.ListIterator",null,function(){
$_I(java.util,"ListIterator",java.util.Iterator);
});
