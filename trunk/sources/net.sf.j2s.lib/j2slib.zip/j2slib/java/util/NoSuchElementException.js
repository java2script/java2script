﻿$_L(["java.lang.RuntimeException"],"java.util.NoSuchElementException",null,function(){
c$=$_T(java.util,"NoSuchElementException",RuntimeException);
});
