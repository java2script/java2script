﻿$_L(["java.util.AbstractCollection","$.AbstractMap","$.AbstractSet","$.Iterator","$.Map"],"java.util.IdentityHashMap",["java.io.IOException","java.lang.IllegalArgumentException","$.IllegalStateException","$.InternalError","java.util.ArrayList","$.ConcurrentModificationException","$.NoSuchElementException"],function(){
c$=$_C(function(){
this.table=null;
this.$size=0;
this.modCount=0;
this.threshold=0;
if(!$_D("java.util.IdentityHashMap.IdentityHashMapIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
this.index=0;
this.expectedModCount=0;
this.lastReturnedIndex=-1;
this.indexValid=false;
this.traversalTable=null;
$_Z(this,arguments);
},java.util.IdentityHashMap,"IdentityHashMapIterator",null,java.util.Iterator);
$_Y(c$,function(){
this.index=(this.b$["java.util.IdentityHashMap"].$size!=0?0:this.b$["java.util.IdentityHashMap"].table.length);
this.expectedModCount=this.b$["java.util.IdentityHashMap"].modCount;
this.traversalTable=this.b$["java.util.IdentityHashMap"].table;
});
$_V(c$,"hasNext",
function(){
var a=this.traversalTable;
for(var b=this.index;b<a.length;b+=2){
var c=a[b];
if(c!=null){
this.index=b;
return this.indexValid=true;
}}
this.index=a.length;
return false;
});
$_M(c$,"nextIndex",
function(){
if(this.b$["java.util.IdentityHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
if(!this.indexValid&&!this.hasNext())throw new java.util.NoSuchElementException();
this.indexValid=false;
this.lastReturnedIndex=this.index;
this.index+=2;
return this.lastReturnedIndex;
});
$_V(c$,"remove",
function(){
if(this.lastReturnedIndex==-1)throw new IllegalStateException();
if(this.b$["java.util.IdentityHashMap"].modCount!=this.expectedModCount)throw new java.util.ConcurrentModificationException();
this.expectedModCount=++this.b$["java.util.IdentityHashMap"].modCount;
var a=this.lastReturnedIndex;
this.lastReturnedIndex=-1;
this.b$["java.util.IdentityHashMap"].$size--;
this.index=a;
this.indexValid=false;
var b=this.traversalTable;
var c=b.length;
var d=a;
var e=b[d];
b[d]=null;
b[d+1]=null;
if(b!=this.b$["java.util.IdentityHashMap"].table){
this.b$["java.util.IdentityHashMap"].remove(e);
this.expectedModCount=this.b$["java.util.IdentityHashMap"].modCount;
return;
}var f;
for(var g=java.util.IdentityHashMap.nextKeyIndex(d,c);(f=b[g])!=null;g=java.util.IdentityHashMap.nextKeyIndex(g,c)){
var h=java.util.IdentityHashMap.hash(f,c);
if((g<h&&(h<=d||d<=g))||(h<=d&&d<=g)){
if(g<a&&d>=a&&this.traversalTable==this.b$["java.util.IdentityHashMap"].table){
var i=c-a;
var j=new Array(i);
System.arraycopy(b,a,j,0,i);
this.traversalTable=j;
this.index=0;
}b[d]=f;
b[d+1]=b[g+1];
b[g]=null;
b[g+1]=null;
d=g;
}}
});
c$=$_P();
}
if(!$_D("java.util.IdentityHashMap.KeyIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"KeyIterator",java.util.IdentityHashMap.IdentityHashMapIterator,null,$_N(java.util.IdentityHashMap.IdentityHashMapIterator,this,null,$_G));
$_V(c$,"next",
function(){
return java.util.IdentityHashMap.unmaskNull(this.traversalTable[this.nextIndex()]);
});
c$=$_P();
}
if(!$_D("java.util.IdentityHashMap.ValueIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"ValueIterator",java.util.IdentityHashMap.IdentityHashMapIterator,null,$_N(java.util.IdentityHashMap.IdentityHashMapIterator,this,null,$_G));
$_V(c$,"next",
function(){
return this.traversalTable[this.nextIndex()+1];
});
c$=$_P();
}
if(!$_D("java.util.IdentityHashMap.EntryIterator")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"EntryIterator",java.util.IdentityHashMap.IdentityHashMapIterator,java.util.Map.Entry,$_N(java.util.IdentityHashMap.IdentityHashMapIterator,this,null,$_G));
$_V(c$,"next",
function(){
this.nextIndex();
return this;
});
$_M(c$,"getKey",
function(){
if(this.lastReturnedIndex<0)throw new IllegalStateException("Entry was removed");
return java.util.IdentityHashMap.unmaskNull(this.traversalTable[this.lastReturnedIndex]);
});
$_M(c$,"getValue",
function(){
if(this.lastReturnedIndex<0)throw new IllegalStateException("Entry was removed");
return this.traversalTable[this.lastReturnedIndex+1];
});
$_V(c$,"setValue",
function(a){
if(this.lastReturnedIndex<0)throw new IllegalStateException("Entry was removed");
var b=this.traversalTable[this.lastReturnedIndex+1];
this.traversalTable[this.lastReturnedIndex+1]=a;
if(this.traversalTable!=this.b$["java.util.IdentityHashMap"].table)this.b$["java.util.IdentityHashMap"].put(this.traversalTable[this.lastReturnedIndex],a);
return b;
},"~O");
$_V(c$,"equals",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return b.getKey()==this.getKey()&&b.getValue()==this.getValue();
},"~O");
$_V(c$,"hashCode",
function(){
return System.identityHashCode(this.getKey())^System.identityHashCode(this.getValue());
});
$_V(c$,"toString",
function(){
return this.getKey()+"="+this.getValue();
});
c$=$_P();
}
this.$entrySet=null;
if(!$_D("java.util.IdentityHashMap.KeySet")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"KeySet",java.util.AbstractSet);
$_V(c$,"iterator",
function(){
return $_N(java.util.IdentityHashMap.KeyIterator,this,null);
});
$_V(c$,"size",
function(){
return this.b$["java.util.IdentityHashMap"].$size;
});
$_V(c$,"contains",
function(a){
return this.b$["java.util.IdentityHashMap"].containsKey(a);
},"~O");
$_V(c$,"remove",
function(a){
var b=this.b$["java.util.IdentityHashMap"].$size;
this.b$["java.util.IdentityHashMap"].remove(a);
return this.b$["java.util.IdentityHashMap"].$size!=b;
},"~O");
$_V(c$,"removeAll",
function(a){
var b=false;
for(var c=this.iterator();c.hasNext();){
if(a.contains(c.next())){
c.remove();
b=true;
}}
return b;
},"java.util.Collection");
$_V(c$,"clear",
function(){
this.b$["java.util.IdentityHashMap"].clear();
});
$_V(c$,"hashCode",
function(){
var a=0;
for(var b=this.iterator();b.hasNext();)a+=System.identityHashCode(b.next());

return a;
});
c$=$_P();
}
if(!$_D("java.util.IdentityHashMap.Values")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"Values",java.util.AbstractCollection);
$_V(c$,"iterator",
function(){
return $_N(java.util.IdentityHashMap.ValueIterator,this,null);
});
$_V(c$,"size",
function(){
return this.b$["java.util.IdentityHashMap"].$size;
});
$_V(c$,"contains",
function(a){
return this.b$["java.util.IdentityHashMap"].containsValue(a);
},"~O");
$_V(c$,"remove",
function(a){
for(var b=this.iterator();b.hasNext();){
if(b.next()==a){
b.remove();
return true;
}}
return false;
},"~O");
$_V(c$,"clear",
function(){
this.b$["java.util.IdentityHashMap"].clear();
});
c$=$_P();
}
if(!$_D("java.util.IdentityHashMap.EntrySet")){
$_H();
c$=$_C(function(){
$_B(this,arguments);
$_Z(this,arguments);
},java.util.IdentityHashMap,"EntrySet",java.util.AbstractSet);
$_V(c$,"iterator",
function(){
return $_N(java.util.IdentityHashMap.EntryIterator,this,null);
});
$_V(c$,"contains",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return this.b$["java.util.IdentityHashMap"].containsMapping(b.getKey(),b.getValue());
},"~O");
$_V(c$,"remove",
function(a){
if(!($_O(a,java.util.Map.Entry)))return false;
var b=a;
return this.b$["java.util.IdentityHashMap"].removeMapping(b.getKey(),b.getValue());
},"~O");
$_V(c$,"size",
function(){
return this.b$["java.util.IdentityHashMap"].$size;
});
$_V(c$,"clear",
function(){
this.b$["java.util.IdentityHashMap"].clear();
});
$_V(c$,"removeAll",
function(a){
var b=false;
for(var c=this.iterator();c.hasNext();){
if(a.contains(c.next())){
c.remove();
b=true;
}}
return b;
},"java.util.Collection");
$_M(c$,"toArray",
function(){
var a=new java.util.ArrayList(this.size());
for(var b=this.iterator();b.hasNext();)a.add(new java.util.AbstractMap.SimpleEntry(b.next()));

return a.toArray();
});
$_M(c$,"toArray",
function(a){
var b=new java.util.ArrayList(this.size());
for(var c=this.iterator();c.hasNext();)b.add(new java.util.AbstractMap.SimpleEntry(c.next()));

return b.toArray(a);
},"~A");
c$=$_P();
}
$_Z(this,arguments);
},java.util,"IdentityHashMap",java.util.AbstractMap,[java.util.Map,java.io.Serializable,Cloneable]);
c$.maskNull=$_M(c$,"maskNull",
($fz=function(key){
return(key==null?java.util.IdentityHashMap.NULL_KEY:key);
},$fz.isPrivate=true,$fz),"~O");
c$.unmaskNull=$_M(c$,"unmaskNull",
($fz=function(key){
return(key==java.util.IdentityHashMap.NULL_KEY?null:key);
},$fz.isPrivate=true,$fz),"~O");
$_K(c$,
function(){
$_R(this,java.util.IdentityHashMap,[]);
this.init(32);
});
$_K(c$,
function(expectedMaxSize){
$_R(this,java.util.IdentityHashMap,[]);
if(expectedMaxSize<0)throw new IllegalArgumentException("expectedMaxSize is negative: "+expectedMaxSize);
this.init(this.capacity(expectedMaxSize));
},"~N");
$_M(c$,"capacity",
($fz=function(expectedMaxSize){
var minCapacity=Math.floor((3*expectedMaxSize)/2);
var result;
if(minCapacity>536870912||minCapacity<0){
result=536870912;
}else{
result=4;
while(result<minCapacity)result<<=1;

}return result;
},$fz.isPrivate=true,$fz),"~N");
$_M(c$,"init",
($fz=function(initCapacity){
this.threshold=Math.floor((initCapacity*2)/3);
this.table=new Array(2*initCapacity);
},$fz.isPrivate=true,$fz),"~N");
$_K(c$,
function(m){
this.construct(Math.round(((1+m.size())*1.1)));
this.putAll(m);
},"java.util.Map");
$_M(c$,"size",
function(){
return this.$size;
});
$_V(c$,"isEmpty",
function(){
return this.$size==0;
});
c$.hash=$_M(c$,"hash",
($fz=function(x,length){
var h=System.identityHashCode(x);
return((h<<1)-(h<<8))&(length-1);
},$fz.isPrivate=true,$fz),"~O,~N");
c$.nextKeyIndex=$_M(c$,"nextKeyIndex",
($fz=function(i,len){
return(i+2<len?i+2:0);
},$fz.isPrivate=true,$fz),"~N,~N");
$_V(c$,"get",
function(key){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
while(true){
var item=tab[i];
if(item==k)return tab[i+1];
if(item==null)return item;
i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
},"~O");
$_V(c$,"containsKey",
function(key){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
while(true){
var item=tab[i];
if(item==k)return true;
if(item==null)return false;
i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
},"~O");
$_V(c$,"containsValue",
function(value){
var tab=this.table;
for(var i=1;i<tab.length;i+=2)if(tab[i]==value)return true;

return false;
},"~O");
$_M(c$,"containsMapping",
($fz=function(key,value){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
while(true){
var item=tab[i];
if(item==k)return tab[i+1]==value;
if(item==null)return false;
i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
},$fz.isPrivate=true,$fz),"~O,~O");
$_V(c$,"put",
function(key,value){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
var item;
while((item=tab[i])!=null){
if(item==k){
var oldValue=tab[i+1];
tab[i+1]=value;
return oldValue;
}i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
this.modCount++;
tab[i]=k;
tab[i+1]=value;
if(++this.$size>=this.threshold)this.resize(len);
return null;
},"~O,~O");
$_M(c$,"resize",
($fz=function(newCapacity){
var newLength=newCapacity*2;
var oldTable=this.table;
var oldLength=oldTable.length;
if(oldLength==1073741824){
if(this.threshold==536870911)throw new IllegalStateException("Capacity exhausted.");
this.threshold=536870911;
return;
}if(oldLength>=newLength)return;
var newTable=new Array(newLength);
this.threshold=Math.floor(newLength/3);
for(var j=0;j<oldLength;j+=2){
var key=oldTable[j];
if(key!=null){
var value=oldTable[j+1];
oldTable[j]=null;
oldTable[j+1]=null;
var i=java.util.IdentityHashMap.hash(key,newLength);
while(newTable[i]!=null)i=java.util.IdentityHashMap.nextKeyIndex(i,newLength);

newTable[i]=key;
newTable[i+1]=value;
}}
this.table=newTable;
},$fz.isPrivate=true,$fz),"~N");
$_V(c$,"putAll",
function(t){
var n=t.size();
if(n==0)return;
if(n>this.threshold)this.resize(this.capacity(n));
for(var it=t.entrySet().iterator();it.hasNext();){
var e=it.next();
this.put(e.getKey(),e.getValue());
}
},"java.util.Map");
$_V(c$,"remove",
function(key){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
while(true){
var item=tab[i];
if(item==k){
this.modCount++;
this.$size--;
var oldValue=tab[i+1];
tab[i+1]=null;
tab[i]=null;
this.closeDeletion(i);
return oldValue;
}if(item==null)return null;
i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
},"~O");
$_M(c$,"removeMapping",
($fz=function(key,value){
var k=java.util.IdentityHashMap.maskNull(key);
var tab=this.table;
var len=tab.length;
var i=java.util.IdentityHashMap.hash(k,len);
while(true){
var item=tab[i];
if(item==k){
if(tab[i+1]!=value)return false;
this.modCount++;
this.$size--;
tab[i]=null;
tab[i+1]=null;
this.closeDeletion(i);
return true;
}if(item==null)return false;
i=java.util.IdentityHashMap.nextKeyIndex(i,len);
}
},$fz.isPrivate=true,$fz),"~O,~O");
$_M(c$,"closeDeletion",
($fz=function(d){
var tab=this.table;
var len=tab.length;
var item;
for(var i=java.util.IdentityHashMap.nextKeyIndex(d,len);(item=tab[i])!=null;i=java.util.IdentityHashMap.nextKeyIndex(i,len)){
var r=java.util.IdentityHashMap.hash(item,len);
if((i<r&&(r<=d||d<=i))||(r<=d&&d<=i)){
tab[d]=item;
tab[d+1]=tab[i+1];
tab[i]=null;
tab[i+1]=null;
d=i;
}}
},$fz.isPrivate=true,$fz),"~N");
$_V(c$,"clear",
function(){
this.modCount++;
var tab=this.table;
for(var i=0;i<tab.length;i++)tab[i]=null;

this.$size=0;
});
$_V(c$,"equals",
function(o){
if(o==this){
return true;
}else if($_O(o,java.util.IdentityHashMap)){
var m=o;
if(m.size()!=this.$size)return false;
var tab=m.table;
for(var i=0;i<tab.length;i+=2){
var k=tab[i];
if(k!=null&&!this.containsMapping(k,tab[i+1]))return false;
}
return true;
}else if($_O(o,java.util.Map)){
var m=o;
return this.entrySet().equals(m.entrySet());
}else{
return false;
}},"~O");
$_V(c$,"hashCode",
function(){
var result=0;
var tab=this.table;
for(var i=0;i<tab.length;i+=2){
var key=tab[i];
if(key!=null){
var k=java.util.IdentityHashMap.unmaskNull(key);
result+=System.identityHashCode(k)^System.identityHashCode(tab[i+1]);
}}
return result;
});
$_M(c$,"clone",
function(){
try{
var t=$_U(this,java.util.IdentityHashMap,"clone",[]);
t.$entrySet=null;
t.table=(this.table.clone());
return t;
}catch(e){
if($_O(e,CloneNotSupportedException)){
throw new InternalError();
}else{
throw e;
}
}
});
$_V(c$,"keySet",
function(){
var ks=this.$keySet;
if(ks!=null)return ks;
else return this.$keySet=$_N(java.util.IdentityHashMap.KeySet,this,null);
});
$_V(c$,"values",
function(){
var vs=this.$values;
if(vs!=null)return vs;
else return this.$values=$_N(java.util.IdentityHashMap.Values,this,null);
});
$_M(c$,"entrySet",
function(){
var es=this.$entrySet;
if(es!=null)return es;
else return this.$entrySet=$_N(java.util.IdentityHashMap.EntrySet,this,null);
});
$_S(c$,
"DEFAULT_CAPACITY",32,
"MINIMUM_CAPACITY",4,
"MAXIMUM_CAPACITY",536870912);
c$.NULL_KEY=c$.prototype.NULL_KEY=new Object();
});
