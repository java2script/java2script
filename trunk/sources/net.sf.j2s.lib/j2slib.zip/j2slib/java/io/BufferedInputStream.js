﻿$_L(["java.io.FilterInputStream"],"java.io.BufferedInputStream",["java.io.IOException","java.lang.IllegalArgumentException","$.IndexOutOfBoundsException"],function(){
c$=$_C(function(){
this.buf=null;
this.count=0;
this.pos=0;
this.markpos=-1;
this.marklimit=0;
$_Z(this,arguments);
},java.io,"BufferedInputStream",java.io.FilterInputStream);
$_M(c$,"ensureOpen",
($fz=function(){
if(this.$in==null)throw new java.io.IOException("Stream closed");
},$fz.isPrivate=true,$fz));
$_K(c$,
function($in){
this.construct($in,java.io.BufferedInputStream.defaultBufferSize);
},"java.io.InputStream");
$_K(c$,
function($in,size){
$_R(this,java.io.BufferedInputStream,[$in]);
if(size<=0){
throw new IllegalArgumentException("Buffer size <= 0");
}this.buf=$_A(size,0);
},"java.io.InputStream,~N");
$_M(c$,"fill",
($fz=function(){
if(this.markpos<0)this.pos=0;
else if(this.pos>=this.buf.length)if(this.markpos>0){
var sz=this.pos-this.markpos;
System.arraycopy(this.buf,this.markpos,this.buf,0,sz);
this.pos=sz;
this.markpos=0;
}else if(this.buf.length>=this.marklimit){
this.markpos=-1;
this.pos=0;
}else{
var nsz=this.pos*2;
if(nsz>this.marklimit)nsz=this.marklimit;
var nbuf=$_A(nsz,0);
System.arraycopy(this.buf,0,nbuf,0,this.pos);
this.buf=nbuf;
}this.count=this.pos;
var n=this.$in.read(this.buf,this.pos,this.buf.length-this.pos);
if(n>0)this.count=n+this.pos;
},$fz.isPrivate=true,$fz));
$_M(c$,"read",
function(){
this.ensureOpen();
if(this.pos>=this.count){
this.fill();
if(this.pos>=this.count)return-1;
}return this.buf[this.pos++]&0xff;
});
$_M(c$,"read1",
($fz=function(b,off,len){
var avail=this.count-this.pos;
if(avail<=0){
if(len>=this.buf.length&&this.markpos<0){
return this.$in.read(b,off,len);
}this.fill();
avail=this.count-this.pos;
if(avail<=0)return-1;
}var cnt=(avail<len)?avail:len;
System.arraycopy(this.buf,this.pos,b,off,cnt);
this.pos+=cnt;
return cnt;
},$fz.isPrivate=true,$fz),"~A,~N,~N");
$_M(c$,"read",
function(b,off,len){
this.ensureOpen();
if((off|len|(off+len)|(b.length-(off+len)))<0){
throw new IndexOutOfBoundsException();
}else if(len==0){
return 0;
}var n=this.read1(b,off,len);
if(n<=0)return n;
while((n<len)&&(this.$in.available()>0)){
var n1=this.read1(b,off+n,len-n);
if(n1<=0)break;
n+=n1;
}
return n;
},"~A,~N,~N");
$_V(c$,"skip",
function(n){
this.ensureOpen();
if(n<=0){
return 0;
}var avail=this.count-this.pos;
if(avail<=0){
if(this.markpos<0)return this.$in.skip(n);
this.fill();
avail=this.count-this.pos;
if(avail<=0)return 0;
}var skipped=(avail<n)?avail:n;
this.pos+=skipped;
return skipped;
},"~N");
$_V(c$,"available",
function(){
this.ensureOpen();
return(this.count-this.pos)+this.$in.available();
});
$_V(c$,"mark",
function(readlimit){
this.marklimit=readlimit;
this.markpos=this.pos;
},"~N");
$_V(c$,"reset",
function(){
this.ensureOpen();
if(this.markpos<0)throw new java.io.IOException("Resetting to invalid mark");
this.pos=this.markpos;
});
$_V(c$,"markSupported",
function(){
return true;
});
$_V(c$,"close",
function(){
if(this.$in==null)return;
this.$in.close();
this.$in=null;
this.buf=null;
});
$_S(c$,
"defaultBufferSize",2048);
});
