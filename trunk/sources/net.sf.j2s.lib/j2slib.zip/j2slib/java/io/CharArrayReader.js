﻿$_L(["java.io.Reader"],"java.io.CharArrayReader",["java.io.IOException","java.lang.IllegalArgumentException","$.IndexOutOfBoundsException"],function(){
c$=$_C(function(){
this.buf=null;
this.pos=0;
this.markedPos=0;
this.count=0;
$_Z(this,arguments);
},java.io,"CharArrayReader",java.io.Reader);
$_K(c$,
function(buf){
$_R(this,java.io.CharArrayReader,[]);
this.buf=buf;
this.pos=0;
this.count=buf.length;
},"~A");
$_K(c$,
function(buf,offset,length){
$_R(this,java.io.CharArrayReader,[]);
if((offset<0)||(offset>buf.length)||(length<0)||((offset+length)<0)){
throw new IllegalArgumentException();
}this.buf=buf;
this.pos=offset;
this.count=Math.min(offset+length,buf.length);
this.markedPos=offset;
},"~A,~N,~N");
$_M(c$,"ensureOpen",
($fz=function(){
if(this.buf==null)throw new java.io.IOException("Stream closed");
},$fz.isPrivate=true,$fz));
$_M(c$,"read",
function(){
{
this.ensureOpen();
if(this.pos>=this.count)return-1;
else return this.buf[this.pos++];
}});
$_M(c$,"read",
function(b,off,len){
{
this.ensureOpen();
if((off<0)||(off>b.length)||(len<0)||((off+len)>b.length)||((off+len)<0)){
throw new IndexOutOfBoundsException();
}else if(len==0){
return 0;
}if(this.pos>=this.count){
return-1;
}if(this.pos+len>this.count){
len=this.count-this.pos;
}if(len<=0){
return 0;
}System.arraycopy(this.buf,this.pos,b,off,len);
this.pos+=len;
return len;
}},"~A,~N,~N");
$_V(c$,"skip",
function(n){
{
this.ensureOpen();
if(this.pos+n>this.count){
n=this.count-this.pos;
}if(n<0){
return 0;
}this.pos+=n;
return n;
}},"~N");
$_V(c$,"ready",
function(){
{
this.ensureOpen();
return(this.count-this.pos)>0;
}});
$_V(c$,"markSupported",
function(){
return true;
});
$_V(c$,"mark",
function(readAheadLimit){
{
this.ensureOpen();
this.markedPos=this.pos;
}},"~N");
$_V(c$,"reset",
function(){
{
this.ensureOpen();
this.pos=this.markedPos;
}});
$_V(c$,"close",
function(){
this.buf=null;
});
});
