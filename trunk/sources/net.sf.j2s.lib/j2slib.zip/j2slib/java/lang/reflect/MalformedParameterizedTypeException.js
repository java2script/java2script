$_L(["java.lang.RuntimeException"],"java.lang.reflect.MalformedParameterizedTypeException",null,function(){
c$=$_T(reflect,"MalformedParameterizedTypeException",RuntimeException);
});
