/*
 * @author Zhou Renjian (zhourenjian@gmail.com)
 * Aug 31, 2006
 */
ClazzUtils = new Object ();
ClazzUtils.aopWrapFunction = function (func, aopFuncBefore, aopFuncAfter, objThis, args) {
	var ct = new Object ();
	if (aopFuncBefore != null) {
		aopFuncBefore (ct);
	}
	var ret = func.apply (objThis, args);
	if (aopFuncAfter != null) {
		aopFuncAfter (ct);
	}
	return ret;
};

/* private */
ClazzUtils.context = function () {
	return arguments.callee.caller.arguments[0];
};

ClazzUtils.wrap = function (oThis, methodName, before, after) {
	var func = oThis[methodName];
	oThis[methodName] = function () {
		var args = new Array ();
		for (var i = 0; i < arguments.length; i++) {
			args[i] = arguments[i];
		}
		return ClazzUtils.aopWrapFunction (func, before, after, oThis, args);
	};
	if (oThis == window["Clazz"]) {
		for (var x in window) {
			if (x.indexOf ("$_") == 0 && window[x] == func) {
				window[x] = oThis[methodName];
				break;
			}
		}
	}
};


ClazzUtils.ignoredMethods = [
		/*
		"searchMethod",
		"tryToSearchAndExecute",
		"searchAndExecuteMethod",
		"SAEM"
		*/
"getClassName",
"getClass",
"extendsProperties",
"checkInnerFunction",
"implementsProperties",
//"args4InheritClass",
"inheritClass",
"implementOf",
"extendInterface",
"equalsOrExtendsLevel",
"getInheritedLevel",
"instanceOf",
"superCall",
"superConstructor",
"CastedNull",
"castNullAs",
"MethodException",
"MethodNotFoundException",
"getParamsType",
"generateDelegatingMethod",
"formatParameters",
"overrideMethod",
"defineMethod",
"makeConstructor",
"declarePackage",
"evalType",
"defineType",
"instantialize",
"decorateFunction",
"declareInterface",
"decorateAsClass",
"declareType",
"declareAnonymous",
"decorateAsType",
"prepareCallback",
"innerTypeInstance",
"cloneFinals",
"isDefinedClass",
"isClassDefined",
"defineEnumConstant",
"newArray",
"makeFunction",
"defineStatics",
"prepareFields",
//"getMixedCallerMethod",
//"checkPrivateMethod",
"pu$h",
"p0p",
//"callingStack",
"pu$hCalling",
"p0pCalling",
"addBinaryFolder",
"removeBinaryFolder",
"setPrimaryFolder",
"load",
"forName",
"registerCSS",
//"equals",
//"hashCode",
//"clone",
//"finalize",
//"notify",
//"notifyAll",
//"wait",		
];
//ClazzUtils.includedMethods =

ClazzUtils.allMethodAnalytics = new Object ();

ClazzUtils.enableClazzAnalytics = function () {
	for (var m in Clazz) {
		if (typeof Clazz[m] == "function" && Clazz[m].__CLASS_NAME__ == null) {
			var shouldBeIgnored = false;
			for (var i = 0; i < ClazzUtils.ignoredMethods.length; i++) {
				if (m == ClazzUtils.ignoredMethods[i]) {
					shouldBeIgnored = true;
					break;
				}
			}
			if (!shouldBeIgnored) {
				continue;
			}
			ClazzUtils.wrap (Clazz, m, (function (m) {return function () {
				if (ClazzUtils.allMethodAnalytics["$$" + m] == null) {
					var k = new Object ();
					k.name = m;
					k.time = 0;
					k.hits = 0;
					k.toString = function () {
						return "Clazz." + this.name + " :" 
								+ this.time + "/" + this.hits + " = " 
								+ (this.time / this.hits);
					};
					ClazzUtils.allMethodAnalytics["$$" + m] = k;
				}
				var o = ClazzUtils.context ();
				o.time = new Date ();
			};})(m), (function (m) {return function () {
				var o = ClazzUtils.context ();
				var k = ClazzUtils.allMethodAnalytics["$$" + m];
				k.time += new Date ().getTime () 
						- o.time.getTime ();
				k.hits++;
			};})(m));
		}
	}
};

ClazzUtils.outputClazzAnalytics = function () {
	log ("Clazz analytics:");
	var arr = new Array ();
	for (var m in ClazzUtils.allMethodAnalytics) {
		if (m.indexOf ("$$") == 0) {
			//log (ClazzUtils.allMethodAnalytics[m]);
			arr[arr.length] = ClazzUtils.allMethodAnalytics[m];
		}
	}
	arr.sort (function (m1, m2) {
		var tph1 = m1.time / m1.hits;
		var tph2 = m2.time / m2.hits;
		return tph1 - tph2;
	});
	log ("-----------");
	log (arr.join ("\r\n"));
	arr.sort (function (m1, m2) {
		return m1.time - m2.time;
	});
	log ("===========");
	log (arr.join ("\r\n"));
	arr.sort (function (m1, m2) {
		return m1.hits - m2.hits;
	});
	log ("===========");
	log (arr.join ("\r\n"));
};

ClazzUtils.allLoaderMethodAnalytics = new Object ();

ClazzUtils.enableClazzLoaderAnalytics = function () {
	for (var m in ClazzLoader) {
		if (typeof ClazzLoader[m] == "function" && ClazzLoader[m].__CLASS_NAME__ == null) {
			ClazzUtils.wrap (ClazzLoader, m, (function (m) {return function () {
				if (ClazzUtils.allLoaderMethodAnalytics["$$" + m] == null) {
					var k = new Object ();
					k.name = m;
					k.time = 0;
					k.hits = 0;
					k.toString = function () {
						return "ClazzLoader." + this.name + " :" 
								+ this.time + "/" + this.hits + " = " 
								+ (this.time / this.hits);
					};
					ClazzUtils.allLoaderMethodAnalytics["$$" + m] = k;
				}
				var o = ClazzUtils.context ();
				o.time = new Date ();
			};})(m), (function (m) {return function () {
				var o = ClazzUtils.context ();
				var k = ClazzUtils.allLoaderMethodAnalytics["$$" + m];
				k.time += new Date ().getTime () 
						- o.time.getTime ();
				k.hits++;
			};})(m));
		}
	}
};

ClazzUtils.outputClazzLoaderAnalytics = function () {
	log ("ClazzLoader analytics:");
	var arr = new Array ();
	for (var m in ClazzUtils.allLoaderMethodAnalytics) {
		if (m.indexOf ("$$") == 0) {
			//log (ClazzUtils.allLoaderMethodAnalytics[m]);
			arr[arr.length] = ClazzUtils.allLoaderMethodAnalytics[m];
		}
	}
	arr.sort (function (m1, m2) {
		var tph1 = m1.time / m1.hits;
		var tph2 = m2.time / m2.hits;
		return tph1 - tph2;
	});
	log ("-----------");
	log (arr.join ("\r\n"));
	arr.sort (function (m1, m2) {
		return m1.time - m2.time;
	});
	log ("===========");
	log (arr.join ("\r\n"));
	arr.sort (function (m1, m2) {
		return m1.hits - m2.hits;
	});
	log ("===========");
	log (arr.join ("\r\n"));
};
