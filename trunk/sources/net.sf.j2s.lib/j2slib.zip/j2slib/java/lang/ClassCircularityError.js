$_L(["java.lang.LinkageError"],"java.lang.ClassCircularityError",null,function(){
c$=$_T(java.lang,"ClassCircularityError",LinkageError);
});
