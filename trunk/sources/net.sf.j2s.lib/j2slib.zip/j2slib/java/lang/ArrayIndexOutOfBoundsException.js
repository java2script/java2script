$_L(["java.lang.IndexOutOfBoundsException"],"java.lang.ArrayIndexOutOfBoundsException",null,function(){
c$=$_T(java.lang,"ArrayIndexOutOfBoundsException",IndexOutOfBoundsException);
});
