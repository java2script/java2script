﻿$_J("java.text");
c$=$_T(java.text,"MessageFormat");
$_K(c$,
function(pattern){
},"~S");
$_K(c$,
function(pattern,locale){
},"~S,java.util.Locale");
c$.format=$_M(c$,"format",
function(pattern,$arguments){
return pattern;
},"~S,~A");
$_M(c$,"format",
function(obj){
return obj.toString();
},"~O");
