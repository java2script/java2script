﻿Clazz.declarePackage ("junit.awtui");
Clazz.load (["junit.runner.BaseTestRunner", "java.awt.Font"], "junit.awtui.TestRunner", ["java.awt.BorderLayout", "$.Button", "$.Checkbox", "$.Color", "$.Frame", "$.GridBagConstraints", "$.GridBagLayout", "$.GridLayout", "$.Insets", "$.Label", "$.List", "$.Menu", "$.MenuBar", "$.MenuItem", "$.Panel", "$.SystemColor", "$.TextArea", "$.TextField", "$.Toolkit", "java.awt.event.ActionListener", "$.ItemListener", "$.TextListener", "$.WindowAdapter", "java.awt.image.ImageProducer", "java.lang.Thread", "java.util.Vector", "junit.awtui.AboutDialog", "$.Logo", "$.ProgressBar", "junit.framework.TestResult", "$.TestSuite"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fFrame = null;
this.fExceptions = null;
this.fFailedTests = null;
this.fRunner = null;
this.fTestResult = null;
this.fTraceArea = null;
this.fSuiteField = null;
this.fRun = null;
this.fProgressIndicator = null;
this.fFailureList = null;
this.fLogo = null;
this.fNumberOfErrors = null;
this.fNumberOfFailures = null;
this.fNumberOfRuns = null;
this.fQuitButton = null;
this.fRerunButton = null;
this.fStatusLine = null;
this.fUseLoadingRunner = null;
Clazz.instantialize (this, arguments);
}, junit.awtui, "TestRunner", junit.runner.BaseTestRunner);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.awtui.TestRunner, []);
});
Clazz.defineMethod (c$, "about", 
($fz = function () {
var about =  new junit.awtui.AboutDialog (this.fFrame);
about.setModal (true);
about.setLocation (300, 300);
about.setVisible (true);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "testStarted", 
function (testName) {
this.showInfo ("Running: " + testName);
}, "~S");
Clazz.overrideMethod (c$, "testEnded", 
function (testName) {
this.setLabelValue (this.fNumberOfRuns, this.fTestResult.runCount ());
{
this.fProgressIndicator.step (this.fTestResult.wasSuccessful ());
}}, "~S");
Clazz.overrideMethod (c$, "testFailed", 
function (status, test, t) {
switch (status) {
case 1:
this.fNumberOfErrors.setText (Integer.toString (this.fTestResult.errorCount ()));
this.appendFailure ("Error", test, t);
break;
case 2:
this.fNumberOfFailures.setText (Integer.toString (this.fTestResult.failureCount ()));
this.appendFailure ("Failure", test, t);
break;
}
}, "~N,junit.framework.Test,Throwable");
Clazz.defineMethod (c$, "addGrid", 
function (p, co, x, y, w, fill, wx, anchor) {
var c =  new java.awt.GridBagConstraints ();
c.gridx = x;
c.gridy = y;
c.gridwidth = w;
c.anchor = anchor;
c.weightx = wx;
c.fill = fill;
if (fill == 1 || fill == 3) c.weighty = 1.0;
c.insets =  new java.awt.Insets (y == 0 ? 4 : 0, x == 0 ? 4 : 0, 4, 4);
p.add (co, c);
}, "java.awt.Panel,java.awt.Component,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "appendFailure", 
($fz = function (kind, test, t) {
kind += ": " + test;
var msg = t.getMessage ();
if (msg != null) {
kind += ":" + junit.runner.BaseTestRunner.truncate (msg);
}this.fFailureList.add (kind);
this.fExceptions.addElement (t);
this.fFailedTests.addElement (test);
if (this.fFailureList.getItemCount () == 1) {
this.fFailureList.select (0);
this.failureSelected ();
}}, $fz.isPrivate = true, $fz), "~S,junit.framework.Test,Throwable");
Clazz.defineMethod (c$, "createJUnitMenu", 
function () {
var menu =  new java.awt.Menu ("JUnit");
var mi =  new java.awt.MenuItem ("About...");
mi.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$1", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (event) {
this.b$["junit.awtui.TestRunner"].about ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$1, i$, v$);
}) (this, null));
menu.add (mi);
menu.addSeparator ();
mi =  new java.awt.MenuItem ("Exit");
mi.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$2")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$2", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (event) {
System.exit (0);
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$2, i$, v$);
}) (this, null));
menu.add (mi);
return menu;
});
Clazz.defineMethod (c$, "createMenus", 
function (mb) {
mb.add (this.createJUnitMenu ());
}, "java.awt.MenuBar");
Clazz.defineMethod (c$, "createTestResult", 
function () {
return  new junit.framework.TestResult ();
});
Clazz.defineMethod (c$, "createUI", 
function (suiteName) {
var frame =  new java.awt.Frame ("JUnit");
var icon = this.loadFrameIcon ();
if (icon != null) frame.setIconImage (icon);
frame.setLayout ( new java.awt.BorderLayout (0, 0));
frame.setBackground (java.awt.SystemColor.control);
var finalFrame = frame;
frame.addWindowListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$3")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$3", java.awt.event.WindowAdapter);
Clazz.overrideMethod (c$, "windowClosing", 
function (e) {
this.f$.finalFrame.dispose ();
System.exit (0);
}, "java.awt.event.WindowEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$3, i$, v$);
}) (this, Clazz.cloneFinals ("finalFrame", finalFrame)));
var mb =  new java.awt.MenuBar ();
this.createMenus (mb);
frame.setMenuBar (mb);
var suiteLabel =  new java.awt.Label ("Test class name:");
this.fSuiteField =  new java.awt.TextField (suiteName != null ? suiteName : "");
this.fSuiteField.selectAll ();
this.fSuiteField.requestFocus ();
this.fSuiteField.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fSuiteField.setColumns (40);
this.fSuiteField.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$4")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$4", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.awtui.TestRunner"].runSuite ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$4, i$, v$);
}) (this, null));
this.fSuiteField.addTextListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$5")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$5", null, java.awt.event.TextListener);
Clazz.overrideMethod (c$, "textValueChanged", 
function (e) {
this.b$["junit.awtui.TestRunner"].fRun.setEnabled (this.b$["junit.awtui.TestRunner"].fSuiteField.getText ().length > 0);
this.b$["junit.awtui.TestRunner"].fStatusLine.setText ("");
}, "java.awt.event.TextEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$5, i$, v$);
}) (this, null));
this.fRun =  new java.awt.Button ("Run");
this.fRun.setEnabled (false);
this.fRun.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$6")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$6", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.awtui.TestRunner"].runSuite ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$6, i$, v$);
}) (this, null));
var useLoader = this.useReloadingTestSuiteLoader ();
this.fUseLoadingRunner =  new java.awt.Checkbox ("Reload classes every run", useLoader);
if (junit.runner.BaseTestRunner.inVAJava ()) this.fUseLoadingRunner.setVisible (false);
this.fProgressIndicator =  new junit.awtui.ProgressBar ();
this.fNumberOfErrors =  new java.awt.Label ("0000", 2);
this.fNumberOfErrors.setText ("0");
this.fNumberOfErrors.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fNumberOfFailures =  new java.awt.Label ("0000", 2);
this.fNumberOfFailures.setText ("0");
this.fNumberOfFailures.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fNumberOfRuns =  new java.awt.Label ("0000", 2);
this.fNumberOfRuns.setText ("0");
this.fNumberOfRuns.setFont (junit.awtui.TestRunner.PLAIN_FONT);
var numbersPanel = this.createCounterPanel ();
var failureLabel =  new java.awt.Label ("Errors and Failures:");
this.fFailureList =  new java.awt.List (5);
this.fFailureList.addItemListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$7")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$7", null, java.awt.event.ItemListener);
Clazz.overrideMethod (c$, "itemStateChanged", 
function (e) {
this.b$["junit.awtui.TestRunner"].failureSelected ();
}, "java.awt.event.ItemEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$7, i$, v$);
}) (this, null));
this.fRerunButton =  new java.awt.Button ("Run");
this.fRerunButton.setEnabled (false);
this.fRerunButton.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$8")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$8", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.awtui.TestRunner"].rerun ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$8, i$, v$);
}) (this, null));
var failedPanel =  new java.awt.Panel ( new java.awt.GridLayout (0, 1, 0, 2));
failedPanel.add (this.fRerunButton);
this.fTraceArea =  new java.awt.TextArea ();
this.fTraceArea.setRows (5);
this.fTraceArea.setColumns (60);
this.fStatusLine =  new java.awt.TextField ();
this.fStatusLine.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fStatusLine.setEditable (false);
this.fStatusLine.setForeground (java.awt.Color.red);
this.fQuitButton =  new java.awt.Button ("Exit");
this.fQuitButton.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$9")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$9", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
System.exit (0);
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$9, i$, v$);
}) (this, null));
this.fLogo =  new junit.awtui.Logo ();
var panel =  new java.awt.Panel ( new java.awt.GridBagLayout ());
this.addGrid (panel, suiteLabel, 0, 0, 2, 2, 1.0, 17);
this.addGrid (panel, this.fSuiteField, 0, 1, 2, 2, 1.0, 17);
this.addGrid (panel, this.fRun, 2, 1, 1, 2, 0.0, 10);
this.addGrid (panel, this.fUseLoadingRunner, 0, 2, 2, 0, 1.0, 17);
this.addGrid (panel, this.fProgressIndicator, 0, 3, 2, 2, 1.0, 17);
this.addGrid (panel, this.fLogo, 2, 3, 1, 0, 0.0, 11);
this.addGrid (panel, numbersPanel, 0, 4, 2, 0, 0.0, 17);
this.addGrid (panel, failureLabel, 0, 5, 2, 2, 1.0, 17);
this.addGrid (panel, this.fFailureList, 0, 6, 2, 1, 1.0, 17);
this.addGrid (panel, failedPanel, 2, 6, 1, 2, 0.0, 10);
this.addGrid (panel, this.fTraceArea, 0, 7, 2, 1, 1.0, 17);
this.addGrid (panel, this.fStatusLine, 0, 8, 2, 2, 1.0, 10);
this.addGrid (panel, this.fQuitButton, 2, 8, 1, 2, 0.0, 10);
frame.add (panel, java.awt.BorderLayout.CENTER);
frame.pack ();
return frame;
}, "~S");
Clazz.defineMethod (c$, "createCounterPanel", 
function () {
var numbersPanel =  new java.awt.Panel ( new java.awt.GridBagLayout ());
this.addToCounterPanel (numbersPanel,  new java.awt.Label ("Runs:"), 0, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 0, 0, 0));
this.addToCounterPanel (numbersPanel, this.fNumberOfRuns, 1, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 40));
this.addToCounterPanel (numbersPanel,  new java.awt.Label ("Errors:"), 2, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 8, 0, 0));
this.addToCounterPanel (numbersPanel, this.fNumberOfErrors, 3, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 40));
this.addToCounterPanel (numbersPanel,  new java.awt.Label ("Failures:"), 4, 0, 1, 1, 0.0, 0.0, 10, 0,  new java.awt.Insets (0, 8, 0, 0));
this.addToCounterPanel (numbersPanel, this.fNumberOfFailures, 5, 0, 1, 1, 0.33, 0.0, 10, 2,  new java.awt.Insets (0, 8, 0, 0));
return numbersPanel;
});
Clazz.defineMethod (c$, "addToCounterPanel", 
($fz = function (counter, comp, gridx, gridy, gridwidth, gridheight, weightx, weighty, anchor, fill, insets) {
var constraints =  new java.awt.GridBagConstraints ();
constraints.gridx = gridx;
constraints.gridy = gridy;
constraints.gridwidth = gridwidth;
constraints.gridheight = gridheight;
constraints.weightx = weightx;
constraints.weighty = weighty;
constraints.anchor = anchor;
constraints.fill = fill;
constraints.insets = insets;
counter.add (comp, constraints);
}, $fz.isPrivate = true, $fz), "java.awt.Panel,java.awt.Component,~N,~N,~N,~N,~N,~N,~N,~N,java.awt.Insets");
Clazz.defineMethod (c$, "failureSelected", 
function () {
this.fRerunButton.setEnabled (this.isErrorSelected ());
this.showErrorTrace ();
});
Clazz.defineMethod (c$, "isErrorSelected", 
($fz = function () {
return this.fFailureList.getSelectedIndex () != -1;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "loadFrameIcon", 
($fz = function () {
var toolkit = java.awt.Toolkit.getDefaultToolkit ();
try {
var url = junit.runner.BaseTestRunner.getResource ("smalllogo.gif");
return toolkit.createImage (url.getContent ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
return null;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getRunner", 
function () {
return this.fRunner;
});
c$.main = Clazz.defineMethod (c$, "main", 
function (args) {
 new junit.awtui.TestRunner ().start (args);
}, "~A");
c$.run = Clazz.defineMethod (c$, "run", 
function (test) {
var args = [test.getName ()];
junit.awtui.TestRunner.main (args);
}, "Class");
Clazz.defineMethod (c$, "rerun", 
function () {
var index = this.fFailureList.getSelectedIndex ();
if (index == -1) return ;
var test = this.fFailedTests.elementAt (index);
this.rerunTest (test);
});
Clazz.defineMethod (c$, "rerunTest", 
($fz = function (test) {
if (!(Clazz.instanceOf (test, junit.framework.TestCase))) {
this.showInfo ("Could not reload " + test.toString ());
return ;
}var reloadedTest = null;
var rerunTest = test;
try {
var reloadedTestClass = this.getLoader ().reload (test.getClass ());
reloadedTest = junit.framework.TestSuite.createTest (reloadedTestClass, rerunTest.getName ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
this.showInfo ("Could not reload " + test.toString ());
return ;
} else {
throw e;
}
}
var result =  new junit.framework.TestResult ();
reloadedTest.run (result);
var message = reloadedTest.toString ();
if (result.wasSuccessful ()) this.showInfo (message + " was successful");
 else if (result.errorCount () == 1) this.showStatus (message + " had an error");
 else this.showStatus (message + " had a failure");
}, $fz.isPrivate = true, $fz), "junit.framework.Test");
Clazz.defineMethod (c$, "reset", 
function () {
this.setLabelValue (this.fNumberOfErrors, 0);
this.setLabelValue (this.fNumberOfFailures, 0);
this.setLabelValue (this.fNumberOfRuns, 0);
this.fProgressIndicator.reset ();
this.fRerunButton.setEnabled (false);
this.fFailureList.removeAll ();
this.fExceptions =  new java.util.Vector (10);
this.fFailedTests =  new java.util.Vector (10);
this.fTraceArea.setText ("");
});
Clazz.overrideMethod (c$, "runFailed", 
function (message) {
this.showStatus (message);
this.fRun.setLabel ("Run");
this.fRunner = null;
}, "~S");
Clazz.defineMethod (c$, "runSuite", 
function () {
if (this.fRunner != null && this.fTestResult != null) {
this.fTestResult.stop ();
} else {
this.setLoading (this.shouldReload ());
this.fRun.setLabel ("Stop");
this.showInfo ("Initializing...");
this.reset ();
this.showInfo ("Load Test Case...");
var testSuite = this.getTest (this.fSuiteField.getText ());
if (testSuite != null) {
this.fRunner = (function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.TestRunner$10")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "TestRunner$10", Thread);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["junit.awtui.TestRunner"].fTestResult = this.b$["junit.awtui.TestRunner"].createTestResult ();
this.b$["junit.awtui.TestRunner"].fTestResult.addListener (this.b$["junit.awtui.TestRunner"]);
this.b$["junit.awtui.TestRunner"].fProgressIndicator.start (this.f$.testSuite.countTestCases ());
this.b$["junit.awtui.TestRunner"].showInfo ("Running...");
var startTime = System.currentTimeMillis ();
this.f$.testSuite.run (this.b$["junit.awtui.TestRunner"].fTestResult);
if (this.b$["junit.awtui.TestRunner"].fTestResult.shouldStop ()) {
this.b$["junit.awtui.TestRunner"].showStatus ("Stopped");
} else {
var endTime = System.currentTimeMillis ();
var runTime = endTime - startTime;
this.b$["junit.awtui.TestRunner"].showInfo ("Finished: " + this.b$["junit.awtui.TestRunner"].elapsedTimeAsString (runTime) + " seconds");
}this.b$["junit.awtui.TestRunner"].fTestResult = null;
this.b$["junit.awtui.TestRunner"].fRun.setLabel ("Run");
this.b$["junit.awtui.TestRunner"].fRunner = null;
System.gc ();
});
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.TestRunner$10, i$, v$);
}) (this, Clazz.cloneFinals ("testSuite", testSuite));
this.fRunner.start ();
}}});
Clazz.defineMethod (c$, "shouldReload", 
($fz = function () {
return !junit.runner.BaseTestRunner.inVAJava () && this.fUseLoadingRunner.getState ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setLabelValue", 
($fz = function (label, value) {
label.setText (Integer.toString (value));
label.invalidate ();
label.getParent ().validate ();
}, $fz.isPrivate = true, $fz), "java.awt.Label,~N");
Clazz.defineMethod (c$, "setSuiteName", 
function (suite) {
this.fSuiteField.setText (suite);
}, "~S");
Clazz.defineMethod (c$, "showErrorTrace", 
($fz = function () {
var index = this.fFailureList.getSelectedIndex ();
if (index == -1) return ;
var t = this.fExceptions.elementAt (index);
this.fTraceArea.setText (junit.runner.BaseTestRunner.getFilteredTrace (t));
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "showInfo", 
($fz = function (message) {
this.fStatusLine.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fStatusLine.setForeground (java.awt.Color.black);
this.fStatusLine.setText (message);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.overrideMethod (c$, "clearStatus", 
function () {
this.showStatus ("");
});
Clazz.defineMethod (c$, "showStatus", 
($fz = function (status) {
this.fStatusLine.setFont (junit.awtui.TestRunner.PLAIN_FONT);
this.fStatusLine.setForeground (java.awt.Color.red);
this.fStatusLine.setText (status);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "start", 
function (args) {
var suiteName = this.processArguments (args);
this.fFrame = this.createUI (suiteName);
this.fFrame.setLocation (200, 200);
this.fFrame.setVisible (true);
if (suiteName != null) {
this.setSuiteName (suiteName);
this.runSuite ();
}}, "~A");
c$.PLAIN_FONT = c$.prototype.PLAIN_FONT =  new java.awt.Font ("dialog", 0, 12);
Clazz.defineStatics (c$,
"GAP", 4);
});
