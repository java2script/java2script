﻿Clazz.declarePackage ("junit.awtui");
Clazz.load (["java.awt.Canvas"], "junit.awtui.Logo", ["java.awt.MediaTracker", "$.SystemColor", "$.Toolkit", "java.net.URL", "junit.runner.BaseTestRunner"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fImage = null;
this.fWidth = 0;
this.fHeight = 0;
Clazz.instantialize (this, arguments);
}, junit.awtui, "Logo", java.awt.Canvas);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.awtui.Logo, []);
this.fImage = this.loadImage ("logo.gif");
var tracker =  new java.awt.MediaTracker (this);
tracker.addImage (this.fImage, 0);
try {
tracker.waitForAll ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
if (this.fImage != null) {
this.fWidth = this.fImage.getWidth (this);
this.fHeight = this.fImage.getHeight (this);
} else {
this.fWidth = 20;
this.fHeight = 20;
}this.setSize (this.fWidth, this.fHeight);
});
Clazz.defineMethod (c$, "loadImage", 
function (name) {
var toolkit = java.awt.Toolkit.getDefaultToolkit ();
try {
var url = junit.runner.BaseTestRunner.getResource (name);
return toolkit.createImage (url.getContent ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
return null;
}, "~S");
Clazz.overrideMethod (c$, "paint", 
function (g) {
this.paintBackground (g);
if (this.fImage != null) g.drawImage (this.fImage, 0, 0, this.fWidth, this.fHeight, this);
}, "java.awt.Graphics");
Clazz.defineMethod (c$, "paintBackground", 
function (g) {
g.setColor (java.awt.SystemColor.control);
g.fillRect (0, 0, this.getBounds ().width, this.getBounds ().height);
}, "java.awt.Graphics");
});
