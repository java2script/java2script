Clazz.declarePackage ("junit.awtui");
Clazz.load (["java.awt.Dialog"], "junit.awtui.AboutDialog", ["java.awt.Button", "$.Font", "$.GridBagConstraints", "$.GridBagLayout", "$.Insets", "$.Label", "java.awt.event.ActionListener", "$.WindowAdapter", "junit.awtui.Logo", "junit.runner.Version"], function () {
c$ = Clazz.declareType (junit.awtui, "AboutDialog", java.awt.Dialog);
Clazz.makeConstructor (c$, 
function (parent) {
Clazz.superConstructor (this, junit.awtui.AboutDialog, [parent]);
this.setResizable (false);
this.setLayout ( new java.awt.GridBagLayout ());
this.setSize (330, 138);
this.setTitle ("About");
var button =  new java.awt.Button ("Close");
button.addActionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.AboutDialog$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "AboutDialog$1", null, java.awt.event.ActionListener);
Clazz.overrideMethod (c$, "actionPerformed", 
function (e) {
this.b$["junit.awtui.AboutDialog"].dispose ();
}, "java.awt.event.ActionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.AboutDialog$1, i$, v$);
}) (this, null));
var label1 =  new java.awt.Label ("JUnit");
label1.setFont ( new java.awt.Font ("dialog", 0, 36));
var label2 =  new java.awt.Label ("JUnit " + junit.runner.Version.id () + " by Kent Beck and Erich Gamma");
label2.setFont ( new java.awt.Font ("dialog", 0, 14));
var logo =  new junit.awtui.Logo ();
var constraintsLabel1 =  new java.awt.GridBagConstraints ();
constraintsLabel1.gridx = 3;
constraintsLabel1.gridy = 0;
constraintsLabel1.gridwidth = 1;
constraintsLabel1.gridheight = 1;
constraintsLabel1.anchor = 10;
this.add (label1, constraintsLabel1);
var constraintsLabel2 =  new java.awt.GridBagConstraints ();
constraintsLabel2.gridx = 2;
constraintsLabel2.gridy = 1;
constraintsLabel2.gridwidth = 2;
constraintsLabel2.gridheight = 1;
constraintsLabel2.anchor = 10;
this.add (label2, constraintsLabel2);
var constraintsButton1 =  new java.awt.GridBagConstraints ();
constraintsButton1.gridx = 2;
constraintsButton1.gridy = 2;
constraintsButton1.gridwidth = 2;
constraintsButton1.gridheight = 1;
constraintsButton1.anchor = 10;
constraintsButton1.insets =  new java.awt.Insets (8, 0, 8, 0);
this.add (button, constraintsButton1);
var constraintsLogo1 =  new java.awt.GridBagConstraints ();
constraintsLogo1.gridx = 2;
constraintsLogo1.gridy = 0;
constraintsLogo1.gridwidth = 1;
constraintsLogo1.gridheight = 1;
constraintsLogo1.anchor = 10;
this.add (logo, constraintsLogo1);
this.addWindowListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.awtui.AboutDialog$2")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.awtui, "AboutDialog$2", java.awt.event.WindowAdapter);
Clazz.overrideMethod (c$, "windowClosing", 
function (e) {
this.b$["junit.awtui.AboutDialog"].dispose ();
}, "java.awt.event.WindowEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.awtui.AboutDialog$2, i$, v$);
}) (this, null));
}, "java.awt.Frame");
});
