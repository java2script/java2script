(function () {
	ClazzLoader.registerPackages ("junit", [
			"awtui", "extensions", "framework", "runner",
			"swingui", "textui"]);
}) ();

/* private */
window["junit.package"] = true;
