﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.AbstractListModel", "$.DefaultListCellRenderer", "junit.runner.FailureDetailView", "java.util.Vector"], "junit.swingui.DefaultFailureDetailView", ["java.awt.Font", "java.util.StringTokenizer", "javax.swing.JList", "junit.framework.TestFailure", "junit.runner.BaseTestRunner"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fList = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "DefaultFailureDetailView", null, junit.runner.FailureDetailView);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fLines = null;
Clazz.instantialize (this, arguments);
}, junit.swingui.DefaultFailureDetailView, "StackTraceListModel", javax.swing.AbstractListModel);
Clazz.prepareFields (c$, function () {
this.fLines =  new java.util.Vector (20);
});
Clazz.overrideMethod (c$, "getElementAt", 
function (a) {
return this.fLines.elementAt (a);
}, "~N");
Clazz.overrideMethod (c$, "getSize", 
function () {
return this.fLines.size ();
});
Clazz.defineMethod (c$, "setTrace", 
function (a) {
this.scan (a);
this.fireContentsChanged (this, 0, this.fLines.size ());
}, "~S");
Clazz.defineMethod (c$, "clear", 
function () {
this.fLines.removeAllElements ();
this.fireContentsChanged (this, 0, this.fLines.size ());
});
Clazz.defineMethod (c$, "scan", 
($fz = function (a) {
this.fLines.removeAllElements ();
var b =  new java.util.StringTokenizer (a, "\n\r", false);
while (b.hasMoreTokens ()) this.fLines.add (b.nextToken ());

}, $fz.isPrivate = true, $fz), "~S");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (junit.swingui.DefaultFailureDetailView, "StackEntryRenderer", javax.swing.DefaultListCellRenderer);
Clazz.defineMethod (c$, "getListCellRendererComponent", 
function (a, b, c, d, e) {
var f = (b).$replace ('\t', ' ');
var g = Clazz.superCall (this, junit.swingui.DefaultFailureDetailView.StackEntryRenderer, "getListCellRendererComponent", [a, f, c, d, e]);
this.setText (f);
this.setToolTipText (f);
return g;
}, "javax.swing.JList,~O,~N,~B,~B");
c$ = Clazz.p0p ();
Clazz.overrideMethod (c$, "getComponent", 
function () {
if (this.fList == null) {
this.fList =  new javax.swing.JList ( new junit.swingui.DefaultFailureDetailView.StackTraceListModel ());
this.fList.setFont ( new java.awt.Font ("Dialog", 0, 12));
this.fList.setSelectionMode (0);
this.fList.setVisibleRowCount (5);
this.fList.setCellRenderer ( new junit.swingui.DefaultFailureDetailView.StackEntryRenderer ());
}return this.fList;
});
Clazz.overrideMethod (c$, "showFailure", 
function (failure) {
this.getModel ().setTrace (junit.runner.BaseTestRunner.getFilteredTrace (failure.trace ()));
}, "junit.framework.TestFailure");
Clazz.overrideMethod (c$, "clear", 
function () {
this.getModel ().clear ();
});
Clazz.defineMethod (c$, "getModel", 
($fz = function () {
return this.fList.getModel ();
}, $fz.isPrivate = true, $fz));
});
