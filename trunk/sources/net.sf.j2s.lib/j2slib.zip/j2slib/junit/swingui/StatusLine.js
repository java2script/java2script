﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.JTextField", "java.awt.Font"], "junit.swingui.StatusLine", ["java.awt.Color", "javax.swing.BorderFactory", "javax.swing.border.BevelBorder"], function () {
c$ = Clazz.declareType (junit.swingui, "StatusLine", javax.swing.JTextField);
Clazz.makeConstructor (c$, 
function (preferredWidth) {
Clazz.superConstructor (this, junit.swingui.StatusLine);
this.setFont (junit.swingui.StatusLine.BOLD_FONT);
this.setEditable (false);
this.setBorder (javax.swing.BorderFactory.createBevelBorder (1));
var d = this.getPreferredSize ();
d.width = preferredWidth;
this.setPreferredSize (d);
}, "~N");
Clazz.defineMethod (c$, "showInfo", 
function (message) {
this.setFont (junit.swingui.StatusLine.PLAIN_FONT);
this.setForeground (java.awt.Color.black);
this.setText (message);
}, "~S");
Clazz.defineMethod (c$, "showError", 
function (status) {
this.setFont (junit.swingui.StatusLine.BOLD_FONT);
this.setForeground (java.awt.Color.red);
this.setText (status);
this.setToolTipText (status);
}, "~S");
Clazz.defineMethod (c$, "clear", 
function () {
this.setText ("");
this.setToolTipText (null);
});
c$.PLAIN_FONT = c$.prototype.PLAIN_FONT =  new java.awt.Font ("dialog", 0, 12);
c$.BOLD_FONT = c$.prototype.BOLD_FONT =  new java.awt.Font ("dialog", 1, 12);
});
