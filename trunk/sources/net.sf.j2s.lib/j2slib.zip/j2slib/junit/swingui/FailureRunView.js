Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.DefaultListCellRenderer", "junit.swingui.TestRunView"], "junit.swingui.FailureRunView", ["java.awt.Font", "javax.swing.JList", "$.JScrollPane", "javax.swing.event.ListSelectionListener", "junit.runner.BaseTestRunner", "junit.swingui.TestRunner"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fFailureList = null;
this.fRunContext = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "FailureRunView", null, junit.swingui.TestRunView);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fFailureIcon = null;
this.fErrorIcon = null;
Clazz.instantialize (this, arguments);
}, junit.swingui.FailureRunView, "FailureListCellRenderer", javax.swing.DefaultListCellRenderer);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, junit.swingui.FailureRunView.FailureListCellRenderer);
this.loadIcons ();
});
Clazz.defineMethod (c$, "loadIcons", 
function () {
this.fFailureIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/failure.gif");
this.fErrorIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/error.gif");
});
Clazz.defineMethod (c$, "getListCellRendererComponent", 
function (a, b, c, d, e) {
var f = Clazz.superCall (this, junit.swingui.FailureRunView.FailureListCellRenderer, "getListCellRendererComponent", [a, b, c, d, e]);
var g = b;
var h = g.failedTest ().toString ();
var i = g.exceptionMessage ();
if (i != null) h += ":" + junit.runner.BaseTestRunner.truncate (i);
if (g.isFailure ()) {
if (this.fFailureIcon != null) this.setIcon (this.fFailureIcon);
} else {
if (this.fErrorIcon != null) this.setIcon (this.fErrorIcon);
}this.setText (h);
this.setToolTipText (h);
return f;
}, "javax.swing.JList,~O,~N,~B,~B");
c$ = Clazz.p0p ();
Clazz.makeConstructor (c$, 
function (context) {
this.fRunContext = context;
this.fFailureList =  new javax.swing.JList (this.fRunContext.getFailures ());
this.fFailureList.setFont ( new java.awt.Font ("Dialog", 0, 12));
this.fFailureList.setSelectionMode (0);
this.fFailureList.setCellRenderer ( new junit.swingui.FailureRunView.FailureListCellRenderer ());
this.fFailureList.setVisibleRowCount (5);
this.fFailureList.addListSelectionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.FailureRunView$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "FailureRunView$1", null, javax.swing.event.ListSelectionListener);
Clazz.overrideMethod (c$, "valueChanged", 
function (e) {
this.b$["junit.swingui.FailureRunView"].testSelected ();
}, "javax.swing.event.ListSelectionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.FailureRunView$1, i$, v$);
}) (this, null));
}, "junit.swingui.TestRunContext");
Clazz.overrideMethod (c$, "getSelectedTest", 
function () {
var index = this.fFailureList.getSelectedIndex ();
if (index == -1) return null;
var model = this.fFailureList.getModel ();
var failure = model.getElementAt (index);
return failure.failedTest ();
});
Clazz.overrideMethod (c$, "activate", 
function () {
this.testSelected ();
});
Clazz.overrideMethod (c$, "addTab", 
function (pane) {
var scrollPane =  new javax.swing.JScrollPane (this.fFailureList, 22, 32);
var errorIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/error.gif");
pane.addTab ("Failures", errorIcon, scrollPane, "The list of failed tests");
}, "javax.swing.JTabbedPane");
Clazz.overrideMethod (c$, "revealFailure", 
function (failure) {
this.fFailureList.setSelectedIndex (0);
}, "junit.framework.Test");
Clazz.overrideMethod (c$, "aboutToStart", 
function (suite, result) {
}, "junit.framework.Test,junit.framework.TestResult");
Clazz.overrideMethod (c$, "runFinished", 
function (suite, result) {
}, "junit.framework.Test,junit.framework.TestResult");
Clazz.defineMethod (c$, "testSelected", 
function () {
this.fRunContext.handleTestSelected (this.getSelectedTest ());
});
});
