﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (null, "junit.swingui.TestRunView", ["javax.swing.JTabbedPane"], function () {
Clazz.declareInterface (junit.swingui, "TestRunView");
});
