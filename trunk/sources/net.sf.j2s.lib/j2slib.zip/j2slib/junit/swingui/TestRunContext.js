﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (null, "junit.swingui.TestRunContext", ["javax.swing.ListModel", "junit.framework.Test"], function () {
Clazz.declareInterface (junit.swingui, "TestRunContext");
});
