﻿Clazz.declarePackage ("junit.swingui");
Clazz.load (["javax.swing.tree.TreeModel", "java.util.Hashtable", "$.Vector"], "junit.swingui.TestTreeModel", ["javax.swing.event.TreeModelEvent", "junit.extensions.TestDecorator"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fRoot = null;
this.fModelListeners = null;
this.fFailures = null;
this.fErrors = null;
this.fRunTests = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "TestTreeModel", null, javax.swing.tree.TreeModel);
Clazz.prepareFields (c$, function () {
this.fModelListeners =  new java.util.Vector ();
this.fFailures =  new java.util.Hashtable ();
this.fErrors =  new java.util.Hashtable ();
this.fRunTests =  new java.util.Hashtable ();
});
Clazz.makeConstructor (c$, 
function (root) {
this.fRoot = root;
}, "junit.framework.Test");
Clazz.overrideMethod (c$, "addTreeModelListener", 
function (l) {
if (!this.fModelListeners.contains (l)) this.fModelListeners.addElement (l);
}, "javax.swing.event.TreeModelListener");
Clazz.overrideMethod (c$, "removeTreeModelListener", 
function (l) {
this.fModelListeners.removeElement (l);
}, "javax.swing.event.TreeModelListener");
Clazz.defineMethod (c$, "findTest", 
function (target, node, path) {
if (target.equals (node)) return 0;
var suite = this.isTestSuite (node);
for (var i = 0; i < this.getChildCount (node); i++) {
var t = suite.testAt (i);
var index = this.findTest (target, t, path);
if (index >= 0) {
path.insertElementAt (node, 0);
if (path.size () == 1) return i;
return index;
}}
return -1;
}, "junit.framework.Test,junit.framework.Test,java.util.Vector");
Clazz.defineMethod (c$, "fireNodeChanged", 
function (path, index) {
var indices = [index];
var changedChildren = [this.getChild (path.getLastPathComponent (), index)];
var event =  new javax.swing.event.TreeModelEvent (this, path, indices, changedChildren);
var e = this.fModelListeners.elements ();
while (e.hasMoreElements ()) {
var l = e.nextElement ();
l.treeNodesChanged (event);
}
}, "javax.swing.tree.TreePath,~N");
Clazz.overrideMethod (c$, "getChild", 
function (parent, index) {
var suite = this.isTestSuite (parent);
if (suite != null) return suite.testAt (index);
return null;
}, "~O,~N");
Clazz.overrideMethod (c$, "getChildCount", 
function (parent) {
var suite = this.isTestSuite (parent);
if (suite != null) return suite.testCount ();
return 0;
}, "~O");
Clazz.overrideMethod (c$, "getIndexOfChild", 
function (parent, child) {
var suite = this.isTestSuite (parent);
if (suite != null) {
var i = 0;
for (var e = suite.tests (); e.hasMoreElements (); i++) {
if (child.equals (e.nextElement ())) return i;
}
}return -1;
}, "~O,~O");
Clazz.overrideMethod (c$, "getRoot", 
function () {
return this.fRoot;
});
Clazz.overrideMethod (c$, "isLeaf", 
function (node) {
return this.isTestSuite (node) == null;
}, "~O");
Clazz.defineMethod (c$, "isTestSuite", 
function (node) {
if (Clazz.instanceOf (node, junit.framework.TestSuite)) return node;
if (Clazz.instanceOf (node, junit.extensions.TestDecorator)) {
var baseTest = (node).getTest ();
return this.isTestSuite (baseTest);
}return null;
}, "~O");
Clazz.overrideMethod (c$, "valueForPathChanged", 
function (path, newValue) {
System.out.println ("TreeModel.valueForPathChanged: not implemented");
}, "javax.swing.tree.TreePath,~O");
Clazz.defineMethod (c$, "addFailure", 
function (t) {
this.fFailures.put (t, t);
}, "junit.framework.Test");
Clazz.defineMethod (c$, "addError", 
function (t) {
this.fErrors.put (t, t);
}, "junit.framework.Test");
Clazz.defineMethod (c$, "addRunTest", 
function (t) {
this.fRunTests.put (t, t);
}, "junit.framework.Test");
Clazz.defineMethod (c$, "wasRun", 
function (t) {
return this.fRunTests.get (t) != null;
}, "junit.framework.Test");
Clazz.defineMethod (c$, "isError", 
function (t) {
return (this.fErrors != null) && this.fErrors.get (t) != null;
}, "junit.framework.Test");
Clazz.defineMethod (c$, "isFailure", 
function (t) {
return (this.fFailures != null) && this.fFailures.get (t) != null;
}, "junit.framework.Test");
Clazz.defineMethod (c$, "resetResults", 
function () {
this.fFailures =  new java.util.Hashtable ();
this.fRunTests =  new java.util.Hashtable ();
this.fErrors =  new java.util.Hashtable ();
});
});
