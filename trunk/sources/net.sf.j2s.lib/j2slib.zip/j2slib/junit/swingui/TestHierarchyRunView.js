Clazz.declarePackage ("junit.swingui");
Clazz.load (["junit.swingui.TestRunView"], "junit.swingui.TestHierarchyRunView", ["java.util.Vector", "javax.swing.event.TreeSelectionListener", "javax.swing.tree.TreePath", "junit.swingui.TestRunner", "$.TestSuitePanel"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fTreeBrowser = null;
this.fTestContext = null;
Clazz.instantialize (this, arguments);
}, junit.swingui, "TestHierarchyRunView", null, junit.swingui.TestRunView);
Clazz.makeConstructor (c$, 
function (context) {
this.fTestContext = context;
this.fTreeBrowser =  new junit.swingui.TestSuitePanel ();
this.fTreeBrowser.getTree ().addTreeSelectionListener ((function (i$, v$) {
if (!Clazz.isClassDefined ("junit.swingui.TestHierarchyRunView$1")) {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (junit.swingui, "TestHierarchyRunView$1", null, javax.swing.event.TreeSelectionListener);
Clazz.overrideMethod (c$, "valueChanged", 
function (e) {
this.b$["junit.swingui.TestHierarchyRunView"].testSelected ();
}, "javax.swing.event.TreeSelectionEvent");
c$ = Clazz.p0p ();
}
return Clazz.innerTypeInstance (junit.swingui.TestHierarchyRunView$1, i$, v$);
}) (this, null));
}, "junit.swingui.TestRunContext");
Clazz.overrideMethod (c$, "addTab", 
function (pane) {
var treeIcon = junit.swingui.TestRunner.getIconResource (this.getClass (), "icons/hierarchy.gif");
pane.addTab ("Test Hierarchy", treeIcon, this.fTreeBrowser, "The test hierarchy");
}, "javax.swing.JTabbedPane");
Clazz.overrideMethod (c$, "getSelectedTest", 
function () {
return this.fTreeBrowser.getSelectedTest ();
});
Clazz.overrideMethod (c$, "activate", 
function () {
this.testSelected ();
});
Clazz.overrideMethod (c$, "revealFailure", 
function (failure) {
var tree = this.fTreeBrowser.getTree ();
var model = tree.getModel ();
var vpath =  new java.util.Vector ();
var index = model.findTest (failure, model.getRoot (), vpath);
if (index >= 0) {
var path =  new Array (vpath.size () + 1);
vpath.copyInto (path);
var last = path[vpath.size () - 1];
path[vpath.size ()] = model.getChild (last, index);
var selectionPath =  new javax.swing.tree.TreePath (path);
tree.setSelectionPath (selectionPath);
tree.makeVisible (selectionPath);
}}, "junit.framework.Test");
Clazz.overrideMethod (c$, "aboutToStart", 
function (suite, result) {
this.fTreeBrowser.showTestTree (suite);
result.addListener (this.fTreeBrowser);
}, "junit.framework.Test,junit.framework.TestResult");
Clazz.overrideMethod (c$, "runFinished", 
function (suite, result) {
result.removeListener (this.fTreeBrowser);
}, "junit.framework.Test,junit.framework.TestResult");
Clazz.defineMethod (c$, "testSelected", 
function () {
this.fTestContext.handleTestSelected (this.getSelectedTest ());
});
});
