﻿Clazz.declarePackage ("junit.runner");
Clazz.load (null, "junit.runner.FailureDetailView", ["java.awt.Component"], function () {
Clazz.declareInterface (junit.runner, "FailureDetailView");
});
