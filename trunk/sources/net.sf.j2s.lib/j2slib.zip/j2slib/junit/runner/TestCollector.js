﻿Clazz.declarePackage ("junit.runner");
Clazz.declareInterface (junit.runner, "TestCollector");
