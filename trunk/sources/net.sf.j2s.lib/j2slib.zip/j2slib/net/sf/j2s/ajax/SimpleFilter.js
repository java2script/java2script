﻿$_J("net.sf.j2s.ajax");
$_I(net.sf.j2s.ajax,"SimpleFilter");
