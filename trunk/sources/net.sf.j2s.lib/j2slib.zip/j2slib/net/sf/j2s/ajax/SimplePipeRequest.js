﻿$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.SimpleRPCRequest"],"net.sf.j2s.ajax.SimplePipeRequest",["net.sf.j2s.ajax.HttpRequest","$.SimplePipeHelper","$.SimpleSerializable","$.XHRCallbackAdapter"],function(){
c$=$_T(net.sf.j2s.ajax,"SimplePipeRequest",net.sf.j2s.ajax.SimpleRPCRequest);
c$.getPipeMode=$_M(c$,"getPipeMode",
function(){
return net.sf.j2s.ajax.SimplePipeRequest.pipeMode;
});
c$.getQueryInterval=$_M(c$,"getQueryInterval",
function(){
return net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval;
});
c$.switchToQueryMode=$_M(c$,"switchToQueryMode",
function(){
($t$=net.sf.j2s.ajax.SimplePipeRequest.pipeMode=3,net.sf.j2s.ajax.SimplePipeRequest.prototype.pipeMode=net.sf.j2s.ajax.SimplePipeRequest.pipeMode,$t$);
($t$=net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval=1000,net.sf.j2s.ajax.SimplePipeRequest.prototype.pipeQueryInterval=net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval,$t$);
});
c$.switchToQueryMode=$_M(c$,"switchToQueryMode",
function(ms){
($t$=net.sf.j2s.ajax.SimplePipeRequest.pipeMode=3,net.sf.j2s.ajax.SimplePipeRequest.prototype.pipeMode=net.sf.j2s.ajax.SimplePipeRequest.pipeMode,$t$);
if(ms<0){
ms=1000;
}($t$=net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval=ms,net.sf.j2s.ajax.SimplePipeRequest.prototype.pipeQueryInterval=net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval,$t$);
},"~N");
c$.switchToContinuumMode=$_M(c$,"switchToContinuumMode",
function(){
($t$=net.sf.j2s.ajax.SimplePipeRequest.pipeMode=4,net.sf.j2s.ajax.SimplePipeRequest.prototype.pipeMode=net.sf.j2s.ajax.SimplePipeRequest.pipeMode,$t$);
});
c$.constructRequest=$_M(c$,"constructRequest",
function(pipeKey,pipeRequestType,rand){
($t$=net.sf.j2s.ajax.SimplePipeRequest.reqCount++,net.sf.j2s.ajax.SimplePipeRequest.prototype.reqCount=net.sf.j2s.ajax.SimplePipeRequest.reqCount,$t$);
return"k"+"="+pipeKey+"&"+"t"+"="+pipeRequestType+(rand?"&"+"r"+"="+net.sf.j2s.ajax.SimplePipeRequest.reqCount:"");
},"~S,~S,~B");
c$.sendRequest=$_M(c$,"sendRequest",
function(request,method,url,data,async){
if("GET".equals(method.toUpperCase())){
request.open(method,url+(url.indexOf('?')!=-1?"&":"?")+data,async);
request.send(null);
}else{
request.open(method,url,async);
request.send(data);
}},"net.sf.j2s.ajax.HttpRequest,~S,~S,~S,~B");
c$.pipe=$_M(c$,"pipe",
function(runnable){
runnable.ajaxIn();
net.sf.j2s.ajax.SimplePipeRequest.pipeRequest(runnable);
},"net.sf.j2s.ajax.SimplePipeRunnable");
c$.pipeRequest=$_M(c$,"pipeRequest",
($fz=function(runnable){
var url=runnable.getHttpURL();
var method=runnable.getHttpMethod();
var serialize=runnable.serialize();
if(method==null){
method="POST";
}var ajaxOut=null;
{
ajaxOut=runnable.ajaxOut;
runnable.ajaxOut=(function(aO,r){
return function(){
aO.apply(r,[]);
net.sf.j2s.ajax.SimplePipeRequest.ajaxPipe(r);
};
})(ajaxOut,runnable);
}if(net.sf.j2s.ajax.SimpleRPCRequest.checkXSS(url,serialize,runnable)){
return;
}{
runnable.ajaxOut=ajaxOut;
}var url2=net.sf.j2s.ajax.SimpleRPCRequest.adjustRequestURL(method,url,serialize);
if(url2!==url){
serialize=null;
}var request=new net.sf.j2s.ajax.HttpRequest();
request.open(method,url,true);
request.registerOnReadyStateChange((function(i$,v$){
if(!$_D("net.sf.j2s.ajax.SimplePipeRequest$1")){
$_H();
c$=$_W(net.sf.j2s.ajax,"SimplePipeRequest$1",net.sf.j2s.ajax.XHRCallbackAdapter);
$_V(c$,"onLoaded",
function(){
var responseText=this.f$.request.getResponseText();
if(responseText==null||responseText.length==0){
this.f$.runnable.ajaxFail();
return;
}this.f$.runnable.deserialize(responseText);
this.f$.runnable.ajaxOut();
net.sf.j2s.ajax.SimplePipeRequest.ajaxPipe(this.f$.runnable);
});
c$=$_P();
}
return $_N(net.sf.j2s.ajax.SimplePipeRequest$1,i$,v$);
})(this,$_F("request",request,"runnable",runnable)));
request.send(serialize);
},$fz.isPrivate=true,$fz),"net.sf.j2s.ajax.SimplePipeRunnable");
c$.loadPipeScript=$_M(c$,"loadPipeScript",
function(url){
var script=document.createElement("SCRIPT");
script.type="text/javascript";
script.src=url;
var iframeID=arguments[1];
var userAgent=navigator.userAgent.toLowerCase();
var isOpera=(userAgent.indexOf("opera")!=-1);
var isIE=(userAgent.indexOf("msie")!=-1)&&!isOpera;
if(typeof(script.onreadystatechange)=="undefined"||!isIE){
script.onerror=function(){
this.onerror=null;
if(iframeID!=null){
if(window.parent==null||window.parent["net"]==null)return;
window.parent.net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
var iframe=window.parent.document.getElementById(iframeID);
if(iframe!=null){
iframe.parentNode.removeChild(iframe);
}
return;
}
if(window==null||window["net"]==null)return;
net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
};
script.onload=function(){
this.onload=null;
if(iframeID!=null){
if(window.parent==null||window.parent["net"]==null)return;
window.parent.net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
var iframe=window.parent.document.getElementById(iframeID);
if(iframe!=null){
iframe.parentNode.removeChild(iframe);
}
return;
}
if(window==null||window["net"]==null)return;
net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
};
}else{
script.defer=true;
script.onreadystatechange=function(){
var state=""+this.readyState;
if(state=="loaded"||state=="complete"){
this.onreadystatechange=null;
if(iframeID!=null){
if(window.parent==null||window.parent["net"]==null)return;
window.parent.net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
var iframe=window.parent.document.getElementById(iframeID);
if(iframe!=null){
iframe.parentNode.removeChild(iframe);
}
return;
}
if(window==null||window["net"]==null)return;
net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
document.getElementsByTagName("HEAD")[0].removeChild(this);
}
};
}
var head=document.getElementsByTagName("HEAD")[0];
head.appendChild(script);
},"~S");
c$.loadPipeIFrameScript=$_M(c$,"loadPipeIFrameScript",
function(url){
var iframe=document.createElement("IFRAME");
iframe.style.display="none";
var iframeID=null;
do{
iframeID="pipe-script-"+Math.round(10000000*Math.random());
}while(document.getElementById(iframeID)!=null);
iframe.id=iframeID;
document.body.appendChild(iframe);
var html="<html><head><title></title>";
html+="<script type=\"text/javascript\">\r\n";
html+="window[\"$p1p3p$\"] = function (string) {\r\n";
html+="		with (window.parent) {\r\n";
html+="				net.sf.j2s.ajax.SimplePipeRequest.parseReceived (string);\r\n";
html+="		};\r\n";
html+="};\r\n";
html+="window[\"$p1p3b$\"] = function (key, result) {\r\n";
html+="		with (window.parent) {\r\n";
html+="				net.sf.j2s.ajax.SimplePipeRequest.pipeNotifyCallBack (key, result);\r\n";
html+="		};\r\n";
html+="};\r\n";
html+="</scr"+"ipt></head><body><script type=\"text/javascript\">\r\n";
if(ClassLoader.isOpera)
html+="window.setTimeout (function () {\r\n";
html+="("+net.sf.j2s.ajax.SimplePipeRequest.loadPipeScript+") (";
html+="\"" + url.replace (/"/g,"\\\"") + "\", \"" + iframeID + "\"";
html+=");\r\n";
if(ClassLoader.isOpera)
html+="}, "+(net.sf.j2s.ajax.SimplePipeRequest.pipeQueryInterval>>2)+");\r\n";
html+="</scr"+"ipt></body></html>";
net.sf.j2s.ajax.SimplePipeRequest.iframeDocumentWrite(iframe,html);
},"~S");
c$.iframeDocumentWrite=$_M(c$,"iframeDocumentWrite",
($fz=function(handle,html){
var handle=arguments[0];
var html=arguments[1];
if(handle.contentWindow!=null){
handle.contentWindow.location="about:blank";
}else{
handle.src="about:blank";
}
try{
var doc=handle.contentWindow.document;
doc.open();
doc.write(html);
doc.close();
document.title=document.title;
}catch(e){
window.setTimeout((function(handle,html){
return function(){
var doc=handle.contentWindow.document;
doc.open();
doc.write(html);
doc.close();
document.title=document.title;
};
})(handle,html),25);
}
},$fz.isPrivate=true,$fz),"~O,~S");
c$.pipeScript=$_M(c$,"pipeScript",
function(runnable){
var url=runnable.getPipeURL();
var requestURL=url+(url.indexOf('?')!=-1?"&":"?")+net.sf.j2s.ajax.SimplePipeRequest.constructRequest(runnable.pipeKey,"x",true);
if(net.sf.j2s.ajax.SimpleRPCRequest.isXSSMode(url)){
net.sf.j2s.ajax.SimplePipeRequest.loadPipeIFrameScript(requestURL);
return;
}net.sf.j2s.ajax.SimplePipeRequest.loadPipeScript(requestURL);
},"net.sf.j2s.ajax.SimplePipeRunnable");
c$.pipeNotify=$_M(c$,"pipeNotify",
function(runnable){
var url=runnable.getPipeURL();
net.sf.j2s.ajax.SimplePipeRequest.loadPipeScript(url+(url.indexOf('?')!=-1?"&":"?")+net.sf.j2s.ajax.SimplePipeRequest.constructRequest(runnable.pipeKey,"n",true));
},"net.sf.j2s.ajax.SimplePipeRunnable");
c$.pipeNotifyCallBack=$_M(c$,"pipeNotifyCallBack",
function(key,result){
if("l".equals(result)){
var pipe=net.sf.j2s.ajax.SimplePipeHelper.getPipe(key);
if(pipe!=null){
pipe.pipeAlive=false;
pipe.pipeLost();
net.sf.j2s.ajax.SimplePipeHelper.removePipe(key);
}}},"~S,~S");
c$.pipeQuery=$_M(c$,"pipeQuery",
function(runnable){
var pipeRequest=new net.sf.j2s.ajax.HttpRequest();
var pipeKey=runnable.pipeKey;
var pipeMethod=runnable.getPipeMethod();
var pipeURL=runnable.getPipeURL();
pipeRequest.registerOnReadyStateChange((function(i$,v$){
if(!$_D("net.sf.j2s.ajax.SimplePipeRequest$2")){
$_H();
c$=$_W(net.sf.j2s.ajax,"SimplePipeRequest$2",net.sf.j2s.ajax.XHRCallbackAdapter);
$_V(c$,"onLoaded",
function(){
{
if(window==null||window["net"]==null)return;
}var responseText=this.f$.pipeRequest.getResponseText();
if(responseText!=null){
var retStr=net.sf.j2s.ajax.SimplePipeRequest.parseReceived(responseText);
if(retStr!=null&&retStr.length>0){
var destroyedKey="d";
if(retStr.indexOf(destroyedKey)==0){
var beginIndex=destroyedKey.length+1;
var pipeKeyStr=retStr.substring(beginIndex,beginIndex+6);
var pipe=net.sf.j2s.ajax.SimplePipeHelper.getPipe(pipeKeyStr);
if(pipe!=null){
pipe.pipeAlive=false;
pipe.pipeClosed();
net.sf.j2s.ajax.SimplePipeHelper.removePipe(pipeKeyStr);
}}}}{
net.sf.j2s.ajax.SimplePipeRequest.lastQueryReceived=true;
}});
c$=$_P();
}
return $_N(net.sf.j2s.ajax.SimplePipeRequest$2,i$,v$);
})(this,$_F("pipeRequest",pipeRequest)));
var async=false;
{
async=true;
}var pipeRequestData=net.sf.j2s.ajax.SimplePipeRequest.constructRequest(pipeKey,"q",true);
net.sf.j2s.ajax.SimplePipeRequest.sendRequest(pipeRequest,pipeMethod,pipeURL,pipeRequestData,async);
},"net.sf.j2s.ajax.SimplePipeRunnable");
c$.pipeContinuum=$_M(c$,"pipeContinuum",
function(runnable){
var ifr=document.createElement("IFRAME");
ifr.style.display="none";
var pipeKey=runnable.pipeKey;
var spr=net.sf.j2s.ajax.SimplePipeRequest;
var url=runnable.getPipeURL();
ifr.src=url+(url.indexOf('?')!=-1?"&":"?")
+spr.constructRequest(pipeKey,spr.PIPE_TYPE_SCRIPT,true);
document.body.appendChild(ifr);
var threadFun=function(pipeFun,key){
return function(){
var runnable=net.sf.j2s.ajax.SimplePipeHelper.getPipe(key);
if(runnable!=null){
var spr=net.sf.j2s.ajax.SimplePipeRequest;

pipeFun(runnable);


window.setTimeout(arguments.callee,spr.pipeLiveNotifyInterval);
}
};
};

var fun=threadFun(spr.pipeNotify,runnable.pipeKey);
window.setTimeout(fun,spr.pipeLiveNotifyInterval);
},"net.sf.j2s.ajax.SimplePipeRunnable");
c$.parseReceived=$_M(c$,"parseReceived",
function(string){
var ss=null;
var start=0;
while(string.length>start+6){
var destroyedKey="d";
var end=start+6;
if(destroyedKey.equals(string.substring(end,end+destroyedKey.length))){
{
var key=string.substring(start,end);
var pipe=net.sf.j2s.ajax.SimplePipeHelper.getPipe(key)
if(pipe!=null){
pipe.pipeAlive=false;
pipe.pipeClosed();
}
net.sf.j2s.ajax.SimplePipeHelper.removePipe(key);
}return destroyedKey+":"+string.substring(start,end)+":"+string.substring(end+destroyedKey.length);
}if((ss=net.sf.j2s.ajax.SimpleSerializable.parseInstance(string,end))==null||!ss.deserialize(string,end)){
break;
}var key=string.substring(start,end);
var runnable=net.sf.j2s.ajax.SimplePipeHelper.getPipe(key);
if(runnable!=null){
runnable.deal(ss);
}start=net.sf.j2s.ajax.SimplePipeRequest.restStringIndex(string,start);
}
if(start!=0){
return string.substring(start);
}return string;
},"~S");
c$.restStringIndex=$_M(c$,"restStringIndex",
function(string,start){
var idx1=string.indexOf('#',start)+1;
var idx2=string.indexOf('$',idx1);
var sizeStr=string.substring(idx1,idx2);
sizeStr=sizeStr.replaceFirst("^0+","");
var size=0;
if(sizeStr.length!=0){
try{
size=Integer.parseInt(sizeStr);
}catch(e){
if($_O(e,NumberFormatException)){
}else{
throw e;
}
}
}var end=idx2+size+1;
if(end<=string.length){
return end;
}else{
return start;
}},"~S,~N");
c$.ajaxPipe=$_M(c$,"ajaxPipe",
function(runnable){
net.sf.j2s.ajax.SimplePipeHelper.registerPipe(runnable.pipeKey,runnable);
var isXSS=net.sf.j2s.ajax.SimpleRPCRequest.isXSSMode(runnable.getPipeURL());
if(!isXSS&&net.sf.j2s.ajax.SimplePipeRequest.pipeMode==4){
net.sf.j2s.ajax.SimplePipeRequest.pipeContinuum(runnable);
}else{
var spr=net.sf.j2s.ajax.SimplePipeRequest;
spr.lastQueryReceived=true;
if(spr.queryTimeoutHandle!=null){
window.clearTimeout(spr.queryTimeoutHandle);
spr.queryTimeoutHandle=null;
}
(function(pipeFun,key){
return function(){
var runnable=net.sf.j2s.ajax.SimplePipeHelper.getPipe(key);
if(runnable!=null){
var spr=net.sf.j2s.ajax.SimplePipeRequest;
if(spr.lastQueryReceived){
spr.lastQueryReceived=false;
pipeFun(runnable);
}
spr.queryTimeoutHandle=window.setTimeout(arguments.callee,spr.pipeQueryInterval);
}
};
})((!isXSS)?spr.pipeQuery:spr.pipeScript,runnable.pipeKey)()
}},"net.sf.j2s.ajax.SimplePipeRunnable");
$_S(c$,
"PIPE_STATUS_OK","o",
"PIPE_STATUS_DESTROYED","d",
"PIPE_STATUS_LOST","l",
"PIPE_TYPE_QUERY","q",
"PIPE_TYPE_NOTIFY","n",
"PIPE_TYPE_SCRIPT","s",
"PIPE_TYPE_XSS","x",
"PIPE_TYPE_CONTINUUM","c",
"FORM_PIPE_KEY","k",
"FORM_PIPE_TYPE","t",
"FORM_PIPE_RANDOM","r",
"PIPE_KEY_LENGTH",6,
"MODE_PIPE_QUERY",3,
"MODE_PIPE_CONTINUUM",4,
"pipeMode",4,
"pipeQueryInterval",1000,
"pipeLiveNotifyInterval",25000,
"reqCount",0);

window["$p1p3p$"]=net.sf.j2s.ajax.SimplePipeRequest.parseReceived;
window["$p1p3b$"]=net.sf.j2s.ajax.SimplePipeRequest.pipeNotifyCallBack;
});
