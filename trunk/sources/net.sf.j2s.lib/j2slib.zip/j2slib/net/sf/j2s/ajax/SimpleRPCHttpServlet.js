﻿$_J("net.sf.j2s.ajax");
$_L(["javax.servlet.http.HttpServlet","java.util.HashSet"],"net.sf.j2s.ajax.SimpleRPCHttpServlet",["java.io.ByteArrayOutputStream"],function(){
c$=$_C(function(){
this.runnables=null;
this.mappings=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimpleRPCHttpServlet",javax.servlet.http.HttpServlet);
$_Y(c$,function(){
this.runnables=new java.util.HashSet();
this.mappings=new java.util.HashSet();
});
$_M(c$,"getRunnableByURL",
function(url){
var lastIndexOf=url.lastIndexOf('/');
var shortURL=null;
if(lastIndexOf==url.length-1){
lastIndexOf=url.lastIndexOf('/',lastIndexOf-1);
if(lastIndexOf==-1){
return null;
}shortURL=url.substring(lastIndexOf+1,url.length-1);
}else{
shortURL=url.substring(lastIndexOf+1);
}if(this.runnables.contains(shortURL)){
if(url!=null){
var obj=this.getNewInstanceByClassName(shortURL);
if(obj!=null&&$_O(obj,net.sf.j2s.ajax.SimpleRPCRunnable)){
return obj;
}}}for(var iter=this.mappings.iterator();iter.hasNext();){
var mappingStr=iter.next();
if(mappingStr!=null){
var obj=this.getNewInstanceByClassName(mappingStr);
if(obj!=null&&$_O(obj,net.sf.j2s.ajax.SimpleRPCMapping)){
var mapping=obj;
var mappedRunnable=mapping.getRunnableClassName(shortURL);
if(mappedRunnable!=null){
obj=this.getNewInstanceByClassName(mappedRunnable);
if(obj!=null&&$_O(obj,net.sf.j2s.ajax.SimpleRPCRunnable)){
return obj;
}}}}}
return null;
},"~S");
$_M(c$,"getNewInstanceByClassName",
function(className){
try{
var runnableClass=Class.forName(className);
if(runnableClass!=null){
var constructor=runnableClass.getConstructor(new Array(0));
return constructor.newInstance(new Array(0));
}}catch(e){
if($_O(e,SecurityException)){
e.printStackTrace();
}else if($_O(e,IllegalArgumentException)){
e.printStackTrace();
}else if($_O(e,ClassNotFoundException)){
e.printStackTrace();
}else if($_O(e,NoSuchMethodException)){
e.printStackTrace();
}else if($_O(e,InstantiationException)){
e.printStackTrace();
}else if($_O(e,IllegalAccessException)){
e.printStackTrace();
}else if($_O(e,java.lang.reflect.InvocationTargetException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},"~S");
c$.readAll=$_M(c$,"readAll",
function(res){
try{
var baos=new java.io.ByteArrayOutputStream();
var buf=$_A(1024,0);
var read=0;
while((read=res.read(buf))!=-1){
baos.write(buf,0,read);
}
res.close();
return baos.toString();
}catch(e){
if($_O(e,java.io.IOException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},"java.io.InputStream");
$_M(c$,"init",
function(){
var runnableStr=this.getInitParameter("simple.rpc.runnables");
if(runnableStr!=null){
var splits=runnableStr.trim().$plit("\\s*[,;:]\\s*");
for(var i=0;i<splits.length;i++){
var trim=splits[i].trim();
if(trim.length!=0){
this.runnables.add(trim);
}}
}var mappingStr=this.getInitParameter("simple.rpc.mappings");
if(mappingStr!=null){
var splits=mappingStr.trim().$plit("\\s*[,;:]\\s*");
for(var i=0;i<splits.length;i++){
var trim=splits[i].trim();
if(trim.length!=0){
this.mappings.add(trim);
}}
}});
$_V(c$,"doPost",
function(req,resp){
var runnable=this.getRunnableByURL(req.getPathInfo());
if(runnable==null){
resp.sendError(404);
return;
}var writer=resp.getWriter();
resp.setContentType("text/plain");
var request=net.sf.j2s.ajax.SimpleRPCHttpServlet.readAll(req.getInputStream());
runnable.deserialize(request);
runnable.ajaxRun();
writer.write(runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_V(c$,"doGet",
function(req,resp){
var runnable=this.getRunnableByURL(req.getPathInfo());
if(runnable==null){
resp.sendError(404);
return;
}var writer=resp.getWriter();
resp.setContentType("text/plain");
runnable.deserialize(req.getQueryString());
runnable.ajaxRun();
writer.write(runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
});
