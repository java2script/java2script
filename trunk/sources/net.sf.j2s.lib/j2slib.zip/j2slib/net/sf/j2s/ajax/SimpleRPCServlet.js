﻿$_J("net.sf.j2s.ajax");
$_L(["javax.servlet.http.HttpServlet"],"net.sf.j2s.ajax.SimpleRPCServlet",["java.io.ByteArrayOutputStream"],function(){
c$=$_C(function(){
this.runnable=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimpleRPCServlet",javax.servlet.http.HttpServlet);
c$.readAll=$_M(c$,"readAll",
function(res){
try{
var baos=new java.io.ByteArrayOutputStream();
var buf=$_A(1024,0);
var read=0;
while((read=res.read(buf))!=-1){
baos.write(buf,0,read);
}
res.close();
return baos.toString();
}catch(e){
if($_O(e,java.io.IOException)){
e.printStackTrace();
}else{
throw e;
}
}
return null;
},"java.io.InputStream");
$_V(c$,"doPost",
function(req,resp){
if(this.runnable==null){
this.initServletRunnable(req,resp);
}var writer=resp.getWriter();
resp.setContentType("text/plain");
resp.setCharacterEncoding("utf-8");
var request=net.sf.j2s.ajax.SimpleRPCServlet.readAll(req.getInputStream());
this.runnable.deserialize(request);
this.runnable.ajaxRun();
writer.write(this.runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_V(c$,"doGet",
function(req,resp){
if(this.runnable==null){
this.initServletRunnable(req,resp);
}var writer=resp.getWriter();
resp.setContentType("text/plain");
resp.setCharacterEncoding("utf-8");
this.runnable.deserialize(req.getQueryString());
this.runnable.ajaxRun();
writer.write(this.runnable.serialize());
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
});
