﻿$_J("net.sf.j2s.ajax");
$_L(["javax.servlet.http.HttpServlet"],"net.sf.j2s.ajax.SimplePipeHttpServlet",["java.lang.Long","$.StringBuffer","java.util.Date","net.sf.j2s.ajax.SimplePipeHelper","$.SimplePipeRequest"],function(){
c$=$_C(function(){
this.pipeQueryTimeout=5000;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimplePipeHttpServlet",javax.servlet.http.HttpServlet);
$_M(c$,"init",
function(){
var timeoutStr=this.getInitParameter("simple.pipe.query.timeout");
if(timeoutStr!=null){
try{
this.pipeQueryTimeout=Long.parseLong(timeoutStr);
if(this.pipeQueryTimeout<0||this.pipeQueryTimeout>20000){
this.pipeQueryTimeout=20000;
}}catch(e){
if($_O(e,NumberFormatException)){
e.printStackTrace();
}else{
throw e;
}
}
}$_U(this,net.sf.j2s.ajax.SimplePipeHttpServlet,"init",[]);
});
$_V(c$,"doGet",
function(req,resp){
var key=req.getParameter("k");
var type=req.getParameter("t");
if(type==null){
type="c";
}this.doPipe(resp,key,type);
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
$_M(c$,"doPipe",
function(resp,key,type){
var writer=null;
resp.setHeader("Pragma","no-cache");
resp.setHeader("Cache-Control","no-cache");
resp.setDateHeader("Expires",0);
if("n".equals(type)){
var updated=net.sf.j2s.ajax.SimplePipeHelper.notifyPipeStatus(key,true);
resp.setContentType("text/plain; charset=utf-8");
writer=resp.getWriter();
writer.write("$p1p3b$ (\"");
writer.write(key);
writer.write("\",\"");
writer.write(updated?"o":"l");
writer.write("\");");
return;
}resp.setHeader("Transfer-Encoding","chunked");
if("s".equals(type)){
resp.setContentType("text/html; charset=utf-8");
writer=resp.getWriter();
var buffer=new StringBuffer();
buffer.append("<html><head><title></title></head><body>\r\n");
buffer.append("<script type=\"text/javascript\">");
buffer.append("function $ (s) { if (window.parent) window.parent.net.sf.j2s.ajax.SimplePipeRequest.parseReceived (s); }");
buffer.append("</script>\r\n");
writer.write(buffer.toString());
}else{
resp.setContentType("text/plain; charset=utf-8");
writer=resp.getWriter();
}net.sf.j2s.ajax.SimplePipeHelper.notifyPipeStatus(key,true);
var hasPipeData=false;
var beforeLoop=new java.util.Date().getTime();
var vector=null;
while((vector=net.sf.j2s.ajax.SimplePipeHelper.getPipeVector(key))!=null&&net.sf.j2s.ajax.SimplePipeHelper.isPipeLive(key)&&!writer.checkError()){
var size=vector.size();
if(size>0){
for(var i=size-1;i>=0;i--){
var ss=null;
{
if(vector.size()<=0)break;
ss=vector.remove(0);
}if(ss==null)break;
this.output(writer,type,key,ss.serialize());
hasPipeData=true;
writer.flush();
}
}else{
writer.flush();
}var now=new java.util.Date().getTime();
if((vector=net.sf.j2s.ajax.SimplePipeHelper.getPipeVector(key))!=null&&("c".equals(type)||"s".equals(type)||(size<=0&&now-beforeLoop<this.pipeQueryTimeout))){
{
try{
vector.wait(1000);
}catch(e){
if($_O(e,InterruptedException)){
e.printStackTrace();
}else{
throw e;
}
}
}}else{
break;
}}
if(net.sf.j2s.ajax.SimplePipeHelper.getPipeVector(key)==null||!net.sf.j2s.ajax.SimplePipeHelper.isPipeLive(key)){
net.sf.j2s.ajax.SimplePipeHelper.notifyPipeStatus(key,false);
net.sf.j2s.ajax.SimplePipeHelper.pipeTearDown(key);
net.sf.j2s.ajax.SimplePipeHelper.removePipe(key);
try{
this.output(writer,type,key,"d");
hasPipeData=true;
}catch(e){
if($_O(e,Exception)){
}else{
throw e;
}
}
}if(!hasPipeData){
}if("s".equals(type)){
try{
writer.write("</body></html>\r\n");
}catch(e){
if($_O(e,Exception)){
}else{
throw e;
}
}
}},"javax.servlet.http.HttpServletResponse,~S,~S");
$_M(c$,"output",
function(writer,type,key,str){
var buffer=new StringBuffer();
if("s".equals(type)){
buffer.append("<script type=\"text/javascript\">$ (\"");
}else if("x".equals(type)){
buffer.append("$p1p3p$ (\"");
}buffer.append(key);
if("s".equals(type)||"x".equals(type)){
str=str.replaceAll("\\\\","\\\\\\\\").replaceAll("\r","\\\\r").replaceAll("\n","\\\\n").replaceAll("\"", "\\\\\"");
if("s".equals(type)){
str=str.replaceAll("<\\/script>","<\\/scr\"+\"ipt>");
}}buffer.append(str);
if("s".equals(type)){
buffer.append("\");</script>\r\n");
}else if("x".equals(type)){
buffer.append("\");\r\n");
}writer.write(buffer.toString());
},"java.io.PrintWriter,~S,~S,~S");
$_V(c$,"doPost",
function(req,resp){
this.doGet(req,resp);
},"javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse");
});
