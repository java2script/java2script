﻿$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.SimplePipeRunnable"],"net.sf.j2s.ajax.SessionPipeRunnable",null,function(){
c$=$_C(function(){
this.session=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SessionPipeRunnable",net.sf.j2s.ajax.SimplePipeRunnable);
$_V(c$,"pipeDestroy",
function(){
});
$_V(c$,"pipeSetup",
function(){
});
$_V(c$,"through",
function(args){
var cs=this.convert(args);
for(var i=0;i<cs.length;i++){
cs[i].session=this.session;
}
return cs;
},"~A");
$_M(c$,"deal",
function(ss){
if($_O(ss,net.sf.j2s.ajax.CompoundSerializable)){
var cs=ss;
if(cs.session==null||!cs.session.equals(this.session)){
return false;
}return $_U(this,net.sf.j2s.ajax.SessionPipeRunnable,"deal",[cs]);
}return false;
},"net.sf.j2s.ajax.SimpleSerializable");
$_s(c$,"session","s");
});
