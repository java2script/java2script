$_J("net.sf.j2s.ajax");
c$=$_T(net.sf.j2s.ajax,"AClass");
c$.load=$_M(c$,"load",
function(clazzName,afterLoaded){
ClazzLoader.loadClass(clazzName,function(){
if($_O(afterLoaded,net.sf.j2s.ajax.ARunnable)){
var clz=Clazz.evalType(clazzName);
afterLoaded.setClazz(clz);
}
afterLoaded.run();
},false,true);
},"~S,Runnable");
