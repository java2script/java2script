﻿Clazz.declarePackage ("org.eclipse.core.runtime");
c$ = Clazz.declareInterface (org.eclipse.core.runtime, "ILibrary");
Clazz.defineStatics (c$,
"CODE", "code",
"RESOURCE", "resource");
