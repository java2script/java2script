﻿Clazz.declarePackage ("org.eclipse.core.runtime");
Clazz.load (["java.util.EventListener"], "org.eclipse.core.runtime.ILogListener", null, function () {
Clazz.declareInterface (org.eclipse.core.runtime, "ILogListener", java.util.EventListener);
});
