﻿Clazz.declarePackage ("org.eclipse.core.runtime");
Clazz.load (["org.eclipse.core.runtime.IProgressMonitor"], "org.eclipse.core.runtime.IProgressMonitorWithBlocking", null, function () {
Clazz.declareInterface (org.eclipse.core.runtime, "IProgressMonitorWithBlocking", org.eclipse.core.runtime.IProgressMonitor);
});
