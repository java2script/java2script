﻿Clazz.declarePackage ("org.eclipse.core.runtime");
Clazz.declareInterface (org.eclipse.core.runtime, "IProductProvider");
