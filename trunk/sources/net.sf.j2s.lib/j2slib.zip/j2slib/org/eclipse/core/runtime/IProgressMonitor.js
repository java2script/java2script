﻿Clazz.declarePackage ("org.eclipse.core.runtime");
c$ = Clazz.declareInterface (org.eclipse.core.runtime, "IProgressMonitor");
Clazz.defineStatics (c$,
"UNKNOWN", -1);
