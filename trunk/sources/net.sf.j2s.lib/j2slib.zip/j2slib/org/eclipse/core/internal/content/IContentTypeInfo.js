﻿Clazz.declarePackage ("org.eclipse.core.internal.content");
Clazz.declareInterface (org.eclipse.core.internal.content, "IContentTypeInfo");
