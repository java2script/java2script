﻿$_L(["$wt.events.TypedEvent"],"$wt.browser.TitleEvent",null,function(){
c$=$_C(function(){
this.title=null;
$_Z(this,arguments);
},$wt.browser,"TitleEvent",$wt.events.TypedEvent);
});
