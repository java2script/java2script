﻿$_I($wt.internal,"CloneableCompatibility",Cloneable);
