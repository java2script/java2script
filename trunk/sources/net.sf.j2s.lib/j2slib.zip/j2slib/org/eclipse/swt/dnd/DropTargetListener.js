$_L(["$wt.internal.SWTEventListener"],"$wt.dnd.DropTargetListener",null,function(){
$_I($wt.dnd,"DropTargetListener",$wt.internal.SWTEventListener);
});
