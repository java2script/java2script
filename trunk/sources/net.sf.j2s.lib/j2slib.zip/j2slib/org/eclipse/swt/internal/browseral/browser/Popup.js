$_J("org.eclipse.swt.internal.browseral.browser");
c$=$_T($wt.internal.browseral.browser,"Popup");
