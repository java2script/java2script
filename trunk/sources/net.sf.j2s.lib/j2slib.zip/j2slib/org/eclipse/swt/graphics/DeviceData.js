﻿c$=$_C(function(){
this.debug=false;
this.tracking=false;
this.errors=null;
this.objects=null;
$_Z(this,arguments);
},$wt.graphics,"DeviceData");
