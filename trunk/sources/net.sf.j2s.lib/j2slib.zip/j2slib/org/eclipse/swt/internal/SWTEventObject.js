$_L(["java.util.EventObject"],"$wt.internal.SWTEventObject",null,function(){
c$=$_T($wt.internal,"SWTEventObject",java.util.EventObject);
});
