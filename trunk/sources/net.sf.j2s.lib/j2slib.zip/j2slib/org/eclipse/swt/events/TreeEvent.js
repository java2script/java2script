$_L(["$wt.events.SelectionEvent"],"$wt.events.TreeEvent",["$wt.widgets.Event"],function(){
c$=$_T($wt.events,"TreeEvent",$wt.events.SelectionEvent);
});
