$_L(["$wt.events.TypedEvent"],"$wt.events.ArmEvent",null,function(){
c$=$_T($wt.events,"ArmEvent",$wt.events.TypedEvent);
});
