﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.ControlListener",null,function(){
$_I($wt.events,"ControlListener",$wt.internal.SWTEventListener);
});
