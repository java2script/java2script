$_L(["$wt.events.TypedEvent"],"$wt.events.HelpEvent",["$wt.widgets.Event"],function(){
c$=$_T($wt.events,"HelpEvent",$wt.events.TypedEvent);
});
