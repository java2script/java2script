﻿$_L(["$wt.events.TypedEvent"],"$wt.events.ModifyEvent",null,function(){
c$=$_T($wt.events,"ModifyEvent",$wt.events.TypedEvent);
});
