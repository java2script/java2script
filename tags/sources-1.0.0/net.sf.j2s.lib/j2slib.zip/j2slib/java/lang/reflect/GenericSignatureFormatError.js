﻿$_L(["java.lang.ClassFormatError"],"java.lang.reflect.GenericSignatureFormatError",null,function(){
c$=$_T(java.lang.reflect,"GenericSignatureFormatError",ClassFormatError);
});
