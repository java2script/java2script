﻿$_L(["java.lang.Throwable"],"java.lang.Error",null,function(){
c$=$_T(java.lang,"Error",Throwable);
});
