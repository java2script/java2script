package net.sf.j2s.ajax;

public interface ISimpleConstant {

}
