package net.sf.j2s.ajax;

public interface SimpleFactory {

	public SimpleSerializable createInstance();
	
}
