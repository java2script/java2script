package org.sgx.j2s.doc.userGuide.examples;

public class FunctionProblemExample1 {

}
