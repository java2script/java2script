﻿$_J("net.sf.j2s.store");
$_I(net.sf.j2s.store,"IStore");
