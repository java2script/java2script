﻿Clazz.declarePackage ("org.eclipse.core.runtime.content");
Clazz.declareInterface (org.eclipse.core.runtime.content, "IContentTypeMatcher");
