﻿Clazz.declarePackage ("org.eclipse.core.runtime.dynamichelpers");
Clazz.declareInterface (org.eclipse.core.runtime.dynamichelpers, "IFilter");
