﻿Clazz.declarePackage ("org.eclipse.core.runtime.content");
Clazz.load (["org.eclipse.core.runtime.content.IContentDescriber"], "org.eclipse.core.runtime.content.ITextContentDescriber", null, function () {
Clazz.declareInterface (org.eclipse.core.runtime.content, "ITextContentDescriber", org.eclipse.core.runtime.content.IContentDescriber);
});
