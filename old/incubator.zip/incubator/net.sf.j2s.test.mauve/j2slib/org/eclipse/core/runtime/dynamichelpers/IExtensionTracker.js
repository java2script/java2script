﻿Clazz.declarePackage ("org.eclipse.core.runtime.dynamichelpers");
c$ = Clazz.declareInterface (org.eclipse.core.runtime.dynamichelpers, "IExtensionTracker");
Clazz.defineStatics (c$,
"REF_STRONG", 0,
"REF_SOFT", 1,
"REF_WEAK", 2);
