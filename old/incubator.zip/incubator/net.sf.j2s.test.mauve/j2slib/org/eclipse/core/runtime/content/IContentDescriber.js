﻿Clazz.declarePackage ("org.eclipse.core.runtime.content");
c$ = Clazz.declareInterface (org.eclipse.core.runtime.content, "IContentDescriber");
Clazz.defineStatics (c$,
"INDETERMINATE", 1,
"INVALID", 0,
"VALID", 2);
