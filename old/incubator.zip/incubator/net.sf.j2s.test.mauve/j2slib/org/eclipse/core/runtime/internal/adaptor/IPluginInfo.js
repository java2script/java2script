﻿Clazz.declarePackage ("org.eclipse.core.runtime.internal.adaptor");
Clazz.declareInterface (org.eclipse.core.runtime.internal.adaptor, "IPluginInfo");
