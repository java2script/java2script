#cleanup script
#author: sgurin

rm -rf CATALOG.local *dsl db2html* *pdf dist


