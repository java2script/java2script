package net.sf.j2s.ajax;

public class CompoundSerializable extends SimpleSerializable {

	public String session;

}
